/**
* Utilidades para cálculo de ocupación y detección de colisiones de polos
* en cuadros de cargas de tableros eléctricos.
* 
* Regla de disposición:
* - Columna Izquierda: Polos impares [1, 3, 5, 7, ...]
* - Columna Derecha: Polos pares [2, 4, 6, 8, ...]
* - Disyuntor Multipolo (1P, 2P, 3P): Ocupa polos sucesivos en su respectiva columna (salto de +2).
*/
/**
* Retorna el arreglo de polos físicos ocupados dado el polo inicial y la cantidad de polos.
* @param {number|string} startPole - Polo inicial (ej. 1, 2, 3...)
* @param {number|string} numPoles - Cantidad de polos (1, 2, 3)
* @returns {number[]} Arreglo de números de polos (ej. [1, 3] para 2P en polo 1)
*/
export const getRequiredPoles = (startPole, numPoles = 1) => {
	const start = parseInt(startPole, 10);
	const n = parseInt(numPoles, 10);
	if (isNaN(start) || start < 1) return [];
	const count = isNaN(n) || n < 1 ? 1 : Math.min(n, 3);
	const poles = [];
	for (let i = 0; i < count; i++) {
		poles.push(start + i * 2);
	}
	return poles;
};
/**
* Construye un mapa de ocupación de polos a partir de la lista de circuitos de un tablero.
* @param {Array} circuits - Arreglo de circuitos del tablero
* @param {string|number|null} excludeCircuitId - ID del circuito a excluir (en caso de edición)
* @returns {Object} Mapa { [polo]: { circuitId, descripcion, numPolos, posicionPolo, amperaje, estado, tipoDestino } }
*/
export const buildPolesOccupancyMap = (circuits = [], excludeCircuitId = null) => {
	const map = {};
	if (!Array.isArray(circuits)) return map;
	circuits.forEach((circ) => {
		// Ignorar el circuito que se está editando
		if (excludeCircuitId && (circ.id === excludeCircuitId || circ.id === `auto_${excludeCircuitId}`)) {
			return;
		}
		// Ignorar circuitos automáticos sin personalizar o vacíos si no tienen carga o configuración
		const isAutoEmpty = circ.id?.startsWith?.("auto_") && !circ.breaker?.amp && !circ.equipo && circ.equipo !== "RESERVA_MANUAL";
		if (isAutoEmpty) {
			return;
		}
		// Ignorar circuitos que son puramente RESERVA o DISPONIBLE sin equipo real asignado
		const isReserva = !circ.equipo || circ.equipo === "RESERVA" || circ.equipo === "DISPONIBLE" || circ.tipoDestino === "RESERVA";
		const hasRealLoad = circ.equipo && circ.equipo !== "RESERVA" && circ.equipo !== "DISPONIBLE" && !circ.equipo.startsWith("RESERVA");
		if (isReserva && !hasRealLoad && !circ.vinculadoId && !circ.elementoDestinoId) {
			return;
		}
		// Determinar los polos ocupados por este circuito
		let occupiedPoles = [];
		if (Array.isArray(circ.poles) && circ.poles.length > 0) {
			occupiedPoles = circ.poles.map((p) => parseInt(p, 10)).filter((p) => !isNaN(p));
		} else if (circ.posicionPolo !== undefined) {
			occupiedPoles = getRequiredPoles(circ.posicionPolo, circ.numPolos || 1);
		}
		const estadoNorm = circ.estado === "RESERVA" || circ.tipoDestino === "RESERVA" || circ.equipo === "RESERVA" ? "RESERVA" : "ACTIVO";
		const descripcion = circ.descripcion || circ.equipo || circ.nombre || `Circuito Polo ${occupiedPoles[0] || "N/A"}`;
		const amperaje = circ.amperaje || circ.breaker?.amp || null;
		occupiedPoles.forEach((pole) => {
			map[pole] = {
				circuitId: circ.id,
				descripcion,
				posicionPolo: circ.posicionPolo || occupiedPoles[0],
				numPolos: circ.numPolos || occupiedPoles.length,
				amperaje,
				estado: estadoNorm,
				tipoDestino: circ.tipoDestino || "ARTEFACTO",
				breaker: circ.breaker || null
			};
		});
	});
	return map;
};
/**
* Valida si una asignación de polos colisiona con circuitos existentes o excede la capacidad máxima.
* @param {Object} params
* @param {number|string} params.posicionPolo - Polo inicial
* @param {number|string} params.numPolos - Cantidad de polos (1, 2, 3)
* @param {number} [params.maxPolos=42] - Capacidad máxima de polos del tablero
* @param {Array} [params.circuits=[]] - Circuitos existentes en el tablero
* @param {string|number|null} [params.excludeCircuitId=null] - ID del circuito en edición
* @returns {Object} { isValid, requiredPoles, exceedsMax, maxPole, conflicts, conflictMessages, occupancyMap }
*/
export const validatePoleOccupancy = ({ posicionPolo, numPolos = 1, maxPolos = 42, circuits = [], excludeCircuitId = null }) => {
	const start = parseInt(posicionPolo, 10);
	const count = parseInt(numPolos, 10) || 1;
	const max = parseInt(maxPolos, 10) || 42;
	if (isNaN(start) || start < 1) {
		return {
			isValid: false,
			requiredPoles: [],
			exceedsMax: false,
			maxPole: null,
			conflicts: [],
			conflictMessages: ["Debe indicar un polo inicial válido mayor o igual a 1."],
			occupancyMap: {}
		};
	}
	if (count < 1 || count > 3) {
		return {
			isValid: false,
			requiredPoles: [],
			exceedsMax: false,
			maxPole: null,
			conflicts: [],
			conflictMessages: ["El número de polos debe ser 1 (Monofásico), 2 (Bifásico) o 3 (Trifásico)."],
			occupancyMap: {}
		};
	}
	const requiredPoles = getRequiredPoles(start, count);
	const highestPole = Math.max(...requiredPoles);
	const exceedsMax = highestPole > max;
	const occupancyMap = buildPolesOccupancyMap(circuits, excludeCircuitId);
	const conflicts = [];
	const conflictMessages = [];
	if (exceedsMax) {
		conflictMessages.push(`Los polos requeridos [${requiredPoles.join(", ")}] superan la capacidad máxima del tablero (${max} polos). El polo ${highestPole} está fuera de rango.`);
	}
	requiredPoles.forEach((pole) => {
		if (occupancyMap[pole]) {
			const occ = occupancyMap[pole];
			conflicts.push({
				pole,
				occupiedBy: occ
			});
			conflictMessages.push(`El polo ${pole} ya está ocupado por "${occ.descripcion}" (Estado: ${occ.estado}${occ.amperaje ? `, ${occ.amperaje}A` : ""}).`);
		}
	});
	const isValid = !exceedsMax && conflicts.length === 0;
	return {
		isValid,
		requiredPoles,
		exceedsMax,
		maxPole: highestPole,
		conflicts,
		conflictMessages,
		occupancyMap
	};
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JBLE9BQU8sTUFBTSxvQkFBb0IsV0FBVyxXQUFXLE1BQU07Q0FDM0QsTUFBTSxRQUFRLFNBQVMsV0FBVyxFQUFFO0NBQ3BDLE1BQU0sSUFBSSxTQUFTLFVBQVUsRUFBRTtDQUMvQixJQUFJLE1BQU0sS0FBSyxLQUFLLFFBQVEsR0FBRyxPQUFPLENBQUM7Q0FDdkMsTUFBTSxRQUFRLE1BQU0sQ0FBQyxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLENBQUM7Q0FFbkQsTUFBTSxRQUFRLENBQUM7Q0FDZixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLO0VBQzlCLE1BQU0sS0FBSyxRQUFRLElBQUksQ0FBQztDQUMxQjtDQUNBLE9BQU87QUFDVDs7Ozs7OztBQVFBLE9BQU8sTUFBTSwwQkFBMEIsV0FBVyxDQUFDLEdBQUcsbUJBQW1CLFNBQVM7Q0FDaEYsTUFBTSxNQUFNLENBQUM7Q0FFYixJQUFJLENBQUMsTUFBTSxRQUFRLFFBQVEsR0FBRyxPQUFPO0NBRXJDLFNBQVMsU0FBUyxTQUFTOztFQUV6QixJQUFJLHFCQUFxQixLQUFLLE9BQU8sb0JBQW9CLEtBQUssT0FBTyxRQUFRLHFCQUFxQjtHQUNoRztFQUNGOztFQUdBLE1BQU0sY0FBYyxLQUFLLElBQUksYUFBYSxPQUFPLEtBQU0sQ0FBQyxLQUFLLFNBQVMsT0FBTyxDQUFDLEtBQUssVUFBVSxLQUFLLFdBQVc7RUFDN0csSUFBSSxhQUFhO0dBQ2Y7RUFDRjs7RUFHQSxNQUFNLFlBQVksQ0FBQyxLQUFLLFVBQVUsS0FBSyxXQUFXLGFBQWEsS0FBSyxXQUFXLGdCQUFnQixLQUFLLGdCQUFnQjtFQUNwSCxNQUFNLGNBQWMsS0FBSyxVQUFVLEtBQUssV0FBVyxhQUFhLEtBQUssV0FBVyxnQkFBZ0IsQ0FBQyxLQUFLLE9BQU8sV0FBVyxTQUFTO0VBQ2pJLElBQUksYUFBYSxDQUFDLGVBQWUsQ0FBQyxLQUFLLGVBQWUsQ0FBQyxLQUFLLG1CQUFtQjtHQUM3RTtFQUNGOztFQUdBLElBQUksZ0JBQWdCLENBQUM7RUFDckIsSUFBSSxNQUFNLFFBQVEsS0FBSyxLQUFLLEtBQUssS0FBSyxNQUFNLFNBQVMsR0FBRztHQUN0RCxnQkFBZ0IsS0FBSyxNQUFNLEtBQUssTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztFQUNoRixPQUFPLElBQUksS0FBSyxpQkFBaUIsV0FBVztHQUMxQyxnQkFBZ0IsaUJBQWlCLEtBQUssY0FBYyxLQUFLLFlBQVksQ0FBQztFQUN4RTtFQUVBLE1BQU0sYUFBYyxLQUFLLFdBQVcsYUFBYSxLQUFLLGdCQUFnQixhQUFhLEtBQUssV0FBVyxZQUMvRixZQUNBO0VBRUosTUFBTSxjQUFjLEtBQUssZUFBZSxLQUFLLFVBQVUsS0FBSyxVQUFVLGlCQUFpQixjQUFjLE1BQU07RUFDM0csTUFBTSxXQUFXLEtBQUssWUFBWSxLQUFLLFNBQVMsT0FBTztFQUV2RCxjQUFjLFNBQVMsU0FBUztHQUM5QixJQUFJLFFBQVE7SUFDVixXQUFXLEtBQUs7SUFDaEI7SUFDQSxjQUFjLEtBQUssZ0JBQWdCLGNBQWM7SUFDakQsVUFBVSxLQUFLLFlBQVksY0FBYztJQUN6QztJQUNBLFFBQVE7SUFDUixhQUFhLEtBQUssZUFBZTtJQUNqQyxTQUFTLEtBQUssV0FBVztHQUMzQjtFQUNGLENBQUM7Q0FDSCxDQUFDO0NBRUQsT0FBTztBQUNUOzs7Ozs7Ozs7OztBQVlBLE9BQU8sTUFBTSx5QkFBeUIsRUFDcEMsY0FDQSxXQUFXLEdBQ1gsV0FBVyxJQUNYLFdBQVcsQ0FBQyxHQUNaLG1CQUFtQixXQUNmO0NBQ0osTUFBTSxRQUFRLFNBQVMsY0FBYyxFQUFFO0NBQ3ZDLE1BQU0sUUFBUSxTQUFTLFVBQVUsRUFBRSxLQUFLO0NBQ3hDLE1BQU0sTUFBTSxTQUFTLFVBQVUsRUFBRSxLQUFLO0NBRXRDLElBQUksTUFBTSxLQUFLLEtBQUssUUFBUSxHQUFHO0VBQzdCLE9BQU87R0FDTCxTQUFTO0dBQ1QsZUFBZSxDQUFDO0dBQ2hCLFlBQVk7R0FDWixTQUFTO0dBQ1QsV0FBVyxDQUFDO0dBQ1osa0JBQWtCLENBQUMsd0RBQXdEO0dBQzNFLGNBQWMsQ0FBQztFQUNqQjtDQUNGO0NBRUEsSUFBSSxRQUFRLEtBQUssUUFBUSxHQUFHO0VBQzFCLE9BQU87R0FDTCxTQUFTO0dBQ1QsZUFBZSxDQUFDO0dBQ2hCLFlBQVk7R0FDWixTQUFTO0dBQ1QsV0FBVyxDQUFDO0dBQ1osa0JBQWtCLENBQUMsMkVBQTJFO0dBQzlGLGNBQWMsQ0FBQztFQUNqQjtDQUNGO0NBRUEsTUFBTSxnQkFBZ0IsaUJBQWlCLE9BQU8sS0FBSztDQUNuRCxNQUFNLGNBQWMsS0FBSyxJQUFJLEdBQUcsYUFBYTtDQUM3QyxNQUFNLGFBQWEsY0FBYztDQUVqQyxNQUFNLGVBQWUsdUJBQXVCLFVBQVUsZ0JBQWdCO0NBQ3RFLE1BQU0sWUFBWSxDQUFDO0NBQ25CLE1BQU0sbUJBQW1CLENBQUM7Q0FFMUIsSUFBSSxZQUFZO0VBQ2QsaUJBQWlCLEtBQ2YseUJBQXlCLGNBQWMsS0FBSyxJQUFJLEVBQUUsNkNBQTZDLElBQUksbUJBQW1CLFlBQVksc0JBQ3BJO0NBQ0Y7Q0FFQSxjQUFjLFNBQVMsU0FBUztFQUM5QixJQUFJLGFBQWEsT0FBTztHQUN0QixNQUFNLE1BQU0sYUFBYTtHQUN6QixVQUFVLEtBQUs7SUFDYjtJQUNBLFlBQVk7R0FDZCxDQUFDO0dBQ0QsaUJBQWlCLEtBQ2YsV0FBVyxLQUFLLHdCQUF3QixJQUFJLFlBQVksYUFBYSxJQUFJLFNBQVMsSUFBSSxXQUFXLEtBQUssSUFBSSxTQUFTLEtBQUssR0FBRyxHQUM3SDtFQUNGO0NBQ0YsQ0FBQztDQUVELE1BQU0sVUFBVSxDQUFDLGNBQWMsVUFBVSxXQUFXO0NBRXBELE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQSxTQUFTO0VBQ1Q7RUFDQTtFQUNBO0NBQ0Y7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJwb2xlVmFsaWRhdGlvbi5qcyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFV0aWxpZGFkZXMgcGFyYSBjw6FsY3VsbyBkZSBvY3VwYWNpw7NuIHkgZGV0ZWNjacOzbiBkZSBjb2xpc2lvbmVzIGRlIHBvbG9zXG4gKiBlbiBjdWFkcm9zIGRlIGNhcmdhcyBkZSB0YWJsZXJvcyBlbMOpY3RyaWNvcy5cbiAqIFxuICogUmVnbGEgZGUgZGlzcG9zaWNpw7NuOlxuICogLSBDb2x1bW5hIEl6cXVpZXJkYTogUG9sb3MgaW1wYXJlcyBbMSwgMywgNSwgNywgLi4uXVxuICogLSBDb2x1bW5hIERlcmVjaGE6IFBvbG9zIHBhcmVzIFsyLCA0LCA2LCA4LCAuLi5dXG4gKiAtIERpc3l1bnRvciBNdWx0aXBvbG8gKDFQLCAyUCwgM1ApOiBPY3VwYSBwb2xvcyBzdWNlc2l2b3MgZW4gc3UgcmVzcGVjdGl2YSBjb2x1bW5hIChzYWx0byBkZSArMikuXG4gKi9cblxuLyoqXG4gKiBSZXRvcm5hIGVsIGFycmVnbG8gZGUgcG9sb3MgZsOtc2ljb3Mgb2N1cGFkb3MgZGFkbyBlbCBwb2xvIGluaWNpYWwgeSBsYSBjYW50aWRhZCBkZSBwb2xvcy5cbiAqIEBwYXJhbSB7bnVtYmVyfHN0cmluZ30gc3RhcnRQb2xlIC0gUG9sbyBpbmljaWFsIChlai4gMSwgMiwgMy4uLilcbiAqIEBwYXJhbSB7bnVtYmVyfHN0cmluZ30gbnVtUG9sZXMgLSBDYW50aWRhZCBkZSBwb2xvcyAoMSwgMiwgMylcbiAqIEByZXR1cm5zIHtudW1iZXJbXX0gQXJyZWdsbyBkZSBuw7ptZXJvcyBkZSBwb2xvcyAoZWouIFsxLCAzXSBwYXJhIDJQIGVuIHBvbG8gMSlcbiAqL1xuZXhwb3J0IGNvbnN0IGdldFJlcXVpcmVkUG9sZXMgPSAoc3RhcnRQb2xlLCBudW1Qb2xlcyA9IDEpID0+IHtcbiAgY29uc3Qgc3RhcnQgPSBwYXJzZUludChzdGFydFBvbGUsIDEwKTtcbiAgY29uc3QgbiA9IHBhcnNlSW50KG51bVBvbGVzLCAxMCk7XG4gIGlmIChpc05hTihzdGFydCkgfHwgc3RhcnQgPCAxKSByZXR1cm4gW107XG4gIGNvbnN0IGNvdW50ID0gaXNOYU4obikgfHwgbiA8IDEgPyAxIDogTWF0aC5taW4obiwgMyk7XG5cbiAgY29uc3QgcG9sZXMgPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudDsgaSsrKSB7XG4gICAgcG9sZXMucHVzaChzdGFydCArIGkgKiAyKTtcbiAgfVxuICByZXR1cm4gcG9sZXM7XG59O1xuXG4vKipcbiAqIENvbnN0cnV5ZSB1biBtYXBhIGRlIG9jdXBhY2nDs24gZGUgcG9sb3MgYSBwYXJ0aXIgZGUgbGEgbGlzdGEgZGUgY2lyY3VpdG9zIGRlIHVuIHRhYmxlcm8uXG4gKiBAcGFyYW0ge0FycmF5fSBjaXJjdWl0cyAtIEFycmVnbG8gZGUgY2lyY3VpdG9zIGRlbCB0YWJsZXJvXG4gKiBAcGFyYW0ge3N0cmluZ3xudW1iZXJ8bnVsbH0gZXhjbHVkZUNpcmN1aXRJZCAtIElEIGRlbCBjaXJjdWl0byBhIGV4Y2x1aXIgKGVuIGNhc28gZGUgZWRpY2nDs24pXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBNYXBhIHsgW3BvbG9dOiB7IGNpcmN1aXRJZCwgZGVzY3JpcGNpb24sIG51bVBvbG9zLCBwb3NpY2lvblBvbG8sIGFtcGVyYWplLCBlc3RhZG8sIHRpcG9EZXN0aW5vIH0gfVxuICovXG5leHBvcnQgY29uc3QgYnVpbGRQb2xlc09jY3VwYW5jeU1hcCA9IChjaXJjdWl0cyA9IFtdLCBleGNsdWRlQ2lyY3VpdElkID0gbnVsbCkgPT4ge1xuICBjb25zdCBtYXAgPSB7fTtcblxuICBpZiAoIUFycmF5LmlzQXJyYXkoY2lyY3VpdHMpKSByZXR1cm4gbWFwO1xuXG4gIGNpcmN1aXRzLmZvckVhY2goKGNpcmMpID0+IHtcbiAgICAvLyBJZ25vcmFyIGVsIGNpcmN1aXRvIHF1ZSBzZSBlc3TDoSBlZGl0YW5kb1xuICAgIGlmIChleGNsdWRlQ2lyY3VpdElkICYmIChjaXJjLmlkID09PSBleGNsdWRlQ2lyY3VpdElkIHx8IGNpcmMuaWQgPT09IGBhdXRvXyR7ZXhjbHVkZUNpcmN1aXRJZH1gKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIElnbm9yYXIgY2lyY3VpdG9zIGF1dG9tw6F0aWNvcyBzaW4gcGVyc29uYWxpemFyIG8gdmFjw61vcyBzaSBubyB0aWVuZW4gY2FyZ2EgbyBjb25maWd1cmFjacOzblxuICAgIGNvbnN0IGlzQXV0b0VtcHR5ID0gY2lyYy5pZD8uc3RhcnRzV2l0aD8uKCdhdXRvXycpICYmICghY2lyYy5icmVha2VyPy5hbXAgJiYgIWNpcmMuZXF1aXBvICYmIGNpcmMuZXF1aXBvICE9PSAnUkVTRVJWQV9NQU5VQUwnKTtcbiAgICBpZiAoaXNBdXRvRW1wdHkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBJZ25vcmFyIGNpcmN1aXRvcyBxdWUgc29uIHB1cmFtZW50ZSBSRVNFUlZBIG8gRElTUE9OSUJMRSBzaW4gZXF1aXBvIHJlYWwgYXNpZ25hZG9cbiAgICBjb25zdCBpc1Jlc2VydmEgPSAhY2lyYy5lcXVpcG8gfHwgY2lyYy5lcXVpcG8gPT09ICdSRVNFUlZBJyB8fCBjaXJjLmVxdWlwbyA9PT0gJ0RJU1BPTklCTEUnIHx8IGNpcmMudGlwb0Rlc3Rpbm8gPT09ICdSRVNFUlZBJztcbiAgICBjb25zdCBoYXNSZWFsTG9hZCA9IGNpcmMuZXF1aXBvICYmIGNpcmMuZXF1aXBvICE9PSAnUkVTRVJWQScgJiYgY2lyYy5lcXVpcG8gIT09ICdESVNQT05JQkxFJyAmJiAhY2lyYy5lcXVpcG8uc3RhcnRzV2l0aCgnUkVTRVJWQScpO1xuICAgIGlmIChpc1Jlc2VydmEgJiYgIWhhc1JlYWxMb2FkICYmICFjaXJjLnZpbmN1bGFkb0lkICYmICFjaXJjLmVsZW1lbnRvRGVzdGlub0lkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gRGV0ZXJtaW5hciBsb3MgcG9sb3Mgb2N1cGFkb3MgcG9yIGVzdGUgY2lyY3VpdG9cbiAgICBsZXQgb2NjdXBpZWRQb2xlcyA9IFtdO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGNpcmMucG9sZXMpICYmIGNpcmMucG9sZXMubGVuZ3RoID4gMCkge1xuICAgICAgb2NjdXBpZWRQb2xlcyA9IGNpcmMucG9sZXMubWFwKChwKSA9PiBwYXJzZUludChwLCAxMCkpLmZpbHRlcigocCkgPT4gIWlzTmFOKHApKTtcbiAgICB9IGVsc2UgaWYgKGNpcmMucG9zaWNpb25Qb2xvICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIG9jY3VwaWVkUG9sZXMgPSBnZXRSZXF1aXJlZFBvbGVzKGNpcmMucG9zaWNpb25Qb2xvLCBjaXJjLm51bVBvbG9zIHx8IDEpO1xuICAgIH1cblxuICAgIGNvbnN0IGVzdGFkb05vcm0gPSAoY2lyYy5lc3RhZG8gPT09ICdSRVNFUlZBJyB8fCBjaXJjLnRpcG9EZXN0aW5vID09PSAnUkVTRVJWQScgfHwgY2lyYy5lcXVpcG8gPT09ICdSRVNFUlZBJylcbiAgICAgID8gJ1JFU0VSVkEnXG4gICAgICA6ICdBQ1RJVk8nO1xuXG4gICAgY29uc3QgZGVzY3JpcGNpb24gPSBjaXJjLmRlc2NyaXBjaW9uIHx8IGNpcmMuZXF1aXBvIHx8IGNpcmMubm9tYnJlIHx8IGBDaXJjdWl0byBQb2xvICR7b2NjdXBpZWRQb2xlc1swXSB8fCAnTi9BJ31gO1xuICAgIGNvbnN0IGFtcGVyYWplID0gY2lyYy5hbXBlcmFqZSB8fCBjaXJjLmJyZWFrZXI/LmFtcCB8fCBudWxsO1xuXG4gICAgb2NjdXBpZWRQb2xlcy5mb3JFYWNoKChwb2xlKSA9PiB7XG4gICAgICBtYXBbcG9sZV0gPSB7XG4gICAgICAgIGNpcmN1aXRJZDogY2lyYy5pZCxcbiAgICAgICAgZGVzY3JpcGNpb24sXG4gICAgICAgIHBvc2ljaW9uUG9sbzogY2lyYy5wb3NpY2lvblBvbG8gfHwgb2NjdXBpZWRQb2xlc1swXSxcbiAgICAgICAgbnVtUG9sb3M6IGNpcmMubnVtUG9sb3MgfHwgb2NjdXBpZWRQb2xlcy5sZW5ndGgsXG4gICAgICAgIGFtcGVyYWplLFxuICAgICAgICBlc3RhZG86IGVzdGFkb05vcm0sXG4gICAgICAgIHRpcG9EZXN0aW5vOiBjaXJjLnRpcG9EZXN0aW5vIHx8ICdBUlRFRkFDVE8nLFxuICAgICAgICBicmVha2VyOiBjaXJjLmJyZWFrZXIgfHwgbnVsbFxuICAgICAgfTtcbiAgICB9KTtcbiAgfSk7XG5cbiAgcmV0dXJuIG1hcDtcbn07XG5cbi8qKlxuICogVmFsaWRhIHNpIHVuYSBhc2lnbmFjacOzbiBkZSBwb2xvcyBjb2xpc2lvbmEgY29uIGNpcmN1aXRvcyBleGlzdGVudGVzIG8gZXhjZWRlIGxhIGNhcGFjaWRhZCBtw6F4aW1hLlxuICogQHBhcmFtIHtPYmplY3R9IHBhcmFtc1xuICogQHBhcmFtIHtudW1iZXJ8c3RyaW5nfSBwYXJhbXMucG9zaWNpb25Qb2xvIC0gUG9sbyBpbmljaWFsXG4gKiBAcGFyYW0ge251bWJlcnxzdHJpbmd9IHBhcmFtcy5udW1Qb2xvcyAtIENhbnRpZGFkIGRlIHBvbG9zICgxLCAyLCAzKVxuICogQHBhcmFtIHtudW1iZXJ9IFtwYXJhbXMubWF4UG9sb3M9NDJdIC0gQ2FwYWNpZGFkIG3DoXhpbWEgZGUgcG9sb3MgZGVsIHRhYmxlcm9cbiAqIEBwYXJhbSB7QXJyYXl9IFtwYXJhbXMuY2lyY3VpdHM9W11dIC0gQ2lyY3VpdG9zIGV4aXN0ZW50ZXMgZW4gZWwgdGFibGVyb1xuICogQHBhcmFtIHtzdHJpbmd8bnVtYmVyfG51bGx9IFtwYXJhbXMuZXhjbHVkZUNpcmN1aXRJZD1udWxsXSAtIElEIGRlbCBjaXJjdWl0byBlbiBlZGljacOzblxuICogQHJldHVybnMge09iamVjdH0geyBpc1ZhbGlkLCByZXF1aXJlZFBvbGVzLCBleGNlZWRzTWF4LCBtYXhQb2xlLCBjb25mbGljdHMsIGNvbmZsaWN0TWVzc2FnZXMsIG9jY3VwYW5jeU1hcCB9XG4gKi9cbmV4cG9ydCBjb25zdCB2YWxpZGF0ZVBvbGVPY2N1cGFuY3kgPSAoe1xuICBwb3NpY2lvblBvbG8sXG4gIG51bVBvbG9zID0gMSxcbiAgbWF4UG9sb3MgPSA0MixcbiAgY2lyY3VpdHMgPSBbXSxcbiAgZXhjbHVkZUNpcmN1aXRJZCA9IG51bGxcbn0pID0+IHtcbiAgY29uc3Qgc3RhcnQgPSBwYXJzZUludChwb3NpY2lvblBvbG8sIDEwKTtcbiAgY29uc3QgY291bnQgPSBwYXJzZUludChudW1Qb2xvcywgMTApIHx8IDE7XG4gIGNvbnN0IG1heCA9IHBhcnNlSW50KG1heFBvbG9zLCAxMCkgfHwgNDI7XG5cbiAgaWYgKGlzTmFOKHN0YXJ0KSB8fCBzdGFydCA8IDEpIHtcbiAgICByZXR1cm4ge1xuICAgICAgaXNWYWxpZDogZmFsc2UsXG4gICAgICByZXF1aXJlZFBvbGVzOiBbXSxcbiAgICAgIGV4Y2VlZHNNYXg6IGZhbHNlLFxuICAgICAgbWF4UG9sZTogbnVsbCxcbiAgICAgIGNvbmZsaWN0czogW10sXG4gICAgICBjb25mbGljdE1lc3NhZ2VzOiBbJ0RlYmUgaW5kaWNhciB1biBwb2xvIGluaWNpYWwgdsOhbGlkbyBtYXlvciBvIGlndWFsIGEgMS4nXSxcbiAgICAgIG9jY3VwYW5jeU1hcDoge31cbiAgICB9O1xuICB9XG5cbiAgaWYgKGNvdW50IDwgMSB8fCBjb3VudCA+IDMpIHtcbiAgICByZXR1cm4ge1xuICAgICAgaXNWYWxpZDogZmFsc2UsXG4gICAgICByZXF1aXJlZFBvbGVzOiBbXSxcbiAgICAgIGV4Y2VlZHNNYXg6IGZhbHNlLFxuICAgICAgbWF4UG9sZTogbnVsbCxcbiAgICAgIGNvbmZsaWN0czogW10sXG4gICAgICBjb25mbGljdE1lc3NhZ2VzOiBbJ0VsIG7Dum1lcm8gZGUgcG9sb3MgZGViZSBzZXIgMSAoTW9ub2bDoXNpY28pLCAyIChCaWbDoXNpY28pIG8gMyAoVHJpZsOhc2ljbykuJ10sXG4gICAgICBvY2N1cGFuY3lNYXA6IHt9XG4gICAgfTtcbiAgfVxuXG4gIGNvbnN0IHJlcXVpcmVkUG9sZXMgPSBnZXRSZXF1aXJlZFBvbGVzKHN0YXJ0LCBjb3VudCk7XG4gIGNvbnN0IGhpZ2hlc3RQb2xlID0gTWF0aC5tYXgoLi4ucmVxdWlyZWRQb2xlcyk7XG4gIGNvbnN0IGV4Y2VlZHNNYXggPSBoaWdoZXN0UG9sZSA+IG1heDtcblxuICBjb25zdCBvY2N1cGFuY3lNYXAgPSBidWlsZFBvbGVzT2NjdXBhbmN5TWFwKGNpcmN1aXRzLCBleGNsdWRlQ2lyY3VpdElkKTtcbiAgY29uc3QgY29uZmxpY3RzID0gW107XG4gIGNvbnN0IGNvbmZsaWN0TWVzc2FnZXMgPSBbXTtcblxuICBpZiAoZXhjZWVkc01heCkge1xuICAgIGNvbmZsaWN0TWVzc2FnZXMucHVzaChcbiAgICAgIGBMb3MgcG9sb3MgcmVxdWVyaWRvcyBbJHtyZXF1aXJlZFBvbGVzLmpvaW4oJywgJyl9XSBzdXBlcmFuIGxhIGNhcGFjaWRhZCBtw6F4aW1hIGRlbCB0YWJsZXJvICgke21heH0gcG9sb3MpLiBFbCBwb2xvICR7aGlnaGVzdFBvbGV9IGVzdMOhIGZ1ZXJhIGRlIHJhbmdvLmBcbiAgICApO1xuICB9XG5cbiAgcmVxdWlyZWRQb2xlcy5mb3JFYWNoKChwb2xlKSA9PiB7XG4gICAgaWYgKG9jY3VwYW5jeU1hcFtwb2xlXSkge1xuICAgICAgY29uc3Qgb2NjID0gb2NjdXBhbmN5TWFwW3BvbGVdO1xuICAgICAgY29uZmxpY3RzLnB1c2goe1xuICAgICAgICBwb2xlLFxuICAgICAgICBvY2N1cGllZEJ5OiBvY2NcbiAgICAgIH0pO1xuICAgICAgY29uZmxpY3RNZXNzYWdlcy5wdXNoKFxuICAgICAgICBgRWwgcG9sbyAke3BvbGV9IHlhIGVzdMOhIG9jdXBhZG8gcG9yIFwiJHtvY2MuZGVzY3JpcGNpb259XCIgKEVzdGFkbzogJHtvY2MuZXN0YWRvfSR7b2NjLmFtcGVyYWplID8gYCwgJHtvY2MuYW1wZXJhamV9QWAgOiAnJ30pLmBcbiAgICAgICk7XG4gICAgfVxuICB9KTtcblxuICBjb25zdCBpc1ZhbGlkID0gIWV4Y2VlZHNNYXggJiYgY29uZmxpY3RzLmxlbmd0aCA9PT0gMDtcblxuICByZXR1cm4ge1xuICAgIGlzVmFsaWQsXG4gICAgcmVxdWlyZWRQb2xlcyxcbiAgICBleGNlZWRzTWF4LFxuICAgIG1heFBvbGU6IGhpZ2hlc3RQb2xlLFxuICAgIGNvbmZsaWN0cyxcbiAgICBjb25mbGljdE1lc3NhZ2VzLFxuICAgIG9jY3VwYW5jeU1hcFxuICB9O1xufTtcbiJdfQ==