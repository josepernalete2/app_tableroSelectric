import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SelectorAlimentadorJerarquico.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { API_BASE_URL } from "/src/utils/api.js";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { Search, ChevronDown, Zap, Building2, Cpu, Layers, Activity, Edit3, X, Check, AlertCircle, Radio } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SelectorAlimentadorJerarquico.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
/**
* Retorna el icono temático y colores según el tipo de elemento eléctrico
*/
const getIconAndColor = (tipo) => {
	switch (tipo) {
		case "SUBESTACION": return {
			icon: Building2,
			color: "text-rose-400 bg-rose-500/10 border-rose-500/30"
		};
		case "TRANSFORMADOR": return {
			icon: Zap,
			color: "text-amber-400 bg-amber-500/10 border-amber-500/30"
		};
		case "CCM": return {
			icon: Cpu,
			color: "text-purple-400 bg-purple-500/10 border-purple-500/30"
		};
		case "TABLERO": return {
			icon: Layers,
			color: "text-cyan-400 bg-cyan-500/10 border-cyan-500/30"
		};
		case "GENERADOR":
		case "TRANSFER": return {
			icon: Activity,
			color: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30"
		};
		case "BANCO_CONDENSADOR": return {
			icon: Zap,
			color: "text-amber-400 bg-amber-500/10 border-amber-500/30"
		};
		case "PUNTO_MEDICION": return {
			icon: Radio,
			color: "text-blue-400 bg-blue-500/10 border-blue-500/30"
		};
		default: return {
			icon: Zap,
			color: "text-slate-400 bg-slate-500/10 border-slate-500/30"
		};
	}
};
/**
* Componente Selector Dinámico e Inteligente de Alimentador / Nodo Padre Jerárquico
*/
export default function SelectorAlimentadorJerarquico({ value = "", onChange, proyectoId, tableroActualId, elementosList = null, placeholder = "Seleccionar equipo o acometida de alimentación...", disabled = false, label = "Alimentado Por (Procedencia / Jerarquía)", className = "", allowQuickCreate = false, onQuickCreate = null }) {
	_s();
	const [isOpen, setIsOpen] = useState(false);
	const [search, setSearch] = useState("");
	const [items, setItems] = useState([]);
	const [loading, setLoading] = useState(false);
	const [isCustomMode, setIsCustomMode] = useState(false);
	const [customText, setCustomText] = useState("");
	const containerRef = useRef(null);
	const searchInputRef = useRef(null);
	// Normalizar elementosList externos si se proporcionan
	const normalizedExternalList = useMemo(() => {
		if (!elementosList || !Array.isArray(elementosList)) return null;
		const resolverCategoria = (tipo) => {
			switch (tipo) {
				case "SUBESTACION": return "Subestaciones";
				case "TRANSFORMADOR": return "Transformadores";
				case "CCM": return "Celdas y CCM";
				case "TABLERO": return "Tableros Aguas Arriba";
				case "BANCO_CONDENSADOR": return "Bancos de Condensadores";
				case "GENERADOR":
				case "TRANSFER": return "Generación y Transferencias";
				case "PUNTO_MEDICION": return "Puntos de Medición / Acometidas";
				case "ALIMENTADOR": return "Alimentadores Dedicados";
				default: return "Otros Equipos";
			}
		};
		const resolverNivelTension = (el) => {
			const tech = typeof el.datosTecnicos === "string" ? JSON.parse(el.datosTecnicos || "{}") : el.datosTecnicos || {};
			if (el.tipoElemento === "TRANSFORMADOR") {
				return tech.voltajeSecundario || tech.tensionSecundaria || tech.voltajePrimario || (tech.kva ? `${tech.kva} kVA` : "N/D");
			}
			if (el.tipoElemento === "SUBESTACION") {
				return el.nivelTension ? `${el.nivelTension} kV` : tech.nivelTension || "Media/Alta Tensión";
			}
			if (el.tipoElemento === "TABLERO") {
				return tech.voltajeAcometida || tech.tension || (tech.voltaje?.va ? `${tech.voltaje.va}V` : "208/120 V");
			}
			if (el.tipoElemento === "CCM") {
				return tech.tension || "480/277 V";
			}
			if (el.tipoElemento === "BANCO_CONDENSADOR") {
				return tech.tensionNominal || (tech.potenciaReactivaTotal ? `${tech.potenciaReactivaTotal} kVAR` : "Compensación Reactiva");
			}
			if (el.tipoElemento === "PUNTO_MEDICION") {
				return tech.tensionNominal || tech.nivelTensionContrato || "Acometida Red";
			}
			return tech.tension || tech.voltaje || "N/D";
		};
		return elementosList.filter((el) => !tableroActualId || el.id !== tableroActualId && el.nombre !== tableroActualId).map((el) => ({
			id: el.id,
			nombre: el.nombre,
			tipoElemento: el.tipoElemento || "TABLERO",
			categoria: el.categoria || resolverCategoria(el.tipoElemento),
			nivelTension: el.nivelTension || resolverNivelTension(el),
			ubicacion: el.ubicacion || "Ubicación no especificada",
			detalles: el.detalles || (el.datosTecnicos?.kva ? `${el.datosTecnicos.kva} kVA` : null)
		}));
	}, [elementosList, tableroActualId]);
	// Cargar datos desde el backend o usar lista normalizada
	useEffect(() => {
		if (normalizedExternalList && normalizedExternalList.length > 0) {
			setItems(normalizedExternalList);
			return;
		}
		if (!proyectoId) return;
		let isMounted = true;
		const fetchFeeders = async () => {
			try {
				setLoading(true);
				const token = useStore.getState().token || localStorage.getItem("token") || "";
				const url = `${API_BASE_URL}/api/jerarquia/alimentadores/${proyectoId}${tableroActualId ? `?excluirId=${tableroActualId}` : ""}`;
				const res = await fetch(url, { headers: { "Authorization": `Bearer ${token}` } });
				const contentType = res.headers.get("content-type") || "";
				if (res.ok && contentType.includes("application/json")) {
					const data = await res.json();
					if (isMounted && data.ok) {
						setItems(data.data || []);
					}
				}
			} catch (err) {
				console.error("Error al cargar potenciales alimentadores:", err);
			} finally {
				if (isMounted) setLoading(false);
			}
		};
		fetchFeeders();
		return () => {
			isMounted = false;
		};
	}, [
		proyectoId,
		tableroActualId,
		normalizedExternalList
	]);
	// Sincronizar el valor inicial con el estado local
	useEffect(() => {
		if (!value) {
			setCustomText("");
			return;
		}
		const found = items.find((item) => item.nombre === value || item.id === value || `${item.nombre} (ID: ${item.id})` === value);
		if (!found && value && value.trim() !== "") {
			setIsCustomMode(true);
			setCustomText(value);
		} else if (found) {
			setIsCustomMode(false);
		}
	}, [value, items]);
	// Cerrar dropdown al hacer clic fuera
	useEffect(() => {
		const handleClickOutside = (e) => {
			if (containerRef.current && !containerRef.current.contains(e.target)) {
				setIsOpen(false);
			}
		};
		document.addEventListener("mousedown", handleClickOutside);
		return () => document.removeEventListener("mousedown", handleClickOutside);
	}, []);
	// Enfocar input de búsqueda al abrir
	useEffect(() => {
		if (isOpen && searchInputRef.current) {
			searchInputRef.current.focus();
		}
	}, [isOpen]);
	// Elemento seleccionado actual
	const selectedItem = useMemo(() => {
		if (!value) return null;
		return items.find((item) => item.nombre === value || item.id === value || `${item.nombre} (ID: ${item.id})` === value);
	}, [value, items]);
	// Filtrado reactivo en tiempo real
	const filteredItems = useMemo(() => {
		if (!search.trim()) return items;
		const term = search.toLowerCase();
		return items.filter((item) => item.nombre?.toLowerCase().includes(term) || item.tipoElemento?.toLowerCase().includes(term) || item.ubicacion?.toLowerCase().includes(term) || item.nivelTension?.toLowerCase().includes(term) || item.detalles?.toLowerCase().includes(term));
	}, [items, search]);
	// Agrupación visual por categoría
	const groupedItems = useMemo(() => {
		const groups = {};
		filteredItems.forEach((item) => {
			const cat = item.categoria || "Otros Equipos";
			if (!groups[cat]) groups[cat] = [];
			groups[cat].push(item);
		});
		return groups;
	}, [filteredItems]);
	const handleSelect = (item) => {
		setIsCustomMode(false);
		setCustomText("");
		setIsOpen(false);
		setSearch("");
		if (onChange) {
			onChange(item.nombre, item);
		}
	};
	const handleClear = (e) => {
		e.stopPropagation();
		setIsCustomMode(false);
		setCustomText("");
		if (onChange) {
			onChange("", null);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `w-full space-y-1.5 ${className}`,
		ref: containerRef,
		children: [
			label && /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-[11px] font-bold text-slate-400 uppercase tracking-wider",
					children: label
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 257,
					columnNumber: 11
				}, this), selectedItem && /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] text-amber-400 font-mono font-bold flex items-center gap-1",
					children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 15
					}, this), "Nodo Jerárquico Vinculado"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 261,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 256,
				columnNumber: 9
			}, this),
			isCustomMode ? /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "relative flex-1",
					children: [
						/* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							disabled,
							value: customText,
							onChange: (e) => {
								const val = e.target.value;
								setCustomText(val);
								if (onChange) {
									onChange(val, {
										id: "CUSTOM",
										nombre: val,
										tipoElemento: "OTRO",
										categoria: "Acometida Externa",
										nivelTension: "Personalizado",
										ubicacion: "Exterior / Directo"
									});
								}
							},
							placeholder: "Ej. Acometida Directa CORPOELEC, Generador Móvil, etc.",
							className: "w-full pl-9 pr-8 py-2.5 bg-slate-900 border border-amber-500/40 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition-all font-mono"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 273,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Edit3, { className: "w-4 h-4 text-amber-400 absolute left-3 top-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 294,
							columnNumber: 13
						}, this),
						customText && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => {
								setCustomText("");
								if (onChange) onChange("", null);
							},
							className: "absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-200 p-0.5 rounded-md cursor-pointer",
							title: "Borrar texto",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 305,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 296,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 272,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					disabled,
					onClick: () => {
						setIsCustomMode(false);
						setIsOpen(true);
					},
					className: "px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer",
					children: "Ver Catálogo"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 309,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 271,
				columnNumber: 9
			}, this) : 
			/* MODO SELECTOR DINÁMICO */
/* @__PURE__ */ _jsxDEV("div", {
				className: "relative",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					disabled,
					onClick: () => setIsOpen(!isOpen),
					className: `w-full min-h-[46px] px-3.5 py-2 rounded-xl text-left border flex items-center justify-between gap-3 transition-all duration-200 cursor-pointer ${isOpen ? "bg-slate-900 border-amber-500 ring-2 ring-amber-500/20 shadow-lg shadow-amber-500/5" : "bg-slate-900 hover:bg-slate-850 border-slate-800 hover:border-slate-750"} ${disabled ? "opacity-50 cursor-not-allowed" : ""}`,
					children: [selectedItem ? /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2.5 min-w-0 flex-1",
						children: [(() => {
							const { icon: ItemIcon, color } = getIconAndColor(selectedItem.tipoElemento);
							return /* @__PURE__ */ _jsxDEV("div", {
								className: `p-1.5 rounded-lg border shrink-0 ${color}`,
								children: /* @__PURE__ */ _jsxDEV(ItemIcon, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 340,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 339,
								columnNumber: 21
							}, this);
						})(), /* @__PURE__ */ _jsxDEV("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-semibold text-sm text-slate-100 truncate",
									children: selectedItem.nombre
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 346,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30 shrink-0",
									children: ["⚡ ", selectedItem.nivelTension]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 345,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs text-slate-400 mt-0.5",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "truncate",
									children: selectedItem.ubicacion
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 354,
									columnNumber: 21
								}, this), selectedItem.detalles && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-600",
									children: "•"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 357,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 truncate",
									children: selectedItem.detalles
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 358,
									columnNumber: 25
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 356,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 353,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 344,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("span", {
						className: "text-sm text-slate-500 truncate font-mono",
						children: value || placeholder
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 365,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1.5 shrink-0",
						children: [value && /* @__PURE__ */ _jsxDEV("span", {
							role: "button",
							tabIndex: 0,
							onClick: handleClear,
							className: "p-1 text-slate-400 hover:text-rose-400 rounded-md transition-colors",
							title: "Limpiar selección",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 379,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 372,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV(ChevronDown, { className: `w-4 h-4 text-slate-400 transition-transform duration-200 ${isOpen ? "rotate-180 text-amber-400" : ""}` }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 382,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 370,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 324,
					columnNumber: 11
				}, this), isOpen && /* @__PURE__ */ _jsxDEV("div", {
					className: "absolute z-50 left-0 right-0 mt-2 bg-slate-900 border border-slate-750 rounded-2xl shadow-2xl backdrop-blur-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 border-b border-slate-800 bg-slate-950/50",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "relative",
								children: [
									/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 396,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										ref: searchInputRef,
										type: "text",
										value: search,
										onChange: (e) => setSearch(e.target.value),
										placeholder: "Buscar por nombre, tipo, nivel de tensión o ubicación...",
										className: "w-full pl-9 pr-8 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 397,
										columnNumber: 19
									}, this),
									search && /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setSearch(""),
										className: "absolute right-2.5 top-2.5 text-slate-400 hover:text-white",
										children: /* @__PURE__ */ _jsxDEV(X, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 411,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 406,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 395,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 394,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "max-h-64 overflow-y-auto divide-y divide-slate-800/60 p-1.5 custom-scrollbar",
							children: loading ? /* @__PURE__ */ _jsxDEV("div", {
								className: "p-6 text-center text-xs text-slate-400 flex items-center justify-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-4 h-4 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 421,
									columnNumber: 21
								}, this), "Cargando jerarquía eléctrica del proyecto..."]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 420,
								columnNumber: 19
							}, this) : Object.keys(groupedItems).length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
								className: "p-6 text-center text-xs text-slate-400 space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-5 h-5 mx-auto text-slate-500 mb-1" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 426,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "font-semibold text-slate-300",
										children: "No se encontraron equipos registrados"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 427,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-500",
										children: "Puedes ingresar una acometida externa manual con la opción de abajo."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 428,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 425,
								columnNumber: 19
							}, this) : Object.entries(groupedItems).map(([categoria, group]) => /* @__PURE__ */ _jsxDEV("div", {
								className: "py-1.5 first:pt-0 last:pb-0",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: categoria }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 435,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 font-mono text-[9px] bg-slate-800 px-1.5 py-0.5 rounded-full",
										children: group.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-0.5 mt-1",
									children: group.map((item) => {
										const isSelected = selectedItem?.id === item.id || value === item.nombre;
										const { icon: ItemIcon, color } = getIconAndColor(item.tipoElemento);
										return /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => handleSelect(item),
											className: `w-full text-left px-2.5 py-2 rounded-xl flex items-center justify-between gap-3 transition-colors cursor-pointer ${isSelected ? "bg-amber-500/15 text-amber-300 border border-amber-500/30" : "hover:bg-slate-800/80 text-slate-200"}`,
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2.5 min-w-0 flex-1",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: `p-1.5 rounded-lg border shrink-0 ${color}`,
													children: /* @__PURE__ */ _jsxDEV(ItemIcon, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 460,
														columnNumber: 35
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 459,
													columnNumber: 33
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "min-w-0 flex-1",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "font-semibold text-xs text-slate-100 truncate",
															children: item.nombre
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 464,
															columnNumber: 37
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-slate-800 text-amber-300 shrink-0",
															children: ["⚡ ", item.nivelTension]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 467,
															columnNumber: 37
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 463,
														columnNumber: 35
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "text-[11px] text-slate-400 truncate mt-0.5",
														children: [
															"📍 ",
															item.ubicacion,
															item.detalles ? ` • ${item.detalles}` : ""
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 471,
														columnNumber: 35
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 462,
													columnNumber: 33
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 458,
												columnNumber: 31
											}, this), isSelected && /* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-amber-400 shrink-0" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 477,
												columnNumber: 46
											}, this)]
										}, item.id, true, {
											fileName: _jsxFileName,
											lineNumber: 448,
											columnNumber: 29
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 442,
									columnNumber: 23
								}, this)]
							}, categoria, true, {
								fileName: _jsxFileName,
								lineNumber: 432,
								columnNumber: 21
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 418,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-2 border-t border-slate-800 bg-slate-950/80 space-y-1.5",
							children: [(allowQuickCreate || onQuickCreate) && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setIsOpen(false);
									if (onQuickCreate) {
										onQuickCreate();
									}
								},
								className: "w-full px-3 py-2 rounded-xl text-left flex items-center gap-2 text-xs text-emerald-400 hover:text-emerald-300 bg-emerald-950/30 hover:bg-emerald-900/40 transition-colors font-bold border border-emerald-500/30 cursor-pointer shadow-sm",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "p-0.5 bg-emerald-500 text-slate-950 rounded font-black text-[10px] leading-none",
									children: "+"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 500,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Crear nueva fuente / nodo en línea" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 501,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 490,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setIsCustomMode(true);
									setIsOpen(false);
								},
								className: "w-full px-3 py-2 rounded-xl text-left flex items-center gap-2 text-xs text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 transition-colors font-medium border border-dashed border-amber-500/30 cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(Edit3, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 513,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Personalizado / Acometida Externa (Texto Manual)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 514,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 505,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 488,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 392,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 323,
				columnNumber: 9
			}, this),
			selectedItem && /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center flex-wrap gap-2 px-3 py-1.5 bg-slate-900/60 border border-slate-800 rounded-xl text-[11px] text-slate-300 animate-in fade-in",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-500 font-bold uppercase text-[9px] tracking-wide",
						children: "Origen:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 525,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "font-semibold text-slate-200",
						children: selectedItem.nombre
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 526,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-600",
						children: "•"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 527,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-amber-400 font-mono font-medium",
						children: ["⚡ ", selectedItem.nivelTension]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 528,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-600",
						children: "•"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 529,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-400 truncate",
						children: ["📍 ", selectedItem.ubicacion]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 530,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 524,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 254,
		columnNumber: 5
	}, this);
}
_s(SelectorAlimentadorJerarquico, "VtqrtH/yGX/GUz5I1v1ZZcnwz0E=");
_c = SelectorAlimentadorJerarquico;
var _c;
$RefreshReg$(_c, "SelectorAlimentadorJerarquico");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SelectorAlimentadorJerarquico.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SelectorAlimentadorJerarquico.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SelectorAlimentadorJerarquico.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SelectorAlimentadorJerarquico.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxRQUFRLGVBQWU7QUFDNUQsU0FBUyxvQkFBb0I7QUFDN0IsT0FBTyxjQUFjO0FBQ3JCLFNBQ0UsUUFDQSxhQUNBLEtBQ0EsV0FDQSxLQUNBLFFBQ0EsVUFDQSxPQUNBLEdBQ0EsT0FDQSxhQUNBLGFBQ0s7Ozs7Ozs7QUFLUCxNQUFNLG1CQUFtQixTQUFTO0NBQ2hDLFFBQVEsTUFBUjtFQUNFLEtBQUssZUFDSCxPQUFPO0dBQUUsTUFBTTtHQUFXLE9BQU87RUFBa0Q7RUFDckYsS0FBSyxpQkFDSCxPQUFPO0dBQUUsTUFBTTtHQUFLLE9BQU87RUFBcUQ7RUFDbEYsS0FBSyxPQUNILE9BQU87R0FBRSxNQUFNO0dBQUssT0FBTztFQUF3RDtFQUNyRixLQUFLLFdBQ0gsT0FBTztHQUFFLE1BQU07R0FBUSxPQUFPO0VBQWtEO0VBQ2xGLEtBQUs7RUFDTCxLQUFLLFlBQ0gsT0FBTztHQUFFLE1BQU07R0FBVSxPQUFPO0VBQTJEO0VBQzdGLEtBQUsscUJBQ0gsT0FBTztHQUFFLE1BQU07R0FBSyxPQUFPO0VBQXFEO0VBQ2xGLEtBQUssa0JBQ0gsT0FBTztHQUFFLE1BQU07R0FBTyxPQUFPO0VBQWtEO0VBQ2pGLFNBQ0UsT0FBTztHQUFFLE1BQU07R0FBSyxPQUFPO0VBQXFEO0NBQ3BGO0FBQ0Y7Ozs7QUFLQSxlQUFlLFNBQVMsOEJBQThCLEVBQ3BELFFBQVEsSUFDUixVQUNBLFlBQ0EsaUJBQ0EsZ0JBQWdCLE1BQ2hCLGNBQWMscURBQ2QsV0FBVyxPQUNYLFFBQVEsNENBQ1IsWUFBWSxJQUNaLG1CQUFtQixPQUNuQixnQkFBZ0IsUUFDZjs7Q0FDRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRTtDQUN2QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsQ0FBQyxDQUFDO0NBQ3JDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUUvQyxNQUFNLGVBQWUsT0FBTyxJQUFJO0NBQ2hDLE1BQU0saUJBQWlCLE9BQU8sSUFBSTs7Q0FHbEMsTUFBTSx5QkFBeUIsY0FBYztFQUMzQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxRQUFRLGFBQWEsR0FBRyxPQUFPO0VBRTVELE1BQU0scUJBQXFCLFNBQVM7R0FDbEMsUUFBUSxNQUFSO0lBQ0UsS0FBSyxlQUFlLE9BQU87SUFDM0IsS0FBSyxpQkFBaUIsT0FBTztJQUM3QixLQUFLLE9BQU8sT0FBTztJQUNuQixLQUFLLFdBQVcsT0FBTztJQUN2QixLQUFLLHFCQUFxQixPQUFPO0lBQ2pDLEtBQUs7SUFDTCxLQUFLLFlBQVksT0FBTztJQUN4QixLQUFLLGtCQUFrQixPQUFPO0lBQzlCLEtBQUssZUFBZSxPQUFPO0lBQzNCLFNBQVMsT0FBTztHQUNsQjtFQUNGO0VBRUEsTUFBTSx3QkFBd0IsT0FBTztHQUNuQyxNQUFNLE9BQU8sT0FBTyxHQUFHLGtCQUFrQixXQUNyQyxLQUFLLE1BQU0sR0FBRyxpQkFBaUIsSUFBSSxJQUNsQyxHQUFHLGlCQUFpQixDQUFDO0dBRTFCLElBQUksR0FBRyxpQkFBaUIsaUJBQWlCO0lBQ3ZDLE9BQU8sS0FBSyxxQkFBcUIsS0FBSyxxQkFBcUIsS0FBSyxvQkFBb0IsS0FBSyxNQUFNLEdBQUcsS0FBSyxJQUFJLFFBQVE7R0FDckg7R0FDQSxJQUFJLEdBQUcsaUJBQWlCLGVBQWU7SUFDckMsT0FBTyxHQUFHLGVBQWUsR0FBRyxHQUFHLGFBQWEsT0FBUSxLQUFLLGdCQUFnQjtHQUMzRTtHQUNBLElBQUksR0FBRyxpQkFBaUIsV0FBVztJQUNqQyxPQUFPLEtBQUssb0JBQW9CLEtBQUssWUFBWSxLQUFLLFNBQVMsS0FBSyxHQUFHLEtBQUssUUFBUSxHQUFHLEtBQUs7R0FDOUY7R0FDQSxJQUFJLEdBQUcsaUJBQWlCLE9BQU87SUFDN0IsT0FBTyxLQUFLLFdBQVc7R0FDekI7R0FDQSxJQUFJLEdBQUcsaUJBQWlCLHFCQUFxQjtJQUMzQyxPQUFPLEtBQUssbUJBQW1CLEtBQUssd0JBQXdCLEdBQUcsS0FBSyxzQkFBc0IsU0FBUztHQUNyRztHQUNBLElBQUksR0FBRyxpQkFBaUIsa0JBQWtCO0lBQ3hDLE9BQU8sS0FBSyxrQkFBa0IsS0FBSyx3QkFBd0I7R0FDN0Q7R0FDQSxPQUFPLEtBQUssV0FBVyxLQUFLLFdBQVc7RUFDekM7RUFFQSxPQUFPLGNBQ0osUUFBUSxPQUFPLENBQUMsbUJBQW9CLEdBQUcsT0FBTyxtQkFBbUIsR0FBRyxXQUFXLGVBQWdCLENBQUMsQ0FDaEcsS0FBSyxRQUFRO0dBQ1osSUFBSSxHQUFHO0dBQ1AsUUFBUSxHQUFHO0dBQ1gsY0FBYyxHQUFHLGdCQUFnQjtHQUNqQyxXQUFXLEdBQUcsYUFBYSxrQkFBa0IsR0FBRyxZQUFZO0dBQzVELGNBQWMsR0FBRyxnQkFBZ0IscUJBQXFCLEVBQUU7R0FDeEQsV0FBVyxHQUFHLGFBQWE7R0FDM0IsVUFBVSxHQUFHLGFBQWEsR0FBRyxlQUFlLE1BQU0sR0FBRyxHQUFHLGNBQWMsSUFBSSxRQUFRO0VBQ3BGLEVBQUU7Q0FDTixHQUFHLENBQUMsZUFBZSxlQUFlLENBQUM7O0NBR25DLGdCQUFnQjtFQUNkLElBQUksMEJBQTBCLHVCQUF1QixTQUFTLEdBQUc7R0FDL0QsU0FBUyxzQkFBc0I7R0FDL0I7RUFDRjtFQUVBLElBQUksQ0FBQyxZQUFZO0VBRWpCLElBQUksWUFBWTtFQUNoQixNQUFNLGVBQWUsWUFBWTtHQUMvQixJQUFJO0lBQ0YsV0FBVyxJQUFJO0lBQ2YsTUFBTSxRQUFRLFNBQVMsU0FBUyxDQUFDLENBQUMsU0FBUyxhQUFhLFFBQVEsT0FBTyxLQUFLO0lBQzVFLE1BQU0sTUFBTSxHQUFHLGFBQWEsK0JBQStCLGFBQWEsa0JBQWtCLGNBQWMsb0JBQW9CO0lBQzVILE1BQU0sTUFBTSxNQUFNLE1BQU0sS0FBSyxFQUMzQixTQUFTLEVBQ1AsaUJBQWlCLFVBQVUsUUFDN0IsRUFDRixDQUFDO0lBQ0QsTUFBTSxjQUFjLElBQUksUUFBUSxJQUFJLGNBQWMsS0FBSztJQUN2RCxJQUFJLElBQUksTUFBTSxZQUFZLFNBQVMsa0JBQWtCLEdBQUc7S0FDdEQsTUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0tBQzVCLElBQUksYUFBYSxLQUFLLElBQUk7TUFDeEIsU0FBUyxLQUFLLFFBQVEsQ0FBQyxDQUFDO0tBQzFCO0lBQ0Y7R0FDRixTQUFTLEtBQUs7SUFDWixRQUFRLE1BQU0sOENBQThDLEdBQUc7R0FDakUsVUFBVTtJQUNSLElBQUksV0FBVyxXQUFXLEtBQUs7R0FDakM7RUFDRjtFQUVBLGFBQWE7RUFDYixhQUFhO0dBQUUsWUFBWTtFQUFPO0NBQ3BDLEdBQUc7RUFBQztFQUFZO0VBQWlCO0NBQXNCLENBQUM7O0NBR3hELGdCQUFnQjtFQUNkLElBQUksQ0FBQyxPQUFPO0dBQ1YsY0FBYyxFQUFFO0dBQ2hCO0VBQ0Y7RUFDQSxNQUFNLFFBQVEsTUFBTSxNQUNqQixTQUFTLEtBQUssV0FBVyxTQUFTLEtBQUssT0FBTyxTQUFTLEdBQUcsS0FBSyxPQUFPLFFBQVEsS0FBSyxHQUFHLE9BQU8sS0FDaEc7RUFDQSxJQUFJLENBQUMsU0FBUyxTQUFTLE1BQU0sS0FBSyxNQUFNLElBQUk7R0FDMUMsZ0JBQWdCLElBQUk7R0FDcEIsY0FBYyxLQUFLO0VBQ3JCLE9BQU8sSUFBSSxPQUFPO0dBQ2hCLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0YsR0FBRyxDQUFDLE9BQU8sS0FBSyxDQUFDOztDQUdqQixnQkFBZ0I7RUFDZCxNQUFNLHNCQUFzQixNQUFNO0dBQ2hDLElBQUksYUFBYSxXQUFXLENBQUMsYUFBYSxRQUFRLFNBQVMsRUFBRSxNQUFNLEdBQUc7SUFDcEUsVUFBVSxLQUFLO0dBQ2pCO0VBQ0Y7RUFDQSxTQUFTLGlCQUFpQixhQUFhLGtCQUFrQjtFQUN6RCxhQUFhLFNBQVMsb0JBQW9CLGFBQWEsa0JBQWtCO0NBQzNFLEdBQUcsQ0FBQyxDQUFDOztDQUdMLGdCQUFnQjtFQUNkLElBQUksVUFBVSxlQUFlLFNBQVM7R0FDcEMsZUFBZSxRQUFRLE1BQU07RUFDL0I7Q0FDRixHQUFHLENBQUMsTUFBTSxDQUFDOztDQUdYLE1BQU0sZUFBZSxjQUFjO0VBQ2pDLElBQUksQ0FBQyxPQUFPLE9BQU87RUFDbkIsT0FBTyxNQUFNLE1BQ1YsU0FBUyxLQUFLLFdBQVcsU0FBUyxLQUFLLE9BQU8sU0FBUyxHQUFHLEtBQUssT0FBTyxRQUFRLEtBQUssR0FBRyxPQUFPLEtBQ2hHO0NBQ0YsR0FBRyxDQUFDLE9BQU8sS0FBSyxDQUFDOztDQUdqQixNQUFNLGdCQUFnQixjQUFjO0VBQ2xDLElBQUksQ0FBQyxPQUFPLEtBQUssR0FBRyxPQUFPO0VBQzNCLE1BQU0sT0FBTyxPQUFPLFlBQVk7RUFDaEMsT0FBTyxNQUFNLFFBQ1YsU0FDQyxLQUFLLFFBQVEsWUFBWSxDQUFDLENBQUMsU0FBUyxJQUFJLEtBQ3hDLEtBQUssY0FBYyxZQUFZLENBQUMsQ0FBQyxTQUFTLElBQUksS0FDOUMsS0FBSyxXQUFXLFlBQVksQ0FBQyxDQUFDLFNBQVMsSUFBSSxLQUMzQyxLQUFLLGNBQWMsWUFBWSxDQUFDLENBQUMsU0FBUyxJQUFJLEtBQzlDLEtBQUssVUFBVSxZQUFZLENBQUMsQ0FBQyxTQUFTLElBQUksQ0FDOUM7Q0FDRixHQUFHLENBQUMsT0FBTyxNQUFNLENBQUM7O0NBR2xCLE1BQU0sZUFBZSxjQUFjO0VBQ2pDLE1BQU0sU0FBUyxDQUFDO0VBQ2hCLGNBQWMsU0FBUyxTQUFTO0dBQzlCLE1BQU0sTUFBTSxLQUFLLGFBQWE7R0FDOUIsSUFBSSxDQUFDLE9BQU8sTUFBTSxPQUFPLE9BQU8sQ0FBQztHQUNqQyxPQUFPLElBQUksQ0FBQyxLQUFLLElBQUk7RUFDdkIsQ0FBQztFQUNELE9BQU87Q0FDVCxHQUFHLENBQUMsYUFBYSxDQUFDO0NBRWxCLE1BQU0sZ0JBQWdCLFNBQVM7RUFDN0IsZ0JBQWdCLEtBQUs7RUFDckIsY0FBYyxFQUFFO0VBQ2hCLFVBQVUsS0FBSztFQUNmLFVBQVUsRUFBRTtFQUNaLElBQUksVUFBVTtHQUNaLFNBQVMsS0FBSyxRQUFRLElBQUk7RUFDNUI7Q0FDRjtDQUVBLE1BQU0sZUFBZSxNQUFNO0VBQ3pCLEVBQUUsZ0JBQWdCO0VBQ2xCLGdCQUFnQixLQUFLO0VBQ3JCLGNBQWMsRUFBRTtFQUNoQixJQUFJLFVBQVU7R0FDWixTQUFTLElBQUksSUFBSTtFQUNuQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVyxzQkFBc0I7RUFBYSxLQUFLO1lBQXhEO0dBQ0csU0FDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFDZDtJQUNJOzs7O2NBQ04sZ0JBQ0Msd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxzREFBdUQ7Ozs7ZUFBQywyQkFFcEU7Ozs7O1lBRUw7Ozs7OztHQUlOLGVBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNLO09BQ1YsT0FBTztPQUNQLFdBQVcsTUFBTTtRQUNmLE1BQU0sTUFBTSxFQUFFLE9BQU87UUFDckIsY0FBYyxHQUFHO1FBQ2pCLElBQUksVUFBVTtTQUNaLFNBQVMsS0FBSztVQUNaLElBQUk7VUFDSixRQUFRO1VBQ1IsY0FBYztVQUNkLFdBQVc7VUFDWCxjQUFjO1VBQ2QsV0FBVztTQUNiLENBQUM7UUFDSDtPQUNGO09BQ0EsYUFBWTtPQUNaLFdBQVU7TUFDWDs7Ozs7TUFDRCx3QkFBQyxPQUFELEVBQU8sV0FBVSwrQ0FBZ0Q7Ozs7O01BQ2hFLGNBQ0Msd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxlQUFlO1FBQ2IsY0FBYyxFQUFFO1FBQ2hCLElBQUksVUFBVSxTQUFTLElBQUksSUFBSTtPQUNqQztPQUNBLFdBQVU7T0FDVixPQUFNO2lCQUVOLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O01BQ2xCOzs7OztLQUVQOzs7OztjQUNMLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0s7S0FDVixlQUFlO01BQ2IsZ0JBQWdCLEtBQUs7TUFDckIsVUFBVSxJQUFJO0tBQ2hCO0tBQ0EsV0FBVTtlQUNYO0lBRU87Ozs7WUFDTDs7Ozs7OztBQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNLO0tBQ1YsZUFBZSxVQUFVLENBQUMsTUFBTTtLQUNoQyxXQUFXLGtKQUNULFNBQ0ksd0ZBQ0EsMEVBQ0wsR0FBRyxXQUFXLGtDQUFrQztlQVJuRCxDQVVHLGVBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsUUFDVTtPQUNOLE1BQU0sRUFBRSxNQUFNLFVBQVUsVUFBVSxnQkFBZ0IsYUFBYSxZQUFZO09BQzNFLE9BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVcsb0NBQW9DO2tCQUNsRCx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7OztPQUM1Qjs7Ozs7TUFFVCxFQUFDLENBQUUsR0FDSCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsYUFBYTtRQUNWOzs7O2tCQUNOLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUEySSxNQUN0SSxhQUFhLFlBQ1o7Ozs7O2dCQUNIOzs7OztpQkFDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFZLGFBQWE7UUFBZ0I7Ozs7a0JBQ3hELGFBQWEsWUFDWixnREFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUI7UUFBTzs7OztrQkFDeEMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTJCLGFBQWE7UUFBZTs7OztnQkFDdkU7Ozs7Z0JBRUQ7Ozs7O2VBQ0Y7Ozs7O2NBQ0Y7Ozs7O2dCQUVMLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNiLFNBQVM7S0FDTjs7OztlQUdSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0csU0FDQyx3QkFBQyxRQUFEO09BQ0UsTUFBSztPQUNMLFVBQVU7T0FDVixTQUFTO09BQ1QsV0FBVTtPQUNWLE9BQU07aUJBRU4sd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7TUFDcEI7Ozs7Z0JBRVIsd0JBQUMsYUFBRCxFQUNFLFdBQVcsNERBQ1QsU0FBUyw4QkFBOEIsS0FFMUM7Ozs7Y0FDRTs7Ozs7YUFDQzs7Ozs7Y0FHUCxVQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGlEQUFrRDs7Ozs7U0FDcEUsd0JBQUMsU0FBRDtVQUNFLEtBQUs7VUFDTCxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSxVQUFVLEVBQUUsT0FBTyxLQUFLO1VBQ3pDLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7O1NBQ0EsVUFDQyx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLGVBQWUsVUFBVSxFQUFFO1VBQzNCLFdBQVU7b0JBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsY0FBZTs7Ozs7U0FDdEI7Ozs7O1FBRVA7Ozs7OztNQUNGOzs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLFVBQ0Msd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQUssV0FBVSxtRkFBb0Y7Ozs7a0JBQUMsOENBRWpHOzs7OztrQkFDSCxPQUFPLEtBQUssWUFBWSxDQUFDLENBQUMsV0FBVyxJQUN2Qyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHNDQUF1Qzs7Ozs7U0FDOUQsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQStCO1NBQXdDOzs7OztTQUNwRix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBNkI7U0FBdUU7Ozs7O1FBQzlHOzs7OztrQkFFTCxPQUFPLFFBQVEsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsV0FDNUMsd0JBQUMsT0FBRDtRQUFxQixXQUFVO2tCQUEvQixDQUVFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFPLFVBQWdCOzs7O21CQUN2Qix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixNQUFNO1NBQ0g7Ozs7aUJBQ0g7Ozs7O2tCQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLE1BQU0sS0FBSyxTQUFTO1VBQ25CLE1BQU0sYUFBYSxjQUFjLE9BQU8sS0FBSyxNQUFNLFVBQVUsS0FBSztVQUNsRSxNQUFNLEVBQUUsTUFBTSxVQUFVLFVBQVUsZ0JBQWdCLEtBQUssWUFBWTtVQUVuRSxPQUNFLHdCQUFDLFVBQUQ7V0FFRSxNQUFLO1dBQ0wsZUFBZSxhQUFhLElBQUk7V0FDaEMsV0FBVyxvSEFDVCxhQUNJLDhEQUNBO3FCQVBSLENBVUUsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxPQUFEO2FBQUssV0FBVyxvQ0FBb0M7dUJBQ2xELHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7O1lBQ2hDOzs7O3NCQUNMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDRSx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFDYixLQUFLO2NBQ0Y7Ozs7d0JBQ04sd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQWhCLENBQTRHLE1BQ3ZHLEtBQUssWUFDSjs7Ozs7c0JBQ0g7Ozs7O3VCQUNMLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmO2VBQTREO2VBQ3RELEtBQUs7ZUFDUixLQUFLLFdBQVcsTUFBTSxLQUFLLGFBQWE7Y0FDdEM7Ozs7O3FCQUNGOzs7OztvQkFDRjs7Ozs7cUJBQ0osY0FBYyx3QkFBQyxPQUFELEVBQU8sV0FBVSxrQ0FBbUM7Ozs7bUJBQzdEO2FBN0JELEtBQUs7Ozs7aUJBNkJKO1NBRVosQ0FBQztRQUNFOzs7O2dCQUNGO1VBbERLOzs7O2NBa0RMLENBQ047TUFFQTs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixFQUNJLG9CQUFvQixrQkFDcEIsd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlO1NBQ2IsVUFBVSxLQUFLO1NBQ2YsSUFBSSxlQUFlO1VBQ2pCLGNBQWM7U0FDaEI7UUFDRjtRQUNBLFdBQVU7a0JBUlosQ0FVRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBa0Y7UUFBTzs7OztrQkFDekcsd0JBQUMsUUFBRCxZQUFNLHFDQUF3Qzs7OztnQkFDeEM7Ozs7O2lCQUdWLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZTtTQUNiLGdCQUFnQixJQUFJO1NBQ3BCLFVBQVUsS0FBSztRQUNqQjtRQUNBLFdBQVU7a0JBTlosQ0FRRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7O2tCQUNoQyx3QkFBQyxRQUFELFlBQU0sbURBQXNEOzs7O2dCQUN0RDs7Ozs7ZUFDTDs7Ozs7O0tBQ0Y7Ozs7O1lBRUo7Ozs7OztHQUlOLGdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBOEQ7S0FBYTs7Ozs7S0FDM0Ysd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWdDLGFBQWE7S0FBYTs7Ozs7S0FDMUUsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWlCO0tBQU87Ozs7O0tBQ3hDLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUF1RCxNQUFHLGFBQWEsWUFBbUI7Ozs7OztLQUMxRix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaUI7S0FBTzs7Ozs7S0FDeEMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQTBDLE9BQUksYUFBYSxTQUFnQjs7Ozs7O0lBQ3hFOzs7Ozs7RUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2VsZWN0b3JBbGltZW50YWRvckplcmFycXVpY28uanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBBUElfQkFTRV9VUkwgfSBmcm9tICcuLi91dGlscy9hcGknO1xuaW1wb3J0IHVzZVN0b3JlIGZyb20gJy4uL3N0b3JlL3VzZVN0b3JlJztcbmltcG9ydCB7XG4gIFNlYXJjaCxcbiAgQ2hldnJvbkRvd24sXG4gIFphcCxcbiAgQnVpbGRpbmcyLFxuICBDcHUsXG4gIExheWVycyxcbiAgQWN0aXZpdHksXG4gIEVkaXQzLFxuICBYLFxuICBDaGVjayxcbiAgQWxlcnRDaXJjbGUsXG4gIFJhZGlvXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbi8qKlxuICogUmV0b3JuYSBlbCBpY29ubyB0ZW3DoXRpY28geSBjb2xvcmVzIHNlZ8O6biBlbCB0aXBvIGRlIGVsZW1lbnRvIGVsw6ljdHJpY29cbiAqL1xuY29uc3QgZ2V0SWNvbkFuZENvbG9yID0gKHRpcG8pID0+IHtcbiAgc3dpdGNoICh0aXBvKSB7XG4gICAgY2FzZSAnU1VCRVNUQUNJT04nOlxuICAgICAgcmV0dXJuIHsgaWNvbjogQnVpbGRpbmcyLCBjb2xvcjogJ3RleHQtcm9zZS00MDAgYmctcm9zZS01MDAvMTAgYm9yZGVyLXJvc2UtNTAwLzMwJyB9O1xuICAgIGNhc2UgJ1RSQU5TRk9STUFET1InOlxuICAgICAgcmV0dXJuIHsgaWNvbjogWmFwLCBjb2xvcjogJ3RleHQtYW1iZXItNDAwIGJnLWFtYmVyLTUwMC8xMCBib3JkZXItYW1iZXItNTAwLzMwJyB9O1xuICAgIGNhc2UgJ0NDTSc6XG4gICAgICByZXR1cm4geyBpY29uOiBDcHUsIGNvbG9yOiAndGV4dC1wdXJwbGUtNDAwIGJnLXB1cnBsZS01MDAvMTAgYm9yZGVyLXB1cnBsZS01MDAvMzAnIH07XG4gICAgY2FzZSAnVEFCTEVSTyc6XG4gICAgICByZXR1cm4geyBpY29uOiBMYXllcnMsIGNvbG9yOiAndGV4dC1jeWFuLTQwMCBiZy1jeWFuLTUwMC8xMCBib3JkZXItY3lhbi01MDAvMzAnIH07XG4gICAgY2FzZSAnR0VORVJBRE9SJzpcbiAgICBjYXNlICdUUkFOU0ZFUic6XG4gICAgICByZXR1cm4geyBpY29uOiBBY3Rpdml0eSwgY29sb3I6ICd0ZXh0LWVtZXJhbGQtNDAwIGJnLWVtZXJhbGQtNTAwLzEwIGJvcmRlci1lbWVyYWxkLTUwMC8zMCcgfTtcbiAgICBjYXNlICdCQU5DT19DT05ERU5TQURPUic6XG4gICAgICByZXR1cm4geyBpY29uOiBaYXAsIGNvbG9yOiAndGV4dC1hbWJlci00MDAgYmctYW1iZXItNTAwLzEwIGJvcmRlci1hbWJlci01MDAvMzAnIH07XG4gICAgY2FzZSAnUFVOVE9fTUVESUNJT04nOlxuICAgICAgcmV0dXJuIHsgaWNvbjogUmFkaW8sIGNvbG9yOiAndGV4dC1ibHVlLTQwMCBiZy1ibHVlLTUwMC8xMCBib3JkZXItYmx1ZS01MDAvMzAnIH07XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB7IGljb246IFphcCwgY29sb3I6ICd0ZXh0LXNsYXRlLTQwMCBiZy1zbGF0ZS01MDAvMTAgYm9yZGVyLXNsYXRlLTUwMC8zMCcgfTtcbiAgfVxufTtcblxuLyoqXG4gKiBDb21wb25lbnRlIFNlbGVjdG9yIERpbsOhbWljbyBlIEludGVsaWdlbnRlIGRlIEFsaW1lbnRhZG9yIC8gTm9kbyBQYWRyZSBKZXLDoXJxdWljb1xuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZWxlY3RvckFsaW1lbnRhZG9ySmVyYXJxdWljbyh7XG4gIHZhbHVlID0gJycsXG4gIG9uQ2hhbmdlLFxuICBwcm95ZWN0b0lkLFxuICB0YWJsZXJvQWN0dWFsSWQsXG4gIGVsZW1lbnRvc0xpc3QgPSBudWxsLFxuICBwbGFjZWhvbGRlciA9ICdTZWxlY2Npb25hciBlcXVpcG8gbyBhY29tZXRpZGEgZGUgYWxpbWVudGFjacOzbi4uLicsXG4gIGRpc2FibGVkID0gZmFsc2UsXG4gIGxhYmVsID0gJ0FsaW1lbnRhZG8gUG9yIChQcm9jZWRlbmNpYSAvIEplcmFycXXDrWEpJyxcbiAgY2xhc3NOYW1lID0gJycsXG4gIGFsbG93UXVpY2tDcmVhdGUgPSBmYWxzZSxcbiAgb25RdWlja0NyZWF0ZSA9IG51bGxcbn0pIHtcbiAgY29uc3QgW2lzT3Blbiwgc2V0SXNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NlYXJjaCwgc2V0U2VhcmNoXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2l0ZW1zLCBzZXRJdGVtc10gPSB1c2VTdGF0ZShbXSk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzQ3VzdG9tTW9kZSwgc2V0SXNDdXN0b21Nb2RlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2N1c3RvbVRleHQsIHNldEN1c3RvbVRleHRdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IGNvbnRhaW5lclJlZiA9IHVzZVJlZihudWxsKTtcbiAgY29uc3Qgc2VhcmNoSW5wdXRSZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgLy8gTm9ybWFsaXphciBlbGVtZW50b3NMaXN0IGV4dGVybm9zIHNpIHNlIHByb3BvcmNpb25hblxuICBjb25zdCBub3JtYWxpemVkRXh0ZXJuYWxMaXN0ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKCFlbGVtZW50b3NMaXN0IHx8ICFBcnJheS5pc0FycmF5KGVsZW1lbnRvc0xpc3QpKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHJlc29sdmVyQ2F0ZWdvcmlhID0gKHRpcG8pID0+IHtcbiAgICAgIHN3aXRjaCAodGlwbykge1xuICAgICAgICBjYXNlICdTVUJFU1RBQ0lPTic6IHJldHVybiAnU3ViZXN0YWNpb25lcyc7XG4gICAgICAgIGNhc2UgJ1RSQU5TRk9STUFET1InOiByZXR1cm4gJ1RyYW5zZm9ybWFkb3Jlcyc7XG4gICAgICAgIGNhc2UgJ0NDTSc6IHJldHVybiAnQ2VsZGFzIHkgQ0NNJztcbiAgICAgICAgY2FzZSAnVEFCTEVSTyc6IHJldHVybiAnVGFibGVyb3MgQWd1YXMgQXJyaWJhJztcbiAgICAgICAgY2FzZSAnQkFOQ09fQ09OREVOU0FET1InOiByZXR1cm4gJ0JhbmNvcyBkZSBDb25kZW5zYWRvcmVzJztcbiAgICAgICAgY2FzZSAnR0VORVJBRE9SJzpcbiAgICAgICAgY2FzZSAnVFJBTlNGRVInOiByZXR1cm4gJ0dlbmVyYWNpw7NuIHkgVHJhbnNmZXJlbmNpYXMnO1xuICAgICAgICBjYXNlICdQVU5UT19NRURJQ0lPTic6IHJldHVybiAnUHVudG9zIGRlIE1lZGljacOzbiAvIEFjb21ldGlkYXMnO1xuICAgICAgICBjYXNlICdBTElNRU5UQURPUic6IHJldHVybiAnQWxpbWVudGFkb3JlcyBEZWRpY2Fkb3MnO1xuICAgICAgICBkZWZhdWx0OiByZXR1cm4gJ090cm9zIEVxdWlwb3MnO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCByZXNvbHZlck5pdmVsVGVuc2lvbiA9IChlbCkgPT4ge1xuICAgICAgY29uc3QgdGVjaCA9IHR5cGVvZiBlbC5kYXRvc1RlY25pY29zID09PSAnc3RyaW5nJ1xuICAgICAgICA/IEpTT04ucGFyc2UoZWwuZGF0b3NUZWNuaWNvcyB8fCAne30nKVxuICAgICAgICA6IChlbC5kYXRvc1RlY25pY29zIHx8IHt9KTtcblxuICAgICAgaWYgKGVsLnRpcG9FbGVtZW50byA9PT0gJ1RSQU5TRk9STUFET1InKSB7XG4gICAgICAgIHJldHVybiB0ZWNoLnZvbHRhamVTZWN1bmRhcmlvIHx8IHRlY2gudGVuc2lvblNlY3VuZGFyaWEgfHwgdGVjaC52b2x0YWplUHJpbWFyaW8gfHwgKHRlY2gua3ZhID8gYCR7dGVjaC5rdmF9IGtWQWAgOiAnTi9EJyk7XG4gICAgICB9XG4gICAgICBpZiAoZWwudGlwb0VsZW1lbnRvID09PSAnU1VCRVNUQUNJT04nKSB7XG4gICAgICAgIHJldHVybiBlbC5uaXZlbFRlbnNpb24gPyBgJHtlbC5uaXZlbFRlbnNpb259IGtWYCA6ICh0ZWNoLm5pdmVsVGVuc2lvbiB8fCAnTWVkaWEvQWx0YSBUZW5zacOzbicpO1xuICAgICAgfVxuICAgICAgaWYgKGVsLnRpcG9FbGVtZW50byA9PT0gJ1RBQkxFUk8nKSB7XG4gICAgICAgIHJldHVybiB0ZWNoLnZvbHRhamVBY29tZXRpZGEgfHwgdGVjaC50ZW5zaW9uIHx8ICh0ZWNoLnZvbHRhamU/LnZhID8gYCR7dGVjaC52b2x0YWplLnZhfVZgIDogJzIwOC8xMjAgVicpO1xuICAgICAgfVxuICAgICAgaWYgKGVsLnRpcG9FbGVtZW50byA9PT0gJ0NDTScpIHtcbiAgICAgICAgcmV0dXJuIHRlY2gudGVuc2lvbiB8fCAnNDgwLzI3NyBWJztcbiAgICAgIH1cbiAgICAgIGlmIChlbC50aXBvRWxlbWVudG8gPT09ICdCQU5DT19DT05ERU5TQURPUicpIHtcbiAgICAgICAgcmV0dXJuIHRlY2gudGVuc2lvbk5vbWluYWwgfHwgKHRlY2gucG90ZW5jaWFSZWFjdGl2YVRvdGFsID8gYCR7dGVjaC5wb3RlbmNpYVJlYWN0aXZhVG90YWx9IGtWQVJgIDogJ0NvbXBlbnNhY2nDs24gUmVhY3RpdmEnKTtcbiAgICAgIH1cbiAgICAgIGlmIChlbC50aXBvRWxlbWVudG8gPT09ICdQVU5UT19NRURJQ0lPTicpIHtcbiAgICAgICAgcmV0dXJuIHRlY2gudGVuc2lvbk5vbWluYWwgfHwgdGVjaC5uaXZlbFRlbnNpb25Db250cmF0byB8fCAnQWNvbWV0aWRhIFJlZCc7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGVjaC50ZW5zaW9uIHx8IHRlY2gudm9sdGFqZSB8fCAnTi9EJztcbiAgICB9O1xuXG4gICAgcmV0dXJuIGVsZW1lbnRvc0xpc3RcbiAgICAgIC5maWx0ZXIoKGVsKSA9PiAhdGFibGVyb0FjdHVhbElkIHx8IChlbC5pZCAhPT0gdGFibGVyb0FjdHVhbElkICYmIGVsLm5vbWJyZSAhPT0gdGFibGVyb0FjdHVhbElkKSlcbiAgICAgIC5tYXAoKGVsKSA9PiAoe1xuICAgICAgICBpZDogZWwuaWQsXG4gICAgICAgIG5vbWJyZTogZWwubm9tYnJlLFxuICAgICAgICB0aXBvRWxlbWVudG86IGVsLnRpcG9FbGVtZW50byB8fCAnVEFCTEVSTycsXG4gICAgICAgIGNhdGVnb3JpYTogZWwuY2F0ZWdvcmlhIHx8IHJlc29sdmVyQ2F0ZWdvcmlhKGVsLnRpcG9FbGVtZW50byksXG4gICAgICAgIG5pdmVsVGVuc2lvbjogZWwubml2ZWxUZW5zaW9uIHx8IHJlc29sdmVyTml2ZWxUZW5zaW9uKGVsKSxcbiAgICAgICAgdWJpY2FjaW9uOiBlbC51YmljYWNpb24gfHwgJ1ViaWNhY2nDs24gbm8gZXNwZWNpZmljYWRhJyxcbiAgICAgICAgZGV0YWxsZXM6IGVsLmRldGFsbGVzIHx8IChlbC5kYXRvc1RlY25pY29zPy5rdmEgPyBgJHtlbC5kYXRvc1RlY25pY29zLmt2YX0ga1ZBYCA6IG51bGwpXG4gICAgICB9KSk7XG4gIH0sIFtlbGVtZW50b3NMaXN0LCB0YWJsZXJvQWN0dWFsSWRdKTtcblxuICAvLyBDYXJnYXIgZGF0b3MgZGVzZGUgZWwgYmFja2VuZCBvIHVzYXIgbGlzdGEgbm9ybWFsaXphZGFcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAobm9ybWFsaXplZEV4dGVybmFsTGlzdCAmJiBub3JtYWxpemVkRXh0ZXJuYWxMaXN0Lmxlbmd0aCA+IDApIHtcbiAgICAgIHNldEl0ZW1zKG5vcm1hbGl6ZWRFeHRlcm5hbExpc3QpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICghcHJveWVjdG9JZCkgcmV0dXJuO1xuXG4gICAgbGV0IGlzTW91bnRlZCA9IHRydWU7XG4gICAgY29uc3QgZmV0Y2hGZWVkZXJzID0gYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgY29uc3QgdG9rZW4gPSB1c2VTdG9yZS5nZXRTdGF0ZSgpLnRva2VuIHx8IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0b2tlbicpIHx8ICcnO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHtBUElfQkFTRV9VUkx9L2FwaS9qZXJhcnF1aWEvYWxpbWVudGFkb3Jlcy8ke3Byb3llY3RvSWR9JHt0YWJsZXJvQWN0dWFsSWQgPyBgP2V4Y2x1aXJJZD0ke3RhYmxlcm9BY3R1YWxJZH1gIDogJyd9YDtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiBgQmVhcmVyICR7dG9rZW59YFxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gcmVzLmhlYWRlcnMuZ2V0KCdjb250ZW50LXR5cGUnKSB8fCAnJztcbiAgICAgICAgaWYgKHJlcy5vayAmJiBjb250ZW50VHlwZS5pbmNsdWRlcygnYXBwbGljYXRpb24vanNvbicpKSB7XG4gICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XG4gICAgICAgICAgaWYgKGlzTW91bnRlZCAmJiBkYXRhLm9rKSB7XG4gICAgICAgICAgICBzZXRJdGVtcyhkYXRhLmRhdGEgfHwgW10pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGNhcmdhciBwb3RlbmNpYWxlcyBhbGltZW50YWRvcmVzOicsIGVycik7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBpZiAoaXNNb3VudGVkKSBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgZmV0Y2hGZWVkZXJzKCk7XG4gICAgcmV0dXJuICgpID0+IHsgaXNNb3VudGVkID0gZmFsc2U7IH07XG4gIH0sIFtwcm95ZWN0b0lkLCB0YWJsZXJvQWN0dWFsSWQsIG5vcm1hbGl6ZWRFeHRlcm5hbExpc3RdKTtcblxuICAvLyBTaW5jcm9uaXphciBlbCB2YWxvciBpbmljaWFsIGNvbiBlbCBlc3RhZG8gbG9jYWxcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXZhbHVlKSB7XG4gICAgICBzZXRDdXN0b21UZXh0KCcnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZm91bmQgPSBpdGVtcy5maW5kKFxuICAgICAgKGl0ZW0pID0+IGl0ZW0ubm9tYnJlID09PSB2YWx1ZSB8fCBpdGVtLmlkID09PSB2YWx1ZSB8fCBgJHtpdGVtLm5vbWJyZX0gKElEOiAke2l0ZW0uaWR9KWAgPT09IHZhbHVlXG4gICAgKTtcbiAgICBpZiAoIWZvdW5kICYmIHZhbHVlICYmIHZhbHVlLnRyaW0oKSAhPT0gJycpIHtcbiAgICAgIHNldElzQ3VzdG9tTW9kZSh0cnVlKTtcbiAgICAgIHNldEN1c3RvbVRleHQodmFsdWUpO1xuICAgIH0gZWxzZSBpZiAoZm91bmQpIHtcbiAgICAgIHNldElzQ3VzdG9tTW9kZShmYWxzZSk7XG4gICAgfVxuICB9LCBbdmFsdWUsIGl0ZW1zXSk7XG5cbiAgLy8gQ2VycmFyIGRyb3Bkb3duIGFsIGhhY2VyIGNsaWMgZnVlcmFcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBoYW5kbGVDbGlja091dHNpZGUgPSAoZSkgPT4ge1xuICAgICAgaWYgKGNvbnRhaW5lclJlZi5jdXJyZW50ICYmICFjb250YWluZXJSZWYuY3VycmVudC5jb250YWlucyhlLnRhcmdldCkpIHtcbiAgICAgICAgc2V0SXNPcGVuKGZhbHNlKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIGhhbmRsZUNsaWNrT3V0c2lkZSk7XG4gICAgcmV0dXJuICgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIGhhbmRsZUNsaWNrT3V0c2lkZSk7XG4gIH0sIFtdKTtcblxuICAvLyBFbmZvY2FyIGlucHV0IGRlIGLDunNxdWVkYSBhbCBhYnJpclxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc09wZW4gJiYgc2VhcmNoSW5wdXRSZWYuY3VycmVudCkge1xuICAgICAgc2VhcmNoSW5wdXRSZWYuY3VycmVudC5mb2N1cygpO1xuICAgIH1cbiAgfSwgW2lzT3Blbl0pO1xuXG4gIC8vIEVsZW1lbnRvIHNlbGVjY2lvbmFkbyBhY3R1YWxcbiAgY29uc3Qgc2VsZWN0ZWRJdGVtID0gdXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKCF2YWx1ZSkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIGl0ZW1zLmZpbmQoXG4gICAgICAoaXRlbSkgPT4gaXRlbS5ub21icmUgPT09IHZhbHVlIHx8IGl0ZW0uaWQgPT09IHZhbHVlIHx8IGAke2l0ZW0ubm9tYnJlfSAoSUQ6ICR7aXRlbS5pZH0pYCA9PT0gdmFsdWVcbiAgICApO1xuICB9LCBbdmFsdWUsIGl0ZW1zXSk7XG5cbiAgLy8gRmlsdHJhZG8gcmVhY3Rpdm8gZW4gdGllbXBvIHJlYWxcbiAgY29uc3QgZmlsdGVyZWRJdGVtcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmICghc2VhcmNoLnRyaW0oKSkgcmV0dXJuIGl0ZW1zO1xuICAgIGNvbnN0IHRlcm0gPSBzZWFyY2gudG9Mb3dlckNhc2UoKTtcbiAgICByZXR1cm4gaXRlbXMuZmlsdGVyKFxuICAgICAgKGl0ZW0pID0+XG4gICAgICAgIGl0ZW0ubm9tYnJlPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRlcm0pIHx8XG4gICAgICAgIGl0ZW0udGlwb0VsZW1lbnRvPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRlcm0pIHx8XG4gICAgICAgIGl0ZW0udWJpY2FjaW9uPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRlcm0pIHx8XG4gICAgICAgIGl0ZW0ubml2ZWxUZW5zaW9uPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRlcm0pIHx8XG4gICAgICAgIGl0ZW0uZGV0YWxsZXM/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModGVybSlcbiAgICApO1xuICB9LCBbaXRlbXMsIHNlYXJjaF0pO1xuXG4gIC8vIEFncnVwYWNpw7NuIHZpc3VhbCBwb3IgY2F0ZWdvcsOtYVxuICBjb25zdCBncm91cGVkSXRlbXMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBncm91cHMgPSB7fTtcbiAgICBmaWx0ZXJlZEl0ZW1zLmZvckVhY2goKGl0ZW0pID0+IHtcbiAgICAgIGNvbnN0IGNhdCA9IGl0ZW0uY2F0ZWdvcmlhIHx8ICdPdHJvcyBFcXVpcG9zJztcbiAgICAgIGlmICghZ3JvdXBzW2NhdF0pIGdyb3Vwc1tjYXRdID0gW107XG4gICAgICBncm91cHNbY2F0XS5wdXNoKGl0ZW0pO1xuICAgIH0pO1xuICAgIHJldHVybiBncm91cHM7XG4gIH0sIFtmaWx0ZXJlZEl0ZW1zXSk7XG5cbiAgY29uc3QgaGFuZGxlU2VsZWN0ID0gKGl0ZW0pID0+IHtcbiAgICBzZXRJc0N1c3RvbU1vZGUoZmFsc2UpO1xuICAgIHNldEN1c3RvbVRleHQoJycpO1xuICAgIHNldElzT3BlbihmYWxzZSk7XG4gICAgc2V0U2VhcmNoKCcnKTtcbiAgICBpZiAob25DaGFuZ2UpIHtcbiAgICAgIG9uQ2hhbmdlKGl0ZW0ubm9tYnJlLCBpdGVtKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xlYXIgPSAoZSkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgc2V0SXNDdXN0b21Nb2RlKGZhbHNlKTtcbiAgICBzZXRDdXN0b21UZXh0KCcnKTtcbiAgICBpZiAob25DaGFuZ2UpIHtcbiAgICAgIG9uQ2hhbmdlKCcnLCBudWxsKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YHctZnVsbCBzcGFjZS15LTEuNSAke2NsYXNzTmFtZX1gfSByZWY9e2NvbnRhaW5lclJlZn0+XG4gICAgICB7bGFiZWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICB7bGFiZWx9XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICB7c2VsZWN0ZWRJdGVtICYmIChcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNDAwIGZvbnQtbW9ubyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTQwMCBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICAgICAgTm9kbyBKZXLDoXJxdWljbyBWaW5jdWxhZG9cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNT0RPIFBFUlNPTkFMSVpBRE8gLyBBQ09NRVRJREEgRVhURVJOQSAqL31cbiAgICAgIHtpc0N1c3RvbU1vZGUgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXgtMVwiPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgICB2YWx1ZT17Y3VzdG9tVGV4dH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gZS50YXJnZXQudmFsdWU7XG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tVGV4dCh2YWwpO1xuICAgICAgICAgICAgICAgIGlmIChvbkNoYW5nZSkge1xuICAgICAgICAgICAgICAgICAgb25DaGFuZ2UodmFsLCB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAnQ1VTVE9NJyxcbiAgICAgICAgICAgICAgICAgICAgbm9tYnJlOiB2YWwsXG4gICAgICAgICAgICAgICAgICAgIHRpcG9FbGVtZW50bzogJ09UUk8nLFxuICAgICAgICAgICAgICAgICAgICBjYXRlZ29yaWE6ICdBY29tZXRpZGEgRXh0ZXJuYScsXG4gICAgICAgICAgICAgICAgICAgIG5pdmVsVGVuc2lvbjogJ1BlcnNvbmFsaXphZG8nLFxuICAgICAgICAgICAgICAgICAgICB1YmljYWNpb246ICdFeHRlcmlvciAvIERpcmVjdG8nXG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIEFjb21ldGlkYSBEaXJlY3RhIENPUlBPRUxFQywgR2VuZXJhZG9yIE3Ds3ZpbCwgZXRjLlwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC05IHByLTggcHktMi41IGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC80MCByb3VuZGVkLXhsIHRleHQtc20gdGV4dC1zbGF0ZS0xMDAgcGxhY2Vob2xkZXItc2xhdGUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hbWJlci01MDAvMzAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCB0cmFuc2l0aW9uLWFsbCBmb250LW1vbm9cIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxFZGl0MyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtM1wiIC8+XG4gICAgICAgICAgICB7Y3VzdG9tVGV4dCAmJiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRDdXN0b21UZXh0KCcnKTtcbiAgICAgICAgICAgICAgICAgIGlmIChvbkNoYW5nZSkgb25DaGFuZ2UoJycsIG51bGwpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMi41IHRvcC0yLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAgcC0wLjUgcm91bmRlZC1tZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJCb3JyYXIgdGV4dG9cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgc2V0SXNDdXN0b21Nb2RlKGZhbHNlKTtcbiAgICAgICAgICAgICAgc2V0SXNPcGVuKHRydWUpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMi41IGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgVmVyIENhdMOhbG9nb1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIC8qIE1PRE8gU0VMRUNUT1IgRElOw4FNSUNPICovXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzT3BlbighaXNPcGVuKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBtaW4taC1bNDZweF0gcHgtMy41IHB5LTIgcm91bmRlZC14bCB0ZXh0LWxlZnQgYm9yZGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgaXNPcGVuXG4gICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtOTAwIGJvcmRlci1hbWJlci01MDAgcmluZy0yIHJpbmctYW1iZXItNTAwLzIwIHNoYWRvdy1sZyBzaGFkb3ctYW1iZXItNTAwLzUnXG4gICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTg1MCBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1zbGF0ZS03NTAnXG4gICAgICAgICAgICB9ICR7ZGlzYWJsZWQgPyAnb3BhY2l0eS01MCBjdXJzb3Itbm90LWFsbG93ZWQnIDogJyd9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7c2VsZWN0ZWRJdGVtID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgbWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICB7KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHsgaWNvbjogSXRlbUljb24sIGNvbG9yIH0gPSBnZXRJY29uQW5kQ29sb3Ioc2VsZWN0ZWRJdGVtLnRpcG9FbGVtZW50byk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIHNocmluay0wICR7Y29sb3J9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgPEl0ZW1JY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSkoKX1cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTEwMCB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEl0ZW0ubm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTEuNSBweS0wLjUgcm91bmRlZCB0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1ib2xkIGJnLWFtYmVyLTUwMC8xNSB0ZXh0LWFtYmVyLTMwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIOKaoSB7c2VsZWN0ZWRJdGVtLm5pdmVsVGVuc2lvbn1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+e3NlbGVjdGVkSXRlbS51YmljYWNpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRJdGVtLmRldGFsbGVzICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDBcIj7igKI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0cnVuY2F0ZVwiPntzZWxlY3RlZEl0ZW0uZGV0YWxsZXN9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCB0cnVuY2F0ZSBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICB7dmFsdWUgfHwgcGxhY2Vob2xkZXJ9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICB7dmFsdWUgJiYgKFxuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICByb2xlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIHRhYkluZGV4PXswfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJ9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1yb3NlLTQwMCByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTGltcGlhciBzZWxlY2Npw7NuXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxDaGV2cm9uRG93blxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctNCBoLTQgdGV4dC1zbGF0ZS00MDAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwICR7XG4gICAgICAgICAgICAgICAgICBpc09wZW4gPyAncm90YXRlLTE4MCB0ZXh0LWFtYmVyLTQwMCcgOiAnJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICB7LyogTUVOw5ogREVTUExFR0FCTEUgQ09OIELDmlNRVUVEQSBZIENBVEVHT1LDjUFTICovfVxuICAgICAgICAgIHtpc09wZW4gJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB6LTUwIGxlZnQtMCByaWdodC0wIG10LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzUwIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgYmFja2Ryb3AtYmx1ci14bCBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMTUwXCI+XG4gICAgICAgICAgICAgIHsvKiBCYXJyYSBkZSBiw7pzcXVlZGEgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgYmctc2xhdGUtOTUwLzUwXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICByZWY9e3NlYXJjaElucHV0UmVmfVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2h9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgcG9yIG5vbWJyZSwgdGlwbywgbml2ZWwgZGUgdGVuc2nDs24gbyB1YmljYWNpw7NuLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItOCBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMC84MCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgcGxhY2Vob2xkZXItc2xhdGUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIHtzZWFyY2ggJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VhcmNoKCcnKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0yLjUgdG9wLTIuNSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogTGlzdGEgZGUgb3BjaW9uZXMgYWdydXBhZGFzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC1oLTY0IG92ZXJmbG93LXktYXV0byBkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwLzYwIHAtMS41IGN1c3RvbS1zY3JvbGxiYXJcIj5cbiAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTQgaC00IGJvcmRlci0yIGJvcmRlci1hbWJlci01MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICAgICAgICAgIENhcmdhbmRvIGplcmFycXXDrWEgZWzDqWN0cmljYSBkZWwgcHJveWVjdG8uLi5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkgOiBPYmplY3Qua2V5cyhncm91cGVkSXRlbXMpLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS00MDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTUgaC01IG14LWF1dG8gdGV4dC1zbGF0ZS01MDAgbWItMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj5ObyBzZSBlbmNvbnRyYXJvbiBlcXVpcG9zIHJlZ2lzdHJhZG9zPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPlB1ZWRlcyBpbmdyZXNhciB1bmEgYWNvbWV0aWRhIGV4dGVybmEgbWFudWFsIGNvbiBsYSBvcGNpw7NuIGRlIGFiYWpvLjwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICBPYmplY3QuZW50cmllcyhncm91cGVkSXRlbXMpLm1hcCgoW2NhdGVnb3JpYSwgZ3JvdXBdKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjYXRlZ29yaWF9IGNsYXNzTmFtZT1cInB5LTEuNSBmaXJzdDpwdC0wIGxhc3Q6cGItMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBDYWJlY2VyYSBkZSBDYXRlZ29yw61hICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgdGV4dC1bMTBweF0gZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Y2F0ZWdvcmlhfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGZvbnQtbW9ubyB0ZXh0LVs5cHhdIGJnLXNsYXRlLTgwMCBweC0xLjUgcHktMC41IHJvdW5kZWQtZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAubGVuZ3RofVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEl0ZW1zIGRlbCBHcnVwbyAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMC41IG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHNlbGVjdGVkSXRlbT8uaWQgPT09IGl0ZW0uaWQgfHwgdmFsdWUgPT09IGl0ZW0ubm9tYnJlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB7IGljb246IEl0ZW1JY29uLCBjb2xvciB9ID0gZ2V0SWNvbkFuZENvbG9yKGl0ZW0udGlwb0VsZW1lbnRvKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VsZWN0KGl0ZW0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHRleHQtbGVmdCBweC0yLjUgcHktMiByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwLzE1IHRleHQtYW1iZXItMzAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2hvdmVyOmJnLXNsYXRlLTgwMC84MCB0ZXh0LXNsYXRlLTIwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIHNocmluay0wICR7Y29sb3J9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEl0ZW1JY29uIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMS41IHB5LTAuMiByb3VuZGVkIHRleHQtWzlweF0gZm9udC1tb25vIGZvbnQtYm9sZCBiZy1zbGF0ZS04MDAgdGV4dC1hbWJlci0zMDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pqhIHtpdGVtLm5pdmVsVGVuc2lvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIHRydW5jYXRlIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+TjSB7aXRlbS51YmljYWNpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5kZXRhbGxlcyA/IGAg4oCiICR7aXRlbS5kZXRhbGxlc31gIDogJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNTZWxlY3RlZCAmJiA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTQwMCBzaHJpbmstMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRm9vdGVyIGNvbiBvcGNpb25lcyBkZSBjcmVhY2nDs24gcsOhcGlkYSB5IGVudHJhZGEgbWFudWFsICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBib3JkZXItdCBib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTk1MC84MCBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIHsoYWxsb3dRdWlja0NyZWF0ZSB8fCBvblF1aWNrQ3JlYXRlKSAmJiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0SXNPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAob25RdWlja0NyZWF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgb25RdWlja0NyZWF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiByb3VuZGVkLXhsIHRleHQtbGVmdCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtZW1lcmFsZC00MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTMwMCBiZy1lbWVyYWxkLTk1MC8zMCBob3ZlcjpiZy1lbWVyYWxkLTkwMC80MCB0cmFuc2l0aW9uLWNvbG9ycyBmb250LWJvbGQgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBjdXJzb3ItcG9pbnRlciBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwLTAuNSBiZy1lbWVyYWxkLTUwMCB0ZXh0LXNsYXRlLTk1MCByb3VuZGVkIGZvbnQtYmxhY2sgdGV4dC1bMTBweF0gbGVhZGluZy1ub25lXCI+Kzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q3JlYXIgbnVldmEgZnVlbnRlIC8gbm9kbyBlbiBsw61uZWE8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldElzQ3VzdG9tTW9kZSh0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0SXNPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHJvdW5kZWQteGwgdGV4dC1sZWZ0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1hbWJlci00MDAgaG92ZXI6dGV4dC1hbWJlci0zMDAgaG92ZXI6YmctYW1iZXItNTAwLzEwIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtbWVkaXVtIGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1hbWJlci01MDAvMzAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxFZGl0MyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5QZXJzb25hbGl6YWRvIC8gQWNvbWV0aWRhIEV4dGVybmEgKFRleHRvIE1hbnVhbCk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogSU5TSUdOSUEgU0VDVU5EQVJJQSBSRVNVTUVOIERFTCBBTElNRU5UQURPUiBTRUxFQ0NJT05BRE8gKi99XG4gICAgICB7c2VsZWN0ZWRJdGVtICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBmbGV4LXdyYXAgZ2FwLTIgcHgtMyBweS0xLjUgYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS0zMDAgYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0ZXh0LVs5cHhdIHRyYWNraW5nLXdpZGVcIj5PcmlnZW46PC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0yMDBcIj57c2VsZWN0ZWRJdGVtLm5vbWJyZX08L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDBcIj7igKI8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hbWJlci00MDAgZm9udC1tb25vIGZvbnQtbWVkaXVtXCI+4pqhIHtzZWxlY3RlZEl0ZW0ubml2ZWxUZW5zaW9ufTwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMFwiPuKAojwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0cnVuY2F0ZVwiPvCfk40ge3NlbGVjdGVkSXRlbS51YmljYWNpb259PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=