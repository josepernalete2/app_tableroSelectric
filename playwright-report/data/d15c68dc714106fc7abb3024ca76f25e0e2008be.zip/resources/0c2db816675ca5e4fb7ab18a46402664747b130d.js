import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_USER_NODE_ENV": "development", "VITE_VAPID_PUBLIC_KEY": "BEvczk5jNzJMDSBNa_C__C-ZwvWwrdIJLiI9WRXpraE1XoEIuW5PyvLklmz4tPo2kotyBlYz6hwKqkP6cgg6u1g"};/**
* Configuración dinámica y desacoplada de la URL Base de la API
* Totalmente agnóstica de hosting (Vercel, Railway, Docker, LAN y Vite Dev Proxy).
* Utiliza rutas relativas para resolver siempre contra el host actual sin CORS.
*/
const getBaseApiUrl = () => {
	// 1. Sobreescritura manual en tiempo de ejecución (útil para pruebas y Capacitor)
	const storedUrl = typeof window !== "undefined" && window.localStorage ? window.localStorage.getItem("CUSTOM_API_BASE_URL") : null;
	if (storedUrl && storedUrl.trim() !== "") {
		return storedUrl.trim().replace(/\/$/, "").replace(/\/api$/, "");
	}
	// 2. Si viene definida expresamente por variable de entorno Vite y no está vacía:
	if (import.meta.env.VITE_API_URL && import.meta.env.VITE_API_URL.trim() !== "") {
		return import.meta.env.VITE_API_URL.trim().replace(/\/$/, "").replace(/\/api$/, "");
	}
	if (import.meta.env.VITE_API_BASE_URL && import.meta.env.VITE_API_BASE_URL.trim() !== "") {
		return import.meta.env.VITE_API_BASE_URL.trim().replace(/\/$/, "").replace(/\/api$/, "");
	}
	// 3. Verificación de Capacitor / Emulador Android nativo
	if (typeof window !== "undefined" && (window.Capacitor || window.location?.protocol === "capacitor:")) {
		return "http://10.0.2.2:3001";
	}
	// 4. Por defecto en todos los entornos web (Vercel, Railway, LAN, Tablets, Dev Server con Proxy):
	// Usar ruta relativa para que las peticiones vayan al mismo origen sin errores de CORS
	return "";
};
export const API_BASE_URL = getBaseApiUrl();
export const API_URL = API_BASE_URL ? `${API_BASE_URL}/api` : "/api";
export default API_BASE_URL;

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxNQUFNLHNCQUFzQjs7Q0FFMUIsTUFBTSxZQUFZLE9BQU8sV0FBVyxlQUFlLE9BQU8sZUFBZSxPQUFPLGFBQWEsUUFBUSxxQkFBcUIsSUFBSTtDQUM5SCxJQUFJLGFBQWEsVUFBVSxLQUFLLE1BQU0sSUFBSTtFQUN4QyxPQUFPLFVBQVUsS0FBSyxDQUFDLENBQUMsUUFBUSxPQUFPLEVBQUUsQ0FBQyxDQUFDLFFBQVEsVUFBVSxFQUFFO0NBQ2pFOztDQUdBLElBQUksT0FBTyxLQUFLLElBQUksZ0JBQWdCLE9BQU8sS0FBSyxJQUFJLGFBQWEsS0FBSyxNQUFNLElBQUk7RUFDOUUsT0FBTyxPQUFPLEtBQUssSUFBSSxhQUFhLEtBQUssQ0FBQyxDQUFDLFFBQVEsT0FBTyxFQUFFLENBQUMsQ0FBQyxRQUFRLFVBQVUsRUFBRTtDQUNwRjtDQUNBLElBQUksT0FBTyxLQUFLLElBQUkscUJBQXFCLE9BQU8sS0FBSyxJQUFJLGtCQUFrQixLQUFLLE1BQU0sSUFBSTtFQUN4RixPQUFPLE9BQU8sS0FBSyxJQUFJLGtCQUFrQixLQUFLLENBQUMsQ0FBQyxRQUFRLE9BQU8sRUFBRSxDQUFDLENBQUMsUUFBUSxVQUFVLEVBQUU7Q0FDekY7O0NBR0EsSUFBSSxPQUFPLFdBQVcsZ0JBQWdCLE9BQU8sYUFBYSxPQUFPLFVBQVUsYUFBYSxlQUFlO0VBQ3JHLE9BQU87Q0FDVDs7O0NBSUEsT0FBTztBQUNUO0FBRUEsT0FBTyxNQUFNLGVBQWUsY0FBYztBQUMxQyxPQUFPLE1BQU0sVUFBVSxlQUFlLEdBQUcsYUFBYSxRQUFRO0FBRTlELGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYXBpLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQ29uZmlndXJhY2nDs24gZGluw6FtaWNhIHkgZGVzYWNvcGxhZGEgZGUgbGEgVVJMIEJhc2UgZGUgbGEgQVBJXG4gKiBUb3RhbG1lbnRlIGFnbsOzc3RpY2EgZGUgaG9zdGluZyAoVmVyY2VsLCBSYWlsd2F5LCBEb2NrZXIsIExBTiB5IFZpdGUgRGV2IFByb3h5KS5cbiAqIFV0aWxpemEgcnV0YXMgcmVsYXRpdmFzIHBhcmEgcmVzb2x2ZXIgc2llbXByZSBjb250cmEgZWwgaG9zdCBhY3R1YWwgc2luIENPUlMuXG4gKi9cbmNvbnN0IGdldEJhc2VBcGlVcmwgPSAoKSA9PiB7XG4gIC8vIDEuIFNvYnJlZXNjcml0dXJhIG1hbnVhbCBlbiB0aWVtcG8gZGUgZWplY3VjacOzbiAow7p0aWwgcGFyYSBwcnVlYmFzIHkgQ2FwYWNpdG9yKVxuICBjb25zdCBzdG9yZWRVcmwgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cubG9jYWxTdG9yYWdlID8gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdDVVNUT01fQVBJX0JBU0VfVVJMJykgOiBudWxsO1xuICBpZiAoc3RvcmVkVXJsICYmIHN0b3JlZFVybC50cmltKCkgIT09ICcnKSB7XG4gICAgcmV0dXJuIHN0b3JlZFVybC50cmltKCkucmVwbGFjZSgvXFwvJC8sICcnKS5yZXBsYWNlKC9cXC9hcGkkLywgJycpO1xuICB9XG5cbiAgLy8gMi4gU2kgdmllbmUgZGVmaW5pZGEgZXhwcmVzYW1lbnRlIHBvciB2YXJpYWJsZSBkZSBlbnRvcm5vIFZpdGUgeSBubyBlc3TDoSB2YWPDrWE6XG4gIGlmIChpbXBvcnQubWV0YS5lbnYuVklURV9BUElfVVJMICYmIGltcG9ydC5tZXRhLmVudi5WSVRFX0FQSV9VUkwudHJpbSgpICE9PSAnJykge1xuICAgIHJldHVybiBpbXBvcnQubWV0YS5lbnYuVklURV9BUElfVVJMLnRyaW0oKS5yZXBsYWNlKC9cXC8kLywgJycpLnJlcGxhY2UoL1xcL2FwaSQvLCAnJyk7XG4gIH1cbiAgaWYgKGltcG9ydC5tZXRhLmVudi5WSVRFX0FQSV9CQVNFX1VSTCAmJiBpbXBvcnQubWV0YS5lbnYuVklURV9BUElfQkFTRV9VUkwudHJpbSgpICE9PSAnJykge1xuICAgIHJldHVybiBpbXBvcnQubWV0YS5lbnYuVklURV9BUElfQkFTRV9VUkwudHJpbSgpLnJlcGxhY2UoL1xcLyQvLCAnJykucmVwbGFjZSgvXFwvYXBpJC8sICcnKTtcbiAgfVxuXG4gIC8vIDMuIFZlcmlmaWNhY2nDs24gZGUgQ2FwYWNpdG9yIC8gRW11bGFkb3IgQW5kcm9pZCBuYXRpdm9cbiAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmICh3aW5kb3cuQ2FwYWNpdG9yIHx8IHdpbmRvdy5sb2NhdGlvbj8ucHJvdG9jb2wgPT09ICdjYXBhY2l0b3I6JykpIHtcbiAgICByZXR1cm4gJ2h0dHA6Ly8xMC4wLjIuMjozMDAxJztcbiAgfVxuXG4gIC8vIDQuIFBvciBkZWZlY3RvIGVuIHRvZG9zIGxvcyBlbnRvcm5vcyB3ZWIgKFZlcmNlbCwgUmFpbHdheSwgTEFOLCBUYWJsZXRzLCBEZXYgU2VydmVyIGNvbiBQcm94eSk6XG4gIC8vIFVzYXIgcnV0YSByZWxhdGl2YSBwYXJhIHF1ZSBsYXMgcGV0aWNpb25lcyB2YXlhbiBhbCBtaXNtbyBvcmlnZW4gc2luIGVycm9yZXMgZGUgQ09SU1xuICByZXR1cm4gJyc7XG59O1xuXG5leHBvcnQgY29uc3QgQVBJX0JBU0VfVVJMID0gZ2V0QmFzZUFwaVVybCgpO1xuZXhwb3J0IGNvbnN0IEFQSV9VUkwgPSBBUElfQkFTRV9VUkwgPyBgJHtBUElfQkFTRV9VUkx9L2FwaWAgOiAnL2FwaSc7XG5cbmV4cG9ydCBkZWZhdWx0IEFQSV9CQVNFX1VSTDtcblxuIl19