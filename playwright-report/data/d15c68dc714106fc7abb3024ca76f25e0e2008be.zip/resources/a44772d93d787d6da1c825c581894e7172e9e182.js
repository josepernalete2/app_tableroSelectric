import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/ReportesView.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f49807c8";
import useStore, { formatElementTitleWithId } from "/src/store/useStore.js?t=1790792337841";
import { API_BASE_URL } from "/src/utils/api.js";
import { FileText, TrendingUp, ShieldAlert, CheckCircle2, AlertTriangle, Download, ExternalLink, Building, Layers, Zap, Cpu, Activity, FileCode, Sparkles, Printer, RefreshCw, Search, Filter } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/ReportesView.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function ReportesView() {
	_s();
	const navigate = useNavigate();
	const { user, token, companies } = useStore();
	// Filtrar empresas si es CLIENT
	const availableCompanies = useMemo(() => {
		if (user?.role === "CLIENT") {
			return companies.filter((c) => c.id === user.companyId);
		}
		return companies;
	}, [companies, user]);
	const [selectedCompanyId, setSelectedCompanyId] = useState("");
	const [selectedProyectoId, setSelectedProyectoId] = useState("");
	const [activeTab, setActiveTab] = useState("informes");
	const [auditData, setAuditData] = useState(null);
	const [alarmasData, setAlarmasData] = useState([]);
	const [loadingData, setLoadingData] = useState(false);
	// Inicializar empresa seleccionada
	useEffect(() => {
		if (availableCompanies.length > 0 && !selectedCompanyId) {
			setSelectedCompanyId(availableCompanies[0].id);
		}
	}, [availableCompanies, selectedCompanyId]);
	const currentCompany = useMemo(() => {
		return availableCompanies.find((c) => c.id === selectedCompanyId) || availableCompanies[0];
	}, [availableCompanies, selectedCompanyId]);
	const currentProjects = useMemo(() => {
		return currentCompany?.proyectos || [];
	}, [currentCompany]);
	// Inicializar proyecto seleccionado
	useEffect(() => {
		if (currentProjects.length > 0 && (!selectedProyectoId || !currentProjects.find((p) => p.id === selectedProyectoId))) {
			setSelectedProyectoId(currentProjects[0].id);
		} else if (currentProjects.length === 0) {
			setSelectedProyectoId("");
		}
	}, [currentProjects, selectedProyectoId]);
	const currentProyecto = useMemo(() => {
		return currentProjects.find((p) => p.id === selectedProyectoId);
	}, [currentProjects, selectedProyectoId]);
	// Cargar datos de auditoría y alarmas desde el backend cuando cambia el proyecto
	useEffect(() => {
		if (!selectedProyectoId) {
			setAuditData(null);
			setAlarmasData([]);
			return;
		}
		let isMounted = true;
		setLoadingData(true);
		const fetchData = async () => {
			try {
				const headers = token ? { "Authorization": `Bearer ${token}` } : {};
				// 1. Auditoría
				const resAudit = await fetch(`${API_BASE_URL}/api/auditoria/${selectedProyectoId}`, { headers });
				if (resAudit.ok) {
					const auditJson = await resAudit.json();
					if (isMounted) setAuditData(auditJson);
				}
				// 2. Alarmas
				const resAlarmas = await fetch(`${API_BASE_URL}/api/alarmas/proyecto/${selectedProyectoId}`, { headers });
				if (resAlarmas.ok) {
					const alarmasJson = await resAlarmas.json();
					if (isMounted) setAlarmasData(Array.isArray(alarmasJson) ? alarmasJson : []);
				}
			} catch (err) {
				console.error("Error al cargar auditoría y alarmas:", err);
			} finally {
				if (isMounted) setLoadingData(false);
			}
		};
		fetchData();
		return () => {
			isMounted = false;
		};
	}, [selectedProyectoId, token]);
	// Cálculos locales para el proyecto actual
	const elementos = currentProyecto?.elementosUnifilares || currentProyecto?.tableros || [];
	const tableros = elementos.filter((e) => e.tipoElemento === "TABLERO");
	const transformadores = elementos.filter((e) => e.tipoElemento === "TRANSFORMADOR");
	const generadores = elementos.filter((e) => e.tipoElemento === "GENERADOR");
	const subestaciones = currentProyecto?.inspeccionesSubestacion || currentProyecto?.subestaciones || [];
	// Descarga de DXF
	const handleDownloadDXF = async (tableroId, tableroNombre) => {
		try {
			const authToken = token || useStore.getState().token || localStorage.getItem("token");
			const headers = { ...authToken ? { "Authorization": `Bearer ${authToken}` } : {} };
			// 1. Intento primario vía GET por ID
			let res = await fetch(`${API_BASE_URL}/api/tableros/${tableroId}/dxf`, { headers });
			// 2. Si retorna 404, hacer fallback enviando los datos del tablero que ya están en memoria local
			if (!res.ok) {
				const localTablero = tableros.find((t) => t.id === tableroId);
				if (localTablero) {
					res = await fetch(`${API_BASE_URL}/api/tableros/dxf/export-custom`, {
						method: "POST",
						headers: {
							"Content-Type": "application/json",
							...headers
						},
						body: JSON.stringify({ tablero: localTablero })
					});
				}
			}
			if (!res.ok) {
				throw new Error(`El servidor respondió con estado ${res.status}`);
			}
			const blob = await res.blob();
			const url = window.URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = `unifilar_${(tableroNombre || "tablero").toLowerCase().replace(/[^a-zA-Z0-9_-]/g, "_")}.dxf`;
			document.body.appendChild(a);
			a.click();
			a.remove();
			window.URL.revokeObjectURL(url);
		} catch (err) {
			console.error("Error al descargar DXF:", err);
			alert(`No se pudo descargar el archivo DXF: ${err.message}`);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 text-slate-100 p-4 md:p-8 space-y-8 max-w-7xl mx-auto",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-slate-800",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-amber-400",
						children: /* @__PURE__ */ _jsxDEV(TrendingUp, { className: "w-6 h-6" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl md:text-2xl font-black text-slate-100 tracking-tight",
						children: "Centro de Reportes y Auditoría Eléctrica"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: "Informes técnicos compilados, auditoría de red, balance de cargas y exportación CAD"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 175,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 11
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 170,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center gap-3 w-full md:w-auto",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 bg-slate-950 border border-slate-800 p-1.5 rounded-xl",
						children: [/* @__PURE__ */ _jsxDEV(Building, { className: "w-4 h-4 text-amber-500 ml-2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							value: selectedCompanyId,
							onChange: (e) => {
								setSelectedCompanyId(e.target.value);
								setSelectedProyectoId("");
							},
							className: "bg-transparent text-xs text-slate-200 font-bold outline-none pr-3 cursor-pointer",
							children: availableCompanies.map((c) => /* @__PURE__ */ _jsxDEV("option", {
								value: c.id,
								className: "bg-slate-900 text-slate-200",
								children: c.nombre
							}, c.id, false, {
								fileName: _jsxFileName,
								lineNumber: 199,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 188,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 bg-slate-950 border border-slate-800 p-1.5 rounded-xl",
						children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-4 h-4 text-amber-500 ml-2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							value: selectedProyectoId,
							onChange: (e) => setSelectedProyectoId(e.target.value),
							className: "bg-transparent text-xs text-slate-200 font-bold outline-none pr-3 cursor-pointer",
							disabled: currentProjects.length === 0,
							children: currentProjects.length === 0 ? /* @__PURE__ */ _jsxDEV("option", {
								value: "",
								className: "bg-slate-900 text-slate-400",
								children: "Sin proyectos registrados"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 215,
								columnNumber: 17
							}, this) : currentProjects.map((p) => /* @__PURE__ */ _jsxDEV("option", {
								value: p.id,
								className: "bg-slate-900 text-slate-200",
								children: p.nombre
							}, p.id, false, {
								fileName: _jsxFileName,
								lineNumber: 218,
								columnNumber: 19
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 206,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 169,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-5 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 13
								}, this), " Salud de Red"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "my-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: `text-2xl font-black ${(auditData?.saludRed || 100) >= 80 ? "text-emerald-400" : (auditData?.saludRed || 100) >= 50 ? "text-amber-400" : "text-red-400"}`,
									children: loadingData ? "..." : `${auditData?.saludRed ?? 100}%`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 236,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-slate-500",
									children: auditData?.saludRed >= 80 ? "Red en estado óptimo" : "Requiere atención"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 241,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 235,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-full bg-slate-900 rounded-full h-1.5 overflow-hidden",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: `h-full transition-all duration-500 ${(auditData?.saludRed || 100) >= 80 ? "bg-emerald-500" : (auditData?.saludRed || 100) >= 50 ? "bg-amber-500" : "bg-red-500"}`,
									style: { width: `${auditData?.saludRed ?? 100}%` }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 246,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 231,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 258,
									columnNumber: 13
								}, this), " Tableros"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 257,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "my-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-2xl font-black text-slate-100",
									children: tableros.length
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 261,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-slate-500",
									children: "Tableros eléctricos registrados"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 262,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 260,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[9px] text-slate-400 font-mono",
								children: "Capa 1 / Diagramas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 256,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Cpu, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 270,
									columnNumber: 13
								}, this), " Potencia / Suministro"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 269,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "my-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-2xl font-black text-slate-100",
									children: transformadores.length + generadores.length
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 273,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-slate-500",
									children: [
										transformadores.length,
										" Trafos / ",
										generadores.length,
										" Gen"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 274,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 272,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[9px] text-slate-400 font-mono",
								children: "Subestación / Acometida"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 276,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 268,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Building, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 282,
									columnNumber: 13
								}, this), " Subestaciones"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 281,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "my-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-2xl font-black text-slate-100",
									children: subestaciones.length
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 285,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-slate-500",
									children: "Inspecciones físicas"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 286,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 284,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[9px] text-slate-400 font-mono",
								children: "Infraestructura"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 280,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-3.5 h-3.5 text-red-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 294,
									columnNumber: 13
								}, this), " Alarmas Activas"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 293,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "my-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: `text-2xl font-black ${alarmasData.length > 0 ? "text-red-400" : "text-slate-100"}`,
									children: alarmasData.length
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 297,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-slate-500",
									children: alarmasData.length > 0 ? "Desbalances o sobrecargas" : "Sin anomalías críticas"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 300,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 296,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[9px] text-slate-400 font-mono",
								children: "Capa 8 / Alertas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 304,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 292,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 229,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex border-b border-slate-800 gap-2 overflow-x-auto text-xs font-semibold",
				children: [
					{
						id: "informes",
						label: "Informes Técnicos PDF",
						icon: FileText,
						count: currentProjects.length
					},
					{
						id: "auditoria",
						label: "Auditoría de Red",
						icon: CheckCircle2,
						count: auditData?.totalInconsistencias || 0
					},
					{
						id: "alarmas",
						label: "Alarmas y Desbalance",
						icon: AlertTriangle,
						count: alarmasData.length
					},
					{
						id: "dxf",
						label: "Planos AutoCAD (DXF)",
						icon: FileCode,
						count: tableros.length
					},
					{
						id: "ia",
						label: "Analíticas IA (Futuro)",
						icon: Sparkles
					}
				].map((tab) => {
					const Icon = tab.icon;
					const active = activeTab === tab.id;
					return /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveTab(tab.id),
						className: `py-3 px-4 flex items-center gap-2 border-b-2 transition-all whitespace-nowrap cursor-pointer ${active ? "border-amber-500 text-amber-400 font-bold bg-amber-500/5" : "border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700"}`,
						children: [
							/* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 329,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: tab.label }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 330,
								columnNumber: 15
							}, this),
							typeof tab.count === "number" && tab.count > 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: `ml-1.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold ${tab.id === "alarmas" ? "bg-red-500/20 text-red-400 border border-red-500/30" : "bg-slate-800 text-slate-300"}`,
								children: tab.count
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 17
							}, this)
						]
					}, tab.id, true, {
						fileName: _jsxFileName,
						lineNumber: 320,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 309,
				columnNumber: 7
			}, this),
			activeTab === "informes" && /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-950/60 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-bold text-slate-100 flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV(FileText, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 351,
									columnNumber: 17
								}, this),
								"Informe Técnico Compilado de ",
								currentProyecto?.nombre || "Proyecto"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 350,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Genera el documento consolidado oficial con portada ejecutiva, diagramas unifilares, fichas de equipos y cuadro de recomendaciones según norma CEN."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 354,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 349,
						columnNumber: 13
					}, this), selectedProyectoId && /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigate(`/empresa/${selectedCompanyId}/proyecto/${selectedProyectoId}/informe`),
						className: "px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-2 transition-all shadow-md active:scale-95 shrink-0 cursor-pointer",
						children: [/* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 363,
							columnNumber: 17
						}, this), " Abrir Informe Completo"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 359,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 348,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-slate-400",
						children: ["Proyectos Disponibles en ", currentCompany?.nombre]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 370,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4",
						children: currentProjects.map((proj) => {
							const numTableros = (proj.elementosUnifilares || proj.tableros || []).filter((e) => e.tipoElemento === "TABLERO").length;
							const numSubestaciones = (proj.inspeccionesSubestacion || proj.subestaciones || []).length;
							return /* @__PURE__ */ _jsxDEV("div", {
								className: "p-5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-start",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
										className: "font-bold text-sm text-slate-200",
										children: proj.nombre
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 384,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400",
										children: proj.direccion || "Ubicación no especificada"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 385,
										columnNumber: 25
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 383,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] font-mono text-amber-400",
										children: [numTableros, " Tableros"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 387,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 382,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between text-xs text-slate-400 pt-3 border-t border-slate-900",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: [numSubestaciones, " Subestaciones registradas"] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 393,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => navigate(`/empresa/${selectedCompanyId}/proyecto/${proj.id}/informe`),
										className: "text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 cursor-pointer",
										children: "Ver Informe PDF →"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 394,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 392,
									columnNumber: 21
								}, this)]
							}, proj.id, true, {
								fileName: _jsxFileName,
								lineNumber: 378,
								columnNumber: 19
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 373,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 369,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 347,
				columnNumber: 9
			}, this),
			activeTab === "auditoria" && /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "p-5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-sm font-bold text-slate-100 flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 415,
							columnNumber: 17
						}, this), " Diagnóstico de Integridad Eléctrica"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 414,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: "Detección automática de inconsistencias jerárquicas, elementos huérfanos y tableros sin carga."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 417,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 413,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs text-slate-400",
							children: "Índice de Salud:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 422,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: `text-base font-black px-2.5 py-0.5 rounded-lg border ${(auditData?.saludRed || 100) >= 80 ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" : "bg-amber-500/10 border-amber-500/30 text-amber-400"}`,
							children: [auditData?.saludRed ?? 100, "%"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 423,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 421,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 412,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 437,
									columnNumber: 17
								}, this),
								"Equipos Huérfanos (",
								auditData?.huerfanos?.length || 0,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 15
						}, this), auditData?.huerfanos?.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: auditData.huerfanos.map((item, idx) => /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
									className: "text-slate-200 block",
									children: item.nombre
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 445,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] text-slate-500 font-mono",
									children: ["Tipo: ", item.tipoElemento]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 446,
									columnNumber: 25
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 444,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-0.5 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded text-[10px] font-bold",
									children: "Sin conexión"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 448,
									columnNumber: 23
								}, this)]
							}, idx, true, {
								fileName: _jsxFileName,
								lineNumber: 443,
								columnNumber: 21
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 441,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 rounded-xl bg-slate-950/40 border border-slate-800/60 text-center text-xs text-slate-500 italic",
							children: "✓ No se detectaron equipos huérfanos en la red jerárquica."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 455,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 435,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 464,
									columnNumber: 17
								}, this),
								"Tableros Sin Carga Registrada (",
								auditData?.sinCarga?.length || 0,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 463,
							columnNumber: 15
						}, this), auditData?.sinCarga?.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: auditData.sinCarga.map((item, idx) => /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
									className: "text-slate-200 block",
									children: item.nombre
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 472,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] text-slate-500",
									children: ["Ubicación: ", item.ubicacion || "No definida"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 473,
									columnNumber: 25
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 471,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-0.5 bg-blue-500/10 border border-blue-500/30 text-blue-400 rounded text-[10px] font-bold",
									children: "0 VA / Sin Circuitos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 475,
									columnNumber: 23
								}, this)]
							}, idx, true, {
								fileName: _jsxFileName,
								lineNumber: 470,
								columnNumber: 21
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 468,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 rounded-xl bg-slate-950/40 border border-slate-800/60 text-center text-xs text-slate-500 italic",
							children: "✓ Todos los tableros tienen circuitos o cargas operativas."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 482,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 462,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 433,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 411,
				columnNumber: 9
			}, this),
			activeTab === "alarmas" && /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "p-5 rounded-2xl bg-slate-950 border border-slate-800 flex justify-between items-center",
					children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-sm font-bold text-slate-100 flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-4 h-4 text-red-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 497,
							columnNumber: 17
						}, this), " Registro de Anomalías y Desbalances Eléctricos"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 496,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: "Monitoreo continuo de desbalances de fase > 15% y sobrecargas en interruptores principales."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 499,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 495,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 494,
					columnNumber: 11
				}, this), alarmasData.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-3",
					children: alarmasData.map((alarma) => /* @__PURE__ */ _jsxDEV("div", {
						className: `p-4 rounded-2xl border flex flex-col md:flex-row justify-between items-start md:items-center gap-3 ${alarma.severidad === "CRITICAL" ? "bg-red-950/20 border-red-800/40 text-red-300" : "bg-amber-950/20 border-amber-800/40 text-amber-300"}`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: `px-2 py-0.5 rounded text-[9px] font-black uppercase ${alarma.severidad === "CRITICAL" ? "bg-red-500 text-slate-950" : "bg-amber-500 text-slate-950"}`,
										children: alarma.severidad
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 518,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("strong", {
										className: "text-xs text-slate-100",
										children: alarma.tipo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 523,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 font-mono",
										children: new Date(alarma.createdAt).toLocaleString()
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 524,
										columnNumber: 23
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 517,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300",
								children: alarma.mensaje
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 528,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 516,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-[10px] font-bold text-slate-300",
							children: ["Estado: ", alarma.estado]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 531,
							columnNumber: 19
						}, this)]
					}, alarma.id, true, {
						fileName: _jsxFileName,
						lineNumber: 508,
						columnNumber: 17
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 506,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "p-8 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-2",
					children: [
						/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-10 h-10 text-emerald-400 mx-auto" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 539,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("h4", {
							className: "text-sm font-bold text-slate-200",
							children: "Red en Perfecto Balance"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 540,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "No se detectaron alarmas críticas ni desbalances mayores al 15% en los tableros del proyecto."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 541,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 538,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 493,
				columnNumber: 9
			}, this),
			activeTab === "dxf" && /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "p-5 rounded-2xl bg-slate-950 border border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-sm font-bold text-slate-100 flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(FileCode, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 554,
							columnNumber: 15
						}, this), " Exportación Vectorial DXF (AutoCAD R12)"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 553,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400 mt-1",
						children: "Descarga los diagramas unifilares individuales de cada tablero listos para editar en AutoCAD, LibreCAD o ZWCAD."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 556,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 552,
					columnNumber: 11
				}, this), tableros.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",
					children: tableros.map((tab) => /* @__PURE__ */ _jsxDEV("div", {
						className: "p-5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded",
									children: ["ID: ", tab.id]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 569,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-sm text-slate-200 mt-2",
									children: tab.nombre
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 572,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400",
									children: ["Ubicación: ", tab.ubicacion || "Sin especificar"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 573,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 568,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => handleDownloadDXF(tab.id, tab.nombre),
							className: "w-full py-2 bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-slate-200 border border-slate-800 hover:border-amber-500 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 580,
								columnNumber: 21
							}, this), " Descargar DXF"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 576,
							columnNumber: 19
						}, this)]
					}, tab.id, true, {
						fileName: _jsxFileName,
						lineNumber: 564,
						columnNumber: 17
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 562,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "p-8 rounded-2xl bg-slate-950 border border-slate-800 text-center text-xs text-slate-500 italic",
					children: "No hay tableros eléctricos registrados en este proyecto para exportar."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 586,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 551,
				columnNumber: 9
			}, this),
			activeTab === "ia" && /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "p-5 rounded-2xl bg-slate-950 border border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-sm font-bold text-slate-100 flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 598,
							columnNumber: 15
						}, this), " Analíticas Predictivas y Machine Learning"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 597,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400 mt-1",
						children: "Próximas integraciones en desarrollo para mantenimiento preventivo y optimización de redes eléctricas:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 600,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 596,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-3 gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 rounded-2xl bg-slate-950/60 border border-emerald-900/40 space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold",
									children: "Predictivo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 607,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-sm text-slate-200",
									children: "Análisis Predictivo de Fallas"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 608,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400",
									children: "Cálculo de probabilidad de disparo de interruptores bajo condiciones de carga máxima sostenida."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 609,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 606,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 rounded-2xl bg-slate-950/60 border border-sky-900/40 space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-0.5 rounded bg-sky-500/20 text-sky-400 text-[10px] font-bold",
									children: "Termografía"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 615,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-sm text-slate-200",
									children: "Evolución Térmica Temporal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 616,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400",
									children: "Histogramas de variación de temperatura en bornes de conexión para detectar falsos contactos."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 617,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 614,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 rounded-2xl bg-slate-950/60 border border-purple-900/40 space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 text-[10px] font-bold",
									children: "Normativa"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 623,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-sm text-slate-200",
									children: "Auditoría Automática CEN"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 624,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400",
									children: "Verificación de calibres de conductores y distancias de seguridad según Código Eléctrico Nacional."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 625,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 622,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 605,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 595,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 166,
		columnNumber: 5
	}, this);
}
_s(ReportesView, "KP3f4Ib7ylVhU/FKHY94CE6e2jk=", false, function() {
	return [useNavigate, useStore];
});
_c = ReportesView;
var _c;
$RefreshReg$(_c, "ReportesView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/views/ReportesView.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/ReportesView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/ReportesView.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/ReportesView.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxlQUFlO0FBQ3BELFNBQVMsbUJBQW1CO0FBQzVCLE9BQU8sWUFBWSxnQ0FBZ0M7QUFDbkQsU0FBUyxvQkFBb0I7QUFDN0IsU0FDRSxVQUNBLFlBQ0EsYUFDQSxjQUNBLGVBQ0EsVUFDQSxjQUNBLFVBQ0EsUUFDQSxLQUNBLEtBQ0EsVUFDQSxVQUNBLFVBQ0EsU0FDQSxXQUNBLFFBQ0EsY0FDSzs7OztBQUVQLGVBQWUsU0FBUyxlQUFlOztDQUNyQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLEVBQUUsTUFBTSxPQUFPLGNBQWMsU0FBUzs7Q0FHNUMsTUFBTSxxQkFBcUIsY0FBYztFQUN2QyxJQUFJLE1BQU0sU0FBUyxVQUFVO0dBQzNCLE9BQU8sVUFBVSxRQUFPLE1BQUssRUFBRSxPQUFPLEtBQUssU0FBUztFQUN0RDtFQUNBLE9BQU87Q0FDVCxHQUFHLENBQUMsV0FBVyxJQUFJLENBQUM7Q0FFcEIsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxFQUFFO0NBQzdELE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsRUFBRTtDQUMvRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxVQUFVO0NBQ3JELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLElBQUk7Q0FDL0MsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsQ0FBQyxDQUFDO0NBQ2pELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7O0NBR3BELGdCQUFnQjtFQUNkLElBQUksbUJBQW1CLFNBQVMsS0FBSyxDQUFDLG1CQUFtQjtHQUN2RCxxQkFBcUIsbUJBQW1CLEVBQUUsQ0FBQyxFQUFFO0VBQy9DO0NBQ0YsR0FBRyxDQUFDLG9CQUFvQixpQkFBaUIsQ0FBQztDQUUxQyxNQUFNLGlCQUFpQixjQUFjO0VBQ25DLE9BQU8sbUJBQW1CLE1BQUssTUFBSyxFQUFFLE9BQU8saUJBQWlCLEtBQUssbUJBQW1CO0NBQ3hGLEdBQUcsQ0FBQyxvQkFBb0IsaUJBQWlCLENBQUM7Q0FFMUMsTUFBTSxrQkFBa0IsY0FBYztFQUNwQyxPQUFPLGdCQUFnQixhQUFhLENBQUM7Q0FDdkMsR0FBRyxDQUFDLGNBQWMsQ0FBQzs7Q0FHbkIsZ0JBQWdCO0VBQ2QsSUFBSSxnQkFBZ0IsU0FBUyxNQUFNLENBQUMsc0JBQXNCLENBQUMsZ0JBQWdCLE1BQUssTUFBSyxFQUFFLE9BQU8sa0JBQWtCLElBQUk7R0FDbEgsc0JBQXNCLGdCQUFnQixFQUFFLENBQUMsRUFBRTtFQUM3QyxPQUFPLElBQUksZ0JBQWdCLFdBQVcsR0FBRztHQUN2QyxzQkFBc0IsRUFBRTtFQUMxQjtDQUNGLEdBQUcsQ0FBQyxpQkFBaUIsa0JBQWtCLENBQUM7Q0FFeEMsTUFBTSxrQkFBa0IsY0FBYztFQUNwQyxPQUFPLGdCQUFnQixNQUFLLE1BQUssRUFBRSxPQUFPLGtCQUFrQjtDQUM5RCxHQUFHLENBQUMsaUJBQWlCLGtCQUFrQixDQUFDOztDQUd4QyxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsb0JBQW9CO0dBQ3ZCLGFBQWEsSUFBSTtHQUNqQixlQUFlLENBQUMsQ0FBQztHQUNqQjtFQUNGO0VBRUEsSUFBSSxZQUFZO0VBQ2hCLGVBQWUsSUFBSTtFQUVuQixNQUFNLFlBQVksWUFBWTtHQUM1QixJQUFJO0lBQ0YsTUFBTSxVQUFVLFFBQVEsRUFBRSxpQkFBaUIsVUFBVSxRQUFRLElBQUksQ0FBQzs7SUFHbEUsTUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLGFBQWEsaUJBQWlCLHNCQUFzQixFQUFFLFFBQVEsQ0FBQztJQUMvRixJQUFJLFNBQVMsSUFBSTtLQUNmLE1BQU0sWUFBWSxNQUFNLFNBQVMsS0FBSztLQUN0QyxJQUFJLFdBQVcsYUFBYSxTQUFTO0lBQ3ZDOztJQUdBLE1BQU0sYUFBYSxNQUFNLE1BQU0sR0FBRyxhQUFhLHdCQUF3QixzQkFBc0IsRUFBRSxRQUFRLENBQUM7SUFDeEcsSUFBSSxXQUFXLElBQUk7S0FDakIsTUFBTSxjQUFjLE1BQU0sV0FBVyxLQUFLO0tBQzFDLElBQUksV0FBVyxlQUFlLE1BQU0sUUFBUSxXQUFXLElBQUksY0FBYyxDQUFDLENBQUM7SUFDN0U7R0FDRixTQUFTLEtBQUs7SUFDWixRQUFRLE1BQU0sd0NBQXdDLEdBQUc7R0FDM0QsVUFBVTtJQUNSLElBQUksV0FBVyxlQUFlLEtBQUs7R0FDckM7RUFDRjtFQUVBLFVBQVU7RUFDVixhQUFhO0dBQUUsWUFBWTtFQUFPO0NBQ3BDLEdBQUcsQ0FBQyxvQkFBb0IsS0FBSyxDQUFDOztDQUc5QixNQUFNLFlBQVksaUJBQWlCLHVCQUF1QixpQkFBaUIsWUFBWSxDQUFDO0NBQ3hGLE1BQU0sV0FBVyxVQUFVLFFBQU8sTUFBSyxFQUFFLGlCQUFpQixTQUFTO0NBQ25FLE1BQU0sa0JBQWtCLFVBQVUsUUFBTyxNQUFLLEVBQUUsaUJBQWlCLGVBQWU7Q0FDaEYsTUFBTSxjQUFjLFVBQVUsUUFBTyxNQUFLLEVBQUUsaUJBQWlCLFdBQVc7Q0FDeEUsTUFBTSxnQkFBZ0IsaUJBQWlCLDJCQUEyQixpQkFBaUIsaUJBQWlCLENBQUM7O0NBR3JHLE1BQU0sb0JBQW9CLE9BQU8sV0FBVyxrQkFBa0I7RUFDNUQsSUFBSTtHQUNGLE1BQU0sWUFBWSxTQUFTLFNBQVMsU0FBUyxDQUFDLENBQUMsU0FBUyxhQUFhLFFBQVEsT0FBTztHQUNwRixNQUFNLFVBQVUsRUFDZCxHQUFJLFlBQVksRUFBRSxpQkFBaUIsVUFBVSxZQUFZLElBQUksQ0FBQyxFQUNoRTs7R0FHQSxJQUFJLE1BQU0sTUFBTSxNQUFNLEdBQUcsYUFBYSxnQkFBZ0IsVUFBVSxPQUFPLEVBQUUsUUFBUSxDQUFDOztHQUdsRixJQUFJLENBQUMsSUFBSSxJQUFJO0lBQ1gsTUFBTSxlQUFlLFNBQVMsTUFBSyxNQUFLLEVBQUUsT0FBTyxTQUFTO0lBQzFELElBQUksY0FBYztLQUNoQixNQUFNLE1BQU0sTUFBTSxHQUFHLGFBQWEsa0NBQWtDO01BQ2xFLFFBQVE7TUFDUixTQUFTO09BQ1AsZ0JBQWdCO09BQ2hCLEdBQUc7TUFDTDtNQUNBLE1BQU0sS0FBSyxVQUFVLEVBQUUsU0FBUyxhQUFhLENBQUM7S0FDaEQsQ0FBQztJQUNIO0dBQ0Y7R0FFQSxJQUFJLENBQUMsSUFBSSxJQUFJO0lBQ1gsTUFBTSxJQUFJLE1BQU0sb0NBQW9DLElBQUksUUFBUTtHQUNsRTtHQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSztHQUM1QixNQUFNLE1BQU0sT0FBTyxJQUFJLGdCQUFnQixJQUFJO0dBQzNDLE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztHQUNwQyxFQUFFLE9BQU87R0FDVCxFQUFFLFdBQVcsYUFBYSxpQkFBaUIsVUFBUyxDQUFFLFlBQVksQ0FBQyxDQUFDLFFBQVEsbUJBQW1CLEdBQUcsRUFBRTtHQUNwRyxTQUFTLEtBQUssWUFBWSxDQUFDO0dBQzNCLEVBQUUsTUFBTTtHQUNSLEVBQUUsT0FBTztHQUNULE9BQU8sSUFBSSxnQkFBZ0IsR0FBRztFQUNoQyxTQUFTLEtBQUs7R0FDWixRQUFRLE1BQU0sMkJBQTJCLEdBQUc7R0FDNUMsTUFBTSx3Q0FBd0MsSUFBSSxTQUFTO0VBQzdEO0NBQ0Y7Q0FHQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FHRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxZQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7OztLQUM5Qjs7OztlQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBK0Q7S0FFekU7Ozs7ZUFDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBeUI7S0FFbkM7Ozs7YUFDQTs7OzthQUNGOzs7OzthQUNGOzs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsOEJBQStCOzs7O2dCQUNuRCx3QkFBQyxVQUFEO09BQ0UsT0FBTztPQUNQLFdBQVcsTUFBTTtRQUNmLHFCQUFxQixFQUFFLE9BQU8sS0FBSztRQUNuQyxzQkFBc0IsRUFBRTtPQUMxQjtPQUNBLFdBQVU7aUJBRVQsbUJBQW1CLEtBQUksTUFDdEIsd0JBQUMsVUFBRDtRQUFtQixPQUFPLEVBQUU7UUFBSSxXQUFVO2tCQUN2QyxFQUFFO09BQ0csR0FGSyxFQUFFOzs7O2NBRVAsQ0FDVDtNQUNLOzs7O2NBQ0w7Ozs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSw4QkFBK0I7Ozs7Z0JBQ2pELHdCQUFDLFVBQUQ7T0FDRSxPQUFPO09BQ1AsV0FBVyxNQUFNLHNCQUFzQixFQUFFLE9BQU8sS0FBSztPQUNyRCxXQUFVO09BQ1YsVUFBVSxnQkFBZ0IsV0FBVztpQkFFcEMsZ0JBQWdCLFdBQVcsSUFDMUIsd0JBQUMsVUFBRDtRQUFRLE9BQU07UUFBRyxXQUFVO2tCQUE4QjtPQUFpQzs7OztrQkFFMUYsZ0JBQWdCLEtBQUksTUFDbEIsd0JBQUMsVUFBRDtRQUFtQixPQUFPLEVBQUU7UUFBSSxXQUFVO2tCQUN2QyxFQUFFO09BQ0csR0FGSyxFQUFFOzs7O2NBRVAsQ0FDVDtNQUVHOzs7O2NBQ0w7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDZCQUE4Qjs7OztrQkFBQyxlQUMvQzs7Ozs7O09BQ04sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVyx3QkFDZCxXQUFXLFlBQVksUUFBUSxLQUFLLHNCQUFzQixXQUFXLFlBQVksUUFBUSxLQUFLLG1CQUFtQjttQkFFakgsY0FBYyxRQUFRLEdBQUcsV0FBVyxZQUFZLElBQUk7UUFDakQ7Ozs7a0JBQ04sd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsV0FBVyxZQUFZLEtBQUsseUJBQXlCO1FBQ3JEOzs7O2dCQUNBOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxPQUFEO1NBQ0UsV0FBVyx1Q0FDUixXQUFXLFlBQVksUUFBUSxLQUFLLG9CQUFvQixXQUFXLFlBQVksUUFBUSxLQUFLLGlCQUFpQjtTQUVoSCxPQUFPLEVBQUUsT0FBTyxHQUFHLFdBQVcsWUFBWSxJQUFJLEdBQUc7UUFDbEQ7Ozs7O09BQ0U7Ozs7O01BQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQ0Usd0JBQUMsS0FBRCxFQUFLLFdBQVUsNEJBQTZCOzs7O2tCQUFDLFdBQ3pDOzs7Ozs7T0FDTix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFzQyxTQUFTO1FBQWE7Ozs7a0JBQzVFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUE2QjtRQUFrQzs7OztnQkFDekU7Ozs7OztPQUNMLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFzQztPQUF3Qjs7Ozs7TUFDM0U7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQ0Usd0JBQUMsS0FBRCxFQUFLLFdBQVUsOEJBQStCOzs7O2tCQUFDLHdCQUMzQzs7Ozs7O09BQ04sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0MsZ0JBQWdCLFNBQVMsWUFBWTtRQUFhOzs7O2tCQUN4Ryx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUEyQyxnQkFBZ0I7VUFBTztVQUFXLFlBQVk7VUFBTztTQUFPOzs7OztnQkFDcEc7Ozs7OztPQUNMLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFzQztPQUE2Qjs7Ozs7TUFDaEY7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsNkJBQThCOzs7O2tCQUFDLGdCQUMvQzs7Ozs7O09BQ04sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0MsY0FBYztRQUFhOzs7O2tCQUNqRix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBNkI7UUFBdUI7Ozs7Z0JBQzlEOzs7Ozs7T0FDTCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBc0M7T0FBcUI7Ozs7O01BQ3hFOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLDJCQUE0Qjs7OztrQkFBQyxrQkFDaEQ7Ozs7OztPQUNOLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVcsdUJBQXVCLFlBQVksU0FBUyxJQUFJLGlCQUFpQjttQkFDL0UsWUFBWTtRQUNUOzs7O2tCQUNOLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLFlBQVksU0FBUyxJQUFJLDhCQUE4QjtRQUN2RDs7OztnQkFDQTs7Ozs7O09BQ0wsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXNDO09BQXNCOzs7OztNQUN6RTs7Ozs7O0lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1o7S0FDQztNQUFFLElBQUk7TUFBWSxPQUFPO01BQXlCLE1BQU07TUFBVSxPQUFPLGdCQUFnQjtLQUFPO0tBQ2hHO01BQUUsSUFBSTtNQUFhLE9BQU87TUFBb0IsTUFBTTtNQUFjLE9BQU8sV0FBVyx3QkFBd0I7S0FBRTtLQUM5RztNQUFFLElBQUk7TUFBVyxPQUFPO01BQXdCLE1BQU07TUFBZSxPQUFPLFlBQVk7S0FBTztLQUMvRjtNQUFFLElBQUk7TUFBTyxPQUFPO01BQXdCLE1BQU07TUFBVSxPQUFPLFNBQVM7S0FBTztLQUNuRjtNQUFFLElBQUk7TUFBTSxPQUFPO01BQTBCLE1BQU07S0FBUztJQUM5RCxDQUFDLENBQUMsS0FBSSxRQUFPO0tBQ1gsTUFBTSxPQUFPLElBQUk7S0FDakIsTUFBTSxTQUFTLGNBQWMsSUFBSTtLQUNqQyxPQUNFLHdCQUFDLFVBQUQ7TUFFRSxlQUFlLGFBQWEsSUFBSSxFQUFFO01BQ2xDLFdBQVcsZ0dBQ1QsU0FDSSw2REFDQTtnQkFOUjtPQVNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7O09BQzNCLHdCQUFDLFFBQUQsWUFBTyxJQUFJLE1BQVk7Ozs7O09BQ3RCLE9BQU8sSUFBSSxVQUFVLFlBQVksSUFBSSxRQUFRLEtBQzVDLHdCQUFDLFFBQUQ7UUFBTSxXQUFXLDJEQUNmLElBQUksT0FBTyxZQUFZLHdEQUF3RDtrQkFFOUUsSUFBSTtPQUNEOzs7OztNQUVGO1FBakJELElBQUk7Ozs7WUFpQkg7SUFFWixDQUFDO0dBQ0U7Ozs7O0dBS0osY0FBYyxjQUNiLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7Ozs7UUFBQztRQUNqQixpQkFBaUIsVUFBVTtPQUN2RDs7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BRW5DOzs7O2NBQ0E7Ozs7O2VBQ0osc0JBQ0Msd0JBQUMsVUFBRDtNQUNFLGVBQWUsU0FBUyxZQUFZLGtCQUFrQixZQUFZLG1CQUFtQixTQUFTO01BQzlGLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxjQUFELEVBQWMsV0FBVSxVQUFXOzs7O2dCQUFDLHlCQUM5Qjs7Ozs7YUFFUDs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQsQ0FBMEUsNkJBQzlDLGdCQUFnQixNQUN4Qzs7Ozs7ZUFDSix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixnQkFBZ0IsS0FBSSxTQUFRO09BQzNCLE1BQU0sZUFBZSxLQUFLLHVCQUF1QixLQUFLLFlBQVksQ0FBQyxFQUFDLENBQUUsUUFBTyxNQUFLLEVBQUUsaUJBQWlCLFNBQVMsQ0FBQyxDQUFDO09BQ2hILE1BQU0sb0JBQW9CLEtBQUssMkJBQTJCLEtBQUssaUJBQWlCLENBQUMsRUFBQyxDQUFFO09BQ3BGLE9BQ0Usd0JBQUMsT0FBRDtRQUVFLFdBQVU7a0JBRlosQ0FJRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBb0MsS0FBSztTQUFXOzs7O21CQUNsRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBMEIsS0FBSyxhQUFhO1NBQStCOzs7O2lCQUNyRjs7OzttQkFDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDRyxhQUFZLFdBQ1Q7Ozs7O2lCQUNIOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQsYUFBTyxrQkFBaUIsNEJBQWdDOzs7O21CQUN4RCx3QkFBQyxVQUFEO1VBQ0UsZUFBZSxTQUFTLFlBQVksa0JBQWtCLFlBQVksS0FBSyxHQUFHLFNBQVM7VUFDbkYsV0FBVTtvQkFDWDtTQUVPOzs7O2lCQUNMOzs7OztnQkFDRjtVQXRCRSxLQUFLOzs7O2NBc0JQO01BRVQsQ0FBQztLQUNFOzs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUlOLGNBQWMsZUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDJCQUE0Qjs7OztnQkFBQyxzQ0FDbkQ7Ozs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQXlCO0tBRW5DOzs7O2FBQ0E7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF5QjtNQUFzQjs7OztnQkFDL0Qsd0JBQUMsUUFBRDtPQUFNLFdBQVcseURBQ2QsV0FBVyxZQUFZLFFBQVEsS0FDNUIsNkRBQ0E7aUJBSE4sQ0FLRyxXQUFXLFlBQVksS0FBSSxHQUN4Qjs7Ozs7Y0FDSDs7Ozs7YUFDRjs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLHlCQUEwQjs7Ozs7UUFBQztRQUNoQyxXQUFXLFdBQVcsVUFBVTtRQUFFO09BQ3BEOzs7OztnQkFDSCxXQUFXLFdBQVcsU0FBUyxJQUM5Qix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixVQUFVLFVBQVUsS0FBSyxNQUFNLFFBQzlCLHdCQUFDLE9BQUQ7UUFBZSxXQUFVO2tCQUF6QixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxVQUFEO1NBQVEsV0FBVTttQkFBd0IsS0FBSztRQUFlOzs7O2tCQUM5RCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBdUQsVUFBTyxLQUFLLFlBQW1COzs7OztnQkFDbkY7Ozs7a0JBQ0wsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXNHO1FBRWhIOzs7O2dCQUNIO1VBUks7Ozs7Y0FRTCxDQUNOO01BQ0U7Ozs7aUJBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQXNHO01BRWhIOzs7O2NBRUo7Ozs7O2VBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLHdCQUF5Qjs7Ozs7UUFBQztRQUNULFdBQVcsVUFBVSxVQUFVO1FBQUU7T0FDL0Q7Ozs7O2dCQUNILFdBQVcsVUFBVSxTQUFTLElBQzdCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLFVBQVUsU0FBUyxLQUFLLE1BQU0sUUFDN0Isd0JBQUMsT0FBRDtRQUFlLFdBQVU7a0JBQXpCLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO21CQUF3QixLQUFLO1FBQWU7Ozs7a0JBQzlELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUE2QyxlQUFZLEtBQUssYUFBYSxhQUFvQjs7Ozs7Z0JBQzVGOzs7O2tCQUNMLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFtRztRQUU3Rzs7OztnQkFDSDtVQVJLOzs7O2NBUUwsQ0FDTjtNQUNFOzs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFzRztNQUVoSDs7OztjQUVKOzs7OzthQUNGOzs7OztZQUNGOzs7Ozs7R0FJTixjQUFjLGFBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsdUJBQXdCOzs7O2dCQUFDLGlEQUM5Qzs7Ozs7ZUFDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBeUI7S0FFbkM7Ozs7YUFDQTs7Ozs7SUFDRjs7OztjQUVKLFlBQVksU0FBUyxJQUNwQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLFlBQVksS0FBSyxXQUNoQix3QkFBQyxPQUFEO01BRUUsV0FBVyxzR0FDVCxPQUFPLGNBQWMsYUFDakIsaURBQ0E7Z0JBTFIsQ0FRRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVcsdURBQ2YsT0FBTyxjQUFjLGFBQWEsOEJBQThCO29CQUUvRCxPQUFPO1NBQ0o7Ozs7O1NBQ04sd0JBQUMsVUFBRDtVQUFRLFdBQVU7b0JBQTBCLE9BQU87U0FBYTs7Ozs7U0FDaEUsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsSUFBSSxLQUFLLE9BQU8sU0FBUyxDQUFDLENBQUMsZUFBZTtTQUN2Qzs7Ozs7UUFDSDs7Ozs7aUJBQ0wsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQTBCLE9BQU87T0FBVzs7OztlQUN0RDs7Ozs7Z0JBRUwsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQWlILFlBQ3RHLE9BQU8sTUFDWjs7Ozs7Y0FDSDtRQXpCRSxPQUFPOzs7O1lBeUJULENBQ047SUFDRTs7OztlQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSxxQ0FBc0M7Ozs7O01BQzlELHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFtQztNQUEyQjs7Ozs7TUFDNUUsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BRW5DOzs7OztLQUNBOzs7OztZQUVKOzs7Ozs7R0FJTixjQUFjLFNBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OztnQkFBQywwQ0FDN0M7Ozs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQThCO0tBRXhDOzs7O2FBQ0E7Ozs7O2NBRUosU0FBUyxTQUFTLElBQ2pCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osU0FBUyxLQUFLLFFBQ2Isd0JBQUMsT0FBRDtNQUVFLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUFnSSxRQUN6SCxJQUFJLEVBQ0w7Ozs7OztRQUNOLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QyxJQUFJO1FBQVc7Ozs7O1FBQ3RFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiLENBQXNDLGVBQVksSUFBSSxhQUFhLGlCQUFxQjs7Ozs7O09BQ3JGOzs7OztnQkFFTCx3QkFBQyxVQUFEO09BQ0UsZUFBZSxrQkFBa0IsSUFBSSxJQUFJLElBQUksTUFBTTtPQUNuRCxXQUFVO2lCQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7OztpQkFBQyxnQkFDOUI7Ozs7O2NBQ0w7UUFqQkUsSUFBSTs7OztZQWlCTixDQUNOO0lBQ0U7Ozs7ZUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFpRztJQUUzRzs7OztZQUVKOzs7Ozs7R0FJTixjQUFjLFFBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OztnQkFBQyw0Q0FDN0M7Ozs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQThCO0tBRXhDOzs7O2FBQ0E7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQStFO1FBQWdCOzs7OztRQUMvRyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUM7UUFBaUM7Ozs7O1FBQ2xGLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QjtRQUVuQzs7Ozs7T0FDQTs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBdUU7UUFBaUI7Ozs7O1FBQ3hHLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFtQztRQUE4Qjs7Ozs7UUFDL0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlCO1FBRW5DOzs7OztPQUNBOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUE2RTtRQUFlOzs7OztRQUM1Ryx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUM7UUFBNEI7Ozs7O1FBQzdFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QjtRQUVuQzs7Ozs7T0FDQTs7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztFQUdKOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJSZXBvcnRlc1ZpZXcuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB1c2VTdG9yZSwgeyBmb3JtYXRFbGVtZW50VGl0bGVXaXRoSWQgfSBmcm9tICcuLi9zdG9yZS91c2VTdG9yZSc7XG5pbXBvcnQgeyBBUElfQkFTRV9VUkwgfSBmcm9tICcuLi91dGlscy9hcGknO1xuaW1wb3J0IHsgXG4gIEZpbGVUZXh0LCBcbiAgVHJlbmRpbmdVcCwgXG4gIFNoaWVsZEFsZXJ0LCBcbiAgQ2hlY2tDaXJjbGUyLCBcbiAgQWxlcnRUcmlhbmdsZSwgXG4gIERvd25sb2FkLCBcbiAgRXh0ZXJuYWxMaW5rLCBcbiAgQnVpbGRpbmcsIFxuICBMYXllcnMsIFxuICBaYXAsIFxuICBDcHUsIFxuICBBY3Rpdml0eSwgXG4gIEZpbGVDb2RlLCBcbiAgU3BhcmtsZXMsIFxuICBQcmludGVyLCBcbiAgUmVmcmVzaEN3LFxuICBTZWFyY2gsXG4gIEZpbHRlclxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZXBvcnRlc1ZpZXcoKSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgeyB1c2VyLCB0b2tlbiwgY29tcGFuaWVzIH0gPSB1c2VTdG9yZSgpO1xuXG4gIC8vIEZpbHRyYXIgZW1wcmVzYXMgc2kgZXMgQ0xJRU5UXG4gIGNvbnN0IGF2YWlsYWJsZUNvbXBhbmllcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmICh1c2VyPy5yb2xlID09PSAnQ0xJRU5UJykge1xuICAgICAgcmV0dXJuIGNvbXBhbmllcy5maWx0ZXIoYyA9PiBjLmlkID09PSB1c2VyLmNvbXBhbnlJZCk7XG4gICAgfVxuICAgIHJldHVybiBjb21wYW5pZXM7XG4gIH0sIFtjb21wYW5pZXMsIHVzZXJdKTtcblxuICBjb25zdCBbc2VsZWN0ZWRDb21wYW55SWQsIHNldFNlbGVjdGVkQ29tcGFueUlkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3NlbGVjdGVkUHJveWVjdG9JZCwgc2V0U2VsZWN0ZWRQcm95ZWN0b0lkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKCdpbmZvcm1lcycpOyAvLyAnaW5mb3JtZXMnIHwgJ2F1ZGl0b3JpYScgfCAnYWxhcm1hcycgfCAnZHhmJyB8ICdpYSdcbiAgY29uc3QgW2F1ZGl0RGF0YSwgc2V0QXVkaXREYXRhXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbYWxhcm1hc0RhdGEsIHNldEFsYXJtYXNEYXRhXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgW2xvYWRpbmdEYXRhLCBzZXRMb2FkaW5nRGF0YV0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gSW5pY2lhbGl6YXIgZW1wcmVzYSBzZWxlY2Npb25hZGFcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoYXZhaWxhYmxlQ29tcGFuaWVzLmxlbmd0aCA+IDAgJiYgIXNlbGVjdGVkQ29tcGFueUlkKSB7XG4gICAgICBzZXRTZWxlY3RlZENvbXBhbnlJZChhdmFpbGFibGVDb21wYW5pZXNbMF0uaWQpO1xuICAgIH1cbiAgfSwgW2F2YWlsYWJsZUNvbXBhbmllcywgc2VsZWN0ZWRDb21wYW55SWRdKTtcblxuICBjb25zdCBjdXJyZW50Q29tcGFueSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiBhdmFpbGFibGVDb21wYW5pZXMuZmluZChjID0+IGMuaWQgPT09IHNlbGVjdGVkQ29tcGFueUlkKSB8fCBhdmFpbGFibGVDb21wYW5pZXNbMF07XG4gIH0sIFthdmFpbGFibGVDb21wYW5pZXMsIHNlbGVjdGVkQ29tcGFueUlkXSk7XG5cbiAgY29uc3QgY3VycmVudFByb2plY3RzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIGN1cnJlbnRDb21wYW55Py5wcm95ZWN0b3MgfHwgW107XG4gIH0sIFtjdXJyZW50Q29tcGFueV0pO1xuXG4gIC8vIEluaWNpYWxpemFyIHByb3llY3RvIHNlbGVjY2lvbmFkb1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChjdXJyZW50UHJvamVjdHMubGVuZ3RoID4gMCAmJiAoIXNlbGVjdGVkUHJveWVjdG9JZCB8fCAhY3VycmVudFByb2plY3RzLmZpbmQocCA9PiBwLmlkID09PSBzZWxlY3RlZFByb3llY3RvSWQpKSkge1xuICAgICAgc2V0U2VsZWN0ZWRQcm95ZWN0b0lkKGN1cnJlbnRQcm9qZWN0c1swXS5pZCk7XG4gICAgfSBlbHNlIGlmIChjdXJyZW50UHJvamVjdHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBzZXRTZWxlY3RlZFByb3llY3RvSWQoJycpO1xuICAgIH1cbiAgfSwgW2N1cnJlbnRQcm9qZWN0cywgc2VsZWN0ZWRQcm95ZWN0b0lkXSk7XG5cbiAgY29uc3QgY3VycmVudFByb3llY3RvID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIGN1cnJlbnRQcm9qZWN0cy5maW5kKHAgPT4gcC5pZCA9PT0gc2VsZWN0ZWRQcm95ZWN0b0lkKTtcbiAgfSwgW2N1cnJlbnRQcm9qZWN0cywgc2VsZWN0ZWRQcm95ZWN0b0lkXSk7XG5cbiAgLy8gQ2FyZ2FyIGRhdG9zIGRlIGF1ZGl0b3LDrWEgeSBhbGFybWFzIGRlc2RlIGVsIGJhY2tlbmQgY3VhbmRvIGNhbWJpYSBlbCBwcm95ZWN0b1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWRQcm95ZWN0b0lkKSB7XG4gICAgICBzZXRBdWRpdERhdGEobnVsbCk7XG4gICAgICBzZXRBbGFybWFzRGF0YShbXSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgbGV0IGlzTW91bnRlZCA9IHRydWU7XG4gICAgc2V0TG9hZGluZ0RhdGEodHJ1ZSk7XG5cbiAgICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBoZWFkZXJzID0gdG9rZW4gPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9O1xuICAgICAgICBcbiAgICAgICAgLy8gMS4gQXVkaXRvcsOtYVxuICAgICAgICBjb25zdCByZXNBdWRpdCA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2F1ZGl0b3JpYS8ke3NlbGVjdGVkUHJveWVjdG9JZH1gLCB7IGhlYWRlcnMgfSk7XG4gICAgICAgIGlmIChyZXNBdWRpdC5vaykge1xuICAgICAgICAgIGNvbnN0IGF1ZGl0SnNvbiA9IGF3YWl0IHJlc0F1ZGl0Lmpzb24oKTtcbiAgICAgICAgICBpZiAoaXNNb3VudGVkKSBzZXRBdWRpdERhdGEoYXVkaXRKc29uKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIDIuIEFsYXJtYXNcbiAgICAgICAgY29uc3QgcmVzQWxhcm1hcyA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2FsYXJtYXMvcHJveWVjdG8vJHtzZWxlY3RlZFByb3llY3RvSWR9YCwgeyBoZWFkZXJzIH0pO1xuICAgICAgICBpZiAocmVzQWxhcm1hcy5vaykge1xuICAgICAgICAgIGNvbnN0IGFsYXJtYXNKc29uID0gYXdhaXQgcmVzQWxhcm1hcy5qc29uKCk7XG4gICAgICAgICAgaWYgKGlzTW91bnRlZCkgc2V0QWxhcm1hc0RhdGEoQXJyYXkuaXNBcnJheShhbGFybWFzSnNvbikgPyBhbGFybWFzSnNvbiA6IFtdKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGNhcmdhciBhdWRpdG9yw61hIHkgYWxhcm1hczonLCBlcnIpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgaWYgKGlzTW91bnRlZCkgc2V0TG9hZGluZ0RhdGEoZmFsc2UpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBmZXRjaERhdGEoKTtcbiAgICByZXR1cm4gKCkgPT4geyBpc01vdW50ZWQgPSBmYWxzZTsgfTtcbiAgfSwgW3NlbGVjdGVkUHJveWVjdG9JZCwgdG9rZW5dKTtcblxuICAvLyBDw6FsY3Vsb3MgbG9jYWxlcyBwYXJhIGVsIHByb3llY3RvIGFjdHVhbFxuICBjb25zdCBlbGVtZW50b3MgPSBjdXJyZW50UHJveWVjdG8/LmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgY3VycmVudFByb3llY3RvPy50YWJsZXJvcyB8fCBbXTtcbiAgY29uc3QgdGFibGVyb3MgPSBlbGVtZW50b3MuZmlsdGVyKGUgPT4gZS50aXBvRWxlbWVudG8gPT09ICdUQUJMRVJPJyk7XG4gIGNvbnN0IHRyYW5zZm9ybWFkb3JlcyA9IGVsZW1lbnRvcy5maWx0ZXIoZSA9PiBlLnRpcG9FbGVtZW50byA9PT0gJ1RSQU5TRk9STUFET1InKTtcbiAgY29uc3QgZ2VuZXJhZG9yZXMgPSBlbGVtZW50b3MuZmlsdGVyKGUgPT4gZS50aXBvRWxlbWVudG8gPT09ICdHRU5FUkFET1InKTtcbiAgY29uc3Qgc3ViZXN0YWNpb25lcyA9IGN1cnJlbnRQcm95ZWN0bz8uaW5zcGVjY2lvbmVzU3ViZXN0YWNpb24gfHwgY3VycmVudFByb3llY3RvPy5zdWJlc3RhY2lvbmVzIHx8IFtdO1xuXG4gIC8vIERlc2NhcmdhIGRlIERYRlxuICBjb25zdCBoYW5kbGVEb3dubG9hZERYRiA9IGFzeW5jICh0YWJsZXJvSWQsIHRhYmxlcm9Ob21icmUpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgYXV0aFRva2VuID0gdG9rZW4gfHwgdXNlU3RvcmUuZ2V0U3RhdGUoKS50b2tlbiB8fCBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKTtcbiAgICAgIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgICAgIC4uLihhdXRoVG9rZW4gPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke2F1dGhUb2tlbn1gIH0gOiB7fSlcbiAgICAgIH07XG5cbiAgICAgIC8vIDEuIEludGVudG8gcHJpbWFyaW8gdsOtYSBHRVQgcG9yIElEXG4gICAgICBsZXQgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvdGFibGVyb3MvJHt0YWJsZXJvSWR9L2R4ZmAsIHsgaGVhZGVycyB9KTtcblxuICAgICAgLy8gMi4gU2kgcmV0b3JuYSA0MDQsIGhhY2VyIGZhbGxiYWNrIGVudmlhbmRvIGxvcyBkYXRvcyBkZWwgdGFibGVybyBxdWUgeWEgZXN0w6FuIGVuIG1lbW9yaWEgbG9jYWxcbiAgICAgIGlmICghcmVzLm9rKSB7XG4gICAgICAgIGNvbnN0IGxvY2FsVGFibGVybyA9IHRhYmxlcm9zLmZpbmQodCA9PiB0LmlkID09PSB0YWJsZXJvSWQpO1xuICAgICAgICBpZiAobG9jYWxUYWJsZXJvKSB7XG4gICAgICAgICAgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvdGFibGVyb3MvZHhmL2V4cG9ydC1jdXN0b21gLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgICAgICAgLi4uaGVhZGVyc1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdGFibGVybzogbG9jYWxUYWJsZXJvIH0pXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKCFyZXMub2spIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFbCBzZXJ2aWRvciByZXNwb25kacOzIGNvbiBlc3RhZG8gJHtyZXMuc3RhdHVzfWApO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzLmJsb2IoKTtcbiAgICAgIGNvbnN0IHVybCA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgIGEuaHJlZiA9IHVybDtcbiAgICAgIGEuZG93bmxvYWQgPSBgdW5pZmlsYXJfJHsodGFibGVyb05vbWJyZSB8fCAndGFibGVybycpLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvW15hLXpBLVowLTlfLV0vZywgJ18nKX0uZHhmYDtcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoYSk7XG4gICAgICBhLmNsaWNrKCk7XG4gICAgICBhLnJlbW92ZSgpO1xuICAgICAgd2luZG93LlVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGRlc2NhcmdhciBEWEY6JywgZXJyKTtcbiAgICAgIGFsZXJ0KGBObyBzZSBwdWRvIGRlc2NhcmdhciBlbCBhcmNoaXZvIERYRjogJHtlcnIubWVzc2FnZX1gKTtcbiAgICB9XG4gIH07XG5cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTEwMCBwLTQgbWQ6cC04IHNwYWNlLXktOCBtYXgtdy03eGwgbXgtYXV0b1wiPlxuICAgICAgXG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBtZDppdGVtcy1jZW50ZXIgZ2FwLTQgcGItNiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcm91bmRlZC0yeGwgdGV4dC1hbWJlci00MDBcIj5cbiAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIG1kOnRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS0xMDAgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgICBDZW50cm8gZGUgUmVwb3J0ZXMgeSBBdWRpdG9yw61hIEVsw6ljdHJpY2FcbiAgICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIEluZm9ybWVzIHTDqWNuaWNvcyBjb21waWxhZG9zLCBhdWRpdG9yw61hIGRlIHJlZCwgYmFsYW5jZSBkZSBjYXJnYXMgeSBleHBvcnRhY2nDs24gQ0FEXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogU2VsZWN0b3JlcyBkZSBFbXByZXNhIHkgUHJveWVjdG8gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0zIHctZnVsbCBtZDp3LWF1dG9cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTEuNSByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICA8QnVpbGRpbmcgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMCBtbC0yXCIgLz5cbiAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ29tcGFueUlkfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZENvbXBhbnlJZChlLnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQcm95ZWN0b0lkKCcnKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctdHJhbnNwYXJlbnQgdGV4dC14cyB0ZXh0LXNsYXRlLTIwMCBmb250LWJvbGQgb3V0bGluZS1ub25lIHByLTMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7YXZhaWxhYmxlQ29tcGFuaWVzLm1hcChjID0+IChcbiAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Yy5pZH0gdmFsdWU9e2MuaWR9IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAge2Mubm9tYnJlfVxuICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcC0xLjUgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgPExheWVycyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwIG1sLTJcIiAvPlxuICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRQcm95ZWN0b0lkfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkUHJveWVjdG9JZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXRyYW5zcGFyZW50IHRleHQteHMgdGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIG91dGxpbmUtbm9uZSBwci0zIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRQcm9qZWN0cy5sZW5ndGggPT09IDB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtjdXJyZW50UHJvamVjdHMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS00MDBcIj5TaW4gcHJveWVjdG9zIHJlZ2lzdHJhZG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgY3VycmVudFByb2plY3RzLm1hcChwID0+IChcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0gY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtwLm5vbWJyZX1cbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFRhcmpldGFzIEtQSSBkZSBFc3RhZG8gZGUgUmVkICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy01IGdhcC00XCI+XG4gICAgICAgIHsvKiBTYWx1ZCBkZSBSZWQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPEFjdGl2aXR5IGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNDAwXCIgLz4gU2FsdWQgZGUgUmVkXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC0yeGwgZm9udC1ibGFjayAke1xuICAgICAgICAgICAgICAoYXVkaXREYXRhPy5zYWx1ZFJlZCB8fCAxMDApID49IDgwID8gJ3RleHQtZW1lcmFsZC00MDAnIDogKGF1ZGl0RGF0YT8uc2FsdWRSZWQgfHwgMTAwKSA+PSA1MCA/ICd0ZXh0LWFtYmVyLTQwMCcgOiAndGV4dC1yZWQtNDAwJ1xuICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICB7bG9hZGluZ0RhdGEgPyAnLi4uJyA6IGAke2F1ZGl0RGF0YT8uc2FsdWRSZWQgPz8gMTAwfSVgfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAge2F1ZGl0RGF0YT8uc2FsdWRSZWQgPj0gODAgPyAnUmVkIGVuIGVzdGFkbyDDs3B0aW1vJyA6ICdSZXF1aWVyZSBhdGVuY2nDs24nfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCByb3VuZGVkLWZ1bGwgaC0xLjUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwICR7XG4gICAgICAgICAgICAgICAgKGF1ZGl0RGF0YT8uc2FsdWRSZWQgfHwgMTAwKSA+PSA4MCA/ICdiZy1lbWVyYWxkLTUwMCcgOiAoYXVkaXREYXRhPy5zYWx1ZFJlZCB8fCAxMDApID49IDUwID8gJ2JnLWFtYmVyLTUwMCcgOiAnYmctcmVkLTUwMCdcbiAgICAgICAgICAgICAgfWB9IFxuICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7YXVkaXREYXRhPy5zYWx1ZFJlZCA/PyAxMDB9JWAgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBUYWJsZXJvcyBBY3Rpdm9zICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ibHVlLTQwMFwiIC8+IFRhYmxlcm9zXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTEwMFwiPnt0YWJsZXJvcy5sZW5ndGh9PC9zcGFuPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5UYWJsZXJvcyBlbMOpY3RyaWNvcyByZWdpc3RyYWRvczwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPkNhcGEgMSAvIERpYWdyYW1hczwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFRyYW5zZm9ybWFkb3JlcyAmIEdlbmVyYWRvcmVzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxDcHUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1wdXJwbGUtNDAwXCIgLz4gUG90ZW5jaWEgLyBTdW1pbmlzdHJvXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTEwMFwiPnt0cmFuc2Zvcm1hZG9yZXMubGVuZ3RoICsgZ2VuZXJhZG9yZXMubGVuZ3RofTwvc3Bhbj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwXCI+e3RyYW5zZm9ybWFkb3Jlcy5sZW5ndGh9IFRyYWZvcyAvIHtnZW5lcmFkb3Jlcy5sZW5ndGh9IEdlbjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPlN1YmVzdGFjacOzbiAvIEFjb21ldGlkYTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFN1YmVzdGFjaW9uZXMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPEJ1aWxkaW5nIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNDAwXCIgLz4gU3ViZXN0YWNpb25lc1xuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS0xMDBcIj57c3ViZXN0YWNpb25lcy5sZW5ndGh9PC9zcGFuPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5JbnNwZWNjaW9uZXMgZsOtc2ljYXM8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj5JbmZyYWVzdHJ1Y3R1cmE8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBBbGFybWFzIEVsw6ljdHJpY2FzIEFjdGl2YXMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtcmVkLTQwMFwiIC8+IEFsYXJtYXMgQWN0aXZhc1xuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtMnhsIGZvbnQtYmxhY2sgJHthbGFybWFzRGF0YS5sZW5ndGggPiAwID8gJ3RleHQtcmVkLTQwMCcgOiAndGV4dC1zbGF0ZS0xMDAnfWB9PlxuICAgICAgICAgICAgICB7YWxhcm1hc0RhdGEubGVuZ3RofVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAge2FsYXJtYXNEYXRhLmxlbmd0aCA+IDAgPyAnRGVzYmFsYW5jZXMgbyBzb2JyZWNhcmdhcycgOiAnU2luIGFub21hbMOtYXMgY3LDrXRpY2FzJ31cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPkNhcGEgOCAvIEFsZXJ0YXM8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBUYWJzIGRlIE5hdmVnYWNpw7NuIGRlIFJlcG9ydGVzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZ2FwLTIgb3ZlcmZsb3cteC1hdXRvIHRleHQteHMgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICB7W1xuICAgICAgICAgIHsgaWQ6ICdpbmZvcm1lcycsIGxhYmVsOiAnSW5mb3JtZXMgVMOpY25pY29zIFBERicsIGljb246IEZpbGVUZXh0LCBjb3VudDogY3VycmVudFByb2plY3RzLmxlbmd0aCB9LFxuICAgICAgICAgIHsgaWQ6ICdhdWRpdG9yaWEnLCBsYWJlbDogJ0F1ZGl0b3LDrWEgZGUgUmVkJywgaWNvbjogQ2hlY2tDaXJjbGUyLCBjb3VudDogYXVkaXREYXRhPy50b3RhbEluY29uc2lzdGVuY2lhcyB8fCAwIH0sXG4gICAgICAgICAgeyBpZDogJ2FsYXJtYXMnLCBsYWJlbDogJ0FsYXJtYXMgeSBEZXNiYWxhbmNlJywgaWNvbjogQWxlcnRUcmlhbmdsZSwgY291bnQ6IGFsYXJtYXNEYXRhLmxlbmd0aCB9LFxuICAgICAgICAgIHsgaWQ6ICdkeGYnLCBsYWJlbDogJ1BsYW5vcyBBdXRvQ0FEIChEWEYpJywgaWNvbjogRmlsZUNvZGUsIGNvdW50OiB0YWJsZXJvcy5sZW5ndGggfSxcbiAgICAgICAgICB7IGlkOiAnaWEnLCBsYWJlbDogJ0FuYWzDrXRpY2FzIElBIChGdXR1cm8pJywgaWNvbjogU3BhcmtsZXMgfVxuICAgICAgICBdLm1hcCh0YWIgPT4ge1xuICAgICAgICAgIGNvbnN0IEljb24gPSB0YWIuaWNvbjtcbiAgICAgICAgICBjb25zdCBhY3RpdmUgPSBhY3RpdmVUYWIgPT09IHRhYi5pZDtcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e3RhYi5pZH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKHRhYi5pZCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTMgcHgtNCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXItYi0yIHRyYW5zaXRpb24tYWxsIHdoaXRlc3BhY2Utbm93cmFwIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgYWN0aXZlIFxuICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWFtYmVyLTUwMCB0ZXh0LWFtYmVyLTQwMCBmb250LWJvbGQgYmctYW1iZXItNTAwLzUnIFxuICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+e3RhYi5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgIHt0eXBlb2YgdGFiLmNvdW50ID09PSAnbnVtYmVyJyAmJiB0YWIuY291bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BtbC0xLjUgcHgtMS41IHB5LTAuMiByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkICR7XG4gICAgICAgICAgICAgICAgICB0YWIuaWQgPT09ICdhbGFybWFzJyA/ICdiZy1yZWQtNTAwLzIwIHRleHQtcmVkLTQwMCBib3JkZXIgYm9yZGVyLXJlZC01MDAvMzAnIDogJ2JnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCdcbiAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICB7dGFiLmNvdW50fVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICk7XG4gICAgICAgIH0pfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBDT05URU5JRE8gREUgUEVTVEHDkUFTICovfVxuXG4gICAgICB7LyogUEVTVEHDkUEgMTogSU5GT1JNRVMgVMOJQ05JQ09TIFBERiBDT01QSUxBRE9TICovfVxuICAgICAge2FjdGl2ZVRhYiA9PT0gJ2luZm9ybWVzJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC02IGZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1kOml0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8RmlsZVRleHQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgSW5mb3JtZSBUw6ljbmljbyBDb21waWxhZG8gZGUge2N1cnJlbnRQcm95ZWN0bz8ubm9tYnJlIHx8ICdQcm95ZWN0byd9XG4gICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICBHZW5lcmEgZWwgZG9jdW1lbnRvIGNvbnNvbGlkYWRvIG9maWNpYWwgY29uIHBvcnRhZGEgZWplY3V0aXZhLCBkaWFncmFtYXMgdW5pZmlsYXJlcywgZmljaGFzIGRlIGVxdWlwb3MgeSBjdWFkcm8gZGUgcmVjb21lbmRhY2lvbmVzIHNlZ8O6biBub3JtYSBDRU4uXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge3NlbGVjdGVkUHJveWVjdG9JZCAmJiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2VtcHJlc2EvJHtzZWxlY3RlZENvbXBhbnlJZH0vcHJveWVjdG8vJHtzZWxlY3RlZFByb3llY3RvSWR9L2luZm9ybWVgKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1hbGwgc2hhZG93LW1kIGFjdGl2ZTpzY2FsZS05NSBzaHJpbmstMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBBYnJpciBJbmZvcm1lIENvbXBsZXRvXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBMaXN0YSBkZSB0b2RvcyBsb3MgcHJveWVjdG9zIGRlIGxhIGVtcHJlc2EgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgUHJveWVjdG9zIERpc3BvbmlibGVzIGVuIHtjdXJyZW50Q29tcGFueT8ubm9tYnJlfVxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgICAgICB7Y3VycmVudFByb2plY3RzLm1hcChwcm9qID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBudW1UYWJsZXJvcyA9IChwcm9qLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgcHJvai50YWJsZXJvcyB8fCBbXSkuZmlsdGVyKGUgPT4gZS50aXBvRWxlbWVudG8gPT09ICdUQUJMRVJPJykubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGNvbnN0IG51bVN1YmVzdGFjaW9uZXMgPSAocHJvai5pbnNwZWNjaW9uZXNTdWJlc3RhY2lvbiB8fCBwcm9qLnN1YmVzdGFjaW9uZXMgfHwgW10pLmxlbmd0aDtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgICAgICAga2V5PXtwcm9qLmlkfSBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwLzQwIHRyYW5zaXRpb24tYWxsIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXktNFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtc2xhdGUtMjAwXCI+e3Byb2oubm9tYnJlfTwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+e3Byb2ouZGlyZWNjaW9uIHx8ICdVYmljYWNpw7NuIG5vIGVzcGVjaWZpY2FkYSd9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtWzEwcHhdIGZvbnQtbW9ubyB0ZXh0LWFtYmVyLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge251bVRhYmxlcm9zfSBUYWJsZXJvc1xuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57bnVtU3ViZXN0YWNpb25lc30gU3ViZXN0YWNpb25lcyByZWdpc3RyYWRhczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2VtcHJlc2EvJHtzZWxlY3RlZENvbXBhbnlJZH0vcHJveWVjdG8vJHtwcm9qLmlkfS9pbmZvcm1lYCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTQwMCBob3Zlcjp0ZXh0LWFtYmVyLTMwMCBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIFZlciBJbmZvcm1lIFBERiDihpJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBQRVNUQcORQSAyOiBBVURJVE9Sw41BIERFIFJFRCAoQ0FQQSA1KSAqL31cbiAgICAgIHthY3RpdmVUYWIgPT09ICdhdWRpdG9yaWEnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMFwiIC8+IERpYWduw7NzdGljbyBkZSBJbnRlZ3JpZGFkIEVsw6ljdHJpY2FcbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIERldGVjY2nDs24gYXV0b23DoXRpY2EgZGUgaW5jb25zaXN0ZW5jaWFzIGplcsOhcnF1aWNhcywgZWxlbWVudG9zIGh1w6lyZmFub3MgeSB0YWJsZXJvcyBzaW4gY2FyZ2EuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+w41uZGljZSBkZSBTYWx1ZDo8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtYmFzZSBmb250LWJsYWNrIHB4LTIuNSBweS0wLjUgcm91bmRlZC1sZyBib3JkZXIgJHtcbiAgICAgICAgICAgICAgICAoYXVkaXREYXRhPy5zYWx1ZFJlZCB8fCAxMDApID49IDgwIFxuICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvMTAgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC00MDAnIFxuICAgICAgICAgICAgICAgICAgOiAnYmctYW1iZXItNTAwLzEwIGJvcmRlci1hbWJlci01MDAvMzAgdGV4dC1hbWJlci00MDAnXG4gICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICB7YXVkaXREYXRhPy5zYWx1ZFJlZCA/PyAxMDB9JVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxuICAgICAgICAgICAgey8qIEVxdWlwb3MgSHXDqXJmYW5vcyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICBFcXVpcG9zIEh1w6lyZmFub3MgKHthdWRpdERhdGE/Lmh1ZXJmYW5vcz8ubGVuZ3RoIHx8IDB9KVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICB7YXVkaXREYXRhPy5odWVyZmFub3M/Lmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgIHthdWRpdERhdGEuaHVlcmZhbm9zLm1hcCgoaXRlbSwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIGJsb2NrXCI+e2l0ZW0ubm9tYnJlfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1tb25vXCI+VGlwbzoge2l0ZW0udGlwb0VsZW1lbnRvfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgdGV4dC1hbWJlci00MDAgcm91bmRlZCB0ZXh0LVsxMHB4XSBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFNpbiBjb25leGnDs25cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvNjAgdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBpdGFsaWNcIj5cbiAgICAgICAgICAgICAgICAgIOKckyBObyBzZSBkZXRlY3Rhcm9uIGVxdWlwb3MgaHXDqXJmYW5vcyBlbiBsYSByZWQgamVyw6FycXVpY2EuXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFRhYmxlcm9zIFNpbiBDYXJnYSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgVGFibGVyb3MgU2luIENhcmdhIFJlZ2lzdHJhZGEgKHthdWRpdERhdGE/LnNpbkNhcmdhPy5sZW5ndGggfHwgMH0pXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIHthdWRpdERhdGE/LnNpbkNhcmdhPy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICB7YXVkaXREYXRhLnNpbkNhcmdhLm1hcCgoaXRlbSwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIGJsb2NrXCI+e2l0ZW0ubm9tYnJlfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5VYmljYWNpw7NuOiB7aXRlbS51YmljYWNpb24gfHwgJ05vIGRlZmluaWRhJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgYmctYmx1ZS01MDAvMTAgYm9yZGVyIGJvcmRlci1ibHVlLTUwMC8zMCB0ZXh0LWJsdWUtNDAwIHJvdW5kZWQgdGV4dC1bMTBweF0gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAwIFZBIC8gU2luIENpcmN1aXRvc1xuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MC80MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC82MCB0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGl0YWxpY1wiPlxuICAgICAgICAgICAgICAgICAg4pyTIFRvZG9zIGxvcyB0YWJsZXJvcyB0aWVuZW4gY2lyY3VpdG9zIG8gY2FyZ2FzIG9wZXJhdGl2YXMuXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogUEVTVEHDkUEgMzogQUxBUk1BUyBZIERFU0JBTEFOQ0UgKENBUEFTIDQgWSA4KSAqL31cbiAgICAgIHthY3RpdmVUYWIgPT09ICdhbGFybWFzJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0yeGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yZWQtNDAwXCIgLz4gUmVnaXN0cm8gZGUgQW5vbWFsw61hcyB5IERlc2JhbGFuY2VzIEVsw6ljdHJpY29zXG4gICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICBNb25pdG9yZW8gY29udGludW8gZGUgZGVzYmFsYW5jZXMgZGUgZmFzZSAmZ3Q7IDE1JSB5IHNvYnJlY2FyZ2FzIGVuIGludGVycnVwdG9yZXMgcHJpbmNpcGFsZXMuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge2FsYXJtYXNEYXRhLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICB7YWxhcm1hc0RhdGEubWFwKChhbGFybWEpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgICAga2V5PXthbGFybWEuaWR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTQgcm91bmRlZC0yeGwgYm9yZGVyIGZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1kOml0ZW1zLWNlbnRlciBnYXAtMyAke1xuICAgICAgICAgICAgICAgICAgICBhbGFybWEuc2V2ZXJpZGFkID09PSAnQ1JJVElDQUwnIFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXJlZC05NTAvMjAgYm9yZGVyLXJlZC04MDAvNDAgdGV4dC1yZWQtMzAwJyBcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1hbWJlci05NTAvMjAgYm9yZGVyLWFtYmVyLTgwMC80MCB0ZXh0LWFtYmVyLTMwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzlweF0gZm9udC1ibGFjayB1cHBlcmNhc2UgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsYXJtYS5zZXZlcmlkYWQgPT09ICdDUklUSUNBTCcgPyAnYmctcmVkLTUwMCB0ZXh0LXNsYXRlLTk1MCcgOiAnYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHthbGFybWEuc2V2ZXJpZGFkfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0xMDBcIj57YWxhcm1hLnRpcG99PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoYWxhcm1hLmNyZWF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwXCI+e2FsYXJtYS5tZW5zYWplfTwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgcm91bmRlZC14bCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIEVzdGFkbzoge2FsYXJtYS5lc3RhZG99XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LWNlbnRlciBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgdGV4dC1lbWVyYWxkLTQwMCBteC1hdXRvXCIgLz5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwXCI+UmVkIGVuIFBlcmZlY3RvIEJhbGFuY2U8L2g0PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgTm8gc2UgZGV0ZWN0YXJvbiBhbGFybWFzIGNyw610aWNhcyBuaSBkZXNiYWxhbmNlcyBtYXlvcmVzIGFsIDE1JSBlbiBsb3MgdGFibGVyb3MgZGVsIHByb3llY3RvLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBQRVNUQcORQSA0OiBQTEFOT1MgQVVUT0NBRCBEWEYgKENBUEEgMykgKi99XG4gICAgICB7YWN0aXZlVGFiID09PSAnZHhmJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0yeGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPEZpbGVDb2RlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPiBFeHBvcnRhY2nDs24gVmVjdG9yaWFsIERYRiAoQXV0b0NBRCBSMTIpXG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgIERlc2NhcmdhIGxvcyBkaWFncmFtYXMgdW5pZmlsYXJlcyBpbmRpdmlkdWFsZXMgZGUgY2FkYSB0YWJsZXJvIGxpc3RvcyBwYXJhIGVkaXRhciBlbiBBdXRvQ0FELCBMaWJyZUNBRCBvIFpXQ0FELlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge3RhYmxlcm9zLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAgICAgICAge3RhYmxlcm9zLm1hcCgodGFiKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgICAgIGtleT17dGFiLmlkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwLzQwIHRyYW5zaXRpb24tYWxsIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXktNFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcHgtMiBweS0wLjUgcm91bmRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIElEOiB7dGFiLmlkfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTIwMCBtdC0yXCI+e3RhYi5ub21icmV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlViaWNhY2nDs246IHt0YWIudWJpY2FjaW9uIHx8ICdTaW4gZXNwZWNpZmljYXInfTwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURvd25sb2FkRFhGKHRhYi5pZCwgdGFiLm5vbWJyZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1hbWJlci01MDAgaG92ZXI6dGV4dC1zbGF0ZS05NTAgdGV4dC1zbGF0ZS0yMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIGZvbnQtYm9sZCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IERlc2NhcmdhciBEWEZcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBpdGFsaWNcIj5cbiAgICAgICAgICAgICAgTm8gaGF5IHRhYmxlcm9zIGVsw6ljdHJpY29zIHJlZ2lzdHJhZG9zIGVuIGVzdGUgcHJveWVjdG8gcGFyYSBleHBvcnRhci5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFBFU1RBw5FBIDU6IEFOQUzDjVRJQ0FTIElBIEZVVFVSQVMgKi99XG4gICAgICB7YWN0aXZlVGFiID09PSAnaWEnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+IEFuYWzDrXRpY2FzIFByZWRpY3RpdmFzIHkgTWFjaGluZSBMZWFybmluZ1xuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxuICAgICAgICAgICAgICBQcsOzeGltYXMgaW50ZWdyYWNpb25lcyBlbiBkZXNhcnJvbGxvIHBhcmEgbWFudGVuaW1pZW50byBwcmV2ZW50aXZvIHkgb3B0aW1pemFjacOzbiBkZSByZWRlcyBlbMOpY3RyaWNhczpcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0yeGwgYmctc2xhdGUtOTUwLzYwIGJvcmRlciBib3JkZXItZW1lcmFsZC05MDAvNDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQgYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTQwMCB0ZXh0LVsxMHB4XSBmb250LWJvbGRcIj5QcmVkaWN0aXZvPC9zcGFuPlxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc20gdGV4dC1zbGF0ZS0yMDBcIj5BbsOhbGlzaXMgUHJlZGljdGl2byBkZSBGYWxsYXM8L2g0PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgQ8OhbGN1bG8gZGUgcHJvYmFiaWxpZGFkIGRlIGRpc3Bhcm8gZGUgaW50ZXJydXB0b3JlcyBiYWpvIGNvbmRpY2lvbmVzIGRlIGNhcmdhIG3DoXhpbWEgc29zdGVuaWRhLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0yeGwgYmctc2xhdGUtOTUwLzYwIGJvcmRlciBib3JkZXItc2t5LTkwMC80MCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZCBiZy1za3ktNTAwLzIwIHRleHQtc2t5LTQwMCB0ZXh0LVsxMHB4XSBmb250LWJvbGRcIj5UZXJtb2dyYWbDrWE8L3NwYW4+XG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTIwMFwiPkV2b2x1Y2nDs24gVMOpcm1pY2EgVGVtcG9yYWw8L2g0PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgSGlzdG9ncmFtYXMgZGUgdmFyaWFjacOzbiBkZSB0ZW1wZXJhdHVyYSBlbiBib3JuZXMgZGUgY29uZXhpw7NuIHBhcmEgZGV0ZWN0YXIgZmFsc29zIGNvbnRhY3Rvcy5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MC82MCBib3JkZXIgYm9yZGVyLXB1cnBsZS05MDAvNDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQgYmctcHVycGxlLTUwMC8yMCB0ZXh0LXB1cnBsZS00MDAgdGV4dC1bMTBweF0gZm9udC1ib2xkXCI+Tm9ybWF0aXZhPC9zcGFuPlxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc20gdGV4dC1zbGF0ZS0yMDBcIj5BdWRpdG9yw61hIEF1dG9tw6F0aWNhIENFTjwvaDQ+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICBWZXJpZmljYWNpw7NuIGRlIGNhbGlicmVzIGRlIGNvbmR1Y3RvcmVzIHkgZGlzdGFuY2lhcyBkZSBzZWd1cmlkYWQgc2Vnw7puIEPDs2RpZ28gRWzDqWN0cmljbyBOYWNpb25hbC5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgIDwvZGl2PlxuICApO1xufVxuIl19