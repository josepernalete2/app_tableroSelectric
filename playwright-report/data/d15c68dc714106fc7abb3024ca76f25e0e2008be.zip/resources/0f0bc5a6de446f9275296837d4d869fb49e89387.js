import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FichaTecnicaComponent.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport10_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { Save, Edit3, Camera, Printer, Settings, Zap, RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
import ModalEdicionCircuito from "/src/components/ModalEdicionCircuito.jsx?t=1790793566895";
import SelectorAlimentadorJerarquico from "/src/components/SelectorAlimentadorJerarquico.jsx?t=1790792337841";
import TransferComponent from "/src/components/TransferComponent.jsx?t=1790793572890";
import MetrologiaElectricaSection from "/src/components/MetrologiaElectricaSection.jsx";
import DualPhotoUploader from "/src/components/DualPhotoUploader.jsx?t=1790793566895";
import { TENSIONES_COVENIN_159_BT, TENSIONES_COVENIN_159_MT, TENSIONES_COVENIN_TODAS } from "/src/utils/constants.js";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/FichaTecnicaComponent.jsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
// Componente para renderizar Blobs de imagen de forma segura
const SafeImage = ({ blob, src, alt, className }) => {
	_s();
	const [objectUrl, setObjectUrl] = useState(null);
	useEffect(() => {
		if (blob) {
			const url = URL.createObjectURL(blob);
			setObjectUrl(url);
			return () => {
				URL.revokeObjectURL(url);
			};
		} else {
			setObjectUrl(null);
		}
	}, [blob]);
	const finalSrc = objectUrl || src;
	if (!finalSrc) return null;
	return /* @__PURE__ */ _jsxDEV("img", {
		src: finalSrc,
		alt,
		className
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 10
	}, this);
};
_s(SafeImage, "Q4ugJUn5miWrvY9z1+S4+H7NbYg=");
_c = SafeImage;
export default function FichaTecnicaComponent({ elementoData, onUpdate, readOnly }) {
	_s2();
	const [isEditing, setIsEditing] = useState(false);
	const { alert: customAlert, confirm: customConfirm } = useConfirm();
	const companies = useStore((state) => state.companies || []);
	const allFeeders = React.useMemo(() => {
		const list = [];
		const compId = elementoData?.empresaId || elementoData?.companyId;
		const company = companies.find((c) => c.id === compId);
		if (!company) {
			companies.forEach((c) => {
				if (c.elementosUnifilares) {
					list.push(...c.elementosUnifilares);
				}
				if (c.proyectos) {
					c.proyectos.forEach((p) => {
						const elList = p.elementosUnifilares || p.tableros || [];
						list.push(...elList);
					});
				}
			});
			return list.filter((e) => e.id !== elementoData?.id);
		}
		if (company.elementosUnifilares) {
			list.push(...company.elementosUnifilares);
		}
		if (company.proyectos) {
			company.proyectos.forEach((p) => {
				const elList = p.elementosUnifilares || p.tableros || [];
				list.push(...elList);
			});
		}
		return list.filter((e) => e.id !== elementoData?.id);
	}, [companies, elementoData]);
	// Campos principales
	const [nombre, setNombre] = useState(elementoData?.nombre || "");
	const [ubicacion, setUbicacion] = useState(elementoData?.ubicacion || "");
	const [alimentadoPor, setAlimentadoPor] = useState(elementoData?.alimentadoPor || "");
	const [observacionesGenerales, setObservacionesGenerales] = useState(elementoData?.observacionesGenerales || "");
	const [fotoBlob, setFotoBlob] = useState(elementoData?.fotoBlob || null);
	const [fotoSrc, setFotoSrc] = useState(elementoData?.foto || null);
	const [previewUrl, setPreviewUrl] = useState(null);
	// datosTecnicos JSON
	const [dt, setDt] = useState(elementoData?.datosTecnicos || {});
	// Wizard Modal Jerarquía
	const { crearElementoProvisional } = useStore();
	const [modalJerarquiaOpen, setModalJerarquiaOpen] = useState(false);
	const [circuitDataWizard, setCircuitDataWizard] = useState(null);
	const [wizardModo, setWizardModo] = useState("SALIDA");
	// Restringir a las opciones permitidas: TABLERO, TRANSFER, GENERADOR, TRANSFORMADOR
	const tipoElemento = elementoData?.tipoElemento || "TABLERO";
	if (!elementoData) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center p-8 text-slate-400 font-sans",
			children: "No hay datos del elemento seleccionados."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 104,
			columnNumber: 12
		}, this);
	}
	const handleDtChange = (key, value) => {
		if (readOnly) return;
		setDt((prev) => ({
			...prev,
			[key]: value
		}));
	};
	const handleNestedDtChange = (parentKey, key, value) => {
		if (readOnly) return;
		setDt((prev) => ({
			...prev,
			[parentKey]: {
				...prev[parentKey] || {},
				[key]: value
			}
		}));
	};
	const handleSptChange = (key, value) => {
		if (readOnly) return;
		setDt((prev) => ({
			...prev,
			spt: {
				...prev.spt || {},
				[key]: value
			}
		}));
	};
	const handleAcometidaChange = (seccion, key, value) => {
		if (readOnly) return;
		setDt((prev) => ({
			...prev,
			acometidas: {
				...prev.acometidas || {},
				[seccion]: {
					...prev.acometidas && prev.acometidas[seccion] || {},
					[key]: value
				}
			}
		}));
	};
	const handleImageChange = (e) => {
		if (readOnly) return;
		const file = e.target.files[0];
		if (!file) return;
		if (file.size > 10 * 1024 * 1024) {
			customAlert("La imagen es demasiado grande. Por favor elija una de menos de 10MB.");
			return;
		}
		setFotoBlob(file);
		if (previewUrl) URL.revokeObjectURL(previewUrl);
		setPreviewUrl(URL.createObjectURL(file));
	};
	const handleSave = (e) => {
		e.preventDefault();
		if (readOnly) return;
		if (onUpdate) {
			onUpdate({
				...elementoData,
				nombre,
				ubicacion,
				alimentadoPor,
				observacionesGenerales,
				fotoBlob,
				foto: fotoSrc,
				datosTecnicos: dt
			});
		}
		setIsEditing(false);
	};
	const handleLimpiarFormulario = async () => {
		if (readOnly) return;
		const confirmed = await customConfirm("¿Deseas reiniciar todos los campos técnicos de este elemento a blanco?");
		if (!confirmed) return;
		setNombre("");
		setUbicacion("");
		setAlimentadoPor("");
		setObservacionesGenerales("");
		setDt({});
		setFotoBlob(null);
		setFotoSrc(null);
		if (previewUrl) URL.revokeObjectURL(previewUrl);
		setPreviewUrl(null);
	};
	const renderElementWithId = (nombreText, fallbackId) => {
		if (!nombreText) return /* @__PURE__ */ _jsxDEV("span", {
			className: "opacity-40",
			children: "—"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 195,
			columnNumber: 29
		}, this);
		let cleanName = nombreText;
		let elementId = fallbackId || null;
		const match = String(nombreText).match(/^(.*?)(?:\s*\((?:ID:\s*)?([A-Z0-9_-]+)\))?$/i);
		if (match) {
			if (match[1]) cleanName = match[1].trim();
			if (match[2] && !elementId) elementId = match[2].trim();
		}
		return /* @__PURE__ */ _jsxDEV("span", {
			className: "inline-flex items-center gap-1.5 flex-wrap",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "font-semibold text-slate-100 print:text-black",
				children: cleanName
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 207,
				columnNumber: 9
			}, this), elementId && /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center font-mono font-bold text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/30 px-1.5 py-0.5 rounded shadow-sm",
				children: ["ID: ", elementId]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 209,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 206,
			columnNumber: 7
		}, this);
	};
	const renderBadge = () => {
		switch (tipoElemento) {
			case "TRANSFORMADOR": return /* @__PURE__ */ _jsxDEV("span", {
				className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-xs font-bold font-mono",
				children: "⚡ TRANSFORMADOR ELÉCTRICO"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 220,
				columnNumber: 16
			}, this);
			case "GENERADOR": return /* @__PURE__ */ _jsxDEV("span", {
				className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-xs font-bold font-mono",
				children: "⚡ GENERADOR"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 222,
				columnNumber: 16
			}, this);
			case "TRANSFER": return /* @__PURE__ */ _jsxDEV("span", {
				className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-xs font-bold font-mono",
				children: "🔄 TRANSFERENCIA (ATS / MTS)"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 224,
				columnNumber: 16
			}, this);
			case "BANCO_CONDENSADOR": return /* @__PURE__ */ _jsxDEV("span", {
				className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-xs font-bold font-mono",
				children: "⚡ BANCO DE CONDENSADORES"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 226,
				columnNumber: 16
			}, this);
			case "PUESTA_TIERRA": return /* @__PURE__ */ _jsxDEV("span", {
				className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-xs font-bold font-mono",
				children: "🛡️ MALLA PUESTA A TIERRA"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 228,
				columnNumber: 16
			}, this);
			case "PUNTO_SUMINISTRO": return /* @__PURE__ */ _jsxDEV("span", {
				className: "px-3.5 py-1 bg-blue-950/90 text-blue-400 border border-blue-800/50 rounded-full text-xs font-bold font-mono",
				children: "🔌 PUNTO DE SUMINISTRO / ACOMETIDA"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 230,
				columnNumber: 16
			}, this);
			case "CCM": return /* @__PURE__ */ _jsxDEV("span", {
				className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-xs font-bold font-mono",
				children: "⚙️ CENTRO DE CONTROL DE MOTORES (CCM)"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 232,
				columnNumber: 16
			}, this);
			case "TABLERO":
			default: return /* @__PURE__ */ _jsxDEV("span", {
				className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-xs font-bold font-mono",
				children: "⚡ PANEL ELÉCTRICO"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 235,
				columnNumber: 16
			}, this);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `max-w-5xl mx-auto space-y-6 animate-fade-in font-sans pb-12 print-card print:p-0 print:m-0 ${readOnly ? "pointer-events-none opacity-90" : ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex justify-between items-center no-print",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [renderBadge(), /* @__PURE__ */ _jsxDEV("span", {
						className: "inline-flex items-center justify-center font-mono font-black text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/30 text-xs shadow-sm",
						children: ["ID: ", elementoData.id]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 246,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 244,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => window.print(),
						className: "bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-3.5 py-2 rounded-lg flex items-center gap-2 text-xs transition-all cursor-pointer shadow-sm",
						title: "Guardar como PDF o Imprimir esta Plantilla Individual",
						children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 257,
							columnNumber: 13
						}, this), " Guardar PDF"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 252,
						columnNumber: 11
					}, this), !readOnly && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [isEditing && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleLimpiarFormulario,
						className: "bg-slate-900 hover:bg-red-950/60 text-slate-400 hover:text-red-400 border border-slate-800 hover:border-red-800 font-bold px-3 py-2 rounded-lg flex items-center gap-1.5 text-xs transition-all cursor-pointer",
						title: "Reiniciar todos los campos a blanco",
						children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 269,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline",
							children: "Limpiar Formulario"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 270,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 263,
						columnNumber: 17
					}, this), isEditing ? /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleSave,
						className: "bg-slate-100 text-slate-950 font-black hover:bg-white active:scale-98 transition-all px-4 py-2 rounded-lg flex items-center gap-2 text-xs cursor-pointer shadow-md",
						children: [/* @__PURE__ */ _jsxDEV(Save, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 279,
							columnNumber: 19
						}, this), " Guardar Cambios"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 275,
						columnNumber: 17
					}, this) : /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setIsEditing(true),
						className: "bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-200 font-semibold px-4 py-2 rounded-lg flex items-center gap-2 text-xs transition-all cursor-pointer",
						children: [/* @__PURE__ */ _jsxDEV(Edit3, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 286,
							columnNumber: 19
						}, this), " Editar Plantilla"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 282,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 261,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 251,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 243,
				columnNumber: 7
			}, this),
			tipoElemento === "TABLERO" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950 border-2 border-slate-700 rounded-xl overflow-hidden shadow-2xl print:border-black print:bg-white print:text-black",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border-b-2 border-slate-700 p-3.5 text-center print:bg-gray-200 print:border-black",
						children: /* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base md:text-lg font-black tracking-wide text-slate-100 uppercase font-mono print:text-black",
							children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: nombre,
								onChange: (e) => setNombre(e.target.value),
								className: "bg-slate-950 border border-slate-600 rounded px-3 py-1 text-center w-full focus:outline-none focus:border-amber-500 text-slate-100 font-bold"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 304,
								columnNumber: 17
							}, this) : `INFORMACIÓN GENERAL DE TABLERO ${nombre ? "No. " + nombre : "No. 20"}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 302,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 301,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "border-b border-slate-700 p-3 bg-slate-900/60 font-mono text-xs text-slate-100 print:bg-white print:text-black print:border-black",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-bold uppercase text-slate-400 print:text-black mr-2",
							children: "UBICACIÓN:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 318,
							columnNumber: 13
						}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: ubicacion,
							onChange: (e) => setUbicacion(e.target.value),
							className: "bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 w-3/4"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 320,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("span", {
							className: "font-semibold",
							children: ubicacion || "SOTANO SALA DE TABLEROS"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 327,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 317,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "border-b border-slate-700 p-3 bg-slate-900/40 font-mono text-xs text-slate-100 print:bg-white print:text-black print:border-black flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-bold uppercase text-slate-400 print:text-black mr-2",
							children: "TABLERO ALIMENTADO POR:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => {
								setWizardModo("ENTRADA");
								setCircuitDataWizard({
									id: "ALIMENTACION_PRINCIPAL",
									nombre: "Acometida / Fuente Principal",
									equipo: alimentadoPor || "",
									poles: [1],
									breaker: {
										amp: "",
										marca: "",
										tipo: ""
									}
								});
								setModalJerarquiaOpen(true);
							},
							className: "no-print inline-flex items-center gap-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-all",
							title: "Configurar Origen de Alimentación (Wizard)",
							children: [/* @__PURE__ */ _jsxDEV(Settings, { className: "w-3 h-3 text-amber-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 351,
								columnNumber: 17
							}, this), " Configurar Jerarquía"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 335,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 13
						}, this), isEditing ? /* @__PURE__ */ _jsxDEV("div", {
							className: "w-full sm:w-2/3",
							children: /* @__PURE__ */ _jsxDEV(SelectorAlimentadorJerarquico, {
								proyectoId: elementoData?.proyectoId,
								tableroActualId: elementoData?.id,
								elementosList: allFeeders,
								value: alimentadoPor,
								onChange: (val) => setAlimentadoPor(val),
								label: "",
								placeholder: "Seleccionar o escribir procedencia..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 356,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 355,
							columnNumber: 15
						}, this) : renderElementWithId(alimentadoPor || "ATS SOTANO (ID: ATS-1)", elementoData?.alimentadoPorId)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 332,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-xs text-center border-collapse border-b-2 border-slate-700 font-mono print:border-black",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: [/* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900/80 border-b border-slate-700 font-bold text-slate-300 uppercase print:bg-gray-200 print:text-black print:border-gray-400",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									colSpan: "3",
									className: "p-2 border-r border-slate-700 print:border-black",
									children: "TIPO DE TABLERO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 375,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									colSpan: "3",
									className: "p-2 border-r border-slate-700 print:border-black",
									children: "BREAKER PRINCIPAL"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 376,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									rowSpan: "2",
									className: "p-2 border-r border-slate-700 print:border-black",
									children: "VOLTAJE"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 377,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									rowSpan: "2",
									className: "p-2",
									children: "ACOMETIDA"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 378,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 374,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900/50 border-b border-slate-700 font-bold text-slate-400 uppercase print:bg-gray-100 print:text-black print:border-gray-400",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									colSpan: "2",
									className: "p-1.5 border-r border-slate-700 print:border-black",
									children: "SUPERFICIAL"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 381,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1.5 border-r border-slate-700 print:border-black",
									children: "EMPOTRADO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 382,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1.5 border-r border-slate-700 print:border-black",
									children: "MARCA"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 383,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1.5 border-r border-slate-700 print:border-black",
									children: "TIPO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 384,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1.5 border-r border-slate-700 print:border-black",
									children: "AMP"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 385,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 380,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 373,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: /* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-slate-800 print:border-black",
							children: [
								/* @__PURE__ */ _jsxDEV("td", {
									colSpan: "2",
									className: "p-2 font-bold text-slate-200 border-r border-slate-800 print:text-black print:border-gray-300",
									children: dt.tipoTablero === "EMPOTRADO" ? "[  ]" : "[ X ]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-2 font-bold text-slate-200 border-r border-slate-800 print:text-black print:border-gray-300",
									children: dt.tipoTablero === "EMPOTRADO" ? "[ X ]" : "[  ]"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 393,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-2 font-bold text-slate-100 border-r border-slate-800 print:text-black print:border-gray-300",
									children: dt.breakerPrincipal?.marca || "SIN BREAKER"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 396,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-2 font-bold text-slate-100 border-r border-slate-800 print:text-black print:border-gray-300",
									children: dt.breakerPrincipal?.tipo || "-"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 399,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-2 font-bold text-amber-400 border-r border-slate-800 print:text-black print:border-gray-300",
									children: dt.breakerPrincipal?.amp || "-"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 402,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-2 font-bold text-slate-100 border-r border-slate-800 print:text-black print:border-gray-300",
									children: [
										"IA: ",
										dt.voltaje?.va || dt.barrasPrincipales?.ia || "211,5",
										/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 406,
											columnNumber: 78
										}, this),
										"IB: ",
										dt.voltaje?.vb || dt.barrasPrincipales?.ib || "207,4",
										/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 407,
											columnNumber: 78
										}, this),
										"IC: ",
										dt.voltaje?.vc || dt.barrasPrincipales?.ic || "208,6"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 405,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-2 font-bold text-slate-100 print:text-black",
									children: dt.acometida || "3X500 MCM"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 410,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 389,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 388,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 372,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-xs text-left border-collapse border-b-2 border-slate-700 font-mono print:border-black",
						children: /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800 print:divide-black",
							children: [/* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "w-1/4 bg-slate-900/90 font-bold p-2.5 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-black",
									children: "NEUTRO DE LLEGADA"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 421,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "w-1/4 p-2.5 border-r border-slate-800 print:border-black",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 block font-bold",
										children: "CALIB COND."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 425,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-100 print:text-black",
										children: dt.neutroLlegada?.calibre || "1X500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 426,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 424,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-2.5",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 block font-bold",
										children: "OBSERVACIONES:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 429,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-300 print:text-black",
										children: dt.neutroLlegada?.observaciones || "CABLE ROJO EN TABLERO"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 430,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 428,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 420,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "bg-slate-900/90 font-bold p-2.5 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-black",
									children: "PUESTA A TIERRA"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-2.5 border-r border-slate-800 print:border-black",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 block font-bold",
										children: "CALIB COND."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 438,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-100 print:text-black",
										children: dt.puestaTierra?.calibre || "SOLIDO #4"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 439,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 437,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-2.5",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 block font-bold",
										children: "OBSERVACIONES:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 442,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-300 print:text-black",
										children: dt.puestaTierra?.observaciones || "LLEGA SOLIDO #4. BUSCAR TANQUILLA DE MALLA A TIERRA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 443,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 441,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 433,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 419,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 418,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-amber-950/40 border-b-2 border-amber-800/60 p-4 font-mono text-xs text-amber-200 print:bg-yellow-100 print:text-black print:border-black",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-black uppercase text-amber-400 block mb-1 print:text-black",
							children: "OBSERVACIÓN GENERAL:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 451,
							columnNumber: 13
						}, this), isEditing ? /* @__PURE__ */ _jsxDEV("textarea", {
							value: observacionesGenerales,
							onChange: (e) => setObservacionesGenerales(e.target.value),
							rows: 3,
							className: "w-full bg-slate-900 border border-amber-600 rounded p-2 text-slate-100 text-xs resize-none"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 453,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("p", {
							className: "leading-relaxed font-medium",
							children: observacionesGenerales || "SALEN ACOMETIDAS 1 X 500 Y 1X250 MCM DE LA BARRA PARTE INFERIOR. LA ACOMETIDA 250 MCM VA A CAJA CON UN BREAKER AL LADO DEL TABLERO PRINCIPAL. INTERRUPTOR EATON, Ki400, 350 A. SALEN UNA ACOMETIDA 4/0 QUE ALIMENTA TRANSFERENCIA 160. LA ACOMETIDA 500 MCM VA A UNA CAJA AL LADO DEL TABLERO PRINCIPAL. INTERRUPTOR ABB, TIPO 6520, 400 A, SALEN 2X500 Y ALIMENTAN TABLERO EN PRIMER PISO."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 460,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 450,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-900/30 text-center print:bg-white",
						children: fotoBlob || fotoSrc || previewUrl ? /* @__PURE__ */ _jsxDEV("div", {
							className: "max-w-md mx-auto rounded-xl overflow-hidden border border-slate-700 shadow-lg print:border-black",
							children: /* @__PURE__ */ _jsxDEV(SafeImage, {
								blob: fotoBlob,
								src: previewUrl || fotoSrc,
								alt: "Tablero Eléctrico",
								className: "w-full h-auto max-h-96 object-cover"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 470,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 469,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "p-6 border-2 border-dashed border-slate-800 rounded-xl text-center space-y-2 no-print",
							children: [
								/* @__PURE__ */ _jsxDEV(Camera, { className: "w-8 h-8 text-slate-600 mx-auto" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 474,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-500 font-mono block",
									children: "Sin fotografía adjunta del panel eléctrico"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 475,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("label", {
									className: "inline-block px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold rounded-lg cursor-pointer transition-colors",
									children: ["Adjuntar Foto", /* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										accept: "image/*",
										onChange: handleImageChange,
										className: "hidden"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 478,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 476,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 473,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 467,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 298,
				columnNumber: 9
			}, this),
			tipoElemento === "GENERADOR" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950 border-2 border-slate-700 rounded-xl overflow-hidden shadow-2xl print:border-black print:bg-white print:text-black",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border-b-2 border-slate-700 p-3.5 text-center print:bg-gray-200 print:border-black",
						children: /* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base md:text-lg font-black tracking-wide text-slate-100 uppercase font-mono print:text-black",
							children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: nombre,
								onChange: (e) => setNombre(e.target.value),
								placeholder: "Ej. GENERADOR DE EMERGENCIA No. 1",
								className: "bg-slate-950 border border-slate-600 rounded px-3 py-1 text-center w-full focus:outline-none focus:border-amber-500 text-slate-100 font-bold placeholder-slate-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 497,
								columnNumber: 17
							}, this) : nombre || "GENERADOR DE EMERGENCIA"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 495,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 494,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-xs text-left border-collapse border-b border-slate-700 font-mono print:border-black",
						children: /* @__PURE__ */ _jsxDEV("tbody", { children: [/* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-slate-800 print:border-gray-300",
							children: [/* @__PURE__ */ _jsxDEV("td", {
								className: "w-1/3 bg-slate-900/90 font-bold p-3 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-gray-300 flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "GENERADOR ALIMENTA A:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 515,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setWizardModo("SALIDA");
										setCircuitDataWizard({
											id: "GENERADOR_SALIDA",
											nombre: "Salida del Generador",
											equipo: alimentadoPor || "",
											poles: [3],
											breaker: {
												amp: dt.amperaje || "",
												marca: dt.marca || "",
												tipo: ""
											}
										});
										setModalJerarquiaOpen(true);
									},
									className: "no-print inline-flex items-center gap-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-all",
									title: "Configurar Equipo Alimentado (Wizard)",
									children: [/* @__PURE__ */ _jsxDEV(Settings, { className: "w-3 h-3 text-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 532,
										columnNumber: 21
									}, this), " Configurar Jerarquía"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 516,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 514,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 text-slate-100 font-semibold print:text-black",
								children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: alimentadoPor,
									onChange: (e) => setAlimentadoPor(e.target.value),
									placeholder: "Ej. TRANSFERENCIA PRINCIPAL (ATS-1)",
									className: "w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 placeholder-slate-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 537,
									columnNumber: 21
								}, this) : renderElementWithId(alimentadoPor || "—")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 535,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 513,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
							className: "bg-slate-900/90 font-bold p-3 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-gray-300",
							children: "UBICACIÓN:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 550,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("td", {
							className: "p-3 text-slate-100 font-semibold print:text-black",
							children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: ubicacion,
								onChange: (e) => setUbicacion(e.target.value),
								placeholder: "Ej. Caseta de Generación / Estacionamiento",
								className: "w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 placeholder-slate-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 555,
								columnNumber: 21
							}, this) : ubicacion || "—"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 553,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 549,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 512,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 511,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/80 border-b border-slate-700 p-2 text-center font-bold text-xs uppercase tracking-wider text-amber-400 font-mono print:bg-gray-200 print:text-black print:border-black",
						children: "Datos de placa"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 571,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-xs text-left border-collapse border-b-2 border-slate-700 font-mono print:border-black",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900/50 border-b border-slate-800 font-bold text-slate-400 uppercase print:bg-gray-100 print:text-black print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2.5 border-r border-slate-800 w-1/3 print:border-gray-300",
									children: "PARÁMETRO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 579,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2.5 border-r border-slate-800 w-1/3 text-center print:border-gray-300",
									children: "VALOR"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 580,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2.5 w-1/3 text-center",
									children: "UNIDAD"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 581,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 578,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 577,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800 print:divide-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "MARCA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 586,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-bold text-slate-100 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.marca || "",
											onChange: (e) => handleDtChange("marca", e.target.value),
											placeholder: "Ej. CATERPILLAR / DOMOSA / CUMMINS",
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 placeholder-slate-600"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 588,
											columnNumber: 32
										}, this) : dt.marca || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 587,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: "PLACA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 590,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 585,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "FASES"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 593,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-bold text-slate-100 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("select", {
											value: dt.fases || "3",
											onChange: (e) => handleDtChange("fases", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "1",
													children: "1 (Monofásico)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 601,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "2",
													children: "2 (Bifásico)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 602,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "3",
													children: "3 (Trifásico)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 603,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 596,
											columnNumber: 21
										}, this) : dt.fases || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 594,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: "FASE"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 609,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 592,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "POTENCIA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 612,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-extrabold text-amber-400 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.kva || dt.potenciaKva || "",
											onChange: (e) => handleDtChange("kva", e.target.value),
											placeholder: "Ej. 580",
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-amber-400 placeholder-slate-600"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 614,
											columnNumber: 32
										}, this) : dt.kva || dt.potenciaKva || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 613,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: "KVA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 616,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 611,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "VOLTAJE NOMINAL (COVENIN 159)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 619,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-bold text-slate-100 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("select", {
											value: dt.voltajeGeneracion || dt.voltaje || "",
											onChange: (e) => handleDtChange("voltajeGeneracion", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs",
											children: [/* @__PURE__ */ _jsxDEV("option", {
												value: "",
												children: "-- Seleccionar Tensión --"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 627,
												columnNumber: 23
											}, this), TENSIONES_COVENIN_159_BT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
												value: v,
												children: v
											}, v, false, {
												fileName: _jsxFileName,
												lineNumber: 629,
												columnNumber: 25
											}, this))]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 622,
											columnNumber: 21
										}, this) : dt.voltajeGeneracion || dt.voltaje || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 620,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: "VOLTIOS"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 636,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 618,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "AMPERAJE NOMINAL"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 639,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-bold text-slate-100 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.amperaje || "",
											onChange: (e) => handleDtChange("amperaje", e.target.value),
											placeholder: "Ej. 1600",
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 placeholder-slate-600"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 641,
											columnNumber: 32
										}, this) : dt.amperaje || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 640,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: "AMP"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 643,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 638,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "FP (FACTOR POTENCIA)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 646,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-bold text-slate-100 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.fp || "",
											onChange: (e) => handleDtChange("fp", e.target.value),
											placeholder: "Ej. 0.8",
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 placeholder-slate-600"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 648,
											columnNumber: 32
										}, this) : dt.fp || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 647,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: "cos φ"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 650,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 645,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "TIPO DE COMBUSTIBLE"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 653,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-bold text-slate-100 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("select", {
											value: dt.combustible || "DIÉSEL",
											onChange: (e) => handleDtChange("combustible", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "DIÉSEL",
													children: "DIÉSEL / GASOIL"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 661,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "GAS_NATURAL",
													children: "GAS NATURAL"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 662,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "GLP",
													children: "GAS LICUADO (GLP)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 663,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "GASOLINA",
													children: "GASOLINA"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 664,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "DUAL_FUEL",
													children: "DUAL FUEL (GAS / DIÉSEL)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 665,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 656,
											columnNumber: 21
										}, this) : dt.combustible || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 654,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: "TIPO"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 671,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 652,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 584,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 576,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/80 border-b border-slate-700 p-2 text-center font-bold text-xs uppercase tracking-wider text-amber-400 font-mono print:bg-gray-200 print:text-black print:border-black",
						children: "INTERRUPTOR PRINCIPAL DEL GENERADOR"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 677,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-xs text-center border-collapse border-b-2 border-slate-700 font-mono print:border-black",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900/50 border-b border-slate-800 font-bold text-slate-400 uppercase print:bg-gray-100 print:text-black print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300",
									children: "INTERRUPTOR"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 685,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300",
									children: "MARCA"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 686,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300",
									children: "TIPO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 687,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300",
									children: "AMP"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 688,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300",
									children: "COND. FASE"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 689,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2",
									children: "COND. NEUTRO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 690,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 684,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 683,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
							/* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 font-bold text-slate-300 border-r border-slate-800 bg-slate-900/40 print:bg-gray-50 print:text-black print:border-gray-300",
								children: "GENERADOR"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 695,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 font-bold text-slate-100 border-r border-slate-800 print:text-black print:border-gray-300",
								children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: dt.interruptor?.marca || dt.interruptorMarca || "",
									onChange: (e) => handleNestedDtChange("interruptor", "marca", e.target.value),
									placeholder: "Ej. CHINT / ABB",
									className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 placeholder-slate-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 697,
									columnNumber: 32
								}, this) : dt.interruptor?.marca || dt.interruptorMarca || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 696,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 font-bold text-slate-100 border-r border-slate-800 print:text-black print:border-gray-300",
								children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: dt.interruptor?.tipo || dt.interruptorTipo || "",
									onChange: (e) => handleNestedDtChange("interruptor", "tipo", e.target.value),
									placeholder: "Ej. Termomagnético",
									className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 placeholder-slate-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 700,
									columnNumber: 32
								}, this) : dt.interruptor?.tipo || dt.interruptorTipo || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 699,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 font-extrabold text-amber-400 border-r border-slate-800 print:text-black print:border-gray-300",
								children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: dt.interruptor?.amp || dt.interruptorAmp || "",
									onChange: (e) => handleNestedDtChange("interruptor", "amp", e.target.value),
									placeholder: "Ej. 1600 A",
									className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-amber-400 placeholder-slate-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 703,
									columnNumber: 32
								}, this) : dt.interruptor?.amp || dt.interruptorAmp || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 702,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 font-bold text-slate-100 border-r border-slate-800 print:text-black print:border-gray-300",
								children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: dt.interruptor?.condFase || dt.condFase || "",
									onChange: (e) => handleNestedDtChange("interruptor", "condFase", e.target.value),
									placeholder: "Ej. 2(3X500 MCM)",
									className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 placeholder-slate-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 706,
									columnNumber: 32
								}, this) : dt.interruptor?.condFase || dt.condFase || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 705,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 font-bold text-slate-100 print:text-black",
								children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: dt.interruptor?.condNeutro || dt.condNeutro || "",
									onChange: (e) => handleNestedDtChange("interruptor", "condNeutro", e.target.value),
									placeholder: "Ej. 1X500 MCM",
									className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 placeholder-slate-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 709,
									columnNumber: 32
								}, this) : dt.interruptor?.condNeutro || dt.condNeutro || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 708,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 694,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 693,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 682,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-950 border-b-2 border-slate-700",
						children: /* @__PURE__ */ _jsxDEV(MetrologiaElectricaSection, {
							mediciones: dt.mediciones || {},
							onChange: (nuevasMediciones) => handleDtChange("mediciones", nuevasMediciones),
							readOnly: !isEditing,
							titulo: "Metrología Eléctrica y Medición de Generación (COVENIN 159)",
							subtitulo: "Lectura de voltajes desglosados L-L, L-N y 5 canales de corriente en bornes de generación"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 717,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 716,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/80 border-b border-slate-700 p-2 text-center font-bold text-xs uppercase tracking-wider text-amber-400 font-mono print:bg-gray-200 print:text-black print:border-black",
						children: "INSPECCIÓN DE TANQUE DE COMBUSTIBLE Y AUTONOMÍA (SISTEMA MÉTRICO LITROS / GALONES)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 727,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-950 border-b border-slate-700 space-y-4 font-mono text-xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 block font-bold mb-1",
									children: "CAPACIDAD TOTAL:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 734,
									columnNumber: 17
								}, this), isEditing ? /* @__PURE__ */ _jsxDEV("div", {
									className: "flex gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										value: dt.tanqueCapacidad || "",
										onChange: (e) => handleDtChange("tanqueCapacidad", e.target.value),
										placeholder: "Ej. 1000",
										className: "w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs focus:border-amber-500 placeholder-slate-600"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 737,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: dt.tanqueUnidad || "Litros",
										onChange: (e) => handleDtChange("tanqueUnidad", e.target.value),
										className: "bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs px-1 font-bold",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "Litros",
											children: "Litros (L)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 749,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("option", {
											value: "Galones",
											children: "Galones (gal)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 750,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 744,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 736,
									columnNumber: 19
								}, this) : /* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-100 font-bold bg-slate-900/60 px-2.5 py-1 rounded block",
									children: dt.tanqueCapacidad ? `${dt.tanqueCapacidad} ${dt.tanqueUnidad === "Galones" ? "Galones (gal)" : "Litros (L)"}` : "—"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 754,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 733,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 block font-bold mb-1",
									children: "NIVEL ACTUAL (%):"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 761,
									columnNumber: 17
								}, this), isEditing ? /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "0",
										max: "100",
										value: dt.tanqueNivelPct !== undefined ? dt.tanqueNivelPct : 50,
										onChange: (e) => handleDtChange("tanqueNivelPct", parseInt(e.target.value)),
										className: "w-full h-2 bg-slate-800 rounded appearance-none accent-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 764,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-amber-400 w-10 text-right",
										children: [dt.tanqueNivelPct !== undefined ? dt.tanqueNivelPct : 50, "%"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 772,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 763,
									columnNumber: 19
								}, this) : /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 bg-slate-900 rounded-full h-3 overflow-hidden border border-slate-800",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: `h-full ${(dt.tanqueNivelPct || 0) < 25 ? "bg-red-500" : (dt.tanqueNivelPct || 0) < 50 ? "bg-amber-500" : "bg-emerald-500"}`,
											style: { width: `${dt.tanqueNivelPct || 0}%` }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 777,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 776,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-200",
										children: dt.tanqueNivelPct !== undefined ? `${dt.tanqueNivelPct}%` : "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 785,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 775,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 760,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 block font-bold mb-1",
									children: "CONSUMO ESPECÍFICO (L/h):"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 791,
									columnNumber: 17
								}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "number",
									value: dt.consumoLh || "",
									onChange: (e) => handleDtChange("consumoLh", e.target.value),
									placeholder: "Ej. 35",
									className: "w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs focus:border-amber-500 placeholder-slate-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 793,
									columnNumber: 19
								}, this) : /* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-100 font-bold bg-slate-900/60 px-2.5 py-1 rounded block",
									children: dt.consumoLh ? `${dt.consumoLh} L/h` : "—"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 801,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 790,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 block font-bold mb-1",
									children: "AUTONOMÍA ESTIMADA:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 808,
									columnNumber: 17
								}, this), (() => {
									const cap = parseFloat(dt.tanqueCapacidad) || 0;
									const nivel = parseFloat(dt.tanqueNivelPct !== undefined ? dt.tanqueNivelPct : 50) / 100;
									const cons = parseFloat(dt.consumoLh) || 0;
									const litrosDisponibles = dt.tanqueUnidad === "Galones" ? cap * 3.78541 * nivel : cap * nivel;
									const horasAutonomia = cons > 0 && cap > 0 ? (litrosDisponibles / cons).toFixed(1) : null;
									return /* @__PURE__ */ _jsxDEV("span", {
										className: `px-2.5 py-1 rounded block font-bold font-mono text-center ${horasAutonomia && parseFloat(horasAutonomia) >= 12 ? "bg-emerald-950 text-emerald-400 border border-emerald-800" : horasAutonomia && parseFloat(horasAutonomia) >= 6 ? "bg-amber-950 text-amber-400 border border-amber-800" : "bg-slate-900 text-slate-300 border border-slate-800"}`,
										children: horasAutonomia ? `⏱️ ~${horasAutonomia} Horas` : "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 817,
										columnNumber: 21
									}, this);
								})()] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 807,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 732,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t border-slate-900 text-[11px]",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between p-2 bg-slate-900/50 rounded-lg border border-slate-850",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400",
										children: "Dique Contención (110%):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 832,
										columnNumber: 17
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.diqueContencion || "Conforme",
										onChange: (e) => handleDtChange("diqueContencion", e.target.value),
										className: "bg-slate-950 border border-slate-700 rounded px-1 text-slate-200",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Conforme",
												children: "Conforme"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 839,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Sin Dique",
												children: "Sin Dique"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 840,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Fisurado / Sucio",
												children: "Fisurado / Sucio"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 841,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 834,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: `font-bold ${dt.diqueContencion === "Sin Dique" ? "text-red-400" : "text-emerald-400"}`,
										children: dt.diqueContencion || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 844,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 831,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between p-2 bg-slate-900/50 rounded-lg border border-slate-850",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400",
										children: "Filtro Racor / Trampa:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 851,
										columnNumber: 17
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.filtroRacor || "Operativo",
										onChange: (e) => handleDtChange("filtroRacor", e.target.value),
										className: "bg-slate-950 border border-slate-700 rounded px-1 text-slate-200",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Operativo",
												children: "Operativo"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 858,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Agua / Sucio",
												children: "Agua / Sucio"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 859,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Requiere Reemplazo",
												children: "Requiere Reemplazo"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 860,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 853,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-200",
										children: dt.filtroRacor || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 863,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 850,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between p-2 bg-slate-900/50 rounded-lg border border-slate-850",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400",
										children: "Bomba de Trasiego:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 868,
										columnNumber: 17
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.bombaTrasiego || "Manual y Eléctrica",
										onChange: (e) => handleDtChange("bombaTrasiego", e.target.value),
										className: "bg-slate-950 border border-slate-700 rounded px-1 text-slate-200",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Manual y Eléctrica",
												children: "Manual y Eléctrica"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 875,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Solo Manual",
												children: "Solo Manual"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 876,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Solo Eléctrica",
												children: "Solo Eléctrica"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 877,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Inoperativa",
												children: "Inoperativa"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 878,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 870,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-200",
										children: dt.bombaTrasiego || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 881,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 867,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between p-2 bg-slate-900/50 rounded-lg border border-slate-850",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400",
										children: "Válvula Corte Rápido:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 886,
										columnNumber: 17
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.valvulaCorte || "Operativa",
										onChange: (e) => handleDtChange("valvulaCorte", e.target.value),
										className: "bg-slate-950 border border-slate-700 rounded px-1 text-slate-200",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Operativa",
												children: "Operativa"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 893,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Trabada",
												children: "Trabada"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 894,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "No Posee",
												children: "No Posee"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 895,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 888,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-200",
										children: dt.valvulaCorte || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 898,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 885,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 830,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 731,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-5 bg-slate-900/30",
						children: /* @__PURE__ */ _jsxDEV(DualPhotoUploader, {
							fotoBlob,
							fotoSrc,
							previewUrl,
							onImageSelected: (file) => {
								setFotoBlob(file);
								if (previewUrl) URL.revokeObjectURL(previewUrl);
								setPreviewUrl(URL.createObjectURL(file));
							},
							onRemove: () => {
								setFotoBlob(null);
								setFotoSrc(null);
								if (previewUrl) URL.revokeObjectURL(previewUrl);
								setPreviewUrl(null);
							},
							readOnly: !isEditing,
							label: "Fotografía del Generador y Grupo Electrógeno",
							sublabel: "Cámara en vivo o selección desde galería"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 906,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 905,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 491,
				columnNumber: 9
			}, this),
			tipoElemento === "TRANSFER" && /* @__PURE__ */ _jsxDEV(TransferComponent, {
				transferData: elementoData,
				onUpdate,
				readOnly
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 934,
				columnNumber: 9
			}, this),
			tipoElemento === "TRANSFORMADOR" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950 border-2 border-slate-700 rounded-xl overflow-hidden shadow-2xl print:border-black print:bg-white print:text-black",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border-b-2 border-slate-700 p-3.5 text-center print:bg-gray-200 print:border-black",
						children: /* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base md:text-lg font-black tracking-wide text-slate-100 uppercase font-mono print:text-black",
							children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: nombre,
								onChange: (e) => setNombre(e.target.value),
								className: "bg-slate-950 border border-slate-600 rounded px-3 py-1 text-center w-full focus:outline-none focus:border-violet-500 text-slate-100 font-bold"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 951,
								columnNumber: 17
							}, this) : `INFORMACIÓN GENERAL DE TRANSFORMADOR No. ${nombre || "—"}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 949,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 948,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "border-b border-slate-700 p-3 bg-slate-900/60 font-mono text-xs text-slate-100 print:bg-white print:text-black print:border-black flex flex-col md:flex-row md:items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold uppercase text-slate-400 print:text-black mr-1.5",
								children: "ID ELEMENTO:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 967,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30 print:text-black print:border-black",
								children: elementoData.id || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 968,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 966,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold uppercase text-slate-400 print:text-black mr-1.5",
								children: "ALIMENTADO POR:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 973,
								columnNumber: 17
							}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: alimentadoPor,
								onChange: (e) => setAlimentadoPor(e.target.value),
								className: "bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 focus:outline-none focus:border-violet-500",
								placeholder: "Ej. PCC / Acometida 1"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 975,
								columnNumber: 19
							}, this) : /* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold",
								children: alimentadoPor || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 983,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 972,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 965,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-bold uppercase text-slate-400 print:text-black mr-1.5",
							children: "UBICACIÓN:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 988,
							columnNumber: 15
						}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: ubicacion,
							onChange: (e) => setUbicacion(e.target.value),
							className: "bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 focus:outline-none focus:border-violet-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 990,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV("span", {
							className: "font-semibold",
							children: ubicacion || "—"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 997,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 987,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 964,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-xs text-left border-collapse border-b border-slate-700 font-mono print:border-black",
						children: /* @__PURE__ */ _jsxDEV("tbody", { children: [/* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-slate-800 print:border-gray-300",
							children: [/* @__PURE__ */ _jsxDEV("td", {
								className: "w-1/3 bg-slate-900/90 font-bold p-3 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-gray-300",
								children: "MARCA"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1006,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 text-slate-100 font-semibold print:text-black",
								children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: dt.marca || "",
									onChange: (e) => handleDtChange("marca", e.target.value),
									className: "w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 focus:outline-none focus:border-violet-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1009,
									columnNumber: 21
								}, this) : dt.marca || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1007,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1005,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-slate-800 print:border-gray-300",
							children: [/* @__PURE__ */ _jsxDEV("td", {
								className: "bg-slate-900/90 font-bold p-3 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-gray-300",
								children: "FASES"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1021,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 text-slate-100 font-semibold print:text-black",
								children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: dt.fases || "",
									onChange: (e) => handleDtChange("fases", e.target.value),
									className: "w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 focus:outline-none focus:border-violet-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1024,
									columnNumber: 21
								}, this) : dt.fases || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1022,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1020,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1004,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1003,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-xs text-left border-collapse border-b-2 border-slate-700 font-mono print:border-black",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900/50 border-b border-slate-800 font-bold text-slate-400 uppercase print:bg-gray-100 print:text-black print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2.5 border-r border-slate-800 w-1/3 print:border-gray-300",
									children: "PARÁMETRO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1042,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2.5 border-r border-slate-800 w-1/3 text-center print:border-gray-300",
									children: "VALOR"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1043,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2.5 w-1/3 text-center",
									children: "UNIDAD"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1044,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1041,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1040,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800 print:divide-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "POTENCIA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1049,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-extrabold text-violet-400 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											maxLength: 4,
											value: dt.potenciaKva || dt.kva || "",
											onChange: (e) => {
												const val = e.target.value.replace(/\D/g, "").slice(0, 4);
												handleDtChange("potenciaKva", val);
												handleDtChange("kva", val);
											},
											placeholder: "Ej. 500",
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-violet-400 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1052,
											columnNumber: 21
										}, this) : dt.potenciaKva || dt.kva || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1050,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("select", {
											value: dt.unidadPotencia || "kVA",
											onChange: (e) => handleDtChange("unidadPotencia", e.target.value),
											className: "bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500 text-center",
											children: [/* @__PURE__ */ _jsxDEV("option", {
												value: "kVA",
												children: "kVA"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1075,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("option", {
												value: "MVA",
												children: "MVA"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1076,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1070,
											columnNumber: 21
										}, this) : dt.unidadPotencia || "kVA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1068,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1048,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
									className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
									children: "IMPEDANCIA"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1084,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("td", {
									className: "p-2.5 border-r border-slate-800 print:border-gray-300",
									colSpan: "2",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-3 gap-2 text-center items-center",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 justify-center",
												children: [isEditing ? /* @__PURE__ */ _jsxDEV("input", {
													type: "text",
													value: dt.impedanciaPct || "",
													onChange: (e) => handleDtChange("impedanciaPct", e.target.value),
													placeholder: "%",
													className: "w-16 bg-slate-900 border border-slate-700 rounded text-slate-100 text-center text-xs p-1 focus:outline-none focus:border-violet-500"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1089,
													columnNumber: 25
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "font-bold text-slate-100 print:text-black",
													children: dt.impedanciaPct || "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1097,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-slate-500 font-bold",
													children: "%"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1099,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1087,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 justify-center border-l border-slate-850 print:border-gray-300",
												children: [isEditing ? /* @__PURE__ */ _jsxDEV("input", {
													type: "text",
													value: dt.impedanciaAmp || "",
													onChange: (e) => handleDtChange("impedanciaAmp", e.target.value),
													placeholder: "A",
													className: "w-16 bg-slate-900 border border-slate-700 rounded text-slate-100 text-center text-xs p-1 focus:outline-none focus:border-violet-500"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1103,
													columnNumber: 25
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "font-bold text-slate-100 print:text-black",
													children: dt.impedanciaAmp || "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1111,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-slate-500 font-bold",
													children: "A"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1113,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1101,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 justify-center border-l border-slate-850 print:border-gray-300",
												children: [isEditing ? /* @__PURE__ */ _jsxDEV("input", {
													type: "text",
													value: dt.impedanciaTemp || "",
													onChange: (e) => handleDtChange("impedanciaTemp", e.target.value),
													placeholder: "°C",
													className: "w-16 bg-slate-900 border border-slate-700 rounded text-slate-100 text-center text-xs p-1 focus:outline-none focus:border-violet-500"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1117,
													columnNumber: 25
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "font-bold text-slate-100 print:text-black",
													children: dt.impedanciaTemp || "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1125,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-slate-500 font-bold",
													children: "°C"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1127,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1115,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1086,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1085,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1083,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "TENSIÓN PRIMARIA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1133,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-bold text-slate-100 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.tensionPrimaria || dt.voltajePrimario || "",
											onChange: (e) => {
												const val = e.target.value.replace(/[^0-9.]/g, "").replace(/(\..*)\./g, "$1");
												handleDtChange("tensionPrimaria", val);
												handleDtChange("voltajePrimario", val);
											},
											placeholder: "Ej. 13.8",
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1136,
											columnNumber: 21
										}, this) : dt.tensionPrimaria || dt.voltajePrimario || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1134,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("select", {
											value: dt.unidadTensionPrimaria || "kV",
											onChange: (e) => handleDtChange("unidadTensionPrimaria", e.target.value),
											className: "bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500 text-center",
											children: [/* @__PURE__ */ _jsxDEV("option", {
												value: "kV",
												children: "kV"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1158,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("option", {
												value: "V",
												children: "V"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1159,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1153,
											columnNumber: 21
										}, this) : dt.unidadTensionPrimaria || "kV"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1151,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1132,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "TENSIÓN SECUNDARIA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1167,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-bold text-slate-100 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.tensionSecundaria || dt.voltajeSecundario || "",
											onChange: (e) => {
												const val = e.target.value.replace(/[^0-9/]/g, "");
												handleDtChange("tensionSecundaria", val);
												handleDtChange("voltajeSecundario", val);
											},
											placeholder: "Ej. 208/120",
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1170,
											columnNumber: 21
										}, this) : dt.tensionSecundaria || dt.voltajeSecundario || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1168,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: "V"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1185,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1166,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 bg-slate-900/40 font-bold text-slate-300 border-r border-slate-800 print:bg-gray-50 print:text-black print:border-gray-300",
										children: "AMPERIOS SEC."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1188,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 border-r border-slate-800 text-center font-bold text-slate-100 print:text-black print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.amperiosSecundaria || "",
											onChange: (e) => handleDtChange("amperiosSecundaria", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1191,
											columnNumber: 21
										}, this) : dt.amperiosSecundaria || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1189,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2.5 text-center text-slate-400 print:text-black",
										children: "AMP"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1201,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1187,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1047,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1039,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/80 border-b border-slate-700 p-2 text-center font-bold text-xs uppercase tracking-wider text-violet-400 font-mono print:bg-gray-200 print:text-black print:border-black",
						children: "ACOMETIDAS"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1207,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-[10px] md:text-xs text-center border-collapse border-b-2 border-slate-700 font-mono print:border-black",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: [/* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900/50 border-b border-slate-800 font-bold text-slate-400 uppercase print:bg-gray-100 print:text-black print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300 w-20",
									rowSpan: "2",
									children: "ACOMETIDAS"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1214,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300 w-24",
									colSpan: "2",
									children: "TIPO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1215,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300",
									colSpan: "3",
									children: "CONDUCTOR"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1216,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300",
									colSpan: "2",
									children: "PROTECCIONES"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1217,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 print:text-black",
									rowSpan: "2",
									children: "OBSERVACIONES"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1218,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1213,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900/30 border-b border-slate-800 font-bold text-slate-500 uppercase print:bg-gray-50 print:text-black print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "AEREA"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1221,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "SUB-TERR"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1222,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "CALIB"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1223,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "TIPO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1224,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "TERMINAL"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1225,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "FUSIBLE"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1226,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "PARARRAYO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1227,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1220,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1212,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800 print:divide-gray-300",
							children: ["primaria", "secundaria"].map((seccion) => {
								const ac = dt.acometidas?.[seccion] || {
									aerea: false,
									subterranea: false,
									calibre: "",
									tipo: "",
									terminal: "",
									fusible: "",
									pararrayo: "",
									observaciones: ""
								};
								return /* @__PURE__ */ _jsxDEV("tr", {
									className: "print:text-black",
									children: [
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-2 font-bold bg-slate-900/40 border-r border-slate-800 uppercase print:bg-gray-50 print:border-gray-300 text-slate-350 print:text-black",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between gap-1",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: seccion }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1237,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => {
														const isEntrada = seccion === "primaria";
														setWizardModo(isEntrada ? "ENTRADA" : "SECUNDARIA");
														setCircuitDataWizard({
															id: `TRANSFORMADOR_${seccion.toUpperCase()}`,
															nombre: `Transformador - Acometida ${seccion.toUpperCase()}`,
															equipo: isEntrada ? alimentadoPor : ac.observaciones || "",
															poles: [3],
															breaker: {
																amp: "",
																marca: "",
																tipo: ""
															}
														});
														setModalJerarquiaOpen(true);
													},
													className: "no-print p-1 hover:bg-violet-500/20 text-violet-400 rounded transition-all cursor-pointer",
													title: `Configurar Jerarquía (${seccion})`,
													children: /* @__PURE__ */ _jsxDEV(Settings, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1255,
														columnNumber: 27
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1238,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1236,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1235,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-2 border-r border-slate-800 print:border-gray-300 text-center",
											children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: ac.aerea || false,
												onChange: (e) => handleAcometidaChange(seccion, "aerea", e.target.checked),
												className: "w-4 h-4 cursor-pointer accent-violet-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1261,
												columnNumber: 25
											}, this) : ac.aerea ? "[ X ]" : "[   ]"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1259,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-2 border-r border-slate-800 print:border-gray-300 text-center",
											children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: ac.subterranea || false,
												onChange: (e) => handleAcometidaChange(seccion, "subterranea", e.target.checked),
												className: "w-4 h-4 cursor-pointer accent-violet-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1273,
												columnNumber: 25
											}, this) : ac.subterranea ? "[ X ]" : "[   ]"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1271,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-2 border-r border-slate-800 print:border-gray-300",
											children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: ac.calibre || "",
												onChange: (e) => handleAcometidaChange(seccion, "calibre", e.target.value),
												className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1285,
												columnNumber: 25
											}, this) : ac.calibre || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1283,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-2 border-r border-slate-800 print:border-gray-300",
											children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: ac.tipo || "",
												onChange: (e) => handleAcometidaChange(seccion, "tipo", e.target.value),
												className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1297,
												columnNumber: 25
											}, this) : ac.tipo || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1295,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-2 border-r border-slate-800 print:border-gray-300",
											children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: ac.terminal || "",
												onChange: (e) => handleAcometidaChange(seccion, "terminal", e.target.value),
												className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1309,
												columnNumber: 25
											}, this) : ac.terminal || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1307,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-2 border-r border-slate-800 print:border-gray-300",
											children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: ac.fusible || "",
												onChange: (e) => handleAcometidaChange(seccion, "fusible", e.target.value),
												className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1321,
												columnNumber: 25
											}, this) : ac.fusible || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1319,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-2 border-r border-slate-800 print:border-gray-300",
											children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: ac.pararrayo || "",
												onChange: (e) => handleAcometidaChange(seccion, "pararrayo", e.target.value),
												className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1333,
												columnNumber: 25
											}, this) : ac.pararrayo || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1331,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-2 text-left",
											children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: ac.observaciones || "",
												onChange: (e) => handleAcometidaChange(seccion, "observaciones", e.target.value),
												className: "w-full bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1345,
												columnNumber: 25
											}, this) : ac.observaciones || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1343,
											columnNumber: 21
										}, this)
									]
								}, seccion, true, {
									fileName: _jsxFileName,
									lineNumber: 1234,
									columnNumber: 19
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1230,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1211,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/80 border-b border-slate-700 p-2 text-center font-bold text-xs uppercase tracking-wider text-violet-400 font-mono print:bg-gray-200 print:text-black print:border-black",
						children: "SISTEMA DE PUESTA A TIERRA (SPT)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1362,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-[10px] md:text-xs text-center border-collapse border-b-2 border-slate-700 font-mono print:border-black",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: [/* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900/50 border-b border-slate-800 font-bold text-slate-400 uppercase print:bg-gray-100 print:text-black print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300 w-20",
									rowSpan: "2",
									children: "SPT"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1369,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300",
									colSpan: "3",
									children: "BARILLA (VARILLA)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1370,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300",
									colSpan: "2",
									children: "CONDUCTOR"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1371,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 border-r border-slate-800 print:border-gray-300 w-24",
									rowSpan: "2",
									children: "RESISTENCIA"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1372,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-2 print:text-black",
									rowSpan: "2",
									children: "FECHA DE MEDICIÓN"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1373,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1368,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900/30 border-b border-slate-800 font-bold text-slate-500 uppercase print:bg-gray-50 print:text-black print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "CALIBRE"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1376,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "CANTIDAD"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1377,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "CONFIGURACIÓN"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1378,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "CALIBRE"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1379,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "p-1 border-r border-slate-800 print:border-gray-350",
									children: "TIPO SOLD"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1380,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1375,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1367,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800 print:divide-gray-300",
							children: /* @__PURE__ */ _jsxDEV("tr", {
								className: "print:text-black",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-3 font-bold bg-slate-900/40 border-r border-slate-800 print:bg-gray-50 print:border-gray-300 text-slate-350 print:text-black",
										children: "MEDIDA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1385,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2 border-r border-slate-800 print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.spt?.barillaCalibre || "",
											onChange: (e) => handleSptChange("barillaCalibre", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1390,
											columnNumber: 21
										}, this) : dt.spt?.barillaCalibre || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1388,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2 border-r border-slate-800 print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.spt?.barillaCantidad || "",
											onChange: (e) => handleSptChange("barillaCantidad", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1402,
											columnNumber: 21
										}, this) : dt.spt?.barillaCantidad || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1400,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2 border-r border-slate-800 print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.spt?.barillaConfiguracion || "",
											onChange: (e) => handleSptChange("barillaConfiguracion", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1414,
											columnNumber: 21
										}, this) : dt.spt?.barillaConfiguracion || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1412,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2 border-r border-slate-800 print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.spt?.conductorCalibre || "",
											onChange: (e) => handleSptChange("conductorCalibre", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1426,
											columnNumber: 21
										}, this) : dt.spt?.conductorCalibre || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1424,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2 border-r border-slate-800 print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.spt?.conductorTipoSold || "",
											onChange: (e) => handleSptChange("conductorTipoSold", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1438,
											columnNumber: 21
										}, this) : dt.spt?.conductorTipoSold || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1436,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2 border-r border-slate-800 print:border-gray-300",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.spt?.resistencia || "",
											onChange: (e) => handleSptChange("resistencia", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1450,
											columnNumber: 21
										}, this) : dt.spt?.resistencia || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1448,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-2",
										children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.spt?.fechaMedicion || "",
											onChange: (e) => handleSptChange("fechaMedicion", e.target.value),
											className: "w-full text-center bg-slate-900 border border-slate-700 rounded text-slate-100 text-xs p-1 focus:outline-none focus:border-violet-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1462,
											columnNumber: 21
										}, this) : dt.spt?.fechaMedicion || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1460,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1384,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1383,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1366,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/60 border-b border-slate-700 p-4 font-mono text-xs text-slate-200 print:bg-white print:text-black print:border-black",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-black uppercase text-slate-400 block mb-1 print:text-black",
							children: "OBSERVACIONES:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1478,
							columnNumber: 13
						}, this), isEditing ? /* @__PURE__ */ _jsxDEV("textarea", {
							value: observacionesGenerales,
							onChange: (e) => setObservacionesGenerales(e.target.value),
							rows: 3,
							className: "w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 text-xs resize-none focus:outline-none focus:border-violet-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1480,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("p", {
							className: "leading-relaxed font-medium text-slate-350 print:text-black",
							children: observacionesGenerales || "Sin observaciones registradas."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1487,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1477,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-950 text-[10px] text-slate-500 font-mono leading-relaxed border-b border-slate-700 print:bg-white print:text-black print:border-black print:text-[8px]",
						children: /* @__PURE__ */ _jsxDEV("p", { children: [
							/* @__PURE__ */ _jsxDEV("strong", { children: "LEYENDA:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 16
							}, this),
							" ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "BB" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 42
							}, this),
							" BARRA EN BUEN ESTADO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "BD" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 84
							}, this),
							" BARRA DEFECTUOSA, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "SB" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 122
							}, this),
							" SIN BARRA, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "CB" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 153
							}, this),
							" CONDUCTOR EN BUEN ESTADO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "CS" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 199
							}, this),
							" CONDUCTOR SULFATADO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "SC" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 240
							}, this),
							" SIN CONDUCTOR, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "IB" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 275
							}, this),
							" INTERRUPTOR EN BUEN ESTADO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "ID" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 323
							}, this),
							" INTERRUPTOR DEFECTUOSO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "IS" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 367
							}, this),
							" INTERRUPTOR SULFATADO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "AT" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 410
							}, this),
							" ALTA TEMPERATURA, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "CTB" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 448
							}, this),
							" COPA TERMINAL BUEN ESTADO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "CTD" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 496
							}, this),
							" COPA TERMINAL DEFECTUOSA, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "SCT" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 543
							}, this),
							" SIN COPA, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "FB" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 574
							}, this),
							" FUSIBLE EN BUEN ESTADO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "FD" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 618
							}, this),
							" FUSIBLE DEFECTUOSO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "SF" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 658
							}, this),
							" SIN FUSIBLE, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "PB" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 691
							}, this),
							" PARARRAYO EN BUEN ESTADO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "PD" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 737
							}, this),
							" PARARRAYO DEFECTUOSO, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "SP" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 779
							}, this),
							" SIN PARARRAYO. ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "SE" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 814
							}, this),
							" SOLDADURA EXOTÉRMICA, ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "KS" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1495,
								columnNumber: 856
							}, this),
							" CONECTORES EN BARRA DE TIERRA."
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1495,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1494,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-900/30 text-center print:bg-white",
						children: [fotoBlob || fotoSrc || previewUrl ? /* @__PURE__ */ _jsxDEV("div", {
							className: "max-w-md mx-auto rounded-xl overflow-hidden border border-slate-700 shadow-lg print:border-black",
							children: /* @__PURE__ */ _jsxDEV(SafeImage, {
								blob: fotoBlob,
								src: previewUrl || fotoSrc,
								alt: "Transformador Eléctrico",
								className: "w-full object-cover",
								style: { maxHeight: `${dt.fotoScale || 280}px` }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1502,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1501,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "p-6 border-2 border-dashed border-slate-800 rounded-xl text-center space-y-2 no-print",
							children: [
								/* @__PURE__ */ _jsxDEV(Camera, { className: "w-8 h-8 text-slate-600 mx-auto" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1512,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-500 font-mono block",
									children: "Sin fotografía adjunta del transformador"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1513,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("label", {
									className: "inline-block px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-violet-400 text-xs font-bold rounded-lg cursor-pointer transition-colors",
									children: ["Adjuntar Foto", /* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										accept: "image/*",
										onChange: handleImageChange,
										className: "hidden"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1516,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1514,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1511,
							columnNumber: 15
						}, this), (fotoBlob || fotoSrc || previewUrl) && /* @__PURE__ */ _jsxDEV("div", {
							className: "no-print mt-3 max-w-xs mx-auto space-y-1.5",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ajustar tamaño en PDF" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1525,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-violet-400 font-mono",
									children: [dt.fotoScale || 280, "px"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1526,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1524,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "range",
								min: "120",
								max: "380",
								value: dt.fotoScale || 280,
								onChange: (e) => handleDtChange("fotoScale", parseInt(e.target.value)),
								className: "w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-violet-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1528,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1523,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1499,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 945,
				columnNumber: 9
			}, this),
			tipoElemento === "BANCO_CONDENSADOR" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950 border-2 border-slate-700 rounded-xl overflow-hidden shadow-2xl print:border-black print:bg-white print:text-black",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border-b-2 border-slate-700 p-3.5 text-center print:bg-gray-200 print:border-black",
					children: /* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base md:text-lg font-black tracking-wide text-slate-100 uppercase font-mono print:text-black",
						children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: nombre,
							onChange: (e) => setNombre(e.target.value),
							className: "bg-slate-950 border border-slate-600 rounded px-3 py-1 text-center w-full focus:outline-none focus:border-amber-500 text-slate-100 font-bold"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1553,
							columnNumber: 17
						}, this) : `FICHA TÉCNICA - BANCO DE COMPENSACIÓN DE POTENCIA REACTIVA: ${nombre || "BC-1"}`
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1551,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1550,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "p-4 md:p-6 space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-bold text-amber-500 uppercase tracking-wider border-b border-slate-900 pb-1.5 print:text-slate-800 print:border-gray-200",
								children: "1. Datos Generales"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1569,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Código / Tag:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1574,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-slate-300 font-bold bg-slate-900 border border-slate-850 px-2.5 py-1.5 rounded-lg block print:bg-white print:border-gray-300 print:text-slate-900",
										children: elementoData.id
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1575,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1573,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Ubicación / Planta:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1581,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: ubicacion,
										onChange: (e) => setUbicacion(e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1583,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-medium px-2.5 py-1.5 bg-slate-900/50 rounded-lg border border-slate-900 block truncate print:bg-white print:border-gray-200 print:text-slate-800",
										children: ubicacion || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1590,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1580,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Alimentador:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1597,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.alimentador || "",
										onChange: (e) => handleDtChange("alimentador", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1599,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-medium px-2.5 py-1.5 bg-slate-900/50 rounded-lg border border-slate-900 block truncate print:bg-white print:border-gray-200 print:text-slate-800",
										children: dt.alimentador || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1606,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1596,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Calibre del Conductor:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1613,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.calibreConductor || "",
										onChange: (e) => handleDtChange("calibreConductor", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1615,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-medium px-2.5 py-1.5 bg-slate-900/50 rounded-lg border border-slate-900 block truncate print:bg-white print:border-gray-200 print:text-slate-800",
										children: dt.calibreConductor || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1622,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1612,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Marca / Modelo:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1629,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.marca || "",
										onChange: (e) => handleDtChange("marca", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1631,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-medium px-2.5 py-1.5 bg-slate-950/50 rounded-lg border border-slate-900 block truncate print:bg-white print:border-gray-200 print:text-slate-800",
										children: dt.marca || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1638,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1628,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Fabricante:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1645,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.fabricante || "",
										onChange: (e) => handleDtChange("fabricante", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1647,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-medium px-2.5 py-1.5 bg-slate-900/50 rounded-lg border border-slate-900 block truncate print:bg-white print:border-gray-200 print:text-slate-800",
										children: dt.fabricante || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1654,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1644,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Año de Fabricación:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1661,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.anioFabricacion || "",
										onChange: (e) => handleDtChange("anioFabricacion", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1663,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-medium px-2.5 py-1.5 bg-slate-900/50 rounded-lg border border-slate-900 block truncate print:bg-white print:border-gray-200 print:text-slate-800",
										children: dt.anioFabricacion || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1670,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1660,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1572,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1568,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-bold text-amber-500 uppercase tracking-wider border-b border-slate-900 pb-1.5 print:text-slate-800 print:border-gray-200",
								children: "2. Parámetros Eléctricos Nominales de la Red"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1680,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Tensión Nominal (V / kV):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1685,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.tensionNominal || "",
										onChange: (e) => handleDtChange("tensionNominal", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1687,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-bold px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.tensionNominal || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1694,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1684,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Tensión Registrada (V / kV):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1699,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.tensionRegistrada || "",
										onChange: (e) => handleDtChange("tensionRegistrada", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1701,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-bold px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.tensionRegistrada || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1708,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1698,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Frecuencia:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1713,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.frecuencia || "60 Hz",
										onChange: (e) => handleDtChange("frecuencia", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "50 Hz",
											children: "50 Hz"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1720,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("option", {
											value: "60 Hz",
											children: "60 Hz"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1721,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1715,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.frecuencia || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1724,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1712,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Potencia Reactiva Total (kVAR):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1729,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.potenciaReactivaTotal || "",
										onChange: (e) => handleDtChange("potenciaReactivaTotal", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1731,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-bold px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.potenciaReactivaTotal || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1738,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1728,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Corriente Nominal Total (A):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1743,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.corrienteNominalTotal || "",
										onChange: (e) => handleDtChange("corrienteNominalTotal", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1745,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-bold px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.corrienteNominalTotal || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1752,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1742,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Nro. Fases:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1757,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.numFases || "Trifásico",
										onChange: (e) => handleDtChange("numFases", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Monofásico",
												children: "Monofásico"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1764,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Bifásico",
												children: "Bifásico"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1765,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Trifásico",
												children: "Trifásico"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1766,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1759,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.numFases || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1769,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1756,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Conexión:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1774,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.conexion || "Estrella",
										onChange: (e) => handleDtChange("conexion", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "Delta",
											children: "Delta"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1781,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("option", {
											value: "Estrella",
											children: "Estrella"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1782,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1776,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.conexion || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1785,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1773,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Nivel de Aislamiento BIL (kV):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1790,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.nivelAislamientoBIL || "",
										onChange: (e) => handleDtChange("nivelAislamientoBIL", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1792,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.nivelAislamientoBIL || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1799,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1789,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1683,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1679,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold text-amber-500 uppercase tracking-wider border-b border-slate-900 pb-1.5 print:text-slate-800 print:border-gray-200",
									children: "3. Configuración y Pasos de Compensación"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1807,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
											children: "Tipo de Compensación:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1812,
											columnNumber: 19
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
											value: dt.tipoCompensacion || "Automática (Pasos)",
											onChange: (e) => handleDtChange("tipoCompensacion", e.target.value),
											className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Fija",
													children: "Fija"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1819,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Automática (Pasos)",
													children: "Automática (Pasos)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1820,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Dinámica (Tiristores/SVG)",
													children: "Dinámica (Tiristores/SVG)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1821,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1814,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-200 font-bold px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
											children: dt.tipoCompensacion || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1824,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1811,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
											children: "Nro. Total de Pasos:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1829,
											columnNumber: 19
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.numPasos || "",
											onChange: (e) => handleDtChange("numPasos", e.target.value),
											className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1831,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
											children: dt.numPasos || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1838,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1828,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
											children: "Secuencia de Pasos (kVAR):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1843,
											columnNumber: 19
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.secuenciaPasosKvar || "",
											onChange: (e) => handleDtChange("secuenciaPasosKvar", e.target.value),
											placeholder: "Ej. 50+50+100+100 kVAR",
											className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1845,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white font-mono",
											children: dt.secuenciaPasosKvar || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1853,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1842,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
											children: "Tipo de Conmutación:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1858,
											columnNumber: 19
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
											value: dt.tipoConmutacion || "Contactores dedicados",
											onChange: (e) => handleDtChange("tipoConmutacion", e.target.value),
											className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
											children: [/* @__PURE__ */ _jsxDEV("option", {
												value: "Contactores dedicados",
												children: "Contactores dedicados"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1865,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("option", {
												value: "Interruptores estáticos",
												children: "Interruptores estáticos"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1866,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1860,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
											children: dt.tipoConmutacion || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1869,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1857,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1810,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between items-center",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-bold text-slate-300 uppercase tracking-wide",
											children: "Registro de Corriente por Paso (Auditoría en Campo):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1877,
											columnNumber: 19
										}, this), isEditing && /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => {
												const current = dt.pasosAuditoria || [];
												const nextNum = current.length + 1;
												handleDtChange("pasosAuditoria", [...current, {
													paso: nextNum,
													kvar: "",
													iNominal: "",
													iL1: "",
													iL2: "",
													iL3: "",
													estado: "Operativo"
												}]);
											},
											className: "px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/40 rounded text-[10px] font-bold transition-all cursor-pointer",
											children: "+ Agregar Paso"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1881,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1876,
										columnNumber: 17
									}, this), dt.pasosAuditoria && dt.pasosAuditoria.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
										className: "overflow-x-auto border border-slate-800 rounded-lg",
										children: /* @__PURE__ */ _jsxDEV("table", {
											className: "w-full text-[11px] text-left",
											children: [/* @__PURE__ */ _jsxDEV("thead", {
												className: "bg-slate-900 text-slate-400 font-bold border-b border-slate-800",
												children: /* @__PURE__ */ _jsxDEV("tr", { children: [
													/* @__PURE__ */ _jsxDEV("th", {
														className: "p-2",
														children: "Paso"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1902,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "p-2",
														children: "Potencia (kVAR)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1903,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "p-2",
														children: "I Nominal (A)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1904,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "p-2",
														children: "I L1 (A)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1905,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "p-2",
														children: "I L2 (A)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1906,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "p-2",
														children: "I L3 (A)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1907,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("th", {
														className: "p-2",
														children: "Estado"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1908,
														columnNumber: 27
													}, this),
													isEditing && /* @__PURE__ */ _jsxDEV("th", {
														className: "p-2 text-center",
														children: "Acción"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1909,
														columnNumber: 41
													}, this)
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1901,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1900,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("tbody", {
												className: "divide-y divide-slate-850 text-slate-200",
												children: dt.pasosAuditoria.map((p, idx) => /* @__PURE__ */ _jsxDEV("tr", { children: [
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-2 font-mono font-bold text-amber-500",
														children: ["Paso #", p.paso || idx + 1]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1915,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-2",
														children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
															type: "text",
															value: p.kvar || "",
															onChange: (e) => {
																const updated = [...dt.pasosAuditoria];
																updated[idx] = {
																	...updated[idx],
																	kvar: e.target.value
																};
																handleDtChange("pasosAuditoria", updated);
															},
															placeholder: "kVAR",
															className: "w-16 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center focus:border-amber-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1918,
															columnNumber: 33
														}, this) : p.kvar ? `${p.kvar} kVAR` : "—"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1916,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-2",
														children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
															type: "text",
															value: p.iNominal || "",
															onChange: (e) => {
																const updated = [...dt.pasosAuditoria];
																updated[idx] = {
																	...updated[idx],
																	iNominal: e.target.value
																};
																handleDtChange("pasosAuditoria", updated);
															},
															placeholder: "A",
															className: "w-16 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center focus:border-amber-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1933,
															columnNumber: 33
														}, this) : p.iNominal ? `${p.iNominal} A` : "—"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1931,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-2",
														children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
															type: "text",
															value: p.iL1 || "",
															onChange: (e) => {
																const updated = [...dt.pasosAuditoria];
																updated[idx] = {
																	...updated[idx],
																	iL1: e.target.value
																};
																handleDtChange("pasosAuditoria", updated);
															},
															placeholder: "A",
															className: "w-16 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center focus:border-amber-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1948,
															columnNumber: 33
														}, this) : p.iL1 ? `${p.iL1} A` : "—"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1946,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-2",
														children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
															type: "text",
															value: p.iL2 || "",
															onChange: (e) => {
																const updated = [...dt.pasosAuditoria];
																updated[idx] = {
																	...updated[idx],
																	iL2: e.target.value
																};
																handleDtChange("pasosAuditoria", updated);
															},
															placeholder: "A",
															className: "w-16 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center focus:border-amber-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1963,
															columnNumber: 33
														}, this) : p.iL2 ? `${p.iL2} A` : "—"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1961,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-2",
														children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
															type: "text",
															value: p.iL3 || "",
															onChange: (e) => {
																const updated = [...dt.pasosAuditoria];
																updated[idx] = {
																	...updated[idx],
																	iL3: e.target.value
																};
																handleDtChange("pasosAuditoria", updated);
															},
															placeholder: "A",
															className: "w-16 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center focus:border-amber-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1978,
															columnNumber: 33
														}, this) : p.iL3 ? `${p.iL3} A` : "—"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1976,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "p-2",
														children: isEditing ? /* @__PURE__ */ _jsxDEV("select", {
															value: p.estado || "Operativo",
															onChange: (e) => {
																const updated = [...dt.pasosAuditoria];
																updated[idx] = {
																	...updated[idx],
																	estado: e.target.value
																};
																handleDtChange("pasosAuditoria", updated);
															},
															className: "bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-xs text-slate-200 focus:border-amber-500",
															children: [
																/* @__PURE__ */ _jsxDEV("option", {
																	value: "Operativo",
																	children: "Operativo"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2002,
																	columnNumber: 35
																}, this),
																/* @__PURE__ */ _jsxDEV("option", {
																	value: "Capacitor Débil / Desbalanceado",
																	children: "Capacitor Débil"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2003,
																	columnNumber: 35
																}, this),
																/* @__PURE__ */ _jsxDEV("option", {
																	value: "Desconectado",
																	children: "Desconectado"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2004,
																	columnNumber: 35
																}, this),
																/* @__PURE__ */ _jsxDEV("option", {
																	value: "Dañado / Fuga Dieléctrica",
																	children: "Dañado"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 2005,
																	columnNumber: 35
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1993,
															columnNumber: 33
														}, this) : /* @__PURE__ */ _jsxDEV("span", {
															className: `px-2 py-0.5 rounded text-[10px] font-bold ${p.estado === "Operativo" ? "bg-emerald-950 text-emerald-400 border border-emerald-800" : p.estado === "Capacitor Débil / Desbalanceado" ? "bg-amber-950 text-amber-400 border border-amber-800" : "bg-red-950 text-red-400 border border-red-800"}`,
															children: p.estado || "Operativo"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2008,
															columnNumber: 33
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1991,
														columnNumber: 29
													}, this),
													isEditing && /* @__PURE__ */ _jsxDEV("td", {
														className: "p-2 text-center",
														children: /* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => {
																const updated = dt.pasosAuditoria.filter((_, i) => i !== idx);
																handleDtChange("pasosAuditoria", updated);
															},
															className: "text-red-400 hover:text-red-300 p-1 text-xs",
															title: "Eliminar paso",
															children: "✕"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2019,
															columnNumber: 33
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2018,
														columnNumber: 31
													}, this)
												] }, idx, true, {
													fileName: _jsxFileName,
													lineNumber: 1914,
													columnNumber: 27
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1912,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1899,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1898,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-500 italic bg-slate-950/40 p-2.5 rounded-lg border border-slate-900",
										children: ["Sin registros individuales de pasos. ", isEditing ? "Haz clic en \"+ Agregar Paso\" para auditar corrientes." : ""]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2038,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1875,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1806,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-bold text-amber-500 uppercase tracking-wider border-b border-slate-900 pb-1.5 print:text-slate-800 print:border-gray-200",
								children: "4. Unidades de Condensadores (Módulos)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2047,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Potencia Individual (kVAR):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2052,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.potenciaIndividual || "",
										onChange: (e) => handleDtChange("potenciaIndividual", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2054,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.potenciaIndividual || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2061,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2051,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Capacitancia (µF):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2066,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.capacitanciaMuf || "",
										onChange: (e) => handleDtChange("capacitanciaMuf", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2068,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.capacitanciaMuf || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2075,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2065,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Tensión del Condensador (V):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2080,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.tensionCondensador || "",
										onChange: (e) => handleDtChange("tensionCondensador", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2082,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.tensionCondensador || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2089,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2079,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Tecnología Dieléctrica:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2094,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.tecnologiaDielectrica || "Polipropileno metalizado",
										onChange: (e) => handleDtChange("tecnologiaDielectrica", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2096,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.tecnologiaDielectrica || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2103,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2093,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Resistencia de Descarga:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2108,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.resistenciaDescarga || "Sí",
										onChange: (e) => handleDtChange("resistenciaDescarga", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "Sí",
											children: "Sí (<50V en <60s)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2115,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("option", {
											value: "No",
											children: "No"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2116,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2110,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.resistenciaDescarga || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2119,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2107,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Seguridad:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2124,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.seguridad || "Desconectador por sobrepresión",
										onChange: (e) => handleDtChange("seguridad", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2126,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.seguridad || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2133,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2123,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2050,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2046,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-bold text-amber-500 uppercase tracking-wider border-b border-slate-900 pb-1.5 print:text-slate-800 print:border-gray-200",
								children: "5. Reactancias Antiharmónicas / Filtros"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2141,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Factor de Desintonización (p%):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2146,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.factorDesintonizacion || "N/A",
										onChange: (e) => handleDtChange("factorDesintonizacion", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "7% (189 Hz)",
												children: "7% (189 Hz)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2153,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "14% (134 Hz)",
												children: "14% (134 Hz)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2154,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "N/A",
												children: "N/A"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2155,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2148,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.factorDesintonizacion || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2158,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2145,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Tipo de Núcleo:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2163,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.tipoNucleo || "Núcleo de Hierro con Entrehierro",
										onChange: (e) => handleDtChange("tipoNucleo", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "Núcleo de Hierro con Entrehierro",
											children: "Núcleo de Hierro con Entrehierro"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2170,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("option", {
											value: "Aire",
											children: "Aire"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2171,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2165,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.tipoNucleo || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2174,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2162,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Aislamiento Térmico:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2179,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.claseAislamientoTermico || "Clase H (180°C)",
										onChange: (e) => handleDtChange("claseAislamientoTermico", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2181,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.claseAislamientoTermico || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2188,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2178,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Protección Térmica:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2193,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.proteccionTermica || "Sensor Bimetálico / PT100 integrado",
										onChange: (e) => handleDtChange("proteccionTermica", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2195,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.proteccionTermica || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2202,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2192,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2144,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2140,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-bold text-amber-500 uppercase tracking-wider border-b border-slate-900 pb-1.5 print:text-slate-800 print:border-gray-200",
								children: "6. Regulador y Protecciones"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2210,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "lg:col-span-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
											children: "Regulador de FP (Marca / Modelo / Rango):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2215,
											columnNumber: 19
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.reguladorMarcaModelo || "",
											onChange: (e) => handleDtChange("reguladorMarcaModelo", e.target.value),
											className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2217,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
											children: dt.reguladorMarcaModelo || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2224,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2214,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Relación de TC Requerida:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2229,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.relacionTc || "",
										onChange: (e) => handleDtChange("relacionTc", e.target.value),
										placeholder: "Ej. 1600/5A",
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2231,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white font-mono",
										children: dt.relacionTc || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2239,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2228,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Puerto de Comunicación:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2244,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.puertoComunicacion || "RS-485 (Modbus RTU)",
										onChange: (e) => handleDtChange("puertoComunicacion", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "RS-485 (Modbus RTU)",
												children: "RS-485 (Modbus RTU)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2251,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Ethernet (Modbus TCP)",
												children: "Ethernet (Modbus TCP)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2252,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Ninguno",
												children: "Ninguno"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2253,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2246,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.puertoComunicacion || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2256,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2243,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Interruptor Principal (A):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2261,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.interruptorPrincipalAmp || "",
										onChange: (e) => handleDtChange("interruptorPrincipalAmp", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2263,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-bold px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.interruptorPrincipalAmp ? dt.interruptorPrincipalAmp + " A" : "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2270,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2260,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Protección de Pasos:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2275,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.proteccionPasos || "Fusibles",
										onChange: (e) => handleDtChange("proteccionPasos", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "Fusibles",
											children: "Fusibles"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2282,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("option", {
											value: "Breakers",
											children: "Breakers"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2283,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2277,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.proteccionPasos || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2286,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2274,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2213,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2209,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-bold text-amber-500 uppercase tracking-wider border-b border-slate-900 pb-1.5 print:text-slate-800 print:border-gray-200",
								children: "7. Gabinete y Entorno de Operación"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2294,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Grado de Protección Envolvente:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2299,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.gradoProteccionEnvolvente || "IP54",
										onChange: (e) => handleDtChange("gradoProteccionEnvolvente", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "IP41",
												children: "IP41"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2306,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "IP54",
												children: "IP54"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2307,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "NEMA 3R",
												children: "NEMA 3R"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2308,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2301,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.gradoProteccionEnvolvente || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2311,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2298,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Dimensiones (Al x An x Pr):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2316,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("div", {
										className: "flex gap-1.5 items-center",
										children: [
											/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: dt.dimensionesAlto || "",
												onChange: (e) => handleDtChange("dimensionesAlto", e.target.value),
												placeholder: "Al",
												className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2 py-1.5 text-slate-100 focus:border-amber-500 text-center"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2319,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: "x" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2326,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: dt.dimensionesAncho || "",
												onChange: (e) => handleDtChange("dimensionesAncho", e.target.value),
												placeholder: "An",
												className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 text-center"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2327,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: "x" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2334,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: dt.dimensionesProf || "",
												onChange: (e) => handleDtChange("dimensionesProf", e.target.value),
												placeholder: "Pr",
												className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 text-center"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2335,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px]",
												children: "mm"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2342,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2318,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white font-mono",
										children: [
											dt.dimensionesAlto || "—",
											" x ",
											dt.dimensionesAncho || "—",
											" x ",
											dt.dimensionesProf || "—",
											" mm"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2345,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2315,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Sistema de Enfriamiento:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2352,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.sistemaEnfriamiento || "Ventilación Forzada",
										onChange: (e) => handleDtChange("sistemaEnfriamiento", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Ventilación Natural",
												children: "Ventilación Natural"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2359,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Ventilación Forzada",
												children: "Ventilación Forzada"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2360,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Extractores y Filtros",
												children: "Extractores y Filtros"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2361,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2354,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white",
										children: dt.sistemaEnfriamiento || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2364,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2351,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Temperatura / Humedad:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2369,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.temperaturaC || "",
											onChange: (e) => handleDtChange("temperaturaC", e.target.value),
											placeholder: "°C",
											className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 text-center"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2372,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.humedadPct || "",
											onChange: (e) => handleDtChange("humedadPct", e.target.value),
											placeholder: "%",
											className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 text-center"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2379,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2371,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:text-black print:bg-white font-mono",
										children: [
											dt.temperaturaC ? dt.temperaturaC + " °C" : "—",
											" / ",
											dt.humedadPct ? dt.humedadPct + " %" : "—"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2388,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2368,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2297,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2293,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-700",
								children: "Observaciones Generales y Recomendaciones"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2398,
								columnNumber: 15
							}, this), isEditing ? /* @__PURE__ */ _jsxDEV("textarea", {
								value: observacionesGenerales,
								onChange: (e) => setObservacionesGenerales(e.target.value),
								rows: 4,
								className: "w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all font-sans resize-none",
								placeholder: "Escriba las condiciones del banco de compensación, problemas en celdas, desbalance en corriente de condensadores, estado de contactores..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2400,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs leading-relaxed text-slate-300 font-sans italic bg-slate-900/40 p-4 rounded-xl border border-slate-900 print:text-black print:bg-white print:border-gray-300",
								children: observacionesGenerales || "No se han registrado observaciones específicas para este banco de condensadores."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2408,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2397,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-4 border-t border-slate-900/60 flex flex-col items-center gap-4",
							children: [fotoBlob || fotoSrc || previewUrl ? /* @__PURE__ */ _jsxDEV("div", {
								className: "relative group rounded-xl overflow-hidden border border-slate-800 shadow-lg max-w-sm",
								children: /* @__PURE__ */ _jsxDEV(SafeImage, {
									blob: fotoBlob,
									src: fotoSrc,
									alt: nombre,
									className: "object-contain w-full rounded-xl",
									style: { maxHeight: `${dt.fotoScale || 280}px` }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2418,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2417,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "p-6 border-2 border-dashed border-slate-800 rounded-xl text-center space-y-2 no-print",
								children: [
									/* @__PURE__ */ _jsxDEV(Camera, { className: "w-8 h-8 text-slate-600 mx-auto" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2428,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-500 font-mono block",
										children: "Sin fotografía adjunta del banco de condensadores"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2429,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("label", {
										className: "inline-block px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-bold rounded-lg cursor-pointer transition-colors",
										children: ["Adjuntar Foto", /* @__PURE__ */ _jsxDEV("input", {
											type: "file",
											accept: "image/*",
											onChange: handleImageChange,
											className: "hidden"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2432,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2430,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2427,
								columnNumber: 17
							}, this), (fotoBlob || fotoSrc || previewUrl) && /* @__PURE__ */ _jsxDEV("div", {
								className: "no-print mt-3 max-w-xs mx-auto space-y-1.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ajustar tamaño en PDF" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2441,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-cyan-400 font-mono",
										children: [dt.fotoScale || 280, "px"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2442,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2440,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "range",
									min: "120",
									max: "380",
									value: dt.fotoScale || 280,
									onChange: (e) => handleDtChange("fotoScale", parseInt(e.target.value)),
									className: "w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2444,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2439,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2415,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1565,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1547,
				columnNumber: 9
			}, this),
			tipoElemento === "PUESTA_TIERRA" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950 border-2 border-slate-700 rounded-xl overflow-hidden shadow-2xl print:border-black print:bg-white print:text-black",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border-b-2 border-slate-700 p-3.5 text-center print:bg-gray-200 print:border-black",
					children: /* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base md:text-lg font-black tracking-wide text-slate-100 uppercase font-mono print:text-black",
						children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: nombre,
							onChange: (e) => setNombre(e.target.value),
							className: "bg-slate-950 border border-slate-600 rounded px-3 py-1 text-center w-full focus:outline-none focus:border-amber-500 text-slate-100 font-bold"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2471,
							columnNumber: 17
						}, this) : `FICHA TÉCNICA - SISTEMA DE PUESTA A TIERRA (PAT): ${nombre || "PAT-1"}`
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 2469,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 2468,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "p-4 md:p-6 space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-bold text-amber-500 uppercase tracking-wider border-b border-slate-900 pb-1.5 print:text-slate-800 print:border-gray-200",
								children: "1. Datos Generales de la Puesta a Tierra"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2487,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Código / Tag:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2492,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-slate-300 font-bold bg-slate-900 border border-slate-850 px-2.5 py-1.5 rounded-lg block print:bg-white print:border-gray-300 print:text-slate-900",
										children: elementoData.id
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2493,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2491,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Ubicación / Área:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2499,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: ubicacion,
										onChange: (e) => setUbicacion(e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2501,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-medium px-2.5 py-1.5 bg-slate-900/50 rounded-lg border border-slate-900 block truncate print:bg-white print:border-gray-200 print:text-slate-800",
										children: ubicacion || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2508,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2498,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Equipo Protegido / Vinculado:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2515,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.equipoVinculado || "",
										onChange: (e) => handleDtChange("equipoVinculado", e.target.value),
										placeholder: "Ej. Subestación Principal / Tablero TAB-1",
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2517,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-medium px-2.5 py-1.5 bg-slate-900/50 rounded-lg border border-slate-900 block truncate print:bg-white print:border-gray-200 print:text-slate-800",
										children: dt.equipoVinculado || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2525,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2514,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Fecha de Medición:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2532,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "date",
										value: dt.fechaMedicion || "",
										onChange: (e) => handleDtChange("fechaMedicion", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2534,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-medium px-2.5 py-1.5 bg-slate-900/50 rounded-lg border border-slate-900 block print:bg-white print:border-gray-200 print:text-slate-800",
										children: dt.fechaMedicion || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2541,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2531,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2490,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2486,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-bold text-amber-500 uppercase tracking-wider border-b border-slate-900 pb-1.5 print:text-slate-800 print:border-gray-200",
								children: "2. Medición de Telurometría y Conformidad Normativa (IEEE 80 / CEN)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2551,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Resistencia Medida (Ω):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2556,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										step: "0.01",
										value: dt.resistenciaOhms || dt.resistencia || "",
										onChange: (e) => {
											handleDtChange("resistenciaOhms", e.target.value);
											handleDtChange("resistencia", e.target.value);
										},
										placeholder: "Ej. 2.45",
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 font-mono font-bold"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2558,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-amber-400 font-mono font-extrabold text-base px-2.5 py-1 bg-slate-900/80 rounded-lg border border-slate-800 block print:bg-white print:text-black",
										children: dt.resistenciaOhms || dt.resistencia ? `${dt.resistenciaOhms || dt.resistencia} Ω` : "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2570,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2555,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Estado de Conformidad:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2577,
										columnNumber: 19
									}, this), (() => {
										const r = parseFloat(dt.resistenciaOhms || dt.resistencia);
										if (isNaN(r)) return /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400",
											children: "Sin Medición"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2580,
											columnNumber: 42
										}, this);
										if (r <= 5) {
											return /* @__PURE__ */ _jsxDEV("span", {
												className: "px-2.5 py-1.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded-lg font-bold block text-center",
												children: "🟢 Conforme (≤ 5.0 Ω)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2583,
												columnNumber: 25
											}, this);
										} else if (r <= 10) {
											return /* @__PURE__ */ _jsxDEV("span", {
												className: "px-2.5 py-1.5 bg-amber-950 text-amber-400 border border-amber-800 rounded-lg font-bold block text-center",
												children: "🟡 Aceptable Secundario (≤ 10.0 Ω)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2589,
												columnNumber: 25
											}, this);
										} else {
											return /* @__PURE__ */ _jsxDEV("span", {
												className: "px-2.5 py-1.5 bg-red-950 text-red-400 border border-red-800 rounded-lg font-bold block text-center",
												children: "🔴 No Conforme (> 10.0 Ω)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2595,
												columnNumber: 25
											}, this);
										}
									})()] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2576,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Método de Medición:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2604,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.metodoMedicion || "Caída de Potencial (62%)",
										onChange: (e) => handleDtChange("metodoMedicion", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Caída de Potencial (62%)",
												children: "Caída de Potencial (62%)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2611,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Método de 3 Puntos",
												children: "Método de 3 Puntos"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2612,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Método Wenner (4 Picas)",
												children: "Método Wenner (4 Picas)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2613,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Pinza de Tierra (Sin Picas)",
												children: "Pinza de Tierra (Sin Picas)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2614,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2606,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:bg-white print:text-black",
										children: dt.metodoMedicion || "Caída de Potencial (62%)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2617,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2603,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Telurómetro Utilizado:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2624,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.telurometroMarcaModelo || "",
										onChange: (e) => handleDtChange("telurometroMarcaModelo", e.target.value),
										placeholder: "Ej. Megger DET4TD2 / Fluke 1625",
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2626,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:bg-white print:text-black",
										children: dt.telurometroMarcaModelo || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2634,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2623,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2554,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2550,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-bold text-amber-500 uppercase tracking-wider border-b border-slate-900 pb-1.5 print:text-slate-800 print:border-gray-200",
								children: "3. Configuración Física de la Malla y Electrodos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2644,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Tipo de Sistema:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2649,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.tipoSistemaPat || "Malla con Varillas",
										onChange: (e) => handleDtChange("tipoSistemaPat", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Malla con Varillas",
												children: "Malla con Varillas"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2656,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Pozo Individual",
												children: "Pozo Individual"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2657,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Anillo Perimetral Equipotencial",
												children: "Anillo Perimetral Equipotencial"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2658,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Pata de Ganso",
												children: "Pata de Ganso"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2659,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2651,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:bg-white print:text-black",
										children: dt.tipoSistemaPat || "Malla con Varillas"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2662,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2648,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Nro. de Varillas / Picas:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2669,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.spt?.barillaCantidad || dt.numVarillas || "",
										onChange: (e) => handleDtChange("numVarillas", e.target.value),
										placeholder: "Ej. 4 (5/8'' x 2.4m)",
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2671,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:bg-white print:text-black",
										children: dt.spt?.barillaCantidad || dt.numVarillas || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2679,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2668,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Calibre Conductor (GEC):"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2686,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.spt?.conductorCalibre || dt.calibreConductor || "",
										onChange: (e) => handleDtChange("calibreConductor", e.target.value),
										placeholder: "Ej. 2/0 AWG Cu Desnudo",
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2688,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:bg-white print:text-black",
										children: dt.spt?.conductorCalibre || dt.calibreConductor || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2696,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2685,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 block font-semibold mb-1 print:text-slate-600",
										children: "Tipo de Unión / Soldadura:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2703,
										columnNumber: 19
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.tipoUnion || "Soldadura Exotérmica (Cadweld)",
										onChange: (e) => handleDtChange("tipoUnion", e.target.value),
										className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-amber-500 h-9",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Soldadura Exotérmica (Cadweld)",
												children: "Soldadura Exotérmica (Cadweld)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2710,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Conector Mecánico (Grapa de Bronce)",
												children: "Conector Mecánico (Grapa de Bronce)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2711,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Terminal a Compresión",
												children: "Terminal a Compresión"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2712,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2705,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 px-2.5 py-1.5 bg-slate-900/50 rounded-lg block print:bg-white print:text-black",
										children: dt.tipoUnion || "Soldadura Exotérmica (Cadweld)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2715,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2702,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2647,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2643,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-center border-b border-slate-900 pb-1.5",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold text-amber-500 uppercase tracking-wider print:text-slate-800 print:border-gray-200",
									children: "4. Inspección Termográfica y Puntos Calientes en Conexiones"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2726,
									columnNumber: 17
								}, this), isEditing && /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										const current = dt.puntosTermograficos || [];
										handleDtChange("puntosTermograficos", [...current, {
											punto: `Punto #${current.length + 1}`,
											tSpot: "",
											tRef: "",
											componente: "Borne / Terminal"
										}]);
									},
									className: "px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/40 rounded text-[10px] font-bold cursor-pointer transition-all",
									children: "+ Agregar Punto Termográfico"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2730,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2725,
								columnNumber: 15
							}, this), dt.puntosTermograficos && dt.puntosTermograficos.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
								className: "overflow-x-auto border border-slate-800 rounded-lg",
								children: /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-[11px] text-left",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-slate-900 text-slate-400 font-bold border-b border-slate-800",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2",
												children: "Componente / Punto"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2751,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2",
												children: "T. Medida (°C)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2752,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2",
												children: "T. Referencia (°C)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2753,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2",
												children: "ΔT Calculado"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2754,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2",
												children: "Severidad NETA/NFPA"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2755,
												columnNumber: 25
											}, this),
											isEditing && /* @__PURE__ */ _jsxDEV("th", {
												className: "p-2 text-center",
												children: "Acción"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2756,
												columnNumber: 39
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2750,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2749,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-slate-850 text-slate-200",
										children: dt.puntosTermograficos.map((pt, idx) => {
											const spot = parseFloat(pt.tSpot);
											const ref = parseFloat(pt.tRef);
											const deltaT = !isNaN(spot) && !isNaN(ref) ? (spot - ref).toFixed(1) : null;
											const deltaNum = deltaT !== null ? parseFloat(deltaT) : null;
											return /* @__PURE__ */ _jsxDEV("tr", { children: [
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-2",
													children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
														type: "text",
														value: pt.componente || "",
														onChange: (e) => {
															const updated = [...dt.puntosTermograficos];
															updated[idx] = {
																...updated[idx],
																componente: e.target.value
															};
															handleDtChange("puntosTermograficos", updated);
														},
														placeholder: "Ej. Borne barra de tierra",
														className: "w-full bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-xs text-slate-100"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2770,
														columnNumber: 33
													}, this) : pt.componente || "Borne de Conexión"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2768,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-2",
													children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
														type: "number",
														step: "0.1",
														value: pt.tSpot || "",
														onChange: (e) => {
															const updated = [...dt.puntosTermograficos];
															updated[idx] = {
																...updated[idx],
																tSpot: e.target.value
															};
															handleDtChange("puntosTermograficos", updated);
														},
														placeholder: "°C",
														className: "w-16 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2785,
														columnNumber: 33
													}, this) : pt.tSpot ? `${pt.tSpot} °C` : "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2783,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-2",
													children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
														type: "number",
														step: "0.1",
														value: pt.tRef || "",
														onChange: (e) => {
															const updated = [...dt.puntosTermograficos];
															updated[idx] = {
																...updated[idx],
																tRef: e.target.value
															};
															handleDtChange("puntosTermograficos", updated);
														},
														placeholder: "°C",
														className: "w-16 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2801,
														columnNumber: 33
													}, this) : pt.tRef ? `${pt.tRef} °C` : "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2799,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-2 font-mono font-bold",
													children: deltaT !== null ? `${deltaT > 0 ? "+" : ""}${deltaT} °C` : "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2815,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-2",
													children: deltaNum !== null ? deltaNum > 20 ? /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2 py-0.5 bg-red-950 text-red-400 border border-red-800 rounded text-[10px] font-bold",
														children: "🔴 Crítica (Acción Inmediata)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2821,
														columnNumber: 35
													}, this) : deltaNum > 10 ? /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2 py-0.5 bg-amber-950 text-amber-400 border border-amber-800 rounded text-[10px] font-bold",
														children: "🟡 Moderada (Mantenimiento)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2825,
														columnNumber: 35
													}, this) : /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded text-[10px] font-bold",
														children: "🟢 Normal"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2829,
														columnNumber: 35
													}, this) : /* @__PURE__ */ _jsxDEV("span", {
														className: "text-slate-500",
														children: "Pendiente"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2833,
														columnNumber: 35
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2818,
													columnNumber: 29
												}, this),
												isEditing && /* @__PURE__ */ _jsxDEV("td", {
													className: "p-2 text-center",
													children: /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => {
															const updated = dt.puntosTermograficos.filter((_, i) => i !== idx);
															handleDtChange("puntosTermograficos", updated);
														},
														className: "text-red-400 hover:text-red-300 p-1 text-xs",
														children: "✕"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2837,
														columnNumber: 33
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2836,
													columnNumber: 31
												}, this)
											] }, idx, true, {
												fileName: _jsxFileName,
												lineNumber: 2767,
												columnNumber: 27
											}, this);
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2759,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2748,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2747,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] text-slate-500 italic bg-slate-900/40 p-2.5 rounded-lg border border-slate-900",
								children: ["Sin registros de anomalías térmicas en este electrodo/malla. ", isEditing ? "Haz clic en \"+ Agregar Punto Termográfico\" para registrar inspección." : ""]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2856,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2724,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-700",
								children: "5. Observaciones Técnicas y Recomendaciones"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2864,
								columnNumber: 15
							}, this), isEditing ? /* @__PURE__ */ _jsxDEV("textarea", {
								value: observacionesGenerales,
								onChange: (e) => setObservacionesGenerales(e.target.value),
								rows: 4,
								className: "w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 font-sans resize-none",
								placeholder: "Escriba observaciones sobre corrosión en soldaduras, sulfatación en barras, estado de la caja de inspección..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2868,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs leading-relaxed text-slate-300 font-sans italic bg-slate-900/40 p-4 rounded-xl border border-slate-900 print:text-black print:bg-white print:border-gray-300",
								children: observacionesGenerales || "Sin observaciones específicas registradas para este sistema de puesta a tierra."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2876,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2863,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-4 border-t border-slate-900/60 flex flex-col items-center gap-4",
							children: [fotoBlob || fotoSrc || previewUrl ? /* @__PURE__ */ _jsxDEV("div", {
								className: "relative group rounded-xl overflow-hidden border border-slate-800 shadow-lg max-w-sm",
								children: /* @__PURE__ */ _jsxDEV(SafeImage, {
									blob: fotoBlob,
									src: fotoSrc,
									alt: nombre,
									className: "object-contain w-full rounded-xl",
									style: { maxHeight: `${dt.fotoScale || 280}px` }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2886,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2885,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "p-6 border-2 border-dashed border-slate-800 rounded-xl text-center space-y-2 no-print",
								children: [
									/* @__PURE__ */ _jsxDEV(Camera, { className: "w-8 h-8 text-slate-600 mx-auto" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2896,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-500 font-mono block",
										children: "Sin fotografía adjunta de la puesta a tierra"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2897,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("label", {
										className: "inline-block px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold rounded-lg cursor-pointer transition-colors",
										children: ["Adjuntar Foto", /* @__PURE__ */ _jsxDEV("input", {
											type: "file",
											accept: "image/*",
											onChange: handleImageChange,
											className: "hidden"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2900,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2898,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2895,
								columnNumber: 17
							}, this), (fotoBlob || fotoSrc || previewUrl) && /* @__PURE__ */ _jsxDEV("div", {
								className: "no-print mt-3 max-w-xs mx-auto space-y-1.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ajustar tamaño en PDF" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2908,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-amber-400 font-mono",
										children: [dt.fotoScale || 280, "px"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2909,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2907,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "range",
									min: "120",
									max: "380",
									value: dt.fotoScale || 280,
									onChange: (e) => handleDtChange("fotoScale", parseInt(e.target.value)),
									className: "w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2911,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2906,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2883,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2483,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 2465,
				columnNumber: 9
			}, this),
			tipoElemento === "PUNTO_SUMINISTRO" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950 border-2 border-slate-700 rounded-xl overflow-hidden shadow-2xl print:border-black print:bg-white print:text-black",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border-b-2 border-slate-700 p-3.5 text-center print:bg-gray-200 print:border-black",
						children: /* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base md:text-lg font-black tracking-wide text-slate-100 uppercase font-mono print:text-black",
							children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: nombre,
								onChange: (e) => setNombre(e.target.value),
								placeholder: "Ej. PUNTO DE SUMINISTRO PRINCIPAL",
								className: "bg-slate-950 border border-slate-600 rounded px-3 py-1 text-center w-full focus:outline-none focus:border-amber-500 text-slate-100 font-bold placeholder-slate-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2938,
								columnNumber: 17
							}, this) : `PLANILLA DE LEVANTAMIENTO TÉCNICO: ${nombre || "PUNTO DE SUMINISTRO / ACOMETIDA"}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2936,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 2935,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-xs text-left border-collapse border-b border-slate-700 font-mono print:border-black",
						children: /* @__PURE__ */ _jsxDEV("tbody", { children: [
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 print:border-gray-300",
								children: [/* @__PURE__ */ _jsxDEV("td", {
									className: "w-1/3 bg-slate-900/90 font-bold p-3 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-gray-300",
									children: "UBICACIÓN / PCC (PUNTO CONEXIÓN):"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2955,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("td", {
									className: "p-3 text-slate-100 font-semibold print:text-black",
									children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: ubicacion,
										onChange: (e) => setUbicacion(e.target.value),
										placeholder: "Ej. Límite de Propiedad / Caseta de Medición",
										className: "w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 placeholder-slate-600"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2960,
										columnNumber: 21
									}, this) : ubicacion || "—"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2958,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2954,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 print:border-gray-300",
								children: [/* @__PURE__ */ _jsxDEV("td", {
									className: "bg-slate-900/90 font-bold p-3 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-gray-300",
									children: "CARGA CONTRATADA (kVA):"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2973,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("td", {
									className: "p-3 text-amber-400 font-bold print:text-black font-mono",
									children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: dt.cargaContratadaKva || dt.capacidadContratadaKva || "",
										onChange: (e) => {
											handleDtChange("cargaContratadaKva", e.target.value);
											handleDtChange("capacidadContratadaKva", e.target.value);
										},
										placeholder: "Ej. 1000 kVA",
										className: "w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 placeholder-slate-600"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2978,
										columnNumber: 21
									}, this) : dt.cargaContratadaKva || dt.capacidadContratadaKva || "—"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2976,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2972,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 print:border-gray-300",
								children: [/* @__PURE__ */ _jsxDEV("td", {
									className: "bg-slate-900/90 font-bold p-3 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-gray-300",
									children: "TIPO DE MEDICIÓN ELÉCTRICA:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2994,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("td", {
									className: "p-3 text-slate-100 font-semibold print:text-black",
									children: isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: dt.tipoMedicion || "Medición Directa (Baja Tensión)",
										onChange: (e) => handleDtChange("tipoMedicion", e.target.value),
										className: "w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Medición Directa (Baja Tensión)",
												children: "Medición Directa (Baja Tensión)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 3004,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Medición Indirecta BT",
												children: "Medición Indirecta BT (con TCs)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 3005,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Medición Indirecta AT/MT",
												children: "Medición Indirecta AT/MT (con TCs y TPs)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 3006,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2999,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-sky-400 print:text-black",
										children: dt.tipoMedicion || "Medición Directa (Baja Tensión)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 3009,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2997,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2993,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 print:border-gray-300",
								children: [/* @__PURE__ */ _jsxDEV("td", {
									className: "bg-slate-900/90 font-bold p-3 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-gray-300",
									children: "TENSIÓN DE SERVICIO (COVENIN 159:1997):"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 3014,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("td", {
									className: "p-3 text-slate-100 font-semibold print:text-black",
									children: isEditing ? /* @__PURE__ */ _jsxDEV("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ _jsxDEV("select", {
											value: TENSIONES_COVENIN_TODAS.includes(dt.nivelTension || dt.tensionNominal) ? dt.nivelTension || dt.tensionNominal : dt.nivelTension || dt.tensionNominal ? "CUSTOM" : "",
											onChange: (e) => {
												if (e.target.value !== "CUSTOM") {
													handleDtChange("nivelTension", e.target.value);
													handleDtChange("tensionNominal", e.target.value);
												}
											},
											className: "bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 w-1/2",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "",
													children: "Seleccione tensión..."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 3030,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("optgroup", {
													label: "Baja Tensión (BT)",
													children: TENSIONES_COVENIN_159_BT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
														value: v,
														children: v
													}, v, false, {
														fileName: _jsxFileName,
														lineNumber: 3033,
														columnNumber: 29
													}, this))
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 3031,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("optgroup", {
													label: "Media Tensión (MT)",
													children: TENSIONES_COVENIN_159_MT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
														value: v,
														children: v
													}, v, false, {
														fileName: _jsxFileName,
														lineNumber: 3038,
														columnNumber: 29
													}, this))
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 3036,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "CUSTOM",
													children: "Otra tensión..."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 3041,
													columnNumber: 25
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 3020,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.nivelTension || dt.tensionNominal || "",
											onChange: (e) => {
												handleDtChange("nivelTension", e.target.value);
												handleDtChange("tensionNominal", e.target.value);
											},
											placeholder: "Ej. 13.8 kV o 208/120 V",
											className: "bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 w-1/2 font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 3043,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 3019,
										columnNumber: 21
									}, this) : dt.nivelTension || dt.tensionNominal || "—"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 3017,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 3013,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
								className: "bg-slate-900/90 font-bold p-3 text-slate-300 uppercase border-r border-slate-800 print:bg-gray-100 print:text-black print:border-gray-300",
								children: "RED PÚBLICA / ENLACE CORPOELEC:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3060,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 text-slate-100 font-semibold print:text-black",
								children: isEditing ? /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 md:grid-cols-2 gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.empresaDistribuidora || "CORPOELEC",
											onChange: (e) => handleDtChange("empresaDistribuidora", e.target.value),
											placeholder: "Distribuidora (CORPOELEC)",
											className: "bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 3066,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.numeroContrato || "",
											onChange: (e) => handleDtChange("numeroContrato", e.target.value),
											placeholder: "N° Contrato / NIC",
											className: "bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 3073,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.nic || "",
											onChange: (e) => handleDtChange("nic", e.target.value),
											placeholder: "N° Medidor",
											className: "bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 3080,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.posteTransformador || "",
											onChange: (e) => handleDtChange("posteTransformador", e.target.value),
											placeholder: "Poste / Trafo Servicio",
											className: "bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 3087,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 3065,
									columnNumber: 21
								}, this) : /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-slate-400",
												children: "Distribuidora:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 3097,
												columnNumber: 28
											}, this),
											" ",
											dt.empresaDistribuidora || "CORPOELEC",
											" | ",
											/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-slate-400",
												children: "Acometida:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 3097,
												columnNumber: 130
											}, this),
											" ",
											dt.tipoAcometida || "Subterránea"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 3097,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-slate-400",
												children: "N° Contrato / NIC:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 3098,
												columnNumber: 28
											}, this),
											" ",
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-mono text-amber-400 font-bold",
												children: dt.numeroContrato || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 3098,
												columnNumber: 91
											}, this),
											" | ",
											/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-slate-400",
												children: "N° Medidor:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 3098,
												columnNumber: 180
											}, this),
											" ",
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-mono",
												children: dt.nic || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 3098,
												columnNumber: 236
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 3098,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-slate-400",
												children: "Poste / Trafo Suministro:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 3099,
												columnNumber: 28
											}, this),
											" ",
											dt.posteTransformador || "—"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 3099,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 3096,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3063,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 3059,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2953,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 2952,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/80 border-b border-slate-700 p-2 text-center font-bold text-xs uppercase tracking-wider text-amber-400 font-mono print:bg-gray-200 print:text-black print:border-black",
						children: "Metrología Eléctrica en Punto de Suministro (COVENIN 159:1997)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 3108,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 border-b border-slate-700 bg-slate-900/30",
						children: /* @__PURE__ */ _jsxDEV(MetrologiaElectricaSection, {
							mediciones: dt.mediciones || {},
							onChange: (nuevasMediciones) => handleDtChange("mediciones", nuevasMediciones),
							readOnly: !isEditing,
							titulo: "Metrología Eléctrica en Punto de Suministro (COVENIN 159:1997)",
							subtitulo: "Tensiones L-L, L-N y 5 Canales de Corriente (Fases, Neutro y Tierra)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 3113,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 3112,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-amber-950/40 border-b-2 border-amber-800/60 p-4 font-mono text-xs text-amber-200 print:bg-yellow-100 print:text-black print:border-black",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-black uppercase text-amber-400 block mb-1 print:text-black",
							children: "OBSERVACIÓN GENERAL:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 3124,
							columnNumber: 13
						}, this), isEditing ? /* @__PURE__ */ _jsxDEV("textarea", {
							value: observacionesGenerales,
							onChange: (e) => setObservacionesGenerales(e.target.value),
							rows: 2,
							className: "w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-100 placeholder-slate-600",
							placeholder: "Indique hallazgos, estado del medidor o condiciones de la acometida..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 3126,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("p", { children: observacionesGenerales || "NINGUNA OBSERVACION" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 3134,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 3123,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-900/60 text-center font-mono print:bg-white print:border-black",
						children: /* @__PURE__ */ _jsxDEV(DualPhotoUploader, {
							fotoBlob,
							fotoSrc,
							previewUrl,
							onImageSelected: (file) => {
								setFotoBlob(file);
								const reader = new FileReader();
								reader.onloadend = () => {
									setFotoSrc(reader.result);
								};
								reader.readAsDataURL(file);
								if (previewUrl) URL.revokeObjectURL(previewUrl);
								setPreviewUrl(URL.createObjectURL(file));
							},
							onRemove: () => {
								setFotoBlob(null);
								setFotoSrc(null);
								if (previewUrl) URL.revokeObjectURL(previewUrl);
								setPreviewUrl(null);
							},
							readOnly: !isEditing,
							label: "Foto del Medidor / Punto de Suministro",
							sublabel: "Cámara en vivo o selección de galería"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 3140,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 3139,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 2932,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-8 bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-slate-50 print:border-gray-200 print:mt-3",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-900 pb-2.5 print:text-slate-700 print:border-gray-200",
					children: "Firma y Cierre de Inspección"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 3171,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1.5 items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-600",
								children: "Firma del Inspector"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3178,
								columnNumber: 13
							}, this),
							isEditing ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: dt.firmaInspector || "",
								onChange: (e) => handleDtChange("firmaInspector", e.target.value),
								className: "w-full max-w-xs bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all text-center no-print",
								placeholder: "Nombre del Inspector"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3181,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden print:block text-xs font-bold text-slate-900 mt-1 h-6",
								children: dt.firmaInspector || "___________________________"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3188,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 3180,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-100 font-bold print:text-slate-900",
								children: dt.firmaInspector || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3193,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "hidden print:block w-48 border-b border-gray-300 mt-6 h-1" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3195,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 3177,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1.5 items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-600",
								children: "Firma / Sello de la Empresa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3200,
								columnNumber: 13
							}, this),
							isEditing ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: dt.firmaSupervisor || "",
								onChange: (e) => handleDtChange("firmaSupervisor", e.target.value),
								className: "w-full max-w-xs bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all text-center no-print",
								placeholder: "Nombre / Sello de la Empresa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3203,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden print:block text-xs font-bold text-slate-900 mt-1 h-6",
								children: dt.firmaSupervisor || "___________________________"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3210,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 3202,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-100 font-bold print:text-slate-900",
								children: dt.firmaSupervisor || "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3215,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "hidden print:block w-48 border-b border-gray-300 mt-6 h-1" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 3217,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 3199,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 3175,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 3170,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ModalEdicionCircuito, {
				isOpen: modalJerarquiaOpen,
				onClose: () => setModalJerarquiaOpen(false),
				circuitData: circuitDataWizard,
				tableroCircuits: dt.circuits || dt.circuitos || [],
				maxPolos: dt.maxPoles || 42,
				modo: wizardModo,
				tipoOrigen: tipoElemento,
				elementosCreados: allFeeders,
				onSave: (idSalida, updated) => {
					const isEntradaOrPrimaria = wizardModo === "ENTRADA" || wizardModo === "PRIMARIA" || idSalida.includes("PRIMARIA");
					let newAlimentadoPor = alimentadoPor;
					if (isEntradaOrPrimaria && updated.equipo) {
						newAlimentadoPor = updated.equipo;
						setAlimentadoPor(updated.equipo);
					}
					let newDt = { ...dt };
					// 1. Transformador Acometidas y tensiones
					if (tipoElemento === "TRANSFORMADOR") {
						const seccionKey = isEntradaOrPrimaria ? "primaria" : "secundaria";
						const prevAc = dt.acometidas?.[seccionKey] || {};
						newDt = {
							...newDt,
							acometidas: {
								...newDt.acometidas || {},
								[seccionKey]: {
									...prevAc,
									calibre: updated.conductor || prevAc.calibre || "",
									fusible: updated.detallesTecnicos?.fusibleMT || prevAc.fusible || "",
									pararrayo: updated.detallesTecnicos?.pararrayos || prevAc.pararrayo || "",
									observaciones: updated.equipo || prevAc.observaciones || "",
									...isEntradaOrPrimaria && updated.equipo?.includes("POSTE") ? { aerea: true } : {}
								}
							}
						};
						if (updated.detallesTecnicos?.nivelMT) {
							newDt.tensionPrimaria = updated.detallesTecnicos.nivelMT;
							newDt.voltajePrimario = updated.detallesTecnicos.nivelMT;
						}
						if (updated.detallesTecnicos?.tensionSecundaria) {
							newDt.tensionSecundaria = updated.detallesTecnicos.tensionSecundaria;
							newDt.voltajeSecundario = updated.detallesTecnicos.tensionSecundaria;
						}
					}
					// 2. Generador / Planta Eléctrica
					if (tipoElemento === "GENERADOR") {
						if (updated.breaker?.amp) newDt.amperaje = updated.breaker.amp;
						if (updated.detallesTecnicos?.potenciaKvaKw) newDt.potenciaKva = updated.detallesTecnicos.potenciaKvaKw;
					}
					// 3. Transfer (ATS)
					if (tipoElemento === "TRANSFER") {
						if (idSalida.includes("ATS_GEN1")) {
							newDt.alimentacionGenerador1 = updated.conductor || updated.equipo || newDt.alimentacionGenerador1;
						} else if (idSalida.includes("ATS_GEN2")) {
							newDt.alimentacionGenerador2 = updated.conductor || updated.equipo || newDt.alimentacionGenerador2;
						} else if (idSalida.includes("ATS_CARGA")) {
							newDt.carga = updated.conductor || updated.equipo || newDt.carga;
						}
					}
					// Merge additional technical details
					if (updated.detallesTecnicos) {
						newDt = {
							...newDt,
							...updated.detallesTecnicos
						};
					}
					setDt(newDt);
					// Persistir inmediatamente en el Store
					if (onUpdate) {
						onUpdate({
							...elementoData,
							alimentadoPor: newAlimentadoPor,
							datosTecnicos: newDt
						});
					}
					// Elemento provisional pendiente
					if (updated.tipoDestino === "SUB_TABLERO_PENDIENTE" && elementoData?.proyectoId) {
						const existingProvId = updated.elementoDestinoId || updated.vinculadoId;
						if (!existingProvId) {
							crearElementoProvisional(elementoData.proyectoId, {
								nombre: updated.equipo && updated.equipo !== "RESERVA (Pendiente por Crear)" ? updated.equipo : `Sub-Tablero Alimentado (${idSalida})`,
								tipoElemento: "TABLERO",
								circuitoOrigen: idSalida
							});
						}
					}
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 3222,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 240,
		columnNumber: 5
	}, this);
}
_s2(FichaTecnicaComponent, "10SL3ffY0EnOOniCWGhtMQvGwyU=", false, function() {
	return [
		useConfirm,
		useStore,
		useStore
	];
});
_c2 = FichaTecnicaComponent;
var _c, _c2;
$RefreshReg$(_c, "SafeImage");
$RefreshReg$(_c2, "FichaTecnicaComponent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/FichaTecnicaComponent.jsx?t=1790793862643";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/FichaTecnicaComponent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/FichaTecnicaComponent.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/FichaTecnicaComponent.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQ0UsTUFDQSxPQUNBLFFBQ0EsU0FDQSxVQUNBLEtBQ0EsaUJBQ0s7QUFDUCxPQUFPLGNBQWM7QUFDckIsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTywwQkFBMEI7QUFDakMsT0FBTyxtQ0FBbUM7QUFDMUMsT0FBTyx1QkFBdUI7QUFDOUIsT0FBTyxnQ0FBZ0M7QUFDdkMsT0FBTyx1QkFBdUI7QUFDOUIsU0FDRSwwQkFDQSwwQkFDQSwrQkFDSzs7Ozs7QUFHUCxNQUFNLGFBQWEsRUFBRSxNQUFNLEtBQUssS0FBSyxnQkFBZ0I7O0NBQ25ELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLElBQUk7Q0FFL0MsZ0JBQWdCO0VBQ2QsSUFBSSxNQUFNO0dBQ1IsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7R0FDcEMsYUFBYSxHQUFHO0dBQ2hCLGFBQWE7SUFDWCxJQUFJLGdCQUFnQixHQUFHO0dBQ3pCO0VBQ0YsT0FBTztHQUNMLGFBQWEsSUFBSTtFQUNuQjtDQUNGLEdBQUcsQ0FBQyxJQUFJLENBQUM7Q0FFVCxNQUFNLFdBQVcsYUFBYTtDQUM5QixJQUFJLENBQUMsVUFBVSxPQUFPO0NBRXRCLE9BQU8sd0JBQUMsT0FBRDtFQUFLLEtBQUs7RUFBZTtFQUFnQjtDQUFZOzs7OztBQUM5RDs7O0FBRUEsZUFBZSxTQUFTLHNCQUFzQixFQUFFLGNBQWMsVUFBVSxZQUFZOztDQUNsRixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sRUFBRSxPQUFPLGFBQWEsU0FBUyxrQkFBa0IsV0FBVztDQUNsRSxNQUFNLFlBQVksVUFBVSxVQUFVLE1BQU0sYUFBYSxDQUFDLENBQUM7Q0FFM0QsTUFBTSxhQUFhLE1BQU0sY0FBYztFQUNyQyxNQUFNLE9BQU8sQ0FBQztFQUNkLE1BQU0sU0FBUyxjQUFjLGFBQWEsY0FBYztFQUN4RCxNQUFNLFVBQVUsVUFBVSxNQUFLLE1BQUssRUFBRSxPQUFPLE1BQU07RUFDbkQsSUFBSSxDQUFDLFNBQVM7R0FDWixVQUFVLFNBQVEsTUFBSztJQUNyQixJQUFJLEVBQUUscUJBQXFCO0tBQ3pCLEtBQUssS0FBSyxHQUFHLEVBQUUsbUJBQW1CO0lBQ3BDO0lBQ0EsSUFBSSxFQUFFLFdBQVc7S0FDZixFQUFFLFVBQVUsU0FBUSxNQUFLO01BQ3ZCLE1BQU0sU0FBUyxFQUFFLHVCQUF1QixFQUFFLFlBQVksQ0FBQztNQUN2RCxLQUFLLEtBQUssR0FBRyxNQUFNO0tBQ3JCLENBQUM7SUFDSDtHQUNGLENBQUM7R0FDRCxPQUFPLEtBQUssUUFBTyxNQUFLLEVBQUUsT0FBTyxjQUFjLEVBQUU7RUFDbkQ7RUFFQSxJQUFJLFFBQVEscUJBQXFCO0dBQy9CLEtBQUssS0FBSyxHQUFHLFFBQVEsbUJBQW1CO0VBQzFDO0VBQ0EsSUFBSSxRQUFRLFdBQVc7R0FDckIsUUFBUSxVQUFVLFNBQVEsTUFBSztJQUM3QixNQUFNLFNBQVMsRUFBRSx1QkFBdUIsRUFBRSxZQUFZLENBQUM7SUFDdkQsS0FBSyxLQUFLLEdBQUcsTUFBTTtHQUNyQixDQUFDO0VBQ0g7RUFDQSxPQUFPLEtBQUssUUFBTyxNQUFLLEVBQUUsT0FBTyxjQUFjLEVBQUU7Q0FDbkQsR0FBRyxDQUFDLFdBQVcsWUFBWSxDQUFDOztDQUc1QixNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsY0FBYyxVQUFVLEVBQUU7Q0FDL0QsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsY0FBYyxhQUFhLEVBQUU7Q0FDeEUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsY0FBYyxpQkFBaUIsRUFBRTtDQUNwRixNQUFNLENBQUMsd0JBQXdCLDZCQUE2QixTQUFTLGNBQWMsMEJBQTBCLEVBQUU7Q0FDL0csTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLGNBQWMsWUFBWSxJQUFJO0NBQ3ZFLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxjQUFjLFFBQVEsSUFBSTtDQUNqRSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxJQUFJOztDQUdqRCxNQUFNLENBQUMsSUFBSSxTQUFTLFNBQVMsY0FBYyxpQkFBaUIsQ0FBQyxDQUFDOztDQUc5RCxNQUFNLEVBQUUsNkJBQTZCLFNBQVM7Q0FDOUMsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBUyxLQUFLO0NBQ2xFLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsSUFBSTtDQUMvRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxRQUFROztDQUdyRCxNQUFNLGVBQWUsY0FBYyxnQkFBZ0I7Q0FFbkQsSUFBSSxDQUFDLGNBQWM7RUFDakIsT0FBTyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUEyQztFQUE2Qzs7Ozs7Q0FDaEg7Q0FFQSxNQUFNLGtCQUFrQixLQUFLLFVBQVU7RUFDckMsSUFBSSxVQUFVO0VBQ2QsT0FBTyxVQUFVO0dBQUUsR0FBRztJQUFPLE1BQU07RUFBTSxFQUFFO0NBQzdDO0NBRUEsTUFBTSx3QkFBd0IsV0FBVyxLQUFLLFVBQVU7RUFDdEQsSUFBSSxVQUFVO0VBQ2QsT0FBTyxVQUFVO0dBQ2YsR0FBRztJQUNGLFlBQVk7SUFDWCxHQUFJLEtBQUssY0FBYyxDQUFDO0tBQ3ZCLE1BQU07R0FDVDtFQUNGLEVBQUU7Q0FDSjtDQUVBLE1BQU0sbUJBQW1CLEtBQUssVUFBVTtFQUN0QyxJQUFJLFVBQVU7RUFDZCxPQUFPLFVBQVU7R0FDZixHQUFHO0dBQ0gsS0FBSztJQUNILEdBQUksS0FBSyxPQUFPLENBQUM7S0FDaEIsTUFBTTtHQUNUO0VBQ0YsRUFBRTtDQUNKO0NBRUEsTUFBTSx5QkFBeUIsU0FBUyxLQUFLLFVBQVU7RUFDckQsSUFBSSxVQUFVO0VBQ2QsT0FBTyxVQUFVO0dBQ2YsR0FBRztHQUNILFlBQVk7SUFDVixHQUFJLEtBQUssY0FBYyxDQUFDO0tBQ3ZCLFVBQVU7S0FDVCxHQUFLLEtBQUssY0FBYyxLQUFLLFdBQVcsWUFBYSxDQUFDO01BQ3JELE1BQU07SUFDVDtHQUNGO0VBQ0YsRUFBRTtDQUNKO0NBRUEsTUFBTSxxQkFBcUIsTUFBTTtFQUMvQixJQUFJLFVBQVU7RUFDZCxNQUFNLE9BQU8sRUFBRSxPQUFPLE1BQU07RUFDNUIsSUFBSSxDQUFDLE1BQU07RUFDWCxJQUFJLEtBQUssT0FBTyxLQUFLLE9BQU8sTUFBTTtHQUNoQyxZQUFZLHNFQUFzRTtHQUNsRjtFQUNGO0VBQ0EsWUFBWSxJQUFJO0VBQ2hCLElBQUksWUFBWSxJQUFJLGdCQUFnQixVQUFVO0VBQzlDLGNBQWMsSUFBSSxnQkFBZ0IsSUFBSSxDQUFDO0NBQ3pDO0NBRUEsTUFBTSxjQUFjLE1BQU07RUFDeEIsRUFBRSxlQUFlO0VBQ2pCLElBQUksVUFBVTtFQUNkLElBQUksVUFBVTtHQUNaLFNBQVM7SUFDUCxHQUFHO0lBQ0g7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU07SUFDTixlQUFlO0dBQ2pCLENBQUM7RUFDSDtFQUNBLGFBQWEsS0FBSztDQUNwQjtDQUVBLE1BQU0sMEJBQTBCLFlBQVk7RUFDMUMsSUFBSSxVQUFVO0VBQ2QsTUFBTSxZQUFZLE1BQU0sY0FBYyx3RUFBd0U7RUFDOUcsSUFBSSxDQUFDLFdBQVc7RUFDaEIsVUFBVSxFQUFFO0VBQ1osYUFBYSxFQUFFO0VBQ2YsaUJBQWlCLEVBQUU7RUFDbkIsMEJBQTBCLEVBQUU7RUFDNUIsTUFBTSxDQUFDLENBQUM7RUFDUixZQUFZLElBQUk7RUFDaEIsV0FBVyxJQUFJO0VBQ2YsSUFBSSxZQUFZLElBQUksZ0JBQWdCLFVBQVU7RUFDOUMsY0FBYyxJQUFJO0NBQ3BCO0NBRUEsTUFBTSx1QkFBdUIsWUFBWSxlQUFlO0VBQ3RELElBQUksQ0FBQyxZQUFZLE9BQU8sd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBYTtFQUFPOzs7OztFQUM1RCxJQUFJLFlBQVk7RUFDaEIsSUFBSSxZQUFZLGNBQWM7RUFFOUIsTUFBTSxRQUFRLE9BQU8sVUFBVSxDQUFDLENBQUMsTUFBTSw4Q0FBOEM7RUFDckYsSUFBSSxPQUFPO0dBQ1QsSUFBSSxNQUFNLElBQUksWUFBWSxNQUFNLEVBQUUsQ0FBQyxLQUFLO0dBQ3hDLElBQUksTUFBTSxNQUFNLENBQUMsV0FBVyxZQUFZLE1BQU0sRUFBRSxDQUFDLEtBQUs7RUFDeEQ7RUFFQSxPQUNFLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCLENBQ0Usd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaUQ7R0FBZ0I7Ozs7YUFDaEYsYUFDQyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQixDQUFxSyxRQUM5SixTQUNEOzs7OztXQUVKOzs7Ozs7Q0FFVjtDQUVBLE1BQU0sb0JBQW9CO0VBQ3hCLFFBQVEsY0FBUjtHQUNFLEtBQUssaUJBQ0gsT0FBTyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFpSDtHQUErQjs7Ozs7R0FDekssS0FBSyxhQUNILE9BQU8sd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaUg7R0FBaUI7Ozs7O0dBQzNKLEtBQUssWUFDSCxPQUFPLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWlIO0dBQWtDOzs7OztHQUM1SyxLQUFLLHFCQUNILE9BQU8sd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaUg7R0FBOEI7Ozs7O0dBQ3hLLEtBQUssaUJBQ0gsT0FBTyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFpSDtHQUErQjs7Ozs7R0FDekssS0FBSyxvQkFDSCxPQUFPLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQThHO0dBQXdDOzs7OztHQUMvSyxLQUFLLE9BQ0gsT0FBTyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFpSDtHQUEyQzs7Ozs7R0FDckwsS0FBSztHQUNMLFNBQ0UsT0FBTyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFpSDtHQUF1Qjs7Ozs7RUFDbks7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVcsOEZBQThGLFdBQVcsbUNBQW1DO1lBQTVKO0dBR0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRyxZQUFZLEdBQ2Isd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQWtMLFFBQzNLLGFBQWEsRUFDZDs7Ozs7YUFDSDs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsT0FBTyxNQUFNO01BQzVCLFdBQVU7TUFDVixPQUFNO2dCQUhSLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7OztnQkFBQyxjQUN6Qjs7Ozs7ZUFFUCxDQUFDLFlBQ0EsZ0RBQ0csYUFDQyx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFNBQVM7TUFDVCxXQUFVO01BQ1YsT0FBTTtnQkFKUixDQU1FLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7Z0JBQ3BDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFtQjtNQUF3Qjs7OztjQUNyRDs7Ozs7ZUFHVCxZQUNDLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLDJCQUE0Qjs7OztnQkFBQyxrQkFDdkM7Ozs7O2dCQUVSLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGFBQWEsSUFBSTtNQUNoQyxXQUFVO2dCQUZaLENBSUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUseUJBQTBCOzs7O2dCQUFDLG1CQUN0Qzs7Ozs7YUFFVjs7OzthQUVEOzs7OztZQUNGOzs7Ozs7R0FLSixpQkFBaUIsYUFDaEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUdFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLFlBQ0Msd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFVBQVUsRUFBRSxPQUFPLEtBQUs7UUFDekMsV0FBVTtPQUNYOzs7O2tCQUVELGtDQUFrQyxTQUFTLFNBQVMsU0FBUztNQUU3RDs7Ozs7S0FDRDs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUEyRDtNQUFnQjs7OztnQkFDMUYsWUFDQyx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLE9BQU87T0FDUCxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztPQUM1QyxXQUFVO01BQ1g7Ozs7aUJBRUQsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWlCLGFBQWE7TUFBZ0M7Ozs7Y0FFN0U7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUEyRDtNQUE2Qjs7OztnQkFDeEcsd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxlQUFlO1FBQ2IsY0FBYyxTQUFTO1FBQ3ZCLHFCQUFxQjtTQUNuQixJQUFJO1NBQ0osUUFBUTtTQUNSLFFBQVEsaUJBQWlCO1NBQ3pCLE9BQU8sQ0FBQyxDQUFDO1NBQ1QsU0FBUztVQUFFLEtBQUs7VUFBSSxPQUFPO1VBQUksTUFBTTtTQUFHO1FBQzFDLENBQUM7UUFDRCxzQkFBc0IsSUFBSTtPQUM1QjtPQUNBLFdBQVU7T0FDVixPQUFNO2lCQWRSLENBZ0JFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OztpQkFBQyx1QkFDekM7Ozs7O2NBQ0w7Ozs7Z0JBQ0osWUFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQywrQkFBRDtRQUNFLFlBQVksY0FBYztRQUMxQixpQkFBaUIsY0FBYztRQUMvQixlQUFlO1FBQ2YsT0FBTztRQUNQLFdBQVcsUUFBUSxpQkFBaUIsR0FBRztRQUN2QyxPQUFNO1FBQ04sYUFBWTtPQUNiOzs7OztNQUNFOzs7O2lCQUVMLG9CQUFvQixpQkFBaUIsMEJBQTBCLGNBQWMsZUFBZSxDQUUzRjs7Ozs7O0tBR0wsd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQ0Usd0JBQUMsU0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFNBQVE7U0FBSSxXQUFVO21CQUFtRDtRQUFtQjs7Ozs7UUFDaEcsd0JBQUMsTUFBRDtTQUFJLFNBQVE7U0FBSSxXQUFVO21CQUFtRDtRQUFxQjs7Ozs7UUFDbEcsd0JBQUMsTUFBRDtTQUFJLFNBQVE7U0FBSSxXQUFVO21CQUFtRDtRQUFXOzs7OztRQUN4Rix3QkFBQyxNQUFEO1NBQUksU0FBUTtTQUFJLFdBQVU7bUJBQU07UUFBYTs7Ozs7T0FDM0M7Ozs7O2dCQUNKLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFNBQVE7U0FBSSxXQUFVO21CQUFxRDtRQUFlOzs7OztRQUM5Rix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBcUQ7UUFBYTs7Ozs7UUFDaEYsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXFEO1FBQVM7Ozs7O1FBQzVFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFxRDtRQUFROzs7OztRQUMzRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBcUQ7UUFBTzs7Ozs7T0FDeEU7Ozs7O2NBQ0M7Ozs7Z0JBQ1Asd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFNBQVE7U0FBSSxXQUFVO21CQUN2QixHQUFHLGdCQUFnQixjQUFjLFNBQVM7UUFDekM7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsR0FBRyxnQkFBZ0IsY0FBYyxVQUFVO1FBQzFDOzs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLEdBQUcsa0JBQWtCLFNBQVM7UUFDN0I7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsR0FBRyxrQkFBa0IsUUFBUTtRQUM1Qjs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxHQUFHLGtCQUFrQixPQUFPO1FBQzNCOzs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkO1VBQThHO1VBQ3ZHLEdBQUcsU0FBUyxNQUFNLEdBQUcsbUJBQW1CLE1BQU07VUFBUSx3QkFBQyxNQUFELENBQUk7Ozs7O1VBQUM7VUFDM0QsR0FBRyxTQUFTLE1BQU0sR0FBRyxtQkFBbUIsTUFBTTtVQUFRLHdCQUFDLE1BQUQsQ0FBSTs7Ozs7VUFBQztVQUMzRCxHQUFHLFNBQVMsTUFBTSxHQUFHLG1CQUFtQixNQUFNO1NBQ2pEOzs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxHQUFHLGFBQWE7UUFDZjs7Ozs7T0FDRjs7Ozs7ZUFDQzs7OztjQUNGOzs7Ozs7S0FHUCx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFDZix3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxNQUFEO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWlKO1FBRTNKOzs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZDO1NBQWlCOzs7O21CQUM5RSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNkMsR0FBRyxlQUFlLFdBQVc7U0FBYzs7OztpQkFDdEc7Ozs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZDO1NBQW9COzs7O21CQUNqRix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBbUMsR0FBRyxlQUFlLGlCQUFpQjtTQUE4Qjs7OztpQkFDbEg7Ozs7OztPQUNGOzs7O2lCQUNKLHdCQUFDLE1BQUQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBMkk7UUFFcko7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNkM7U0FBaUI7Ozs7bUJBQzlFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QyxHQUFHLGNBQWMsV0FBVztTQUFrQjs7OztpQkFDekc7Ozs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZDO1NBQW9COzs7O21CQUNqRix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBbUMsR0FBRyxjQUFjLGlCQUFpQjtTQUE0RDs7OztpQkFDL0k7Ozs7OztPQUNGOzs7O2VBQ0M7Ozs7OztLQUNGOzs7OztLQUdQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWtFO01BQTBCOzs7O2dCQUMzRyxZQUNDLHdCQUFDLFlBQUQ7T0FDRSxPQUFPO09BQ1AsV0FBVyxNQUFNLDBCQUEwQixFQUFFLE9BQU8sS0FBSztPQUN6RCxNQUFNO09BQ04sV0FBVTtNQUNYOzs7O2lCQUVELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUNWLDBCQUEwQjtNQUMxQjs7OztjQUVGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixZQUFZLFdBQVcsYUFDdEIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsV0FBRDtRQUFXLE1BQU07UUFBVSxLQUFLLGNBQWM7UUFBUyxLQUFJO1FBQW9CLFdBQVU7T0FBdUM7Ozs7O01BQzdIOzs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsaUNBQWtDOzs7OztRQUNwRCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBeUM7UUFBZ0Q7Ozs7O1FBQ3pHLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUF5SixpQkFFdkosd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxRQUFPO1VBQVUsVUFBVTtVQUFtQixXQUFVO1NBQVU7Ozs7aUJBQ2hGOzs7Ozs7T0FDSjs7Ozs7O0tBRUo7Ozs7O0lBRUY7Ozs7OztHQU1OLGlCQUFpQixlQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBR0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsWUFDQyx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sVUFBVSxFQUFFLE9BQU8sS0FBSztRQUN6QyxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2tCQUVELFVBQVU7TUFFVjs7Ozs7S0FDRDs7Ozs7S0FHTCx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFDZix3QkFBQyxTQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNFLHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7a0JBQ2pDLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZTtVQUNiLGNBQWMsUUFBUTtVQUN0QixxQkFBcUI7V0FDbkIsSUFBSTtXQUNKLFFBQVE7V0FDUixRQUFRLGlCQUFpQjtXQUN6QixPQUFPLENBQUMsQ0FBQztXQUNULFNBQVM7WUFBRSxLQUFLLEdBQUcsWUFBWTtZQUFJLE9BQU8sR0FBRyxTQUFTO1lBQUksTUFBTTtXQUFHO1VBQ3JFLENBQUM7VUFDRCxzQkFBc0IsSUFBSTtTQUM1QjtTQUNBLFdBQVU7U0FDVixPQUFNO21CQWRSLENBZ0JFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OzttQkFBQyx1QkFDekM7Ozs7O2dCQUNOOzs7OztpQkFDSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxZQUNDLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7U0FDaEQsYUFBWTtTQUNaLFdBQVU7UUFDWDs7OzttQkFFRCxvQkFBb0IsaUJBQWlCLEdBQUc7T0FFeEM7Ozs7ZUFDRjs7Ozs7Z0JBQ0osd0JBQUMsTUFBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUE0STtNQUV0Sjs7OztnQkFDSix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxZQUNDLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1FBQzVDLGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7a0JBRUQsYUFBYTtNQUViOzs7O2NBQ0Y7Ozs7Y0FDQzs7Ozs7S0FDRjs7Ozs7S0FHUCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBc0w7S0FFaE07Ozs7O0tBR0wsd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQThEO1FBQWE7Ozs7O1FBQ3pGLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUEwRTtRQUFTOzs7OztRQUNqRyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBMEI7UUFBVTs7Ozs7T0FDaEQ7Ozs7O2VBQ0M7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCO1FBQ0Usd0JBQUMsTUFBRDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFtSTtTQUFTOzs7OztTQUMxSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUFZLHdCQUFDLFNBQUQ7V0FBTyxNQUFLO1dBQU8sT0FBTyxHQUFHLFNBQVM7V0FBSSxXQUFXLE1BQU0sZUFBZSxTQUFTLEVBQUUsT0FBTyxLQUFLO1dBQUcsYUFBWTtXQUFxQyxXQUFVO1VBQXdHOzs7O3FCQUFLLEdBQUcsU0FBUztTQUNuUzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBb0Q7U0FBUzs7Ozs7UUFDekU7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFtSTtTQUFTOzs7OztTQUMxSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUNDLHdCQUFDLFVBQUQ7V0FDRSxPQUFPLEdBQUcsU0FBUztXQUNuQixXQUFXLE1BQU0sZUFBZSxTQUFTLEVBQUUsT0FBTyxLQUFLO1dBQ3ZELFdBQVU7cUJBSFo7WUFLRSx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBSTtZQUFzQjs7Ozs7WUFDeEMsd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQUk7WUFBb0I7Ozs7O1lBQ3RDLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFJO1lBQXFCOzs7OztXQUNqQzs7Ozs7cUJBRVIsR0FBRyxTQUFTO1NBRVo7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW9EO1NBQVE7Ozs7O1FBQ3hFOzs7OztRQUNKLHdCQUFDLE1BQUQ7U0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBbUk7U0FBWTs7Ozs7U0FDN0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gsWUFBWSx3QkFBQyxTQUFEO1dBQU8sTUFBSztXQUFPLE9BQU8sR0FBRyxPQUFPLEdBQUcsZUFBZTtXQUFJLFdBQVcsTUFBTSxlQUFlLE9BQU8sRUFBRSxPQUFPLEtBQUs7V0FBRyxhQUFZO1dBQVUsV0FBVTtVQUF3Rzs7OztxQkFBSyxHQUFHLE9BQU8sR0FBRyxlQUFlO1NBQ3RTOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFvRDtTQUFPOzs7OztRQUN2RTs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1JO1NBQWlDOzs7OztTQUNsTCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUNDLHdCQUFDLFVBQUQ7V0FDRSxPQUFPLEdBQUcscUJBQXFCLEdBQUcsV0FBVztXQUM3QyxXQUFXLE1BQU0sZUFBZSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7V0FDbkUsV0FBVTtxQkFIWixDQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFHO1dBQWlDOzs7O3FCQUNqRCx5QkFBeUIsS0FBSSxNQUM1Qix3QkFBQyxVQUFEO1lBQWdCLE9BQU87c0JBQUk7V0FBVSxHQUF4Qjs7OztrQkFBd0IsQ0FDdEMsQ0FDSzs7Ozs7cUJBRVIsR0FBRyxxQkFBcUIsR0FBRyxXQUFXO1NBRXRDOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFvRDtTQUFXOzs7OztRQUMzRTs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1JO1NBQW9COzs7OztTQUNySyx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUFZLHdCQUFDLFNBQUQ7V0FBTyxNQUFLO1dBQU8sT0FBTyxHQUFHLFlBQVk7V0FBSSxXQUFXLE1BQU0sZUFBZSxZQUFZLEVBQUUsT0FBTyxLQUFLO1dBQUcsYUFBWTtXQUFXLFdBQVU7VUFBd0c7Ozs7cUJBQUssR0FBRyxZQUFZO1NBQ2xSOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFvRDtTQUFPOzs7OztRQUN2RTs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1JO1NBQXdCOzs7OztTQUN6Syx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUFZLHdCQUFDLFNBQUQ7V0FBTyxNQUFLO1dBQU8sT0FBTyxHQUFHLE1BQU07V0FBSSxXQUFXLE1BQU0sZUFBZSxNQUFNLEVBQUUsT0FBTyxLQUFLO1dBQUcsYUFBWTtXQUFVLFdBQVU7VUFBd0c7Ozs7cUJBQUssR0FBRyxNQUFNO1NBQy9QOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFvRDtTQUFTOzs7OztRQUN6RTs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1JO1NBQXVCOzs7OztTQUN4Syx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUNDLHdCQUFDLFVBQUQ7V0FDRSxPQUFPLEdBQUcsZUFBZTtXQUN6QixXQUFXLE1BQU0sZUFBZSxlQUFlLEVBQUUsT0FBTyxLQUFLO1dBQzdELFdBQVU7cUJBSFo7WUFLRSx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBUztZQUF1Qjs7Ozs7WUFDOUMsd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQWM7WUFBbUI7Ozs7O1lBQy9DLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFNO1lBQXlCOzs7OztZQUM3Qyx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBVztZQUFnQjs7Ozs7WUFDekMsd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQVk7WUFBZ0M7Ozs7O1dBQ3BEOzs7OztxQkFFUixHQUFHLGVBQWU7U0FFbEI7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW9EO1NBQVE7Ozs7O1FBQ3hFOzs7OztPQUNDOzs7OztjQUNGOzs7Ozs7S0FHUCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBc0w7S0FFaE07Ozs7O0tBR0wsd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXNEO1FBQWU7Ozs7O1FBQ25GLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzRDtRQUFTOzs7OztRQUM3RSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBc0Q7UUFBUTs7Ozs7UUFDNUUsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXNEO1FBQU87Ozs7O1FBQzNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzRDtRQUFjOzs7OztRQUNsRix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBTTtRQUFnQjs7Ozs7T0FDbEM7Ozs7O2VBQ0M7Ozs7Z0JBQ1Asd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBaUk7T0FBYTs7Ozs7T0FDNUosd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsWUFBWSx3QkFBQyxTQUFEO1NBQU8sTUFBSztTQUFPLE9BQU8sR0FBRyxhQUFhLFNBQVMsR0FBRyxvQkFBb0I7U0FBSSxXQUFXLE1BQU0scUJBQXFCLGVBQWUsU0FBUyxFQUFFLE9BQU8sS0FBSztTQUFHLGFBQVk7U0FBa0IsV0FBVTtRQUF3Rzs7OzttQkFBSyxHQUFHLGFBQWEsU0FBUyxHQUFHLG9CQUFvQjtPQUM3Vzs7Ozs7T0FDSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxZQUFZLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQU8sT0FBTyxHQUFHLGFBQWEsUUFBUSxHQUFHLG1CQUFtQjtTQUFJLFdBQVcsTUFBTSxxQkFBcUIsZUFBZSxRQUFRLEVBQUUsT0FBTyxLQUFLO1NBQUcsYUFBWTtTQUFxQixXQUFVO1FBQXdHOzs7O21CQUFLLEdBQUcsYUFBYSxRQUFRLEdBQUcsbUJBQW1CO09BQzNXOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLFlBQVksd0JBQUMsU0FBRDtTQUFPLE1BQUs7U0FBTyxPQUFPLEdBQUcsYUFBYSxPQUFPLEdBQUcsa0JBQWtCO1NBQUksV0FBVyxNQUFNLHFCQUFxQixlQUFlLE9BQU8sRUFBRSxPQUFPLEtBQUs7U0FBRyxhQUFZO1NBQWEsV0FBVTtRQUF3Rzs7OzttQkFBSyxHQUFHLGFBQWEsT0FBTyxHQUFHLGtCQUFrQjtPQUM5Vjs7Ozs7T0FDSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxZQUFZLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQU8sT0FBTyxHQUFHLGFBQWEsWUFBWSxHQUFHLFlBQVk7U0FBSSxXQUFXLE1BQU0scUJBQXFCLGVBQWUsWUFBWSxFQUFFLE9BQU8sS0FBSztTQUFHLGFBQVk7U0FBbUIsV0FBVTtRQUF3Rzs7OzttQkFBSyxHQUFHLGFBQWEsWUFBWSxHQUFHLFlBQVk7T0FDdlc7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsWUFBWSx3QkFBQyxTQUFEO1NBQU8sTUFBSztTQUFPLE9BQU8sR0FBRyxhQUFhLGNBQWMsR0FBRyxjQUFjO1NBQUksV0FBVyxNQUFNLHFCQUFxQixlQUFlLGNBQWMsRUFBRSxPQUFPLEtBQUs7U0FBRyxhQUFZO1NBQWdCLFdBQVU7UUFBd0c7Ozs7bUJBQUssR0FBRyxhQUFhLGNBQWMsR0FBRyxjQUFjO09BQzlXOzs7OztNQUNGOzs7O2VBQ0M7Ozs7Y0FDRjs7Ozs7O0tBR1Asd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsNEJBQUQ7T0FDRSxZQUFZLEdBQUcsY0FBYyxDQUFDO09BQzlCLFdBQVcscUJBQXFCLGVBQWUsY0FBYyxnQkFBZ0I7T0FDN0UsVUFBVSxDQUFDO09BQ1gsUUFBTztPQUNQLFdBQVU7TUFDWDs7Ozs7S0FDRTs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBc0w7S0FFaE07Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0M7UUFBc0I7Ozs7a0JBQzNFLFlBQ0Msd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU8sR0FBRyxtQkFBbUI7VUFDN0IsV0FBVyxNQUFNLGVBQWUsbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1VBQ2pFLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7bUJBQ0Qsd0JBQUMsVUFBRDtVQUNFLE9BQU8sR0FBRyxnQkFBZ0I7VUFDMUIsV0FBVyxNQUFNLGVBQWUsZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1VBQzlELFdBQVU7b0JBSFosQ0FLRSx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBUztVQUFrQjs7OztvQkFDekMsd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQVU7VUFBcUI7Ozs7a0JBQ3ZDOzs7OztpQkFDTDs7Ozs7bUJBRUwsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsR0FBRyxrQkFBa0IsR0FBRyxHQUFHLGdCQUFnQixHQUFHLEdBQUcsaUJBQWlCLFlBQVksa0JBQWtCLGlCQUFpQjtRQUM5Rzs7OztnQkFFTDs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXNDO1FBQXVCOzs7O2tCQUM1RSxZQUNDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osS0FBSTtVQUNKLE9BQU8sR0FBRyxtQkFBbUIsWUFBWSxHQUFHLGlCQUFpQjtVQUM3RCxXQUFXLE1BQU0sZUFBZSxrQkFBa0IsU0FBUyxFQUFFLE9BQU8sS0FBSyxDQUFDO1VBQzFFLFdBQVU7U0FDWDs7OzttQkFDRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBNEQsR0FBRyxtQkFBbUIsWUFBWSxHQUFHLGlCQUFpQixJQUFHLEdBQU87Ozs7O2lCQUN6SDs7Ozs7bUJBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxPQUFEO1dBQ0UsV0FBVyxXQUNSLEdBQUcsa0JBQWtCLEtBQUssS0FBSyxnQkFDL0IsR0FBRyxrQkFBa0IsS0FBSyxLQUFLLGlCQUFpQjtXQUVuRCxPQUFPLEVBQUUsT0FBTyxHQUFHLEdBQUcsa0JBQWtCLEVBQUUsR0FBRztVQUN6Qzs7Ozs7U0FDSDs7OzttQkFDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNEIsR0FBRyxtQkFBbUIsWUFBWSxHQUFHLEdBQUcsZUFBZSxLQUFLO1NBQVU7Ozs7aUJBQy9HOzs7OztnQkFFSjs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXNDO1FBQStCOzs7O2tCQUNwRixZQUNDLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTyxHQUFHLGFBQWE7U0FDdkIsV0FBVyxNQUFNLGVBQWUsYUFBYSxFQUFFLE9BQU8sS0FBSztTQUMzRCxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O21CQUVELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLEdBQUcsWUFBWSxHQUFHLEdBQUcsVUFBVSxRQUFRO1FBQ3BDOzs7O2dCQUVMOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0M7UUFBeUI7Ozs7eUJBQ3ZFO1NBQ04sTUFBTSxNQUFNLFdBQVcsR0FBRyxlQUFlLEtBQUs7U0FDOUMsTUFBTSxRQUFTLFdBQVcsR0FBRyxtQkFBbUIsWUFBWSxHQUFHLGlCQUFpQixFQUFFLElBQUs7U0FDdkYsTUFBTSxPQUFPLFdBQVcsR0FBRyxTQUFTLEtBQUs7U0FDekMsTUFBTSxvQkFBb0IsR0FBRyxpQkFBaUIsWUFBYSxNQUFNLFVBQVUsUUFBVSxNQUFNO1NBQzNGLE1BQU0saUJBQWlCLE9BQU8sS0FBSyxNQUFNLEtBQUssb0JBQW9CLEtBQUksQ0FBRSxRQUFRLENBQUMsSUFBSTtTQUVyRixPQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFXLDZEQUNmLGtCQUFrQixXQUFXLGNBQWMsS0FBSyxLQUFLLDhEQUNyRCxrQkFBa0IsV0FBVyxjQUFjLEtBQUssSUFBSSx3REFDcEQ7b0JBRUMsaUJBQWlCLE9BQU8sZUFBZSxVQUFVO1NBQzlDOzs7OztRQUVWLEVBQUMsQ0FBRSxDQUNBOzs7OztPQUNGOzs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlCO1NBQThCOzs7O21CQUM5RCxZQUNDLHdCQUFDLFVBQUQ7VUFDRSxPQUFPLEdBQUcsbUJBQW1CO1VBQzdCLFdBQVcsTUFBTSxlQUFlLG1CQUFtQixFQUFFLE9BQU8sS0FBSztVQUNqRSxXQUFVO29CQUhaO1dBS0Usd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVc7V0FBZ0I7Ozs7O1dBQ3pDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFZO1dBQWlCOzs7OztXQUMzQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBbUI7V0FBd0I7Ozs7O1VBQ25EOzs7OztvQkFFUix3QkFBQyxRQUFEO1VBQU0sV0FBVyxhQUFhLEdBQUcsb0JBQW9CLGNBQWMsaUJBQWlCO29CQUNqRixHQUFHLG1CQUFtQjtTQUNuQjs7OztpQkFFTDs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUI7U0FBNEI7Ozs7bUJBQzVELFlBQ0Msd0JBQUMsVUFBRDtVQUNFLE9BQU8sR0FBRyxlQUFlO1VBQ3pCLFdBQVcsTUFBTSxlQUFlLGVBQWUsRUFBRSxPQUFPLEtBQUs7VUFDN0QsV0FBVTtvQkFIWjtXQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFZO1dBQWlCOzs7OztXQUMzQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBZTtXQUFvQjs7Ozs7V0FDakQsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQXFCO1dBQTBCOzs7OztVQUN2RDs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTRCLEdBQUcsZUFBZTtTQUFVOzs7O2lCQUV2RTs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUI7U0FBd0I7Ozs7bUJBQ3hELFlBQ0Msd0JBQUMsVUFBRDtVQUNFLE9BQU8sR0FBRyxpQkFBaUI7VUFDM0IsV0FBVyxNQUFNLGVBQWUsaUJBQWlCLEVBQUUsT0FBTyxLQUFLO1VBQy9ELFdBQVU7b0JBSFo7V0FLRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBcUI7V0FBMEI7Ozs7O1dBQzdELHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFjO1dBQW1COzs7OztXQUMvQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBaUI7V0FBc0I7Ozs7O1dBQ3JELHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFjO1dBQW1COzs7OztVQUN6Qzs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTRCLEdBQUcsaUJBQWlCO1NBQVU7Ozs7aUJBRXpFOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpQjtTQUEyQjs7OzttQkFDM0QsWUFDQyx3QkFBQyxVQUFEO1VBQ0UsT0FBTyxHQUFHLGdCQUFnQjtVQUMxQixXQUFXLE1BQU0sZUFBZSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7VUFDOUQsV0FBVTtvQkFIWjtXQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFZO1dBQWlCOzs7OztXQUMzQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBVTtXQUFlOzs7OztXQUN2Qyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBVztXQUFnQjs7Ozs7VUFDbkM7Ozs7O29CQUVSLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE0QixHQUFHLGdCQUFnQjtTQUFVOzs7O2lCQUV4RTs7Ozs7O09BQ0Y7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLG1CQUFEO09BQ1k7T0FDRDtPQUNHO09BQ1osa0JBQWtCLFNBQVM7UUFDekIsWUFBWSxJQUFJO1FBQ2hCLElBQUksWUFBWSxJQUFJLGdCQUFnQixVQUFVO1FBQzlDLGNBQWMsSUFBSSxnQkFBZ0IsSUFBSSxDQUFDO09BQ3pDO09BQ0EsZ0JBQWdCO1FBQ2QsWUFBWSxJQUFJO1FBQ2hCLFdBQVcsSUFBSTtRQUNmLElBQUksWUFBWSxJQUFJLGdCQUFnQixVQUFVO1FBQzlDLGNBQWMsSUFBSTtPQUNwQjtPQUNBLFVBQVUsQ0FBQztPQUNYLE9BQU07T0FDTixVQUFTO01BQ1Y7Ozs7O0tBQ0U7Ozs7O0lBRUY7Ozs7OztHQU1OLGlCQUFpQixjQUNoQix3QkFBQyxtQkFBRDtJQUNFLGNBQWM7SUFDSjtJQUNBO0dBQ1g7Ozs7O0dBTUYsaUJBQWlCLG1CQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBR0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsWUFDQyx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sVUFBVSxFQUFFLE9BQU8sS0FBSztRQUN6QyxXQUFVO09BQ1g7Ozs7a0JBRUQsNENBQTRDLFVBQVU7TUFFdEQ7Ozs7O0tBQ0Q7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBNkQ7T0FBa0I7Ozs7aUJBQy9GLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLGFBQWEsTUFBTTtPQUNoQjs7OztlQUNIOzs7O2lCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBNkQ7T0FBcUI7Ozs7aUJBQ2pHLFlBQ0Msd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztRQUNoRCxXQUFVO1FBQ1YsYUFBWTtPQUNiOzs7O2tCQUVELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpQixpQkFBaUI7T0FBVTs7OztlQUUzRDs7OztlQUNGOzs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQTZEO01BQWdCOzs7O2dCQUM1RixZQUNDLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsT0FBTztPQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO09BQzVDLFdBQVU7TUFDWDs7OztpQkFFRCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaUIsYUFBYTtNQUFVOzs7O2NBRXZEOzs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUNmLHdCQUFDLFNBQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFrSjtPQUFTOzs7O2lCQUN6Syx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxZQUNDLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTyxHQUFHLFNBQVM7U0FDbkIsV0FBVyxNQUFNLGVBQWUsU0FBUyxFQUFFLE9BQU8sS0FBSztTQUN2RCxXQUFVO1FBQ1g7Ozs7bUJBRUQsR0FBRyxTQUFTO09BRVo7Ozs7ZUFDRjs7Ozs7Z0JBQ0osd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBNEk7T0FBUzs7OztpQkFDbkssd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsWUFDQyx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU8sR0FBRyxTQUFTO1NBQ25CLFdBQVcsTUFBTSxlQUFlLFNBQVMsRUFBRSxPQUFPLEtBQUs7U0FDdkQsV0FBVTtRQUNYOzs7O21CQUVELEdBQUcsU0FBUztPQUVaOzs7O2VBQ0Y7Ozs7O2NBQ0M7Ozs7O0tBQ0Y7Ozs7O0tBR1Asd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQThEO1FBQWE7Ozs7O1FBQ3pGLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUEwRTtRQUFTOzs7OztRQUNqRyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBMEI7UUFBVTs7Ozs7T0FDaEQ7Ozs7O2VBQ0M7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCO1FBQ0Usd0JBQUMsTUFBRDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFtSTtTQUFZOzs7OztTQUM3Six3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUNDLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsV0FBVztXQUNYLE9BQU8sR0FBRyxlQUFlLEdBQUcsT0FBTztXQUNuQyxXQUFXLE1BQU07WUFDZixNQUFNLE1BQU0sRUFBRSxPQUFPLE1BQU0sUUFBUSxPQUFPLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDO1lBQ3hELGVBQWUsZUFBZSxHQUFHO1lBQ2pDLGVBQWUsT0FBTyxHQUFHO1dBQzNCO1dBQ0EsYUFBWTtXQUNaLFdBQVU7VUFDWDs7OztxQkFFRCxHQUFHLGVBQWUsR0FBRyxPQUFPO1NBRTVCOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLFlBQ0Msd0JBQUMsVUFBRDtXQUNFLE9BQU8sR0FBRyxrQkFBa0I7V0FDNUIsV0FBVyxNQUFNLGVBQWUsa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1dBQ2hFLFdBQVU7cUJBSFosQ0FLRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBTTtXQUFXOzs7O3FCQUMvQix3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBTTtXQUFXOzs7O21CQUN6Qjs7Ozs7cUJBRVIsR0FBRyxrQkFBa0I7U0FFckI7Ozs7O1FBQ0Y7Ozs7O1FBQ0osd0JBQUMsTUFBRCxhQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFtSTtRQUFjOzs7O2tCQUMvSix3QkFBQyxNQUFEO1NBQUksV0FBVTtTQUF3RCxTQUFRO21CQUM1RSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0csWUFDQyx3QkFBQyxTQUFEO2FBQ0UsTUFBSzthQUNMLE9BQU8sR0FBRyxpQkFBaUI7YUFDM0IsV0FBVyxNQUFNLGVBQWUsaUJBQWlCLEVBQUUsT0FBTyxLQUFLO2FBQy9ELGFBQVk7YUFDWixXQUFVO1lBQ1g7Ozs7dUJBRUQsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQTZDLEdBQUcsaUJBQWlCO1lBQVU7Ozs7c0JBRTdGLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUF1QztZQUFPOzs7O29CQUMzRDs7Ozs7O1dBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRyxZQUNDLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsT0FBTyxHQUFHLGlCQUFpQjthQUMzQixXQUFXLE1BQU0sZUFBZSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7YUFDL0QsYUFBWTthQUNaLFdBQVU7WUFDWDs7Ozt1QkFFRCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBNkMsR0FBRyxpQkFBaUI7WUFBVTs7OztzQkFFN0Ysd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXVDO1lBQU87Ozs7b0JBQzNEOzs7Ozs7V0FDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNHLFlBQ0Msd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxPQUFPLEdBQUcsa0JBQWtCO2FBQzVCLFdBQVcsTUFBTSxlQUFlLGtCQUFrQixFQUFFLE9BQU8sS0FBSzthQUNoRSxhQUFZO2FBQ1osV0FBVTtZQUNYOzs7O3VCQUVELHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUE2QyxHQUFHLGtCQUFrQjtZQUFVOzs7O3NCQUU5Rix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBdUM7WUFBUTs7OztvQkFDNUQ7Ozs7OztVQUNGOzs7Ozs7UUFDSDs7OztnQkFDRjs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1JO1NBQW9COzs7OztTQUNySyx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUNDLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxHQUFHLG1CQUFtQixHQUFHLG1CQUFtQjtXQUNuRCxXQUFXLE1BQU07WUFDZixNQUFNLE1BQU0sRUFBRSxPQUFPLE1BQU0sUUFBUSxZQUFZLEVBQUUsQ0FBQyxDQUFDLFFBQVEsYUFBYSxJQUFJO1lBQzVFLGVBQWUsbUJBQW1CLEdBQUc7WUFDckMsZUFBZSxtQkFBbUIsR0FBRztXQUN2QztXQUNBLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7cUJBRUQsR0FBRyxtQkFBbUIsR0FBRyxtQkFBbUI7U0FFNUM7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gsWUFDQyx3QkFBQyxVQUFEO1dBQ0UsT0FBTyxHQUFHLHlCQUF5QjtXQUNuQyxXQUFXLE1BQU0sZUFBZSx5QkFBeUIsRUFBRSxPQUFPLEtBQUs7V0FDdkUsV0FBVTtxQkFIWixDQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFLO1dBQVU7Ozs7cUJBQzdCLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFJO1dBQVM7Ozs7bUJBQ3JCOzs7OztxQkFFUixHQUFHLHlCQUF5QjtTQUU1Qjs7Ozs7UUFDRjs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1JO1NBQXNCOzs7OztTQUN2Syx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUNDLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxHQUFHLHFCQUFxQixHQUFHLHFCQUFxQjtXQUN2RCxXQUFXLE1BQU07WUFDZixNQUFNLE1BQU0sRUFBRSxPQUFPLE1BQU0sUUFBUSxZQUFZLEVBQUU7WUFDakQsZUFBZSxxQkFBcUIsR0FBRztZQUN2QyxlQUFlLHFCQUFxQixHQUFHO1dBQ3pDO1dBQ0EsYUFBWTtXQUNaLFdBQVU7VUFDWDs7OztxQkFFRCxHQUFHLHFCQUFxQixHQUFHLHFCQUFxQjtTQUVoRDs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBb0Q7U0FBSzs7Ozs7UUFDckU7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFtSTtTQUFpQjs7Ozs7U0FDbEssd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gsWUFDQyx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sR0FBRyxzQkFBc0I7V0FDaEMsV0FBVyxNQUFNLGVBQWUsc0JBQXNCLEVBQUUsT0FBTyxLQUFLO1dBQ3BFLFdBQVU7VUFDWDs7OztxQkFFRCxHQUFHLHNCQUFzQjtTQUV6Qjs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBb0Q7U0FBTzs7Ozs7UUFDdkU7Ozs7O09BQ0M7Ozs7O2NBQ0Y7Ozs7OztLQUdQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUF1TDtLQUVqTTs7Ozs7S0FFTCx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FDRSx3QkFBQyxTQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTtTQUEyRCxTQUFRO21CQUFJO1FBQWM7Ozs7O1FBQ25HLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO1NBQTJELFNBQVE7bUJBQUk7UUFBUTs7Ozs7UUFDN0Ysd0JBQUMsTUFBRDtTQUFJLFdBQVU7U0FBc0QsU0FBUTttQkFBSTtRQUFhOzs7OztRQUM3Rix3QkFBQyxNQUFEO1NBQUksV0FBVTtTQUFzRCxTQUFRO21CQUFJO1FBQWdCOzs7OztRQUNoRyx3QkFBQyxNQUFEO1NBQUksV0FBVTtTQUF1QixTQUFRO21CQUFJO1FBQWlCOzs7OztPQUNoRTs7Ozs7Z0JBQ0osd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBc0Q7UUFBUzs7Ozs7UUFDN0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXNEO1FBQVk7Ozs7O1FBQ2hGLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzRDtRQUFTOzs7OztRQUM3RSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBc0Q7UUFBUTs7Ozs7UUFDNUUsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXNEO1FBQVk7Ozs7O1FBQ2hGLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzRDtRQUFXOzs7OztRQUMvRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBc0Q7UUFBYTs7Ozs7T0FDL0U7Ozs7O2NBQ0M7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQ2QsQ0FBQyxZQUFZLFlBQVksQ0FBQyxDQUFDLEtBQUssWUFBWTtRQUMzQyxNQUFNLEtBQUssR0FBRyxhQUFhLFlBQVk7U0FBRSxPQUFPO1NBQU8sYUFBYTtTQUFPLFNBQVM7U0FBSSxNQUFNO1NBQUksVUFBVTtTQUFJLFNBQVM7U0FBSSxXQUFXO1NBQUksZUFBZTtRQUFHO1FBQzlKLE9BQ0Usd0JBQUMsTUFBRDtTQUFrQixXQUFVO21CQUE1QjtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNaLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFPLFFBQWM7Ozs7c0JBQ3JCLHdCQUFDLFVBQUQ7YUFDRSxNQUFLO2FBQ0wsZUFBZTtjQUNiLE1BQU0sWUFBWSxZQUFZO2NBQzlCLGNBQWMsWUFBWSxZQUFZLFlBQVk7Y0FDbEQscUJBQXFCO2VBQ25CLElBQUksaUJBQWlCLFFBQVEsWUFBWTtlQUN6QyxRQUFRLDZCQUE2QixRQUFRLFlBQVk7ZUFDekQsUUFBUSxZQUFZLGdCQUFpQixHQUFHLGlCQUFpQjtlQUN6RCxPQUFPLENBQUMsQ0FBQztlQUNULFNBQVM7Z0JBQUUsS0FBSztnQkFBSSxPQUFPO2dCQUFJLE1BQU07ZUFBRztjQUMxQyxDQUFDO2NBQ0Qsc0JBQXNCLElBQUk7YUFDNUI7YUFDQSxXQUFVO2FBQ1YsT0FBTyx5QkFBeUIsUUFBUTt1QkFFeEMsd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7Ozs7WUFDN0I7Ozs7b0JBQ0w7Ozs7OztVQUNIOzs7OztVQUNKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLFlBQ0Msd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxTQUFTLEdBQUcsU0FBUztZQUNyQixXQUFXLE1BQU0sc0JBQXNCLFNBQVMsU0FBUyxFQUFFLE9BQU8sT0FBTztZQUN6RSxXQUFVO1dBQ1g7Ozs7c0JBRUQsR0FBRyxRQUFRLFVBQVU7VUFFckI7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsWUFDQyx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLFNBQVMsR0FBRyxlQUFlO1lBQzNCLFdBQVcsTUFBTSxzQkFBc0IsU0FBUyxlQUFlLEVBQUUsT0FBTyxPQUFPO1lBQy9FLFdBQVU7V0FDWDs7OztzQkFFRCxHQUFHLGNBQWMsVUFBVTtVQUUzQjs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWCxZQUNDLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsT0FBTyxHQUFHLFdBQVc7WUFDckIsV0FBVyxNQUFNLHNCQUFzQixTQUFTLFdBQVcsRUFBRSxPQUFPLEtBQUs7WUFDekUsV0FBVTtXQUNYOzs7O3NCQUVELEdBQUcsV0FBVztVQUVkOzs7OztVQUNKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLFlBQ0Msd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPLEdBQUcsUUFBUTtZQUNsQixXQUFXLE1BQU0sc0JBQXNCLFNBQVMsUUFBUSxFQUFFLE9BQU8sS0FBSztZQUN0RSxXQUFVO1dBQ1g7Ozs7c0JBRUQsR0FBRyxRQUFRO1VBRVg7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsWUFDQyx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU8sR0FBRyxZQUFZO1lBQ3RCLFdBQVcsTUFBTSxzQkFBc0IsU0FBUyxZQUFZLEVBQUUsT0FBTyxLQUFLO1lBQzFFLFdBQVU7V0FDWDs7OztzQkFFRCxHQUFHLFlBQVk7VUFFZjs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWCxZQUNDLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsT0FBTyxHQUFHLFdBQVc7WUFDckIsV0FBVyxNQUFNLHNCQUFzQixTQUFTLFdBQVcsRUFBRSxPQUFPLEtBQUs7WUFDekUsV0FBVTtXQUNYOzs7O3NCQUVELEdBQUcsV0FBVztVQUVkOzs7OztVQUNKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLFlBQ0Msd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPLEdBQUcsYUFBYTtZQUN2QixXQUFXLE1BQU0sc0JBQXNCLFNBQVMsYUFBYSxFQUFFLE9BQU8sS0FBSztZQUMzRSxXQUFVO1dBQ1g7Ozs7c0JBRUQsR0FBRyxhQUFhO1VBRWhCOzs7OztVQUNKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLFlBQ0Msd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPLEdBQUcsaUJBQWlCO1lBQzNCLFdBQVcsTUFBTSxzQkFBc0IsU0FBUyxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7WUFDL0UsV0FBVTtXQUNYOzs7O3NCQUVELEdBQUcsaUJBQWlCO1VBRXBCOzs7OztTQUNGO1dBekhLOzs7O2VBeUhMO09BRVIsQ0FBQztNQUNJOzs7O2NBQ0Y7Ozs7OztLQUdQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUF1TDtLQUVqTTs7Ozs7S0FFTCx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FDRSx3QkFBQyxTQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTtTQUEyRCxTQUFRO21CQUFJO1FBQU87Ozs7O1FBQzVGLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO1NBQXNELFNBQVE7bUJBQUk7UUFBcUI7Ozs7O1FBQ3JHLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO1NBQXNELFNBQVE7bUJBQUk7UUFBYTs7Ozs7UUFDN0Ysd0JBQUMsTUFBRDtTQUFJLFdBQVU7U0FBMkQsU0FBUTttQkFBSTtRQUFlOzs7OztRQUNwRyx3QkFBQyxNQUFEO1NBQUksV0FBVTtTQUF1QixTQUFRO21CQUFJO1FBQXFCOzs7OztPQUNwRTs7Ozs7Z0JBQ0osd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBc0Q7UUFBVzs7Ozs7UUFDL0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXNEO1FBQVk7Ozs7O1FBQ2hGLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzRDtRQUFpQjs7Ozs7UUFDckYsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXNEO1FBQVc7Ozs7O1FBQy9FLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzRDtRQUFhOzs7OztPQUMvRTs7Ozs7Y0FDQzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFpSTtTQUUzSTs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUNDLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxHQUFHLEtBQUssa0JBQWtCO1dBQ2pDLFdBQVcsTUFBTSxnQkFBZ0Isa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1dBQ2pFLFdBQVU7VUFDWDs7OztxQkFFRCxHQUFHLEtBQUssa0JBQWtCO1NBRTFCOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLFlBQ0Msd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLEdBQUcsS0FBSyxtQkFBbUI7V0FDbEMsV0FBVyxNQUFNLGdCQUFnQixtQkFBbUIsRUFBRSxPQUFPLEtBQUs7V0FDbEUsV0FBVTtVQUNYOzs7O3FCQUVELEdBQUcsS0FBSyxtQkFBbUI7U0FFM0I7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gsWUFDQyx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sR0FBRyxLQUFLLHdCQUF3QjtXQUN2QyxXQUFXLE1BQU0sZ0JBQWdCLHdCQUF3QixFQUFFLE9BQU8sS0FBSztXQUN2RSxXQUFVO1VBQ1g7Ozs7cUJBRUQsR0FBRyxLQUFLLHdCQUF3QjtTQUVoQzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUNDLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxHQUFHLEtBQUssb0JBQW9CO1dBQ25DLFdBQVcsTUFBTSxnQkFBZ0Isb0JBQW9CLEVBQUUsT0FBTyxLQUFLO1dBQ25FLFdBQVU7VUFDWDs7OztxQkFFRCxHQUFHLEtBQUssb0JBQW9CO1NBRTVCOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLFlBQ0Msd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLEdBQUcsS0FBSyxxQkFBcUI7V0FDcEMsV0FBVyxNQUFNLGdCQUFnQixxQkFBcUIsRUFBRSxPQUFPLEtBQUs7V0FDcEUsV0FBVTtVQUNYOzs7O3FCQUVELEdBQUcsS0FBSyxxQkFBcUI7U0FFN0I7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gsWUFDQyx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sR0FBRyxLQUFLLGVBQWU7V0FDOUIsV0FBVyxNQUFNLGdCQUFnQixlQUFlLEVBQUUsT0FBTyxLQUFLO1dBQzlELFdBQVU7VUFDWDs7OztxQkFFRCxHQUFHLEtBQUssZUFBZTtTQUV2Qjs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxZQUNDLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxHQUFHLEtBQUssaUJBQWlCO1dBQ2hDLFdBQVcsTUFBTSxnQkFBZ0IsaUJBQWlCLEVBQUUsT0FBTyxLQUFLO1dBQ2hFLFdBQVU7VUFDWDs7OztxQkFFRCxHQUFHLEtBQUssaUJBQWlCO1NBRXpCOzs7OztRQUNGOzs7Ozs7TUFDQzs7OztjQUNGOzs7Ozs7S0FHUCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFrRTtNQUFvQjs7OztnQkFDckcsWUFDQyx3QkFBQyxZQUFEO09BQ0UsT0FBTztPQUNQLFdBQVcsTUFBTSwwQkFBMEIsRUFBRSxPQUFPLEtBQUs7T0FDekQsTUFBTTtPQUNOLFdBQVU7TUFDWDs7OztpQkFFRCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDViwwQkFBMEI7TUFDMUI7Ozs7Y0FFRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsS0FBRDtPQUFHLHdCQUFDLFVBQUQsWUFBUSxXQUFnQjs7Ozs7T0FBQztPQUFDLHdCQUFDLFVBQUQsWUFBUSxLQUFVOzs7OztPQUFDO09BQXVCLHdCQUFDLFVBQUQsWUFBUSxLQUFVOzs7OztPQUFDO09BQW1CLHdCQUFDLFVBQUQsWUFBUSxLQUFVOzs7OztPQUFDO09BQVksd0JBQUMsVUFBRCxZQUFRLEtBQVU7Ozs7O09BQUM7T0FBMkIsd0JBQUMsVUFBRCxZQUFRLEtBQVU7Ozs7O09BQUM7T0FBc0Isd0JBQUMsVUFBRCxZQUFRLEtBQVU7Ozs7O09BQUM7T0FBZ0Isd0JBQUMsVUFBRCxZQUFRLEtBQVU7Ozs7O09BQUM7T0FBNkIsd0JBQUMsVUFBRCxZQUFRLEtBQVU7Ozs7O09BQUM7T0FBeUIsd0JBQUMsVUFBRCxZQUFRLEtBQVU7Ozs7O09BQUM7T0FBd0Isd0JBQUMsVUFBRCxZQUFRLEtBQVU7Ozs7O09BQUM7T0FBbUIsd0JBQUMsVUFBRCxZQUFRLE1BQVc7Ozs7O09BQUM7T0FBNEIsd0JBQUMsVUFBRCxZQUFRLE1BQVc7Ozs7O09BQUM7T0FBMkIsd0JBQUMsVUFBRCxZQUFRLE1BQVc7Ozs7O09BQUM7T0FBVyx3QkFBQyxVQUFELFlBQVEsS0FBVTs7Ozs7T0FBQztPQUF5Qix3QkFBQyxVQUFELFlBQVEsS0FBVTs7Ozs7T0FBQztPQUFxQix3QkFBQyxVQUFELFlBQVEsS0FBVTs7Ozs7T0FBQztPQUFjLHdCQUFDLFVBQUQsWUFBUSxLQUFVOzs7OztPQUFDO09BQTJCLHdCQUFDLFVBQUQsWUFBUSxLQUFVOzs7OztPQUFDO09BQXVCLHdCQUFDLFVBQUQsWUFBUSxLQUFVOzs7OztPQUFDO09BQWdCLHdCQUFDLFVBQUQsWUFBUSxLQUFVOzs7OztPQUFDO09BQXVCLHdCQUFDLFVBQUQsWUFBUSxLQUFVOzs7OztPQUFDO01BQWtDOzs7OztLQUM3M0I7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRyxZQUFZLFdBQVcsYUFDdEIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsV0FBRDtRQUNFLE1BQU07UUFDTixLQUFLLGNBQWM7UUFDbkIsS0FBSTtRQUNKLFdBQVU7UUFDVixPQUFPLEVBQUUsV0FBVyxHQUFHLEdBQUcsYUFBYSxJQUFJLElBQUk7T0FDaEQ7Ozs7O01BQ0U7Ozs7aUJBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxpQ0FBa0M7Ozs7O1FBQ3BELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF5QztRQUE4Qzs7Ozs7UUFDdkcsd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQTBKLGlCQUV4Six3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLFFBQU87VUFBVSxVQUFVO1VBQW1CLFdBQVU7U0FBVTs7OztpQkFDaEY7Ozs7OztPQUNKOzs7OztpQkFJTCxZQUFZLFdBQVcsZUFDdkIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7a0JBQ2pDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUE2QyxHQUFHLGFBQWEsS0FBSSxJQUFROzs7OztnQkFDdEU7Ozs7O2lCQUNMLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsS0FBSTtRQUNKLEtBQUk7UUFDSixPQUFPLEdBQUcsYUFBYTtRQUN2QixXQUFXLE1BQU0sZUFBZSxhQUFhLFNBQVMsRUFBRSxPQUFPLEtBQUssQ0FBQztRQUNyRSxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7Y0FFSjs7Ozs7O0lBRUY7Ozs7OztHQU1OLGlCQUFpQix1QkFDaEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUdFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsWUFDQyx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLE9BQU87T0FDUCxXQUFXLE1BQU0sVUFBVSxFQUFFLE9BQU8sS0FBSztPQUN6QyxXQUFVO01BQ1g7Ozs7aUJBRUQsK0RBQStELFVBQVU7S0FFekU7Ozs7O0lBQ0Q7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BR0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBd0k7T0FFbEo7Ozs7aUJBQ0osd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQW1COzs7O21CQUNsRyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixhQUFhO1NBQ1Y7Ozs7aUJBQ0g7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUF5Qjs7OzttQkFDdkcsWUFDQyx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU87VUFDUCxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztVQUM1QyxXQUFVO1NBQ1g7Ozs7b0JBRUQsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsYUFBYTtTQUNWOzs7O2lCQUVMOzs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBa0I7Ozs7bUJBQ2hHLFlBQ0Msd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPLEdBQUcsZUFBZTtVQUN6QixXQUFXLE1BQU0sZUFBZSxlQUFlLEVBQUUsT0FBTyxLQUFLO1VBQzdELFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixHQUFHLGVBQWU7U0FDZjs7OztpQkFFTDs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQTRCOzs7O21CQUMxRyxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLG9CQUFvQjtVQUM5QixXQUFXLE1BQU0sZUFBZSxvQkFBb0IsRUFBRSxPQUFPLEtBQUs7VUFDbEUsV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLEdBQUcsb0JBQW9CO1NBQ3BCOzs7O2lCQUVMOzs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBcUI7Ozs7bUJBQ25HLFlBQ0Msd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPLEdBQUcsU0FBUztVQUNuQixXQUFXLE1BQU0sZUFBZSxTQUFTLEVBQUUsT0FBTyxLQUFLO1VBQ3ZELFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixHQUFHLFNBQVM7U0FDVDs7OztpQkFFTDs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQWlCOzs7O21CQUMvRixZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLGNBQWM7VUFDeEIsV0FBVyxNQUFNLGVBQWUsY0FBYyxFQUFFLE9BQU8sS0FBSztVQUM1RCxXQUFVO1NBQ1g7Ozs7b0JBRUQsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsR0FBRyxjQUFjO1NBQ2Q7Ozs7aUJBRUw7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUF5Qjs7OzttQkFDdkcsWUFDQyx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU8sR0FBRyxtQkFBbUI7VUFDN0IsV0FBVyxNQUFNLGVBQWUsbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1VBQ2pFLFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixHQUFHLG1CQUFtQjtTQUNuQjs7OztpQkFFTDs7Ozs7UUFDRjs7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBd0k7T0FFbEo7Ozs7aUJBQ0osd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQStCOzs7O21CQUM3RyxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLGtCQUFrQjtVQUM1QixXQUFXLE1BQU0sZUFBZSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7VUFDaEUsV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyRyxHQUFHLGtCQUFrQjtTQUFVOzs7O2lCQUV6Sjs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQWtDOzs7O21CQUNoSCxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLHFCQUFxQjtVQUMvQixXQUFXLE1BQU0sZUFBZSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7VUFDbkUsV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyRyxHQUFHLHFCQUFxQjtTQUFVOzs7O2lCQUU1Sjs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQWlCOzs7O21CQUMvRixZQUNDLHdCQUFDLFVBQUQ7VUFDRSxPQUFPLEdBQUcsY0FBYztVQUN4QixXQUFXLE1BQU0sZUFBZSxjQUFjLEVBQUUsT0FBTyxLQUFLO1VBQzVELFdBQVU7b0JBSFosQ0FLRSx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBUTtVQUFhOzs7O29CQUNuQyx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBUTtVQUFhOzs7O2tCQUM3Qjs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlHLEdBQUcsY0FBYztTQUFVOzs7O2lCQUUzSTs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQXFDOzs7O21CQUNuSCxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLHlCQUF5QjtVQUNuQyxXQUFXLE1BQU0sZUFBZSx5QkFBeUIsRUFBRSxPQUFPLEtBQUs7VUFDdkUsV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyRyxHQUFHLHlCQUF5QjtTQUFVOzs7O2lCQUVoSzs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQWtDOzs7O21CQUNoSCxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLHlCQUF5QjtVQUNuQyxXQUFXLE1BQU0sZUFBZSx5QkFBeUIsRUFBRSxPQUFPLEtBQUs7VUFDdkUsV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyRyxHQUFHLHlCQUF5QjtTQUFVOzs7O2lCQUVoSzs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQWlCOzs7O21CQUMvRixZQUNDLHdCQUFDLFVBQUQ7VUFDRSxPQUFPLEdBQUcsWUFBWTtVQUN0QixXQUFXLE1BQU0sZUFBZSxZQUFZLEVBQUUsT0FBTyxLQUFLO1VBQzFELFdBQVU7b0JBSFo7V0FLRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBYTtXQUFrQjs7Ozs7V0FDN0Msd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVc7V0FBZ0I7Ozs7O1dBQ3pDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFZO1dBQWlCOzs7OztVQUNyQzs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlHLEdBQUcsWUFBWTtTQUFVOzs7O2lCQUV6STs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQWU7Ozs7bUJBQzdGLFlBQ0Msd0JBQUMsVUFBRDtVQUNFLE9BQU8sR0FBRyxZQUFZO1VBQ3RCLFdBQVcsTUFBTSxlQUFlLFlBQVksRUFBRSxPQUFPLEtBQUs7VUFDMUQsV0FBVTtvQkFIWixDQUtFLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFRO1VBQWE7Ozs7b0JBQ25DLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFXO1VBQWdCOzs7O2tCQUNuQzs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlHLEdBQUcsWUFBWTtTQUFVOzs7O2lCQUV6STs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQW9DOzs7O21CQUNsSCxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLHVCQUF1QjtVQUNqQyxXQUFXLE1BQU0sZUFBZSx1QkFBdUIsRUFBRSxPQUFPLEtBQUs7VUFDckUsV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpRyxHQUFHLHVCQUF1QjtTQUFVOzs7O2lCQUVwSjs7Ozs7UUFDRjs7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBd0k7UUFFbEo7Ozs7O1FBQ0osd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQStEO1VBQTJCOzs7O29CQUN6RyxZQUNDLHdCQUFDLFVBQUQ7V0FDRSxPQUFPLEdBQUcsb0JBQW9CO1dBQzlCLFdBQVcsTUFBTSxlQUFlLG9CQUFvQixFQUFFLE9BQU8sS0FBSztXQUNsRSxXQUFVO3FCQUhaO1lBS0Usd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQU87WUFBWTs7Ozs7WUFDakMsd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQXFCO1lBQTBCOzs7OztZQUM3RCx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBNEI7WUFBaUM7Ozs7O1dBQ3JFOzs7OztxQkFFUix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBMkcsR0FBRyxvQkFBb0I7VUFBVTs7OztrQkFFM0o7Ozs7O1VBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUErRDtVQUEwQjs7OztvQkFDeEcsWUFDQyx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sR0FBRyxZQUFZO1dBQ3RCLFdBQVcsTUFBTSxlQUFlLFlBQVksRUFBRSxPQUFPLEtBQUs7V0FDMUQsV0FBVTtVQUNYOzs7O3FCQUVELHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFpRyxHQUFHLFlBQVk7VUFBVTs7OztrQkFFekk7Ozs7O1VBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUErRDtVQUFnQzs7OztvQkFDOUcsWUFDQyx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sR0FBRyxzQkFBc0I7V0FDaEMsV0FBVyxNQUFNLGVBQWUsc0JBQXNCLEVBQUUsT0FBTyxLQUFLO1dBQ3BFLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7cUJBRUQsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTJHLEdBQUcsc0JBQXNCO1VBQVU7Ozs7a0JBRTdKOzs7OztVQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBK0Q7VUFBMEI7Ozs7b0JBQ3hHLFlBQ0Msd0JBQUMsVUFBRDtXQUNFLE9BQU8sR0FBRyxtQkFBbUI7V0FDN0IsV0FBVyxNQUFNLGVBQWUsbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1dBQ2pFLFdBQVU7cUJBSFosQ0FLRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBd0I7V0FBNkI7Ozs7cUJBQ25FLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUEwQjtXQUErQjs7OzttQkFDakU7Ozs7O3FCQUVSLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFpRyxHQUFHLG1CQUFtQjtVQUFVOzs7O2tCQUVoSjs7Ozs7U0FDRjs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUErRDtVQUV6RTs7OztvQkFDTCxhQUNDLHdCQUFDLFVBQUQ7V0FDRSxNQUFLO1dBQ0wsZUFBZTtZQUNiLE1BQU0sVUFBVSxHQUFHLGtCQUFrQixDQUFDO1lBQ3RDLE1BQU0sVUFBVSxRQUFRLFNBQVM7WUFDakMsZUFBZSxrQkFBa0IsQ0FDL0IsR0FBRyxTQUNIO2FBQUUsTUFBTTthQUFTLE1BQU07YUFBSSxVQUFVO2FBQUksS0FBSzthQUFJLEtBQUs7YUFBSSxLQUFLO2FBQUksUUFBUTtZQUFZLENBQzFGLENBQUM7V0FDSDtXQUNBLFdBQVU7cUJBQ1g7VUFFTzs7OztrQkFFUDs7Ozs7bUJBQ0gsR0FBRyxrQkFBa0IsR0FBRyxlQUFlLFNBQVMsSUFDaEQsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQ2Ysd0JBQUMsTUFBRDthQUNFLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUFNO2FBQVE7Ozs7O2FBQzVCLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUFNO2FBQW1COzs7OzthQUN2Qyx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBTTthQUFpQjs7Ozs7YUFDckMsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQU07YUFBWTs7Ozs7YUFDaEMsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQU07YUFBWTs7Ozs7YUFDaEMsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQU07YUFBWTs7Ozs7YUFDaEMsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQU07YUFBVTs7Ozs7YUFDN0IsYUFBYSx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBa0I7YUFBVTs7Ozs7WUFDdEQ7Ozs7O1dBQ0M7Ozs7cUJBQ1Asd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQ2QsR0FBRyxlQUFlLEtBQUssR0FBRyxRQUN6Qix3QkFBQyxNQUFEO2FBQ0Usd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQWQsQ0FBdUQsVUFBTyxFQUFFLFFBQVEsTUFBTSxDQUFNOzs7Ozs7YUFDcEYsd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQ1gsWUFDQyx3QkFBQyxTQUFEO2VBQ0UsTUFBSztlQUNMLE9BQU8sRUFBRSxRQUFRO2VBQ2pCLFdBQVcsTUFBTTtnQkFDZixNQUFNLFVBQVUsQ0FBQyxHQUFHLEdBQUcsY0FBYztnQkFDckMsUUFBUSxPQUFPO2lCQUFFLEdBQUcsUUFBUTtpQkFBTSxNQUFNLEVBQUUsT0FBTztnQkFBTTtnQkFDdkQsZUFBZSxrQkFBa0IsT0FBTztlQUMxQztlQUNBLGFBQVk7ZUFDWixXQUFVO2NBQ1g7Ozs7eUJBQ0UsRUFBRSxPQUFPLEdBQUcsRUFBRSxLQUFLLFNBQVM7YUFDL0I7Ozs7O2FBQ0osd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQ1gsWUFDQyx3QkFBQyxTQUFEO2VBQ0UsTUFBSztlQUNMLE9BQU8sRUFBRSxZQUFZO2VBQ3JCLFdBQVcsTUFBTTtnQkFDZixNQUFNLFVBQVUsQ0FBQyxHQUFHLEdBQUcsY0FBYztnQkFDckMsUUFBUSxPQUFPO2lCQUFFLEdBQUcsUUFBUTtpQkFBTSxVQUFVLEVBQUUsT0FBTztnQkFBTTtnQkFDM0QsZUFBZSxrQkFBa0IsT0FBTztlQUMxQztlQUNBLGFBQVk7ZUFDWixXQUFVO2NBQ1g7Ozs7eUJBQ0UsRUFBRSxXQUFXLEdBQUcsRUFBRSxTQUFTLE1BQU07YUFDcEM7Ozs7O2FBQ0osd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQ1gsWUFDQyx3QkFBQyxTQUFEO2VBQ0UsTUFBSztlQUNMLE9BQU8sRUFBRSxPQUFPO2VBQ2hCLFdBQVcsTUFBTTtnQkFDZixNQUFNLFVBQVUsQ0FBQyxHQUFHLEdBQUcsY0FBYztnQkFDckMsUUFBUSxPQUFPO2lCQUFFLEdBQUcsUUFBUTtpQkFBTSxLQUFLLEVBQUUsT0FBTztnQkFBTTtnQkFDdEQsZUFBZSxrQkFBa0IsT0FBTztlQUMxQztlQUNBLGFBQVk7ZUFDWixXQUFVO2NBQ1g7Ozs7eUJBQ0UsRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU07YUFDMUI7Ozs7O2FBQ0osd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQ1gsWUFDQyx3QkFBQyxTQUFEO2VBQ0UsTUFBSztlQUNMLE9BQU8sRUFBRSxPQUFPO2VBQ2hCLFdBQVcsTUFBTTtnQkFDZixNQUFNLFVBQVUsQ0FBQyxHQUFHLEdBQUcsY0FBYztnQkFDckMsUUFBUSxPQUFPO2lCQUFFLEdBQUcsUUFBUTtpQkFBTSxLQUFLLEVBQUUsT0FBTztnQkFBTTtnQkFDdEQsZUFBZSxrQkFBa0IsT0FBTztlQUMxQztlQUNBLGFBQVk7ZUFDWixXQUFVO2NBQ1g7Ozs7eUJBQ0UsRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU07YUFDMUI7Ozs7O2FBQ0osd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQ1gsWUFDQyx3QkFBQyxTQUFEO2VBQ0UsTUFBSztlQUNMLE9BQU8sRUFBRSxPQUFPO2VBQ2hCLFdBQVcsTUFBTTtnQkFDZixNQUFNLFVBQVUsQ0FBQyxHQUFHLEdBQUcsY0FBYztnQkFDckMsUUFBUSxPQUFPO2lCQUFFLEdBQUcsUUFBUTtpQkFBTSxLQUFLLEVBQUUsT0FBTztnQkFBTTtnQkFDdEQsZUFBZSxrQkFBa0IsT0FBTztlQUMxQztlQUNBLGFBQVk7ZUFDWixXQUFVO2NBQ1g7Ozs7eUJBQ0UsRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU07YUFDMUI7Ozs7O2FBQ0osd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQ1gsWUFDQyx3QkFBQyxVQUFEO2VBQ0UsT0FBTyxFQUFFLFVBQVU7ZUFDbkIsV0FBVyxNQUFNO2dCQUNmLE1BQU0sVUFBVSxDQUFDLEdBQUcsR0FBRyxjQUFjO2dCQUNyQyxRQUFRLE9BQU87aUJBQUUsR0FBRyxRQUFRO2lCQUFNLFFBQVEsRUFBRSxPQUFPO2dCQUFNO2dCQUN6RCxlQUFlLGtCQUFrQixPQUFPO2VBQzFDO2VBQ0EsV0FBVTt5QkFQWjtnQkFTRSx3QkFBQyxVQUFEO2lCQUFRLE9BQU07MkJBQVk7Z0JBQWlCOzs7OztnQkFDM0Msd0JBQUMsVUFBRDtpQkFBUSxPQUFNOzJCQUFrQztnQkFBdUI7Ozs7O2dCQUN2RSx3QkFBQyxVQUFEO2lCQUFRLE9BQU07MkJBQWU7Z0JBQW9COzs7OztnQkFDakQsd0JBQUMsVUFBRDtpQkFBUSxPQUFNOzJCQUE0QjtnQkFBYzs7Ozs7ZUFDbEQ7Ozs7O3lCQUVSLHdCQUFDLFFBQUQ7ZUFBTSxXQUFXLDZDQUNmLEVBQUUsV0FBVyxjQUFjLDhEQUMzQixFQUFFLFdBQVcsb0NBQW9DLHdEQUNqRDt5QkFFQyxFQUFFLFVBQVU7Y0FDVDs7Ozs7YUFFTjs7Ozs7YUFDSCxhQUNDLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUNaLHdCQUFDLFVBQUQ7ZUFDRSxNQUFLO2VBQ0wsZUFBZTtnQkFDYixNQUFNLFVBQVUsR0FBRyxlQUFlLFFBQVEsR0FBRyxNQUFNLE1BQU0sR0FBRztnQkFDNUQsZUFBZSxrQkFBa0IsT0FBTztlQUMxQztlQUNBLFdBQVU7ZUFDVixPQUFNO3lCQUNQO2NBRU87Ozs7O2FBQ047Ozs7O1lBRUosS0F0SEs7Ozs7bUJBc0hMLENBQ0w7V0FDSTs7OzttQkFDRjs7Ozs7O1NBQ0o7Ozs7b0JBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FBNEcseUNBQ3BFLFlBQVksNERBQTBELEVBQ3pHOzs7OztpQkFFSjs7Ozs7O09BQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXdJO09BRWxKOzs7O2lCQUNKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUFpQzs7OzttQkFDL0csWUFDQyx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU8sR0FBRyxzQkFBc0I7VUFDaEMsV0FBVyxNQUFNLGVBQWUsc0JBQXNCLEVBQUUsT0FBTyxLQUFLO1VBQ3BFLFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUcsR0FBRyxzQkFBc0I7U0FBVTs7OztpQkFFbko7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUF3Qjs7OzttQkFDdEcsWUFDQyx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU8sR0FBRyxtQkFBbUI7VUFDN0IsV0FBVyxNQUFNLGVBQWUsbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1VBQ2pFLFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUcsR0FBRyxtQkFBbUI7U0FBVTs7OztpQkFFaEo7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUFrQzs7OzttQkFDaEgsWUFDQyx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU8sR0FBRyxzQkFBc0I7VUFDaEMsV0FBVyxNQUFNLGVBQWUsc0JBQXNCLEVBQUUsT0FBTyxLQUFLO1VBQ3BFLFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUcsR0FBRyxzQkFBc0I7U0FBVTs7OztpQkFFbko7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUE2Qjs7OzttQkFDM0csWUFDQyx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU8sR0FBRyx5QkFBeUI7VUFDbkMsV0FBVyxNQUFNLGVBQWUseUJBQXlCLEVBQUUsT0FBTyxLQUFLO1VBQ3ZFLFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUcsR0FBRyx5QkFBeUI7U0FBVTs7OztpQkFFdEo7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUE4Qjs7OzttQkFDNUcsWUFDQyx3QkFBQyxVQUFEO1VBQ0UsT0FBTyxHQUFHLHVCQUF1QjtVQUNqQyxXQUFXLE1BQU0sZUFBZSx1QkFBdUIsRUFBRSxPQUFPLEtBQUs7VUFDckUsV0FBVTtvQkFIWixDQUtFLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFLO1VBQStCOzs7O29CQUNsRCx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBSztVQUFVOzs7O2tCQUN2Qjs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlHLEdBQUcsdUJBQXVCO1NBQVU7Ozs7aUJBRXBKOzs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBZ0I7Ozs7bUJBQzlGLFlBQ0Msd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPLEdBQUcsYUFBYTtVQUN2QixXQUFXLE1BQU0sZUFBZSxhQUFhLEVBQUUsT0FBTyxLQUFLO1VBQzNELFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUcsR0FBRyxhQUFhO1NBQVU7Ozs7aUJBRTFJOzs7OztRQUNGOzs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF3STtPQUVsSjs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBcUM7Ozs7bUJBQ25ILFlBQ0Msd0JBQUMsVUFBRDtVQUNFLE9BQU8sR0FBRyx5QkFBeUI7VUFDbkMsV0FBVyxNQUFNLGVBQWUseUJBQXlCLEVBQUUsT0FBTyxLQUFLO1VBQ3ZFLFdBQVU7b0JBSFo7V0FLRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBYztXQUFtQjs7Ozs7V0FDL0Msd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQWU7V0FBb0I7Ozs7O1dBQ2pELHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFNO1dBQVc7Ozs7O1VBQ3pCOzs7OztvQkFFUix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUcsR0FBRyx5QkFBeUI7U0FBVTs7OztpQkFFdEo7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUFxQjs7OzttQkFDbkcsWUFDQyx3QkFBQyxVQUFEO1VBQ0UsT0FBTyxHQUFHLGNBQWM7VUFDeEIsV0FBVyxNQUFNLGVBQWUsY0FBYyxFQUFFLE9BQU8sS0FBSztVQUM1RCxXQUFVO29CQUhaLENBS0Usd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQW1DO1VBQXdDOzs7O29CQUN6Rix3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBTztVQUFZOzs7O2tCQUMzQjs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlHLEdBQUcsY0FBYztTQUFVOzs7O2lCQUUzSTs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQTBCOzs7O21CQUN4RyxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLDJCQUEyQjtVQUNyQyxXQUFXLE1BQU0sZUFBZSwyQkFBMkIsRUFBRSxPQUFPLEtBQUs7VUFDekUsV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpRyxHQUFHLDJCQUEyQjtTQUFVOzs7O2lCQUV4Sjs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQXlCOzs7O21CQUN2RyxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLHFCQUFxQjtVQUMvQixXQUFXLE1BQU0sZUFBZSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7VUFDbkUsV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpRyxHQUFHLHFCQUFxQjtTQUFVOzs7O2lCQUVsSjs7Ozs7UUFDRjs7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBd0k7T0FFbEo7Ozs7aUJBQ0osd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUErRDtVQUErQzs7OztvQkFDN0gsWUFDQyx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sR0FBRyx3QkFBd0I7V0FDbEMsV0FBVyxNQUFNLGVBQWUsd0JBQXdCLEVBQUUsT0FBTyxLQUFLO1dBQ3RFLFdBQVU7VUFDWDs7OztxQkFFRCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaUcsR0FBRyx3QkFBd0I7VUFBVTs7OztrQkFFcko7Ozs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBK0I7Ozs7bUJBQzdHLFlBQ0Msd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPLEdBQUcsY0FBYztVQUN4QixXQUFXLE1BQU0sZUFBZSxjQUFjLEVBQUUsT0FBTyxLQUFLO1VBQzVELGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7b0JBRUQsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTJHLEdBQUcsY0FBYztTQUFVOzs7O2lCQUVySjs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQTZCOzs7O21CQUMzRyxZQUNDLHdCQUFDLFVBQUQ7VUFDRSxPQUFPLEdBQUcsc0JBQXNCO1VBQ2hDLFdBQVcsTUFBTSxlQUFlLHNCQUFzQixFQUFFLE9BQU8sS0FBSztVQUNwRSxXQUFVO29CQUhaO1dBS0Usd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQXNCO1dBQTJCOzs7OztXQUMvRCx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBd0I7V0FBNkI7Ozs7O1dBQ25FLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFVO1dBQWU7Ozs7O1VBQ2pDOzs7OztvQkFFUix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUcsR0FBRyxzQkFBc0I7U0FBVTs7OztpQkFFbko7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUFnQzs7OzttQkFDOUcsWUFDQyx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU8sR0FBRywyQkFBMkI7VUFDckMsV0FBVyxNQUFNLGVBQWUsMkJBQTJCLEVBQUUsT0FBTyxLQUFLO1VBQ3pFLFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBMkcsR0FBRywwQkFBMEIsR0FBRywwQkFBMEIsT0FBTztTQUFVOzs7O2lCQUVyTTs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQTBCOzs7O21CQUN4RyxZQUNDLHdCQUFDLFVBQUQ7VUFDRSxPQUFPLEdBQUcsbUJBQW1CO1VBQzdCLFdBQVcsTUFBTSxlQUFlLG1CQUFtQixFQUFFLE9BQU8sS0FBSztVQUNqRSxXQUFVO29CQUhaLENBS0Usd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQVc7VUFBZ0I7Ozs7b0JBQ3pDLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFXO1VBQWdCOzs7O2tCQUNuQzs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlHLEdBQUcsbUJBQW1CO1NBQVU7Ozs7aUJBRWhKOzs7OztRQUNGOzs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF3STtPQUVsSjs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBcUM7Ozs7bUJBQ25ILFlBQ0Msd0JBQUMsVUFBRDtVQUNFLE9BQU8sR0FBRyw2QkFBNkI7VUFDdkMsV0FBVyxNQUFNLGVBQWUsNkJBQTZCLEVBQUUsT0FBTyxLQUFLO1VBQzNFLFdBQVU7b0JBSFo7V0FLRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBTztXQUFZOzs7OztXQUNqQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBTztXQUFZOzs7OztXQUNqQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBVTtXQUFlOzs7OztVQUNqQzs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlHLEdBQUcsNkJBQTZCO1NBQVU7Ozs7aUJBRTFKOzs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBaUM7Ozs7bUJBQy9HLFlBQ0Msd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU8sR0FBRyxtQkFBbUI7WUFDN0IsV0FBVyxNQUFNLGVBQWUsbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1lBQ2pFLGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7O1dBQ0Qsd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O1dBQ2Isd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPLEdBQUcsb0JBQW9CO1lBQzlCLFdBQVcsTUFBTSxlQUFlLG9CQUFvQixFQUFFLE9BQU8sS0FBSztZQUNsRSxhQUFZO1lBQ1osV0FBVTtXQUNYOzs7OztXQUNELHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztXQUNiLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsT0FBTyxHQUFHLG1CQUFtQjtZQUM3QixXQUFXLE1BQU0sZUFBZSxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7WUFDakUsYUFBWTtZQUNaLFdBQVU7V0FDWDs7Ozs7V0FDRCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBYztXQUFROzs7OztVQUNuQzs7Ozs7b0JBRUwsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQ0csR0FBRyxtQkFBbUI7V0FBSTtXQUFJLEdBQUcsb0JBQW9CO1dBQUk7V0FBSSxHQUFHLG1CQUFtQjtXQUFJO1VBQ3BGOzs7OztpQkFFTDs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQThCOzs7O21CQUM1RyxZQUNDLHdCQUFDLFVBQUQ7VUFDRSxPQUFPLEdBQUcsdUJBQXVCO1VBQ2pDLFdBQVcsTUFBTSxlQUFlLHVCQUF1QixFQUFFLE9BQU8sS0FBSztVQUNyRSxXQUFVO29CQUhaO1dBS0Usd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQXNCO1dBQTJCOzs7OztXQUMvRCx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBc0I7V0FBMkI7Ozs7O1dBQy9ELHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUF3QjtXQUE2Qjs7Ozs7VUFDN0Q7Ozs7O29CQUVSLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpRyxHQUFHLHVCQUF1QjtTQUFVOzs7O2lCQUVwSjs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQTRCOzs7O21CQUMxRyxZQUNDLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLEdBQUcsZ0JBQWdCO1dBQzFCLFdBQVcsTUFBTSxlQUFlLGdCQUFnQixFQUFFLE9BQU8sS0FBSztXQUM5RCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7O29CQUNELHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxHQUFHLGNBQWM7V0FDeEIsV0FBVyxNQUFNLGVBQWUsY0FBYyxFQUFFLE9BQU8sS0FBSztXQUM1RCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztvQkFFTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEI7V0FDRyxHQUFHLGVBQWUsR0FBRyxlQUFlLFFBQVE7V0FBSTtXQUFJLEdBQUcsYUFBYSxHQUFHLGFBQWEsT0FBTztVQUN4Rjs7Ozs7aUJBRUw7Ozs7O1FBQ0Y7Ozs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW9GO09BQStDOzs7O2lCQUNsSixZQUNDLHdCQUFDLFlBQUQ7UUFDRSxPQUFPO1FBQ1AsV0FBVyxNQUFNLDBCQUEwQixFQUFFLE9BQU8sS0FBSztRQUN6RCxNQUFNO1FBQ04sV0FBVTtRQUNWLGFBQVk7T0FDYjs7OztrQkFFRCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDViwwQkFBMEI7T0FDMUI7Ozs7ZUFFRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSxZQUFZLFdBQVcsYUFDdkIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsV0FBRDtTQUNFLE1BQU07U0FDTixLQUFLO1NBQ0wsS0FBSztTQUNMLFdBQVU7U0FDVixPQUFPLEVBQUUsV0FBVyxHQUFHLEdBQUcsYUFBYSxJQUFJLElBQUk7UUFDaEQ7Ozs7O09BQ0U7Ozs7a0JBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxpQ0FBa0M7Ozs7O1NBQ3BELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF5QztTQUF1RDs7Ozs7U0FDaEgsd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWpCLENBQXdKLGlCQUV0Six3QkFBQyxTQUFEO1dBQU8sTUFBSztXQUFPLFFBQU87V0FBVSxVQUFVO1dBQW1CLFdBQVU7VUFBVTs7OztrQkFDaEY7Ozs7OztRQUNKOzs7OztrQkFJTCxZQUFZLFdBQVcsZUFDdkIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7bUJBQ2pDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUEyQyxHQUFHLGFBQWEsS0FBSSxJQUFROzs7OztpQkFDcEU7Ozs7O2tCQUNMLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsS0FBSTtTQUNKLEtBQUk7U0FDSixPQUFPLEdBQUcsYUFBYTtTQUN2QixXQUFXLE1BQU0sZUFBZSxhQUFhLFNBQVMsRUFBRSxPQUFPLEtBQUssQ0FBQztTQUNyRSxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O2VBRUo7Ozs7OztLQUVGOzs7OztZQUVGOzs7Ozs7R0FNTixpQkFBaUIsbUJBQ2hCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FHRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNYLFlBQ0Msd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxPQUFPO09BQ1AsV0FBVyxNQUFNLFVBQVUsRUFBRSxPQUFPLEtBQUs7T0FDekMsV0FBVTtNQUNYOzs7O2lCQUVELHFEQUFxRCxVQUFVO0tBRS9EOzs7OztJQUNEOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUdFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXdJO09BRWxKOzs7O2lCQUNKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUFtQjs7OzttQkFDbEcsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsYUFBYTtTQUNWOzs7O2lCQUNIOzs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBdUI7Ozs7bUJBQ3JHLFlBQ0Msd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7VUFDNUMsV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLGFBQWE7U0FDVjs7OztpQkFFTDs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQW1DOzs7O21CQUNqSCxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLG1CQUFtQjtVQUM3QixXQUFXLE1BQU0sZUFBZSxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7VUFDakUsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixHQUFHLG1CQUFtQjtTQUNuQjs7OztpQkFFTDs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQXdCOzs7O21CQUN0RyxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLGlCQUFpQjtVQUMzQixXQUFXLE1BQU0sZUFBZSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7VUFDL0QsV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLEdBQUcsaUJBQWlCO1NBQ2pCOzs7O2lCQUVMOzs7OztRQUNGOzs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF3STtPQUVsSjs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBNkI7Ozs7bUJBQzNHLFlBQ0Msd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxNQUFLO1VBQ0wsT0FBTyxHQUFHLG1CQUFtQixHQUFHLGVBQWU7VUFDL0MsV0FBVyxNQUFNO1dBQ2YsZUFBZSxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7V0FDaEQsZUFBZSxlQUFlLEVBQUUsT0FBTyxLQUFLO1VBQzlDO1VBQ0EsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixHQUFHLG1CQUFtQixHQUFHLGNBQWMsR0FBRyxHQUFHLG1CQUFtQixHQUFHLFlBQVksTUFBTTtTQUNsRjs7OztpQkFFTDs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQTRCOzs7OzBCQUNuRztVQUNOLE1BQU0sSUFBSSxXQUFXLEdBQUcsbUJBQW1CLEdBQUcsV0FBVztVQUN6RCxJQUFJLE1BQU0sQ0FBQyxHQUFHLE9BQU8sd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWlCO1VBQWtCOzs7OztVQUN4RSxJQUFJLEtBQUssR0FBSztXQUNaLE9BQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWlIO1dBRTNIOzs7OztVQUVWLE9BQU8sSUFBSSxLQUFLLElBQU07V0FDcEIsT0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBMkc7V0FFckg7Ozs7O1VBRVYsT0FBTztXQUNMLE9BQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXFHO1dBRS9HOzs7OztVQUVWO1NBQ0YsRUFBQyxDQUFFLENBQ0E7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUF5Qjs7OzttQkFDdkcsWUFDQyx3QkFBQyxVQUFEO1VBQ0UsT0FBTyxHQUFHLGtCQUFrQjtVQUM1QixXQUFXLE1BQU0sZUFBZSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7VUFDaEUsV0FBVTtvQkFIWjtXQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUEyQjtXQUFnQzs7Ozs7V0FDekUsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQXFCO1dBQTBCOzs7OztXQUM3RCx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBMEI7V0FBK0I7Ozs7O1dBQ3ZFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUE4QjtXQUFtQzs7Ozs7VUFDekU7Ozs7O29CQUVSLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLEdBQUcsa0JBQWtCO1NBQ2xCOzs7O2lCQUVMOzs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBNEI7Ozs7bUJBQzFHLFlBQ0Msd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPLEdBQUcsMEJBQTBCO1VBQ3BDLFdBQVcsTUFBTSxlQUFlLDBCQUEwQixFQUFFLE9BQU8sS0FBSztVQUN4RSxhQUFZO1VBQ1osV0FBVTtTQUNYOzs7O29CQUVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLEdBQUcsMEJBQTBCO1NBQzFCOzs7O2lCQUVMOzs7OztRQUNGOzs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF3STtPQUVsSjs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBc0I7Ozs7bUJBQ3BHLFlBQ0Msd0JBQUMsVUFBRDtVQUNFLE9BQU8sR0FBRyxrQkFBa0I7VUFDNUIsV0FBVyxNQUFNLGVBQWUsa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1VBQ2hFLFdBQVU7b0JBSFo7V0FLRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBcUI7V0FBMEI7Ozs7O1dBQzdELHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFrQjtXQUF1Qjs7Ozs7V0FDdkQsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQWtDO1dBQXVDOzs7OztXQUN2Rix3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBZ0I7V0FBcUI7Ozs7O1VBQzdDOzs7OztvQkFFUix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixHQUFHLGtCQUFrQjtTQUNsQjs7OztpQkFFTDs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStEO1NBQStCOzs7O21CQUM3RyxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLEtBQUssbUJBQW1CLEdBQUcsZUFBZTtVQUNwRCxXQUFXLE1BQU0sZUFBZSxlQUFlLEVBQUUsT0FBTyxLQUFLO1VBQzdELGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7b0JBRUQsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsR0FBRyxLQUFLLG1CQUFtQixHQUFHLGVBQWU7U0FDMUM7Ozs7aUJBRUw7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErRDtTQUE4Qjs7OzttQkFDNUcsWUFDQyx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU8sR0FBRyxLQUFLLG9CQUFvQixHQUFHLG9CQUFvQjtVQUMxRCxXQUFXLE1BQU0sZUFBZSxvQkFBb0IsRUFBRSxPQUFPLEtBQUs7VUFDbEUsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixHQUFHLEtBQUssb0JBQW9CLEdBQUcsb0JBQW9CO1NBQ2hEOzs7O2lCQUVMOzs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBK0Q7U0FBZ0M7Ozs7bUJBQzlHLFlBQ0Msd0JBQUMsVUFBRDtVQUNFLE9BQU8sR0FBRyxhQUFhO1VBQ3ZCLFdBQVcsTUFBTSxlQUFlLGFBQWEsRUFBRSxPQUFPLEtBQUs7VUFDM0QsV0FBVTtvQkFIWjtXQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFpQztXQUFzQzs7Ozs7V0FDckYsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQXNDO1dBQTJDOzs7OztXQUMvRix3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBd0I7V0FBNkI7Ozs7O1VBQzdEOzs7OztvQkFFUix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixHQUFHLGFBQWE7U0FDYjs7OztpQkFFTDs7Ozs7UUFDRjs7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF1RztRQUVqSDs7OztrQkFDSCxhQUNDLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZTtVQUNiLE1BQU0sVUFBVSxHQUFHLHVCQUF1QixDQUFDO1VBQzNDLGVBQWUsdUJBQXVCLENBQ3BDLEdBQUcsU0FDSDtXQUFFLE9BQU8sVUFBVSxRQUFRLFNBQVM7V0FBSyxPQUFPO1dBQUksTUFBTTtXQUFJLFlBQVk7VUFBbUIsQ0FDL0YsQ0FBQztTQUNIO1NBQ0EsV0FBVTttQkFDWDtRQUVPOzs7O2dCQUVQOzs7OztpQkFFSCxHQUFHLHVCQUF1QixHQUFHLG9CQUFvQixTQUFTLElBQzFELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUNmLHdCQUFDLE1BQUQ7V0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBTTtXQUFzQjs7Ozs7V0FDMUMsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQU07V0FBa0I7Ozs7O1dBQ3RDLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFNO1dBQXNCOzs7OztXQUMxQyx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBTTtXQUFnQjs7Ozs7V0FDcEMsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQU07V0FBdUI7Ozs7O1dBQzFDLGFBQWEsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWtCO1dBQVU7Ozs7O1VBQ3REOzs7OztTQUNDOzs7O21CQUNQLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUNkLEdBQUcsb0JBQW9CLEtBQUssSUFBSSxRQUFRO1dBQ3ZDLE1BQU0sT0FBTyxXQUFXLEdBQUcsS0FBSztXQUNoQyxNQUFNLE1BQU0sV0FBVyxHQUFHLElBQUk7V0FDOUIsTUFBTSxTQUFVLENBQUMsTUFBTSxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsS0FBTSxPQUFPLElBQUcsQ0FBRSxRQUFRLENBQUMsSUFBSTtXQUN6RSxNQUFNLFdBQVcsV0FBVyxPQUFPLFdBQVcsTUFBTSxJQUFJO1dBRXhELE9BQ0Usd0JBQUMsTUFBRDtZQUNFLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNYLFlBQ0Msd0JBQUMsU0FBRDtjQUNFLE1BQUs7Y0FDTCxPQUFPLEdBQUcsY0FBYztjQUN4QixXQUFXLE1BQU07ZUFDZixNQUFNLFVBQVUsQ0FBQyxHQUFHLEdBQUcsbUJBQW1CO2VBQzFDLFFBQVEsT0FBTztnQkFBRSxHQUFHLFFBQVE7Z0JBQU0sWUFBWSxFQUFFLE9BQU87ZUFBTTtlQUM3RCxlQUFlLHVCQUF1QixPQUFPO2NBQy9DO2NBQ0EsYUFBWTtjQUNaLFdBQVU7YUFDWDs7Ozt3QkFDRSxHQUFHLGNBQWM7WUFDcEI7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1gsWUFDQyx3QkFBQyxTQUFEO2NBQ0UsTUFBSztjQUNMLE1BQUs7Y0FDTCxPQUFPLEdBQUcsU0FBUztjQUNuQixXQUFXLE1BQU07ZUFDZixNQUFNLFVBQVUsQ0FBQyxHQUFHLEdBQUcsbUJBQW1CO2VBQzFDLFFBQVEsT0FBTztnQkFBRSxHQUFHLFFBQVE7Z0JBQU0sT0FBTyxFQUFFLE9BQU87ZUFBTTtlQUN4RCxlQUFlLHVCQUF1QixPQUFPO2NBQy9DO2NBQ0EsYUFBWTtjQUNaLFdBQVU7YUFDWDs7Ozt3QkFDRSxHQUFHLFFBQVEsR0FBRyxHQUFHLE1BQU0sT0FBTztZQUNqQzs7Ozs7WUFDSix3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWCxZQUNDLHdCQUFDLFNBQUQ7Y0FDRSxNQUFLO2NBQ0wsTUFBSztjQUNMLE9BQU8sR0FBRyxRQUFRO2NBQ2xCLFdBQVcsTUFBTTtlQUNmLE1BQU0sVUFBVSxDQUFDLEdBQUcsR0FBRyxtQkFBbUI7ZUFDMUMsUUFBUSxPQUFPO2dCQUFFLEdBQUcsUUFBUTtnQkFBTSxNQUFNLEVBQUUsT0FBTztlQUFNO2VBQ3ZELGVBQWUsdUJBQXVCLE9BQU87Y0FDL0M7Y0FDQSxhQUFZO2NBQ1osV0FBVTthQUNYOzs7O3dCQUNFLEdBQUcsT0FBTyxHQUFHLEdBQUcsS0FBSyxPQUFPO1lBQy9COzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNYLFdBQVcsT0FBTyxHQUFHLFNBQVMsSUFBSSxNQUFNLEtBQUssT0FBTyxPQUFPO1lBQzFEOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNYLGFBQWEsT0FDWixXQUFXLEtBQ1Qsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQTBGO2FBRXBHOzs7O3dCQUNKLFdBQVcsS0FDYix3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBZ0c7YUFFMUc7Ozs7d0JBRU4sd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQXNHO2FBRWhIOzs7O3dCQUVOLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFpQjthQUFlOzs7OztZQUNsRDs7Ozs7WUFDSCxhQUNDLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNaLHdCQUFDLFVBQUQ7Y0FDRSxNQUFLO2NBQ0wsZUFBZTtlQUNiLE1BQU0sVUFBVSxHQUFHLG9CQUFvQixRQUFRLEdBQUcsTUFBTSxNQUFNLEdBQUc7ZUFDakUsZUFBZSx1QkFBdUIsT0FBTztjQUMvQztjQUNBLFdBQVU7d0JBQ1g7YUFFTzs7Ozs7WUFDTjs7Ozs7V0FFSixLQWxGSzs7OztrQkFrRkw7VUFFUixDQUFDO1NBQ0k7Ozs7aUJBQ0Y7Ozs7OztPQUNKOzs7O2tCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQTRHLGlFQUM1QyxZQUFZLDRFQUEwRSxFQUNqSjs7Ozs7ZUFFSjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBb0Y7T0FFOUY7Ozs7aUJBQ0wsWUFDQyx3QkFBQyxZQUFEO1FBQ0UsT0FBTztRQUNQLFdBQVcsTUFBTSwwQkFBMEIsRUFBRSxPQUFPLEtBQUs7UUFDekQsTUFBTTtRQUNOLFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7a0JBRUQsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsMEJBQTBCO09BQzFCOzs7O2VBRUY7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksWUFBWSxXQUFXLGFBQ3ZCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFdBQUQ7U0FDRSxNQUFNO1NBQ04sS0FBSztTQUNMLEtBQUs7U0FDTCxXQUFVO1NBQ1YsT0FBTyxFQUFFLFdBQVcsR0FBRyxHQUFHLGFBQWEsSUFBSSxJQUFJO1FBQ2hEOzs7OztPQUNFOzs7O2tCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsaUNBQWtDOzs7OztTQUNwRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBeUM7U0FBa0Q7Ozs7O1NBQzNHLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQixDQUF5SixpQkFFdkosd0JBQUMsU0FBRDtXQUFPLE1BQUs7V0FBTyxRQUFPO1dBQVUsVUFBVTtXQUFtQixXQUFVO1VBQVU7Ozs7a0JBQ2hGOzs7Ozs7UUFDSjs7Ozs7a0JBR0wsWUFBWSxXQUFXLGVBQ3ZCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7O21CQUNqQyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBNEMsR0FBRyxhQUFhLEtBQUksSUFBUTs7Ozs7aUJBQ3JFOzs7OztrQkFDTCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEtBQUk7U0FDSixLQUFJO1NBQ0osT0FBTyxHQUFHLGFBQWE7U0FDdkIsV0FBVyxNQUFNLGVBQWUsYUFBYSxTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUM7U0FDckUsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztlQUVKOzs7Ozs7S0FFRjs7Ozs7WUFFRjs7Ozs7O0dBTU4saUJBQWlCLHNCQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBR0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsWUFDQyx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sVUFBVSxFQUFFLE9BQU8sS0FBSztRQUN6QyxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2tCQUVELHNDQUFzQyxVQUFVO01BRWhEOzs7OztLQUNEOzs7OztLQUdMLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUNmLHdCQUFDLFNBQUQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFrSjtRQUU1Sjs7OztrQkFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1VBQzVDLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7b0JBRUQsYUFBYTtRQUViOzs7O2dCQUNGOzs7Ozs7T0FDSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUE0STtRQUV0Sjs7OztrQkFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxZQUNDLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxHQUFHLHNCQUFzQixHQUFHLDBCQUEwQjtVQUM3RCxXQUFXLE1BQU07V0FDZixlQUFlLHNCQUFzQixFQUFFLE9BQU8sS0FBSztXQUNuRCxlQUFlLDBCQUEwQixFQUFFLE9BQU8sS0FBSztVQUN6RDtVQUNBLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7b0JBRUQsR0FBRyxzQkFBc0IsR0FBRywwQkFBMEI7UUFFdEQ7Ozs7Z0JBQ0Y7Ozs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQTRJO1FBRXRKOzs7O2tCQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLFlBQ0Msd0JBQUMsVUFBRDtVQUNFLE9BQU8sR0FBRyxnQkFBZ0I7VUFDMUIsV0FBVyxNQUFNLGVBQWUsZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1VBQzlELFdBQVU7b0JBSFo7V0FLRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBa0M7V0FBdUM7Ozs7O1dBQ3ZGLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUF3QjtXQUF1Qzs7Ozs7V0FDN0Usd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQTJCO1dBQWdEOzs7OztVQUNuRjs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTJDLEdBQUcsZ0JBQWdCO1NBQXdDOzs7OztRQUV0SDs7OztnQkFDRjs7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBNEk7UUFFdEo7Ozs7a0JBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsWUFDQyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFVBQUQ7V0FDRSxPQUFPLHdCQUF3QixTQUFTLEdBQUcsZ0JBQWdCLEdBQUcsY0FBYyxJQUFLLEdBQUcsZ0JBQWdCLEdBQUcsaUJBQW9CLEdBQUcsZ0JBQWdCLEdBQUcsaUJBQWtCLFdBQVc7V0FDOUssV0FBVyxNQUFNO1lBQ2YsSUFBSSxFQUFFLE9BQU8sVUFBVSxVQUFVO2FBQy9CLGVBQWUsZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO2FBQzdDLGVBQWUsa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1lBQ2pEO1dBQ0Y7V0FDQSxXQUFVO3FCQVJaO1lBVUUsd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQUc7WUFBNkI7Ozs7O1lBQzlDLHdCQUFDLFlBQUQ7YUFBVSxPQUFNO3VCQUNiLHlCQUF5QixLQUFJLE1BQzVCLHdCQUFDLFVBQUQ7Y0FBZ0IsT0FBTzt3QkFBSTthQUFVLEdBQXhCOzs7O29CQUF3QixDQUN0QztZQUNPOzs7OztZQUNWLHdCQUFDLFlBQUQ7YUFBVSxPQUFNO3VCQUNiLHlCQUF5QixLQUFJLE1BQzVCLHdCQUFDLFVBQUQ7Y0FBZ0IsT0FBTzt3QkFBSTthQUFVLEdBQXhCOzs7O29CQUF3QixDQUN0QztZQUNPOzs7OztZQUNWLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFTO1lBQXVCOzs7OztXQUN4Qzs7Ozs7b0JBQ1Isd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLEdBQUcsZ0JBQWdCLEdBQUcsa0JBQWtCO1dBQy9DLFdBQVcsTUFBTTtZQUNmLGVBQWUsZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1lBQzdDLGVBQWUsa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1dBQ2pEO1dBQ0EsYUFBWTtXQUNaLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7b0JBRUwsR0FBRyxnQkFBZ0IsR0FBRyxrQkFBa0I7UUFFeEM7Ozs7Z0JBQ0Y7Ozs7OztPQUNKLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBNEk7T0FFdEo7Ozs7aUJBQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsWUFDQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxHQUFHLHdCQUF3QjtXQUNsQyxXQUFXLE1BQU0sZUFBZSx3QkFBd0IsRUFBRSxPQUFPLEtBQUs7V0FDdEUsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7VUFDRCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sR0FBRyxrQkFBa0I7V0FDNUIsV0FBVyxNQUFNLGVBQWUsa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1dBQ2hFLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7O1VBQ0Qsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLEdBQUcsT0FBTztXQUNqQixXQUFXLE1BQU0sZUFBZSxPQUFPLEVBQUUsT0FBTyxLQUFLO1dBQ3JELGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7O1VBQ0Qsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLEdBQUcsc0JBQXNCO1dBQ2hDLFdBQVcsTUFBTSxlQUFlLHNCQUFzQixFQUFFLE9BQU8sS0FBSztXQUNwRSxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztTQUNFOzs7OzttQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyx3QkFBQyxVQUFEO1lBQVEsV0FBVTtzQkFBaUI7V0FBc0I7Ozs7O1dBQUM7V0FBRSxHQUFHLHdCQUF3QjtXQUFZO1dBQUcsd0JBQUMsVUFBRDtZQUFRLFdBQVU7c0JBQWlCO1dBQWtCOzs7OztXQUFDO1dBQUUsR0FBRyxpQkFBaUI7VUFBbUI7Ozs7O1VBQzFNLHdCQUFDLE9BQUQ7V0FBSyx3QkFBQyxVQUFEO1lBQVEsV0FBVTtzQkFBaUI7V0FBMEI7Ozs7O1dBQUM7V0FBQyx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBc0MsR0FBRyxrQkFBa0I7V0FBVTs7Ozs7V0FBQztXQUFHLHdCQUFDLFVBQUQ7WUFBUSxXQUFVO3NCQUFpQjtXQUFtQjs7Ozs7V0FBQztXQUFDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFhLEdBQUcsT0FBTztXQUFVOzs7OztVQUFNOzs7OztVQUM1USx3QkFBQyxPQUFEO1dBQUssd0JBQUMsVUFBRDtZQUFRLFdBQVU7c0JBQWlCO1dBQWlDOzs7OztXQUFDO1dBQUUsR0FBRyxzQkFBc0I7VUFBUzs7Ozs7U0FDM0c7Ozs7OztPQUVMOzs7O2VBQ0Y7Ozs7O01BQ0M7Ozs7O0tBQ0Y7Ozs7O0tBR1Asd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQXNMO0tBRWhNOzs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLDRCQUFEO09BQ0UsWUFBWSxHQUFHLGNBQWMsQ0FBQztPQUM5QixXQUFXLHFCQUFxQixlQUFlLGNBQWMsZ0JBQWdCO09BQzdFLFVBQVUsQ0FBQztPQUNYLFFBQU87T0FDUCxXQUFVO01BQ1g7Ozs7O0tBQ0U7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBa0U7TUFBMEI7Ozs7Z0JBQzNHLFlBQ0Msd0JBQUMsWUFBRDtPQUNFLE9BQU87T0FDUCxXQUFXLE1BQU0sMEJBQTBCLEVBQUUsT0FBTyxLQUFLO09BQ3pELE1BQU07T0FDTixXQUFVO09BQ1YsYUFBWTtNQUNiOzs7O2lCQUVELHdCQUFDLEtBQUQsWUFBSSwwQkFBMEIsc0JBQXlCOzs7O2NBRXREOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxtQkFBRDtPQUNZO09BQ0Q7T0FDRztPQUNaLGtCQUFrQixTQUFTO1FBQ3pCLFlBQVksSUFBSTtRQUNoQixNQUFNLFNBQVMsSUFBSSxXQUFXO1FBQzlCLE9BQU8sa0JBQWtCO1NBQ3ZCLFdBQVcsT0FBTyxNQUFNO1FBQzFCO1FBQ0EsT0FBTyxjQUFjLElBQUk7UUFDekIsSUFBSSxZQUFZLElBQUksZ0JBQWdCLFVBQVU7UUFDOUMsY0FBYyxJQUFJLGdCQUFnQixJQUFJLENBQUM7T0FDekM7T0FDQSxnQkFBZ0I7UUFDZCxZQUFZLElBQUk7UUFDaEIsV0FBVyxJQUFJO1FBQ2YsSUFBSSxZQUFZLElBQUksZ0JBQWdCLFVBQVU7UUFDOUMsY0FBYyxJQUFJO09BQ3BCO09BQ0EsVUFBVSxDQUFDO09BQ1gsT0FBTTtPQUNOLFVBQVM7TUFDVjs7Ozs7S0FDRTs7Ozs7SUFFRjs7Ozs7O0dBSVAsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQXdJO0lBRWxKOzs7O2NBRUosd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW9GO09BQXlCOzs7OztPQUM1SCxZQUNDLGdEQUNFLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTyxHQUFHLGtCQUFrQjtRQUM1QixXQUFXLE1BQU0sZUFBZSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7UUFDaEUsV0FBVTtRQUNWLGFBQVk7T0FDYjs7OztpQkFDRCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixHQUFHLGtCQUFrQjtPQUNsQjs7OztlQUNOOzs7O2tCQUVGLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF5RCxHQUFHLGtCQUFrQjtPQUFVOzs7OztPQUUxRyx3QkFBQyxPQUFELEVBQUssV0FBVSw0REFBaUU7Ozs7O01BQzdFOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW9GO09BQWlDOzs7OztPQUNwSSxZQUNDLGdEQUNFLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTyxHQUFHLG1CQUFtQjtRQUM3QixXQUFXLE1BQU0sZUFBZSxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7UUFDakUsV0FBVTtRQUNWLGFBQVk7T0FDYjs7OztpQkFDRCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixHQUFHLG1CQUFtQjtPQUNuQjs7OztlQUNOOzs7O2tCQUVGLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF5RCxHQUFHLG1CQUFtQjtPQUFVOzs7OztPQUUzRyx3QkFBQyxPQUFELEVBQUssV0FBVSw0REFBaUU7Ozs7O01BQzdFOzs7OzthQUNGOzs7OztZQUNGOzs7Ozs7R0FFTCx3QkFBQyxzQkFBRDtJQUNFLFFBQVE7SUFDUixlQUFlLHNCQUFzQixLQUFLO0lBQzFDLGFBQWE7SUFDYixpQkFBaUIsR0FBRyxZQUFZLEdBQUcsYUFBYSxDQUFDO0lBQ2pELFVBQVUsR0FBRyxZQUFZO0lBQ3pCLE1BQU07SUFDTixZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLFNBQVMsVUFBVSxZQUFZO0tBQzdCLE1BQU0sc0JBQXNCLGVBQWUsYUFBYSxlQUFlLGNBQWMsU0FBUyxTQUFTLFVBQVU7S0FFakgsSUFBSSxtQkFBbUI7S0FDdkIsSUFBSSx1QkFBdUIsUUFBUSxRQUFRO01BQ3pDLG1CQUFtQixRQUFRO01BQzNCLGlCQUFpQixRQUFRLE1BQU07S0FDakM7S0FFQSxJQUFJLFFBQVEsRUFBRSxHQUFHLEdBQUc7O0tBR3BCLElBQUksaUJBQWlCLGlCQUFpQjtNQUNwQyxNQUFNLGFBQWEsc0JBQXNCLGFBQWE7TUFDdEQsTUFBTSxTQUFTLEdBQUcsYUFBYSxlQUFlLENBQUM7TUFFL0MsUUFBUTtPQUNOLEdBQUc7T0FDSCxZQUFZO1FBQ1YsR0FBSSxNQUFNLGNBQWMsQ0FBQztTQUN4QixhQUFhO1NBQ1osR0FBRztTQUNILFNBQVMsUUFBUSxhQUFhLE9BQU8sV0FBVztTQUNoRCxTQUFTLFFBQVEsa0JBQWtCLGFBQWEsT0FBTyxXQUFXO1NBQ2xFLFdBQVcsUUFBUSxrQkFBa0IsY0FBYyxPQUFPLGFBQWE7U0FDdkUsZUFBZSxRQUFRLFVBQVUsT0FBTyxpQkFBaUI7U0FDekQsR0FBSSx1QkFBdUIsUUFBUSxRQUFRLFNBQVMsT0FBTyxJQUFJLEVBQUUsT0FBTyxLQUFLLElBQUksQ0FBQztRQUNwRjtPQUNGO01BQ0Y7TUFFQSxJQUFJLFFBQVEsa0JBQWtCLFNBQVM7T0FDckMsTUFBTSxrQkFBa0IsUUFBUSxpQkFBaUI7T0FDakQsTUFBTSxrQkFBa0IsUUFBUSxpQkFBaUI7TUFDbkQ7TUFDQSxJQUFJLFFBQVEsa0JBQWtCLG1CQUFtQjtPQUMvQyxNQUFNLG9CQUFvQixRQUFRLGlCQUFpQjtPQUNuRCxNQUFNLG9CQUFvQixRQUFRLGlCQUFpQjtNQUNyRDtLQUNGOztLQUdBLElBQUksaUJBQWlCLGFBQWE7TUFDaEMsSUFBSSxRQUFRLFNBQVMsS0FBSyxNQUFNLFdBQVcsUUFBUSxRQUFRO01BQzNELElBQUksUUFBUSxrQkFBa0IsZUFBZSxNQUFNLGNBQWMsUUFBUSxpQkFBaUI7S0FDNUY7O0tBR0EsSUFBSSxpQkFBaUIsWUFBWTtNQUMvQixJQUFJLFNBQVMsU0FBUyxVQUFVLEdBQUc7T0FDakMsTUFBTSx5QkFBeUIsUUFBUSxhQUFhLFFBQVEsVUFBVSxNQUFNO01BQzlFLE9BQU8sSUFBSSxTQUFTLFNBQVMsVUFBVSxHQUFHO09BQ3hDLE1BQU0seUJBQXlCLFFBQVEsYUFBYSxRQUFRLFVBQVUsTUFBTTtNQUM5RSxPQUFPLElBQUksU0FBUyxTQUFTLFdBQVcsR0FBRztPQUN6QyxNQUFNLFFBQVEsUUFBUSxhQUFhLFFBQVEsVUFBVSxNQUFNO01BQzdEO0tBQ0Y7O0tBR0EsSUFBSSxRQUFRLGtCQUFrQjtNQUM1QixRQUFRO09BQUUsR0FBRztPQUFPLEdBQUcsUUFBUTtNQUFpQjtLQUNsRDtLQUVBLE1BQU0sS0FBSzs7S0FHWCxJQUFJLFVBQVU7TUFDWixTQUFTO09BQ1AsR0FBRztPQUNILGVBQWU7T0FDZixlQUFlO01BQ2pCLENBQUM7S0FDSDs7S0FHQSxJQUFJLFFBQVEsZ0JBQWdCLDJCQUEyQixjQUFjLFlBQVk7TUFDL0UsTUFBTSxpQkFBaUIsUUFBUSxxQkFBcUIsUUFBUTtNQUM1RCxJQUFJLENBQUMsZ0JBQWdCO09BQ25CLHlCQUF5QixhQUFhLFlBQVk7UUFDaEQsUUFBUSxRQUFRLFVBQVUsUUFBUSxXQUFXLGtDQUFrQyxRQUFRLFNBQVMsMkJBQTJCLFNBQVM7UUFDcEksY0FBYztRQUNkLGdCQUFnQjtPQUNsQixDQUFDO01BQ0g7S0FDRjtJQUNGO0dBQ0Q7Ozs7O0VBRUU7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkZpY2hhVGVjbmljYUNvbXBvbmVudC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgU2F2ZSwgXG4gIEVkaXQzLCBcbiAgQ2FtZXJhLCBcbiAgUHJpbnRlcixcbiAgU2V0dGluZ3MsXG4gIFphcCxcbiAgUm90YXRlQ2N3XG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgdXNlU3RvcmUgZnJvbSAnLi4vc3RvcmUvdXNlU3RvcmUnO1xuaW1wb3J0IHsgdXNlQ29uZmlybSB9IGZyb20gJy4uL2NvbnRleHQvQ29uZmlybUNvbnRleHQnO1xuaW1wb3J0IE1vZGFsRWRpY2lvbkNpcmN1aXRvIGZyb20gJy4vTW9kYWxFZGljaW9uQ2lyY3VpdG8nO1xuaW1wb3J0IFNlbGVjdG9yQWxpbWVudGFkb3JKZXJhcnF1aWNvIGZyb20gJy4vU2VsZWN0b3JBbGltZW50YWRvckplcmFycXVpY28nO1xuaW1wb3J0IFRyYW5zZmVyQ29tcG9uZW50IGZyb20gJy4vVHJhbnNmZXJDb21wb25lbnQnO1xuaW1wb3J0IE1ldHJvbG9naWFFbGVjdHJpY2FTZWN0aW9uIGZyb20gJy4vTWV0cm9sb2dpYUVsZWN0cmljYVNlY3Rpb24nO1xuaW1wb3J0IER1YWxQaG90b1VwbG9hZGVyIGZyb20gJy4vRHVhbFBob3RvVXBsb2FkZXInO1xuaW1wb3J0IHsgXG4gIFRFTlNJT05FU19DT1ZFTklOXzE1OV9CVCwgXG4gIFRFTlNJT05FU19DT1ZFTklOXzE1OV9NVCwgXG4gIFRFTlNJT05FU19DT1ZFTklOX1RPREFTIFxufSBmcm9tICcuLi91dGlscy9jb25zdGFudHMnO1xuXG4vLyBDb21wb25lbnRlIHBhcmEgcmVuZGVyaXphciBCbG9icyBkZSBpbWFnZW4gZGUgZm9ybWEgc2VndXJhXG5jb25zdCBTYWZlSW1hZ2UgPSAoeyBibG9iLCBzcmMsIGFsdCwgY2xhc3NOYW1lIH0pID0+IHtcbiAgY29uc3QgW29iamVjdFVybCwgc2V0T2JqZWN0VXJsXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGJsb2IpIHtcbiAgICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgICBzZXRPYmplY3RVcmwodXJsKTtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbiAgICAgIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldE9iamVjdFVybChudWxsKTtcbiAgICB9XG4gIH0sIFtibG9iXSk7XG5cbiAgY29uc3QgZmluYWxTcmMgPSBvYmplY3RVcmwgfHwgc3JjO1xuICBpZiAoIWZpbmFsU3JjKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gPGltZyBzcmM9e2ZpbmFsU3JjfSBhbHQ9e2FsdH0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IC8+O1xufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRmljaGFUZWNuaWNhQ29tcG9uZW50KHsgZWxlbWVudG9EYXRhLCBvblVwZGF0ZSwgcmVhZE9ubHkgfSkge1xuICBjb25zdCBbaXNFZGl0aW5nLCBzZXRJc0VkaXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCB7IGFsZXJ0OiBjdXN0b21BbGVydCwgY29uZmlybTogY3VzdG9tQ29uZmlybSB9ID0gdXNlQ29uZmlybSgpO1xuICBjb25zdCBjb21wYW5pZXMgPSB1c2VTdG9yZSgoc3RhdGUpID0+IHN0YXRlLmNvbXBhbmllcyB8fCBbXSk7XG5cbiAgY29uc3QgYWxsRmVlZGVycyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IGxpc3QgPSBbXTtcbiAgICBjb25zdCBjb21wSWQgPSBlbGVtZW50b0RhdGE/LmVtcHJlc2FJZCB8fCBlbGVtZW50b0RhdGE/LmNvbXBhbnlJZDtcbiAgICBjb25zdCBjb21wYW55ID0gY29tcGFuaWVzLmZpbmQoYyA9PiBjLmlkID09PSBjb21wSWQpO1xuICAgIGlmICghY29tcGFueSkge1xuICAgICAgY29tcGFuaWVzLmZvckVhY2goYyA9PiB7XG4gICAgICAgIGlmIChjLmVsZW1lbnRvc1VuaWZpbGFyZXMpIHtcbiAgICAgICAgICBsaXN0LnB1c2goLi4uYy5lbGVtZW50b3NVbmlmaWxhcmVzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYy5wcm95ZWN0b3MpIHtcbiAgICAgICAgICBjLnByb3llY3Rvcy5mb3JFYWNoKHAgPT4ge1xuICAgICAgICAgICAgY29uc3QgZWxMaXN0ID0gcC5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IHAudGFibGVyb3MgfHwgW107XG4gICAgICAgICAgICBsaXN0LnB1c2goLi4uZWxMaXN0KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICByZXR1cm4gbGlzdC5maWx0ZXIoZSA9PiBlLmlkICE9PSBlbGVtZW50b0RhdGE/LmlkKTtcbiAgICB9XG5cbiAgICBpZiAoY29tcGFueS5lbGVtZW50b3NVbmlmaWxhcmVzKSB7XG4gICAgICBsaXN0LnB1c2goLi4uY29tcGFueS5lbGVtZW50b3NVbmlmaWxhcmVzKTtcbiAgICB9XG4gICAgaWYgKGNvbXBhbnkucHJveWVjdG9zKSB7XG4gICAgICBjb21wYW55LnByb3llY3Rvcy5mb3JFYWNoKHAgPT4ge1xuICAgICAgICBjb25zdCBlbExpc3QgPSBwLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgcC50YWJsZXJvcyB8fCBbXTtcbiAgICAgICAgbGlzdC5wdXNoKC4uLmVsTGlzdCk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGxpc3QuZmlsdGVyKGUgPT4gZS5pZCAhPT0gZWxlbWVudG9EYXRhPy5pZCk7XG4gIH0sIFtjb21wYW5pZXMsIGVsZW1lbnRvRGF0YV0pO1xuXG4gIC8vIENhbXBvcyBwcmluY2lwYWxlc1xuICBjb25zdCBbbm9tYnJlLCBzZXROb21icmVdID0gdXNlU3RhdGUoZWxlbWVudG9EYXRhPy5ub21icmUgfHwgJycpO1xuICBjb25zdCBbdWJpY2FjaW9uLCBzZXRVYmljYWNpb25dID0gdXNlU3RhdGUoZWxlbWVudG9EYXRhPy51YmljYWNpb24gfHwgJycpO1xuICBjb25zdCBbYWxpbWVudGFkb1Bvciwgc2V0QWxpbWVudGFkb1Bvcl0gPSB1c2VTdGF0ZShlbGVtZW50b0RhdGE/LmFsaW1lbnRhZG9Qb3IgfHwgJycpO1xuICBjb25zdCBbb2JzZXJ2YWNpb25lc0dlbmVyYWxlcywgc2V0T2JzZXJ2YWNpb25lc0dlbmVyYWxlc10gPSB1c2VTdGF0ZShlbGVtZW50b0RhdGE/Lm9ic2VydmFjaW9uZXNHZW5lcmFsZXMgfHwgJycpO1xuICBjb25zdCBbZm90b0Jsb2IsIHNldEZvdG9CbG9iXSA9IHVzZVN0YXRlKGVsZW1lbnRvRGF0YT8uZm90b0Jsb2IgfHwgbnVsbCk7XG4gIGNvbnN0IFtmb3RvU3JjLCBzZXRGb3RvU3JjXSA9IHVzZVN0YXRlKGVsZW1lbnRvRGF0YT8uZm90byB8fCBudWxsKTtcbiAgY29uc3QgW3ByZXZpZXdVcmwsIHNldFByZXZpZXdVcmxdID0gdXNlU3RhdGUobnVsbCk7XG5cbiAgLy8gZGF0b3NUZWNuaWNvcyBKU09OXG4gIGNvbnN0IFtkdCwgc2V0RHRdID0gdXNlU3RhdGUoZWxlbWVudG9EYXRhPy5kYXRvc1RlY25pY29zIHx8IHt9KTtcblxuICAvLyBXaXphcmQgTW9kYWwgSmVyYXJxdcOtYVxuICBjb25zdCB7IGNyZWFyRWxlbWVudG9Qcm92aXNpb25hbCB9ID0gdXNlU3RvcmUoKTtcbiAgY29uc3QgW21vZGFsSmVyYXJxdWlhT3Blbiwgc2V0TW9kYWxKZXJhcnF1aWFPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2NpcmN1aXREYXRhV2l6YXJkLCBzZXRDaXJjdWl0RGF0YVdpemFyZF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW3dpemFyZE1vZG8sIHNldFdpemFyZE1vZG9dID0gdXNlU3RhdGUoJ1NBTElEQScpO1xuXG4gIC8vIFJlc3RyaW5naXIgYSBsYXMgb3BjaW9uZXMgcGVybWl0aWRhczogVEFCTEVSTywgVFJBTlNGRVIsIEdFTkVSQURPUiwgVFJBTlNGT1JNQURPUlxuICBjb25zdCB0aXBvRWxlbWVudG8gPSBlbGVtZW50b0RhdGE/LnRpcG9FbGVtZW50byB8fCAnVEFCTEVSTyc7XG5cbiAgaWYgKCFlbGVtZW50b0RhdGEpIHtcbiAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTggdGV4dC1zbGF0ZS00MDAgZm9udC1zYW5zXCI+Tm8gaGF5IGRhdG9zIGRlbCBlbGVtZW50byBzZWxlY2Npb25hZG9zLjwvZGl2PjtcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUR0Q2hhbmdlID0gKGtleSwgdmFsdWUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBzZXREdCgocHJldikgPT4gKHsgLi4ucHJldiwgW2tleV06IHZhbHVlIH0pKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVOZXN0ZWREdENoYW5nZSA9IChwYXJlbnRLZXksIGtleSwgdmFsdWUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBzZXREdCgocHJldikgPT4gKHtcbiAgICAgIC4uLnByZXYsXG4gICAgICBbcGFyZW50S2V5XToge1xuICAgICAgICAuLi4ocHJldltwYXJlbnRLZXldIHx8IHt9KSxcbiAgICAgICAgW2tleV06IHZhbHVlXG4gICAgICB9XG4gICAgfSkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNwdENoYW5nZSA9IChrZXksIHZhbHVlKSA9PiB7XG4gICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgc2V0RHQoKHByZXYpID0+ICh7XG4gICAgICAuLi5wcmV2LFxuICAgICAgc3B0OiB7XG4gICAgICAgIC4uLihwcmV2LnNwdCB8fCB7fSksXG4gICAgICAgIFtrZXldOiB2YWx1ZVxuICAgICAgfVxuICAgIH0pKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVBY29tZXRpZGFDaGFuZ2UgPSAoc2VjY2lvbiwga2V5LCB2YWx1ZSkgPT4ge1xuICAgIGlmIChyZWFkT25seSkgcmV0dXJuO1xuICAgIHNldER0KChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIGFjb21ldGlkYXM6IHtcbiAgICAgICAgLi4uKHByZXYuYWNvbWV0aWRhcyB8fCB7fSksXG4gICAgICAgIFtzZWNjaW9uXToge1xuICAgICAgICAgIC4uLigocHJldi5hY29tZXRpZGFzICYmIHByZXYuYWNvbWV0aWRhc1tzZWNjaW9uXSkgfHwge30pLFxuICAgICAgICAgIFtrZXldOiB2YWx1ZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUltYWdlQ2hhbmdlID0gKGUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXNbMF07XG4gICAgaWYgKCFmaWxlKSByZXR1cm47XG4gICAgaWYgKGZpbGUuc2l6ZSA+IDEwICogMTAyNCAqIDEwMjQpIHtcbiAgICAgIGN1c3RvbUFsZXJ0KFwiTGEgaW1hZ2VuIGVzIGRlbWFzaWFkbyBncmFuZGUuIFBvciBmYXZvciBlbGlqYSB1bmEgZGUgbWVub3MgZGUgMTBNQi5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldEZvdG9CbG9iKGZpbGUpO1xuICAgIGlmIChwcmV2aWV3VXJsKSBVUkwucmV2b2tlT2JqZWN0VVJMKHByZXZpZXdVcmwpO1xuICAgIHNldFByZXZpZXdVcmwoVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2F2ZSA9IChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmIChyZWFkT25seSkgcmV0dXJuO1xuICAgIGlmIChvblVwZGF0ZSkge1xuICAgICAgb25VcGRhdGUoe1xuICAgICAgICAuLi5lbGVtZW50b0RhdGEsXG4gICAgICAgIG5vbWJyZSxcbiAgICAgICAgdWJpY2FjaW9uLFxuICAgICAgICBhbGltZW50YWRvUG9yLFxuICAgICAgICBvYnNlcnZhY2lvbmVzR2VuZXJhbGVzLFxuICAgICAgICBmb3RvQmxvYixcbiAgICAgICAgZm90bzogZm90b1NyYyxcbiAgICAgICAgZGF0b3NUZWNuaWNvczogZHRcbiAgICAgIH0pO1xuICAgIH1cbiAgICBzZXRJc0VkaXRpbmcoZmFsc2UpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxpbXBpYXJGb3JtdWxhcmlvID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmIChyZWFkT25seSkgcmV0dXJuO1xuICAgIGNvbnN0IGNvbmZpcm1lZCA9IGF3YWl0IGN1c3RvbUNvbmZpcm0oXCLCv0Rlc2VhcyByZWluaWNpYXIgdG9kb3MgbG9zIGNhbXBvcyB0w6ljbmljb3MgZGUgZXN0ZSBlbGVtZW50byBhIGJsYW5jbz9cIik7XG4gICAgaWYgKCFjb25maXJtZWQpIHJldHVybjtcbiAgICBzZXROb21icmUoJycpO1xuICAgIHNldFViaWNhY2lvbignJyk7XG4gICAgc2V0QWxpbWVudGFkb1BvcignJyk7XG4gICAgc2V0T2JzZXJ2YWNpb25lc0dlbmVyYWxlcygnJyk7XG4gICAgc2V0RHQoe30pO1xuICAgIHNldEZvdG9CbG9iKG51bGwpO1xuICAgIHNldEZvdG9TcmMobnVsbCk7XG4gICAgaWYgKHByZXZpZXdVcmwpIFVSTC5yZXZva2VPYmplY3RVUkwocHJldmlld1VybCk7XG4gICAgc2V0UHJldmlld1VybChudWxsKTtcbiAgfTtcblxuICBjb25zdCByZW5kZXJFbGVtZW50V2l0aElkID0gKG5vbWJyZVRleHQsIGZhbGxiYWNrSWQpID0+IHtcbiAgICBpZiAoIW5vbWJyZVRleHQpIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJvcGFjaXR5LTQwXCI+4oCUPC9zcGFuPjtcbiAgICBsZXQgY2xlYW5OYW1lID0gbm9tYnJlVGV4dDtcbiAgICBsZXQgZWxlbWVudElkID0gZmFsbGJhY2tJZCB8fCBudWxsO1xuXG4gICAgY29uc3QgbWF0Y2ggPSBTdHJpbmcobm9tYnJlVGV4dCkubWF0Y2goL14oLio/KSg/OlxccypcXCgoPzpJRDpcXHMqKT8oW0EtWjAtOV8tXSspXFwpKT8kL2kpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgaWYgKG1hdGNoWzFdKSBjbGVhbk5hbWUgPSBtYXRjaFsxXS50cmltKCk7XG4gICAgICBpZiAobWF0Y2hbMl0gJiYgIWVsZW1lbnRJZCkgZWxlbWVudElkID0gbWF0Y2hbMl0udHJpbSgpO1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmbGV4LXdyYXBcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTEwMCBwcmludDp0ZXh0LWJsYWNrXCI+e2NsZWFuTmFtZX08L3NwYW4+XG4gICAgICAgIHtlbGVtZW50SWQgJiYgKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtWzEwcHhdIGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBweC0xLjUgcHktMC41IHJvdW5kZWQgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICBJRDoge2VsZW1lbnRJZH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICl9XG4gICAgICA8L3NwYW4+XG4gICAgKTtcbiAgfTtcblxuICBjb25zdCByZW5kZXJCYWRnZSA9ICgpID0+IHtcbiAgICBzd2l0Y2ggKHRpcG9FbGVtZW50bykge1xuICAgICAgY2FzZSAnVFJBTlNGT1JNQURPUic6XG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJweC0zLjUgcHktMSBiZy1hbWJlci05NTAvOTAgdGV4dC1hbWJlci01MDAgYm9yZGVyIGJvcmRlci1hbWJlci04MDAvNTAgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkIGZvbnQtbW9ub1wiPuKaoSBUUkFOU0ZPUk1BRE9SIEVMw4lDVFJJQ088L3NwYW4+O1xuICAgICAgY2FzZSAnR0VORVJBRE9SJzpcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xIGJnLWFtYmVyLTk1MC85MCB0ZXh0LWFtYmVyLTUwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTgwMC81MCByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgZm9udC1tb25vXCI+4pqhIEdFTkVSQURPUjwvc3Bhbj47XG4gICAgICBjYXNlICdUUkFOU0ZFUic6XG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJweC0zLjUgcHktMSBiZy1hbWJlci05NTAvOTAgdGV4dC1hbWJlci01MDAgYm9yZGVyIGJvcmRlci1hbWJlci04MDAvNTAgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkIGZvbnQtbW9ub1wiPvCflIQgVFJBTlNGRVJFTkNJQSAoQVRTIC8gTVRTKTwvc3Bhbj47XG4gICAgICBjYXNlICdCQU5DT19DT05ERU5TQURPUic6XG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJweC0zLjUgcHktMSBiZy1hbWJlci05NTAvOTAgdGV4dC1hbWJlci01MDAgYm9yZGVyIGJvcmRlci1hbWJlci04MDAvNTAgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkIGZvbnQtbW9ub1wiPuKaoSBCQU5DTyBERSBDT05ERU5TQURPUkVTPC9zcGFuPjtcbiAgICAgIGNhc2UgJ1BVRVNUQV9USUVSUkEnOlxuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwicHgtMy41IHB5LTEgYmctYW1iZXItOTUwLzkwIHRleHQtYW1iZXItNTAwIGJvcmRlciBib3JkZXItYW1iZXItODAwLzUwIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtYm9sZCBmb250LW1vbm9cIj7wn5uh77iPIE1BTExBIFBVRVNUQSBBIFRJRVJSQTwvc3Bhbj47XG4gICAgICBjYXNlICdQVU5UT19TVU1JTklTVFJPJzpcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xIGJnLWJsdWUtOTUwLzkwIHRleHQtYmx1ZS00MDAgYm9yZGVyIGJvcmRlci1ibHVlLTgwMC81MCByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgZm9udC1tb25vXCI+8J+UjCBQVU5UTyBERSBTVU1JTklTVFJPIC8gQUNPTUVUSURBPC9zcGFuPjtcbiAgICAgIGNhc2UgJ0NDTSc6XG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJweC0zLjUgcHktMSBiZy1hbWJlci05NTAvOTAgdGV4dC1hbWJlci01MDAgYm9yZGVyIGJvcmRlci1hbWJlci04MDAvNTAgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkIGZvbnQtbW9ub1wiPuKame+4jyBDRU5UUk8gREUgQ09OVFJPTCBERSBNT1RPUkVTIChDQ00pPC9zcGFuPjtcbiAgICAgIGNhc2UgJ1RBQkxFUk8nOlxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xIGJnLWFtYmVyLTk1MC85MCB0ZXh0LWFtYmVyLTUwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTgwMC81MCByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgZm9udC1tb25vXCI+4pqhIFBBTkVMIEVMw4lDVFJJQ088L3NwYW4+O1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtgbWF4LXctNXhsIG14LWF1dG8gc3BhY2UteS02IGFuaW1hdGUtZmFkZS1pbiBmb250LXNhbnMgcGItMTIgcHJpbnQtY2FyZCBwcmludDpwLTAgcHJpbnQ6bS0wICR7cmVhZE9ubHkgPyAncG9pbnRlci1ldmVudHMtbm9uZSBvcGFjaXR5LTkwJyA6ICcnfWB9PlxuICAgICAgXG4gICAgICB7LyogQm90b25lcyBkZSBjb250cm9sIHN1cGVyaW9yIChPY3VsdG9zIGVuIGltcHJlc2nDs24pICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbm8tcHJpbnRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIHtyZW5kZXJCYWRnZSgpfVxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LW1vbm8gZm9udC1ibGFjayB0ZXh0LWFtYmVyLTQwMCBiZy1hbWJlci01MDAvMTAgcHgtMi41IHB5LTEgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCB0ZXh0LXhzIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgSUQ6IHtlbGVtZW50b0RhdGEuaWR9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LnByaW50KCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgcHgtMy41IHB5LTIgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICB0aXRsZT1cIkd1YXJkYXIgY29tbyBQREYgbyBJbXByaW1pciBlc3RhIFBsYW50aWxsYSBJbmRpdmlkdWFsXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gR3VhcmRhciBQREZcbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIHshcmVhZE9ubHkgJiYgKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAge2lzRWRpdGluZyAmJiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMaW1waWFyRm9ybXVsYXJpb31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBob3ZlcjpiZy1yZWQtOTUwLzYwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtcmVkLTQwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItcmVkLTgwMCBmb250LWJvbGQgcHgtMyBweS0yIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVpbmljaWFyIHRvZG9zIGxvcyBjYW1wb3MgYSBibGFuY29cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPkxpbXBpYXIgRm9ybXVsYXJpbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ibGFjayBob3ZlcjpiZy13aGl0ZSBhY3RpdmU6c2NhbGUtOTggdHJhbnNpdGlvbi1hbGwgcHgtNCBweS0yIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBjdXJzb3ItcG9pbnRlciBzaGFkb3ctbWRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxTYXZlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTYwMFwiIC8+IEd1YXJkYXIgQ2FtYmlvc1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzRWRpdGluZyh0cnVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0yMDAgZm9udC1zZW1pYm9sZCBweC00IHB5LTIgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8RWRpdDMgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+IEVkaXRhciBQbGFudGlsbGFcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgey8qIDEuIFBMQU5USUxMQTogUEFORUwgRUzDiUNUUklDTyAvIFRBQkxFUk8gKFwiSU5GT1JNQUNJw5NOIEdFTkVSQUwgREUgVEFCTEVSTyBOby4gWFwiKSAqL31cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAge3RpcG9FbGVtZW50byA9PT0gJ1RBQkxFUk8nICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctMnhsIHByaW50OmJvcmRlci1ibGFjayBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIFTDrXR1bG8gUHJpbmNpcGFsICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlci1iLTIgYm9yZGVyLXNsYXRlLTcwMCBwLTMuNSB0ZXh0LWNlbnRlciBwcmludDpiZy1ncmF5LTIwMCBwcmludDpib3JkZXItYmxhY2tcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgbWQ6dGV4dC1sZyBmb250LWJsYWNrIHRyYWNraW5nLXdpZGUgdGV4dC1zbGF0ZS0xMDAgdXBwZXJjYXNlIGZvbnQtbW9ubyBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bm9tYnJlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROb21icmUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNjAwIHJvdW5kZWQgcHgtMyBweS0xIHRleHQtY2VudGVyIHctZnVsbCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTEwMCBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgYElORk9STUFDScOTTiBHRU5FUkFMIERFIFRBQkxFUk8gJHtub21icmUgPyAnTm8uICcgKyBub21icmUgOiAnTm8uIDIwJ31gXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEZpbGEgMTogVWJpY2FjacOzbiAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS03MDAgcC0zIGJnLXNsYXRlLTkwMC82MCBmb250LW1vbm8gdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHVwcGVyY2FzZSB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LWJsYWNrIG1yLTJcIj5VQklDQUNJw5NOOjwvc3Bhbj5cbiAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17dWJpY2FjaW9ufVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VWJpY2FjaW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgdy0zLzRcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPnt1YmljYWNpb24gfHwgJ1NPVEFOTyBTQUxBIERFIFRBQkxFUk9TJ308L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEZpbGEgMjogQWxpbWVudGFkbyBQb3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtNzAwIHAtMyBiZy1zbGF0ZS05MDAvNDAgZm9udC1tb25vIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItYmxhY2sgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdXBwZXJjYXNlIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtYmxhY2sgbXItMlwiPlRBQkxFUk8gQUxJTUVOVEFETyBQT1I6PC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0V2l6YXJkTW9kbygnRU5UUkFEQScpO1xuICAgICAgICAgICAgICAgICAgc2V0Q2lyY3VpdERhdGFXaXphcmQoe1xuICAgICAgICAgICAgICAgICAgICBpZDogJ0FMSU1FTlRBQ0lPTl9QUklOQ0lQQUwnLFxuICAgICAgICAgICAgICAgICAgICBub21icmU6ICdBY29tZXRpZGEgLyBGdWVudGUgUHJpbmNpcGFsJyxcbiAgICAgICAgICAgICAgICAgICAgZXF1aXBvOiBhbGltZW50YWRvUG9yIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICBwb2xlczogWzFdLFxuICAgICAgICAgICAgICAgICAgICBicmVha2VyOiB7IGFtcDogJycsIG1hcmNhOiAnJywgdGlwbzogJycgfVxuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICBzZXRNb2RhbEplcmFycXVpYU9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJuby1wcmludCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctYW1iZXItNTAwLzEwIGhvdmVyOmJnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJDb25maWd1cmFyIE9yaWdlbiBkZSBBbGltZW50YWNpw7NuIChXaXphcmQpXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxTZXR0aW5ncyBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtYW1iZXItNDAwXCIgLz4gQ29uZmlndXJhciBKZXJhcnF1w61hXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LTIvM1wiPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RvckFsaW1lbnRhZG9ySmVyYXJxdWljb1xuICAgICAgICAgICAgICAgICAgcHJveWVjdG9JZD17ZWxlbWVudG9EYXRhPy5wcm95ZWN0b0lkfVxuICAgICAgICAgICAgICAgICAgdGFibGVyb0FjdHVhbElkPXtlbGVtZW50b0RhdGE/LmlkfVxuICAgICAgICAgICAgICAgICAgZWxlbWVudG9zTGlzdD17YWxsRmVlZGVyc31cbiAgICAgICAgICAgICAgICAgIHZhbHVlPXthbGltZW50YWRvUG9yfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldEFsaW1lbnRhZG9Qb3IodmFsKX1cbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiXCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWNjaW9uYXIgbyBlc2NyaWJpciBwcm9jZWRlbmNpYS4uLlwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICByZW5kZXJFbGVtZW50V2l0aElkKGFsaW1lbnRhZG9Qb3IgfHwgJ0FUUyBTT1RBTk8gKElEOiBBVFMtMSknLCBlbGVtZW50b0RhdGE/LmFsaW1lbnRhZG9Qb3JJZClcbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRmlsYSAzOiBUaXBvIGRlIFRhYmxlcm8gJiBCYXJyYXMgLyBCcmVha2VyIFByaW5jaXBhbCAqL31cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQteHMgdGV4dC1jZW50ZXIgYm9yZGVyLWNvbGxhcHNlIGJvcmRlci1iLTIgYm9yZGVyLXNsYXRlLTcwMCBmb250LW1vbm8gcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvODAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTcwMCBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIHByaW50OmJnLWdyYXktMjAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgPHRoIGNvbFNwYW49XCIzXCIgY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS03MDAgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+VElQTyBERSBUQUJMRVJPPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY29sU3Bhbj1cIjNcIiBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTcwMCBwcmludDpib3JkZXItYmxhY2tcIj5CUkVBS0VSIFBSSU5DSVBBTDwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIHJvd1NwYW49XCIyXCIgY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS03MDAgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+Vk9MVEFKRTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIHJvd1NwYW49XCIyXCIgY2xhc3NOYW1lPVwicC0yXCI+QUNPTUVUSURBPC90aD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC81MCBib3JkZXItYiBib3JkZXItc2xhdGUtNzAwIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgcHJpbnQ6YmctZ3JheS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICA8dGggY29sU3Bhbj1cIjJcIiBjbGFzc05hbWU9XCJwLTEuNSBib3JkZXItciBib3JkZXItc2xhdGUtNzAwIHByaW50OmJvcmRlci1ibGFja1wiPlNVUEVSRklDSUFMPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0xLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTcwMCBwcmludDpib3JkZXItYmxhY2tcIj5FTVBPVFJBRE88L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTEuNSBib3JkZXItciBib3JkZXItc2xhdGUtNzAwIHByaW50OmJvcmRlci1ibGFja1wiPk1BUkNBPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0xLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTcwMCBwcmludDpib3JkZXItYmxhY2tcIj5USVBPPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0xLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTcwMCBwcmludDpib3JkZXItYmxhY2tcIj5BTVA8L3RoPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49XCIyXCIgY2xhc3NOYW1lPVwicC0yIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTIwMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7ZHQudGlwb1RhYmxlcm8gPT09ICdFTVBPVFJBRE8nID8gJ1sgIF0nIDogJ1sgWCBdJ31cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtkdC50aXBvVGFibGVybyA9PT0gJ0VNUE9UUkFETycgPyAnWyBYIF0nIDogJ1sgIF0nfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAge2R0LmJyZWFrZXJQcmluY2lwYWw/Lm1hcmNhIHx8ICdTSU4gQlJFQUtFUid9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7ZHQuYnJlYWtlclByaW5jaXBhbD8udGlwbyB8fCAnLSd9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7ZHQuYnJlYWtlclByaW5jaXBhbD8uYW1wIHx8ICctJ31cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIElBOiB7ZHQudm9sdGFqZT8udmEgfHwgZHQuYmFycmFzUHJpbmNpcGFsZXM/LmlhIHx8ICcyMTEsNSd9PGJyLz5cbiAgICAgICAgICAgICAgICAgIElCOiB7ZHQudm9sdGFqZT8udmIgfHwgZHQuYmFycmFzUHJpbmNpcGFsZXM/LmliIHx8ICcyMDcsNCd9PGJyLz5cbiAgICAgICAgICAgICAgICAgIElDOiB7ZHQudm9sdGFqZT8udmMgfHwgZHQuYmFycmFzUHJpbmNpcGFsZXM/LmljIHx8ICcyMDgsNid9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICB7ZHQuYWNvbWV0aWRhIHx8ICczWDUwMCBNQ00nfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG5cbiAgICAgICAgICB7LyogRmlsYXMgZGUgTmV1dHJvIHkgVGllcnJhICovfVxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14cyB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlIGJvcmRlci1iLTIgYm9yZGVyLXNsYXRlLTcwMCBmb250LW1vbm8gcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTgwMCBwcmludDpkaXZpZGUtYmxhY2tcIj5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJ3LTEvNCBiZy1zbGF0ZS05MDAvOTAgZm9udC1ib2xkIHAtMi41IHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJnLWdyYXktMTAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICBORVVUUk8gREUgTExFR0FEQVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInctMS80IHAtMi41IGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LWJvbGRcIj5DQUxJQiBDT05ELjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBwcmludDp0ZXh0LWJsYWNrXCI+e2R0Lm5ldXRyb0xsZWdhZGE/LmNhbGlicmUgfHwgJzFYNTAwJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtYm9sZFwiPk9CU0VSVkFDSU9ORVM6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgcHJpbnQ6dGV4dC1ibGFja1wiPntkdC5uZXV0cm9MbGVnYWRhPy5vYnNlcnZhY2lvbmVzIHx8ICdDQUJMRSBST0pPIEVOIFRBQkxFUk8nfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC85MCBmb250LWJvbGQgcC0yLjUgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6YmctZ3JheS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItYmxhY2tcIj5cbiAgICAgICAgICAgICAgICAgIFBVRVNUQSBBIFRJRVJSQVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LWJvbGRcIj5DQUxJQiBDT05ELjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBwcmludDp0ZXh0LWJsYWNrXCI+e2R0LnB1ZXN0YVRpZXJyYT8uY2FsaWJyZSB8fCAnU09MSURPICM0J308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtYm9sZFwiPk9CU0VSVkFDSU9ORVM6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgcHJpbnQ6dGV4dC1ibGFja1wiPntkdC5wdWVzdGFUaWVycmE/Lm9ic2VydmFjaW9uZXMgfHwgJ0xMRUdBIFNPTElETyAjNC4gQlVTQ0FSIFRBTlFVSUxMQSBERSBNQUxMQSBBIFRJRVJSQSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG5cbiAgICAgICAgICB7LyogQ2FqYSBBbWFyaWxsYSBkZSBPYnNlcnZhY2lvbmVzIEdlbmVyYWxlcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWFtYmVyLTk1MC80MCBib3JkZXItYi0yIGJvcmRlci1hbWJlci04MDAvNjAgcC00IGZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtYW1iZXItMjAwIHByaW50OmJnLXllbGxvdy0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItYmxhY2tcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYmxhY2sgdXBwZXJjYXNlIHRleHQtYW1iZXItNDAwIGJsb2NrIG1iLTEgcHJpbnQ6dGV4dC1ibGFja1wiPk9CU0VSVkFDScOTTiBHRU5FUkFMOjwvc3Bhbj5cbiAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgIHZhbHVlPXtvYnNlcnZhY2lvbmVzR2VuZXJhbGVzfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0T2JzZXJ2YWNpb25lc0dlbmVyYWxlcyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItYW1iZXItNjAwIHJvdW5kZWQgcC0yIHRleHQtc2xhdGUtMTAwIHRleHQteHMgcmVzaXplLW5vbmVcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAge29ic2VydmFjaW9uZXNHZW5lcmFsZXMgfHwgJ1NBTEVOIEFDT01FVElEQVMgMSBYIDUwMCBZIDFYMjUwIE1DTSBERSBMQSBCQVJSQSBQQVJURSBJTkZFUklPUi4gTEEgQUNPTUVUSURBIDI1MCBNQ00gVkEgQSBDQUpBIENPTiBVTiBCUkVBS0VSIEFMIExBRE8gREVMIFRBQkxFUk8gUFJJTkNJUEFMLiBJTlRFUlJVUFRPUiBFQVRPTiwgS2k0MDAsIDM1MCBBLiBTQUxFTiBVTkEgQUNPTUVUSURBIDQvMCBRVUUgQUxJTUVOVEEgVFJBTlNGRVJFTkNJQSAxNjAuIExBIEFDT01FVElEQSA1MDAgTUNNIFZBIEEgVU5BIENBSkEgQUwgTEFETyBERUwgVEFCTEVSTyBQUklOQ0lQQUwuIElOVEVSUlVQVE9SIEFCQiwgVElQTyA2NTIwLCA0MDAgQSwgU0FMRU4gMlg1MDAgWSBBTElNRU5UQU4gVEFCTEVSTyBFTiBQUklNRVIgUElTTy4nfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEltYWdlbiBhZGp1bnRhIGRlbCB0YWJsZXJvIChQYXJ0ZSBpbmZlcmlvciBkZSBsYSBwbGFudGlsbGEpICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXNsYXRlLTkwMC8zMCB0ZXh0LWNlbnRlciBwcmludDpiZy13aGl0ZVwiPlxuICAgICAgICAgICAge2ZvdG9CbG9iIHx8IGZvdG9TcmMgfHwgcHJldmlld1VybCA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1tZCBteC1hdXRvIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHNoYWRvdy1sZyBwcmludDpib3JkZXItYmxhY2tcIj5cbiAgICAgICAgICAgICAgICA8U2FmZUltYWdlIGJsb2I9e2ZvdG9CbG9ifSBzcmM9e3ByZXZpZXdVcmwgfHwgZm90b1NyY30gYWx0PVwiVGFibGVybyBFbMOpY3RyaWNvXCIgY2xhc3NOYW1lPVwidy1mdWxsIGgtYXV0byBtYXgtaC05NiBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQtY2VudGVyIHNwYWNlLXktMiBuby1wcmludFwiPlxuICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy04IGgtOCB0ZXh0LXNsYXRlLTYwMCBteC1hdXRvXCIgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ubyBibG9ja1wiPlNpbiBmb3RvZ3JhZsOtYSBhZGp1bnRhIGRlbCBwYW5lbCBlbMOpY3RyaWNvPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgcHgtMyBweS0xLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LWFtYmVyLTQwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICBBZGp1bnRhciBGb3RvXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qXCIgb25DaGFuZ2U9e2hhbmRsZUltYWdlQ2hhbmdlfSBjbGFzc05hbWU9XCJoaWRkZW5cIiAvPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgey8qIDIuIFBMQU5USUxMQTogR0VORVJBRE9SIChcIkdFTkVSQURPUiBOby4gWCBEQVRPUyBERSBQTEFDQVwiKSAqL31cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAge3RpcG9FbGVtZW50byA9PT0gJ0dFTkVSQURPUicgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXItMiBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy0yeGwgcHJpbnQ6Ym9yZGVyLWJsYWNrIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogSGVhZGVyIG9maWNpYWwgZGVsIGN1YWRybyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS03MDAgcC0zLjUgdGV4dC1jZW50ZXIgcHJpbnQ6YmctZ3JheS0yMDAgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIG1kOnRleHQtbGcgZm9udC1ibGFjayB0cmFja2luZy13aWRlIHRleHQtc2xhdGUtMTAwIHVwcGVyY2FzZSBmb250LW1vbm8gcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25vbWJyZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm9tYnJlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIEdFTkVSQURPUiBERSBFTUVSR0VOQ0lBIE5vLiAxXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTYwMCByb3VuZGVkIHB4LTMgcHktMSB0ZXh0LWNlbnRlciB3LWZ1bGwgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgdGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIHBsYWNlaG9sZGVyLXNsYXRlLTYwMFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBub21icmUgfHwgJ0dFTkVSQURPUiBERSBFTUVSR0VOQ0lBJ1xuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDdWFkcm8gZGUgRGVzdGlubyB5IFViaWNhY2nDs24gKi99XG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXhzIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2UgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTcwMCBmb250LW1vbm8gcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJ3LTEvMyBiZy1zbGF0ZS05MDAvOTAgZm9udC1ib2xkIHAtMyB0ZXh0LXNsYXRlLTMwMCB1cHBlcmNhc2UgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpiZy1ncmF5LTEwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkdFTkVSQURPUiBBTElNRU5UQSBBOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRXaXphcmRNb2RvKCdTQUxJREEnKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRDaXJjdWl0RGF0YVdpemFyZCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogJ0dFTkVSQURPUl9TQUxJREEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgbm9tYnJlOiAnU2FsaWRhIGRlbCBHZW5lcmFkb3InLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXF1aXBvOiBhbGltZW50YWRvUG9yIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcG9sZXM6IFszXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrZXI6IHsgYW1wOiBkdC5hbXBlcmFqZSB8fCAnJywgbWFyY2E6IGR0Lm1hcmNhIHx8ICcnLCB0aXBvOiAnJyB9XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0TW9kYWxKZXJhcnF1aWFPcGVuKHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJuby1wcmludCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctYW1iZXItNTAwLzEwIGhvdmVyOmJnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ29uZmlndXJhciBFcXVpcG8gQWxpbWVudGFkbyAoV2l6YXJkKVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxTZXR0aW5ncyBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtYW1iZXItNDAwXCIgLz4gQ29uZmlndXJhciBKZXJhcnF1w61hXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1zbGF0ZS0xMDAgZm9udC1zZW1pYm9sZCBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2FsaW1lbnRhZG9Qb3J9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBbGltZW50YWRvUG9yKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBUUkFOU0ZFUkVOQ0lBIFBSSU5DSVBBTCAoQVRTLTEpXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMiBweS0xIHRleHQtc2xhdGUtMTAwIHBsYWNlaG9sZGVyLXNsYXRlLTYwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICByZW5kZXJFbGVtZW50V2l0aElkKGFsaW1lbnRhZG9Qb3IgfHwgJ+KAlCcpXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGZvbnQtYm9sZCBwLTMgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6YmctZ3JheS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIFVCSUNBQ0nDk046XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtc2xhdGUtMTAwIGZvbnQtc2VtaWJvbGQgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1YmljYWNpb259XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVYmljYWNpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIENhc2V0YSBkZSBHZW5lcmFjacOzbiAvIEVzdGFjaW9uYW1pZW50b1wiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMCBwbGFjZWhvbGRlci1zbGF0ZS02MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgdWJpY2FjaW9uIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG5cbiAgICAgICAgICB7LyogU3ViLUhlYWRlcjogRGF0b3MgZGUgUGxhY2EgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvODAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTcwMCBwLTIgdGV4dC1jZW50ZXIgZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNDAwIGZvbnQtbW9ubyBwcmludDpiZy1ncmF5LTIwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgRGF0b3MgZGUgcGxhY2FcbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDdWFkcm8gZGUgRGF0b3MgZGUgUGxhY2EgKi99XG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXhzIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2UgYm9yZGVyLWItMiBib3JkZXItc2xhdGUtNzAwIGZvbnQtbW9ubyBwcmludDpib3JkZXItYmxhY2tcIj5cbiAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC81MCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgcHJpbnQ6YmctZ3JheS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCB3LTEvMyBwcmludDpib3JkZXItZ3JheS0zMDBcIj5QQVLDgU1FVFJPPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCB3LTEvMyB0ZXh0LWNlbnRlciBwcmludDpib3JkZXItZ3JheS0zMDBcIj5WQUxPUjwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IHctMS8zIHRleHQtY2VudGVyXCI+VU5JREFEPC90aD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTgwMCBwcmludDpkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBiZy1zbGF0ZS05MDAvNDAgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6YmctZ3JheS01MCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPk1BUkNBPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17ZHQubWFyY2EgfHwgJyd9IG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ21hcmNhJywgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiBDQVRFUlBJTExBUiAvIERPTU9TQSAvIENVTU1JTlNcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDAgcGxhY2Vob2xkZXItc2xhdGUtNjAwXCIgLz4gOiAoZHQubWFyY2EgfHwgJ+KAlCcpfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtYmxhY2tcIj5QTEFDQTwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYmctc2xhdGUtOTAwLzQwIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJnLWdyYXktNTAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5GQVNFUzwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1jZW50ZXIgZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmZhc2VzIHx8ICczJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdmYXNlcycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjFcIj4xIChNb25vZsOhc2ljbyk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMlwiPjIgKEJpZsOhc2ljbyk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiM1wiPjMgKFRyaWbDoXNpY28pPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQuZmFzZXMgfHwgJ+KAlCdcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1ibGFja1wiPkZBU0U8L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGJnLXNsYXRlLTkwMC80MCBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpiZy1ncmF5LTUwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+UE9URU5DSUE8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHRleHQtY2VudGVyIGZvbnQtZXh0cmFib2xkIHRleHQtYW1iZXItNDAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2R0Lmt2YSB8fCBkdC5wb3RlbmNpYUt2YSB8fCAnJ30gb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgna3ZhJywgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiA1ODBcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1hbWJlci00MDAgcGxhY2Vob2xkZXItc2xhdGUtNjAwXCIgLz4gOiAoZHQua3ZhIHx8IGR0LnBvdGVuY2lhS3ZhIHx8ICfigJQnKX1cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LWJsYWNrXCI+S1ZBPC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBiZy1zbGF0ZS05MDAvNDAgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6YmctZ3JheS01MCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlZPTFRBSkUgTk9NSU5BTCAoQ09WRU5JTiAxNTkpPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQudm9sdGFqZUdlbmVyYWNpb24gfHwgZHQudm9sdGFqZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCd2b2x0YWplR2VuZXJhY2lvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDAgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+LS0gU2VsZWNjaW9uYXIgVGVuc2nDs24gLS08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICB7VEVOU0lPTkVTX0NPVkVOSU5fMTU5X0JULm1hcCh2ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt2fSB2YWx1ZT17dn0+e3Z9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQudm9sdGFqZUdlbmVyYWNpb24gfHwgZHQudm9sdGFqZSB8fCAn4oCUJ1xuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LWJsYWNrXCI+Vk9MVElPUzwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYmctc2xhdGUtOTAwLzQwIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJnLWdyYXktNTAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5BTVBFUkFKRSBOT01JTkFMPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17ZHQuYW1wZXJhamUgfHwgJyd9IG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2FtcGVyYWplJywgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiAxNjAwXCIgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtY2VudGVyIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtMTAwIHBsYWNlaG9sZGVyLXNsYXRlLTYwMFwiIC8+IDogKGR0LmFtcGVyYWplIHx8ICfigJQnKX1cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LWJsYWNrXCI+QU1QPC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBiZy1zbGF0ZS05MDAvNDAgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6YmctZ3JheS01MCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPkZQIChGQUNUT1IgUE9URU5DSUEpPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17ZHQuZnAgfHwgJyd9IG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2ZwJywgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiAwLjhcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDAgcGxhY2Vob2xkZXItc2xhdGUtNjAwXCIgLz4gOiAoZHQuZnAgfHwgJ+KAlCcpfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtYmxhY2tcIj5jb3Mgz4Y8L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGJnLXNsYXRlLTkwMC80MCBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpiZy1ncmF5LTUwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+VElQTyBERSBDT01CVVNUSUJMRTwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1jZW50ZXIgZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmNvbWJ1c3RpYmxlIHx8ICdEScOJU0VMJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdjb21idXN0aWJsZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkRJw4lTRUxcIj5EScOJU0VMIC8gR0FTT0lMPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkdBU19OQVRVUkFMXCI+R0FTIE5BVFVSQUw8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiR0xQXCI+R0FTIExJQ1VBRE8gKEdMUCk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiR0FTT0xJTkFcIj5HQVNPTElOQTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJEVUFMX0ZVRUxcIj5EVUFMIEZVRUwgKEdBUyAvIERJw4lTRUwpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQuY29tYnVzdGlibGUgfHwgJ+KAlCdcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1ibGFja1wiPlRJUE88L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuXG4gICAgICAgICAgey8qIFN1Yi1IZWFkZXI6IEludGVycnVwdG9yIEdlbmVyYWRvciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC84MCBib3JkZXItYiBib3JkZXItc2xhdGUtNzAwIHAtMiB0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci00MDAgZm9udC1tb25vIHByaW50OmJnLWdyYXktMjAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICBJTlRFUlJVUFRPUiBQUklOQ0lQQUwgREVMIEdFTkVSQURPUlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEN1YWRybyBkZWwgSW50ZXJydXB0b3IgKi99XG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXhzIHRleHQtY2VudGVyIGJvcmRlci1jb2xsYXBzZSBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS03MDAgZm9udC1tb25vIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBwcmludDpiZy1ncmF5LTEwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5JTlRFUlJVUFRPUjwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPk1BUkNBPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+VElQTzwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPkFNUDwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPkNPTkQuIEZBU0U8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTJcIj5DT05ELiBORVVUUk88L3RoPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgYmctc2xhdGUtOTAwLzQwIHByaW50OmJnLWdyYXktNTAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5HRU5FUkFET1I8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17ZHQuaW50ZXJydXB0b3I/Lm1hcmNhIHx8IGR0LmludGVycnVwdG9yTWFyY2EgfHwgJyd9IG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlTmVzdGVkRHRDaGFuZ2UoJ2ludGVycnVwdG9yJywgJ21hcmNhJywgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiBDSElOVCAvIEFCQlwiIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlciBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCB0ZXh0LXNsYXRlLTEwMCBwbGFjZWhvbGRlci1zbGF0ZS02MDBcIiAvPiA6IChkdC5pbnRlcnJ1cHRvcj8ubWFyY2EgfHwgZHQuaW50ZXJydXB0b3JNYXJjYSB8fCAn4oCUJyl9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2R0LmludGVycnVwdG9yPy50aXBvIHx8IGR0LmludGVycnVwdG9yVGlwbyB8fCAnJ30gb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVOZXN0ZWREdENoYW5nZSgnaW50ZXJydXB0b3InLCAndGlwbycsIGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFai4gVGVybW9tYWduw6l0aWNvXCIgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtY2VudGVyIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtMTAwIHBsYWNlaG9sZGVyLXNsYXRlLTYwMFwiIC8+IDogKGR0LmludGVycnVwdG9yPy50aXBvIHx8IGR0LmludGVycnVwdG9yVGlwbyB8fCAn4oCUJyl9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIGZvbnQtZXh0cmFib2xkIHRleHQtYW1iZXItNDAwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17ZHQuaW50ZXJydXB0b3I/LmFtcCB8fCBkdC5pbnRlcnJ1cHRvckFtcCB8fCAnJ30gb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVOZXN0ZWREdENoYW5nZSgnaW50ZXJydXB0b3InLCAnYW1wJywgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiAxNjAwIEFcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1hbWJlci00MDAgcGxhY2Vob2xkZXItc2xhdGUtNjAwXCIgLz4gOiAoZHQuaW50ZXJydXB0b3I/LmFtcCB8fCBkdC5pbnRlcnJ1cHRvckFtcCB8fCAn4oCUJyl9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2R0LmludGVycnVwdG9yPy5jb25kRmFzZSB8fCBkdC5jb25kRmFzZSB8fCAnJ30gb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVOZXN0ZWREdENoYW5nZSgnaW50ZXJydXB0b3InLCAnY29uZEZhc2UnLCBlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIDIoM1g1MDAgTUNNKVwiIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlciBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCB0ZXh0LXNsYXRlLTEwMCBwbGFjZWhvbGRlci1zbGF0ZS02MDBcIiAvPiA6IChkdC5pbnRlcnJ1cHRvcj8uY29uZEZhc2UgfHwgZHQuY29uZEZhc2UgfHwgJ+KAlCcpfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtkdC5pbnRlcnJ1cHRvcj8uY29uZE5ldXRybyB8fCBkdC5jb25kTmV1dHJvIHx8ICcnfSBvbkNoYW5nZT17KGUpID0+IGhhbmRsZU5lc3RlZER0Q2hhbmdlKCdpbnRlcnJ1cHRvcicsICdjb25kTmV1dHJvJywgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiAxWDUwMCBNQ01cIiBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDAgcGxhY2Vob2xkZXItc2xhdGUtNjAwXCIgLz4gOiAoZHQuaW50ZXJydXB0b3I/LmNvbmROZXV0cm8gfHwgZHQuY29uZE5ldXRybyB8fCAn4oCUJyl9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgPC90YWJsZT5cblxuICAgICAgICAgIHsvKiBNZXRyb2xvZ8OtYSBFbMOpY3RyaWNhIGRlbCBHZW5lcmFkb3IgKENPVkVOSU4gMTU5KSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS05NTAgYm9yZGVyLWItMiBib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICA8TWV0cm9sb2dpYUVsZWN0cmljYVNlY3Rpb25cbiAgICAgICAgICAgICAgbWVkaWNpb25lcz17ZHQubWVkaWNpb25lcyB8fCB7fX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhudWV2YXNNZWRpY2lvbmVzKSA9PiBoYW5kbGVEdENoYW5nZSgnbWVkaWNpb25lcycsIG51ZXZhc01lZGljaW9uZXMpfVxuICAgICAgICAgICAgICByZWFkT25seT17IWlzRWRpdGluZ31cbiAgICAgICAgICAgICAgdGl0dWxvPVwiTWV0cm9sb2fDrWEgRWzDqWN0cmljYSB5IE1lZGljacOzbiBkZSBHZW5lcmFjacOzbiAoQ09WRU5JTiAxNTkpXCJcbiAgICAgICAgICAgICAgc3VidGl0dWxvPVwiTGVjdHVyYSBkZSB2b2x0YWplcyBkZXNnbG9zYWRvcyBMLUwsIEwtTiB5IDUgY2FuYWxlcyBkZSBjb3JyaWVudGUgZW4gYm9ybmVzIGRlIGdlbmVyYWNpw7NuXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogU3ViLUhlYWRlcjogVGFucXVlIGRlIENvbWJ1c3RpYmxlLCBBdXRvbm9tw61hIHkgRGlxdWUgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvODAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTcwMCBwLTIgdGV4dC1jZW50ZXIgZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNDAwIGZvbnQtbW9ubyBwcmludDpiZy1ncmF5LTIwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgSU5TUEVDQ0nDk04gREUgVEFOUVVFIERFIENPTUJVU1RJQkxFIFkgQVVUT05PTcONQSAoU0lTVEVNQSBNw4lUUklDTyBMSVRST1MgLyBHQUxPTkVTKVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc2xhdGUtOTUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS03MDAgc3BhY2UteS00IGZvbnQtbW9ubyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBmb250LWJvbGQgbWItMVwiPkNBUEFDSURBRCBUT1RBTDo8L3NwYW4+XG4gICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC50YW5xdWVDYXBhY2lkYWQgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgndGFucXVlQ2FwYWNpZGFkJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDEwMDBcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgdGV4dC14cyBmb2N1czpib3JkZXItYW1iZXItNTAwIHBsYWNlaG9sZGVyLXNsYXRlLTYwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQudGFucXVlVW5pZGFkIHx8ICdMaXRyb3MnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3RhbnF1ZVVuaWRhZCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIHB4LTEgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJMaXRyb3NcIj5MaXRyb3MgKEwpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkdhbG9uZXNcIj5HYWxvbmVzIChnYWwpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMTAwIGZvbnQtYm9sZCBiZy1zbGF0ZS05MDAvNjAgcHgtMi41IHB5LTEgcm91bmRlZCBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICB7ZHQudGFucXVlQ2FwYWNpZGFkID8gYCR7ZHQudGFucXVlQ2FwYWNpZGFkfSAke2R0LnRhbnF1ZVVuaWRhZCA9PT0gJ0dhbG9uZXMnID8gJ0dhbG9uZXMgKGdhbCknIDogJ0xpdHJvcyAoTCknfWAgOiAn4oCUJ31cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIGZvbnQtYm9sZCBtYi0xXCI+TklWRUwgQUNUVUFMICglKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICBtYXg9XCIxMDBcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC50YW5xdWVOaXZlbFBjdCAhPT0gdW5kZWZpbmVkID8gZHQudGFucXVlTml2ZWxQY3QgOiA1MH1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCd0YW5xdWVOaXZlbFBjdCcsIHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMiBiZy1zbGF0ZS04MDAgcm91bmRlZCBhcHBlYXJhbmNlLW5vbmUgYWNjZW50LWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCB3LTEwIHRleHQtcmlnaHRcIj57ZHQudGFucXVlTml2ZWxQY3QgIT09IHVuZGVmaW5lZCA/IGR0LnRhbnF1ZU5pdmVsUGN0IDogNTB9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGJnLXNsYXRlLTkwMCByb3VuZGVkLWZ1bGwgaC0zIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtZnVsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAoZHQudGFucXVlTml2ZWxQY3QgfHwgMCkgPCAyNSA/ICdiZy1yZWQtNTAwJyA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIChkdC50YW5xdWVOaXZlbFBjdCB8fCAwKSA8IDUwID8gJ2JnLWFtYmVyLTUwMCcgOiAnYmctZW1lcmFsZC01MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtkdC50YW5xdWVOaXZlbFBjdCB8fCAwfSVgIH19XG4gICAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwXCI+e2R0LnRhbnF1ZU5pdmVsUGN0ICE9PSB1bmRlZmluZWQgPyBgJHtkdC50YW5xdWVOaXZlbFBjdH0lYCA6ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgZm9udC1ib2xkIG1iLTFcIj5DT05TVU1PIEVTUEVDw41GSUNPIChML2gpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuY29uc3Vtb0xoIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdjb25zdW1vTGgnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDM1XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcGxhY2Vob2xkZXItc2xhdGUtNjAwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMTAwIGZvbnQtYm9sZCBiZy1zbGF0ZS05MDAvNjAgcHgtMi41IHB5LTEgcm91bmRlZCBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICB7ZHQuY29uc3Vtb0xoID8gYCR7ZHQuY29uc3Vtb0xofSBML2hgIDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBmb250LWJvbGQgbWItMVwiPkFVVE9OT03DjUEgRVNUSU1BREE6PC9zcGFuPlxuICAgICAgICAgICAgICAgIHsoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgY2FwID0gcGFyc2VGbG9hdChkdC50YW5xdWVDYXBhY2lkYWQpIHx8IDA7XG4gICAgICAgICAgICAgICAgICBjb25zdCBuaXZlbCA9IChwYXJzZUZsb2F0KGR0LnRhbnF1ZU5pdmVsUGN0ICE9PSB1bmRlZmluZWQgPyBkdC50YW5xdWVOaXZlbFBjdCA6IDUwKSkgLyAxMDA7XG4gICAgICAgICAgICAgICAgICBjb25zdCBjb25zID0gcGFyc2VGbG9hdChkdC5jb25zdW1vTGgpIHx8IDA7XG4gICAgICAgICAgICAgICAgICBjb25zdCBsaXRyb3NEaXNwb25pYmxlcyA9IGR0LnRhbnF1ZVVuaWRhZCA9PT0gJ0dhbG9uZXMnID8gKGNhcCAqIDMuNzg1NDEgKiBuaXZlbCkgOiAoY2FwICogbml2ZWwpO1xuICAgICAgICAgICAgICAgICAgY29uc3QgaG9yYXNBdXRvbm9taWEgPSBjb25zID4gMCAmJiBjYXAgPiAwID8gKGxpdHJvc0Rpc3BvbmlibGVzIC8gY29ucykudG9GaXhlZCgxKSA6IG51bGw7XG5cbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQgYmxvY2sgZm9udC1ib2xkIGZvbnQtbW9ubyB0ZXh0LWNlbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgIGhvcmFzQXV0b25vbWlhICYmIHBhcnNlRmxvYXQoaG9yYXNBdXRvbm9taWEpID49IDEyID8gJ2JnLWVtZXJhbGQtOTUwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTgwMCcgOlxuICAgICAgICAgICAgICAgICAgICAgIGhvcmFzQXV0b25vbWlhICYmIHBhcnNlRmxvYXQoaG9yYXNBdXRvbm9taWEpID49IDYgPyAnYmctYW1iZXItOTUwIHRleHQtYW1iZXItNDAwIGJvcmRlciBib3JkZXItYW1iZXItODAwJyA6XG4gICAgICAgICAgICAgICAgICAgICAgJ2JnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTMwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHtob3Jhc0F1dG9ub21pYSA/IGDij7HvuI8gfiR7aG9yYXNBdXRvbm9taWF9IEhvcmFzYCA6ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pKCl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDaGVja2xpc3QgZGUgU2VndXJpZGFkIGRlIENvbWJ1c3RpYmxlICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIG1kOmdyaWQtY29scy00IGdhcC0zIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTIgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS04NTBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPkRpcXVlIENvbnRlbmNpw7NuICgxMTAlKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmRpcXVlQ29udGVuY2lvbiB8fCAnQ29uZm9ybWUnfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdkaXF1ZUNvbnRlbmNpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTEgdGV4dC1zbGF0ZS0yMDBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ29uZm9ybWVcIj5Db25mb3JtZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU2luIERpcXVlXCI+U2luIERpcXVlPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJGaXN1cmFkbyAvIFN1Y2lvXCI+RmlzdXJhZG8gLyBTdWNpbzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGZvbnQtYm9sZCAke2R0LmRpcXVlQ29udGVuY2lvbiA9PT0gJ1NpbiBEaXF1ZScgPyAndGV4dC1yZWQtNDAwJyA6ICd0ZXh0LWVtZXJhbGQtNDAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAge2R0LmRpcXVlQ29udGVuY2lvbiB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTIgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS04NTBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPkZpbHRybyBSYWNvciAvIFRyYW1wYTo8L3NwYW4+XG4gICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmZpbHRyb1JhY29yIHx8ICdPcGVyYXRpdm8nfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdmaWx0cm9SYWNvcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMSB0ZXh0LXNsYXRlLTIwMFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJPcGVyYXRpdm9cIj5PcGVyYXRpdm88L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFndWEgLyBTdWNpb1wiPkFndWEgLyBTdWNpbzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUmVxdWllcmUgUmVlbXBsYXpvXCI+UmVxdWllcmUgUmVlbXBsYXpvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwXCI+e2R0LmZpbHRyb1JhY29yIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTIgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS04NTBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPkJvbWJhIGRlIFRyYXNpZWdvOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuYm9tYmFUcmFzaWVnbyB8fCAnTWFudWFsIHkgRWzDqWN0cmljYSd9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2JvbWJhVHJhc2llZ28nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTEgdGV4dC1zbGF0ZS0yMDBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTWFudWFsIHkgRWzDqWN0cmljYVwiPk1hbnVhbCB5IEVsw6ljdHJpY2E8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNvbG8gTWFudWFsXCI+U29sbyBNYW51YWw8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNvbG8gRWzDqWN0cmljYVwiPlNvbG8gRWzDqWN0cmljYTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSW5vcGVyYXRpdmFcIj5Jbm9wZXJhdGl2YTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTIwMFwiPntkdC5ib21iYVRyYXNpZWdvIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTIgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS04NTBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlbDoWx2dWxhIENvcnRlIFLDoXBpZG86PC9zcGFuPlxuICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC52YWx2dWxhQ29ydGUgfHwgJ09wZXJhdGl2YSd9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3ZhbHZ1bGFDb3J0ZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMSB0ZXh0LXNsYXRlLTIwMFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJPcGVyYXRpdmFcIj5PcGVyYXRpdmE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRyYWJhZGFcIj5UcmFiYWRhPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJObyBQb3NlZVwiPk5vIFBvc2VlPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwXCI+e2R0LnZhbHZ1bGFDb3J0ZSB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDYXJnYSBEdWFsIGRlIEZvdG9ncmFmw61hcyBkZWwgR2VuZXJhZG9yICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IGJnLXNsYXRlLTkwMC8zMFwiPlxuICAgICAgICAgICAgPER1YWxQaG90b1VwbG9hZGVyXG4gICAgICAgICAgICAgIGZvdG9CbG9iPXtmb3RvQmxvYn1cbiAgICAgICAgICAgICAgZm90b1NyYz17Zm90b1NyY31cbiAgICAgICAgICAgICAgcHJldmlld1VybD17cHJldmlld1VybH1cbiAgICAgICAgICAgICAgb25JbWFnZVNlbGVjdGVkPXsoZmlsZSkgPT4ge1xuICAgICAgICAgICAgICAgIHNldEZvdG9CbG9iKGZpbGUpO1xuICAgICAgICAgICAgICAgIGlmIChwcmV2aWV3VXJsKSBVUkwucmV2b2tlT2JqZWN0VVJMKHByZXZpZXdVcmwpO1xuICAgICAgICAgICAgICAgIHNldFByZXZpZXdVcmwoVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKSk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIG9uUmVtb3ZlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0Rm90b0Jsb2IobnVsbCk7XG4gICAgICAgICAgICAgICAgc2V0Rm90b1NyYyhudWxsKTtcbiAgICAgICAgICAgICAgICBpZiAocHJldmlld1VybCkgVVJMLnJldm9rZU9iamVjdFVSTChwcmV2aWV3VXJsKTtcbiAgICAgICAgICAgICAgICBzZXRQcmV2aWV3VXJsKG51bGwpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICByZWFkT25seT17IWlzRWRpdGluZ31cbiAgICAgICAgICAgICAgbGFiZWw9XCJGb3RvZ3JhZsOtYSBkZWwgR2VuZXJhZG9yIHkgR3J1cG8gRWxlY3Ryw7NnZW5vXCJcbiAgICAgICAgICAgICAgc3VibGFiZWw9XCJDw6FtYXJhIGVuIHZpdm8gbyBzZWxlY2Npw7NuIGRlc2RlIGdhbGVyw61hXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHsvKiAzLiBQTEFOVElMTEE6IFRSQU5TRkVSRU5DSUEgKEFUUyAvIE1UUykgKi99XG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdUUkFOU0ZFUicgJiYgKFxuICAgICAgICA8VHJhbnNmZXJDb21wb25lbnRcbiAgICAgICAgICB0cmFuc2ZlckRhdGE9e2VsZW1lbnRvRGF0YX1cbiAgICAgICAgICBvblVwZGF0ZT17b25VcGRhdGV9XG4gICAgICAgICAgcmVhZE9ubHk9e3JlYWRPbmx5fVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7LyogNC4gUExBTlRJTExBOiBUUkFOU0ZPUk1BRE9SIChcIklORk9STUFDScOTTiBHRU5FUkFMIERFIFRSQU5TRk9STUFET1IgTm8uIFhcIikgKi99XG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdUUkFOU0ZPUk1BRE9SJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlci0yIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LTJ4bCBwcmludDpib3JkZXItYmxhY2sgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgIFxuICAgICAgICAgIHsvKiBUw610dWxvIFByaW5jaXBhbCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS03MDAgcC0zLjUgdGV4dC1jZW50ZXIgcHJpbnQ6YmctZ3JheS0yMDAgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIG1kOnRleHQtbGcgZm9udC1ibGFjayB0cmFja2luZy13aWRlIHRleHQtc2xhdGUtMTAwIHVwcGVyY2FzZSBmb250LW1vbm8gcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25vbWJyZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm9tYnJlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTYwMCByb3VuZGVkIHB4LTMgcHktMSB0ZXh0LWNlbnRlciB3LWZ1bGwgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHRleHQtc2xhdGUtMTAwIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBgSU5GT1JNQUNJw5NOIEdFTkVSQUwgREUgVFJBTlNGT1JNQURPUiBOby4gJHtub21icmUgfHwgJ+KAlCd9YFxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBGaWxhIDE6IElEIEVsZW1lbnRvLCBBbGltZW50YWRvIFBvciB5IFViaWNhY2nDs24gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtNzAwIHAtMyBiZy1zbGF0ZS05MDAvNjAgZm9udC1tb25vIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItYmxhY2sgZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1ibGFjayBtci0xLjVcIj5JRCBFTEVNRU5UTzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCBiZy1hbWJlci01MDAvMTAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgICAgICAge2VsZW1lbnRvRGF0YS5pZCB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1ibGFjayBtci0xLjVcIj5BTElNRU5UQURPIFBPUjo8L3NwYW4+XG4gICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXthbGltZW50YWRvUG9yfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFsaW1lbnRhZG9Qb3IoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gUENDIC8gQWNvbWV0aWRhIDFcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPnthbGltZW50YWRvUG9yIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHVwcGVyY2FzZSB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LWJsYWNrIG1yLTEuNVwiPlVCSUNBQ0nDk046PC9zcGFuPlxuICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3ViaWNhY2lvbn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VWJpY2FjaW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPnt1YmljYWNpb24gfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVGFibGEgZGUgRXNwZWNpZmljYWNpb25lcyAqL31cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQteHMgdGV4dC1sZWZ0IGJvcmRlci1jb2xsYXBzZSBib3JkZXItYiBib3JkZXItc2xhdGUtNzAwIGZvbnQtbW9ubyBwcmludDpib3JkZXItYmxhY2tcIj5cbiAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInctMS8zIGJnLXNsYXRlLTkwMC85MCBmb250LWJvbGQgcC0zIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJnLWdyYXktMTAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+TUFSQ0E8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1zbGF0ZS0xMDAgZm9udC1zZW1pYm9sZCBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0Lm1hcmNhIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ21hcmNhJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIGR0Lm1hcmNhIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvOTAgZm9udC1ib2xkIHAtMyB0ZXh0LXNsYXRlLTMwMCB1cHBlcmNhc2UgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpiZy1ncmF5LTEwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPkZBU0VTPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtc2xhdGUtMTAwIGZvbnQtc2VtaWJvbGQgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5mYXNlcyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdmYXNlcycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMiBweS0xIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICBkdC5mYXNlcyB8fCAn4oCUJ1xuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuXG4gICAgICAgICAgey8qIEN1YWRybyBkZSBEYXRvcyBkZSBQbGFjYSAqL31cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQteHMgdGV4dC1sZWZ0IGJvcmRlci1jb2xsYXBzZSBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS03MDAgZm9udC1tb25vIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBwcmludDpiZy1ncmF5LTEwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHctMS8zIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlBBUsOBTUVUUk88L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHctMS8zIHRleHQtY2VudGVyIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlZBTE9SPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgdy0xLzMgdGV4dC1jZW50ZXJcIj5VTklEQUQ8L3RoPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwIHByaW50OmRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGJnLXNsYXRlLTkwMC80MCBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpiZy1ncmF5LTUwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+UE9URU5DSUE8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHRleHQtY2VudGVyIGZvbnQtZXh0cmFib2xkIHRleHQtdmlvbGV0LTQwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17NH1cbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQucG90ZW5jaWFLdmEgfHwgZHQua3ZhIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsID0gZS50YXJnZXQudmFsdWUucmVwbGFjZSgvXFxEL2csICcnKS5zbGljZSgwLCA0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCdwb3RlbmNpYUt2YScsIHZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEdENoYW5nZSgna3ZhJywgdmFsKTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtY2VudGVyIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtdmlvbGV0LTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQucG90ZW5jaWFLdmEgfHwgZHQua3ZhIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQudW5pZGFkUG90ZW5jaWEgfHwgJ2tWQSd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgndW5pZGFkUG90ZW5jaWEnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDAgdGV4dC14cyBwLTEgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJrVkFcIj5rVkE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTVZBXCI+TVZBPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQudW5pZGFkUG90ZW5jaWEgfHwgJ2tWQSdcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBiZy1zbGF0ZS05MDAvNDAgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6YmctZ3JheS01MCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPklNUEVEQU5DSUE8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiIGNvbFNwYW49XCIyXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTIgdGV4dC1jZW50ZXIgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmltcGVkYW5jaWFQY3QgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2ltcGVkYW5jaWFQY3QnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiJVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTYgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDAgdGV4dC1jZW50ZXIgdGV4dC14cyBwLTEgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBwcmludDp0ZXh0LWJsYWNrXCI+e2R0LmltcGVkYW5jaWFQY3QgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkXCI+JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEganVzdGlmeS1jZW50ZXIgYm9yZGVyLWwgYm9yZGVyLXNsYXRlLTg1MCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmltcGVkYW5jaWFBbXAgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2ltcGVkYW5jaWFBbXAnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTYgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDAgdGV4dC1jZW50ZXIgdGV4dC14cyBwLTEgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBwcmludDp0ZXh0LWJsYWNrXCI+e2R0LmltcGVkYW5jaWFBbXAgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkXCI+QTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEganVzdGlmeS1jZW50ZXIgYm9yZGVyLWwgYm9yZGVyLXNsYXRlLTg1MCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmltcGVkYW5jaWFUZW1wIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdpbXBlZGFuY2lhVGVtcCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLCsENcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTE2IGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtMTAwIHRleHQtY2VudGVyIHRleHQteHMgcC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6dGV4dC1ibGFja1wiPntkdC5pbXBlZGFuY2lhVGVtcCB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGRcIj7CsEM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBiZy1zbGF0ZS05MDAvNDAgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6YmctZ3JheS01MCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlRFTlNJw5NOIFBSSU1BUklBPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQudGVuc2lvblByaW1hcmlhIHx8IGR0LnZvbHRhamVQcmltYXJpbyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IGUudGFyZ2V0LnZhbHVlLnJlcGxhY2UoL1teMC05Ll0vZywgJycpLnJlcGxhY2UoLyhcXC4uKilcXC4vZywgJyQxJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEdENoYW5nZSgndGVuc2lvblByaW1hcmlhJywgdmFsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCd2b2x0YWplUHJpbWFyaW8nLCB2YWwpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMTMuOFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtY2VudGVyIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICBkdC50ZW5zaW9uUHJpbWFyaWEgfHwgZHQudm9sdGFqZVByaW1hcmlvIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQudW5pZGFkVGVuc2lvblByaW1hcmlhIHx8ICdrVid9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgndW5pZGFkVGVuc2lvblByaW1hcmlhJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtMTAwIHRleHQteHMgcC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwia1ZcIj5rVjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJWXCI+Vjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIGR0LnVuaWRhZFRlbnNpb25QcmltYXJpYSB8fCAna1YnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYmctc2xhdGUtOTAwLzQwIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJnLWdyYXktNTAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5URU5TScOTTiBTRUNVTkRBUklBPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQudGVuc2lvblNlY3VuZGFyaWEgfHwgZHQudm9sdGFqZVNlY3VuZGFyaW8gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBlLnRhcmdldC52YWx1ZS5yZXBsYWNlKC9bXjAtOS9dL2csICcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCd0ZW5zaW9uU2VjdW5kYXJpYScsIHZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEdENoYW5nZSgndm9sdGFqZVNlY3VuZGFyaW8nLCB2YWwpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMjA4LzEyMFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtY2VudGVyIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICBkdC50ZW5zaW9uU2VjdW5kYXJpYSB8fCBkdC52b2x0YWplU2VjdW5kYXJpbyB8fCAn4oCUJ1xuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LWJsYWNrXCI+VjwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYmctc2xhdGUtOTAwLzQwIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJnLWdyYXktNTAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5BTVBFUklPUyBTRUMuPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuYW1wZXJpb3NTZWN1bmRhcmlhIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2FtcGVyaW9zU2VjdW5kYXJpYScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIGR0LmFtcGVyaW9zU2VjdW5kYXJpYSB8fCAn4oCUJ1xuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LWJsYWNrXCI+QU1QPC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgPC90YWJsZT5cblxuICAgICAgICAgIHsvKiBTdWItSGVhZGVyOiBBY29tZXRpZGFzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzgwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS03MDAgcC0yIHRleHQtY2VudGVyIGZvbnQtYm9sZCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXZpb2xldC00MDAgZm9udC1tb25vIHByaW50OmJnLWdyYXktMjAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICBBQ09NRVRJREFTXG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtWzEwcHhdIG1kOnRleHQteHMgdGV4dC1jZW50ZXIgYm9yZGVyLWNvbGxhcHNlIGJvcmRlci1iLTIgYm9yZGVyLXNsYXRlLTcwMCBmb250LW1vbm8gcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvNTAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHByaW50OmJnLWdyYXktMTAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMCB3LTIwXCIgcm93U3Bhbj1cIjJcIj5BQ09NRVRJREFTPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwIHctMjRcIiBjb2xTcGFuPVwiMlwiPlRJUE88L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIiBjb2xTcGFuPVwiM1wiPkNPTkRVQ1RPUjwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiIGNvbFNwYW49XCIyXCI+UFJPVEVDQ0lPTkVTPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIHByaW50OnRleHQtYmxhY2tcIiByb3dTcGFuPVwiMlwiPk9CU0VSVkFDSU9ORVM8L3RoPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzMwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBwcmludDpiZy1ncmF5LTUwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTM1MFwiPkFFUkVBPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0xIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzUwXCI+U1VCLVRFUlI8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTEgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zNTBcIj5DQUxJQjwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTM1MFwiPlRJUE88L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTEgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zNTBcIj5URVJNSU5BTDwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTM1MFwiPkZVU0lCTEU8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTEgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zNTBcIj5QQVJBUlJBWU88L3RoPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwIHByaW50OmRpdmlkZS1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICB7WydwcmltYXJpYScsICdzZWN1bmRhcmlhJ10ubWFwKChzZWNjaW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgYWMgPSBkdC5hY29tZXRpZGFzPy5bc2VjY2lvbl0gfHwgeyBhZXJlYTogZmFsc2UsIHN1YnRlcnJhbmVhOiBmYWxzZSwgY2FsaWJyZTogJycsIHRpcG86ICcnLCB0ZXJtaW5hbDogJycsIGZ1c2libGU6ICcnLCBwYXJhcnJheW86ICcnLCBvYnNlcnZhY2lvbmVzOiAnJyB9O1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtzZWNjaW9ufSBjbGFzc05hbWU9XCJwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgZm9udC1ib2xkIGJnLXNsYXRlLTkwMC80MCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHVwcGVyY2FzZSBwcmludDpiZy1ncmF5LTUwIHByaW50OmJvcmRlci1ncmF5LTMwMCB0ZXh0LXNsYXRlLTM1MCBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntzZWNjaW9ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0VudHJhZGEgPSBzZWNjaW9uID09PSAncHJpbWFyaWEnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFdpemFyZE1vZG8oaXNFbnRyYWRhID8gJ0VOVFJBREEnIDogJ1NFQ1VOREFSSUEnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDaXJjdWl0RGF0YVdpemFyZCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogYFRSQU5TRk9STUFET1JfJHtzZWNjaW9uLnRvVXBwZXJDYXNlKCl9YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vbWJyZTogYFRyYW5zZm9ybWFkb3IgLSBBY29tZXRpZGEgJHtzZWNjaW9uLnRvVXBwZXJDYXNlKCl9YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVxdWlwbzogaXNFbnRyYWRhID8gYWxpbWVudGFkb1BvciA6IChhYy5vYnNlcnZhY2lvbmVzIHx8ICcnKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvbGVzOiBbM10sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVha2VyOiB7IGFtcDogJycsIG1hcmNhOiAnJywgdGlwbzogJycgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE1vZGFsSmVyYXJxdWlhT3Blbih0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibm8tcHJpbnQgcC0xIGhvdmVyOmJnLXZpb2xldC01MDAvMjAgdGV4dC12aW9sZXQtNDAwIHJvdW5kZWQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17YENvbmZpZ3VyYXIgSmVyYXJxdcOtYSAoJHtzZWNjaW9ufSlgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2V0dGluZ3MgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2FjLmFlcmVhIHx8IGZhbHNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUFjb21ldGlkYUNoYW5nZShzZWNjaW9uLCAnYWVyZWEnLCBlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCBjdXJzb3ItcG9pbnRlciBhY2NlbnQtdmlvbGV0LTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICBhYy5hZXJlYSA/ICdbIFggXScgOiAnWyAgIF0nXG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17YWMuc3VidGVycmFuZWEgfHwgZmFsc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQWNvbWV0aWRhQ2hhbmdlKHNlY2Npb24sICdzdWJ0ZXJyYW5lYScsIGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IGN1cnNvci1wb2ludGVyIGFjY2VudC12aW9sZXQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjLnN1YnRlcnJhbmVhID8gJ1sgWCBdJyA6ICdbICAgXSdcbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXthYy5jYWxpYnJlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUFjb21ldGlkYUNoYW5nZShzZWNjaW9uLCAnY2FsaWJyZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtY2VudGVyIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtMTAwIHRleHQteHMgcC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICBhYy5jYWxpYnJlIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YWMudGlwbyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVBY29tZXRpZGFDaGFuZ2Uoc2VjY2lvbiwgJ3RpcG8nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlciBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIHAtMSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgYWMudGlwbyB8fCAn4oCUJ1xuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2FjLnRlcm1pbmFsIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUFjb21ldGlkYUNoYW5nZShzZWNjaW9uLCAndGVybWluYWwnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlciBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIHAtMSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgYWMudGVybWluYWwgfHwgJ+KAlCdcbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXthYy5mdXNpYmxlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUFjb21ldGlkYUNoYW5nZShzZWNjaW9uLCAnZnVzaWJsZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtY2VudGVyIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtMTAwIHRleHQteHMgcC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICBhYy5mdXNpYmxlIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YWMucGFyYXJyYXlvIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUFjb21ldGlkYUNoYW5nZShzZWNjaW9uLCAncGFyYXJyYXlvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDAgdGV4dC14cyBwLTEgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjLnBhcmFycmF5byB8fCAn4oCUJ1xuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXthYy5vYnNlcnZhY2lvbmVzIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUFjb21ldGlkYUNoYW5nZShzZWNjaW9uLCAnb2JzZXJ2YWNpb25lcycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtMTAwIHRleHQteHMgcC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICBhYy5vYnNlcnZhY2lvbmVzIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG5cbiAgICAgICAgICB7LyogU3ViLUhlYWRlcjogU1BUICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzgwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS03MDAgcC0yIHRleHQtY2VudGVyIGZvbnQtYm9sZCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXZpb2xldC00MDAgZm9udC1tb25vIHByaW50OmJnLWdyYXktMjAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICBTSVNURU1BIERFIFBVRVNUQSBBIFRJRVJSQSAoU1BUKVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LVsxMHB4XSBtZDp0ZXh0LXhzIHRleHQtY2VudGVyIGJvcmRlci1jb2xsYXBzZSBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS03MDAgZm9udC1tb25vIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBwcmludDpiZy1ncmF5LTEwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDAgdy0yMFwiIHJvd1NwYW49XCIyXCI+U1BUPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCIgY29sU3Bhbj1cIjNcIj5CQVJJTExBIChWQVJJTExBKTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiIGNvbFNwYW49XCIyXCI+Q09ORFVDVE9SPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwIHctMjRcIiByb3dTcGFuPVwiMlwiPlJFU0lTVEVOQ0lBPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIHByaW50OnRleHQtYmxhY2tcIiByb3dTcGFuPVwiMlwiPkZFQ0hBIERFIE1FRElDScOTTjwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvMzAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHByaW50OmJnLWdyYXktNTAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0xIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzUwXCI+Q0FMSUJSRTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTM1MFwiPkNBTlRJREFEPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0xIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzUwXCI+Q09ORklHVVJBQ0nDk048L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTEgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zNTBcIj5DQUxJQlJFPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0xIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzUwXCI+VElQTyBTT0xEPC90aD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTgwMCBwcmludDpkaXZpZGUtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cInByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIGZvbnQtYm9sZCBiZy1zbGF0ZS05MDAvNDAgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpiZy1ncmF5LTUwIHByaW50OmJvcmRlci1ncmF5LTMwMCB0ZXh0LXNsYXRlLTM1MCBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICBNRURJREFcbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuc3B0Py5iYXJpbGxhQ2FsaWJyZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZVNwdENoYW5nZSgnYmFyaWxsYUNhbGlicmUnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtY2VudGVyIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtMTAwIHRleHQteHMgcC0xIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICBkdC5zcHQ/LmJhcmlsbGFDYWxpYnJlIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5zcHQ/LmJhcmlsbGFDYW50aWRhZCB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZVNwdENoYW5nZSgnYmFyaWxsYUNhbnRpZGFkJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlciBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIHAtMSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQuc3B0Py5iYXJpbGxhQ2FudGlkYWQgfHwgJ+KAlCdcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnNwdD8uYmFyaWxsYUNvbmZpZ3VyYWNpb24gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVTcHRDaGFuZ2UoJ2JhcmlsbGFDb25maWd1cmFjaW9uJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlciBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIHAtMSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQuc3B0Py5iYXJpbGxhQ29uZmlndXJhY2lvbiB8fCAn4oCUJ1xuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuc3B0Py5jb25kdWN0b3JDYWxpYnJlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU3B0Q2hhbmdlKCdjb25kdWN0b3JDYWxpYnJlJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlciBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIHAtMSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQuc3B0Py5jb25kdWN0b3JDYWxpYnJlIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5zcHQ/LmNvbmR1Y3RvclRpcG9Tb2xkIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU3B0Q2hhbmdlKCdjb25kdWN0b3JUaXBvU29sZCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1zbGF0ZS0xMDAgdGV4dC14cyBwLTEgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIGR0LnNwdD8uY29uZHVjdG9yVGlwb1NvbGQgfHwgJ+KAlCdcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnNwdD8ucmVzaXN0ZW5jaWEgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVTcHRDaGFuZ2UoJ3Jlc2lzdGVuY2lhJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlciBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIHAtMSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQuc3B0Py5yZXNpc3RlbmNpYSB8fCAn4oCUJ1xuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTJcIj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuc3B0Py5mZWNoYU1lZGljaW9uIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU3B0Q2hhbmdlKCdmZWNoYU1lZGljaW9uJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlciBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIHAtMSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQuc3B0Py5mZWNoYU1lZGljaW9uIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG5cbiAgICAgICAgICB7LyogQ2FqYSBkZSBPYnNlcnZhY2lvbmVzIEdlbmVyYWxlcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC82MCBib3JkZXItYiBib3JkZXItc2xhdGUtNzAwIHAtNCBmb250LW1vbm8gdGV4dC14cyB0ZXh0LXNsYXRlLTIwMCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ibGFjayB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMSBwcmludDp0ZXh0LWJsYWNrXCI+T0JTRVJWQUNJT05FUzo8L3NwYW4+XG4gICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICB2YWx1ZT17b2JzZXJ2YWNpb25lc0dlbmVyYWxlc31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE9ic2VydmFjaW9uZXNHZW5lcmFsZXMoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkIHAtMiB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIHJlc2l6ZS1ub25lIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWQgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS0zNTAgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICAgIHtvYnNlcnZhY2lvbmVzR2VuZXJhbGVzIHx8ICdTaW4gb2JzZXJ2YWNpb25lcyByZWdpc3RyYWRhcy4nfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIExleWVuZGEgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc2xhdGUtOTUwIHRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ubyBsZWFkaW5nLXJlbGF4ZWQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTcwMCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ibGFjayBwcmludDp0ZXh0LVs4cHhdXCI+XG4gICAgICAgICAgICA8cD48c3Ryb25nPkxFWUVOREE6PC9zdHJvbmc+IDxzdHJvbmc+QkI8L3N0cm9uZz4gQkFSUkEgRU4gQlVFTiBFU1RBRE8sIDxzdHJvbmc+QkQ8L3N0cm9uZz4gQkFSUkEgREVGRUNUVU9TQSwgPHN0cm9uZz5TQjwvc3Ryb25nPiBTSU4gQkFSUkEsIDxzdHJvbmc+Q0I8L3N0cm9uZz4gQ09ORFVDVE9SIEVOIEJVRU4gRVNUQURPLCA8c3Ryb25nPkNTPC9zdHJvbmc+IENPTkRVQ1RPUiBTVUxGQVRBRE8sIDxzdHJvbmc+U0M8L3N0cm9uZz4gU0lOIENPTkRVQ1RPUiwgPHN0cm9uZz5JQjwvc3Ryb25nPiBJTlRFUlJVUFRPUiBFTiBCVUVOIEVTVEFETywgPHN0cm9uZz5JRDwvc3Ryb25nPiBJTlRFUlJVUFRPUiBERUZFQ1RVT1NPLCA8c3Ryb25nPklTPC9zdHJvbmc+IElOVEVSUlVQVE9SIFNVTEZBVEFETywgPHN0cm9uZz5BVDwvc3Ryb25nPiBBTFRBIFRFTVBFUkFUVVJBLCA8c3Ryb25nPkNUQjwvc3Ryb25nPiBDT1BBIFRFUk1JTkFMIEJVRU4gRVNUQURPLCA8c3Ryb25nPkNURDwvc3Ryb25nPiBDT1BBIFRFUk1JTkFMIERFRkVDVFVPU0EsIDxzdHJvbmc+U0NUPC9zdHJvbmc+IFNJTiBDT1BBLCA8c3Ryb25nPkZCPC9zdHJvbmc+IEZVU0lCTEUgRU4gQlVFTiBFU1RBRE8sIDxzdHJvbmc+RkQ8L3N0cm9uZz4gRlVTSUJMRSBERUZFQ1RVT1NPLCA8c3Ryb25nPlNGPC9zdHJvbmc+IFNJTiBGVVNJQkxFLCA8c3Ryb25nPlBCPC9zdHJvbmc+IFBBUkFSUkFZTyBFTiBCVUVOIEVTVEFETywgPHN0cm9uZz5QRDwvc3Ryb25nPiBQQVJBUlJBWU8gREVGRUNUVU9TTywgPHN0cm9uZz5TUDwvc3Ryb25nPiBTSU4gUEFSQVJSQVlPLiA8c3Ryb25nPlNFPC9zdHJvbmc+IFNPTERBRFVSQSBFWE9Uw4lSTUlDQSwgPHN0cm9uZz5LUzwvc3Ryb25nPiBDT05FQ1RPUkVTIEVOIEJBUlJBIERFIFRJRVJSQS48L3A+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogSW1hZ2VuIGRlbCBUcmFuc2Zvcm1hZG9yIChQYXJ0ZSBpbmZlcmlvciBkZWwgY3VhZHJvKSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS05MDAvMzAgdGV4dC1jZW50ZXIgcHJpbnQ6Ymctd2hpdGVcIj5cbiAgICAgICAgICAgIHtmb3RvQmxvYiB8fCBmb3RvU3JjIHx8IHByZXZpZXdVcmwgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctbWQgbXgtYXV0byByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBzaGFkb3ctbGcgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgPFNhZmVJbWFnZSBcbiAgICAgICAgICAgICAgICAgIGJsb2I9e2ZvdG9CbG9ifSBcbiAgICAgICAgICAgICAgICAgIHNyYz17cHJldmlld1VybCB8fCBmb3RvU3JjfSBcbiAgICAgICAgICAgICAgICAgIGFsdD1cIlRyYW5zZm9ybWFkb3IgRWzDqWN0cmljb1wiIFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG9iamVjdC1jb3ZlclwiIFxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWF4SGVpZ2h0OiBgJHtkdC5mb3RvU2NhbGUgfHwgMjgwfXB4YCB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC1jZW50ZXIgc3BhY2UteS0yIG5vLXByaW50XCI+XG4gICAgICAgICAgICAgICAgPENhbWVyYSBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtc2xhdGUtNjAwIG14LWF1dG9cIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1tb25vIGJsb2NrXCI+U2luIGZvdG9ncmFmw61hIGFkanVudGEgZGVsIHRyYW5zZm9ybWFkb3I8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0zIHB5LTEuNSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtdmlvbGV0LTQwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICBBZGp1bnRhciBGb3RvXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qXCIgb25DaGFuZ2U9e2hhbmRsZUltYWdlQ2hhbmdlfSBjbGFzc05hbWU9XCJoaWRkZW5cIiAvPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIFNsaWRlciBkZSBhanVzdGUgZGUgdGFtYcOxbyAoc29sbyBlbiBwYW50YWxsYSBzaSBoYXkgaW1hZ2VuKSAqL31cbiAgICAgICAgICAgIHsoZm90b0Jsb2IgfHwgZm90b1NyYyB8fCBwcmV2aWV3VXJsKSAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm8tcHJpbnQgbXQtMyBtYXgtdy14cyBteC1hdXRvIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+QWp1c3RhciB0YW1hw7FvIGVuIFBERjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTQwMCBmb250LW1vbm9cIj57ZHQuZm90b1NjYWxlIHx8IDI4MH1weDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICBtaW49XCIxMjBcIlxuICAgICAgICAgICAgICAgICAgbWF4PVwiMzgwXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5mb3RvU2NhbGUgfHwgMjgwfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnZm90b1NjYWxlJywgcGFyc2VJbnQoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEgYmctc2xhdGUtODAwIHJvdW5kZWQtbGcgYXBwZWFyYW5jZS1ub25lIGN1cnNvci1wb2ludGVyIGFjY2VudC12aW9sZXQtNTAwXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHsvKiA1LiBQTEFOVElMTEE6IEJBTkNPIERFIENPTkRFTlNBRE9SRVMgKENPTVBFTlNBQ0nDk04gREUgUE9URU5DSUEgUkVBQ1RJVkEpICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7dGlwb0VsZW1lbnRvID09PSAnQkFOQ09fQ09OREVOU0FET1InICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctMnhsIHByaW50OmJvcmRlci1ibGFjayBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIFTDrXR1bG8gUHJpbmNpcGFsICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlci1iLTIgYm9yZGVyLXNsYXRlLTcwMCBwLTMuNSB0ZXh0LWNlbnRlciBwcmludDpiZy1ncmF5LTIwMCBwcmludDpib3JkZXItYmxhY2tcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgbWQ6dGV4dC1sZyBmb250LWJsYWNrIHRyYWNraW5nLXdpZGUgdGV4dC1zbGF0ZS0xMDAgdXBwZXJjYXNlIGZvbnQtbW9ubyBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bm9tYnJlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROb21icmUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNjAwIHJvdW5kZWQgcHgtMyBweS0xIHRleHQtY2VudGVyIHctZnVsbCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTEwMCBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgYEZJQ0hBIFTDiUNOSUNBIC0gQkFOQ08gREUgQ09NUEVOU0FDScOTTiBERSBQT1RFTkNJQSBSRUFDVElWQTogJHtub21icmUgfHwgJ0JDLTEnfWBcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBtZDpwLTYgc3BhY2UteS02XCI+XG5cbiAgICAgICAgICAgIHsvKiBTRUNDScOTTiAxOiBEQVRPUyBHRU5FUkFMRVMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1hbWJlci01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJvcmRlci1iIGJvcmRlci1zbGF0ZS05MDAgcGItMS41IHByaW50OnRleHQtc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgIDEuIERhdG9zIEdlbmVyYWxlc1xuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5Dw7NkaWdvIC8gVGFnOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODUwIHB4LTIuNSBweS0xLjUgcm91bmRlZC1sZyBibG9jayBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0zMDAgcHJpbnQ6dGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge2VsZW1lbnRvRGF0YS5pZH1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5VYmljYWNpw7NuIC8gUGxhbnRhOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dWJpY2FjaW9ufVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VWJpY2FjaW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1tZWRpdW0gcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTkwMCBibG9jayB0cnVuY2F0ZSBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0yMDAgcHJpbnQ6dGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7dWJpY2FjaW9uIHx8ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPkFsaW1lbnRhZG9yOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuYWxpbWVudGFkb3IgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnYWxpbWVudGFkb3InLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIGZvbnQtbWVkaXVtIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS05MDAgYmxvY2sgdHJ1bmNhdGUgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6Ym9yZGVyLWdyYXktMjAwIHByaW50OnRleHQtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2R0LmFsaW1lbnRhZG9yIHx8ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPkNhbGlicmUgZGVsIENvbmR1Y3Rvcjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmNhbGlicmVDb25kdWN0b3IgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnY2FsaWJyZUNvbmR1Y3RvcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1tZWRpdW0gcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTkwMCBibG9jayB0cnVuY2F0ZSBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0yMDAgcHJpbnQ6dGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZHQuY2FsaWJyZUNvbmR1Y3RvciB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5NYXJjYSAvIE1vZGVsbzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0Lm1hcmNhIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ21hcmNhJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBmb250LW1lZGl1bSBweC0yLjUgcHktMS41IGJnLXNsYXRlLTk1MC81MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtOTAwIGJsb2NrIHRydW5jYXRlIHByaW50OmJnLXdoaXRlIHByaW50OmJvcmRlci1ncmF5LTIwMCBwcmludDp0ZXh0LXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtkdC5tYXJjYSB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5GYWJyaWNhbnRlOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuZmFicmljYW50ZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdmYWJyaWNhbnRlJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBmb250LW1lZGl1bSBweC0yLjUgcHktMS41IGJnLXNsYXRlLTkwMC81MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtOTAwIGJsb2NrIHRydW5jYXRlIHByaW50OmJnLXdoaXRlIHByaW50OmJvcmRlci1ncmF5LTIwMCBwcmludDp0ZXh0LXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtkdC5mYWJyaWNhbnRlIHx8ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPkHDsW8gZGUgRmFicmljYWNpw7NuOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuYW5pb0ZhYnJpY2FjaW9uIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2FuaW9GYWJyaWNhY2lvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1tZWRpdW0gcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTkwMCBibG9jayB0cnVuY2F0ZSBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0yMDAgcHJpbnQ6dGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZHQuYW5pb0ZhYnJpY2FjaW9uIHx8ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU0VDQ0nDk04gMjogUEFSw4FNRVRST1MgRUzDiUNUUklDT1MgTk9NSU5BTEVTIERFIExBIFJFRCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMCBwYi0xLjUgcHJpbnQ6dGV4dC1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgMi4gUGFyw6FtZXRyb3MgRWzDqWN0cmljb3MgTm9taW5hbGVzIGRlIGxhIFJlZFxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5UZW5zacOzbiBOb21pbmFsIChWIC8ga1YpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQudGVuc2lvbk5vbWluYWwgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgndGVuc2lvbk5vbWluYWwnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBmb250LWJvbGQgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LnRlbnNpb25Ob21pbmFsIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+VGVuc2nDs24gUmVnaXN0cmFkYSAoViAvIGtWKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnRlbnNpb25SZWdpc3RyYWRhIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3RlbnNpb25SZWdpc3RyYWRhJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC50ZW5zaW9uUmVnaXN0cmFkYSB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPkZyZWN1ZW5jaWE6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5mcmVjdWVuY2lhIHx8ICc2MCBIeid9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnZnJlY3VlbmNpYScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGgtOVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiNTAgSHpcIj41MCBIejwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCI2MCBIelwiPjYwIEh6PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LmZyZWN1ZW5jaWEgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5Qb3RlbmNpYSBSZWFjdGl2YSBUb3RhbCAoa1ZBUik6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5wb3RlbmNpYVJlYWN0aXZhVG90YWwgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgncG90ZW5jaWFSZWFjdGl2YVRvdGFsJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC5wb3RlbmNpYVJlYWN0aXZhVG90YWwgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5Db3JyaWVudGUgTm9taW5hbCBUb3RhbCAoQSk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5jb3JyaWVudGVOb21pbmFsVG90YWwgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnY29ycmllbnRlTm9taW5hbFRvdGFsJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC5jb3JyaWVudGVOb21pbmFsVG90YWwgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5Ocm8uIEZhc2VzOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQubnVtRmFzZXMgfHwgJ1RyaWbDoXNpY28nfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ251bUZhc2VzJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgaC05XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNb25vZsOhc2ljb1wiPk1vbm9mw6FzaWNvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkJpZsOhc2ljb1wiPkJpZsOhc2ljbzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUcmlmw6FzaWNvXCI+VHJpZsOhc2ljbzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC5udW1GYXNlcyB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPkNvbmV4acOzbjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmNvbmV4aW9uIHx8ICdFc3RyZWxsYSd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnY29uZXhpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBoLTlcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkRlbHRhXCI+RGVsdGE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRXN0cmVsbGFcIj5Fc3RyZWxsYTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC5jb25leGlvbiB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPk5pdmVsIGRlIEFpc2xhbWllbnRvIEJJTCAoa1YpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQubml2ZWxBaXNsYW1pZW50b0JJTCB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCduaXZlbEFpc2xhbWllbnRvQklMJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0Lm5pdmVsQWlzbGFtaWVudG9CSUwgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNFQ0NJw5NOIDM6IENPTkZJR1VSQUNJw5NOIFkgUEFTT1MgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1hbWJlci01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJvcmRlci1iIGJvcmRlci1zbGF0ZS05MDAgcGItMS41IHByaW50OnRleHQtc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgIDMuIENvbmZpZ3VyYWNpw7NuIHkgUGFzb3MgZGUgQ29tcGVuc2FjacOzblxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5UaXBvIGRlIENvbXBlbnNhY2nDs246PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC50aXBvQ29tcGVuc2FjaW9uIHx8ICdBdXRvbcOhdGljYSAoUGFzb3MpJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCd0aXBvQ29tcGVuc2FjaW9uJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgaC05XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJGaWphXCI+RmlqYTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBdXRvbcOhdGljYSAoUGFzb3MpXCI+QXV0b23DoXRpY2EgKFBhc29zKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJEaW7DoW1pY2EgKFRpcmlzdG9yZXMvU1ZHKVwiPkRpbsOhbWljYSAoVGlyaXN0b3Jlcy9TVkcpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC50aXBvQ29tcGVuc2FjaW9uIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+TnJvLiBUb3RhbCBkZSBQYXNvczo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0Lm51bVBhc29zIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ251bVBhc29zJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0Lm51bVBhc29zIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+U2VjdWVuY2lhIGRlIFBhc29zIChrVkFSKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnNlY3VlbmNpYVBhc29zS3ZhciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdzZWN1ZW5jaWFQYXNvc0t2YXInLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gNTArNTArMTAwKzEwMCBrVkFSXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZSBmb250LW1vbm9cIj57ZHQuc2VjdWVuY2lhUGFzb3NLdmFyIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+VGlwbyBkZSBDb25tdXRhY2nDs246PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC50aXBvQ29ubXV0YWNpb24gfHwgJ0NvbnRhY3RvcmVzIGRlZGljYWRvcyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgndGlwb0Nvbm11dGFjaW9uJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgaC05XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDb250YWN0b3JlcyBkZWRpY2Fkb3NcIj5Db250YWN0b3JlcyBkZWRpY2Fkb3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSW50ZXJydXB0b3JlcyBlc3TDoXRpY29zXCI+SW50ZXJydXB0b3JlcyBlc3TDoXRpY29zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LnRpcG9Db25tdXRhY2lvbiB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU3VidGFibGEgaW50ZXJhY3RpdmEgZGUgUGFzb3MgeSBDb3JyaWVudGVzIEF1ZGl0YWRhcyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cbiAgICAgICAgICAgICAgICAgICAgUmVnaXN0cm8gZGUgQ29ycmllbnRlIHBvciBQYXNvIChBdWRpdG9yw61hIGVuIENhbXBvKTpcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VycmVudCA9IGR0LnBhc29zQXVkaXRvcmlhIHx8IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV4dE51bSA9IGN1cnJlbnQubGVuZ3RoICsgMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCdwYXNvc0F1ZGl0b3JpYScsIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uY3VycmVudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyBwYXNvOiBuZXh0TnVtLCBrdmFyOiAnJywgaU5vbWluYWw6ICcnLCBpTDE6ICcnLCBpTDI6ICcnLCBpTDM6ICcnLCBlc3RhZG86ICdPcGVyYXRpdm8nIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctYW1iZXItNTAwLzIwIGhvdmVyOmJnLWFtYmVyLTUwMC8zMCB0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC80MCByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICArIEFncmVnYXIgUGFzb1xuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgeyhkdC5wYXNvc0F1ZGl0b3JpYSAmJiBkdC5wYXNvc0F1ZGl0b3JpYS5sZW5ndGggPiAwKSA/IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LVsxMXB4XSB0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTJcIj5QYXNvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPlBvdGVuY2lhIChrVkFSKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTJcIj5JIE5vbWluYWwgKEEpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPkkgTDEgKEEpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPkkgTDIgKEEpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPkkgTDMgKEEpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPkVzdGFkbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgJiYgPHRoIGNsYXNzTmFtZT1cInAtMiB0ZXh0LWNlbnRlclwiPkFjY2nDs248L3RoPn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTg1MCB0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2R0LnBhc29zQXVkaXRvcmlhLm1hcCgocCwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2lkeH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYW1iZXItNTAwXCI+UGFzbyAje3AucGFzbyB8fCBpZHggKyAxfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwLmt2YXIgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gWy4uLmR0LnBhc29zQXVkaXRvcmlhXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRbaWR4XSA9IHsgLi4udXBkYXRlZFtpZHhdLCBrdmFyOiBlLnRhcmdldC52YWx1ZSB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRHRDaGFuZ2UoJ3Bhc29zQXVkaXRvcmlhJywgdXBkYXRlZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImtWQVJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTYgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMS41IHB5LTAuNSB0ZXh0LWNlbnRlciBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAocC5rdmFyID8gYCR7cC5rdmFyfSBrVkFSYCA6ICfigJQnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cC5pTm9taW5hbCB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4uZHQucGFzb3NBdWRpdG9yaWFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFtpZHhdID0geyAuLi51cGRhdGVkW2lkeF0sIGlOb21pbmFsOiBlLnRhcmdldC52YWx1ZSB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRHRDaGFuZ2UoJ3Bhc29zQXVkaXRvcmlhJywgdXBkYXRlZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTYgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMS41IHB5LTAuNSB0ZXh0LWNlbnRlciBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAocC5pTm9taW5hbCA/IGAke3AuaU5vbWluYWx9IEFgIDogJ+KAlCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwLmlMMSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4uZHQucGFzb3NBdWRpdG9yaWFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFtpZHhdID0geyAuLi51cGRhdGVkW2lkeF0sIGlMMTogZS50YXJnZXQudmFsdWUgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCdwYXNvc0F1ZGl0b3JpYScsIHVwZGF0ZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTE2IGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTEuNSBweS0wLjUgdGV4dC1jZW50ZXIgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKHAuaUwxID8gYCR7cC5pTDF9IEFgIDogJ+KAlCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwLmlMMiB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4uZHQucGFzb3NBdWRpdG9yaWFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFtpZHhdID0geyAuLi51cGRhdGVkW2lkeF0sIGlMMjogZS50YXJnZXQudmFsdWUgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCdwYXNvc0F1ZGl0b3JpYScsIHVwZGF0ZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTE2IGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTEuNSBweS0wLjUgdGV4dC1jZW50ZXIgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKHAuaUwyID8gYCR7cC5pTDJ9IEFgIDogJ+KAlCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwLmlMMyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4uZHQucGFzb3NBdWRpdG9yaWFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFtpZHhdID0geyAuLi51cGRhdGVkW2lkeF0sIGlMMzogZS50YXJnZXQudmFsdWUgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCdwYXNvc0F1ZGl0b3JpYScsIHVwZGF0ZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTE2IGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTEuNSBweS0wLjUgdGV4dC1jZW50ZXIgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKHAuaUwzID8gYCR7cC5pTDN9IEFgIDogJ+KAlCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwLmVzdGFkbyB8fCAnT3BlcmF0aXZvJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4uZHQucGFzb3NBdWRpdG9yaWFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFtpZHhdID0geyAuLi51cGRhdGVkW2lkeF0sIGVzdGFkbzogZS50YXJnZXQudmFsdWUgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCdwYXNvc0F1ZGl0b3JpYScsIHVwZGF0ZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMS41IHB5LTAuNSB0ZXh0LXhzIHRleHQtc2xhdGUtMjAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk9wZXJhdGl2b1wiPk9wZXJhdGl2bzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDYXBhY2l0b3IgRMOpYmlsIC8gRGVzYmFsYW5jZWFkb1wiPkNhcGFjaXRvciBEw6liaWw8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRGVzY29uZWN0YWRvXCI+RGVzY29uZWN0YWRvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkRhw7FhZG8gLyBGdWdhIERpZWzDqWN0cmljYVwiPkRhw7FhZG88L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHAuZXN0YWRvID09PSAnT3BlcmF0aXZvJyA/ICdiZy1lbWVyYWxkLTk1MCB0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlciBib3JkZXItZW1lcmFsZC04MDAnIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwLmVzdGFkbyA9PT0gJ0NhcGFjaXRvciBEw6liaWwgLyBEZXNiYWxhbmNlYWRvJyA/ICdiZy1hbWJlci05NTAgdGV4dC1hbWJlci00MDAgYm9yZGVyIGJvcmRlci1hbWJlci04MDAnIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnYmctcmVkLTk1MCB0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtODAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3AuZXN0YWRvIHx8ICdPcGVyYXRpdm8nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gZHQucGFzb3NBdWRpdG9yaWEuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpZHgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRHRDaGFuZ2UoJ3Bhc29zQXVkaXRvcmlhJywgdXBkYXRlZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC00MDAgaG92ZXI6dGV4dC1yZWQtMzAwIHAtMSB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVsaW1pbmFyIHBhc29cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pyVXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGl0YWxpYyBiZy1zbGF0ZS05NTAvNDAgcC0yLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICBTaW4gcmVnaXN0cm9zIGluZGl2aWR1YWxlcyBkZSBwYXNvcy4ge2lzRWRpdGluZyA/ICdIYXogY2xpYyBlbiBcIisgQWdyZWdhciBQYXNvXCIgcGFyYSBhdWRpdGFyIGNvcnJpZW50ZXMuJyA6ICcnfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNFQ0NJw5NOIDQ6IFVOSURBREVTIERFIENPTkRFTlNBRE9SRVMgKE3Dk0RVTE9TKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMCBwYi0xLjUgcHJpbnQ6dGV4dC1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgNC4gVW5pZGFkZXMgZGUgQ29uZGVuc2Fkb3JlcyAoTcOzZHVsb3MpXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPlBvdGVuY2lhIEluZGl2aWR1YWwgKGtWQVIpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQucG90ZW5jaWFJbmRpdmlkdWFsIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3BvdGVuY2lhSW5kaXZpZHVhbCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC5wb3RlbmNpYUluZGl2aWR1YWwgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5DYXBhY2l0YW5jaWEgKMK1Rik6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5jYXBhY2l0YW5jaWFNdWYgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnY2FwYWNpdGFuY2lhTXVmJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LmNhcGFjaXRhbmNpYU11ZiB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPlRlbnNpw7NuIGRlbCBDb25kZW5zYWRvciAoVik6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC50ZW5zaW9uQ29uZGVuc2Fkb3IgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgndGVuc2lvbkNvbmRlbnNhZG9yJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LnRlbnNpb25Db25kZW5zYWRvciB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPlRlY25vbG9nw61hIERpZWzDqWN0cmljYTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnRlY25vbG9naWFEaWVsZWN0cmljYSB8fCAnUG9saXByb3BpbGVubyBtZXRhbGl6YWRvJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCd0ZWNub2xvZ2lhRGllbGVjdHJpY2EnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBweC0yLjUgcHktMS41IGJnLXNsYXRlLTkwMC81MCByb3VuZGVkLWxnIGJsb2NrIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ymctd2hpdGVcIj57ZHQudGVjbm9sb2dpYURpZWxlY3RyaWNhIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+UmVzaXN0ZW5jaWEgZGUgRGVzY2FyZ2E6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5yZXNpc3RlbmNpYURlc2NhcmdhIHx8ICdTw60nfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3Jlc2lzdGVuY2lhRGVzY2FyZ2EnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBoLTlcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlPDrVwiPlPDrSAoJmx0OzUwViBlbiAmbHQ7NjBzKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJOb1wiPk5vPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LnJlc2lzdGVuY2lhRGVzY2FyZ2EgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5TZWd1cmlkYWQ6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5zZWd1cmlkYWQgfHwgJ0Rlc2NvbmVjdGFkb3IgcG9yIHNvYnJlcHJlc2nDs24nfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3NlZ3VyaWRhZCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC5zZWd1cmlkYWQgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNFQ0NJw5NOIDU6IFJFQUNUQU5DSUFTIEFOVElIQVJNw5NOSUNBUyAvIEZJTFRST1MgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1hbWJlci01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJvcmRlci1iIGJvcmRlci1zbGF0ZS05MDAgcGItMS41IHByaW50OnRleHQtc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgIDUuIFJlYWN0YW5jaWFzIEFudGloYXJtw7NuaWNhcyAvIEZpbHRyb3NcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+RmFjdG9yIGRlIERlc2ludG9uaXphY2nDs24gKHAlKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmZhY3RvckRlc2ludG9uaXphY2lvbiB8fCAnTi9BJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdmYWN0b3JEZXNpbnRvbml6YWNpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBoLTlcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjclICgxODkgSHopXCI+NyUgKDE4OSBIeik8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMTQlICgxMzQgSHopXCI+MTQlICgxMzQgSHopPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk4vQVwiPk4vQTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC5mYWN0b3JEZXNpbnRvbml6YWNpb24gfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5UaXBvIGRlIE7DumNsZW86PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC50aXBvTnVjbGVvIHx8ICdOw7pjbGVvIGRlIEhpZXJybyBjb24gRW50cmVoaWVycm8nfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3RpcG9OdWNsZW8nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBoLTlcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk7DumNsZW8gZGUgSGllcnJvIGNvbiBFbnRyZWhpZXJyb1wiPk7DumNsZW8gZGUgSGllcnJvIGNvbiBFbnRyZWhpZXJybzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBaXJlXCI+QWlyZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC50aXBvTnVjbGVvIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+QWlzbGFtaWVudG8gVMOpcm1pY286PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5jbGFzZUFpc2xhbWllbnRvVGVybWljbyB8fCAnQ2xhc2UgSCAoMTgwwrBDKSd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnY2xhc2VBaXNsYW1pZW50b1Rlcm1pY28nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBweC0yLjUgcHktMS41IGJnLXNsYXRlLTkwMC81MCByb3VuZGVkLWxnIGJsb2NrIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ymctd2hpdGVcIj57ZHQuY2xhc2VBaXNsYW1pZW50b1Rlcm1pY28gfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5Qcm90ZWNjacOzbiBUw6lybWljYTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnByb3RlY2Npb25UZXJtaWNhIHx8ICdTZW5zb3IgQmltZXTDoWxpY28gLyBQVDEwMCBpbnRlZ3JhZG8nfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3Byb3RlY2Npb25UZXJtaWNhJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LnByb3RlY2Npb25UZXJtaWNhIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTRUNDScOTTiA2OiBSRUdVTEFET1IgWSBQUk9URUNDSU9ORVMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1hbWJlci01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJvcmRlci1iIGJvcmRlci1zbGF0ZS05MDAgcGItMS41IHByaW50OnRleHQtc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgIDYuIFJlZ3VsYWRvciB5IFByb3RlY2Npb25lc1xuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTUgZ2FwLTQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+UmVndWxhZG9yIGRlIEZQIChNYXJjYSAvIE1vZGVsbyAvIFJhbmdvKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnJlZ3VsYWRvck1hcmNhTW9kZWxvIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3JlZ3VsYWRvck1hcmNhTW9kZWxvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LnJlZ3VsYWRvck1hcmNhTW9kZWxvIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+UmVsYWNpw7NuIGRlIFRDIFJlcXVlcmlkYTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnJlbGFjaW9uVGMgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgncmVsYWNpb25UYycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAxNjAwLzVBXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZSBmb250LW1vbm9cIj57ZHQucmVsYWNpb25UYyB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPlB1ZXJ0byBkZSBDb211bmljYWNpw7NuOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQucHVlcnRvQ29tdW5pY2FjaW9uIHx8ICdSUy00ODUgKE1vZGJ1cyBSVFUpJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdwdWVydG9Db211bmljYWNpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBoLTlcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlJTLTQ4NSAoTW9kYnVzIFJUVSlcIj5SUy00ODUgKE1vZGJ1cyBSVFUpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkV0aGVybmV0IChNb2RidXMgVENQKVwiPkV0aGVybmV0IChNb2RidXMgVENQKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJOaW5ndW5vXCI+TmluZ3Vubzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC5wdWVydG9Db211bmljYWNpb24gfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5JbnRlcnJ1cHRvciBQcmluY2lwYWwgKEEpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuaW50ZXJydXB0b3JQcmluY2lwYWxBbXAgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnaW50ZXJydXB0b3JQcmluY2lwYWxBbXAnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBmb250LWJvbGQgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LmludGVycnVwdG9yUHJpbmNpcGFsQW1wID8gZHQuaW50ZXJydXB0b3JQcmluY2lwYWxBbXAgKyAnIEEnIDogJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5Qcm90ZWNjacOzbiBkZSBQYXNvczo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnByb3RlY2Npb25QYXNvcyB8fCAnRnVzaWJsZXMnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3Byb3RlY2Npb25QYXNvcycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGgtOVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRnVzaWJsZXNcIj5GdXNpYmxlczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJCcmVha2Vyc1wiPkJyZWFrZXJzPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LnByb3RlY2Npb25QYXNvcyB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU0VDQ0nDk04gNzogR0FCSU5FVEUgWSBFTlRPUk5PIERFIE9QRVJBQ0nDk04gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1hbWJlci01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJvcmRlci1iIGJvcmRlci1zbGF0ZS05MDAgcGItMS41IHByaW50OnRleHQtc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgIDcuIEdhYmluZXRlIHkgRW50b3JubyBkZSBPcGVyYWNpw7NuXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPkdyYWRvIGRlIFByb3RlY2Npw7NuIEVudm9sdmVudGU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5ncmFkb1Byb3RlY2Npb25FbnZvbHZlbnRlIHx8ICdJUDU0J31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdncmFkb1Byb3RlY2Npb25FbnZvbHZlbnRlJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgaC05XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJJUDQxXCI+SVA0MTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJJUDU0XCI+SVA1NDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJORU1BIDNSXCI+TkVNQSAzUjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZVwiPntkdC5ncmFkb1Byb3RlY2Npb25FbnZvbHZlbnRlIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+RGltZW5zaW9uZXMgKEFsIHggQW4geCBQcik6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xLjUgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuZGltZW5zaW9uZXNBbHRvIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnZGltZW5zaW9uZXNBbHRvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMiBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCB0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj54PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmRpbWVuc2lvbmVzQW5jaG8gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdkaW1lbnNpb25lc0FuY2hvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPng8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuZGltZW5zaW9uZXNQcm9mIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnZGltZW5zaW9uZXNQcm9mJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQclwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdXCI+bW08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtkdC5kaW1lbnNpb25lc0FsdG8gfHwgJ+KAlCd9IHgge2R0LmRpbWVuc2lvbmVzQW5jaG8gfHwgJ+KAlCd9IHgge2R0LmRpbWVuc2lvbmVzUHJvZiB8fCAn4oCUJ30gbW1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5TaXN0ZW1hIGRlIEVuZnJpYW1pZW50bzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnNpc3RlbWFFbmZyaWFtaWVudG8gfHwgJ1ZlbnRpbGFjacOzbiBGb3J6YWRhJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdzaXN0ZW1hRW5mcmlhbWllbnRvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgaC05XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJWZW50aWxhY2nDs24gTmF0dXJhbFwiPlZlbnRpbGFjacOzbiBOYXR1cmFsPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlZlbnRpbGFjacOzbiBGb3J6YWRhXCI+VmVudGlsYWNpw7NuIEZvcnphZGE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRXh0cmFjdG9yZXMgeSBGaWx0cm9zXCI+RXh0cmFjdG9yZXMgeSBGaWx0cm9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJnLXdoaXRlXCI+e2R0LnNpc3RlbWFFbmZyaWFtaWVudG8gfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5UZW1wZXJhdHVyYSAvIEh1bWVkYWQ6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQudGVtcGVyYXR1cmFDIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgndGVtcGVyYXR1cmFDJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLCsENcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCB0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5odW1lZGFkUGN0IHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnaHVtZWRhZFBjdCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiJVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZSBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZHQudGVtcGVyYXR1cmFDID8gZHQudGVtcGVyYXR1cmFDICsgJyDCsEMnIDogJ+KAlCd9IC8ge2R0Lmh1bWVkYWRQY3QgPyBkdC5odW1lZGFkUGN0ICsgJyAlJyA6ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU0VDQ0nDk04gREUgT0JTRVJWQUNJT05FUyBQQVJUSUNVTEFSRVMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5PYnNlcnZhY2lvbmVzIEdlbmVyYWxlcyB5IFJlY29tZW5kYWNpb25lczwvc3Bhbj5cbiAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtvYnNlcnZhY2lvbmVzR2VuZXJhbGVzfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRPYnNlcnZhY2lvbmVzR2VuZXJhbGVzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHJvd3M9ezR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHRyYW5zaXRpb24tYWxsIGZvbnQtc2FucyByZXNpemUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVzY3JpYmEgbGFzIGNvbmRpY2lvbmVzIGRlbCBiYW5jbyBkZSBjb21wZW5zYWNpw7NuLCBwcm9ibGVtYXMgZW4gY2VsZGFzLCBkZXNiYWxhbmNlIGVuIGNvcnJpZW50ZSBkZSBjb25kZW5zYWRvcmVzLCBlc3RhZG8gZGUgY29udGFjdG9yZXMuLi5cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1zbGF0ZS0zMDAgZm9udC1zYW5zIGl0YWxpYyBiZy1zbGF0ZS05MDAvNDAgcC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS05MDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtvYnNlcnZhY2lvbmVzR2VuZXJhbGVzIHx8ICdObyBzZSBoYW4gcmVnaXN0cmFkbyBvYnNlcnZhY2lvbmVzIGVzcGVjw61maWNhcyBwYXJhIGVzdGUgYmFuY28gZGUgY29uZGVuc2Fkb3Jlcy4nfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU0VDQ0nDk04gRk9UT0dSw4FGSUNBICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS05MDAvNjAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgeyhmb3RvQmxvYiB8fCBmb3RvU3JjIHx8IHByZXZpZXdVcmwpID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZ3JvdXAgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc2hhZG93LWxnIG1heC13LXNtXCI+XG4gICAgICAgICAgICAgICAgICA8U2FmZUltYWdlXG4gICAgICAgICAgICAgICAgICAgIGJsb2I9e2ZvdG9CbG9ifVxuICAgICAgICAgICAgICAgICAgICBzcmM9e2ZvdG9TcmN9XG4gICAgICAgICAgICAgICAgICAgIGFsdD17bm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvYmplY3QtY29udGFpbiB3LWZ1bGwgcm91bmRlZC14bFwiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1heEhlaWdodDogYCR7ZHQuZm90b1NjYWxlIHx8IDI4MH1weGAgfX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC1jZW50ZXIgc3BhY2UteS0yIG5vLXByaW50XCI+XG4gICAgICAgICAgICAgICAgICA8Q2FtZXJhIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1zbGF0ZS02MDAgbXgtYXV0b1wiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ubyBibG9ja1wiPlNpbiBmb3RvZ3JhZsOtYSBhZGp1bnRhIGRlbCBiYW5jbyBkZSBjb25kZW5zYWRvcmVzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0zIHB5LTEuNSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtY3lhbi00MDAgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICBBZGp1bnRhciBGb3RvXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlLypcIiBvbkNoYW5nZT17aGFuZGxlSW1hZ2VDaGFuZ2V9IGNsYXNzTmFtZT1cImhpZGRlblwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBBanVzdGUgZGUgZXNjYWxhIGZvdG9ncsOhZmljYSAqL31cbiAgICAgICAgICAgICAgeyhmb3RvQmxvYiB8fCBmb3RvU3JjIHx8IHByZXZpZXdVcmwpICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vLXByaW50IG10LTMgbWF4LXcteHMgbXgtYXV0byBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BanVzdGFyIHRhbWHDsW8gZW4gUERGPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWN5YW4tNDAwIGZvbnQtbW9ub1wiPntkdC5mb3RvU2NhbGUgfHwgMjgwfXB4PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgICAgbWluPVwiMTIwXCJcbiAgICAgICAgICAgICAgICAgICAgbWF4PVwiMzgwXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmZvdG9TY2FsZSB8fCAyODB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2ZvdG9TY2FsZScsIHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEgYmctc2xhdGUtODAwIHJvdW5kZWQtbGcgYXBwZWFyYW5jZS1ub25lIGN1cnNvci1wb2ludGVyIGFjY2VudC1jeWFuLTUwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgey8qIDYuIFBMQU5USUxMQTogU0lTVEVNQSBERSBQVUVTVEEgQSBUSUVSUkEgKFBBVCAvIFRFTFVST01FVFLDjUEpICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7dGlwb0VsZW1lbnRvID09PSAnUFVFU1RBX1RJRVJSQScgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXItMiBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy0yeGwgcHJpbnQ6Ym9yZGVyLWJsYWNrIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogVMOtdHVsbyBQcmluY2lwYWwgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyLWItMiBib3JkZXItc2xhdGUtNzAwIHAtMy41IHRleHQtY2VudGVyIHByaW50OmJnLWdyYXktMjAwIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBtZDp0ZXh0LWxnIGZvbnQtYmxhY2sgdHJhY2tpbmctd2lkZSB0ZXh0LXNsYXRlLTEwMCB1cHBlcmNhc2UgZm9udC1tb25vIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtub21icmV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5vbWJyZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS02MDAgcm91bmRlZCBweC0zIHB5LTEgdGV4dC1jZW50ZXIgdy1mdWxsIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYW1iZXItNTAwIHRleHQtc2xhdGUtMTAwIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBgRklDSEEgVMOJQ05JQ0EgLSBTSVNURU1BIERFIFBVRVNUQSBBIFRJRVJSQSAoUEFUKTogJHtub21icmUgfHwgJ1BBVC0xJ31gXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgbWQ6cC02IHNwYWNlLXktNlwiPlxuXG4gICAgICAgICAgICB7LyogU0VDQ0nDk04gMTogREFUT1MgR0VORVJBTEVTICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtYW1iZXItNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBib3JkZXItYiBib3JkZXItc2xhdGUtOTAwIHBiLTEuNSBwcmludDp0ZXh0LXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAxLiBEYXRvcyBHZW5lcmFsZXMgZGUgbGEgUHVlc3RhIGEgVGllcnJhXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPkPDs2RpZ28gLyBUYWc6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04NTAgcHgtMi41IHB5LTEuNSByb3VuZGVkLWxnIGJsb2NrIHByaW50OmJnLXdoaXRlIHByaW50OmJvcmRlci1ncmF5LTMwMCBwcmludDp0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7ZWxlbWVudG9EYXRhLmlkfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPlViaWNhY2nDs24gLyDDgXJlYTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3ViaWNhY2lvbn1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFViaWNhY2lvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBmb250LW1lZGl1bSBweC0yLjUgcHktMS41IGJnLXNsYXRlLTkwMC81MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtOTAwIGJsb2NrIHRydW5jYXRlIHByaW50OmJnLXdoaXRlIHByaW50OmJvcmRlci1ncmF5LTIwMCBwcmludDp0ZXh0LXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHt1YmljYWNpb24gfHwgJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZCBtYi0xIHByaW50OnRleHQtc2xhdGUtNjAwXCI+RXF1aXBvIFByb3RlZ2lkbyAvIFZpbmN1bGFkbzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmVxdWlwb1ZpbmN1bGFkbyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdlcXVpcG9WaW5jdWxhZG8nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gU3ViZXN0YWNpw7NuIFByaW5jaXBhbCAvIFRhYmxlcm8gVEFCLTFcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1tZWRpdW0gcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTkwMCBibG9jayB0cnVuY2F0ZSBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0yMDAgcHJpbnQ6dGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZHQuZXF1aXBvVmluY3VsYWRvIHx8ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPkZlY2hhIGRlIE1lZGljacOzbjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmZlY2hhTWVkaWNpb24gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnZmVjaGFNZWRpY2lvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIGZvbnQtbWVkaXVtIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS05MDAgYmxvY2sgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6Ym9yZGVyLWdyYXktMjAwIHByaW50OnRleHQtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2R0LmZlY2hhTWVkaWNpb24gfHwgJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTRUNDScOTTiAyOiBNRURJQ0nDs04gREUgVEVMVVJPTUVUUsONQSAoUkVTSVNURU5DSUEgRU4gT0hNSU9TKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMCBwYi0xLjUgcHJpbnQ6dGV4dC1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgMi4gTWVkaWNpw7NuIGRlIFRlbHVyb21ldHLDrWEgeSBDb25mb3JtaWRhZCBOb3JtYXRpdmEgKElFRUUgODAgLyBDRU4pXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPlJlc2lzdGVuY2lhIE1lZGlkYSAozqkpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQucmVzaXN0ZW5jaWFPaG1zIHx8IGR0LnJlc2lzdGVuY2lhIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRHRDaGFuZ2UoJ3Jlc2lzdGVuY2lhT2htcycsIGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCdyZXNpc3RlbmNpYScsIGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDIuNDVcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9udC1tb25vIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTQwMCBmb250LW1vbm8gZm9udC1leHRyYWJvbGQgdGV4dC1iYXNlIHB4LTIuNSBweS0xIGJnLXNsYXRlLTkwMC84MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGJsb2NrIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZHQucmVzaXN0ZW5jaWFPaG1zIHx8IGR0LnJlc2lzdGVuY2lhID8gYCR7ZHQucmVzaXN0ZW5jaWFPaG1zIHx8IGR0LnJlc2lzdGVuY2lhfSDOqWAgOiAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5Fc3RhZG8gZGUgQ29uZm9ybWlkYWQ6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgeygoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHIgPSBwYXJzZUZsb2F0KGR0LnJlc2lzdGVuY2lhT2htcyB8fCBkdC5yZXNpc3RlbmNpYSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc05hTihyKSkgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+U2luIE1lZGljacOzbjwvc3Bhbj47XG4gICAgICAgICAgICAgICAgICAgIGlmIChyIDw9IDUuMCkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yLjUgcHktMS41IGJnLWVtZXJhbGQtOTUwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTgwMCByb3VuZGVkLWxnIGZvbnQtYm9sZCBibG9jayB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICDwn5+iIENvbmZvcm1lICjiiaQgNS4wIM6pKVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAociA8PSAxMC4wKSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIuNSBweS0xLjUgYmctYW1iZXItOTUwIHRleHQtYW1iZXItNDAwIGJvcmRlciBib3JkZXItYW1iZXItODAwIHJvdW5kZWQtbGcgZm9udC1ib2xkIGJsb2NrIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIPCfn6EgQWNlcHRhYmxlIFNlY3VuZGFyaW8gKOKJpCAxMC4wIM6pKVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIuNSBweS0xLjUgYmctcmVkLTk1MCB0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtODAwIHJvdW5kZWQtbGcgZm9udC1ib2xkIGJsb2NrIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIPCflLQgTm8gQ29uZm9ybWUgKCZndDsgMTAuMCDOqSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9KSgpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGQgbWItMSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPk3DqXRvZG8gZGUgTWVkaWNpw7NuOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQubWV0b2RvTWVkaWNpb24gfHwgJ0Nhw61kYSBkZSBQb3RlbmNpYWwgKDYyJSknfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ21ldG9kb01lZGljaW9uJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgaC05XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDYcOtZGEgZGUgUG90ZW5jaWFsICg2MiUpXCI+Q2HDrWRhIGRlIFBvdGVuY2lhbCAoNjIlKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNw6l0b2RvIGRlIDMgUHVudG9zXCI+TcOpdG9kbyBkZSAzIFB1bnRvczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNw6l0b2RvIFdlbm5lciAoNCBQaWNhcylcIj5Nw6l0b2RvIFdlbm5lciAoNCBQaWNhcyk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUGluemEgZGUgVGllcnJhIChTaW4gUGljYXMpXCI+UGluemEgZGUgVGllcnJhIChTaW4gUGljYXMpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC1sZyBibG9jayBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2R0Lm1ldG9kb01lZGljaW9uIHx8ICdDYcOtZGEgZGUgUG90ZW5jaWFsICg2MiUpJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5UZWx1csOzbWV0cm8gVXRpbGl6YWRvOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQudGVsdXJvbWV0cm9NYXJjYU1vZGVsbyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCd0ZWx1cm9tZXRyb01hcmNhTW9kZWxvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIE1lZ2dlciBERVQ0VEQyIC8gRmx1a2UgMTYyNVwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBweC0yLjUgcHktMS41IGJnLXNsYXRlLTkwMC81MCByb3VuZGVkLWxnIGJsb2NrIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZHQudGVsdXJvbWV0cm9NYXJjYU1vZGVsbyB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNFQ0NJw5NOIDM6IENPTkZJR1VSQUNJw5NOIEbDjVNJQ0EgWSBNQVRFUklBTEVTICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtYW1iZXItNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBib3JkZXItYiBib3JkZXItc2xhdGUtOTAwIHBiLTEuNSBwcmludDp0ZXh0LXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICAzLiBDb25maWd1cmFjacOzbiBGw61zaWNhIGRlIGxhIE1hbGxhIHkgRWxlY3Ryb2Rvc1xuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5UaXBvIGRlIFNpc3RlbWE6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC50aXBvU2lzdGVtYVBhdCB8fCAnTWFsbGEgY29uIFZhcmlsbGFzJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCd0aXBvU2lzdGVtYVBhdCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGgtOVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTWFsbGEgY29uIFZhcmlsbGFzXCI+TWFsbGEgY29uIFZhcmlsbGFzPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlBvem8gSW5kaXZpZHVhbFwiPlBvem8gSW5kaXZpZHVhbDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBbmlsbG8gUGVyaW1ldHJhbCBFcXVpcG90ZW5jaWFsXCI+QW5pbGxvIFBlcmltZXRyYWwgRXF1aXBvdGVuY2lhbDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQYXRhIGRlIEdhbnNvXCI+UGF0YSBkZSBHYW5zbzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtkdC50aXBvU2lzdGVtYVBhdCB8fCAnTWFsbGEgY29uIFZhcmlsbGFzJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5Ocm8uIGRlIFZhcmlsbGFzIC8gUGljYXM6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5zcHQ/LmJhcmlsbGFDYW50aWRhZCB8fCBkdC5udW1WYXJpbGxhcyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdudW1WYXJpbGxhcycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiA0ICg1LzgnJyB4IDIuNG0pXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtkdC5zcHQ/LmJhcmlsbGFDYW50aWRhZCB8fCBkdC5udW1WYXJpbGxhcyB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5DYWxpYnJlIENvbmR1Y3RvciAoR0VDKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnNwdD8uY29uZHVjdG9yQ2FsaWJyZSB8fCBkdC5jYWxpYnJlQ29uZHVjdG9yIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2NhbGlicmVDb25kdWN0b3InLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMi8wIEFXRyBDdSBEZXNudWRvXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIHB4LTIuNSBweS0xLjUgYmctc2xhdGUtOTAwLzUwIHJvdW5kZWQtbGcgYmxvY2sgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtkdC5zcHQ/LmNvbmR1Y3RvckNhbGlicmUgfHwgZHQuY2FsaWJyZUNvbmR1Y3RvciB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkIG1iLTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5UaXBvIGRlIFVuacOzbiAvIFNvbGRhZHVyYTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnRpcG9VbmlvbiB8fCAnU29sZGFkdXJhIEV4b3TDqXJtaWNhIChDYWR3ZWxkKSd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgndGlwb1VuaW9uJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgaC05XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTb2xkYWR1cmEgRXhvdMOpcm1pY2EgKENhZHdlbGQpXCI+U29sZGFkdXJhIEV4b3TDqXJtaWNhIChDYWR3ZWxkKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDb25lY3RvciBNZWPDoW5pY28gKEdyYXBhIGRlIEJyb25jZSlcIj5Db25lY3RvciBNZWPDoW5pY28gKEdyYXBhIGRlIEJyb25jZSk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVGVybWluYWwgYSBDb21wcmVzacOzblwiPlRlcm1pbmFsIGEgQ29tcHJlc2nDs248L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBweC0yLjUgcHktMS41IGJnLXNsYXRlLTkwMC81MCByb3VuZGVkLWxnIGJsb2NrIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZHQudGlwb1VuaW9uIHx8ICdTb2xkYWR1cmEgRXhvdMOpcm1pY2EgKENhZHdlbGQpJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNFQ0NJw5NOIDQ6IEFVRElUT1LDjUEgVEVSTU9HUsOBRklDQSBZIFBVTlRPUyBDQUxJRU5URVMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBib3JkZXItYiBib3JkZXItc2xhdGUtOTAwIHBiLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgcHJpbnQ6dGV4dC1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICA0LiBJbnNwZWNjacOzbiBUZXJtb2dyw6FmaWNhIHkgUHVudG9zIENhbGllbnRlcyBlbiBDb25leGlvbmVzXG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICB7aXNFZGl0aW5nICYmIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50ID0gZHQucHVudG9zVGVybW9ncmFmaWNvcyB8fCBbXTtcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEdENoYW5nZSgncHVudG9zVGVybW9ncmFmaWNvcycsIFtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmN1cnJlbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICB7IHB1bnRvOiBgUHVudG8gIyR7Y3VycmVudC5sZW5ndGggKyAxfWAsIHRTcG90OiAnJywgdFJlZjogJycsIGNvbXBvbmVudGU6ICdCb3JuZSAvIFRlcm1pbmFsJyB9XG4gICAgICAgICAgICAgICAgICAgICAgXSk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIuNSBweS0xIGJnLWFtYmVyLTUwMC8yMCBob3ZlcjpiZy1hbWJlci01MDAvMzAgdGV4dC1hbWJlci00MDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvNDAgcm91bmRlZCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICArIEFncmVnYXIgUHVudG8gVGVybW9ncsOhZmljb1xuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgeyhkdC5wdW50b3NUZXJtb2dyYWZpY29zICYmIGR0LnB1bnRvc1Rlcm1vZ3JhZmljb3MubGVuZ3RoID4gMCkgPyAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LVsxMXB4XSB0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTJcIj5Db21wb25lbnRlIC8gUHVudG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPlQuIE1lZGlkYSAowrBDKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yXCI+VC4gUmVmZXJlbmNpYSAowrBDKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yXCI+zpRUIENhbGN1bGFkbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yXCI+U2V2ZXJpZGFkIE5FVEEvTkZQQTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nICYmIDx0aCBjbGFzc05hbWU9XCJwLTIgdGV4dC1jZW50ZXJcIj5BY2Npw7NuPC90aD59XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS04NTAgdGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZHQucHVudG9zVGVybW9ncmFmaWNvcy5tYXAoKHB0LCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNwb3QgPSBwYXJzZUZsb2F0KHB0LnRTcG90KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlZiA9IHBhcnNlRmxvYXQocHQudFJlZik7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkZWx0YVQgPSAoIWlzTmFOKHNwb3QpICYmICFpc05hTihyZWYpKSA/IChzcG90IC0gcmVmKS50b0ZpeGVkKDEpIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRlbHRhTnVtID0gZGVsdGFUICE9PSBudWxsID8gcGFyc2VGbG9hdChkZWx0YVQpIDogbnVsbDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aWR4fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3B0LmNvbXBvbmVudGUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gWy4uLmR0LnB1bnRvc1Rlcm1vZ3JhZmljb3NdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFtpZHhdID0geyAuLi51cGRhdGVkW2lkeF0sIGNvbXBvbmVudGU6IGUudGFyZ2V0LnZhbHVlIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEdENoYW5nZSgncHVudG9zVGVybW9ncmFmaWNvcycsIHVwZGF0ZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gQm9ybmUgYmFycmEgZGUgdGllcnJhXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMS41IHB5LTAuNSB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAocHQuY29tcG9uZW50ZSB8fCAnQm9ybmUgZGUgQ29uZXhpw7NuJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cHQudFNwb3QgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gWy4uLmR0LnB1bnRvc1Rlcm1vZ3JhZmljb3NdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFtpZHhdID0geyAuLi51cGRhdGVkW2lkeF0sIHRTcG90OiBlLnRhcmdldC52YWx1ZSB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRHRDaGFuZ2UoJ3B1bnRvc1Rlcm1vZ3JhZmljb3MnLCB1cGRhdGVkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiwrBDXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTE2IGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTEuNSBweS0wLjUgdGV4dC1jZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChwdC50U3BvdCA/IGAke3B0LnRTcG90fSDCsENgIDogJ+KAlCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3B0LnRSZWYgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gWy4uLmR0LnB1bnRvc1Rlcm1vZ3JhZmljb3NdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFtpZHhdID0geyAuLi51cGRhdGVkW2lkeF0sIHRSZWY6IGUudGFyZ2V0LnZhbHVlIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEdENoYW5nZSgncHVudG9zVGVybW9ncmFmaWNvcycsIHVwZGF0ZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLCsENcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTYgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMS41IHB5LTAuNSB0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKHB0LnRSZWYgPyBgJHtwdC50UmVmfSDCsENgIDogJ+KAlCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBmb250LW1vbm8gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGVsdGFUICE9PSBudWxsID8gYCR7ZGVsdGFUID4gMCA/ICcrJyA6ICcnfSR7ZGVsdGFUfSDCsENgIDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGVsdGFOdW0gIT09IG51bGwgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbHRhTnVtID4gMjAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgYmctcmVkLTk1MCB0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtODAwIHJvdW5kZWQgdGV4dC1bMTBweF0gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5S0IENyw610aWNhIChBY2Npw7NuIElubWVkaWF0YSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBkZWx0YU51bSA+IDEwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IGJnLWFtYmVyLTk1MCB0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTgwMCByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+foSBNb2RlcmFkYSAoTWFudGVuaW1pZW50bylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgYmctZW1lcmFsZC05NTAgdGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtODAwIHJvdW5kZWQgdGV4dC1bMTBweF0gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5+iIE5vcm1hbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwXCI+UGVuZGllbnRlPC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZCA9IGR0LnB1bnRvc1Rlcm1vZ3JhZmljb3MuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpZHgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRHRDaGFuZ2UoJ3B1bnRvc1Rlcm1vZ3JhZmljb3MnLCB1cGRhdGVkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTQwMCBob3Zlcjp0ZXh0LXJlZC0zMDAgcC0xIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pyVXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBpdGFsaWMgYmctc2xhdGUtOTAwLzQwIHAtMi41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgIFNpbiByZWdpc3Ryb3MgZGUgYW5vbWFsw61hcyB0w6lybWljYXMgZW4gZXN0ZSBlbGVjdHJvZG8vbWFsbGEuIHtpc0VkaXRpbmcgPyAnSGF6IGNsaWMgZW4gXCIrIEFncmVnYXIgUHVudG8gVGVybW9ncsOhZmljb1wiIHBhcmEgcmVnaXN0cmFyIGluc3BlY2Npw7NuLicgOiAnJ31cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU0VDQ0nDk04gNTogT0JTRVJWQUNJT05FUyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgIDUuIE9ic2VydmFjaW9uZXMgVMOpY25pY2FzIHkgUmVjb21lbmRhY2lvbmVzXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtvYnNlcnZhY2lvbmVzR2VuZXJhbGVzfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRPYnNlcnZhY2lvbmVzR2VuZXJhbGVzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHJvd3M9ezR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIGZvbnQtc2FucyByZXNpemUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVzY3JpYmEgb2JzZXJ2YWNpb25lcyBzb2JyZSBjb3Jyb3Npw7NuIGVuIHNvbGRhZHVyYXMsIHN1bGZhdGFjacOzbiBlbiBiYXJyYXMsIGVzdGFkbyBkZSBsYSBjYWphIGRlIGluc3BlY2Npw7NuLi4uXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgbGVhZGluZy1yZWxheGVkIHRleHQtc2xhdGUtMzAwIGZvbnQtc2FucyBpdGFsaWMgYmctc2xhdGUtOTAwLzQwIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtOTAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7b2JzZXJ2YWNpb25lc0dlbmVyYWxlcyB8fCAnU2luIG9ic2VydmFjaW9uZXMgZXNwZWPDrWZpY2FzIHJlZ2lzdHJhZGFzIHBhcmEgZXN0ZSBzaXN0ZW1hIGRlIHB1ZXN0YSBhIHRpZXJyYS4nfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU0VDQ0nDk04gNjogUkVHSVNUUk8gRk9UT0dSw4FGSUNPICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS05MDAvNjAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgeyhmb3RvQmxvYiB8fCBmb3RvU3JjIHx8IHByZXZpZXdVcmwpID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZ3JvdXAgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc2hhZG93LWxnIG1heC13LXNtXCI+XG4gICAgICAgICAgICAgICAgICA8U2FmZUltYWdlXG4gICAgICAgICAgICAgICAgICAgIGJsb2I9e2ZvdG9CbG9ifVxuICAgICAgICAgICAgICAgICAgICBzcmM9e2ZvdG9TcmN9XG4gICAgICAgICAgICAgICAgICAgIGFsdD17bm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvYmplY3QtY29udGFpbiB3LWZ1bGwgcm91bmRlZC14bFwiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1heEhlaWdodDogYCR7ZHQuZm90b1NjYWxlIHx8IDI4MH1weGAgfX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC1jZW50ZXIgc3BhY2UteS0yIG5vLXByaW50XCI+XG4gICAgICAgICAgICAgICAgICA8Q2FtZXJhIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1zbGF0ZS02MDAgbXgtYXV0b1wiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ubyBibG9ja1wiPlNpbiBmb3RvZ3JhZsOtYSBhZGp1bnRhIGRlIGxhIHB1ZXN0YSBhIHRpZXJyYTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgcHgtMyBweS0xLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LWFtYmVyLTQwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgIEFkanVudGFyIEZvdG9cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJmaWxlXCIgYWNjZXB0PVwiaW1hZ2UvKlwiIG9uQ2hhbmdlPXtoYW5kbGVJbWFnZUNoYW5nZX0gY2xhc3NOYW1lPVwiaGlkZGVuXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgeyhmb3RvQmxvYiB8fCBmb3RvU3JjIHx8IHByZXZpZXdVcmwpICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vLXByaW50IG10LTMgbWF4LXcteHMgbXgtYXV0byBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BanVzdGFyIHRhbWHDsW8gZW4gUERGPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTQwMCBmb250LW1vbm9cIj57ZHQuZm90b1NjYWxlIHx8IDI4MH1weDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICAgIG1pbj1cIjEyMFwiXG4gICAgICAgICAgICAgICAgICAgIG1heD1cIjM4MFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5mb3RvU2NhbGUgfHwgMjgwfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdmb3RvU2NhbGUnLCBwYXJzZUludChlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xIGJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIGFwcGVhcmFuY2Utbm9uZSBjdXJzb3ItcG9pbnRlciBhY2NlbnQtYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7LyogNi4gUExBTlRJTExBOiBQVU5UTyBERSBTVU1JTklTVFJPIC8gQUNPTUVUSURBICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7dGlwb0VsZW1lbnRvID09PSAnUFVOVE9fU1VNSU5JU1RSTycgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXItMiBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy0yeGwgcHJpbnQ6Ym9yZGVyLWJsYWNrIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogSGVhZGVyIG9maWNpYWwgZGVsIGN1YWRybyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS03MDAgcC0zLjUgdGV4dC1jZW50ZXIgcHJpbnQ6YmctZ3JheS0yMDAgcHJpbnQ6Ym9yZGVyLWJsYWNrXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIG1kOnRleHQtbGcgZm9udC1ibGFjayB0cmFja2luZy13aWRlIHRleHQtc2xhdGUtMTAwIHVwcGVyY2FzZSBmb250LW1vbm8gcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25vbWJyZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm9tYnJlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIFBVTlRPIERFIFNVTUlOSVNUUk8gUFJJTkNJUEFMXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTYwMCByb3VuZGVkIHB4LTMgcHktMSB0ZXh0LWNlbnRlciB3LWZ1bGwgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgdGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIHBsYWNlaG9sZGVyLXNsYXRlLTYwMFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBgUExBTklMTEEgREUgTEVWQU5UQU1JRU5UTyBUw4lDTklDTzogJHtub21icmUgfHwgJ1BVTlRPIERFIFNVTUlOSVNUUk8gLyBBQ09NRVRJREEnfWBcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ3VhZHJvIGRlIEluZm9ybWFjacOzbiBHZW5lcmFsICovfVxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14cyB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlIGJvcmRlci1iIGJvcmRlci1zbGF0ZS03MDAgZm9udC1tb25vIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwidy0xLzMgYmctc2xhdGUtOTAwLzkwIGZvbnQtYm9sZCBwLTMgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6YmctZ3JheS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIFVCSUNBQ0nDk04gLyBQQ0MgKFBVTlRPIENPTkVYScOTTik6XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtc2xhdGUtMTAwIGZvbnQtc2VtaWJvbGQgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1YmljYWNpb259XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVYmljYWNpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIEzDrW1pdGUgZGUgUHJvcGllZGFkIC8gQ2FzZXRhIGRlIE1lZGljacOzblwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMCBwbGFjZWhvbGRlci1zbGF0ZS02MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgdWJpY2FjaW9uIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvOTAgZm9udC1ib2xkIHAtMyB0ZXh0LXNsYXRlLTMwMCB1cHBlcmNhc2UgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpiZy1ncmF5LTEwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgQ0FSR0EgQ09OVFJBVEFEQSAoa1ZBKTpcbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1hbWJlci00MDAgZm9udC1ib2xkIHByaW50OnRleHQtYmxhY2sgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LmNhcmdhQ29udHJhdGFkYUt2YSB8fCBkdC5jYXBhY2lkYWRDb250cmF0YWRhS3ZhIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRHRDaGFuZ2UoJ2NhcmdhQ29udHJhdGFkYUt2YScsIGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCdjYXBhY2lkYWRDb250cmF0YWRhS3ZhJywgZS50YXJnZXQudmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMTAwMCBrVkFcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgcGxhY2Vob2xkZXItc2xhdGUtNjAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIGR0LmNhcmdhQ29udHJhdGFkYUt2YSB8fCBkdC5jYXBhY2lkYWRDb250cmF0YWRhS3ZhIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvOTAgZm9udC1ib2xkIHAtMyB0ZXh0LXNsYXRlLTMwMCB1cHBlcmNhc2UgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpiZy1ncmF5LTEwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgVElQTyBERSBNRURJQ0nDk04gRUzDiUNUUklDQTpcbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1zbGF0ZS0xMDAgZm9udC1zZW1pYm9sZCBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnRpcG9NZWRpY2lvbiB8fCAnTWVkaWNpw7NuIERpcmVjdGEgKEJhamEgVGVuc2nDs24pJ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCd0aXBvTWVkaWNpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTWVkaWNpw7NuIERpcmVjdGEgKEJhamEgVGVuc2nDs24pXCI+TWVkaWNpw7NuIERpcmVjdGEgKEJhamEgVGVuc2nDs24pPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk1lZGljacOzbiBJbmRpcmVjdGEgQlRcIj5NZWRpY2nDs24gSW5kaXJlY3RhIEJUIChjb24gVENzKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNZWRpY2nDs24gSW5kaXJlY3RhIEFUL01UXCI+TWVkaWNpw7NuIEluZGlyZWN0YSBBVC9NVCAoY29uIFRDcyB5IFRQcyk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1za3ktNDAwIHByaW50OnRleHQtYmxhY2tcIj57ZHQudGlwb01lZGljaW9uIHx8ICdNZWRpY2nDs24gRGlyZWN0YSAoQmFqYSBUZW5zacOzbiknfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC85MCBmb250LWJvbGQgcC0zIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSBib3JkZXItciBib3JkZXItc2xhdGUtODAwIHByaW50OmJnLWdyYXktMTAwIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICBURU5TScOTTiBERSBTRVJWSUNJTyAoQ09WRU5JTiAxNTk6MTk5Nyk6XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtc2xhdGUtMTAwIGZvbnQtc2VtaWJvbGQgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1RFTlNJT05FU19DT1ZFTklOX1RPREFTLmluY2x1ZGVzKGR0Lm5pdmVsVGVuc2lvbiB8fCBkdC50ZW5zaW9uTm9taW5hbCkgPyAoZHQubml2ZWxUZW5zaW9uIHx8IGR0LnRlbnNpb25Ob21pbmFsKSA6ICgoZHQubml2ZWxUZW5zaW9uIHx8IGR0LnRlbnNpb25Ob21pbmFsKSA/ICdDVVNUT00nIDogJycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLnRhcmdldC52YWx1ZSAhPT0gJ0NVU1RPTScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEdENoYW5nZSgnbml2ZWxUZW5zaW9uJywgZS50YXJnZXQudmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCd0ZW5zaW9uTm9taW5hbCcsIGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMCB3LTEvMlwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjY2lvbmUgdGVuc2nDs24uLi48L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRncm91cCBsYWJlbD1cIkJhamEgVGVuc2nDs24gKEJUKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7VEVOU0lPTkVTX0NPVkVOSU5fMTU5X0JULm1hcCh2ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dn0gdmFsdWU9e3Z9Pnt2fTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0Z3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0Z3JvdXAgbGFiZWw9XCJNZWRpYSBUZW5zacOzbiAoTVQpXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtURU5TSU9ORVNfQ09WRU5JTl8xNTlfTVQubWFwKHYgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt2fSB2YWx1ZT17dn0+e3Z9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRncm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDVVNUT01cIj5PdHJhIHRlbnNpw7NuLi4uPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQubml2ZWxUZW5zaW9uIHx8IGR0LnRlbnNpb25Ob21pbmFsIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCduaXZlbFRlbnNpb24nLCBlLnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUR0Q2hhbmdlKCd0ZW5zaW9uTm9taW5hbCcsIGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAxMy44IGtWIG8gMjA4LzEyMCBWXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMCB3LTEvMiBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgZHQubml2ZWxUZW5zaW9uIHx8IGR0LnRlbnNpb25Ob21pbmFsIHx8ICfigJQnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGZvbnQtYm9sZCBwLTMgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6YmctZ3JheS0xMDAgcHJpbnQ6dGV4dC1ibGFjayBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIFJFRCBQw5pCTElDQSAvIEVOTEFDRSBDT1JQT0VMRUM6XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtc2xhdGUtMTAwIGZvbnQtc2VtaWJvbGQgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuZW1wcmVzYURpc3RyaWJ1aWRvcmEgfHwgJ0NPUlBPRUxFQyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdlbXByZXNhRGlzdHJpYnVpZG9yYScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGlzdHJpYnVpZG9yYSAoQ09SUE9FTEVDKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDBcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQubnVtZXJvQ29udHJhdG8gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdudW1lcm9Db250cmF0bycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTsKwIENvbnRyYXRvIC8gTklDXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMCBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQubmljIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnbmljJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOwrAgTWVkaWRvclwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0LnBvc3RlVHJhbnNmb3JtYWRvciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3Bvc3RlVHJhbnNmb3JtYWRvcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUG9zdGUgLyBUcmFmbyBTZXJ2aWNpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PjxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5EaXN0cmlidWlkb3JhOjwvc3Ryb25nPiB7ZHQuZW1wcmVzYURpc3RyaWJ1aWRvcmEgfHwgJ0NPUlBPRUxFQyd9IHwgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPkFjb21ldGlkYTo8L3N0cm9uZz4ge2R0LnRpcG9BY29tZXRpZGEgfHwgJ1N1YnRlcnLDoW5lYSd9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj48c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+TsKwIENvbnRyYXRvIC8gTklDOjwvc3Ryb25nPiA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1hbWJlci00MDAgZm9udC1ib2xkXCI+e2R0Lm51bWVyb0NvbnRyYXRvIHx8ICfigJQnfTwvc3Bhbj4gfCA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+TsKwIE1lZGlkb3I6PC9zdHJvbmc+IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPntkdC5uaWMgfHwgJ+KAlCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+PHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlBvc3RlIC8gVHJhZm8gU3VtaW5pc3Rybzo8L3N0cm9uZz4ge2R0LnBvc3RlVHJhbnNmb3JtYWRvciB8fCAn4oCUJ308L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG5cbiAgICAgICAgICB7LyogU3ViLUhlYWRlcjogTWV0cm9sb2fDrWEgRWzDqWN0cmljYSB5IFBhcsOhbWV0cm9zIE9wZXJhdGl2b3MgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvODAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTcwMCBwLTIgdGV4dC1jZW50ZXIgZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNDAwIGZvbnQtbW9ubyBwcmludDpiZy1ncmF5LTIwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgTWV0cm9sb2fDrWEgRWzDqWN0cmljYSBlbiBQdW50byBkZSBTdW1pbmlzdHJvIChDT1ZFTklOIDE1OToxOTk3KVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS05MDAvMzBcIj5cbiAgICAgICAgICAgIDxNZXRyb2xvZ2lhRWxlY3RyaWNhU2VjdGlvblxuICAgICAgICAgICAgICBtZWRpY2lvbmVzPXtkdC5tZWRpY2lvbmVzIHx8IHt9fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KG51ZXZhc01lZGljaW9uZXMpID0+IGhhbmRsZUR0Q2hhbmdlKCdtZWRpY2lvbmVzJywgbnVldmFzTWVkaWNpb25lcyl9XG4gICAgICAgICAgICAgIHJlYWRPbmx5PXshaXNFZGl0aW5nfVxuICAgICAgICAgICAgICB0aXR1bG89XCJNZXRyb2xvZ8OtYSBFbMOpY3RyaWNhIGVuIFB1bnRvIGRlIFN1bWluaXN0cm8gKENPVkVOSU4gMTU5OjE5OTcpXCJcbiAgICAgICAgICAgICAgc3VidGl0dWxvPVwiVGVuc2lvbmVzIEwtTCwgTC1OIHkgNSBDYW5hbGVzIGRlIENvcnJpZW50ZSAoRmFzZXMsIE5ldXRybyB5IFRpZXJyYSlcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBPYnNlcnZhY2lvbmVzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItOTUwLzQwIGJvcmRlci1iLTIgYm9yZGVyLWFtYmVyLTgwMC82MCBwLTQgZm9udC1tb25vIHRleHQteHMgdGV4dC1hbWJlci0yMDAgcHJpbnQ6YmcteWVsbG93LTEwMCBwcmludDp0ZXh0LWJsYWNrIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ibGFjayB1cHBlcmNhc2UgdGV4dC1hbWJlci00MDAgYmxvY2sgbWItMSBwcmludDp0ZXh0LWJsYWNrXCI+T0JTRVJWQUNJw5NOIEdFTkVSQUw6PC9zcGFuPlxuICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgdmFsdWU9e29ic2VydmFjaW9uZXNHZW5lcmFsZXN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRPYnNlcnZhY2lvbmVzR2VuZXJhbGVzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICByb3dzPXsyfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgcGxhY2Vob2xkZXItc2xhdGUtNjAwXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkluZGlxdWUgaGFsbGF6Z29zLCBlc3RhZG8gZGVsIG1lZGlkb3IgbyBjb25kaWNpb25lcyBkZSBsYSBhY29tZXRpZGEuLi5cIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHA+e29ic2VydmFjaW9uZXNHZW5lcmFsZXMgfHwgJ05JTkdVTkEgT0JTRVJWQUNJT04nfTwvcD5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRm90b3MgLyBFdmlkZW5jaWEgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc2xhdGUtOTAwLzYwIHRleHQtY2VudGVyIGZvbnQtbW9ubyBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItYmxhY2tcIj5cbiAgICAgICAgICAgIDxEdWFsUGhvdG9VcGxvYWRlclxuICAgICAgICAgICAgICBmb3RvQmxvYj17Zm90b0Jsb2J9XG4gICAgICAgICAgICAgIGZvdG9TcmM9e2ZvdG9TcmN9XG4gICAgICAgICAgICAgIHByZXZpZXdVcmw9e3ByZXZpZXdVcmx9XG4gICAgICAgICAgICAgIG9uSW1hZ2VTZWxlY3RlZD17KGZpbGUpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRGb3RvQmxvYihmaWxlKTtcbiAgICAgICAgICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgICAgICAgICAgICAgIHJlYWRlci5vbmxvYWRlbmQgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRGb3RvU3JjKHJlYWRlci5yZXN1bHQpO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgICAgICAgICAgICAgaWYgKHByZXZpZXdVcmwpIFVSTC5yZXZva2VPYmplY3RVUkwocHJldmlld1VybCk7XG4gICAgICAgICAgICAgICAgc2V0UHJldmlld1VybChVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgb25SZW1vdmU9eygpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRGb3RvQmxvYihudWxsKTtcbiAgICAgICAgICAgICAgICBzZXRGb3RvU3JjKG51bGwpO1xuICAgICAgICAgICAgICAgIGlmIChwcmV2aWV3VXJsKSBVUkwucmV2b2tlT2JqZWN0VVJMKHByZXZpZXdVcmwpO1xuICAgICAgICAgICAgICAgIHNldFByZXZpZXdVcmwobnVsbCk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIHJlYWRPbmx5PXshaXNFZGl0aW5nfVxuICAgICAgICAgICAgICBsYWJlbD1cIkZvdG8gZGVsIE1lZGlkb3IgLyBQdW50byBkZSBTdW1pbmlzdHJvXCJcbiAgICAgICAgICAgICAgc3VibGFiZWw9XCJDw6FtYXJhIGVuIHZpdm8gbyBzZWxlY2Npw7NuIGRlIGdhbGVyw61hXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogQ2llcnJlIC8gRmlybWFzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGJnLXNsYXRlLTk1MC80MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCByb3VuZGVkLTJ4bCBwLTUgc3BhY2UteS00IHByaW50OmJnLXNsYXRlLTUwIHByaW50OmJvcmRlci1ncmF5LTIwMCBwcmludDptdC0zXCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMCBwYi0yLjUgcHJpbnQ6dGV4dC1zbGF0ZS03MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMjAwXCI+XG4gICAgICAgICAgRmlybWEgeSBDaWVycmUgZGUgSW5zcGVjY2nDs25cbiAgICAgICAgPC9oMz5cbiAgICAgICAgXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxuICAgICAgICAgIHsvKiBGaXJtYSBJbnNwZWN0b3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjUgaXRlbXMtY2VudGVyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5GaXJtYSBkZWwgSW5zcGVjdG9yPC9zcGFuPlxuICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5maXJtYUluc3BlY3RvciB8fCAnJ31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2Zpcm1hSW5zcGVjdG9yJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyIG5vLXByaW50XCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tYnJlIGRlbCBJbnNwZWN0b3JcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHByaW50OmJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG10LTEgaC02XCI+XG4gICAgICAgICAgICAgICAgICB7ZHQuZmlybWFJbnNwZWN0b3IgfHwgJ19fX19fX19fX19fX19fX19fX19fX19fX19fXyd9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIHByaW50OnRleHQtc2xhdGUtOTAwXCI+e2R0LmZpcm1hSW5zcGVjdG9yIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBwcmludDpibG9jayB3LTQ4IGJvcmRlci1iIGJvcmRlci1ncmF5LTMwMCBtdC02IGgtMVwiPjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEZpcm1hIC8gU2VsbG8gZGUgbGEgRW1wcmVzYSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEuNSBpdGVtcy1jZW50ZXIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPkZpcm1hIC8gU2VsbG8gZGUgbGEgRW1wcmVzYTwvc3Bhbj5cbiAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZHQuZmlybWFTdXBlcnZpc29yIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnZmlybWFTdXBlcnZpc29yJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyIG5vLXByaW50XCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tYnJlIC8gU2VsbG8gZGUgbGEgRW1wcmVzYVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gcHJpbnQ6YmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbXQtMSBoLTZcIj5cbiAgICAgICAgICAgICAgICAgIHtkdC5maXJtYVN1cGVydmlzb3IgfHwgJ19fX19fX19fX19fX19fX19fX19fX19fX19fXyd9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIHByaW50OnRleHQtc2xhdGUtOTAwXCI+e2R0LmZpcm1hU3VwZXJ2aXNvciB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gcHJpbnQ6YmxvY2sgdy00OCBib3JkZXItYiBib3JkZXItZ3JheS0zMDAgbXQtNiBoLTFcIj48L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPE1vZGFsRWRpY2lvbkNpcmN1aXRvXG4gICAgICAgIGlzT3Blbj17bW9kYWxKZXJhcnF1aWFPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRNb2RhbEplcmFycXVpYU9wZW4oZmFsc2UpfVxuICAgICAgICBjaXJjdWl0RGF0YT17Y2lyY3VpdERhdGFXaXphcmR9XG4gICAgICAgIHRhYmxlcm9DaXJjdWl0cz17ZHQuY2lyY3VpdHMgfHwgZHQuY2lyY3VpdG9zIHx8IFtdfVxuICAgICAgICBtYXhQb2xvcz17ZHQubWF4UG9sZXMgfHwgNDJ9XG4gICAgICAgIG1vZG89e3dpemFyZE1vZG99XG4gICAgICAgIHRpcG9PcmlnZW49e3RpcG9FbGVtZW50b31cbiAgICAgICAgZWxlbWVudG9zQ3JlYWRvcz17YWxsRmVlZGVyc31cbiAgICAgICAgb25TYXZlPXsoaWRTYWxpZGEsIHVwZGF0ZWQpID0+IHtcbiAgICAgICAgICBjb25zdCBpc0VudHJhZGFPclByaW1hcmlhID0gd2l6YXJkTW9kbyA9PT0gJ0VOVFJBREEnIHx8IHdpemFyZE1vZG8gPT09ICdQUklNQVJJQScgfHwgaWRTYWxpZGEuaW5jbHVkZXMoJ1BSSU1BUklBJyk7XG5cbiAgICAgICAgICBsZXQgbmV3QWxpbWVudGFkb1BvciA9IGFsaW1lbnRhZG9Qb3I7XG4gICAgICAgICAgaWYgKGlzRW50cmFkYU9yUHJpbWFyaWEgJiYgdXBkYXRlZC5lcXVpcG8pIHtcbiAgICAgICAgICAgIG5ld0FsaW1lbnRhZG9Qb3IgPSB1cGRhdGVkLmVxdWlwbztcbiAgICAgICAgICAgIHNldEFsaW1lbnRhZG9Qb3IodXBkYXRlZC5lcXVpcG8pO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGxldCBuZXdEdCA9IHsgLi4uZHQgfTtcblxuICAgICAgICAgIC8vIDEuIFRyYW5zZm9ybWFkb3IgQWNvbWV0aWRhcyB5IHRlbnNpb25lc1xuICAgICAgICAgIGlmICh0aXBvRWxlbWVudG8gPT09ICdUUkFOU0ZPUk1BRE9SJykge1xuICAgICAgICAgICAgY29uc3Qgc2VjY2lvbktleSA9IGlzRW50cmFkYU9yUHJpbWFyaWEgPyAncHJpbWFyaWEnIDogJ3NlY3VuZGFyaWEnO1xuICAgICAgICAgICAgY29uc3QgcHJldkFjID0gZHQuYWNvbWV0aWRhcz8uW3NlY2Npb25LZXldIHx8IHt9O1xuXG4gICAgICAgICAgICBuZXdEdCA9IHtcbiAgICAgICAgICAgICAgLi4ubmV3RHQsXG4gICAgICAgICAgICAgIGFjb21ldGlkYXM6IHtcbiAgICAgICAgICAgICAgICAuLi4obmV3RHQuYWNvbWV0aWRhcyB8fCB7fSksXG4gICAgICAgICAgICAgICAgW3NlY2Npb25LZXldOiB7XG4gICAgICAgICAgICAgICAgICAuLi5wcmV2QWMsXG4gICAgICAgICAgICAgICAgICBjYWxpYnJlOiB1cGRhdGVkLmNvbmR1Y3RvciB8fCBwcmV2QWMuY2FsaWJyZSB8fCAnJyxcbiAgICAgICAgICAgICAgICAgIGZ1c2libGU6IHVwZGF0ZWQuZGV0YWxsZXNUZWNuaWNvcz8uZnVzaWJsZU1UIHx8IHByZXZBYy5mdXNpYmxlIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgcGFyYXJyYXlvOiB1cGRhdGVkLmRldGFsbGVzVGVjbmljb3M/LnBhcmFycmF5b3MgfHwgcHJldkFjLnBhcmFycmF5byB8fCAnJyxcbiAgICAgICAgICAgICAgICAgIG9ic2VydmFjaW9uZXM6IHVwZGF0ZWQuZXF1aXBvIHx8IHByZXZBYy5vYnNlcnZhY2lvbmVzIHx8ICcnLFxuICAgICAgICAgICAgICAgICAgLi4uKGlzRW50cmFkYU9yUHJpbWFyaWEgJiYgdXBkYXRlZC5lcXVpcG8/LmluY2x1ZGVzKCdQT1NURScpID8geyBhZXJlYTogdHJ1ZSB9IDoge30pXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICBpZiAodXBkYXRlZC5kZXRhbGxlc1RlY25pY29zPy5uaXZlbE1UKSB7XG4gICAgICAgICAgICAgIG5ld0R0LnRlbnNpb25QcmltYXJpYSA9IHVwZGF0ZWQuZGV0YWxsZXNUZWNuaWNvcy5uaXZlbE1UO1xuICAgICAgICAgICAgICBuZXdEdC52b2x0YWplUHJpbWFyaW8gPSB1cGRhdGVkLmRldGFsbGVzVGVjbmljb3Mubml2ZWxNVDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh1cGRhdGVkLmRldGFsbGVzVGVjbmljb3M/LnRlbnNpb25TZWN1bmRhcmlhKSB7XG4gICAgICAgICAgICAgIG5ld0R0LnRlbnNpb25TZWN1bmRhcmlhID0gdXBkYXRlZC5kZXRhbGxlc1RlY25pY29zLnRlbnNpb25TZWN1bmRhcmlhO1xuICAgICAgICAgICAgICBuZXdEdC52b2x0YWplU2VjdW5kYXJpbyA9IHVwZGF0ZWQuZGV0YWxsZXNUZWNuaWNvcy50ZW5zaW9uU2VjdW5kYXJpYTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyAyLiBHZW5lcmFkb3IgLyBQbGFudGEgRWzDqWN0cmljYVxuICAgICAgICAgIGlmICh0aXBvRWxlbWVudG8gPT09ICdHRU5FUkFET1InKSB7XG4gICAgICAgICAgICBpZiAodXBkYXRlZC5icmVha2VyPy5hbXApIG5ld0R0LmFtcGVyYWplID0gdXBkYXRlZC5icmVha2VyLmFtcDtcbiAgICAgICAgICAgIGlmICh1cGRhdGVkLmRldGFsbGVzVGVjbmljb3M/LnBvdGVuY2lhS3ZhS3cpIG5ld0R0LnBvdGVuY2lhS3ZhID0gdXBkYXRlZC5kZXRhbGxlc1RlY25pY29zLnBvdGVuY2lhS3ZhS3c7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gMy4gVHJhbnNmZXIgKEFUUylcbiAgICAgICAgICBpZiAodGlwb0VsZW1lbnRvID09PSAnVFJBTlNGRVInKSB7XG4gICAgICAgICAgICBpZiAoaWRTYWxpZGEuaW5jbHVkZXMoJ0FUU19HRU4xJykpIHtcbiAgICAgICAgICAgICAgbmV3RHQuYWxpbWVudGFjaW9uR2VuZXJhZG9yMSA9IHVwZGF0ZWQuY29uZHVjdG9yIHx8IHVwZGF0ZWQuZXF1aXBvIHx8IG5ld0R0LmFsaW1lbnRhY2lvbkdlbmVyYWRvcjE7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGlkU2FsaWRhLmluY2x1ZGVzKCdBVFNfR0VOMicpKSB7XG4gICAgICAgICAgICAgIG5ld0R0LmFsaW1lbnRhY2lvbkdlbmVyYWRvcjIgPSB1cGRhdGVkLmNvbmR1Y3RvciB8fCB1cGRhdGVkLmVxdWlwbyB8fCBuZXdEdC5hbGltZW50YWNpb25HZW5lcmFkb3IyO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChpZFNhbGlkYS5pbmNsdWRlcygnQVRTX0NBUkdBJykpIHtcbiAgICAgICAgICAgICAgbmV3RHQuY2FyZ2EgPSB1cGRhdGVkLmNvbmR1Y3RvciB8fCB1cGRhdGVkLmVxdWlwbyB8fCBuZXdEdC5jYXJnYTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBNZXJnZSBhZGRpdGlvbmFsIHRlY2huaWNhbCBkZXRhaWxzXG4gICAgICAgICAgaWYgKHVwZGF0ZWQuZGV0YWxsZXNUZWNuaWNvcykge1xuICAgICAgICAgICAgbmV3RHQgPSB7IC4uLm5ld0R0LCAuLi51cGRhdGVkLmRldGFsbGVzVGVjbmljb3MgfTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBzZXREdChuZXdEdCk7XG5cbiAgICAgICAgICAvLyBQZXJzaXN0aXIgaW5tZWRpYXRhbWVudGUgZW4gZWwgU3RvcmVcbiAgICAgICAgICBpZiAob25VcGRhdGUpIHtcbiAgICAgICAgICAgIG9uVXBkYXRlKHtcbiAgICAgICAgICAgICAgLi4uZWxlbWVudG9EYXRhLFxuICAgICAgICAgICAgICBhbGltZW50YWRvUG9yOiBuZXdBbGltZW50YWRvUG9yLFxuICAgICAgICAgICAgICBkYXRvc1RlY25pY29zOiBuZXdEdFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gRWxlbWVudG8gcHJvdmlzaW9uYWwgcGVuZGllbnRlXG4gICAgICAgICAgaWYgKHVwZGF0ZWQudGlwb0Rlc3Rpbm8gPT09ICdTVUJfVEFCTEVST19QRU5ESUVOVEUnICYmIGVsZW1lbnRvRGF0YT8ucHJveWVjdG9JZCkge1xuICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdQcm92SWQgPSB1cGRhdGVkLmVsZW1lbnRvRGVzdGlub0lkIHx8IHVwZGF0ZWQudmluY3VsYWRvSWQ7XG4gICAgICAgICAgICBpZiAoIWV4aXN0aW5nUHJvdklkKSB7XG4gICAgICAgICAgICAgIGNyZWFyRWxlbWVudG9Qcm92aXNpb25hbChlbGVtZW50b0RhdGEucHJveWVjdG9JZCwge1xuICAgICAgICAgICAgICAgIG5vbWJyZTogdXBkYXRlZC5lcXVpcG8gJiYgdXBkYXRlZC5lcXVpcG8gIT09ICdSRVNFUlZBIChQZW5kaWVudGUgcG9yIENyZWFyKScgPyB1cGRhdGVkLmVxdWlwbyA6IGBTdWItVGFibGVybyBBbGltZW50YWRvICgke2lkU2FsaWRhfSlgLFxuICAgICAgICAgICAgICAgIHRpcG9FbGVtZW50bzogJ1RBQkxFUk8nLFxuICAgICAgICAgICAgICAgIGNpcmN1aXRvT3JpZ2VuOiBpZFNhbGlkYVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH19XG4gICAgICAvPlxuXG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=