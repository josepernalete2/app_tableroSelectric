import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ModalConfirmacion.jsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { AlertTriangle, Trash2, Info, AlertCircle, X } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalConfirmacion.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
/**
* ModalConfirmacion: Componente visual reutilizable para diálogos modales
* de confirmación y alerta estilizados con Tailwind CSS.
*/
export const ModalConfirmacion = ({ isOpen, title, message, type = "danger", confirmText = "Confirmar", cancelText = "Cancelar", isAlert = false, onConfirm, onCancel }) => {
	_s();
	const confirmButtonRef = useRef(null);
	useEffect(() => {
		if (isOpen) {
			// Auto-focus en el botón principal
			const timer = setTimeout(() => {
				confirmButtonRef.current?.focus();
			}, 50);
			return () => clearTimeout(timer);
		}
	}, [isOpen]);
	// Manejo de teclado (Escape y Enter)
	useEffect(() => {
		if (!isOpen) return;
		const handleKeyDown = (e) => {
			if (e.key === "Escape") {
				e.preventDefault();
				onCancel?.();
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [isOpen, onCancel]);
	if (!isOpen) return null;
	// Configuración de estilos según el tipo
	const getTypeConfig = () => {
		switch (type) {
			case "danger": return {
				icon: Trash2,
				iconBg: "bg-rose-500/10 text-rose-500 border-rose-500/20",
				confirmBtn: "bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/30 focus:ring-rose-500",
				defaultTitle: "Confirmar eliminación"
			};
			case "warning": return {
				icon: AlertTriangle,
				iconBg: "bg-amber-500/10 text-amber-500 border-amber-500/20",
				confirmBtn: "bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold shadow-amber-900/30 focus:ring-amber-500",
				defaultTitle: "Atención requerida"
			};
			case "info":
			default: return {
				icon: Info,
				iconBg: "bg-blue-500/10 text-blue-500 border-blue-500/20",
				confirmBtn: "bg-blue-600 hover:bg-blue-500 text-white shadow-blue-900/30 focus:ring-blue-500",
				defaultTitle: "Información"
			};
		}
	};
	const config = getTypeConfig();
	const IconComponent = config.icon;
	const modalTitle = title || config.defaultTitle;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fade-in no-print",
		onClick: (e) => {
			if (e.target === e.currentTarget) onCancel?.();
		},
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden transition-all transform animate-scale-in",
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "modal-confirm-title",
			children: [/* @__PURE__ */ _jsxDEV("button", {
				onClick: onCancel,
				className: "absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer",
				title: "Cerrar",
				children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "p-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-start gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: `shrink-0 w-11 h-11 rounded-2xl flex items-center justify-center border shadow-xs ${config.iconBg}`,
						children: /* @__PURE__ */ _jsxDEV(IconComponent, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex-1 min-w-0 pr-4",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							id: "modal-confirm-title",
							className: "text-base font-bold text-slate-900 dark:text-slate-100 leading-snug",
							children: modalTitle
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed break-words whitespace-pre-line",
							children: message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-6 flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800/80",
					children: [!isAlert && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: onCancel,
						className: "px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all cursor-pointer",
						children: cancelText
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						ref: confirmButtonRef,
						type: "button",
						onClick: onConfirm,
						className: `px-5 py-2 text-xs font-bold rounded-xl shadow-md transition-all active:scale-95 focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-slate-900 cursor-pointer ${config.confirmBtn}`,
						children: confirmText
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 126,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 87,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 81,
		columnNumber: 5
	}, this);
};
_s(ModalConfirmacion, "OQB3tK7efEDROQaNi+Dx2TMQslg=");
_c = ModalConfirmacion;
export default ModalConfirmacion;
var _c;
$RefreshReg$(_c, "ModalConfirmacion");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ModalConfirmacion.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalConfirmacion.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalConfirmacion.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalConfirmacion.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsY0FBYztBQUN6QyxTQUFTLGVBQWUsUUFBUSxNQUFNLGFBQWEsU0FBUzs7Ozs7Ozs7QUFNNUQsT0FBTyxNQUFNLHFCQUFxQixFQUNoQyxRQUNBLE9BQ0EsU0FDQSxPQUFPLFVBQ1AsY0FBYyxhQUNkLGFBQWEsWUFDYixVQUFVLE9BQ1YsV0FDQSxlQUNJOztDQUNKLE1BQU0sbUJBQW1CLE9BQU8sSUFBSTtDQUVwQyxnQkFBZ0I7RUFDZCxJQUFJLFFBQVE7O0dBRVYsTUFBTSxRQUFRLGlCQUFpQjtJQUM3QixpQkFBaUIsU0FBUyxNQUFNO0dBQ2xDLEdBQUcsRUFBRTtHQUNMLGFBQWEsYUFBYSxLQUFLO0VBQ2pDO0NBQ0YsR0FBRyxDQUFDLE1BQU0sQ0FBQzs7Q0FHWCxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsUUFBUTtFQUViLE1BQU0saUJBQWlCLE1BQU07R0FDM0IsSUFBSSxFQUFFLFFBQVEsVUFBVTtJQUN0QixFQUFFLGVBQWU7SUFDakIsV0FBVztHQUNiO0VBQ0Y7RUFFQSxPQUFPLGlCQUFpQixXQUFXLGFBQWE7RUFDaEQsYUFBYSxPQUFPLG9CQUFvQixXQUFXLGFBQWE7Q0FDbEUsR0FBRyxDQUFDLFFBQVEsUUFBUSxDQUFDO0NBRXJCLElBQUksQ0FBQyxRQUFRLE9BQU87O0NBR3BCLE1BQU0sc0JBQXNCO0VBQzFCLFFBQVEsTUFBUjtHQUNFLEtBQUssVUFDSCxPQUFPO0lBQ0wsTUFBTTtJQUNOLFFBQVE7SUFDUixZQUFZO0lBQ1osY0FBYztHQUNoQjtHQUNGLEtBQUssV0FDSCxPQUFPO0lBQ0wsTUFBTTtJQUNOLFFBQVE7SUFDUixZQUFZO0lBQ1osY0FBYztHQUNoQjtHQUNGLEtBQUs7R0FDTCxTQUNFLE9BQU87SUFDTCxNQUFNO0lBQ04sUUFBUTtJQUNSLFlBQVk7SUFDWixjQUFjO0dBQ2hCO0VBQ0o7Q0FDRjtDQUVBLE1BQU0sU0FBUyxjQUFjO0NBQzdCLE1BQU0sZ0JBQWdCLE9BQU87Q0FDN0IsTUFBTSxhQUFhLFNBQVMsT0FBTztDQUVuQyxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxXQUFVO0VBQ1YsVUFBVSxNQUFNO0dBQ2QsSUFBSSxFQUFFLFdBQVcsRUFBRSxlQUFlLFdBQVc7RUFDL0M7WUFFQSx3QkFBQyxPQUFEO0dBQ0UsV0FBVTtHQUNWLE1BQUs7R0FDTCxjQUFXO0dBQ1gsbUJBQWdCO2FBSmxCLENBT0Usd0JBQUMsVUFBRDtJQUNFLFNBQVM7SUFDVCxXQUFVO0lBQ1YsT0FBTTtjQUVOLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0dBQ2xCOzs7O2FBRVIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FFRSx3QkFBQyxPQUFEO01BQ0UsV0FBVyxvRkFBb0YsT0FBTztnQkFFdEcsd0JBQUMsZUFBRCxFQUFlLFdBQVUsVUFBVzs7Ozs7S0FDakM7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FDRSxJQUFHO09BQ0gsV0FBVTtpQkFFVDtNQUNDOzs7O2dCQUNKLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaO01BQ0U7Ozs7Y0FDRjs7Ozs7YUFDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0csQ0FBQyxXQUNBLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsU0FBUztNQUNULFdBQVU7Z0JBRVQ7S0FDSzs7OztlQUVWLHdCQUFDLFVBQUQ7TUFDRSxLQUFLO01BQ0wsTUFBSztNQUNMLFNBQVM7TUFDVCxXQUFXLHVMQUF1TCxPQUFPO2dCQUV4TTtLQUNLOzs7O2FBQ0w7Ozs7O1lBQ0Y7Ozs7O1dBQ0Y7Ozs7OztDQUNGOzs7OztBQUVUOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1vZGFsQ29uZmlybWFjaW9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBBbGVydFRyaWFuZ2xlLCBUcmFzaDIsIEluZm8sIEFsZXJ0Q2lyY2xlLCBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuLyoqXG4gKiBNb2RhbENvbmZpcm1hY2lvbjogQ29tcG9uZW50ZSB2aXN1YWwgcmV1dGlsaXphYmxlIHBhcmEgZGnDoWxvZ29zIG1vZGFsZXNcbiAqIGRlIGNvbmZpcm1hY2nDs24geSBhbGVydGEgZXN0aWxpemFkb3MgY29uIFRhaWx3aW5kIENTUy5cbiAqL1xuZXhwb3J0IGNvbnN0IE1vZGFsQ29uZmlybWFjaW9uID0gKHtcbiAgaXNPcGVuLFxuICB0aXRsZSxcbiAgbWVzc2FnZSxcbiAgdHlwZSA9ICdkYW5nZXInLFxuICBjb25maXJtVGV4dCA9ICdDb25maXJtYXInLFxuICBjYW5jZWxUZXh0ID0gJ0NhbmNlbGFyJyxcbiAgaXNBbGVydCA9IGZhbHNlLFxuICBvbkNvbmZpcm0sXG4gIG9uQ2FuY2VsLFxufSkgPT4ge1xuICBjb25zdCBjb25maXJtQnV0dG9uUmVmID0gdXNlUmVmKG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzT3Blbikge1xuICAgICAgLy8gQXV0by1mb2N1cyBlbiBlbCBib3TDs24gcHJpbmNpcGFsXG4gICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBjb25maXJtQnV0dG9uUmVmLmN1cnJlbnQ/LmZvY3VzKCk7XG4gICAgICB9LCA1MCk7XG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICB9XG4gIH0sIFtpc09wZW5dKTtcblxuICAvLyBNYW5lam8gZGUgdGVjbGFkbyAoRXNjYXBlIHkgRW50ZXIpXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFpc09wZW4pIHJldHVybjtcblxuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZSkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIG9uQ2FuY2VsPy4oKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duKTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duKTtcbiAgfSwgW2lzT3Blbiwgb25DYW5jZWxdKTtcblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgLy8gQ29uZmlndXJhY2nDs24gZGUgZXN0aWxvcyBzZWfDum4gZWwgdGlwb1xuICBjb25zdCBnZXRUeXBlQ29uZmlnID0gKCkgPT4ge1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSAnZGFuZ2VyJzpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBpY29uOiBUcmFzaDIsXG4gICAgICAgICAgaWNvbkJnOiAnYmctcm9zZS01MDAvMTAgdGV4dC1yb3NlLTUwMCBib3JkZXItcm9zZS01MDAvMjAnLFxuICAgICAgICAgIGNvbmZpcm1CdG46ICdiZy1yb3NlLTYwMCBob3ZlcjpiZy1yb3NlLTUwMCB0ZXh0LXdoaXRlIHNoYWRvdy1yb3NlLTkwMC8zMCBmb2N1czpyaW5nLXJvc2UtNTAwJyxcbiAgICAgICAgICBkZWZhdWx0VGl0bGU6ICdDb25maXJtYXIgZWxpbWluYWNpw7NuJyxcbiAgICAgICAgfTtcbiAgICAgIGNhc2UgJ3dhcm5pbmcnOlxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGljb246IEFsZXJ0VHJpYW5nbGUsXG4gICAgICAgICAgaWNvbkJnOiAnYmctYW1iZXItNTAwLzEwIHRleHQtYW1iZXItNTAwIGJvcmRlci1hbWJlci01MDAvMjAnLFxuICAgICAgICAgIGNvbmZpcm1CdG46ICdiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCBzaGFkb3ctYW1iZXItOTAwLzMwIGZvY3VzOnJpbmctYW1iZXItNTAwJyxcbiAgICAgICAgICBkZWZhdWx0VGl0bGU6ICdBdGVuY2nDs24gcmVxdWVyaWRhJyxcbiAgICAgICAgfTtcbiAgICAgIGNhc2UgJ2luZm8nOlxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBpY29uOiBJbmZvLFxuICAgICAgICAgIGljb25CZzogJ2JnLWJsdWUtNTAwLzEwIHRleHQtYmx1ZS01MDAgYm9yZGVyLWJsdWUtNTAwLzIwJyxcbiAgICAgICAgICBjb25maXJtQnRuOiAnYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MDAgdGV4dC13aGl0ZSBzaGFkb3ctYmx1ZS05MDAvMzAgZm9jdXM6cmluZy1ibHVlLTUwMCcsXG4gICAgICAgICAgZGVmYXVsdFRpdGxlOiAnSW5mb3JtYWNpw7NuJyxcbiAgICAgICAgfTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgY29uZmlnID0gZ2V0VHlwZUNvbmZpZygpO1xuICBjb25zdCBJY29uQ29tcG9uZW50ID0gY29uZmlnLmljb247XG4gIGNvbnN0IG1vZGFsVGl0bGUgPSB0aXRsZSB8fCBjb25maWcuZGVmYXVsdFRpdGxlO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVsxMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1zbGF0ZS05NTAvNzAgYmFja2Ryb3AtYmx1ci14cyBhbmltYXRlLWZhZGUtaW4gbm8tcHJpbnRcIlxuICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgaWYgKGUudGFyZ2V0ID09PSBlLmN1cnJlbnRUYXJnZXQpIG9uQ2FuY2VsPy4oKTtcbiAgICAgIH19XG4gICAgPlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctbWQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgb3ZlcmZsb3ctaGlkZGVuIHRyYW5zaXRpb24tYWxsIHRyYW5zZm9ybSBhbmltYXRlLXNjYWxlLWluXCJcbiAgICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwibW9kYWwtY29uZmlybS10aXRsZVwiXG4gICAgICA+XG4gICAgICAgIHsvKiBCb3TDs24gY2VycmFyIFggKi99XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvbkNhbmNlbH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IHAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgIHRpdGxlPVwiQ2VycmFyXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNFwiPlxuICAgICAgICAgICAgey8qIEljb25vIGNvbiBiYWRnZSB0ZW3DoXRpY28gKi99XG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHNocmluay0wIHctMTEgaC0xMSByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXIgc2hhZG93LXhzICR7Y29uZmlnLmljb25CZ31gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8SWNvbkNvbXBvbmVudCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ29udGVuaWRvIHRleHR1YWwgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wIHByLTRcIj5cbiAgICAgICAgICAgICAgPGgzXG4gICAgICAgICAgICAgICAgaWQ9XCJtb2RhbC1jb25maXJtLXRpdGxlXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgbGVhZGluZy1zbnVnXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHttb2RhbFRpdGxlfVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZCBicmVhay13b3JkcyB3aGl0ZXNwYWNlLXByZS1saW5lXCI+XG4gICAgICAgICAgICAgICAge21lc3NhZ2V9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQWNjaW9uZXMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0zIHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAvODBcIj5cbiAgICAgICAgICAgIHshaXNBbGVydCAmJiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNhbmNlbH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2NhbmNlbFRleHR9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgcmVmPXtjb25maXJtQnV0dG9uUmVmfVxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17b25Db25maXJtfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC01IHB5LTIgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLTk1IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1vZmZzZXQtMiBkYXJrOmZvY3VzOnJpbmctb2Zmc2V0LXNsYXRlLTkwMCBjdXJzb3ItcG9pbnRlciAke2NvbmZpZy5jb25maXJtQnRufWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtjb25maXJtVGV4dH1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgTW9kYWxDb25maXJtYWNpb247XG4iXX0=