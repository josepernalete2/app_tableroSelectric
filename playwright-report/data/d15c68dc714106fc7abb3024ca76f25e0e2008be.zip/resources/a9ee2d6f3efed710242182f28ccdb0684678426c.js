const localforage = __vite__cjsImport2_localforage;import { create } from "/node_modules/.vite/deps/zustand.js?v=f49807c8";
import { persist } from "/node_modules/.vite/deps/zustand_middleware.js?v=f49807c8";
import __vite__cjsImport2_localforage from "/node_modules/.vite/deps/localforage.js?v=f49807c8";
import { API_BASE_URL } from "/src/utils/api.js";
import { initialTablerosData } from "/src/data/mockTableros.js";
// Configurar localforage
localforage.config({
	name: "app-tableros-electricos",
	storeName: "inspecciones_store"
});
export const PREFIX_MAP = {
	TABLERO: "TAB",
	PUNTO_SUMINISTRO: "SUM",
	PUNTO_MEDICION: "PM",
	SUBESTACION: "SUB",
	AMBIENTAL_FISICA: "AMB",
	TERMOGRAFICA: "TER",
	SISTEMA_ATERRAMIENTO: "PAT",
	TANQUE_COMBUSTIBLE: "TK",
	CCM: "CCM",
	TRANSFORMADOR: "TRAFO",
	GENERADOR: "GEN",
	TRANSFER: "ATS",
	PUESTA_TIERRA: "PAT",
	BANCO_CONDENSADOR: "BC",
	OTRO: "OTR"
};
export const cleanElementName = (nombre, id) => {
	if (!nombre) return id || "";
	let cleanName = nombre.trim();
	if (id) {
		if (cleanName.startsWith(`${id} - `)) {
			cleanName = cleanName.substring(id.length + 3);
		} else if (cleanName.startsWith(`${id}: `)) {
			cleanName = cleanName.substring(id.length + 2);
		}
		const idPattern = new RegExp(`\\s*\\(ID:\\s*${id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\)`, "gi");
		cleanName = cleanName.replace(idPattern, "").trim();
	}
	return cleanName || id;
};
export const formatElementTitleWithId = (nombre, id) => {
	return cleanElementName(nombre, id);
};
export const getNextElementId = (tipoElemento, state = {}) => {
	const prefix = PREFIX_MAP[tipoElemento || "TABLERO"] || "ELM";
	let maxNum = 0;
	const checkItem = (item) => {
		if (item && item.id && typeof item.id === "string" && item.id.startsWith(`${prefix}-`)) {
			const parts = item.id.split("-");
			const num = parseInt(parts[parts.length - 1], 10);
			if (!isNaN(num) && num > maxNum) maxNum = num;
		}
	};
	(state.companies || []).forEach((c) => {
		(c.elementosUnifilares || []).forEach(checkItem);
		(c.proyectos || []).forEach((p) => {
			(p.elementosUnifilares || p.tableros || []).forEach(checkItem);
			(p.inspeccionesSubestacion || p.subestaciones || []).forEach(checkItem);
			(p.puntosMedicion || []).forEach(checkItem);
			(p.ccmList || []).forEach(checkItem);
		});
	});
	(state.elementosLocales || []).forEach(checkItem);
	(state.subestacionesLocales || []).forEach(checkItem);
	(state.puntosMedicionLocales || []).forEach(checkItem);
	(state.ccmLocales || []).forEach(checkItem);
	return `${prefix}-${maxNum + 1}`;
};
// Almacenamiento personalizado para localforage (soporta objetos Blob binarios)
const localForageStorage = {
	getItem: async (name) => {
		const value = await localforage.getItem(name);
		return value;
	},
	setItem: async (name, value) => {
		await localforage.setItem(name, value);
	},
	removeItem: async (name) => {
		await localforage.removeItem(name);
	}
};
const initialCompanies = [{
	id: "c-1",
	nombre: "Clínica Valentina Canabal",
	proyectos: [{
		id: "p-1",
		nombre: "Proyecto Diagrama Unifilar y Tableros 2025",
		descripcion: "Estudio de transformadores, generadores, tableros y malla de puesta a tierra.",
		elementosUnifilares: [
			{
				id: "TAB-1",
				nombre: "TAB-1 - Tablero Principal (No. 20)",
				tipoElemento: "TABLERO",
				ubicacion: "SOTANO SALA DE TABLEROS",
				alimentadoPor: "ATS SOTANO (TRANSFERENCIA AUTOMATICA) transferecia 580",
				foto: null,
				fotoBlob: null,
				observacionesGenerales: "SALEN ACOMETIDAS 1 X 500 Y 1X250 MCM DE LA BARRA PARTE INFERIOR. LA ACOMETIDA 250 MCM VA A CAJA CON UN BREAKER AL LADO DEL TABLERO PRINCIPAL. INTERRUPTOR EATON, Ki400, 350 A. SALEN UNA ACOMETIDA 4/0 QUE ALIMENTA TRANSFERENCIA 160. LA ACOMETIDA 500 MCM VA A UNA CAJA AL LADO DEL TABLERO PRINCIPAL. INTERRUPTOR ABB, TIPO 6520, 400 A, SALEN 2X500 Y ALIMENTAN TABLERO EN PRIMER PISO.",
				datosTecnicos: {
					maxPoles: 30,
					tipoTablero: "SUPERFICIAL",
					voltajeAcometida: "211.5 / 207.4 / 208.6 V",
					barrasPrincipales: {
						ia: "",
						ib: "",
						ic: ""
					},
					breakerPrincipal: {
						marca: "SIN BREAKER",
						tipo: "",
						amp: ""
					},
					voltaje: {
						va: "211,5",
						vb: "207,4",
						vc: "208,6"
					},
					acometida: "3X500 MCM",
					neutroLlegada: {
						calibre: "1X500",
						observaciones: ""
					},
					puestaTierra: {
						calibre: "SOLIDO #4",
						observaciones: "LLEGA SOLIDO #4. BUSCAR TANQUILLA DE MALLA A TIERRA"
					}
				},
				proyectoId: "p-1",
				companyId: "c-1",
				createdAt: new Date().toISOString()
			},
			{
				id: "ATS-1",
				nombre: "ATS-1 - Transferencia 580 Estacionamiento",
				tipoElemento: "TRANSFER",
				ubicacion: "ESTACIONAMIENTO",
				alimentadoPor: "GENERADOR 580 1 + GENERADOR 580 2",
				foto: null,
				fotoBlob: null,
				observacionesGenerales: "TRANSFERENCIA ALIMENTADA POR LOS DOS GENERADORES",
				datosTecnicos: {
					modelo: "DOMOSA",
					tipoTransferencia: "YUYE-YES1 3200/4P",
					amperaje: "3200",
					voltaje: {
						vab: "",
						vac: "",
						vbc: ""
					},
					alimentacionGenerador1: "2(3X500)",
					alimentacionGenerador2: "2(3X500)",
					carga: "2(3X500)",
					neutro: "500",
					tierra: "NO"
				},
				proyectoId: "p-1",
				companyId: "c-1",
				createdAt: new Date().toISOString()
			},
			{
				id: "ATS-2",
				nombre: "ATS-2 - Transferencia 580 Sótano Sala Técnica",
				tipoElemento: "TRANSFER",
				ubicacion: "SOTANO SALA TECNICA",
				alimentadoPor: "TRANSFERENCIA DOMOSA + CORPOELEC",
				foto: null,
				fotoBlob: null,
				observacionesGenerales: "PASA DIRECTAMENTE AL TABLERO .",
				datosTecnicos: {
					modelo: "NO TIENE",
					tipoTransferencia: "NO TIENE",
					amperaje: "",
					voltaje: {
						vab: "211",
						vac: "208",
						vbc: "209"
					},
					alimentacionCorpoelec: "3X500",
					alimentacionTransfDomosa: "2X500",
					carga: "3X500",
					neutro: "500",
					tierra: "NO"
				},
				proyectoId: "p-1",
				companyId: "c-1",
				createdAt: new Date().toISOString()
			},
			{
				id: "GEN-1",
				nombre: "GEN-1 - Generador No. 1 DOMOSA 580 KVA",
				tipoElemento: "GENERADOR",
				ubicacion: "ESTACIONAMIENTO",
				alimentadoPor: "TRANSFERENCIA DOMOSA EN ESTACIONAMIENTO",
				foto: null,
				fotoBlob: null,
				observacionesGenerales: "Generador No. 1 DOMOSA 580 KVA ubicado en el estacionamiento.",
				datosTecnicos: {
					kva: "580 KVA",
					marca: "DOMOSA",
					fases: "3",
					voltaje: "208 VOL",
					amperaje: "",
					fp: "",
					combustible: "GALONES",
					interruptor: {
						marca: "CHINT",
						tipo: "",
						amp: "1600",
						condFase: "2(3X500)",
						condNeutro: "500"
					}
				},
				proyectoId: "p-1",
				companyId: "c-1",
				createdAt: new Date().toISOString()
			},
			{
				id: "GEN-2",
				nombre: "GEN-2 - Generador No. 2 DOMOSA 580 KVA",
				tipoElemento: "GENERADOR",
				ubicacion: "ESTACIONAMIENTO",
				alimentadoPor: "TRANSFERENCIA DOMOSA EN ESTACIONAMIENTO",
				foto: null,
				fotoBlob: null,
				observacionesGenerales: "Generador No. 2 DOMOSA 580 KVA ubicado en el estacionamiento.",
				datosTecnicos: {
					kva: "580 KVA",
					marca: "DOMOSA",
					fases: "3",
					voltaje: "208 VOL",
					amperaje: "800 AMP",
					fp: "",
					combustible: "GALONES",
					interruptor: {
						marca: "CHINT",
						tipo: "",
						amp: "1600",
						condFase: "2(3X500)",
						condNeutro: "500"
					}
				},
				proyectoId: "p-1",
				companyId: "c-1",
				createdAt: new Date().toISOString()
			}
		],
		inspeccionesSubestacion: [],
		createdAt: new Date().toISOString()
	}]
}, {
	id: "c-2",
	nombre: "Alimentos Polar Planta Turmero",
	proyectos: []
}];
const getInitialUser = () => {
	try {
		const raw = typeof localStorage !== "undefined" ? localStorage.getItem("user") : null;
		return raw ? JSON.parse(raw) : null;
	} catch (e) {
		return null;
	}
};
const getInitialToken = () => {
	try {
		return typeof localStorage !== "undefined" ? localStorage.getItem("token") || null : null;
	} catch (e) {
		return null;
	}
};
export const useStore = create(persist((set, get) => ({
	user: getInitialUser(),
	token: getInitialToken(),
	usersList: [{
		id: "u-1",
		username: "admin1",
		role: "ADMIN"
	}, {
		id: "u-2",
		username: "admin2",
		role: "ADMIN"
	}],
	companies: initialCompanies,
	proyectosLocales: [],
	elementosLocales: [],
	subestacionesLocales: [],
	syncQueue: [],
	socket: null,
	toast: {
		show: false,
		message: "",
		type: "success",
		action: null
	},
	conflictosCircuitos: [],
	isPanelConflictosOpen: false,
	showToast: (message, type = "success", action = null) => set({ toast: {
		show: true,
		message,
		type,
		action
	} }),
	hideToast: () => set((state) => ({ toast: {
		...state.toast,
		show: false
	} })),
	setSocket: (socket) => set({ socket }),
	setPanelConflictosOpen: (isOpen) => set({ isPanelConflictosOpen: isOpen }),
	registrarConflictoCircuito: (conflicto) => set((state) => {
		const nuevoConflicto = {
			id: conflicto.id || `conf_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
			timestamp: new Date().toISOString(),
			resuelto: false,
			...conflicto
		};
		// Evitar duplicados idénticos en cola
		const filtered = (state.conflictosCircuitos || []).filter((c) => !(c.tableroId === nuevoConflicto.tableroId && JSON.stringify(c.polos) === JSON.stringify(nuevoConflicto.polos)));
		return { conflictosCircuitos: [nuevoConflicto, ...filtered] };
	}),
	resolverConflictoCircuito: (id) => set((state) => ({ conflictosCircuitos: (state.conflictosCircuitos || []).filter((c) => c.id !== id) })),
	limpiarConflictosCircuitos: () => set({ conflictosCircuitos: [] }),
	handleAuthError: (status, errorMsg = "") => {
		if (status === 401 || status === 403 || errorMsg?.toLowerCase().includes("expirado") || errorMsg?.toLowerCase().includes("inválido") || errorMsg?.toLowerCase().includes("token")) {
			try {
				if (typeof window !== "undefined") {
					localStorage.removeItem("token");
					localStorage.removeItem("user");
					localStorage.removeItem("usuario");
					sessionStorage.clear();
				}
			} catch (e) {}
			set({
				user: null,
				token: null
			});
			if (typeof window !== "undefined" && window.location.pathname !== "/login") {
				window.location.replace("/login");
			}
		}
	},
	fetchUsersList: async () => {
		try {
			const { token } = get();
			if (!token || token === "mock-offline-token") return;
			const res = await fetch(`${API_BASE_URL}/api/users`, { headers: { ...token ? { "Authorization": `Bearer ${token}` } : {} } });
			if (res.status === 401 || res.status === 403) {
				get().handleAuthError(res.status);
				return;
			}
			const data = await res.json();
			if (data.ok) {
				set({ usersList: data.data });
			}
		} catch (e) {
			console.error("Error al cargar lista de usuarios:", e);
		}
	},
	fetchMessagesList: async (userId) => {
		try {
			const { token } = get();
			if (!token || token === "mock-offline-token") return;
			const res = await fetch(`${API_BASE_URL}/api/messages/${userId}`, { headers: { ...token ? { "Authorization": `Bearer ${token}` } : {} } });
			if (res.status === 401 || res.status === 403) {
				get().handleAuthError(res.status);
				return;
			}
			const data = await res.json();
			if (data.ok) {
				set({ messages: data.data });
			}
		} catch (e) {
			console.error("Error al cargar lista de mensajes:", e);
		}
	},
	cargarDatosServidor: async () => {
		return get().pullInitialData();
	},
	pullInitialData: async () => {
		const { token, user } = get();
		if (!token || !navigator.onLine || token === "mock-offline-token") return;
		try {
			// 1. Intentar descargar datos vía /api/sync/pull
			const res = await fetch(`${API_BASE_URL}/api/sync/pull`, { headers: { "Authorization": `Bearer ${token}` } });
			if (res.status === 401 || res.status === 403) {
				get().handleAuthError(res.status);
				return {
					success: false,
					error: "Token expirado"
				};
			}
			if (res.ok) {
				const data = await res.json();
				if (data.ok && Array.isArray(data.data) && data.data.length > 0) {
					get().importCompanies(data.data);
					return {
						success: true,
						count: data.data.length
					};
				}
			}
			// 2. Fallback: Si es ADMIN y pull no devolvió empresas, intentar export de base de datos
			if (user && user.role === "ADMIN") {
				const resBackup = await fetch(`${API_BASE_URL}/api/backup/export`, { headers: { "Authorization": `Bearer ${token}` } });
				if (resBackup.status === 401 || resBackup.status === 403) {
					get().handleAuthError(resBackup.status);
					return {
						success: false,
						error: "Token expirado"
					};
				}
				if (resBackup.ok) {
					const dataBackup = await resBackup.json();
					if (dataBackup.ok && Array.isArray(dataBackup.data) && dataBackup.data.length > 0) {
						get().importCompanies(dataBackup.data);
						return {
							success: true,
							count: dataBackup.data.length
						};
					}
				}
			}
		} catch (e) {
			console.error("Error al sincronizar datos iniciales desde el servidor:", e);
		}
	},
	login: async (username, password) => {
		const cleanUsername = (username || "").trim();
		let networkFailed = false;
		if (typeof navigator === "undefined" || navigator.onLine) {
			try {
				const res = await fetch(`${API_BASE_URL}/api/login`, {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify({
						username: cleanUsername,
						password
					})
				});
				const data = await res.json().catch(() => ({}));
				if (res.ok && data.ok) {
					// Cachear usuario para soporte offline posterior
					const currentUsers = get().usersList || [];
					const userIndex = currentUsers.findIndex((u) => (u.username || "").toLowerCase() === data.user.username.toLowerCase());
					let updatedUsers = [...currentUsers];
					const userEntry = {
						id: data.user.id,
						username: data.user.username,
						role: data.user.role,
						companyId: data.user.companyId,
						cachedAt: new Date().toISOString()
					};
					if (userIndex >= 0) {
						updatedUsers[userIndex] = {
							...updatedUsers[userIndex],
							...userEntry
						};
					} else {
						updatedUsers.push(userEntry);
					}
					try {
						if (typeof localStorage !== "undefined") {
							localStorage.setItem("user", JSON.stringify(data.user));
							localStorage.setItem("token", data.token);
						}
					} catch (e) {}
					set({
						user: data.user,
						token: data.token,
						usersList: updatedUsers
					});
					get().fetchMessagesList(data.user.id);
					get().fetchUsersList();
					get().pullInitialData();
					return {
						success: true,
						user: data.user
					};
				}
				// Si el servidor respondió con error de credenciales explícito (401, 400, 403)
				if (res.status === 401 || res.status === 400 || res.status === 403) {
					return {
						success: false,
						error: data.error || "Usuario o contraseña incorrectos."
					};
				}
				if (res.status >= 500) {
					return {
						success: false,
						error: data.error || `Error en el servidor (${res.status}). Intente nuevamente.`
					};
				}
			} catch (e) {
				console.warn("⚠️ Error de conexión con el servidor central al iniciar sesión:", e);
				networkFailed = true;
			}
		} else {
			networkFailed = true;
		}
		// Fallback offline: solo si la red falló o el dispositivo está desconectado
		if (networkFailed) {
			const list = get().usersList || [];
			const inputKey = cleanUsername.toLowerCase();
			const found = list.find((u) => {
				const userKey = (u.username || u.email || "").toLowerCase().trim();
				return userKey === inputKey || userKey === "admin1" && inputKey === "admin1@selectric.com" || userKey === "admin1@selectric.com" && inputKey === "admin1";
			});
			if (found) {
				set({
					user: {
						id: found.id,
						username: found.username,
						role: found.role,
						companyId: found.companyId
					},
					token: "mock-offline-token"
				});
				get().pullInitialData();
				return {
					success: true,
					user: found,
					isOffline: true
				};
			}
			return {
				success: false,
				error: "Sin conexión al servidor central. Inicie sesión con internet por primera vez para habilitar el modo offline para este usuario.",
				isNetworkError: true
			};
		}
		return {
			success: false,
			error: "Usuario o contraseña incorrectos."
		};
	},
	logout: () => {
		try {
			if (typeof window !== "undefined") {
				localStorage.removeItem("token");
				localStorage.removeItem("user");
				localStorage.removeItem("usuario");
				sessionStorage.clear();
			}
		} catch (e) {}
		set({
			user: null,
			token: null
		});
		if (typeof window !== "undefined" && window.location.pathname !== "/login") {
			window.location.replace("/login");
		}
	},
	addUser: async (userObj) => {
		const currentUser = get().user;
		if (!currentUser || currentUser.role !== "ADMIN") {
			return {
				success: false,
				error: "Acción permitida únicamente para administradores."
			};
		}
		const usernameLower = userObj.username.toLowerCase().trim();
		const exists = (get().usersList || []).some((u) => (u.username || u.email || "").toLowerCase().trim() === usernameLower);
		if (exists) {
			return {
				success: false,
				error: "Ya existe un usuario con este nombre de usuario."
			};
		}
		const newUser = {
			id: `user-${Date.now()}`,
			username: userObj.username.trim(),
			password: userObj.password,
			role: userObj.role || "WORKER",
			companyId: userObj.role === "CLIENT" ? userObj.companyId : null
		};
		set((state) => ({ usersList: [...state.usersList || [], newUser] }));
		try {
			const { token } = get();
			const res = await fetch(`${API_BASE_URL}/api/users`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					...token ? { "Authorization": `Bearer ${token}` } : {}
				},
				body: JSON.stringify(newUser)
			});
			const data = await res.json();
			if (data.ok) {
				get().fetchUsersList();
			}
		} catch (e) {
			console.error("Error sincronizando nuevo usuario:", e);
		}
		return {
			success: true,
			user: newUser
		};
	},
	updateUser: async (userId, updatedData) => {
		const currentUser = get().user;
		if (!currentUser || currentUser.role !== "ADMIN") {
			return {
				success: false,
				error: "Acción permitida únicamente para administradores."
			};
		}
		const usernameLower = updatedData.username?.toLowerCase().trim();
		const existsOther = (get().usersList || []).some((u) => u.id !== userId && (u.username || u.email || "").toLowerCase().trim() === usernameLower);
		if (existsOther) {
			return {
				success: false,
				error: "Ya existe otro usuario con este nombre de usuario."
			};
		}
		const mergedData = {
			...updatedData,
			companyId: updatedData.role === "CLIENT" ? updatedData.companyId : null
		};
		set((state) => {
			const updatedList = (state.usersList || []).map((u) => {
				if (u.id === userId) {
					return {
						...u,
						...mergedData
					};
				}
				return u;
			});
			const currentLoggedUser = updatedList.find((u) => u.id === state.user?.id);
			return {
				usersList: updatedList,
				user: currentLoggedUser || state.user
			};
		});
		try {
			const { token } = get();
			const res = await fetch(`${API_BASE_URL}/api/users/${userId}`, {
				method: "PUT",
				headers: {
					"Content-Type": "application/json",
					...token ? { "Authorization": `Bearer ${token}` } : {}
				},
				body: JSON.stringify(mergedData)
			});
			const data = await res.json();
			if (data.ok) {
				get().fetchUsersList();
			}
		} catch (e) {
			console.error("Error actualizando usuario en base de datos:", e);
		}
		return { success: true };
	},
	deleteUser: async (userId) => {
		const currentUser = get().user;
		if (!currentUser || currentUser.role !== "ADMIN") {
			return {
				success: false,
				error: "Acción permitida únicamente para administradores."
			};
		}
		const userToDelete = (get().usersList || []).find((u) => u.id === userId);
		if (userToDelete && (userToDelete.username || "").toLowerCase() === "admin1") {
			return {
				success: false,
				error: "El usuario administrador principal (admin1) está protegido y no se puede eliminar."
			};
		}
		if (currentUser.id === userId) {
			return {
				success: false,
				error: "No puedes eliminar tu propia cuenta de usuario activo."
			};
		}
		set((state) => ({ usersList: (state.usersList || []).filter((u) => u.id !== userId) }));
		try {
			const { token } = get();
			const res = await fetch(`${API_BASE_URL}/api/users/${userId}`, {
				method: "DELETE",
				headers: { ...token ? { "Authorization": `Bearer ${token}` } : {} }
			});
			const data = await res.json();
			if (data.ok) {
				get().fetchUsersList();
			}
		} catch (e) {
			console.error("Error eliminando usuario en base de datos:", e);
		}
		return { success: true };
	},
	updateEmpresa: async (companyId, updatedData) => {
		set((state) => ({ companies: state.companies.map((c) => {
			if (c.id === companyId) {
				return {
					...c,
					...updatedData
				};
			}
			return c;
		}) }));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/empresas/${companyId}`, {
					method: "PUT",
					headers: {
						"Content-Type": "application/json",
						...token ? { "Authorization": `Bearer ${token}` } : {}
					},
					body: JSON.stringify(updatedData)
				});
			} catch (e) {
				console.error("Error al actualizar empresa en el servidor:", e);
			}
		}
	},
	updateProyecto: async (companyId, proyectoId, updatedData) => {
		set((state) => ({ companies: state.companies.map((c) => {
			if (c.id === companyId) {
				return {
					...c,
					proyectos: (c.proyectos || []).map((p) => {
						if (p.id === proyectoId) {
							return {
								...p,
								...updatedData
							};
						}
						return p;
					})
				};
			}
			return c;
		}) }));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/proyectos/${proyectoId}`, {
					method: "PUT",
					headers: {
						"Content-Type": "application/json",
						...token ? { "Authorization": `Bearer ${token}` } : {}
					},
					body: JSON.stringify(updatedData)
				});
			} catch (e) {
				console.error("Error al actualizar proyecto en el servidor:", e);
			}
		}
	},
	fetchAlimentadores: async (proyectoId) => {
		if (navigator.onLine) {
			try {
				const { token } = get();
				const res = await fetch(`${API_BASE_URL}/api/alimentadores?proyectoId=${proyectoId}`, { headers: { ...token ? { "Authorization": `Bearer ${token}` } : {} } });
				const data = await res.json();
				if (data.ok) {
					set((state) => ({ companies: state.companies.map((c) => ({
						...c,
						proyectos: (c.proyectos || []).map((p) => {
							if (p.id === proyectoId) {
								return {
									...p,
									alimentadores: data.data
								};
							}
							return p;
						})
					})) }));
				}
			} catch (e) {
				console.error("Error al obtener alimentadores:", e);
			}
		}
	},
	addAlimentador: async (alimentadorData) => {
		const { proyectoId } = alimentadorData;
		const newAlimentador = {
			id: alimentadorData.id || crypto.randomUUID(),
			...alimentadorData
		};
		set((state) => ({ companies: state.companies.map((c) => ({
			...c,
			proyectos: (c.proyectos || []).map((p) => {
				if (p.id === proyectoId) {
					const currentAlims = p.alimentadores || [];
					return {
						...p,
						alimentadores: [...currentAlims, newAlimentador]
					};
				}
				return p;
			})
		})) }));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/alimentadores`, {
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						...token ? { "Authorization": `Bearer ${token}` } : {}
					},
					body: JSON.stringify(newAlimentador)
				});
			} catch (e) {
				console.error("Error al guardar alimentador:", e);
			}
		}
	},
	deleteAlimentador: async (proyectoId, alimentadorId) => {
		set((state) => ({ companies: state.companies.map((c) => ({
			...c,
			proyectos: (c.proyectos || []).map((p) => {
				if (p.id === proyectoId) {
					const currentAlims = p.alimentadores || [];
					return {
						...p,
						alimentadores: currentAlims.filter((a) => a.id !== alimentadorId)
					};
				}
				return p;
			})
		})) }));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/alimentadores/${alimentadorId}`, {
					method: "DELETE",
					headers: { ...token ? { "Authorization": `Bearer ${token}` } : {} }
				});
			} catch (e) {
				console.error("Error al eliminar alimentador:", e);
			}
		}
	},
	updateTableroAlimentador: (proyectoId, tableroId, alimentadorId) => {
		set((state) => {
			const updateElement = (e) => {
				if (e.id === tableroId) {
					return {
						...e,
						datosTecnicos: {
							...e.datosTecnicos,
							alimentadorId
						}
					};
				}
				return e;
			};
			const updatedCompanies = state.companies.map((c) => {
				if (!proyectoId) {
					const list = c.elementosUnifilares || [];
					return {
						...c,
						elementosUnifilares: list.map(updateElement)
					};
				}
				return {
					...c,
					proyectos: (c.proyectos || []).map((p) => {
						if (p.id === proyectoId) {
							const list = p.elementosUnifilares || p.tableros || [];
							return {
								...p,
								elementosUnifilares: list.map(updateElement)
							};
						}
						return p;
					})
				};
			});
			// Obtener el elemento locales para encolar
			const allElements = state.elementosLocales || [];
			const updatedElement = allElements.find((e) => e.id === tableroId);
			let payload = null;
			if (updatedElement) {
				payload = {
					...updatedElement,
					datosTecnicos: {
						...updatedElement.datosTecnicos,
						alimentadorId
					}
				};
			}
			return {
				companies: updatedCompanies,
				elementosLocales: (state.elementosLocales || []).map(updateElement),
				syncQueue: payload ? [...state.syncQueue, {
					id: tableroId,
					tipo: "ELEMENTO_UNIFILAR",
					companyId: updatedElement ? updatedElement.companyId || updatedElement.empresaId : null,
					payload
				}] : state.syncQueue
			};
		});
	},
	addCompany: async (companyData) => {
		const newCompany = {
			id: companyData.id || `company-${Date.now()}`,
			nombre: companyData.nombre,
			rif: companyData.rif,
			direccionFiscal: companyData.direccionFiscal,
			direccion: companyData.direccion || companyData.direccionFiscal || "",
			gerente1Nombre: companyData.gerente1Nombre || null,
			gerente1Telefono: companyData.gerente1Telefono || null,
			gerente1Email: companyData.gerente1Email || null,
			gerente2Nombre: companyData.gerente2Nombre || null,
			gerente2Telefono: companyData.gerente2Telefono || null,
			gerente2Email: companyData.gerente2Email || null,
			proyectos: []
		};
		set((state) => ({ companies: [...state.companies, newCompany] }));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/empresas`, {
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						...token ? { "Authorization": `Bearer ${token}` } : {}
					},
					body: JSON.stringify(newCompany)
				});
			} catch (e) {
				console.error("Error al registrar empresa en el servidor:", e);
			}
		}
	},
	deleteCompany: (companyId) => {
		set((state) => ({ companies: state.companies.filter((c) => c.id !== companyId) }));
	},
	updateProyecto: async (companyId, proyectoId, updatedData) => {
		set((state) => ({
			companies: state.companies.map((c) => {
				if (c.id === companyId) {
					return {
						...c,
						proyectos: (c.proyectos || []).map((p) => {
							if (p.id === proyectoId) {
								return {
									...p,
									...updatedData
								};
							}
							return p;
						})
					};
				}
				return c;
			}),
			proyectosLocales: (state.proyectosLocales || []).map((p) => {
				if (p.id === proyectoId) {
					return {
						...p,
						...updatedData
					};
				}
				return p;
			}),
			syncQueue: [...state.syncQueue, {
				id: proyectoId,
				tipo: "PROYECTO",
				companyId,
				payload: {
					id: proyectoId,
					...updatedData,
					empresaId: companyId
				}
			}]
		}));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/proyectos/${proyectoId}`, {
					method: "PUT",
					headers: {
						"Content-Type": "application/json",
						...token && token !== "mock-offline-token" ? { "Authorization": `Bearer ${token}` } : {}
					},
					body: JSON.stringify(updatedData)
				});
			} catch (e) {
				console.error("Error al actualizar proyecto en el servidor:", e);
			}
		}
	},
	deleteProyecto: async (companyId, proyectoId) => {
		set((state) => ({
			companies: state.companies.map((c) => {
				if (c.id === companyId) {
					return {
						...c,
						proyectos: (c.proyectos || []).filter((p) => p.id !== proyectoId)
					};
				}
				return c;
			}),
			proyectosLocales: (state.proyectosLocales || []).filter((p) => p.id !== proyectoId),
			syncQueue: state.syncQueue.filter((item) => item.id !== proyectoId)
		}));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/proyectos/${proyectoId}`, {
					method: "DELETE",
					headers: { ...token ? { "Authorization": `Bearer ${token}` } : {} }
				});
			} catch (e) {
				console.error("Error al eliminar proyecto del servidor:", e);
			}
		}
	},
	importCompanies: (companiesList) => {
		const enrichedList = companiesList.map((c) => ({
			...c,
			proyectos: (c.proyectos || []).map((p) => ({
				...p,
				elementosUnifilares: p.elementosUnifilares || p.tableros || [],
				inspeccionesSubestacion: p.inspeccionesSubestacion || p.subestaciones || [],
				puntosMedicion: p.puntosMedicion || [],
				ccmList: p.ccmList || []
			}))
		}));
		set({ companies: enrichedList });
	},
	addProyecto: (nombre, descripcion, companyId) => {
		const { companies } = get();
		const company = companies.find((c) => c.id === companyId);
		if (!company) return {
			success: false,
			error: "Empresa no encontrada."
		};
		const uuidId = crypto.randomUUID();
		const nuevoProyecto = {
			id: uuidId,
			nombre,
			descripcion: descripcion || "",
			empresaId: companyId,
			elementosUnifilares: [],
			inspeccionesSubestacion: [],
			puntosMedicion: [],
			ccmList: [],
			createdAt: new Date().toISOString()
		};
		set((state) => ({
			companies: state.companies.map((c) => {
				if (c.id === companyId) {
					return {
						...c,
						proyectos: [nuevoProyecto, ...c.proyectos || []]
					};
				}
				return c;
			}),
			proyectosLocales: [...state.proyectosLocales || [], nuevoProyecto],
			syncQueue: [...state.syncQueue, {
				id: uuidId,
				tipo: "PROYECTO",
				companyId,
				payload: nuevoProyecto
			}]
		}));
		return {
			success: true,
			proyecto: nuevoProyecto
		};
	},
	// LÓGICA DE CREACIÓN ADAPTATIVA DENTRO Y FUERA DE PROYECTO
	addElementoUnifilar: (arg1, arg2) => {
		let proyectoId = typeof arg1 === "string" ? arg1 : arg1?.proyectoId || arg2?.proyectoId;
		const elementoData = typeof arg1 === "string" ? arg2 : arg1;
		const companyId = elementoData?.companyId || elementoData?.empresaId || (typeof arg1 === "string" ? null : arg1?.companyId);
		const { companies } = get();
		let parentCompanyId = companyId;
		let targetProyecto = null;
		if (proyectoId) {
			for (const company of companies) {
				const proj = (company.proyectos || []).find((p) => p.id === proyectoId);
				if (proj) {
					parentCompanyId = company.id;
					targetProyecto = proj;
					break;
				}
			}
		} else {
			// If no proyectoId is given, default to the companyId provided
			if (!parentCompanyId && companies.length > 0) {
				parentCompanyId = companies[0].id;
			}
		}
		if (proyectoId && !targetProyecto) return {
			success: false,
			error: "Proyecto no encontrado en la base de datos."
		};
		let uuidId = elementoData.id;
		if (!uuidId || !uuidId.includes("-")) {
			uuidId = getNextElementId(elementoData.tipoElemento || "TABLERO", get());
		}
		const nombreFinal = elementoData.nombre && elementoData.nombre.trim() ? elementoData.nombre.trim() : uuidId;
		const nuevoElemento = {
			id: uuidId,
			nombre: nombreFinal,
			tipoElemento: elementoData.tipoElemento || "TABLERO",
			ubicacion: elementoData.ubicacion || "Sin ubicación",
			alimentadoPor: elementoData.alimentadoPor || "",
			foto: elementoData.foto || null,
			fotoBlob: elementoData.fotoBlob || null,
			observacionesGenerales: elementoData.observacionesGenerales || "",
			datosTecnicos: elementoData.datosTecnicos || {},
			proyectoId: proyectoId || null,
			empresaId: parentCompanyId,
			createdAt: new Date().toISOString()
		};
		set((state) => ({
			companies: state.companies.map((c) => {
				if (c.id === parentCompanyId) {
					if (proyectoId) {
						return {
							...c,
							proyectos: c.proyectos.map((p) => {
								if (p.id === proyectoId) {
									const elementos = p.elementosUnifilares || p.tableros || [];
									return {
										...p,
										elementosUnifilares: [...elementos, nuevoElemento]
									};
								}
								return p;
							})
						};
					} else {
						const elementosComp = c.elementosUnifilares || [];
						return {
							...c,
							elementosUnifilares: [...elementosComp, nuevoElemento]
						};
					}
				}
				return c;
			}),
			elementosLocales: [...state.elementosLocales || [], nuevoElemento],
			syncQueue: [...state.syncQueue, {
				id: uuidId,
				tipo: "ELEMENTO_UNIFILAR",
				companyId: parentCompanyId,
				payload: nuevoElemento
			}]
		}));
		return {
			success: true,
			elemento: nuevoElemento
		};
	},
	updateElementoUnifilar: (proyectoId, elementoId, updatedData) => {
		set((state) => {
			const updatedCompanies = state.companies.map((c) => {
				if (!proyectoId) {
					const list = c.elementosUnifilares || [];
					return {
						...c,
						elementosUnifilares: list.map((e) => {
							if (e.id === elementoId) {
								return {
									...e,
									...updatedData
								};
							}
							return e;
						})
					};
				}
				return {
					...c,
					proyectos: (c.proyectos || []).map((p) => {
						if (p.id === proyectoId) {
							const list = p.elementosUnifilares || p.tableros || [];
							return {
								...p,
								elementosUnifilares: list.map((e) => {
									if (e.id === elementoId) {
										return {
											...e,
											...updatedData
										};
									}
									return e;
								})
							};
						}
						return p;
					})
				};
			});
			const updatedElementosLocales = (state.elementosLocales || []).map((e) => {
				if (e.id === elementoId) {
					return {
						...e,
						...updatedData
					};
				}
				return e;
			});
			let inQueue = false;
			const updatedSyncQueue = state.syncQueue.map((item) => {
				if (item.id === elementoId && (item.tipo === "ELEMENTO_UNIFILAR" || item.tipo === "TABLERO")) {
					inQueue = true;
					return {
						...item,
						payload: {
							...item.payload,
							...updatedData
						}
					};
				}
				return item;
			});
			if (!inQueue) {
				let updatedElement = updatedElementosLocales.find((e) => e.id === elementoId);
				if (!updatedElement) {
					for (const c of updatedCompanies) {
						const list = proyectoId ? c.proyectos?.find((p) => p.id === proyectoId)?.elementosUnifilares || [] : c.elementosUnifilares || [];
						const found = list.find((e) => e.id === elementoId);
						if (found) {
							updatedElement = found;
							break;
						}
					}
				}
				if (updatedElement) {
					updatedSyncQueue.push({
						id: elementoId,
						tipo: "ELEMENTO_UNIFILAR",
						companyId: updatedElement.empresaId || updatedElement.companyId || state.companies[0]?.id || null,
						payload: updatedElement
					});
				}
			}
			return {
				companies: updatedCompanies,
				elementosLocales: updatedElementosLocales,
				syncQueue: updatedSyncQueue
			};
		});
	},
	deleteElementoUnifilar: async (proyectoId, elementoId) => {
		set((state) => ({
			companies: state.companies.map((c) => {
				if (!proyectoId) {
					const list = c.elementosUnifilares || [];
					return {
						...c,
						elementosUnifilares: list.filter((e) => e.id !== elementoId)
					};
				}
				return {
					...c,
					proyectos: (c.proyectos || []).map((p) => {
						if (p.id === proyectoId) {
							const list = p.elementosUnifilares || p.tableros || [];
							return {
								...p,
								elementosUnifilares: list.filter((e) => e.id !== elementoId)
							};
						}
						return p;
					})
				};
			}),
			elementosLocales: (state.elementosLocales || []).filter((e) => e.id !== elementoId),
			syncQueue: state.syncQueue.filter((item) => item.id !== elementoId)
		}));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/elementos-unifilares/${elementoId}`, {
					method: "DELETE",
					headers: { ...token ? { "Authorization": `Bearer ${token}` } : {} }
				});
			} catch (e) {
				console.error("Error al eliminar elemento unifilar del servidor:", e);
			}
		}
	},
	addTablero: (proyectoId, tableroData) => {
		return get().addElementoUnifilar(proyectoId, {
			...tableroData,
			tipoElemento: "TABLERO",
			datosTecnicos: {
				maxPoles: tableroData.maxPoles || 24,
				barrasPrincipales: tableroData.barrasPrincipales || {
					ia: "0",
					ib: "0",
					ic: "0"
				},
				breakerPrincipal: tableroData.breakerPrincipal || {
					marca: "",
					tipo: "",
					amp: ""
				},
				voltaje: tableroData.voltaje || {
					va: "208",
					vb: "205",
					vc: "205"
				},
				acometida: tableroData.acometida || "",
				circuits: tableroData.circuits || [],
				neutroLlegada: tableroData.neutroLlegada || {
					calibre: "",
					observaciones: ""
				},
				puestaTierra: tableroData.puestaTierra || {
					calibre: "",
					observaciones: ""
				}
			}
		});
	},
	updateTablero: (proyectoId, tableroId, updatedData) => {
		get().updateElementoUnifilar(proyectoId, tableroId, updatedData);
	},
	deleteTablero: (proyectoId, tableroId) => {
		get().deleteElementoUnifilar(proyectoId, tableroId);
	},
	addInspeccionSubestacion: (proyectoId, payload) => {
		const { companies } = get();
		let parentCompanyId = null;
		let targetProyecto = null;
		for (const company of companies) {
			const proj = (company.proyectos || []).find((p) => p.id === proyectoId);
			if (proj) {
				parentCompanyId = company.id;
				targetProyecto = proj;
				break;
			}
		}
		if (!targetProyecto) return {
			success: false,
			error: "Proyecto no encontrado."
		};
		let uuidId = payload.id;
		if (!uuidId || !uuidId.includes("-")) {
			uuidId = getNextElementId("SUBESTACION", get());
		}
		const nombreFinal = payload.nombre && payload.nombre.trim() ? payload.nombre.trim() : uuidId;
		const nuevaSubestacion = {
			...payload,
			id: uuidId,
			nombre: nombreFinal,
			proyectoId,
			empresaId: parentCompanyId,
			tipoPlantilla: "INSPECCION_SUBESTACION",
			createdAt: new Date().toISOString()
		};
		set((state) => ({
			companies: state.companies.map((c) => {
				if (c.id === parentCompanyId) {
					return {
						...c,
						proyectos: c.proyectos.map((p) => {
							if (p.id === proyectoId) {
								const subestaciones = p.inspeccionesSubestacion || p.subestaciones || [];
								return {
									...p,
									inspeccionesSubestacion: [...subestaciones, nuevaSubestacion]
								};
							}
							return p;
						})
					};
				}
				return c;
			}),
			subestacionesLocales: [...state.subestacionesLocales || [], nuevaSubestacion],
			syncQueue: [...state.syncQueue, {
				id: uuidId,
				tipo: "SUBESTACION",
				companyId: parentCompanyId,
				payload: nuevaSubestacion
			}]
		}));
		return {
			success: true,
			subestacion: nuevaSubestacion
		};
	},
	updateSubestacion: (proyectoId, subestacionId, updatedData) => {
		set((state) => {
			const updatedCompanies = state.companies.map((c) => ({
				...c,
				proyectos: (c.proyectos || []).map((p) => {
					if (p.id === proyectoId) {
						const subestaciones = p.inspeccionesSubestacion || p.subestaciones || [];
						return {
							...p,
							inspeccionesSubestacion: subestaciones.map((s) => {
								if (s.id === subestacionId) {
									return {
										...s,
										...updatedData
									};
								}
								return s;
							})
						};
					}
					return p;
				})
			}));
			const updatedSubestacionesLocales = (state.subestacionesLocales || []).map((s) => {
				if (s.id === subestacionId) {
					return {
						...s,
						...updatedData
					};
				}
				return s;
			});
			const updatedSyncQueue = state.syncQueue.map((item) => {
				if (item.id === subestacionId && item.tipo === "SUBESTACION") {
					return {
						...item,
						payload: {
							...item.payload,
							...updatedData
						}
					};
				}
				return item;
			});
			return {
				companies: updatedCompanies,
				subestacionesLocales: updatedSubestacionesLocales,
				syncQueue: updatedSyncQueue
			};
		});
	},
	deleteSubestacion: async (proyectoId, subestacionId) => {
		set((state) => ({
			companies: state.companies.map((c) => ({
				...c,
				proyectos: (c.proyectos || []).map((p) => {
					if (p.id === proyectoId) {
						const subestaciones = p.inspeccionesSubestacion || p.subestaciones || [];
						return {
							...p,
							inspeccionesSubestacion: subestaciones.filter((s) => s.id !== subestacionId)
						};
					}
					return p;
				})
			})),
			subestacionesLocales: (state.subestacionesLocales || []).filter((s) => s.id !== subestacionId),
			syncQueue: state.syncQueue.filter((item) => item.id !== subestacionId)
		}));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/subestaciones/${subestacionId}`, {
					method: "DELETE",
					headers: { ...token ? { "Authorization": `Bearer ${token}` } : {} }
				});
			} catch (e) {
				console.error("Error al eliminar inspección de subestación del servidor:", e);
			}
		}
	},
	addPuntoMedicion: (proyectoId, payload) => {
		const { companies } = get();
		let parentCompanyId = null;
		let targetProyecto = null;
		for (const company of companies) {
			const proj = (company.proyectos || []).find((p) => p.id === proyectoId);
			if (proj) {
				parentCompanyId = company.id;
				targetProyecto = proj;
				break;
			}
		}
		let uuidId = payload.id;
		if (!uuidId || !uuidId.includes("-")) {
			uuidId = getNextElementId("PUNTO_MEDICION", get());
		}
		const nombreFinal = payload.nombre && payload.nombre.trim() ? payload.nombre.trim() : uuidId;
		const nuevoPunto = {
			...payload,
			id: uuidId,
			nombre: nombreFinal,
			proyectoId,
			empresaId: parentCompanyId,
			tipoPlantilla: "PUNTO_MEDICION",
			createdAt: new Date().toISOString()
		};
		set((state) => ({
			companies: state.companies.map((c) => {
				if (c.id === parentCompanyId) {
					return {
						...c,
						proyectos: c.proyectos.map((p) => {
							if (p.id === proyectoId) {
								const puntos = p.puntosMedicion || [];
								return {
									...p,
									puntosMedicion: [...puntos, nuevoPunto]
								};
							}
							return p;
						})
					};
				}
				return c;
			}),
			puntosMedicionLocales: [...state.puntosMedicionLocales || [], nuevoPunto],
			syncQueue: [...state.syncQueue, {
				id: uuidId,
				tipo: "PUNTO_MEDICION",
				companyId: parentCompanyId,
				payload: nuevoPunto
			}]
		}));
		return {
			success: true,
			puntoMedicion: nuevoPunto
		};
	},
	updatePuntoMedicion: (proyectoId, puntoId, updatedData) => {
		set((state) => {
			const updatedCompanies = state.companies.map((c) => ({
				...c,
				elementosUnifilares: (c.elementosUnifilares || []).map((item) => {
					if (item.id === puntoId) {
						return {
							...item,
							...updatedData
						};
					}
					return item;
				}),
				proyectos: (c.proyectos || []).map((p) => {
					const matchesProj = !proyectoId || p.id === proyectoId;
					const puntos = p.puntosMedicion || [];
					const elementos = p.elementosUnifilares || [];
					return {
						...p,
						puntosMedicion: puntos.map((item) => {
							if (item.id === puntoId) {
								return {
									...item,
									...updatedData
								};
							}
							return item;
						}),
						elementosUnifilares: matchesProj ? elementos.map((item) => {
							if (item.id === puntoId) {
								return {
									...item,
									...updatedData
								};
							}
							return item;
						}) : elementos
					};
				})
			}));
			const updatedPuntosLocales = (state.puntosMedicionLocales || []).map((item) => {
				if (item.id === puntoId) {
					return {
						...item,
						...updatedData
					};
				}
				return item;
			});
			const updatedSyncQueue = state.syncQueue.map((item) => {
				if (item.id === puntoId && (item.tipo === "PUNTO_MEDICION" || item.tipo === "ELEMENTO_UNIFILAR")) {
					return {
						...item,
						payload: {
							...item.payload,
							...updatedData
						}
					};
				}
				return item;
			});
			return {
				companies: updatedCompanies,
				puntosMedicionLocales: updatedPuntosLocales,
				syncQueue: updatedSyncQueue
			};
		});
	},
	deletePuntoMedicion: async (proyectoId, puntoId) => {
		set((state) => ({
			companies: state.companies.map((c) => ({
				...c,
				proyectos: (c.proyectos || []).map((p) => {
					if (p.id === proyectoId) {
						const puntos = p.puntosMedicion || [];
						return {
							...p,
							puntosMedicion: puntos.filter((item) => item.id !== puntoId)
						};
					}
					return p;
				})
			})),
			puntosMedicionLocales: (state.puntosMedicionLocales || []).filter((item) => item.id !== puntoId),
			syncQueue: state.syncQueue.filter((item) => item.id !== puntoId)
		}));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/puntos-medicion/${puntoId}`, {
					method: "DELETE",
					headers: { ...token ? { "Authorization": `Bearer ${token}` } : {} }
				});
			} catch (e) {
				console.error("Error al eliminar punto de medición del servidor:", e);
			}
		}
	},
	addCcm: (proyectoId, payload) => {
		const { companies } = get();
		let parentCompanyId = null;
		let targetProyecto = null;
		for (const company of companies) {
			const proj = (company.proyectos || []).find((p) => p.id === proyectoId);
			if (proj) {
				parentCompanyId = company.id;
				targetProyecto = proj;
				break;
			}
		}
		let uuidId = payload.id;
		if (!uuidId || !uuidId.includes("-")) {
			uuidId = getNextElementId("CCM", get());
		}
		const nombreFinal = payload.nombre && payload.nombre.trim() ? payload.nombre.trim() : uuidId;
		const nuevoCcm = {
			...payload,
			id: uuidId,
			nombre: nombreFinal,
			proyectoId,
			empresaId: parentCompanyId,
			tipoPlantilla: "CCM",
			createdAt: new Date().toISOString()
		};
		set((state) => ({
			companies: state.companies.map((c) => {
				if (c.id === parentCompanyId) {
					return {
						...c,
						proyectos: c.proyectos.map((p) => {
							if (p.id === proyectoId) {
								const ccmItems = p.ccmList || [];
								return {
									...p,
									ccmList: [...ccmItems, nuevoCcm]
								};
							}
							return p;
						})
					};
				}
				return c;
			}),
			ccmLocales: [...state.ccmLocales || [], nuevoCcm],
			syncQueue: [...state.syncQueue, {
				id: uuidId,
				tipo: "CCM",
				companyId: parentCompanyId,
				payload: nuevoCcm
			}]
		}));
		return {
			success: true,
			ccm: nuevoCcm
		};
	},
	updateCcm: (proyectoId, ccmId, updatedData) => {
		set((state) => {
			const updatedCompanies = state.companies.map((c) => ({
				...c,
				proyectos: (c.proyectos || []).map((p) => {
					if (p.id === proyectoId) {
						const ccmItems = p.ccmList || [];
						return {
							...p,
							ccmList: ccmItems.map((item) => {
								if (item.id === ccmId) {
									return {
										...item,
										...updatedData
									};
								}
								return item;
							})
						};
					}
					return p;
				})
			}));
			const updatedCcmLocales = (state.ccmLocales || []).map((item) => {
				if (item.id === ccmId) {
					return {
						...item,
						...updatedData
					};
				}
				return item;
			});
			const updatedSyncQueue = state.syncQueue.map((item) => {
				if (item.id === ccmId && item.tipo === "CCM") {
					return {
						...item,
						payload: {
							...item.payload,
							...updatedData
						}
					};
				}
				return item;
			});
			return {
				companies: updatedCompanies,
				ccmLocales: updatedCcmLocales,
				syncQueue: updatedSyncQueue
			};
		});
	},
	deleteCcm: async (proyectoId, ccmId) => {
		set((state) => ({
			companies: state.companies.map((c) => ({
				...c,
				proyectos: (c.proyectos || []).map((p) => {
					if (p.id === proyectoId) {
						const ccmItems = p.ccmList || [];
						return {
							...p,
							ccmList: ccmItems.filter((item) => item.id !== ccmId)
						};
					}
					return p;
				})
			})),
			ccmLocales: (state.ccmLocales || []).filter((item) => item.id !== ccmId),
			syncQueue: state.syncQueue.filter((item) => item.id !== ccmId)
		}));
		if (navigator.onLine) {
			try {
				const { token } = get();
				await fetch(`${API_BASE_URL}/api/ccm/${ccmId}`, {
					method: "DELETE",
					headers: { ...token ? { "Authorization": `Bearer ${token}` } : {} }
				});
			} catch (e) {
				console.error("Error al eliminar CCM del servidor:", e);
			}
		}
	},
	removeFromQueue: (id) => {
		set((state) => ({
			syncQueue: state.syncQueue.filter((item) => item.id !== id),
			proyectosLocales: (state.proyectosLocales || []).filter((p) => p.id !== id),
			elementosLocales: (state.elementosLocales || []).filter((e) => e.id !== id),
			subestacionesLocales: (state.subestacionesLocales || []).filter((s) => s.id !== id)
		}));
	},
	processSyncQueue: async () => {
		const { syncQueue, token } = get();
		if (!token || syncQueue.length === 0) return { success: true };
		try {
			const res = await fetch(`${API_BASE_URL}/api/sync/push`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					...token && token !== "mock-offline-token" ? { "Authorization": `Bearer ${token}` } : {}
				},
				body: JSON.stringify({ mutations: syncQueue.map((item) => ({
					entity: item.tipo,
					id: item.id,
					operation: "CREATE",
					data: item.payload
				})) })
			});
			if (res.status === 401 || res.status === 403) {
				get().handleAuthError(res.status);
				return {
					success: false,
					error: "Token expirado"
				};
			}
			const data = await res.json();
			if (res.ok && data.ok) {
				// Limpiar la cola localmente tras confirmación exitosa
				set({ syncQueue: [] });
				get().pullInitialData();
				get().showToast("Sincronización completada exitosamente", "success");
				return { success: true };
			} else {
				get().showToast("Error en sincronización: " + (data.error || "unknown"), "error");
				return {
					success: false,
					error: data.error
				};
			}
		} catch (e) {
			console.error("Error al procesar cola de sincronización:", e);
			get().showToast("Error de red al sincronizar", "error");
			return {
				success: false,
				error: e.message
			};
		}
	},
	syncPendingData: async () => {
		return get().processSyncQueue();
	},
	backupDatos: async (tipo = "completo") => {
		const { user } = get();
		if (!user) return {
			success: false,
			error: "No ha iniciado sesión"
		};
		try {
			get().showToast("Generando backup " + tipo + "...", "info");
			const res = await fetch(`${API_BASE_URL}/api/backup/local`, {
				method: "POST",
				headers: { "Authorization": `Bearer ${user.token}` },
				body: JSON.stringify({ tipo })
			});
			const data = await res.json();
			if (data.success && data.archivo) {
				// Guardar archivo en localforage
				const nombreArchivo = `backup-${tipo}-${Date.now()}.json`;
				await localforage.setItem(nombreArchivo, data.archivo);
				get().showToast("Backup guardado localmente como: " + nombreArchivo, "success");
				return {
					success: true,
					filename: nombreArchivo
				};
			} else {
				get().showToast("Error generando backup: " + (data.error || "unknown"), "error");
				return {
					success: false,
					error: data.error
				};
			}
		} catch (e) {
			console.error("Error al generar backup:", e);
			get().showToast("Error de red al generar backup", "error");
			return {
				success: false,
				error: e.message
			};
		}
	},
	respaldarEnLocalStorage: async (nombre, contenidoJson) => {
		// Guardar backup codificado en localforage
		const contenidoBlob = typeof contenidoJson === "string" ? contenidoJson : JSON.stringify(contenidoJson, null, 2);
		await localforage.setItem(nombre, contenidoBlob);
		get().showToast("Backup guardado en almacenamiento local", "success");
	},
	obtenerRespaldoLocal: async (nombre) => {
		return await localforage.getItem(nombre);
	},
	listarBackupsLocales: async () => {
		const keys = await localforage.keys();
		const backups = [];
		for (const key of keys) {
			if (key.startsWith("backup-")) {
				const data = await localforage.getItem(key);
				backups.push({
					nombre: key,
					fecha: key.replace("backup-", "").replace(".json", "") || "desconocida",
					size: typeof data === "string" ? data.length : 0
				});
			}
		}
		return backups;
	},
	eliminarBackupLocal: async (nombre) => {
		await localforage.removeItem(nombre);
	},
	messages: [],
	sendMessage: async (receiverId, text) => {
		const { user } = get();
		if (!user) return {
			success: false,
			error: "No ha iniciado sesión."
		};
		const newMessage = {
			id: `msg-${Date.now()}`,
			senderId: user.id,
			senderUsername: user.username || user.email || "Anónimo",
			receiverId,
			text,
			createdAt: new Date().toISOString()
		};
		set((state) => ({ messages: [...state.messages || [], newMessage] }));
		try {
			const res = await fetch(`${API_BASE_URL}/api/messages`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(newMessage)
			});
			const data = await res.json();
			if (data.ok) {
				set((state) => ({ messages: (state.messages || []).map((m) => m.id === newMessage.id ? data.data : m) }));
			}
		} catch (e) {
			console.error("Error al enviar mensaje:", e);
		}
		return {
			success: true,
			message: newMessage
		};
	},
	addIncomingMessage: (msg) => {
		const exists = (get().messages || []).some((m) => m.id === msg.id);
		if (exists) return;
		set((state) => ({ messages: [...state.messages || [], msg] }));
	},
	markMessagesAsRead: async (senderId) => {
		const { user } = get();
		if (!user) return;
		set((state) => ({ messages: (state.messages || []).map((m) => {
			if (m.senderId === senderId && m.receiverId === user.id && !m.read) {
				return {
					...m,
					read: true
				};
			}
			return m;
		}) }));
		try {
			await fetch(`${API_BASE_URL}/api/messages/read`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					senderId,
					receiverId: user.id
				})
			});
		} catch (e) {
			console.error("Error marcando mensajes como leídos:", e);
		}
	},
	vincularJerarquia: (proyectoId, padreId, hijoId, datosEnlace = {}) => {
		set((state) => {
			let nombrePadre = "";
			const newCompanies = (state.companies || []).map((c) => ({
				...c,
				proyectos: (c.proyectos || []).map((p) => {
					if (p.id !== proyectoId) return p;
					// Buscar nombre del padre si existe
					const list = p.elementosUnifilares || [];
					const padre = list.find((e) => e.id === padreId);
					if (padre) nombrePadre = padre.nombre;
					return {
						...p,
						elementosUnifilares: (p.elementosUnifilares || []).map((e) => {
							if (e.id === hijoId) {
								return {
									...e,
									alimentadoPorId: padreId,
									alimentadoPor: nombrePadre ? `${nombrePadre} (${datosEnlace.circuitoOrigen || "Salida"})` : e.alimentadoPor,
									circuitoOrigen: datosEnlace.circuitoOrigen || e.circuitoOrigen,
									calibreConductor: datosEnlace.calibreConductor || e.calibreConductor,
									breakerAmperaje: datosEnlace.breakerAmperaje || e.breakerAmperaje,
									breakerMarca: datosEnlace.breakerMarca || e.breakerMarca,
									breakerTipo: datosEnlace.breakerTipo || e.breakerTipo,
									estadoVinculo: "ACTIVO"
								};
							}
							return e;
						})
					};
				})
			}));
			return { companies: newCompanies };
		});
	},
	desvincularJerarquia: (proyectoId, hijoId) => {
		set((state) => {
			const newCompanies = (state.companies || []).map((c) => ({
				...c,
				proyectos: (c.proyectos || []).map((p) => {
					if (p.id !== proyectoId) return p;
					return {
						...p,
						elementosUnifilares: (p.elementosUnifilares || []).map((e) => {
							if (e.id === hijoId) {
								return {
									...e,
									alimentadoPorId: null,
									alimentadoPor: null,
									circuitoOrigen: null,
									estadoVinculo: "ACTIVO"
								};
							}
							return e;
						})
					};
				})
			}));
			return { companies: newCompanies };
		});
	},
	crearElementoProvisional: (proyectoId, datosProvisional = {}) => {
		const state = get();
		const tipo = datosProvisional.tipoElemento || "TABLERO";
		const newId = datosProvisional.id || getNextElementId(tipo, state);
		const provisionalObj = {
			id: newId,
			nombre: datosProvisional.nombre || `RESERVA (${newId})`,
			tipoElemento: tipo,
			ubicacion: "RESERVA (Pendiente por Crear)",
			alimentadoPor: datosProvisional.circuitoOrigen ? `Circuito ${datosProvisional.circuitoOrigen}` : null,
			circuitoOrigen: datosProvisional.circuitoOrigen || null,
			estadoVinculo: "PENDIENTE_CREAR",
			observacionesGenerales: "Nodo registrado en estado provisional como Reserva activa.",
			datosTecnicos: {},
			proyectoId
		};
		get().addElementoUnifilar(proyectoId, provisionalObj);
		return provisionalObj;
	}
}), {
	name: "tableroselectrico_zustand_store",
	storage: localForageStorage,
	partialize: (state) => ({
		user: state.user,
		token: state.token,
		usersList: state.usersList || [],
		messages: state.messages || [],
		companies: state.companies,
		proyectosLocales: state.proyectosLocales || [],
		elementosLocales: state.elementosLocales || [],
		subestacionesLocales: state.subestacionesLocales || [],
		conflictosCircuitos: state.conflictosCircuitos || [],
		syncQueue: state.syncQueue
	}),
	onRehydrateStorage: () => (state) => {
		if (state && state.token && state.token !== "mock-offline-token" && typeof navigator !== "undefined" && navigator.onLine) {
			// Descarga automática transparente desde PostgreSQL tras restaurar sesión persistida
			state.pullInitialData?.();
			state.fetchUsersList?.();
		}
	}
}));
export default useStore;

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZUFBZTtBQUN4QixPQUFPLGlCQUFpQjtBQUN4QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLDJCQUEyQjs7QUFHcEMsWUFBWSxPQUFPO0NBQ2pCLE1BQU07Q0FDTixXQUFXO0FBQ2IsQ0FBQztBQUVELE9BQU8sTUFBTSxhQUFhO0NBQ3hCLFNBQVM7Q0FDVCxrQkFBa0I7Q0FDbEIsZ0JBQWdCO0NBQ2hCLGFBQWE7Q0FDYixrQkFBa0I7Q0FDbEIsY0FBYztDQUNkLHNCQUFzQjtDQUN0QixvQkFBb0I7Q0FDcEIsS0FBSztDQUNMLGVBQWU7Q0FDZixXQUFXO0NBQ1gsVUFBVTtDQUNWLGVBQWU7Q0FDZixtQkFBbUI7Q0FDbkIsTUFBTTtBQUNSO0FBRUEsT0FBTyxNQUFNLG9CQUFvQixRQUFRLE9BQU87Q0FDOUMsSUFBSSxDQUFDLFFBQVEsT0FBTyxNQUFNO0NBQzFCLElBQUksWUFBWSxPQUFPLEtBQUs7Q0FFNUIsSUFBSSxJQUFJO0VBQ04sSUFBSSxVQUFVLFdBQVcsR0FBRyxHQUFHLElBQUksR0FBRztHQUNwQyxZQUFZLFVBQVUsVUFBVSxHQUFHLFNBQVMsQ0FBQztFQUMvQyxPQUFPLElBQUksVUFBVSxXQUFXLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDMUMsWUFBWSxVQUFVLFVBQVUsR0FBRyxTQUFTLENBQUM7RUFDL0M7RUFDQSxNQUFNLFlBQVksSUFBSSxPQUFPLGlCQUFpQixHQUFHLFFBQVEsdUJBQXVCLE1BQU0sRUFBRSxNQUFNLElBQUk7RUFDbEcsWUFBWSxVQUFVLFFBQVEsV0FBVyxFQUFFLENBQUMsQ0FBQyxLQUFLO0NBQ3BEO0NBRUEsT0FBTyxhQUFhO0FBQ3RCO0FBRUEsT0FBTyxNQUFNLDRCQUE0QixRQUFRLE9BQU87Q0FDdEQsT0FBTyxpQkFBaUIsUUFBUSxFQUFFO0FBQ3BDO0FBRUEsT0FBTyxNQUFNLG9CQUFvQixjQUFjLFFBQVEsQ0FBQyxNQUFNO0NBQzVELE1BQU0sU0FBUyxXQUFXLGdCQUFnQixjQUFjO0NBQ3hELElBQUksU0FBUztDQUViLE1BQU0sYUFBYSxTQUFTO0VBQzFCLElBQUksUUFBUSxLQUFLLE1BQU0sT0FBTyxLQUFLLE9BQU8sWUFBWSxLQUFLLEdBQUcsV0FBVyxHQUFHLE9BQU8sRUFBRSxHQUFHO0dBQ3RGLE1BQU0sUUFBUSxLQUFLLEdBQUcsTUFBTSxHQUFHO0dBQy9CLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLElBQUksRUFBRTtHQUNoRCxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssTUFBTSxRQUFRLFNBQVM7RUFDNUM7Q0FDRjtDQUVBLENBQUMsTUFBTSxhQUFhLENBQUMsRUFBQyxDQUFFLFNBQVEsTUFBSztFQUNuQyxDQUFDLEVBQUUsdUJBQXVCLENBQUMsRUFBQyxDQUFFLFFBQVEsU0FBUztFQUMvQyxDQUFDLEVBQUUsYUFBYSxDQUFDLEVBQUMsQ0FBRSxTQUFRLE1BQUs7R0FDL0IsQ0FBQyxFQUFFLHVCQUF1QixFQUFFLFlBQVksQ0FBQyxFQUFDLENBQUUsUUFBUSxTQUFTO0dBQzdELENBQUMsRUFBRSwyQkFBMkIsRUFBRSxpQkFBaUIsQ0FBQyxFQUFDLENBQUUsUUFBUSxTQUFTO0dBQ3RFLENBQUMsRUFBRSxrQkFBa0IsQ0FBQyxFQUFDLENBQUUsUUFBUSxTQUFTO0dBQzFDLENBQUMsRUFBRSxXQUFXLENBQUMsRUFBQyxDQUFFLFFBQVEsU0FBUztFQUNyQyxDQUFDO0NBQ0gsQ0FBQztDQUVELENBQUMsTUFBTSxvQkFBb0IsQ0FBQyxFQUFDLENBQUUsUUFBUSxTQUFTO0NBQ2hELENBQUMsTUFBTSx3QkFBd0IsQ0FBQyxFQUFDLENBQUUsUUFBUSxTQUFTO0NBQ3BELENBQUMsTUFBTSx5QkFBeUIsQ0FBQyxFQUFDLENBQUUsUUFBUSxTQUFTO0NBQ3JELENBQUMsTUFBTSxjQUFjLENBQUMsRUFBQyxDQUFFLFFBQVEsU0FBUztDQUUxQyxPQUFPLEdBQUcsT0FBTyxHQUFHLFNBQVM7QUFDL0I7O0FBR0EsTUFBTSxxQkFBcUI7Q0FDekIsU0FBUyxPQUFPLFNBQVM7RUFDdkIsTUFBTSxRQUFRLE1BQU0sWUFBWSxRQUFRLElBQUk7RUFDNUMsT0FBTztDQUNUO0NBQ0EsU0FBUyxPQUFPLE1BQU0sVUFBVTtFQUM5QixNQUFNLFlBQVksUUFBUSxNQUFNLEtBQUs7Q0FDdkM7Q0FDQSxZQUFZLE9BQU8sU0FBUztFQUMxQixNQUFNLFlBQVksV0FBVyxJQUFJO0NBQ25DO0FBQ0Y7QUFFQSxNQUFNLG1CQUFtQixDQUN2QjtDQUNFLElBQUk7Q0FDSixRQUFRO0NBQ1IsV0FBVyxDQUNUO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixhQUFhO0VBQ2IscUJBQXFCO0dBQ25CO0lBQ0UsSUFBSTtJQUNKLFFBQVE7SUFDUixjQUFjO0lBQ2QsV0FBVztJQUNYLGVBQWU7SUFDZixNQUFNO0lBQ04sVUFBVTtJQUNWLHdCQUF3QjtJQUN4QixlQUFlO0tBQ2IsVUFBVTtLQUNWLGFBQWE7S0FDYixrQkFBa0I7S0FDbEIsbUJBQW1CO01BQUUsSUFBSTtNQUFJLElBQUk7TUFBSSxJQUFJO0tBQUc7S0FDNUMsa0JBQWtCO01BQUUsT0FBTztNQUFlLE1BQU07TUFBSSxLQUFLO0tBQUc7S0FDNUQsU0FBUztNQUFFLElBQUk7TUFBUyxJQUFJO01BQVMsSUFBSTtLQUFRO0tBQ2pELFdBQVc7S0FDWCxlQUFlO01BQUUsU0FBUztNQUFTLGVBQWU7S0FBRztLQUNyRCxjQUFjO01BQUUsU0FBUztNQUFhLGVBQWU7S0FBc0Q7SUFDN0c7SUFDQSxZQUFZO0lBQ1osV0FBVztJQUNYLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0dBQ3BDO0dBQ0E7SUFDRSxJQUFJO0lBQ0osUUFBUTtJQUNSLGNBQWM7SUFDZCxXQUFXO0lBQ1gsZUFBZTtJQUNmLE1BQU07SUFDTixVQUFVO0lBQ1Ysd0JBQXdCO0lBQ3hCLGVBQWU7S0FDYixRQUFRO0tBQ1IsbUJBQW1CO0tBQ25CLFVBQVU7S0FDVixTQUFTO01BQUUsS0FBSztNQUFJLEtBQUs7TUFBSSxLQUFLO0tBQUc7S0FDckMsd0JBQXdCO0tBQ3hCLHdCQUF3QjtLQUN4QixPQUFPO0tBQ1AsUUFBUTtLQUNSLFFBQVE7SUFDVjtJQUNBLFlBQVk7SUFDWixXQUFXO0lBQ1gsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDcEM7R0FDQTtJQUNFLElBQUk7SUFDSixRQUFRO0lBQ1IsY0FBYztJQUNkLFdBQVc7SUFDWCxlQUFlO0lBQ2YsTUFBTTtJQUNOLFVBQVU7SUFDVix3QkFBd0I7SUFDeEIsZUFBZTtLQUNiLFFBQVE7S0FDUixtQkFBbUI7S0FDbkIsVUFBVTtLQUNWLFNBQVM7TUFBRSxLQUFLO01BQU8sS0FBSztNQUFPLEtBQUs7S0FBTTtLQUM5Qyx1QkFBdUI7S0FDdkIsMEJBQTBCO0tBQzFCLE9BQU87S0FDUCxRQUFRO0tBQ1IsUUFBUTtJQUNWO0lBQ0EsWUFBWTtJQUNaLFdBQVc7SUFDWCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUNwQztHQUNBO0lBQ0UsSUFBSTtJQUNKLFFBQVE7SUFDUixjQUFjO0lBQ2QsV0FBVztJQUNYLGVBQWU7SUFDZixNQUFNO0lBQ04sVUFBVTtJQUNWLHdCQUF3QjtJQUN4QixlQUFlO0tBQ2IsS0FBSztLQUNMLE9BQU87S0FDUCxPQUFPO0tBQ1AsU0FBUztLQUNULFVBQVU7S0FDVixJQUFJO0tBQ0osYUFBYTtLQUNiLGFBQWE7TUFBRSxPQUFPO01BQVMsTUFBTTtNQUFJLEtBQUs7TUFBUSxVQUFVO01BQVksWUFBWTtLQUFNO0lBQ2hHO0lBQ0EsWUFBWTtJQUNaLFdBQVc7SUFDWCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUNwQztHQUNBO0lBQ0UsSUFBSTtJQUNKLFFBQVE7SUFDUixjQUFjO0lBQ2QsV0FBVztJQUNYLGVBQWU7SUFDZixNQUFNO0lBQ04sVUFBVTtJQUNWLHdCQUF3QjtJQUN4QixlQUFlO0tBQ2IsS0FBSztLQUNMLE9BQU87S0FDUCxPQUFPO0tBQ1AsU0FBUztLQUNULFVBQVU7S0FDVixJQUFJO0tBQ0osYUFBYTtLQUNiLGFBQWE7TUFBRSxPQUFPO01BQVMsTUFBTTtNQUFJLEtBQUs7TUFBUSxVQUFVO01BQVksWUFBWTtLQUFNO0lBQ2hHO0lBQ0EsWUFBWTtJQUNaLFdBQVc7SUFDWCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUNwQztFQUNGO0VBQ0EseUJBQXlCLENBQUM7RUFDMUIsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7Q0FDcEMsQ0FDRjtBQUNGLEdBQ0E7Q0FDRSxJQUFJO0NBQ0osUUFBUTtDQUNSLFdBQVcsQ0FBQztBQUNkLENBQ0Y7QUFFQSxNQUFNLHVCQUF1QjtDQUMzQixJQUFJO0VBQ0YsTUFBTSxNQUFNLE9BQU8saUJBQWlCLGNBQWMsYUFBYSxRQUFRLE1BQU0sSUFBSTtFQUNqRixPQUFPLE1BQU0sS0FBSyxNQUFNLEdBQUcsSUFBSTtDQUNqQyxTQUFTLEdBQUc7RUFDVixPQUFPO0NBQ1Q7QUFDRjtBQUVBLE1BQU0sd0JBQXdCO0NBQzVCLElBQUk7RUFDRixPQUFPLE9BQU8saUJBQWlCLGNBQWUsYUFBYSxRQUFRLE9BQU8sS0FBSyxPQUFRO0NBQ3pGLFNBQVMsR0FBRztFQUNWLE9BQU87Q0FDVDtBQUNGO0FBRUEsT0FBTyxNQUFNLFdBQVcsT0FDdEIsU0FDRyxLQUFLLFNBQVM7Q0FDYixNQUFNLGVBQWU7Q0FDckIsT0FBTyxnQkFBZ0I7Q0FDdkIsV0FBVyxDQUNUO0VBQUUsSUFBSTtFQUFPLFVBQVU7RUFBVSxNQUFNO0NBQVEsR0FDL0M7RUFBRSxJQUFJO0VBQU8sVUFBVTtFQUFVLE1BQU07Q0FBUSxDQUNqRDtDQUNBLFdBQVc7Q0FDWCxrQkFBa0IsQ0FBQztDQUNuQixrQkFBa0IsQ0FBQztDQUNuQixzQkFBc0IsQ0FBQztDQUN2QixXQUFXLENBQUM7Q0FDWixRQUFRO0NBQ1IsT0FBTztFQUFFLE1BQU07RUFBTyxTQUFTO0VBQUksTUFBTTtFQUFXLFFBQVE7Q0FBSztDQUNqRSxxQkFBcUIsQ0FBQztDQUN0Qix1QkFBdUI7Q0FFdkIsWUFBWSxTQUFTLE9BQU8sV0FBVyxTQUFTLFNBQVMsSUFBSSxFQUFFLE9BQU87RUFBRSxNQUFNO0VBQU07RUFBUztFQUFNO0NBQU8sRUFBRSxDQUFDO0NBQzdHLGlCQUFpQixLQUFLLFdBQVcsRUFBRSxPQUFPO0VBQUUsR0FBRyxNQUFNO0VBQU8sTUFBTTtDQUFNLEVBQUUsRUFBRTtDQUM1RSxZQUFZLFdBQVcsSUFBSSxFQUFFLE9BQU8sQ0FBQztDQUNyQyx5QkFBeUIsV0FBVyxJQUFJLEVBQUUsdUJBQXVCLE9BQU8sQ0FBQztDQUV6RSw2QkFBNkIsY0FBYyxLQUFLLFVBQVU7RUFDeEQsTUFBTSxpQkFBaUI7R0FDckIsSUFBSSxVQUFVLE1BQU0sUUFBUSxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQztHQUNoRixXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUNsQyxVQUFVO0dBQ1YsR0FBRztFQUNMOztFQUVBLE1BQU0sWUFBWSxNQUFNLHVCQUF1QixDQUFDLEVBQUMsQ0FBRSxRQUFPLE1BQ3hELEVBQUUsRUFBRSxjQUFjLGVBQWUsYUFBYSxLQUFLLFVBQVUsRUFBRSxLQUFLLE1BQU0sS0FBSyxVQUFVLGVBQWUsS0FBSyxFQUMvRztFQUNBLE9BQU8sRUFDTCxxQkFBcUIsQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLEVBQ25EO0NBQ0YsQ0FBQztDQUVELDRCQUE0QixPQUFPLEtBQUssV0FBVyxFQUNqRCxzQkFBc0IsTUFBTSx1QkFBdUIsQ0FBQyxFQUFDLENBQUUsUUFBTyxNQUFLLEVBQUUsT0FBTyxFQUFFLEVBQ2hGLEVBQUU7Q0FFRixrQ0FBa0MsSUFBSSxFQUFFLHFCQUFxQixDQUFDLEVBQUUsQ0FBQztDQUVqRSxrQkFBa0IsUUFBUSxXQUFXLE9BQU87RUFDMUMsSUFDRSxXQUFXLE9BQ1gsV0FBVyxPQUNYLFVBQVUsWUFBWSxDQUFDLENBQUMsU0FBUyxVQUFVLEtBQzNDLFVBQVUsWUFBWSxDQUFDLENBQUMsU0FBUyxVQUFVLEtBQzNDLFVBQVUsWUFBWSxDQUFDLENBQUMsU0FBUyxPQUFPLEdBQ3hDO0dBQ0EsSUFBSTtJQUNGLElBQUksT0FBTyxXQUFXLGFBQWE7S0FDakMsYUFBYSxXQUFXLE9BQU87S0FDL0IsYUFBYSxXQUFXLE1BQU07S0FDOUIsYUFBYSxXQUFXLFNBQVM7S0FDakMsZUFBZSxNQUFNO0lBQ3ZCO0dBQ0YsU0FBUyxHQUFHLENBQUM7R0FFYixJQUFJO0lBQUUsTUFBTTtJQUFNLE9BQU87R0FBSyxDQUFDO0dBRS9CLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxTQUFTLGFBQWEsVUFBVTtJQUMxRSxPQUFPLFNBQVMsUUFBUSxRQUFRO0dBQ2xDO0VBQ0Y7Q0FDRjtDQUVBLGdCQUFnQixZQUFZO0VBQzFCLElBQUk7R0FDRixNQUFNLEVBQUUsVUFBVSxJQUFJO0dBQ3RCLElBQUksQ0FBQyxTQUFTLFVBQVUsc0JBQXNCO0dBQzlDLE1BQU0sTUFBTSxNQUFNLE1BQU0sR0FBRyxhQUFhLGFBQWEsRUFDbkQsU0FBUyxFQUNQLEdBQUksUUFBUSxFQUFFLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxDQUFDLEVBQ3hELEVBQ0YsQ0FBQztHQUNELElBQUksSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7SUFDNUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLElBQUksTUFBTTtJQUNoQztHQUNGO0dBQ0EsTUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0dBQzVCLElBQUksS0FBSyxJQUFJO0lBQ1gsSUFBSSxFQUFFLFdBQVcsS0FBSyxLQUFLLENBQUM7R0FDOUI7RUFDRixTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sc0NBQXNDLENBQUM7RUFDdkQ7Q0FDRjtDQUVBLG1CQUFtQixPQUFPLFdBQVc7RUFDbkMsSUFBSTtHQUNGLE1BQU0sRUFBRSxVQUFVLElBQUk7R0FDdEIsSUFBSSxDQUFDLFNBQVMsVUFBVSxzQkFBc0I7R0FDOUMsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLGFBQWEsZ0JBQWdCLFVBQVUsRUFDaEUsU0FBUyxFQUNQLEdBQUksUUFBUSxFQUFFLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxDQUFDLEVBQ3hELEVBQ0YsQ0FBQztHQUNELElBQUksSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7SUFDNUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLElBQUksTUFBTTtJQUNoQztHQUNGO0dBQ0EsTUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0dBQzVCLElBQUksS0FBSyxJQUFJO0lBQ1gsSUFBSSxFQUFFLFVBQVUsS0FBSyxLQUFLLENBQUM7R0FDN0I7RUFDRixTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sc0NBQXNDLENBQUM7RUFDdkQ7Q0FDRjtDQUVBLHFCQUFxQixZQUFZO0VBQy9CLE9BQU8sSUFBSSxDQUFDLENBQUMsZ0JBQWdCO0NBQy9CO0NBRUEsaUJBQWlCLFlBQVk7RUFDM0IsTUFBTSxFQUFFLE9BQU8sU0FBUyxJQUFJO0VBQzVCLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxVQUFVLFVBQVUsc0JBQXNCO0VBRW5FLElBQUk7O0dBRUYsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLGFBQWEsaUJBQWlCLEVBQ3ZELFNBQVMsRUFDUCxpQkFBaUIsVUFBVSxRQUM3QixFQUNGLENBQUM7R0FFRCxJQUFJLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0lBQzVDLElBQUksQ0FBQyxDQUFDLGdCQUFnQixJQUFJLE1BQU07SUFDaEMsT0FBTztLQUFFLFNBQVM7S0FBTyxPQUFPO0lBQWlCO0dBQ25EO0dBRUEsSUFBSSxJQUFJLElBQUk7SUFDVixNQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7SUFDNUIsSUFBSSxLQUFLLE1BQU0sTUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxTQUFTLEdBQUc7S0FDL0QsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLEtBQUssSUFBSTtLQUMvQixPQUFPO01BQUUsU0FBUztNQUFNLE9BQU8sS0FBSyxLQUFLO0tBQU87SUFDbEQ7R0FDRjs7R0FHQSxJQUFJLFFBQVEsS0FBSyxTQUFTLFNBQVM7SUFDakMsTUFBTSxZQUFZLE1BQU0sTUFBTSxHQUFHLGFBQWEscUJBQXFCLEVBQ2pFLFNBQVMsRUFDUCxpQkFBaUIsVUFBVSxRQUM3QixFQUNGLENBQUM7SUFDRCxJQUFJLFVBQVUsV0FBVyxPQUFPLFVBQVUsV0FBVyxLQUFLO0tBQ3hELElBQUksQ0FBQyxDQUFDLGdCQUFnQixVQUFVLE1BQU07S0FDdEMsT0FBTztNQUFFLFNBQVM7TUFBTyxPQUFPO0tBQWlCO0lBQ25EO0lBQ0EsSUFBSSxVQUFVLElBQUk7S0FDaEIsTUFBTSxhQUFhLE1BQU0sVUFBVSxLQUFLO0tBQ3hDLElBQUksV0FBVyxNQUFNLE1BQU0sUUFBUSxXQUFXLElBQUksS0FBSyxXQUFXLEtBQUssU0FBUyxHQUFHO01BQ2pGLElBQUksQ0FBQyxDQUFDLGdCQUFnQixXQUFXLElBQUk7TUFDckMsT0FBTztPQUFFLFNBQVM7T0FBTSxPQUFPLFdBQVcsS0FBSztNQUFPO0tBQ3hEO0lBQ0Y7R0FDRjtFQUNGLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSwyREFBMkQsQ0FBQztFQUM1RTtDQUNGO0NBRUEsT0FBTyxPQUFPLFVBQVUsYUFBYTtFQUNuQyxNQUFNLGlCQUFpQixZQUFZLEdBQUUsQ0FBRSxLQUFLO0VBQzVDLElBQUksZ0JBQWdCO0VBRXBCLElBQUksT0FBTyxjQUFjLGVBQWUsVUFBVSxRQUFRO0dBQ3hELElBQUk7SUFDRixNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsYUFBYSxhQUFhO0tBQ25ELFFBQVE7S0FDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtLQUM5QyxNQUFNLEtBQUssVUFBVTtNQUFFLFVBQVU7TUFBZTtLQUFTLENBQUM7SUFDNUQsQ0FBQztJQUVELE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSyxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUU7SUFFOUMsSUFBSSxJQUFJLE1BQU0sS0FBSyxJQUFJOztLQUVyQixNQUFNLGVBQWUsSUFBSSxDQUFDLENBQUMsYUFBYSxDQUFDO0tBQ3pDLE1BQU0sWUFBWSxhQUFhLFdBQzdCLE9BQU0sRUFBRSxZQUFZLEdBQUUsQ0FBRSxZQUFZLE1BQU0sS0FBSyxLQUFLLFNBQVMsWUFBWSxDQUMzRTtLQUNBLElBQUksZUFBZSxDQUFDLEdBQUcsWUFBWTtLQUNuQyxNQUFNLFlBQVk7TUFDaEIsSUFBSSxLQUFLLEtBQUs7TUFDZCxVQUFVLEtBQUssS0FBSztNQUNwQixNQUFNLEtBQUssS0FBSztNQUNoQixXQUFXLEtBQUssS0FBSztNQUNyQixVQUFVLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtLQUNuQztLQUVBLElBQUksYUFBYSxHQUFHO01BQ2xCLGFBQWEsYUFBYTtPQUFFLEdBQUcsYUFBYTtPQUFZLEdBQUc7TUFBVTtLQUN2RSxPQUFPO01BQ0wsYUFBYSxLQUFLLFNBQVM7S0FDN0I7S0FFQSxJQUFJO01BQ0YsSUFBSSxPQUFPLGlCQUFpQixhQUFhO09BQ3ZDLGFBQWEsUUFBUSxRQUFRLEtBQUssVUFBVSxLQUFLLElBQUksQ0FBQztPQUN0RCxhQUFhLFFBQVEsU0FBUyxLQUFLLEtBQUs7TUFDMUM7S0FDRixTQUFTLEdBQUcsQ0FBQztLQUViLElBQUk7TUFDRixNQUFNLEtBQUs7TUFDWCxPQUFPLEtBQUs7TUFDWixXQUFXO0tBQ2IsQ0FBQztLQUVELElBQUksQ0FBQyxDQUFDLGtCQUFrQixLQUFLLEtBQUssRUFBRTtLQUNwQyxJQUFJLENBQUMsQ0FBQyxlQUFlO0tBQ3JCLElBQUksQ0FBQyxDQUFDLGdCQUFnQjtLQUN0QixPQUFPO01BQUUsU0FBUztNQUFNLE1BQU0sS0FBSztLQUFLO0lBQzFDOztJQUdBLElBQUksSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7S0FDbEUsT0FBTztNQUNMLFNBQVM7TUFDVCxPQUFPLEtBQUssU0FBUztLQUN2QjtJQUNGO0lBRUEsSUFBSSxJQUFJLFVBQVUsS0FBSztLQUNyQixPQUFPO01BQ0wsU0FBUztNQUNULE9BQU8sS0FBSyxTQUFTLHlCQUF5QixJQUFJLE9BQU87S0FDM0Q7SUFDRjtHQUNGLFNBQVMsR0FBRztJQUNWLFFBQVEsS0FBSyxtRUFBbUUsQ0FBQztJQUNqRixnQkFBZ0I7R0FDbEI7RUFDRixPQUFPO0dBQ0wsZ0JBQWdCO0VBQ2xCOztFQUdBLElBQUksZUFBZTtHQUNqQixNQUFNLE9BQU8sSUFBSSxDQUFDLENBQUMsYUFBYSxDQUFDO0dBQ2pDLE1BQU0sV0FBVyxjQUFjLFlBQVk7R0FDM0MsTUFBTSxRQUFRLEtBQUssTUFBTSxNQUFNO0lBQzdCLE1BQU0sV0FBVyxFQUFFLFlBQVksRUFBRSxTQUFTLEdBQUUsQ0FBRSxZQUFZLENBQUMsQ0FBQyxLQUFLO0lBQ2pFLE9BQU8sWUFBWSxZQUNYLFlBQVksWUFBWSxhQUFhLDBCQUNyQyxZQUFZLDBCQUEwQixhQUFhO0dBQzdELENBQUM7R0FFRCxJQUFJLE9BQU87SUFDVCxJQUFJO0tBQ0YsTUFBTTtNQUFFLElBQUksTUFBTTtNQUFJLFVBQVUsTUFBTTtNQUFVLE1BQU0sTUFBTTtNQUFNLFdBQVcsTUFBTTtLQUFVO0tBQzdGLE9BQU87SUFDVCxDQUFDO0lBQ0QsSUFBSSxDQUFDLENBQUMsZ0JBQWdCO0lBQ3RCLE9BQU87S0FBRSxTQUFTO0tBQU0sTUFBTTtLQUFPLFdBQVc7SUFBSztHQUN2RDtHQUVBLE9BQU87SUFDTCxTQUFTO0lBQ1QsT0FBTztJQUNQLGdCQUFnQjtHQUNsQjtFQUNGO0VBRUEsT0FBTztHQUFFLFNBQVM7R0FBTyxPQUFPO0VBQW9DO0NBQ3RFO0NBRUEsY0FBYztFQUNaLElBQUk7R0FDRixJQUFJLE9BQU8sV0FBVyxhQUFhO0lBQ2pDLGFBQWEsV0FBVyxPQUFPO0lBQy9CLGFBQWEsV0FBVyxNQUFNO0lBQzlCLGFBQWEsV0FBVyxTQUFTO0lBQ2pDLGVBQWUsTUFBTTtHQUN2QjtFQUNGLFNBQVMsR0FBRyxDQUFDO0VBQ2IsSUFBSTtHQUFFLE1BQU07R0FBTSxPQUFPO0VBQUssQ0FBQztFQUMvQixJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sU0FBUyxhQUFhLFVBQVU7R0FDMUUsT0FBTyxTQUFTLFFBQVEsUUFBUTtFQUNsQztDQUNGO0NBRUEsU0FBUyxPQUFPLFlBQVk7RUFDMUIsTUFBTSxjQUFjLElBQUksQ0FBQyxDQUFDO0VBQzFCLElBQUksQ0FBQyxlQUFlLFlBQVksU0FBUyxTQUFTO0dBQ2hELE9BQU87SUFBRSxTQUFTO0lBQU8sT0FBTztHQUFvRDtFQUN0RjtFQUVBLE1BQU0sZ0JBQWdCLFFBQVEsU0FBUyxZQUFZLENBQUMsQ0FBQyxLQUFLO0VBQzFELE1BQU0sVUFBVSxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBQyxDQUFFLE1BQ3BDLE9BQU8sRUFBRSxZQUFZLEVBQUUsU0FBUyxHQUFFLENBQUUsWUFBWSxDQUFDLENBQUMsS0FBSyxNQUFNLGFBQ2hFO0VBQ0EsSUFBSSxRQUFRO0dBQ1YsT0FBTztJQUFFLFNBQVM7SUFBTyxPQUFPO0dBQW1EO0VBQ3JGO0VBRUEsTUFBTSxVQUFVO0dBQ2QsSUFBSSxRQUFRLEtBQUssSUFBSTtHQUNyQixVQUFVLFFBQVEsU0FBUyxLQUFLO0dBQ2hDLFVBQVUsUUFBUTtHQUNsQixNQUFNLFFBQVEsUUFBUTtHQUN0QixXQUFXLFFBQVEsU0FBUyxXQUFXLFFBQVEsWUFBWTtFQUM3RDtFQUVBLEtBQUssV0FBVyxFQUNkLFdBQVcsQ0FBQyxHQUFJLE1BQU0sYUFBYSxDQUFDLEdBQUksT0FBTyxFQUNqRCxFQUFFO0VBRUYsSUFBSTtHQUNGLE1BQU0sRUFBRSxVQUFVLElBQUk7R0FDdEIsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLGFBQWEsYUFBYTtJQUNuRCxRQUFRO0lBQ1IsU0FBUztLQUNQLGdCQUFnQjtLQUNoQixHQUFJLFFBQVEsRUFBRSxpQkFBaUIsVUFBVSxRQUFRLElBQUksQ0FBQztJQUN4RDtJQUNBLE1BQU0sS0FBSyxVQUFVLE9BQU87R0FDOUIsQ0FBQztHQUNELE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSztHQUM1QixJQUFJLEtBQUssSUFBSTtJQUNYLElBQUksQ0FBQyxDQUFDLGVBQWU7R0FDdkI7RUFDRixTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sc0NBQXNDLENBQUM7RUFDdkQ7RUFFQSxPQUFPO0dBQUUsU0FBUztHQUFNLE1BQU07RUFBUTtDQUN4QztDQUVBLFlBQVksT0FBTyxRQUFRLGdCQUFnQjtFQUN6QyxNQUFNLGNBQWMsSUFBSSxDQUFDLENBQUM7RUFDMUIsSUFBSSxDQUFDLGVBQWUsWUFBWSxTQUFTLFNBQVM7R0FDaEQsT0FBTztJQUFFLFNBQVM7SUFBTyxPQUFPO0dBQW9EO0VBQ3RGO0VBRUEsTUFBTSxnQkFBZ0IsWUFBWSxVQUFVLFlBQVksQ0FBQyxDQUFDLEtBQUs7RUFDL0QsTUFBTSxlQUFlLElBQUksQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFDLENBQUUsTUFDekMsTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLFlBQVksRUFBRSxTQUFTLEdBQUUsQ0FBRSxZQUFZLENBQUMsQ0FBQyxLQUFLLE1BQU0sYUFDbkY7RUFDQSxJQUFJLGFBQWE7R0FDZixPQUFPO0lBQUUsU0FBUztJQUFPLE9BQU87R0FBcUQ7RUFDdkY7RUFFQSxNQUFNLGFBQWE7R0FDakIsR0FBRztHQUNILFdBQVcsWUFBWSxTQUFTLFdBQVcsWUFBWSxZQUFZO0VBQ3JFO0VBRUEsS0FBSyxVQUFVO0dBQ2IsTUFBTSxlQUFlLE1BQU0sYUFBYSxDQUFDLEVBQUMsQ0FBRSxLQUFLLE1BQU07SUFDckQsSUFBSSxFQUFFLE9BQU8sUUFBUTtLQUNuQixPQUFPO01BQUUsR0FBRztNQUFHLEdBQUc7S0FBVztJQUMvQjtJQUNBLE9BQU87R0FDVCxDQUFDO0dBRUQsTUFBTSxvQkFBb0IsWUFBWSxNQUFNLE1BQU0sRUFBRSxPQUFPLE1BQU0sTUFBTSxFQUFFO0dBRXpFLE9BQU87SUFDTCxXQUFXO0lBQ1gsTUFBTSxxQkFBcUIsTUFBTTtHQUNuQztFQUNGLENBQUM7RUFFRCxJQUFJO0dBQ0YsTUFBTSxFQUFFLFVBQVUsSUFBSTtHQUN0QixNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsYUFBYSxhQUFhLFVBQVU7SUFDN0QsUUFBUTtJQUNSLFNBQVM7S0FDUCxnQkFBZ0I7S0FDaEIsR0FBSSxRQUFRLEVBQUUsaUJBQWlCLFVBQVUsUUFBUSxJQUFJLENBQUM7SUFDeEQ7SUFDQSxNQUFNLEtBQUssVUFBVSxVQUFVO0dBQ2pDLENBQUM7R0FDRCxNQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7R0FDNUIsSUFBSSxLQUFLLElBQUk7SUFDWCxJQUFJLENBQUMsQ0FBQyxlQUFlO0dBQ3ZCO0VBQ0YsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLGdEQUFnRCxDQUFDO0VBQ2pFO0VBRUEsT0FBTyxFQUFFLFNBQVMsS0FBSztDQUN6QjtDQUVBLFlBQVksT0FBTyxXQUFXO0VBQzVCLE1BQU0sY0FBYyxJQUFJLENBQUMsQ0FBQztFQUMxQixJQUFJLENBQUMsZUFBZSxZQUFZLFNBQVMsU0FBUztHQUNoRCxPQUFPO0lBQUUsU0FBUztJQUFPLE9BQU87R0FBb0Q7RUFDdEY7RUFFQSxNQUFNLGdCQUFnQixJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBQyxDQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sTUFBTTtFQUN4RSxJQUFJLGlCQUFpQixhQUFhLFlBQVksR0FBRSxDQUFFLFlBQVksTUFBTSxVQUFVO0dBQzVFLE9BQU87SUFBRSxTQUFTO0lBQU8sT0FBTztHQUFxRjtFQUN2SDtFQUVBLElBQUksWUFBWSxPQUFPLFFBQVE7R0FDN0IsT0FBTztJQUFFLFNBQVM7SUFBTyxPQUFPO0dBQXlEO0VBQzNGO0VBRUEsS0FBSyxXQUFXLEVBQ2QsWUFBWSxNQUFNLGFBQWEsQ0FBQyxFQUFDLENBQUUsUUFBUSxNQUFNLEVBQUUsT0FBTyxNQUFNLEVBQ2xFLEVBQUU7RUFFRixJQUFJO0dBQ0YsTUFBTSxFQUFFLFVBQVUsSUFBSTtHQUN0QixNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsYUFBYSxhQUFhLFVBQVU7SUFDN0QsUUFBUTtJQUNSLFNBQVMsRUFDUCxHQUFJLFFBQVEsRUFBRSxpQkFBaUIsVUFBVSxRQUFRLElBQUksQ0FBQyxFQUN4RDtHQUNGLENBQUM7R0FDRCxNQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7R0FDNUIsSUFBSSxLQUFLLElBQUk7SUFDWCxJQUFJLENBQUMsQ0FBQyxlQUFlO0dBQ3ZCO0VBQ0YsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLDhDQUE4QyxDQUFDO0VBQy9EO0VBRUEsT0FBTyxFQUFFLFNBQVMsS0FBSztDQUN6QjtDQUVBLGVBQWUsT0FBTyxXQUFXLGdCQUFnQjtFQUMvQyxLQUFLLFdBQVcsRUFDZCxXQUFXLE1BQU0sVUFBVSxLQUFLLE1BQU07R0FDcEMsSUFBSSxFQUFFLE9BQU8sV0FBVztJQUN0QixPQUFPO0tBQUUsR0FBRztLQUFHLEdBQUc7SUFBWTtHQUNoQztHQUNBLE9BQU87RUFDVCxDQUFDLEVBQ0gsRUFBRTtFQUVGLElBQUksVUFBVSxRQUFRO0dBQ3BCLElBQUk7SUFDRixNQUFNLEVBQUUsVUFBVSxJQUFJO0lBQ3RCLE1BQU0sTUFBTSxHQUFHLGFBQWEsZ0JBQWdCLGFBQWE7S0FDdkQsUUFBUTtLQUNSLFNBQVM7TUFDUCxnQkFBZ0I7TUFDaEIsR0FBSSxRQUFRLEVBQUUsaUJBQWlCLFVBQVUsUUFBUSxJQUFJLENBQUM7S0FDeEQ7S0FDQSxNQUFNLEtBQUssVUFBVSxXQUFXO0lBQ2xDLENBQUM7R0FDSCxTQUFTLEdBQUc7SUFDVixRQUFRLE1BQU0sK0NBQStDLENBQUM7R0FDaEU7RUFDRjtDQUNGO0NBRUEsZ0JBQWdCLE9BQU8sV0FBVyxZQUFZLGdCQUFnQjtFQUM1RCxLQUFLLFdBQVcsRUFDZCxXQUFXLE1BQU0sVUFBVSxLQUFLLE1BQU07R0FDcEMsSUFBSSxFQUFFLE9BQU8sV0FBVztJQUN0QixPQUFPO0tBQ0wsR0FBRztLQUNILFlBQVksRUFBRSxhQUFhLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTTtNQUN4QyxJQUFJLEVBQUUsT0FBTyxZQUFZO09BQ3ZCLE9BQU87UUFBRSxHQUFHO1FBQUcsR0FBRztPQUFZO01BQ2hDO01BQ0EsT0FBTztLQUNULENBQUM7SUFDSDtHQUNGO0dBQ0EsT0FBTztFQUNULENBQUMsRUFDSCxFQUFFO0VBRUYsSUFBSSxVQUFVLFFBQVE7R0FDcEIsSUFBSTtJQUNGLE1BQU0sRUFBRSxVQUFVLElBQUk7SUFDdEIsTUFBTSxNQUFNLEdBQUcsYUFBYSxpQkFBaUIsY0FBYztLQUN6RCxRQUFRO0tBQ1IsU0FBUztNQUNQLGdCQUFnQjtNQUNoQixHQUFJLFFBQVEsRUFBRSxpQkFBaUIsVUFBVSxRQUFRLElBQUksQ0FBQztLQUN4RDtLQUNBLE1BQU0sS0FBSyxVQUFVLFdBQVc7SUFDbEMsQ0FBQztHQUNILFNBQVMsR0FBRztJQUNWLFFBQVEsTUFBTSxnREFBZ0QsQ0FBQztHQUNqRTtFQUNGO0NBQ0Y7Q0FFQSxvQkFBb0IsT0FBTyxlQUFlO0VBQ3hDLElBQUksVUFBVSxRQUFRO0dBQ3BCLElBQUk7SUFDRixNQUFNLEVBQUUsVUFBVSxJQUFJO0lBQ3RCLE1BQU0sTUFBTSxNQUFNLE1BQU0sR0FBRyxhQUFhLGdDQUFnQyxjQUFjLEVBQ3BGLFNBQVMsRUFDUCxHQUFJLFFBQVEsRUFBRSxpQkFBaUIsVUFBVSxRQUFRLElBQUksQ0FBQyxFQUN4RCxFQUNGLENBQUM7SUFDRCxNQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7SUFDNUIsSUFBSSxLQUFLLElBQUk7S0FDWCxLQUFLLFdBQVcsRUFDZCxXQUFXLE1BQU0sVUFBVSxLQUFLLE9BQU87TUFDckMsR0FBRztNQUNILFlBQVksRUFBRSxhQUFhLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTTtPQUN4QyxJQUFJLEVBQUUsT0FBTyxZQUFZO1FBQ3ZCLE9BQU87U0FBRSxHQUFHO1NBQUcsZUFBZSxLQUFLO1FBQUs7T0FDMUM7T0FDQSxPQUFPO01BQ1QsQ0FBQztLQUNILEVBQUUsRUFDSixFQUFFO0lBQ0o7R0FDRixTQUFTLEdBQUc7SUFDVixRQUFRLE1BQU0sbUNBQW1DLENBQUM7R0FDcEQ7RUFDRjtDQUNGO0NBRUEsZ0JBQWdCLE9BQU8sb0JBQW9CO0VBQ3pDLE1BQU0sRUFBRSxlQUFlO0VBQ3ZCLE1BQU0saUJBQWlCO0dBQ3JCLElBQUksZ0JBQWdCLE1BQU0sT0FBTyxXQUFXO0dBQzVDLEdBQUc7RUFDTDtFQUVBLEtBQUssV0FBVyxFQUNkLFdBQVcsTUFBTSxVQUFVLEtBQUssT0FBTztHQUNyQyxHQUFHO0dBQ0gsWUFBWSxFQUFFLGFBQWEsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNO0lBQ3hDLElBQUksRUFBRSxPQUFPLFlBQVk7S0FDdkIsTUFBTSxlQUFlLEVBQUUsaUJBQWlCLENBQUM7S0FDekMsT0FBTztNQUFFLEdBQUc7TUFBRyxlQUFlLENBQUMsR0FBRyxjQUFjLGNBQWM7S0FBRTtJQUNsRTtJQUNBLE9BQU87R0FDVCxDQUFDO0VBQ0gsRUFBRSxFQUNKLEVBQUU7RUFFRixJQUFJLFVBQVUsUUFBUTtHQUNwQixJQUFJO0lBQ0YsTUFBTSxFQUFFLFVBQVUsSUFBSTtJQUN0QixNQUFNLE1BQU0sR0FBRyxhQUFhLHFCQUFxQjtLQUMvQyxRQUFRO0tBQ1IsU0FBUztNQUNQLGdCQUFnQjtNQUNoQixHQUFJLFFBQVEsRUFBRSxpQkFBaUIsVUFBVSxRQUFRLElBQUksQ0FBQztLQUN4RDtLQUNBLE1BQU0sS0FBSyxVQUFVLGNBQWM7SUFDckMsQ0FBQztHQUNILFNBQVMsR0FBRztJQUNWLFFBQVEsTUFBTSxpQ0FBaUMsQ0FBQztHQUNsRDtFQUNGO0NBQ0Y7Q0FFQSxtQkFBbUIsT0FBTyxZQUFZLGtCQUFrQjtFQUN0RCxLQUFLLFdBQVcsRUFDZCxXQUFXLE1BQU0sVUFBVSxLQUFLLE9BQU87R0FDckMsR0FBRztHQUNILFlBQVksRUFBRSxhQUFhLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTTtJQUN4QyxJQUFJLEVBQUUsT0FBTyxZQUFZO0tBQ3ZCLE1BQU0sZUFBZSxFQUFFLGlCQUFpQixDQUFDO0tBQ3pDLE9BQU87TUFBRSxHQUFHO01BQUcsZUFBZSxhQUFhLFFBQU8sTUFBSyxFQUFFLE9BQU8sYUFBYTtLQUFFO0lBQ2pGO0lBQ0EsT0FBTztHQUNULENBQUM7RUFDSCxFQUFFLEVBQ0osRUFBRTtFQUVGLElBQUksVUFBVSxRQUFRO0dBQ3BCLElBQUk7SUFDRixNQUFNLEVBQUUsVUFBVSxJQUFJO0lBQ3RCLE1BQU0sTUFBTSxHQUFHLGFBQWEscUJBQXFCLGlCQUFpQjtLQUNoRSxRQUFRO0tBQ1IsU0FBUyxFQUNQLEdBQUksUUFBUSxFQUFFLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxDQUFDLEVBQ3hEO0lBQ0YsQ0FBQztHQUNILFNBQVMsR0FBRztJQUNWLFFBQVEsTUFBTSxrQ0FBa0MsQ0FBQztHQUNuRDtFQUNGO0NBQ0Y7Q0FFQSwyQkFBMkIsWUFBWSxXQUFXLGtCQUFrQjtFQUNsRSxLQUFLLFVBQVU7R0FDYixNQUFNLGlCQUFpQixNQUFNO0lBQzNCLElBQUksRUFBRSxPQUFPLFdBQVc7S0FDdEIsT0FBTztNQUNMLEdBQUc7TUFDSCxlQUFlO09BQ2IsR0FBRyxFQUFFO09BQ0w7TUFDRjtLQUNGO0lBQ0Y7SUFDQSxPQUFPO0dBQ1Q7R0FFQSxNQUFNLG1CQUFtQixNQUFNLFVBQVUsS0FBSyxNQUFNO0lBQ2xELElBQUksQ0FBQyxZQUFZO0tBQ2YsTUFBTSxPQUFPLEVBQUUsdUJBQXVCLENBQUM7S0FDdkMsT0FBTztNQUFFLEdBQUc7TUFBRyxxQkFBcUIsS0FBSyxJQUFJLGFBQWE7S0FBRTtJQUM5RDtJQUNBLE9BQU87S0FDTCxHQUFHO0tBQ0gsWUFBWSxFQUFFLGFBQWEsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNO01BQ3hDLElBQUksRUFBRSxPQUFPLFlBQVk7T0FDdkIsTUFBTSxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsWUFBWSxDQUFDO09BQ3JELE9BQU87UUFBRSxHQUFHO1FBQUcscUJBQXFCLEtBQUssSUFBSSxhQUFhO09BQUU7TUFDOUQ7TUFDQSxPQUFPO0tBQ1QsQ0FBQztJQUNIO0dBQ0YsQ0FBQzs7R0FHRCxNQUFNLGNBQWMsTUFBTSxvQkFBb0IsQ0FBQztHQUMvQyxNQUFNLGlCQUFpQixZQUFZLE1BQUssTUFBSyxFQUFFLE9BQU8sU0FBUztHQUMvRCxJQUFJLFVBQVU7R0FDZCxJQUFJLGdCQUFnQjtJQUNsQixVQUFVO0tBQ1IsR0FBRztLQUNILGVBQWU7TUFDYixHQUFHLGVBQWU7TUFDbEI7S0FDRjtJQUNGO0dBQ0Y7R0FFQSxPQUFPO0lBQ0wsV0FBVztJQUNYLG1CQUFtQixNQUFNLG9CQUFvQixDQUFDLEVBQUMsQ0FBRSxJQUFJLGFBQWE7SUFDbEUsV0FBVyxVQUFVLENBQUMsR0FBRyxNQUFNLFdBQVc7S0FDeEMsSUFBSTtLQUNKLE1BQU07S0FDTixXQUFXLGlCQUFrQixlQUFlLGFBQWEsZUFBZSxZQUFhO0tBQ3JGO0lBQ0YsQ0FBQyxJQUFJLE1BQU07R0FDYjtFQUNGLENBQUM7Q0FDSDtDQUVBLFlBQVksT0FBTyxnQkFBZ0I7RUFDakMsTUFBTSxhQUFhO0dBQ2pCLElBQUksWUFBWSxNQUFNLFdBQVcsS0FBSyxJQUFJO0dBQzFDLFFBQVEsWUFBWTtHQUNwQixLQUFLLFlBQVk7R0FDakIsaUJBQWlCLFlBQVk7R0FDN0IsV0FBVyxZQUFZLGFBQWEsWUFBWSxtQkFBbUI7R0FDbkUsZ0JBQWdCLFlBQVksa0JBQWtCO0dBQzlDLGtCQUFrQixZQUFZLG9CQUFvQjtHQUNsRCxlQUFlLFlBQVksaUJBQWlCO0dBQzVDLGdCQUFnQixZQUFZLGtCQUFrQjtHQUM5QyxrQkFBa0IsWUFBWSxvQkFBb0I7R0FDbEQsZUFBZSxZQUFZLGlCQUFpQjtHQUM1QyxXQUFXLENBQUM7RUFDZDtFQUVBLEtBQUssV0FBVyxFQUNkLFdBQVcsQ0FBQyxHQUFHLE1BQU0sV0FBVyxVQUFVLEVBQzVDLEVBQUU7RUFFRixJQUFJLFVBQVUsUUFBUTtHQUNwQixJQUFJO0lBQ0YsTUFBTSxFQUFFLFVBQVUsSUFBSTtJQUN0QixNQUFNLE1BQU0sR0FBRyxhQUFhLGdCQUFnQjtLQUMxQyxRQUFRO0tBQ1IsU0FBUztNQUNQLGdCQUFnQjtNQUNoQixHQUFJLFFBQVEsRUFBRSxpQkFBaUIsVUFBVSxRQUFRLElBQUksQ0FBQztLQUN4RDtLQUNBLE1BQU0sS0FBSyxVQUFVLFVBQVU7SUFDakMsQ0FBQztHQUNILFNBQVMsR0FBRztJQUNWLFFBQVEsTUFBTSw4Q0FBOEMsQ0FBQztHQUMvRDtFQUNGO0NBQ0Y7Q0FFQSxnQkFBZ0IsY0FBYztFQUM1QixLQUFLLFdBQVcsRUFDZCxXQUFXLE1BQU0sVUFBVSxRQUFRLE1BQU0sRUFBRSxPQUFPLFNBQVMsRUFDN0QsRUFBRTtDQUNKO0NBRUEsZ0JBQWdCLE9BQU8sV0FBVyxZQUFZLGdCQUFnQjtFQUM1RCxLQUFLLFdBQVc7R0FDZCxXQUFXLE1BQU0sVUFBVSxLQUFLLE1BQU07SUFDcEMsSUFBSSxFQUFFLE9BQU8sV0FBVztLQUN0QixPQUFPO01BQ0wsR0FBRztNQUNILFlBQVksRUFBRSxhQUFhLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTTtPQUN4QyxJQUFJLEVBQUUsT0FBTyxZQUFZO1FBQ3ZCLE9BQU87U0FBRSxHQUFHO1NBQUcsR0FBRztRQUFZO09BQ2hDO09BQ0EsT0FBTztNQUNULENBQUM7S0FDSDtJQUNGO0lBQ0EsT0FBTztHQUNULENBQUM7R0FDRCxtQkFBbUIsTUFBTSxvQkFBb0IsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNO0lBQzFELElBQUksRUFBRSxPQUFPLFlBQVk7S0FDdkIsT0FBTztNQUFFLEdBQUc7TUFBRyxHQUFHO0tBQVk7SUFDaEM7SUFDQSxPQUFPO0dBQ1QsQ0FBQztHQUNELFdBQVcsQ0FBQyxHQUFHLE1BQU0sV0FBVztJQUM5QixJQUFJO0lBQ0osTUFBTTtJQUNOO0lBQ0EsU0FBUztLQUFFLElBQUk7S0FBWSxHQUFHO0tBQWEsV0FBVztJQUFVO0dBQ2xFLENBQUM7RUFDSCxFQUFFO0VBRUYsSUFBSSxVQUFVLFFBQVE7R0FDcEIsSUFBSTtJQUNGLE1BQU0sRUFBRSxVQUFVLElBQUk7SUFDdEIsTUFBTSxNQUFNLEdBQUcsYUFBYSxpQkFBaUIsY0FBYztLQUN6RCxRQUFRO0tBQ1IsU0FBUztNQUNQLGdCQUFnQjtNQUNoQixHQUFJLFNBQVMsVUFBVSx1QkFBdUIsRUFBRSxpQkFBaUIsVUFBVSxRQUFRLElBQUksQ0FBQztLQUMxRjtLQUNBLE1BQU0sS0FBSyxVQUFVLFdBQVc7SUFDbEMsQ0FBQztHQUNILFNBQVMsR0FBRztJQUNWLFFBQVEsTUFBTSxnREFBZ0QsQ0FBQztHQUNqRTtFQUNGO0NBQ0Y7Q0FFQSxnQkFBZ0IsT0FBTyxXQUFXLGVBQWU7RUFDL0MsS0FBSyxXQUFXO0dBQ2QsV0FBVyxNQUFNLFVBQVUsS0FBSyxNQUFNO0lBQ3BDLElBQUksRUFBRSxPQUFPLFdBQVc7S0FDdEIsT0FBTztNQUNMLEdBQUc7TUFDSCxZQUFZLEVBQUUsYUFBYSxDQUFDLEVBQUMsQ0FBRSxRQUFRLE1BQU0sRUFBRSxPQUFPLFVBQVU7S0FDbEU7SUFDRjtJQUNBLE9BQU87R0FDVCxDQUFDO0dBQ0QsbUJBQW1CLE1BQU0sb0JBQW9CLENBQUMsRUFBQyxDQUFFLFFBQVEsTUFBTSxFQUFFLE9BQU8sVUFBVTtHQUNsRixXQUFXLE1BQU0sVUFBVSxRQUFRLFNBQVMsS0FBSyxPQUFPLFVBQVU7RUFDcEUsRUFBRTtFQUVGLElBQUksVUFBVSxRQUFRO0dBQ3BCLElBQUk7SUFDRixNQUFNLEVBQUUsVUFBVSxJQUFJO0lBQ3RCLE1BQU0sTUFBTSxHQUFHLGFBQWEsaUJBQWlCLGNBQWM7S0FDekQsUUFBUTtLQUNSLFNBQVMsRUFDUCxHQUFJLFFBQVEsRUFBRSxpQkFBaUIsVUFBVSxRQUFRLElBQUksQ0FBQyxFQUN4RDtJQUNGLENBQUM7R0FDSCxTQUFTLEdBQUc7SUFDVixRQUFRLE1BQU0sNENBQTRDLENBQUM7R0FDN0Q7RUFDRjtDQUNGO0NBRUEsa0JBQWtCLGtCQUFrQjtFQUNsQyxNQUFNLGVBQWUsY0FBYyxLQUFLLE9BQU87R0FDN0MsR0FBRztHQUNILFlBQVksRUFBRSxhQUFhLENBQUMsRUFBQyxDQUFFLEtBQUssT0FBTztJQUN6QyxHQUFHO0lBQ0gscUJBQXFCLEVBQUUsdUJBQXVCLEVBQUUsWUFBWSxDQUFDO0lBQzdELHlCQUF5QixFQUFFLDJCQUEyQixFQUFFLGlCQUFpQixDQUFDO0lBQzFFLGdCQUFnQixFQUFFLGtCQUFrQixDQUFDO0lBQ3JDLFNBQVMsRUFBRSxXQUFXLENBQUM7R0FDekIsRUFBRTtFQUNKLEVBQUU7RUFDRixJQUFJLEVBQUUsV0FBVyxhQUFhLENBQUM7Q0FDakM7Q0FFQSxjQUFjLFFBQVEsYUFBYSxjQUFjO0VBQy9DLE1BQU0sRUFBRSxjQUFjLElBQUk7RUFDMUIsTUFBTSxVQUFVLFVBQVUsTUFBTSxNQUFNLEVBQUUsT0FBTyxTQUFTO0VBQ3hELElBQUksQ0FBQyxTQUFTLE9BQU87R0FBRSxTQUFTO0dBQU8sT0FBTztFQUF5QjtFQUV2RSxNQUFNLFNBQVMsT0FBTyxXQUFXO0VBRWpDLE1BQU0sZ0JBQWdCO0dBQ3BCLElBQUk7R0FDSjtHQUNBLGFBQWEsZUFBZTtHQUM1QixXQUFXO0dBQ1gscUJBQXFCLENBQUM7R0FDdEIseUJBQXlCLENBQUM7R0FDMUIsZ0JBQWdCLENBQUM7R0FDakIsU0FBUyxDQUFDO0dBQ1YsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDcEM7RUFFQSxLQUFLLFdBQVc7R0FDZCxXQUFXLE1BQU0sVUFBVSxLQUFLLE1BQU07SUFDcEMsSUFBSSxFQUFFLE9BQU8sV0FBVztLQUN0QixPQUFPO01BQ0wsR0FBRztNQUNILFdBQVcsQ0FBQyxlQUFlLEdBQUksRUFBRSxhQUFhLENBQUMsQ0FBRTtLQUNuRDtJQUNGO0lBQ0EsT0FBTztHQUNULENBQUM7R0FDRCxrQkFBa0IsQ0FBQyxHQUFJLE1BQU0sb0JBQW9CLENBQUMsR0FBSSxhQUFhO0dBQ25FLFdBQVcsQ0FBQyxHQUFHLE1BQU0sV0FBVztJQUM5QixJQUFJO0lBQ0osTUFBTTtJQUNOO0lBQ0EsU0FBUztHQUNYLENBQUM7RUFDSCxFQUFFO0VBRUYsT0FBTztHQUFFLFNBQVM7R0FBTSxVQUFVO0VBQWM7Q0FDbEQ7O0NBR0Esc0JBQXNCLE1BQU0sU0FBUztFQUNuQyxJQUFJLGFBQWEsT0FBTyxTQUFTLFdBQVcsT0FBUSxNQUFNLGNBQWMsTUFBTTtFQUM5RSxNQUFNLGVBQWUsT0FBTyxTQUFTLFdBQVcsT0FBTztFQUN2RCxNQUFNLFlBQVksY0FBYyxhQUFhLGNBQWMsY0FBYyxPQUFPLFNBQVMsV0FBVyxPQUFPLE1BQU07RUFFakgsTUFBTSxFQUFFLGNBQWMsSUFBSTtFQUMxQixJQUFJLGtCQUFrQjtFQUN0QixJQUFJLGlCQUFpQjtFQUVyQixJQUFJLFlBQVk7R0FDZCxLQUFLLE1BQU0sV0FBVyxXQUFXO0lBQy9CLE1BQU0sUUFBUSxRQUFRLGFBQWEsQ0FBQyxFQUFDLENBQUUsTUFBTSxNQUFNLEVBQUUsT0FBTyxVQUFVO0lBQ3RFLElBQUksTUFBTTtLQUNSLGtCQUFrQixRQUFRO0tBQzFCLGlCQUFpQjtLQUNqQjtJQUNGO0dBQ0Y7RUFDRixPQUFPOztHQUVMLElBQUksQ0FBQyxtQkFBbUIsVUFBVSxTQUFTLEdBQUc7SUFDNUMsa0JBQWtCLFVBQVUsRUFBRSxDQUFDO0dBQ2pDO0VBQ0Y7RUFFQSxJQUFJLGNBQWMsQ0FBQyxnQkFBZ0IsT0FBTztHQUFFLFNBQVM7R0FBTyxPQUFPO0VBQThDO0VBRWpILElBQUksU0FBUyxhQUFhO0VBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxTQUFTLEdBQUcsR0FBRztHQUNwQyxTQUFTLGlCQUFpQixhQUFhLGdCQUFnQixXQUFXLElBQUksQ0FBQztFQUN6RTtFQUVBLE1BQU0sY0FBZSxhQUFhLFVBQVUsYUFBYSxPQUFPLEtBQUssSUFDakUsYUFBYSxPQUFPLEtBQUssSUFDekI7RUFFSixNQUFNLGdCQUFnQjtHQUNwQixJQUFJO0dBQ0osUUFBUTtHQUNSLGNBQWMsYUFBYSxnQkFBZ0I7R0FDM0MsV0FBVyxhQUFhLGFBQWE7R0FDckMsZUFBZSxhQUFhLGlCQUFpQjtHQUM3QyxNQUFNLGFBQWEsUUFBUTtHQUMzQixVQUFVLGFBQWEsWUFBWTtHQUNuQyx3QkFBd0IsYUFBYSwwQkFBMEI7R0FDL0QsZUFBZSxhQUFhLGlCQUFpQixDQUFDO0dBQzlDLFlBQVksY0FBYztHQUMxQixXQUFXO0dBQ1gsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDcEM7RUFFQSxLQUFLLFdBQVc7R0FDZCxXQUFXLE1BQU0sVUFBVSxLQUFLLE1BQU07SUFDcEMsSUFBSSxFQUFFLE9BQU8saUJBQWlCO0tBQzVCLElBQUksWUFBWTtNQUNkLE9BQU87T0FDTCxHQUFHO09BQ0gsV0FBVyxFQUFFLFVBQVUsS0FBSyxNQUFNO1FBQ2hDLElBQUksRUFBRSxPQUFPLFlBQVk7U0FDdkIsTUFBTSxZQUFZLEVBQUUsdUJBQXVCLEVBQUUsWUFBWSxDQUFDO1NBQzFELE9BQU87VUFDTCxHQUFHO1VBQ0gscUJBQXFCLENBQUMsR0FBRyxXQUFXLGFBQWE7U0FDbkQ7UUFDRjtRQUNBLE9BQU87T0FDVCxDQUFDO01BQ0g7S0FDRixPQUFPO01BQ0wsTUFBTSxnQkFBZ0IsRUFBRSx1QkFBdUIsQ0FBQztNQUNoRCxPQUFPO09BQ0wsR0FBRztPQUNILHFCQUFxQixDQUFDLEdBQUcsZUFBZSxhQUFhO01BQ3ZEO0tBQ0Y7SUFDRjtJQUNBLE9BQU87R0FDVCxDQUFDO0dBQ0Qsa0JBQWtCLENBQUMsR0FBSSxNQUFNLG9CQUFvQixDQUFDLEdBQUksYUFBYTtHQUNuRSxXQUFXLENBQUMsR0FBRyxNQUFNLFdBQVc7SUFDOUIsSUFBSTtJQUNKLE1BQU07SUFDTixXQUFXO0lBQ1gsU0FBUztHQUNYLENBQUM7RUFDSCxFQUFFO0VBRUYsT0FBTztHQUFFLFNBQVM7R0FBTSxVQUFVO0VBQWM7Q0FDbEQ7Q0FFQSx5QkFBeUIsWUFBWSxZQUFZLGdCQUFnQjtFQUMvRCxLQUFLLFVBQVU7R0FDYixNQUFNLG1CQUFtQixNQUFNLFVBQVUsS0FBSyxNQUFNO0lBQ2xELElBQUksQ0FBQyxZQUFZO0tBQ2YsTUFBTSxPQUFPLEVBQUUsdUJBQXVCLENBQUM7S0FDdkMsT0FBTztNQUNMLEdBQUc7TUFDSCxxQkFBcUIsS0FBSyxLQUFLLE1BQU07T0FDbkMsSUFBSSxFQUFFLE9BQU8sWUFBWTtRQUN2QixPQUFPO1NBQUUsR0FBRztTQUFHLEdBQUc7UUFBWTtPQUNoQztPQUNBLE9BQU87TUFDVCxDQUFDO0tBQ0g7SUFDRjtJQUNBLE9BQU87S0FDTCxHQUFHO0tBQ0gsWUFBWSxFQUFFLGFBQWEsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNO01BQ3hDLElBQUksRUFBRSxPQUFPLFlBQVk7T0FDdkIsTUFBTSxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsWUFBWSxDQUFDO09BQ3JELE9BQU87UUFDTCxHQUFHO1FBQ0gscUJBQXFCLEtBQUssS0FBSyxNQUFNO1NBQ25DLElBQUksRUFBRSxPQUFPLFlBQVk7VUFDdkIsT0FBTztXQUFFLEdBQUc7V0FBRyxHQUFHO1VBQVk7U0FDaEM7U0FDQSxPQUFPO1FBQ1QsQ0FBQztPQUNIO01BQ0Y7TUFDQSxPQUFPO0tBQ1QsQ0FBQztJQUNIO0dBQ0YsQ0FBQztHQUVELE1BQU0sMkJBQTJCLE1BQU0sb0JBQW9CLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTTtJQUN4RSxJQUFJLEVBQUUsT0FBTyxZQUFZO0tBQ3ZCLE9BQU87TUFBRSxHQUFHO01BQUcsR0FBRztLQUFZO0lBQ2hDO0lBQ0EsT0FBTztHQUNULENBQUM7R0FFRCxJQUFJLFVBQVU7R0FDZCxNQUFNLG1CQUFtQixNQUFNLFVBQVUsS0FBSyxTQUFTO0lBQ3JELElBQUksS0FBSyxPQUFPLGVBQWUsS0FBSyxTQUFTLHVCQUF1QixLQUFLLFNBQVMsWUFBWTtLQUM1RixVQUFVO0tBQ1YsT0FBTztNQUFFLEdBQUc7TUFBTSxTQUFTO09BQUUsR0FBRyxLQUFLO09BQVMsR0FBRztNQUFZO0tBQUU7SUFDakU7SUFDQSxPQUFPO0dBQ1QsQ0FBQztHQUVELElBQUksQ0FBQyxTQUFTO0lBQ1osSUFBSSxpQkFBaUIsd0JBQXdCLE1BQUssTUFBSyxFQUFFLE9BQU8sVUFBVTtJQUMxRSxJQUFJLENBQUMsZ0JBQWdCO0tBQ25CLEtBQUssTUFBTSxLQUFLLGtCQUFrQjtNQUNoQyxNQUFNLE9BQU8sYUFDUixFQUFFLFdBQVcsTUFBSyxNQUFLLEVBQUUsT0FBTyxVQUFVLENBQUMsRUFBRSx1QkFBdUIsQ0FBQyxJQUNyRSxFQUFFLHVCQUF1QixDQUFDO01BQy9CLE1BQU0sUUFBUSxLQUFLLE1BQUssTUFBSyxFQUFFLE9BQU8sVUFBVTtNQUNoRCxJQUFJLE9BQU87T0FDVCxpQkFBaUI7T0FDakI7TUFDRjtLQUNGO0lBQ0Y7SUFDQSxJQUFJLGdCQUFnQjtLQUNsQixpQkFBaUIsS0FBSztNQUNwQixJQUFJO01BQ0osTUFBTTtNQUNOLFdBQVcsZUFBZSxhQUFhLGVBQWUsYUFBYyxNQUFNLFVBQVUsRUFBRSxFQUFFLE1BQU07TUFDOUYsU0FBUztLQUNYLENBQUM7SUFDSDtHQUNGO0dBRUEsT0FBTztJQUNMLFdBQVc7SUFDWCxrQkFBa0I7SUFDbEIsV0FBVztHQUNiO0VBQ0YsQ0FBQztDQUNIO0NBRUEsd0JBQXdCLE9BQU8sWUFBWSxlQUFlO0VBQ3hELEtBQUssV0FBVztHQUNkLFdBQVcsTUFBTSxVQUFVLEtBQUssTUFBTTtJQUNwQyxJQUFJLENBQUMsWUFBWTtLQUNmLE1BQU0sT0FBTyxFQUFFLHVCQUF1QixDQUFDO0tBQ3ZDLE9BQU87TUFDTCxHQUFHO01BQ0gscUJBQXFCLEtBQUssUUFBUSxNQUFNLEVBQUUsT0FBTyxVQUFVO0tBQzdEO0lBQ0Y7SUFDQSxPQUFPO0tBQ0wsR0FBRztLQUNILFlBQVksRUFBRSxhQUFhLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTTtNQUN4QyxJQUFJLEVBQUUsT0FBTyxZQUFZO09BQ3ZCLE1BQU0sT0FBTyxFQUFFLHVCQUF1QixFQUFFLFlBQVksQ0FBQztPQUNyRCxPQUFPO1FBQ0wsR0FBRztRQUNILHFCQUFxQixLQUFLLFFBQVEsTUFBTSxFQUFFLE9BQU8sVUFBVTtPQUM3RDtNQUNGO01BQ0EsT0FBTztLQUNULENBQUM7SUFDSDtHQUNGLENBQUM7R0FDRCxtQkFBbUIsTUFBTSxvQkFBb0IsQ0FBQyxFQUFDLENBQUUsUUFBUSxNQUFNLEVBQUUsT0FBTyxVQUFVO0dBQ2xGLFdBQVcsTUFBTSxVQUFVLFFBQVEsU0FBUyxLQUFLLE9BQU8sVUFBVTtFQUNwRSxFQUFFO0VBRUYsSUFBSSxVQUFVLFFBQVE7R0FDcEIsSUFBSTtJQUNGLE1BQU0sRUFBRSxVQUFVLElBQUk7SUFDdEIsTUFBTSxNQUFNLEdBQUcsYUFBYSw0QkFBNEIsY0FBYztLQUNwRSxRQUFRO0tBQ1IsU0FBUyxFQUNQLEdBQUksUUFBUSxFQUFFLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxDQUFDLEVBQ3hEO0lBQ0YsQ0FBQztHQUNILFNBQVMsR0FBRztJQUNWLFFBQVEsTUFBTSxxREFBcUQsQ0FBQztHQUN0RTtFQUNGO0NBQ0Y7Q0FFQSxhQUFhLFlBQVksZ0JBQWdCO0VBQ3ZDLE9BQU8sSUFBSSxDQUFDLENBQUMsb0JBQW9CLFlBQVk7R0FDM0MsR0FBRztHQUNILGNBQWM7R0FDZCxlQUFlO0lBQ2IsVUFBVSxZQUFZLFlBQVk7SUFDbEMsbUJBQW1CLFlBQVkscUJBQXFCO0tBQUUsSUFBSTtLQUFLLElBQUk7S0FBSyxJQUFJO0lBQUk7SUFDaEYsa0JBQWtCLFlBQVksb0JBQW9CO0tBQUUsT0FBTztLQUFJLE1BQU07S0FBSSxLQUFLO0lBQUc7SUFDakYsU0FBUyxZQUFZLFdBQVc7S0FBRSxJQUFJO0tBQU8sSUFBSTtLQUFPLElBQUk7SUFBTTtJQUNsRSxXQUFXLFlBQVksYUFBYTtJQUNwQyxVQUFVLFlBQVksWUFBWSxDQUFDO0lBQ25DLGVBQWUsWUFBWSxpQkFBaUI7S0FBRSxTQUFTO0tBQUksZUFBZTtJQUFHO0lBQzdFLGNBQWMsWUFBWSxnQkFBZ0I7S0FBRSxTQUFTO0tBQUksZUFBZTtJQUFHO0dBQzdFO0VBQ0YsQ0FBQztDQUNIO0NBRUEsZ0JBQWdCLFlBQVksV0FBVyxnQkFBZ0I7RUFDckQsSUFBSSxDQUFDLENBQUMsdUJBQXVCLFlBQVksV0FBVyxXQUFXO0NBQ2pFO0NBRUEsZ0JBQWdCLFlBQVksY0FBYztFQUN4QyxJQUFJLENBQUMsQ0FBQyx1QkFBdUIsWUFBWSxTQUFTO0NBQ3BEO0NBRUEsMkJBQTJCLFlBQVksWUFBWTtFQUNqRCxNQUFNLEVBQUUsY0FBYyxJQUFJO0VBRTFCLElBQUksa0JBQWtCO0VBQ3RCLElBQUksaUJBQWlCO0VBRXJCLEtBQUssTUFBTSxXQUFXLFdBQVc7R0FDL0IsTUFBTSxRQUFRLFFBQVEsYUFBYSxDQUFDLEVBQUMsQ0FBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLFVBQVU7R0FDdEUsSUFBSSxNQUFNO0lBQ1Isa0JBQWtCLFFBQVE7SUFDMUIsaUJBQWlCO0lBQ2pCO0dBQ0Y7RUFDRjtFQUVBLElBQUksQ0FBQyxnQkFBZ0IsT0FBTztHQUFFLFNBQVM7R0FBTyxPQUFPO0VBQTBCO0VBRS9FLElBQUksU0FBUyxRQUFRO0VBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxTQUFTLEdBQUcsR0FBRztHQUNwQyxTQUFTLGlCQUFpQixlQUFlLElBQUksQ0FBQztFQUNoRDtFQUVBLE1BQU0sY0FBZSxRQUFRLFVBQVUsUUFBUSxPQUFPLEtBQUssSUFDdkQsUUFBUSxPQUFPLEtBQUssSUFDcEI7RUFFSixNQUFNLG1CQUFtQjtHQUN2QixHQUFHO0dBQ0gsSUFBSTtHQUNKLFFBQVE7R0FDUjtHQUNBLFdBQVc7R0FDWCxlQUFlO0dBQ2YsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDcEM7RUFFQSxLQUFLLFdBQVc7R0FDZCxXQUFXLE1BQU0sVUFBVSxLQUFLLE1BQU07SUFDcEMsSUFBSSxFQUFFLE9BQU8saUJBQWlCO0tBQzVCLE9BQU87TUFDTCxHQUFHO01BQ0gsV0FBVyxFQUFFLFVBQVUsS0FBSyxNQUFNO09BQ2hDLElBQUksRUFBRSxPQUFPLFlBQVk7UUFDdkIsTUFBTSxnQkFBZ0IsRUFBRSwyQkFBMkIsRUFBRSxpQkFBaUIsQ0FBQztRQUN2RSxPQUFPO1NBQ0wsR0FBRztTQUNILHlCQUF5QixDQUFDLEdBQUcsZUFBZSxnQkFBZ0I7UUFDOUQ7T0FDRjtPQUNBLE9BQU87TUFDVCxDQUFDO0tBQ0g7SUFDRjtJQUNBLE9BQU87R0FDVCxDQUFDO0dBQ0Qsc0JBQXNCLENBQUMsR0FBSSxNQUFNLHdCQUF3QixDQUFDLEdBQUksZ0JBQWdCO0dBQzlFLFdBQVcsQ0FBQyxHQUFHLE1BQU0sV0FBVztJQUM5QixJQUFJO0lBQ0osTUFBTTtJQUNOLFdBQVc7SUFDWCxTQUFTO0dBQ1gsQ0FBQztFQUNILEVBQUU7RUFFRixPQUFPO0dBQUUsU0FBUztHQUFNLGFBQWE7RUFBaUI7Q0FDeEQ7Q0FFQSxvQkFBb0IsWUFBWSxlQUFlLGdCQUFnQjtFQUM3RCxLQUFLLFVBQVU7R0FDYixNQUFNLG1CQUFtQixNQUFNLFVBQVUsS0FBSyxPQUFPO0lBQ25ELEdBQUc7SUFDSCxZQUFZLEVBQUUsYUFBYSxDQUFDLEVBQUMsQ0FBRSxLQUFLLE1BQU07S0FDeEMsSUFBSSxFQUFFLE9BQU8sWUFBWTtNQUN2QixNQUFNLGdCQUFnQixFQUFFLDJCQUEyQixFQUFFLGlCQUFpQixDQUFDO01BQ3ZFLE9BQU87T0FDTCxHQUFHO09BQ0gseUJBQXlCLGNBQWMsS0FBSyxNQUFNO1FBQ2hELElBQUksRUFBRSxPQUFPLGVBQWU7U0FDMUIsT0FBTztVQUFFLEdBQUc7VUFBRyxHQUFHO1NBQVk7UUFDaEM7UUFDQSxPQUFPO09BQ1QsQ0FBQztNQUNIO0tBQ0Y7S0FDQSxPQUFPO0lBQ1QsQ0FBQztHQUNILEVBQUU7R0FFRixNQUFNLCtCQUErQixNQUFNLHdCQUF3QixDQUFDLEVBQUMsQ0FBRSxLQUFLLE1BQU07SUFDaEYsSUFBSSxFQUFFLE9BQU8sZUFBZTtLQUMxQixPQUFPO01BQUUsR0FBRztNQUFHLEdBQUc7S0FBWTtJQUNoQztJQUNBLE9BQU87R0FDVCxDQUFDO0dBRUQsTUFBTSxtQkFBbUIsTUFBTSxVQUFVLEtBQUssU0FBUztJQUNyRCxJQUFJLEtBQUssT0FBTyxpQkFBaUIsS0FBSyxTQUFTLGVBQWU7S0FDNUQsT0FBTztNQUFFLEdBQUc7TUFBTSxTQUFTO09BQUUsR0FBRyxLQUFLO09BQVMsR0FBRztNQUFZO0tBQUU7SUFDakU7SUFDQSxPQUFPO0dBQ1QsQ0FBQztHQUVELE9BQU87SUFDTCxXQUFXO0lBQ1gsc0JBQXNCO0lBQ3RCLFdBQVc7R0FDYjtFQUNGLENBQUM7Q0FDSDtDQUVBLG1CQUFtQixPQUFPLFlBQVksa0JBQWtCO0VBQ3RELEtBQUssV0FBVztHQUNkLFdBQVcsTUFBTSxVQUFVLEtBQUssT0FBTztJQUNyQyxHQUFHO0lBQ0gsWUFBWSxFQUFFLGFBQWEsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNO0tBQ3hDLElBQUksRUFBRSxPQUFPLFlBQVk7TUFDdkIsTUFBTSxnQkFBZ0IsRUFBRSwyQkFBMkIsRUFBRSxpQkFBaUIsQ0FBQztNQUN2RSxPQUFPO09BQ0wsR0FBRztPQUNILHlCQUF5QixjQUFjLFFBQVEsTUFBTSxFQUFFLE9BQU8sYUFBYTtNQUM3RTtLQUNGO0tBQ0EsT0FBTztJQUNULENBQUM7R0FDSCxFQUFFO0dBQ0YsdUJBQXVCLE1BQU0sd0JBQXdCLENBQUMsRUFBQyxDQUFFLFFBQVEsTUFBTSxFQUFFLE9BQU8sYUFBYTtHQUM3RixXQUFXLE1BQU0sVUFBVSxRQUFRLFNBQVMsS0FBSyxPQUFPLGFBQWE7RUFDdkUsRUFBRTtFQUVGLElBQUksVUFBVSxRQUFRO0dBQ3BCLElBQUk7SUFDRixNQUFNLEVBQUUsVUFBVSxJQUFJO0lBQ3RCLE1BQU0sTUFBTSxHQUFHLGFBQWEscUJBQXFCLGlCQUFpQjtLQUNoRSxRQUFRO0tBQ1IsU0FBUyxFQUNQLEdBQUksUUFBUSxFQUFFLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxDQUFDLEVBQ3hEO0lBQ0YsQ0FBQztHQUNILFNBQVMsR0FBRztJQUNWLFFBQVEsTUFBTSw2REFBNkQsQ0FBQztHQUM5RTtFQUNGO0NBQ0Y7Q0FFQSxtQkFBbUIsWUFBWSxZQUFZO0VBQ3pDLE1BQU0sRUFBRSxjQUFjLElBQUk7RUFFMUIsSUFBSSxrQkFBa0I7RUFDdEIsSUFBSSxpQkFBaUI7RUFFckIsS0FBSyxNQUFNLFdBQVcsV0FBVztHQUMvQixNQUFNLFFBQVEsUUFBUSxhQUFhLENBQUMsRUFBQyxDQUFFLE1BQU0sTUFBTSxFQUFFLE9BQU8sVUFBVTtHQUN0RSxJQUFJLE1BQU07SUFDUixrQkFBa0IsUUFBUTtJQUMxQixpQkFBaUI7SUFDakI7R0FDRjtFQUNGO0VBRUEsSUFBSSxTQUFTLFFBQVE7RUFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLFNBQVMsR0FBRyxHQUFHO0dBQ3BDLFNBQVMsaUJBQWlCLGtCQUFrQixJQUFJLENBQUM7RUFDbkQ7RUFFQSxNQUFNLGNBQWUsUUFBUSxVQUFVLFFBQVEsT0FBTyxLQUFLLElBQ3ZELFFBQVEsT0FBTyxLQUFLLElBQ3BCO0VBRUosTUFBTSxhQUFhO0dBQ2pCLEdBQUc7R0FDSCxJQUFJO0dBQ0osUUFBUTtHQUNSO0dBQ0EsV0FBVztHQUNYLGVBQWU7R0FDZixXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtFQUNwQztFQUVBLEtBQUssV0FBVztHQUNkLFdBQVcsTUFBTSxVQUFVLEtBQUssTUFBTTtJQUNwQyxJQUFJLEVBQUUsT0FBTyxpQkFBaUI7S0FDNUIsT0FBTztNQUNMLEdBQUc7TUFDSCxXQUFXLEVBQUUsVUFBVSxLQUFLLE1BQU07T0FDaEMsSUFBSSxFQUFFLE9BQU8sWUFBWTtRQUN2QixNQUFNLFNBQVMsRUFBRSxrQkFBa0IsQ0FBQztRQUNwQyxPQUFPO1NBQ0wsR0FBRztTQUNILGdCQUFnQixDQUFDLEdBQUcsUUFBUSxVQUFVO1FBQ3hDO09BQ0Y7T0FDQSxPQUFPO01BQ1QsQ0FBQztLQUNIO0lBQ0Y7SUFDQSxPQUFPO0dBQ1QsQ0FBQztHQUNELHVCQUF1QixDQUFDLEdBQUksTUFBTSx5QkFBeUIsQ0FBQyxHQUFJLFVBQVU7R0FDMUUsV0FBVyxDQUFDLEdBQUcsTUFBTSxXQUFXO0lBQzlCLElBQUk7SUFDSixNQUFNO0lBQ04sV0FBVztJQUNYLFNBQVM7R0FDWCxDQUFDO0VBQ0gsRUFBRTtFQUVGLE9BQU87R0FBRSxTQUFTO0dBQU0sZUFBZTtFQUFXO0NBQ3BEO0NBRUEsc0JBQXNCLFlBQVksU0FBUyxnQkFBZ0I7RUFDekQsS0FBSyxVQUFVO0dBQ2IsTUFBTSxtQkFBbUIsTUFBTSxVQUFVLEtBQUssT0FBTztJQUNuRCxHQUFHO0lBQ0gsc0JBQXNCLEVBQUUsdUJBQXVCLENBQUMsRUFBQyxDQUFFLEtBQUssU0FBUztLQUMvRCxJQUFJLEtBQUssT0FBTyxTQUFTO01BQ3ZCLE9BQU87T0FBRSxHQUFHO09BQU0sR0FBRztNQUFZO0tBQ25DO0tBQ0EsT0FBTztJQUNULENBQUM7SUFDRCxZQUFZLEVBQUUsYUFBYSxDQUFDLEVBQUMsQ0FBRSxLQUFLLE1BQU07S0FDeEMsTUFBTSxjQUFjLENBQUMsY0FBYyxFQUFFLE9BQU87S0FDNUMsTUFBTSxTQUFTLEVBQUUsa0JBQWtCLENBQUM7S0FDcEMsTUFBTSxZQUFZLEVBQUUsdUJBQXVCLENBQUM7S0FDNUMsT0FBTztNQUNMLEdBQUc7TUFDSCxnQkFBZ0IsT0FBTyxLQUFLLFNBQVM7T0FDbkMsSUFBSSxLQUFLLE9BQU8sU0FBUztRQUN2QixPQUFPO1NBQUUsR0FBRztTQUFNLEdBQUc7UUFBWTtPQUNuQztPQUNBLE9BQU87TUFDVCxDQUFDO01BQ0QscUJBQXFCLGNBQWMsVUFBVSxLQUFLLFNBQVM7T0FDekQsSUFBSSxLQUFLLE9BQU8sU0FBUztRQUN2QixPQUFPO1NBQUUsR0FBRztTQUFNLEdBQUc7UUFBWTtPQUNuQztPQUNBLE9BQU87TUFDVCxDQUFDLElBQUk7S0FDUDtJQUNGLENBQUM7R0FDSCxFQUFFO0dBRUYsTUFBTSx3QkFBd0IsTUFBTSx5QkFBeUIsQ0FBQyxFQUFDLENBQUUsS0FBSyxTQUFTO0lBQzdFLElBQUksS0FBSyxPQUFPLFNBQVM7S0FDdkIsT0FBTztNQUFFLEdBQUc7TUFBTSxHQUFHO0tBQVk7SUFDbkM7SUFDQSxPQUFPO0dBQ1QsQ0FBQztHQUVELE1BQU0sbUJBQW1CLE1BQU0sVUFBVSxLQUFLLFNBQVM7SUFDckQsSUFBSSxLQUFLLE9BQU8sWUFBWSxLQUFLLFNBQVMsb0JBQW9CLEtBQUssU0FBUyxzQkFBc0I7S0FDaEcsT0FBTztNQUFFLEdBQUc7TUFBTSxTQUFTO09BQUUsR0FBRyxLQUFLO09BQVMsR0FBRztNQUFZO0tBQUU7SUFDakU7SUFDQSxPQUFPO0dBQ1QsQ0FBQztHQUVELE9BQU87SUFDTCxXQUFXO0lBQ1gsdUJBQXVCO0lBQ3ZCLFdBQVc7R0FDYjtFQUNGLENBQUM7Q0FDSDtDQUVBLHFCQUFxQixPQUFPLFlBQVksWUFBWTtFQUNsRCxLQUFLLFdBQVc7R0FDZCxXQUFXLE1BQU0sVUFBVSxLQUFLLE9BQU87SUFDckMsR0FBRztJQUNILFlBQVksRUFBRSxhQUFhLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTTtLQUN4QyxJQUFJLEVBQUUsT0FBTyxZQUFZO01BQ3ZCLE1BQU0sU0FBUyxFQUFFLGtCQUFrQixDQUFDO01BQ3BDLE9BQU87T0FDTCxHQUFHO09BQ0gsZ0JBQWdCLE9BQU8sUUFBUSxTQUFTLEtBQUssT0FBTyxPQUFPO01BQzdEO0tBQ0Y7S0FDQSxPQUFPO0lBQ1QsQ0FBQztHQUNILEVBQUU7R0FDRix3QkFBd0IsTUFBTSx5QkFBeUIsQ0FBQyxFQUFDLENBQUUsUUFBUSxTQUFTLEtBQUssT0FBTyxPQUFPO0dBQy9GLFdBQVcsTUFBTSxVQUFVLFFBQVEsU0FBUyxLQUFLLE9BQU8sT0FBTztFQUNqRSxFQUFFO0VBRUYsSUFBSSxVQUFVLFFBQVE7R0FDcEIsSUFBSTtJQUNGLE1BQU0sRUFBRSxVQUFVLElBQUk7SUFDdEIsTUFBTSxNQUFNLEdBQUcsYUFBYSx1QkFBdUIsV0FBVztLQUM1RCxRQUFRO0tBQ1IsU0FBUyxFQUNQLEdBQUksUUFBUSxFQUFFLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxDQUFDLEVBQ3hEO0lBQ0YsQ0FBQztHQUNILFNBQVMsR0FBRztJQUNWLFFBQVEsTUFBTSxxREFBcUQsQ0FBQztHQUN0RTtFQUNGO0NBQ0Y7Q0FFQSxTQUFTLFlBQVksWUFBWTtFQUMvQixNQUFNLEVBQUUsY0FBYyxJQUFJO0VBRTFCLElBQUksa0JBQWtCO0VBQ3RCLElBQUksaUJBQWlCO0VBRXJCLEtBQUssTUFBTSxXQUFXLFdBQVc7R0FDL0IsTUFBTSxRQUFRLFFBQVEsYUFBYSxDQUFDLEVBQUMsQ0FBRSxNQUFNLE1BQU0sRUFBRSxPQUFPLFVBQVU7R0FDdEUsSUFBSSxNQUFNO0lBQ1Isa0JBQWtCLFFBQVE7SUFDMUIsaUJBQWlCO0lBQ2pCO0dBQ0Y7RUFDRjtFQUVBLElBQUksU0FBUyxRQUFRO0VBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxTQUFTLEdBQUcsR0FBRztHQUNwQyxTQUFTLGlCQUFpQixPQUFPLElBQUksQ0FBQztFQUN4QztFQUVBLE1BQU0sY0FBZSxRQUFRLFVBQVUsUUFBUSxPQUFPLEtBQUssSUFDdkQsUUFBUSxPQUFPLEtBQUssSUFDcEI7RUFFSixNQUFNLFdBQVc7R0FDZixHQUFHO0dBQ0gsSUFBSTtHQUNKLFFBQVE7R0FDUjtHQUNBLFdBQVc7R0FDWCxlQUFlO0dBQ2YsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDcEM7RUFFQSxLQUFLLFdBQVc7R0FDZCxXQUFXLE1BQU0sVUFBVSxLQUFLLE1BQU07SUFDcEMsSUFBSSxFQUFFLE9BQU8saUJBQWlCO0tBQzVCLE9BQU87TUFDTCxHQUFHO01BQ0gsV0FBVyxFQUFFLFVBQVUsS0FBSyxNQUFNO09BQ2hDLElBQUksRUFBRSxPQUFPLFlBQVk7UUFDdkIsTUFBTSxXQUFXLEVBQUUsV0FBVyxDQUFDO1FBQy9CLE9BQU87U0FDTCxHQUFHO1NBQ0gsU0FBUyxDQUFDLEdBQUcsVUFBVSxRQUFRO1FBQ2pDO09BQ0Y7T0FDQSxPQUFPO01BQ1QsQ0FBQztLQUNIO0lBQ0Y7SUFDQSxPQUFPO0dBQ1QsQ0FBQztHQUNELFlBQVksQ0FBQyxHQUFJLE1BQU0sY0FBYyxDQUFDLEdBQUksUUFBUTtHQUNsRCxXQUFXLENBQUMsR0FBRyxNQUFNLFdBQVc7SUFDOUIsSUFBSTtJQUNKLE1BQU07SUFDTixXQUFXO0lBQ1gsU0FBUztHQUNYLENBQUM7RUFDSCxFQUFFO0VBRUYsT0FBTztHQUFFLFNBQVM7R0FBTSxLQUFLO0VBQVM7Q0FDeEM7Q0FFQSxZQUFZLFlBQVksT0FBTyxnQkFBZ0I7RUFDN0MsS0FBSyxVQUFVO0dBQ2IsTUFBTSxtQkFBbUIsTUFBTSxVQUFVLEtBQUssT0FBTztJQUNuRCxHQUFHO0lBQ0gsWUFBWSxFQUFFLGFBQWEsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNO0tBQ3hDLElBQUksRUFBRSxPQUFPLFlBQVk7TUFDdkIsTUFBTSxXQUFXLEVBQUUsV0FBVyxDQUFDO01BQy9CLE9BQU87T0FDTCxHQUFHO09BQ0gsU0FBUyxTQUFTLEtBQUssU0FBUztRQUM5QixJQUFJLEtBQUssT0FBTyxPQUFPO1NBQ3JCLE9BQU87VUFBRSxHQUFHO1VBQU0sR0FBRztTQUFZO1FBQ25DO1FBQ0EsT0FBTztPQUNULENBQUM7TUFDSDtLQUNGO0tBQ0EsT0FBTztJQUNULENBQUM7R0FDSCxFQUFFO0dBRUYsTUFBTSxxQkFBcUIsTUFBTSxjQUFjLENBQUMsRUFBQyxDQUFFLEtBQUssU0FBUztJQUMvRCxJQUFJLEtBQUssT0FBTyxPQUFPO0tBQ3JCLE9BQU87TUFBRSxHQUFHO01BQU0sR0FBRztLQUFZO0lBQ25DO0lBQ0EsT0FBTztHQUNULENBQUM7R0FFRCxNQUFNLG1CQUFtQixNQUFNLFVBQVUsS0FBSyxTQUFTO0lBQ3JELElBQUksS0FBSyxPQUFPLFNBQVMsS0FBSyxTQUFTLE9BQU87S0FDNUMsT0FBTztNQUFFLEdBQUc7TUFBTSxTQUFTO09BQUUsR0FBRyxLQUFLO09BQVMsR0FBRztNQUFZO0tBQUU7SUFDakU7SUFDQSxPQUFPO0dBQ1QsQ0FBQztHQUVELE9BQU87SUFDTCxXQUFXO0lBQ1gsWUFBWTtJQUNaLFdBQVc7R0FDYjtFQUNGLENBQUM7Q0FDSDtDQUVBLFdBQVcsT0FBTyxZQUFZLFVBQVU7RUFDdEMsS0FBSyxXQUFXO0dBQ2QsV0FBVyxNQUFNLFVBQVUsS0FBSyxPQUFPO0lBQ3JDLEdBQUc7SUFDSCxZQUFZLEVBQUUsYUFBYSxDQUFDLEVBQUMsQ0FBRSxLQUFLLE1BQU07S0FDeEMsSUFBSSxFQUFFLE9BQU8sWUFBWTtNQUN2QixNQUFNLFdBQVcsRUFBRSxXQUFXLENBQUM7TUFDL0IsT0FBTztPQUNMLEdBQUc7T0FDSCxTQUFTLFNBQVMsUUFBUSxTQUFTLEtBQUssT0FBTyxLQUFLO01BQ3REO0tBQ0Y7S0FDQSxPQUFPO0lBQ1QsQ0FBQztHQUNILEVBQUU7R0FDRixhQUFhLE1BQU0sY0FBYyxDQUFDLEVBQUMsQ0FBRSxRQUFRLFNBQVMsS0FBSyxPQUFPLEtBQUs7R0FDdkUsV0FBVyxNQUFNLFVBQVUsUUFBUSxTQUFTLEtBQUssT0FBTyxLQUFLO0VBQy9ELEVBQUU7RUFFRixJQUFJLFVBQVUsUUFBUTtHQUNwQixJQUFJO0lBQ0YsTUFBTSxFQUFFLFVBQVUsSUFBSTtJQUN0QixNQUFNLE1BQU0sR0FBRyxhQUFhLFdBQVcsU0FBUztLQUM5QyxRQUFRO0tBQ1IsU0FBUyxFQUNQLEdBQUksUUFBUSxFQUFFLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxDQUFDLEVBQ3hEO0lBQ0YsQ0FBQztHQUNILFNBQVMsR0FBRztJQUNWLFFBQVEsTUFBTSx1Q0FBdUMsQ0FBQztHQUN4RDtFQUNGO0NBQ0Y7Q0FFQSxrQkFBa0IsT0FBTztFQUN2QixLQUFLLFdBQVc7R0FDZCxXQUFXLE1BQU0sVUFBVSxRQUFRLFNBQVMsS0FBSyxPQUFPLEVBQUU7R0FDMUQsbUJBQW1CLE1BQU0sb0JBQW9CLENBQUMsRUFBQyxDQUFFLFFBQVEsTUFBTSxFQUFFLE9BQU8sRUFBRTtHQUMxRSxtQkFBbUIsTUFBTSxvQkFBb0IsQ0FBQyxFQUFDLENBQUUsUUFBUSxNQUFNLEVBQUUsT0FBTyxFQUFFO0dBQzFFLHVCQUF1QixNQUFNLHdCQUF3QixDQUFDLEVBQUMsQ0FBRSxRQUFRLE1BQU0sRUFBRSxPQUFPLEVBQUU7RUFDcEYsRUFBRTtDQUNKO0NBRUEsa0JBQWtCLFlBQVk7RUFDNUIsTUFBTSxFQUFFLFdBQVcsVUFBVSxJQUFJO0VBQ2pDLElBQUksQ0FBQyxTQUFTLFVBQVUsV0FBVyxHQUFHLE9BQU8sRUFBRSxTQUFTLEtBQUs7RUFFN0QsSUFBSTtHQUNGLE1BQU0sTUFBTSxNQUFNLE1BQU0sR0FBRyxhQUFhLGlCQUFpQjtJQUN2RCxRQUFRO0lBQ1IsU0FBUztLQUNQLGdCQUFnQjtLQUNoQixHQUFJLFNBQVMsVUFBVSx1QkFBdUIsRUFBRSxpQkFBaUIsVUFBVSxRQUFRLElBQUksQ0FBQztJQUMxRjtJQUNBLE1BQU0sS0FBSyxVQUFVLEVBQUUsV0FBVyxVQUFVLEtBQUksVUFBUztLQUN2RCxRQUFRLEtBQUs7S0FDYixJQUFJLEtBQUs7S0FDVCxXQUFXO0tBQ1gsTUFBTSxLQUFLO0lBQ2IsRUFBRSxFQUFFLENBQUM7R0FDUCxDQUFDO0dBRUQsSUFBSSxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztJQUM1QyxJQUFJLENBQUMsQ0FBQyxnQkFBZ0IsSUFBSSxNQUFNO0lBQ2hDLE9BQU87S0FBRSxTQUFTO0tBQU8sT0FBTztJQUFpQjtHQUNuRDtHQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSztHQUM1QixJQUFJLElBQUksTUFBTSxLQUFLLElBQUk7O0lBRXJCLElBQUksRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDO0lBQ3JCLElBQUksQ0FBQyxDQUFDLGdCQUFnQjtJQUN0QixJQUFJLENBQUMsQ0FBQyxVQUFVLDBDQUEwQyxTQUFTO0lBQ25FLE9BQU8sRUFBRSxTQUFTLEtBQUs7R0FDekIsT0FBTztJQUNMLElBQUksQ0FBQyxDQUFDLFVBQVUsK0JBQStCLEtBQUssU0FBUyxZQUFZLE9BQU87SUFDaEYsT0FBTztLQUFFLFNBQVM7S0FBTyxPQUFPLEtBQUs7SUFBTTtHQUM3QztFQUNGLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSw2Q0FBNkMsQ0FBQztHQUM1RCxJQUFJLENBQUMsQ0FBQyxVQUFVLCtCQUErQixPQUFPO0dBQ3RELE9BQU87SUFBRSxTQUFTO0lBQU8sT0FBTyxFQUFFO0dBQVE7RUFDNUM7Q0FDRjtDQUVBLGlCQUFpQixZQUFZO0VBQzNCLE9BQU8sSUFBSSxDQUFDLENBQUMsaUJBQWlCO0NBQ2hDO0NBRUEsYUFBYSxPQUFPLE9BQU8sZUFBZTtFQUN4QyxNQUFNLEVBQUUsU0FBUyxJQUFJO0VBQ3JCLElBQUksQ0FBQyxNQUFNLE9BQU87R0FBRSxTQUFTO0dBQU8sT0FBTztFQUF3QjtFQUVuRSxJQUFJO0dBQ0YsSUFBSSxDQUFDLENBQUMsVUFBVSxzQkFBc0IsT0FBTyxPQUFPLE1BQU07R0FFMUQsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLGFBQWEsb0JBQW9CO0lBQzFELFFBQVE7SUFDUixTQUFTLEVBQUUsaUJBQWlCLFVBQVUsS0FBSyxRQUFRO0lBQ25ELE1BQU0sS0FBSyxVQUFVLEVBQUUsS0FBSyxDQUFDO0dBQy9CLENBQUM7R0FFRCxNQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7R0FDNUIsSUFBSSxLQUFLLFdBQVcsS0FBSyxTQUFTOztJQUVoQyxNQUFNLGdCQUFnQixVQUFVLEtBQUssR0FBRyxLQUFLLElBQUksRUFBRTtJQUNuRCxNQUFNLFlBQVksUUFBUSxlQUFlLEtBQUssT0FBTztJQUNyRCxJQUFJLENBQUMsQ0FBQyxVQUFVLHNDQUFzQyxlQUFlLFNBQVM7SUFDOUUsT0FBTztLQUFFLFNBQVM7S0FBTSxVQUFVO0lBQWM7R0FDbEQsT0FBTztJQUNMLElBQUksQ0FBQyxDQUFDLFVBQVUsOEJBQThCLEtBQUssU0FBUyxZQUFZLE9BQU87SUFDL0UsT0FBTztLQUFFLFNBQVM7S0FBTyxPQUFPLEtBQUs7SUFBTTtHQUM3QztFQUNGLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSw0QkFBNEIsQ0FBQztHQUMzQyxJQUFJLENBQUMsQ0FBQyxVQUFVLGtDQUFrQyxPQUFPO0dBQ3pELE9BQU87SUFBRSxTQUFTO0lBQU8sT0FBTyxFQUFFO0dBQVE7RUFDNUM7Q0FDRjtDQUVBLHlCQUF5QixPQUFPLFFBQVEsa0JBQWtCOztFQUV4RCxNQUFNLGdCQUFnQixPQUFPLGtCQUFrQixXQUMzQyxnQkFDQSxLQUFLLFVBQVUsZUFBZSxNQUFNLENBQUM7RUFFekMsTUFBTSxZQUFZLFFBQVEsUUFBUSxhQUFhO0VBQy9DLElBQUksQ0FBQyxDQUFDLFVBQVUsMkNBQTJDLFNBQVM7Q0FDdEU7Q0FFQSxzQkFBc0IsT0FBTyxXQUFXO0VBQ3RDLE9BQU8sTUFBTSxZQUFZLFFBQVEsTUFBTTtDQUN6QztDQUVBLHNCQUFzQixZQUFZO0VBQ2hDLE1BQU0sT0FBTyxNQUFNLFlBQVksS0FBSztFQUNwQyxNQUFNLFVBQVUsQ0FBQztFQUVqQixLQUFLLE1BQU0sT0FBTyxNQUFNO0dBQ3RCLElBQUksSUFBSSxXQUFXLFNBQVMsR0FBRztJQUM3QixNQUFNLE9BQU8sTUFBTSxZQUFZLFFBQVEsR0FBRztJQUMxQyxRQUFRLEtBQUs7S0FDWCxRQUFRO0tBQ1IsT0FBTyxJQUFJLFFBQVEsV0FBVyxFQUFFLENBQUMsQ0FBQyxRQUFRLFNBQVMsRUFBRSxLQUFLO0tBQzFELE1BQU0sT0FBTyxTQUFTLFdBQVcsS0FBSyxTQUFTO0lBQ2pELENBQUM7R0FDSDtFQUNGO0VBRUEsT0FBTztDQUNUO0NBRUEscUJBQXFCLE9BQU8sV0FBVztFQUNyQyxNQUFNLFlBQVksV0FBVyxNQUFNO0NBQ3JDO0NBRUEsVUFBVSxDQUFDO0NBQ1gsYUFBYSxPQUFPLFlBQVksU0FBUztFQUN2QyxNQUFNLEVBQUUsU0FBUyxJQUFJO0VBQ3JCLElBQUksQ0FBQyxNQUFNLE9BQU87R0FBRSxTQUFTO0dBQU8sT0FBTztFQUF5QjtFQUVwRSxNQUFNLGFBQWE7R0FDakIsSUFBSSxPQUFPLEtBQUssSUFBSTtHQUNwQixVQUFVLEtBQUs7R0FDZixnQkFBZ0IsS0FBSyxZQUFZLEtBQUssU0FBUztHQUMvQztHQUNBO0dBQ0EsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDcEM7RUFFQSxLQUFLLFdBQVcsRUFDZCxVQUFVLENBQUMsR0FBSSxNQUFNLFlBQVksQ0FBQyxHQUFJLFVBQVUsRUFDbEQsRUFBRTtFQUVGLElBQUk7R0FDRixNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsYUFBYSxnQkFBZ0I7SUFDdEQsUUFBUTtJQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0lBQzlDLE1BQU0sS0FBSyxVQUFVLFVBQVU7R0FDakMsQ0FBQztHQUNELE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSztHQUM1QixJQUFJLEtBQUssSUFBSTtJQUNYLEtBQUssV0FBVyxFQUNkLFdBQVcsTUFBTSxZQUFZLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTSxFQUFFLE9BQU8sV0FBVyxLQUFLLEtBQUssT0FBTyxDQUFDLEVBQ3BGLEVBQUU7R0FDSjtFQUNGLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSw0QkFBNEIsQ0FBQztFQUM3QztFQUVBLE9BQU87R0FBRSxTQUFTO0dBQU0sU0FBUztFQUFXO0NBQzlDO0NBRUEscUJBQXFCLFFBQVE7RUFDM0IsTUFBTSxVQUFVLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFDLENBQUUsTUFBTSxNQUFNLEVBQUUsT0FBTyxJQUFJLEVBQUU7RUFDakUsSUFBSSxRQUFRO0VBRVosS0FBSyxXQUFXLEVBQ2QsVUFBVSxDQUFDLEdBQUksTUFBTSxZQUFZLENBQUMsR0FBSSxHQUFHLEVBQzNDLEVBQUU7Q0FDSjtDQUVBLG9CQUFvQixPQUFPLGFBQWE7RUFDdEMsTUFBTSxFQUFFLFNBQVMsSUFBSTtFQUNyQixJQUFJLENBQUMsTUFBTTtFQUVYLEtBQUssV0FBVyxFQUNkLFdBQVcsTUFBTSxZQUFZLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTTtHQUMxQyxJQUFJLEVBQUUsYUFBYSxZQUFZLEVBQUUsZUFBZSxLQUFLLE1BQU0sQ0FBQyxFQUFFLE1BQU07SUFDbEUsT0FBTztLQUFFLEdBQUc7S0FBRyxNQUFNO0lBQUs7R0FDNUI7R0FDQSxPQUFPO0VBQ1QsQ0FBQyxFQUNILEVBQUU7RUFFRixJQUFJO0dBQ0YsTUFBTSxNQUFNLEdBQUcsYUFBYSxxQkFBcUI7SUFDL0MsUUFBUTtJQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0lBQzlDLE1BQU0sS0FBSyxVQUFVO0tBQUU7S0FBVSxZQUFZLEtBQUs7SUFBRyxDQUFDO0dBQ3hELENBQUM7RUFDSCxTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sd0NBQXdDLENBQUM7RUFDekQ7Q0FDRjtDQUVBLG9CQUFvQixZQUFZLFNBQVMsUUFBUSxjQUFjLENBQUMsTUFBTTtFQUNwRSxLQUFLLFVBQVU7R0FDYixJQUFJLGNBQWM7R0FDbEIsTUFBTSxnQkFBZ0IsTUFBTSxhQUFhLENBQUMsRUFBQyxDQUFFLEtBQUssT0FBTztJQUN2RCxHQUFHO0lBQ0gsWUFBWSxFQUFFLGFBQWEsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNO0tBQ3hDLElBQUksRUFBRSxPQUFPLFlBQVksT0FBTzs7S0FHaEMsTUFBTSxPQUFPLEVBQUUsdUJBQXVCLENBQUM7S0FDdkMsTUFBTSxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUUsT0FBTyxPQUFPO0tBQy9DLElBQUksT0FBTyxjQUFjLE1BQU07S0FFL0IsT0FBTztNQUNMLEdBQUc7TUFDSCxzQkFBc0IsRUFBRSx1QkFBdUIsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNO09BQzVELElBQUksRUFBRSxPQUFPLFFBQVE7UUFDbkIsT0FBTztTQUNMLEdBQUc7U0FDSCxpQkFBaUI7U0FDakIsZUFBZSxjQUFjLEdBQUcsWUFBWSxJQUFJLFlBQVksa0JBQWtCLFNBQVMsS0FBSyxFQUFFO1NBQzlGLGdCQUFnQixZQUFZLGtCQUFrQixFQUFFO1NBQ2hELGtCQUFrQixZQUFZLG9CQUFvQixFQUFFO1NBQ3BELGlCQUFpQixZQUFZLG1CQUFtQixFQUFFO1NBQ2xELGNBQWMsWUFBWSxnQkFBZ0IsRUFBRTtTQUM1QyxhQUFhLFlBQVksZUFBZSxFQUFFO1NBQzFDLGVBQWU7UUFDakI7T0FDRjtPQUNBLE9BQU87TUFDVCxDQUFDO0tBQ0g7SUFDRixDQUFDO0dBQ0gsRUFBRTtHQUNGLE9BQU8sRUFBRSxXQUFXLGFBQWE7RUFDbkMsQ0FBQztDQUNIO0NBRUEsdUJBQXVCLFlBQVksV0FBVztFQUM1QyxLQUFLLFVBQVU7R0FDYixNQUFNLGdCQUFnQixNQUFNLGFBQWEsQ0FBQyxFQUFDLENBQUUsS0FBSyxPQUFPO0lBQ3ZELEdBQUc7SUFDSCxZQUFZLEVBQUUsYUFBYSxDQUFDLEVBQUMsQ0FBRSxLQUFLLE1BQU07S0FDeEMsSUFBSSxFQUFFLE9BQU8sWUFBWSxPQUFPO0tBQ2hDLE9BQU87TUFDTCxHQUFHO01BQ0gsc0JBQXNCLEVBQUUsdUJBQXVCLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTTtPQUM1RCxJQUFJLEVBQUUsT0FBTyxRQUFRO1FBQ25CLE9BQU87U0FDTCxHQUFHO1NBQ0gsaUJBQWlCO1NBQ2pCLGVBQWU7U0FDZixnQkFBZ0I7U0FDaEIsZUFBZTtRQUNqQjtPQUNGO09BQ0EsT0FBTztNQUNULENBQUM7S0FDSDtJQUNGLENBQUM7R0FDSCxFQUFFO0dBQ0YsT0FBTyxFQUFFLFdBQVcsYUFBYTtFQUNuQyxDQUFDO0NBQ0g7Q0FFQSwyQkFBMkIsWUFBWSxtQkFBbUIsQ0FBQyxNQUFNO0VBQy9ELE1BQU0sUUFBUSxJQUFJO0VBQ2xCLE1BQU0sT0FBTyxpQkFBaUIsZ0JBQWdCO0VBQzlDLE1BQU0sUUFBUSxpQkFBaUIsTUFBTSxpQkFBaUIsTUFBTSxLQUFLO0VBRWpFLE1BQU0saUJBQWlCO0dBQ3JCLElBQUk7R0FDSixRQUFRLGlCQUFpQixVQUFVLFlBQVksTUFBTTtHQUNyRCxjQUFjO0dBQ2QsV0FBVztHQUNYLGVBQWUsaUJBQWlCLGlCQUFpQixZQUFZLGlCQUFpQixtQkFBbUI7R0FDakcsZ0JBQWdCLGlCQUFpQixrQkFBa0I7R0FDbkQsZUFBZTtHQUNmLHdCQUF3QjtHQUN4QixlQUFlLENBQUM7R0FDaEI7RUFDRjtFQUVBLElBQUksQ0FBQyxDQUFDLG9CQUFvQixZQUFZLGNBQWM7RUFDcEQsT0FBTztDQUNUO0FBQ0YsSUFDQTtDQUNFLE1BQU07Q0FDTixTQUFTO0NBQ1QsYUFBYSxXQUFXO0VBQ3RCLE1BQU0sTUFBTTtFQUNaLE9BQU8sTUFBTTtFQUNiLFdBQVcsTUFBTSxhQUFhLENBQUM7RUFDL0IsVUFBVSxNQUFNLFlBQVksQ0FBQztFQUM3QixXQUFXLE1BQU07RUFDakIsa0JBQWtCLE1BQU0sb0JBQW9CLENBQUM7RUFDN0Msa0JBQWtCLE1BQU0sb0JBQW9CLENBQUM7RUFDN0Msc0JBQXNCLE1BQU0sd0JBQXdCLENBQUM7RUFDckQscUJBQXFCLE1BQU0sdUJBQXVCLENBQUM7RUFDbkQsV0FBVyxNQUFNO0NBQ25CO0NBQ0EsMkJBQTJCLFVBQVU7RUFDbkMsSUFBSSxTQUFTLE1BQU0sU0FBUyxNQUFNLFVBQVUsd0JBQXdCLE9BQU8sY0FBYyxlQUFlLFVBQVUsUUFBUTs7R0FFeEgsTUFBTSxrQkFBa0I7R0FDeEIsTUFBTSxpQkFBaUI7RUFDekI7Q0FDRjtBQUNGLENBQ0YsQ0FDRjtBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidXNlU3RvcmUuanMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlIH0gZnJvbSAnenVzdGFuZCc7XHJcbmltcG9ydCB7IHBlcnNpc3QgfSBmcm9tICd6dXN0YW5kL21pZGRsZXdhcmUnO1xyXG5pbXBvcnQgbG9jYWxmb3JhZ2UgZnJvbSAnbG9jYWxmb3JhZ2UnO1xyXG5pbXBvcnQgeyBBUElfQkFTRV9VUkwgfSBmcm9tICcuLi91dGlscy9hcGknO1xyXG5pbXBvcnQgeyBpbml0aWFsVGFibGVyb3NEYXRhIH0gZnJvbSAnLi4vZGF0YS9tb2NrVGFibGVyb3MnO1xyXG5cclxuLy8gQ29uZmlndXJhciBsb2NhbGZvcmFnZVxyXG5sb2NhbGZvcmFnZS5jb25maWcoe1xyXG4gIG5hbWU6ICdhcHAtdGFibGVyb3MtZWxlY3RyaWNvcycsXHJcbiAgc3RvcmVOYW1lOiAnaW5zcGVjY2lvbmVzX3N0b3JlJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjb25zdCBQUkVGSVhfTUFQID0ge1xyXG4gIFRBQkxFUk86ICdUQUInLFxyXG4gIFBVTlRPX1NVTUlOSVNUUk86ICdTVU0nLFxyXG4gIFBVTlRPX01FRElDSU9OOiAnUE0nLFxyXG4gIFNVQkVTVEFDSU9OOiAnU1VCJyxcclxuICBBTUJJRU5UQUxfRklTSUNBOiAnQU1CJyxcclxuICBURVJNT0dSQUZJQ0E6ICdURVInLFxyXG4gIFNJU1RFTUFfQVRFUlJBTUlFTlRPOiAnUEFUJyxcclxuICBUQU5RVUVfQ09NQlVTVElCTEU6ICdUSycsXHJcbiAgQ0NNOiAnQ0NNJyxcclxuICBUUkFOU0ZPUk1BRE9SOiAnVFJBRk8nLFxyXG4gIEdFTkVSQURPUjogJ0dFTicsXHJcbiAgVFJBTlNGRVI6ICdBVFMnLFxyXG4gIFBVRVNUQV9USUVSUkE6ICdQQVQnLFxyXG4gIEJBTkNPX0NPTkRFTlNBRE9SOiAnQkMnLFxyXG4gIE9UUk86ICdPVFInXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgY2xlYW5FbGVtZW50TmFtZSA9IChub21icmUsIGlkKSA9PiB7XHJcbiAgaWYgKCFub21icmUpIHJldHVybiBpZCB8fCAnJztcclxuICBsZXQgY2xlYW5OYW1lID0gbm9tYnJlLnRyaW0oKTtcclxuICBcclxuICBpZiAoaWQpIHtcclxuICAgIGlmIChjbGVhbk5hbWUuc3RhcnRzV2l0aChgJHtpZH0gLSBgKSkge1xyXG4gICAgICBjbGVhbk5hbWUgPSBjbGVhbk5hbWUuc3Vic3RyaW5nKGlkLmxlbmd0aCArIDMpO1xyXG4gICAgfSBlbHNlIGlmIChjbGVhbk5hbWUuc3RhcnRzV2l0aChgJHtpZH06IGApKSB7XHJcbiAgICAgIGNsZWFuTmFtZSA9IGNsZWFuTmFtZS5zdWJzdHJpbmcoaWQubGVuZ3RoICsgMik7XHJcbiAgICB9XHJcbiAgICBjb25zdCBpZFBhdHRlcm4gPSBuZXcgUmVnRXhwKGBcXFxccypcXFxcKElEOlxcXFxzKiR7aWQucmVwbGFjZSgvWy4qKz9eJHt9KCl8W1xcXVxcXFxdL2csICdcXFxcJCYnKX1cXFxcKWAsICdnaScpO1xyXG4gICAgY2xlYW5OYW1lID0gY2xlYW5OYW1lLnJlcGxhY2UoaWRQYXR0ZXJuLCAnJykudHJpbSgpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGNsZWFuTmFtZSB8fCBpZDtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBmb3JtYXRFbGVtZW50VGl0bGVXaXRoSWQgPSAobm9tYnJlLCBpZCkgPT4ge1xyXG4gIHJldHVybiBjbGVhbkVsZW1lbnROYW1lKG5vbWJyZSwgaWQpO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldE5leHRFbGVtZW50SWQgPSAodGlwb0VsZW1lbnRvLCBzdGF0ZSA9IHt9KSA9PiB7XHJcbiAgY29uc3QgcHJlZml4ID0gUFJFRklYX01BUFt0aXBvRWxlbWVudG8gfHwgJ1RBQkxFUk8nXSB8fCAnRUxNJztcclxuICBsZXQgbWF4TnVtID0gMDtcclxuXHJcbiAgY29uc3QgY2hlY2tJdGVtID0gKGl0ZW0pID0+IHtcclxuICAgIGlmIChpdGVtICYmIGl0ZW0uaWQgJiYgdHlwZW9mIGl0ZW0uaWQgPT09ICdzdHJpbmcnICYmIGl0ZW0uaWQuc3RhcnRzV2l0aChgJHtwcmVmaXh9LWApKSB7XHJcbiAgICAgIGNvbnN0IHBhcnRzID0gaXRlbS5pZC5zcGxpdCgnLScpO1xyXG4gICAgICBjb25zdCBudW0gPSBwYXJzZUludChwYXJ0c1twYXJ0cy5sZW5ndGggLSAxXSwgMTApO1xyXG4gICAgICBpZiAoIWlzTmFOKG51bSkgJiYgbnVtID4gbWF4TnVtKSBtYXhOdW0gPSBudW07XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgKHN0YXRlLmNvbXBhbmllcyB8fCBbXSkuZm9yRWFjaChjID0+IHtcclxuICAgIChjLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgW10pLmZvckVhY2goY2hlY2tJdGVtKTtcclxuICAgIChjLnByb3llY3RvcyB8fCBbXSkuZm9yRWFjaChwID0+IHtcclxuICAgICAgKHAuZWxlbWVudG9zVW5pZmlsYXJlcyB8fCBwLnRhYmxlcm9zIHx8IFtdKS5mb3JFYWNoKGNoZWNrSXRlbSk7XHJcbiAgICAgIChwLmluc3BlY2Npb25lc1N1YmVzdGFjaW9uIHx8IHAuc3ViZXN0YWNpb25lcyB8fCBbXSkuZm9yRWFjaChjaGVja0l0ZW0pO1xyXG4gICAgICAocC5wdW50b3NNZWRpY2lvbiB8fCBbXSkuZm9yRWFjaChjaGVja0l0ZW0pO1xyXG4gICAgICAocC5jY21MaXN0IHx8IFtdKS5mb3JFYWNoKGNoZWNrSXRlbSk7XHJcbiAgICB9KTtcclxuICB9KTtcclxuXHJcbiAgKHN0YXRlLmVsZW1lbnRvc0xvY2FsZXMgfHwgW10pLmZvckVhY2goY2hlY2tJdGVtKTtcclxuICAoc3RhdGUuc3ViZXN0YWNpb25lc0xvY2FsZXMgfHwgW10pLmZvckVhY2goY2hlY2tJdGVtKTtcclxuICAoc3RhdGUucHVudG9zTWVkaWNpb25Mb2NhbGVzIHx8IFtdKS5mb3JFYWNoKGNoZWNrSXRlbSk7XHJcbiAgKHN0YXRlLmNjbUxvY2FsZXMgfHwgW10pLmZvckVhY2goY2hlY2tJdGVtKTtcclxuXHJcbiAgcmV0dXJuIGAke3ByZWZpeH0tJHttYXhOdW0gKyAxfWA7XHJcbn07XHJcblxyXG4vLyBBbG1hY2VuYW1pZW50byBwZXJzb25hbGl6YWRvIHBhcmEgbG9jYWxmb3JhZ2UgKHNvcG9ydGEgb2JqZXRvcyBCbG9iIGJpbmFyaW9zKVxyXG5jb25zdCBsb2NhbEZvcmFnZVN0b3JhZ2UgPSB7XHJcbiAgZ2V0SXRlbTogYXN5bmMgKG5hbWUpID0+IHtcclxuICAgIGNvbnN0IHZhbHVlID0gYXdhaXQgbG9jYWxmb3JhZ2UuZ2V0SXRlbShuYW1lKTtcclxuICAgIHJldHVybiB2YWx1ZTtcclxuICB9LFxyXG4gIHNldEl0ZW06IGFzeW5jIChuYW1lLCB2YWx1ZSkgPT4ge1xyXG4gICAgYXdhaXQgbG9jYWxmb3JhZ2Uuc2V0SXRlbShuYW1lLCB2YWx1ZSk7XHJcbiAgfSxcclxuICByZW1vdmVJdGVtOiBhc3luYyAobmFtZSkgPT4ge1xyXG4gICAgYXdhaXQgbG9jYWxmb3JhZ2UucmVtb3ZlSXRlbShuYW1lKTtcclxuICB9XHJcbn07XHJcblxyXG5jb25zdCBpbml0aWFsQ29tcGFuaWVzID0gW1xyXG4gIHtcclxuICAgIGlkOiAnYy0xJyxcclxuICAgIG5vbWJyZTogJ0Nsw61uaWNhIFZhbGVudGluYSBDYW5hYmFsJyxcclxuICAgIHByb3llY3RvczogW1xyXG4gICAgICB7XHJcbiAgICAgICAgaWQ6ICdwLTEnLFxyXG4gICAgICAgIG5vbWJyZTogJ1Byb3llY3RvIERpYWdyYW1hIFVuaWZpbGFyIHkgVGFibGVyb3MgMjAyNScsXHJcbiAgICAgICAgZGVzY3JpcGNpb246ICdFc3R1ZGlvIGRlIHRyYW5zZm9ybWFkb3JlcywgZ2VuZXJhZG9yZXMsIHRhYmxlcm9zIHkgbWFsbGEgZGUgcHVlc3RhIGEgdGllcnJhLicsXHJcbiAgICAgICAgZWxlbWVudG9zVW5pZmlsYXJlczogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJ1RBQi0xJyxcclxuICAgICAgICAgICAgbm9tYnJlOiAnVEFCLTEgLSBUYWJsZXJvIFByaW5jaXBhbCAoTm8uIDIwKScsXHJcbiAgICAgICAgICAgIHRpcG9FbGVtZW50bzogJ1RBQkxFUk8nLFxyXG4gICAgICAgICAgICB1YmljYWNpb246ICdTT1RBTk8gU0FMQSBERSBUQUJMRVJPUycsXHJcbiAgICAgICAgICAgIGFsaW1lbnRhZG9Qb3I6ICdBVFMgU09UQU5PIChUUkFOU0ZFUkVOQ0lBIEFVVE9NQVRJQ0EpIHRyYW5zZmVyZWNpYSA1ODAnLFxyXG4gICAgICAgICAgICBmb3RvOiBudWxsLFxyXG4gICAgICAgICAgICBmb3RvQmxvYjogbnVsbCxcclxuICAgICAgICAgICAgb2JzZXJ2YWNpb25lc0dlbmVyYWxlczogJ1NBTEVOIEFDT01FVElEQVMgMSBYIDUwMCBZIDFYMjUwIE1DTSBERSBMQSBCQVJSQSBQQVJURSBJTkZFUklPUi4gTEEgQUNPTUVUSURBIDI1MCBNQ00gVkEgQSBDQUpBIENPTiBVTiBCUkVBS0VSIEFMIExBRE8gREVMIFRBQkxFUk8gUFJJTkNJUEFMLiBJTlRFUlJVUFRPUiBFQVRPTiwgS2k0MDAsIDM1MCBBLiBTQUxFTiBVTkEgQUNPTUVUSURBIDQvMCBRVUUgQUxJTUVOVEEgVFJBTlNGRVJFTkNJQSAxNjAuIExBIEFDT01FVElEQSA1MDAgTUNNIFZBIEEgVU5BIENBSkEgQUwgTEFETyBERUwgVEFCTEVSTyBQUklOQ0lQQUwuIElOVEVSUlVQVE9SIEFCQiwgVElQTyA2NTIwLCA0MDAgQSwgU0FMRU4gMlg1MDAgWSBBTElNRU5UQU4gVEFCTEVSTyBFTiBQUklNRVIgUElTTy4nLFxyXG4gICAgICAgICAgICBkYXRvc1RlY25pY29zOiB7XHJcbiAgICAgICAgICAgICAgbWF4UG9sZXM6IDMwLFxyXG4gICAgICAgICAgICAgIHRpcG9UYWJsZXJvOiAnU1VQRVJGSUNJQUwnLFxyXG4gICAgICAgICAgICAgIHZvbHRhamVBY29tZXRpZGE6ICcyMTEuNSAvIDIwNy40IC8gMjA4LjYgVicsXHJcbiAgICAgICAgICAgICAgYmFycmFzUHJpbmNpcGFsZXM6IHsgaWE6ICcnLCBpYjogJycsIGljOiAnJyB9LFxyXG4gICAgICAgICAgICAgIGJyZWFrZXJQcmluY2lwYWw6IHsgbWFyY2E6ICdTSU4gQlJFQUtFUicsIHRpcG86ICcnLCBhbXA6ICcnIH0sXHJcbiAgICAgICAgICAgICAgdm9sdGFqZTogeyB2YTogJzIxMSw1JywgdmI6ICcyMDcsNCcsIHZjOiAnMjA4LDYnIH0sXHJcbiAgICAgICAgICAgICAgYWNvbWV0aWRhOiAnM1g1MDAgTUNNJyxcclxuICAgICAgICAgICAgICBuZXV0cm9MbGVnYWRhOiB7IGNhbGlicmU6ICcxWDUwMCcsIG9ic2VydmFjaW9uZXM6ICcnIH0sXHJcbiAgICAgICAgICAgICAgcHVlc3RhVGllcnJhOiB7IGNhbGlicmU6ICdTT0xJRE8gIzQnLCBvYnNlcnZhY2lvbmVzOiAnTExFR0EgU09MSURPICM0LiBCVVNDQVIgVEFOUVVJTExBIERFIE1BTExBIEEgVElFUlJBJyB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHByb3llY3RvSWQ6ICdwLTEnLFxyXG4gICAgICAgICAgICBjb21wYW55SWQ6ICdjLTEnLFxyXG4gICAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICdBVFMtMScsXHJcbiAgICAgICAgICAgIG5vbWJyZTogJ0FUUy0xIC0gVHJhbnNmZXJlbmNpYSA1ODAgRXN0YWNpb25hbWllbnRvJyxcclxuICAgICAgICAgICAgdGlwb0VsZW1lbnRvOiAnVFJBTlNGRVInLFxyXG4gICAgICAgICAgICB1YmljYWNpb246ICdFU1RBQ0lPTkFNSUVOVE8nLFxyXG4gICAgICAgICAgICBhbGltZW50YWRvUG9yOiAnR0VORVJBRE9SIDU4MCAxICsgR0VORVJBRE9SIDU4MCAyJyxcclxuICAgICAgICAgICAgZm90bzogbnVsbCxcclxuICAgICAgICAgICAgZm90b0Jsb2I6IG51bGwsXHJcbiAgICAgICAgICAgIG9ic2VydmFjaW9uZXNHZW5lcmFsZXM6ICdUUkFOU0ZFUkVOQ0lBIEFMSU1FTlRBREEgUE9SIExPUyBET1MgR0VORVJBRE9SRVMnLFxyXG4gICAgICAgICAgICBkYXRvc1RlY25pY29zOiB7XHJcbiAgICAgICAgICAgICAgbW9kZWxvOiAnRE9NT1NBJyxcclxuICAgICAgICAgICAgICB0aXBvVHJhbnNmZXJlbmNpYTogJ1lVWUUtWUVTMSAzMjAwLzRQJyxcclxuICAgICAgICAgICAgICBhbXBlcmFqZTogJzMyMDAnLFxyXG4gICAgICAgICAgICAgIHZvbHRhamU6IHsgdmFiOiAnJywgdmFjOiAnJywgdmJjOiAnJyB9LFxyXG4gICAgICAgICAgICAgIGFsaW1lbnRhY2lvbkdlbmVyYWRvcjE6ICcyKDNYNTAwKScsXHJcbiAgICAgICAgICAgICAgYWxpbWVudGFjaW9uR2VuZXJhZG9yMjogJzIoM1g1MDApJyxcclxuICAgICAgICAgICAgICBjYXJnYTogJzIoM1g1MDApJyxcclxuICAgICAgICAgICAgICBuZXV0cm86ICc1MDAnLFxyXG4gICAgICAgICAgICAgIHRpZXJyYTogJ05PJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwcm95ZWN0b0lkOiAncC0xJyxcclxuICAgICAgICAgICAgY29tcGFueUlkOiAnYy0xJyxcclxuICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnQVRTLTInLFxyXG4gICAgICAgICAgICBub21icmU6ICdBVFMtMiAtIFRyYW5zZmVyZW5jaWEgNTgwIFPDs3Rhbm8gU2FsYSBUw6ljbmljYScsXHJcbiAgICAgICAgICAgIHRpcG9FbGVtZW50bzogJ1RSQU5TRkVSJyxcclxuICAgICAgICAgICAgdWJpY2FjaW9uOiAnU09UQU5PIFNBTEEgVEVDTklDQScsXHJcbiAgICAgICAgICAgIGFsaW1lbnRhZG9Qb3I6ICdUUkFOU0ZFUkVOQ0lBIERPTU9TQSArIENPUlBPRUxFQycsXHJcbiAgICAgICAgICAgIGZvdG86IG51bGwsXHJcbiAgICAgICAgICAgIGZvdG9CbG9iOiBudWxsLFxyXG4gICAgICAgICAgICBvYnNlcnZhY2lvbmVzR2VuZXJhbGVzOiAnUEFTQSBESVJFQ1RBTUVOVEUgQUwgVEFCTEVSTyAuJyxcclxuICAgICAgICAgICAgZGF0b3NUZWNuaWNvczoge1xyXG4gICAgICAgICAgICAgIG1vZGVsbzogJ05PIFRJRU5FJyxcclxuICAgICAgICAgICAgICB0aXBvVHJhbnNmZXJlbmNpYTogJ05PIFRJRU5FJyxcclxuICAgICAgICAgICAgICBhbXBlcmFqZTogJycsXHJcbiAgICAgICAgICAgICAgdm9sdGFqZTogeyB2YWI6ICcyMTEnLCB2YWM6ICcyMDgnLCB2YmM6ICcyMDknIH0sXHJcbiAgICAgICAgICAgICAgYWxpbWVudGFjaW9uQ29ycG9lbGVjOiAnM1g1MDAnLFxyXG4gICAgICAgICAgICAgIGFsaW1lbnRhY2lvblRyYW5zZkRvbW9zYTogJzJYNTAwJyxcclxuICAgICAgICAgICAgICBjYXJnYTogJzNYNTAwJyxcclxuICAgICAgICAgICAgICBuZXV0cm86ICc1MDAnLFxyXG4gICAgICAgICAgICAgIHRpZXJyYTogJ05PJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwcm95ZWN0b0lkOiAncC0xJyxcclxuICAgICAgICAgICAgY29tcGFueUlkOiAnYy0xJyxcclxuICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnR0VOLTEnLFxyXG4gICAgICAgICAgICBub21icmU6ICdHRU4tMSAtIEdlbmVyYWRvciBOby4gMSBET01PU0EgNTgwIEtWQScsXHJcbiAgICAgICAgICAgIHRpcG9FbGVtZW50bzogJ0dFTkVSQURPUicsXHJcbiAgICAgICAgICAgIHViaWNhY2lvbjogJ0VTVEFDSU9OQU1JRU5UTycsXHJcbiAgICAgICAgICAgIGFsaW1lbnRhZG9Qb3I6ICdUUkFOU0ZFUkVOQ0lBIERPTU9TQSBFTiBFU1RBQ0lPTkFNSUVOVE8nLFxyXG4gICAgICAgICAgICBmb3RvOiBudWxsLFxyXG4gICAgICAgICAgICBmb3RvQmxvYjogbnVsbCxcclxuICAgICAgICAgICAgb2JzZXJ2YWNpb25lc0dlbmVyYWxlczogJ0dlbmVyYWRvciBOby4gMSBET01PU0EgNTgwIEtWQSB1YmljYWRvIGVuIGVsIGVzdGFjaW9uYW1pZW50by4nLFxyXG4gICAgICAgICAgICBkYXRvc1RlY25pY29zOiB7XHJcbiAgICAgICAgICAgICAga3ZhOiAnNTgwIEtWQScsXHJcbiAgICAgICAgICAgICAgbWFyY2E6ICdET01PU0EnLFxyXG4gICAgICAgICAgICAgIGZhc2VzOiAnMycsXHJcbiAgICAgICAgICAgICAgdm9sdGFqZTogJzIwOCBWT0wnLFxyXG4gICAgICAgICAgICAgIGFtcGVyYWplOiAnJyxcclxuICAgICAgICAgICAgICBmcDogJycsXHJcbiAgICAgICAgICAgICAgY29tYnVzdGlibGU6ICdHQUxPTkVTJyxcclxuICAgICAgICAgICAgICBpbnRlcnJ1cHRvcjogeyBtYXJjYTogJ0NISU5UJywgdGlwbzogJycsIGFtcDogJzE2MDAnLCBjb25kRmFzZTogJzIoM1g1MDApJywgY29uZE5ldXRybzogJzUwMCcgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwcm95ZWN0b0lkOiAncC0xJyxcclxuICAgICAgICAgICAgY29tcGFueUlkOiAnYy0xJyxcclxuICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnR0VOLTInLFxyXG4gICAgICAgICAgICBub21icmU6ICdHRU4tMiAtIEdlbmVyYWRvciBOby4gMiBET01PU0EgNTgwIEtWQScsXHJcbiAgICAgICAgICAgIHRpcG9FbGVtZW50bzogJ0dFTkVSQURPUicsXHJcbiAgICAgICAgICAgIHViaWNhY2lvbjogJ0VTVEFDSU9OQU1JRU5UTycsXHJcbiAgICAgICAgICAgIGFsaW1lbnRhZG9Qb3I6ICdUUkFOU0ZFUkVOQ0lBIERPTU9TQSBFTiBFU1RBQ0lPTkFNSUVOVE8nLFxyXG4gICAgICAgICAgICBmb3RvOiBudWxsLFxyXG4gICAgICAgICAgICBmb3RvQmxvYjogbnVsbCxcclxuICAgICAgICAgICAgb2JzZXJ2YWNpb25lc0dlbmVyYWxlczogJ0dlbmVyYWRvciBOby4gMiBET01PU0EgNTgwIEtWQSB1YmljYWRvIGVuIGVsIGVzdGFjaW9uYW1pZW50by4nLFxyXG4gICAgICAgICAgICBkYXRvc1RlY25pY29zOiB7XHJcbiAgICAgICAgICAgICAga3ZhOiAnNTgwIEtWQScsXHJcbiAgICAgICAgICAgICAgbWFyY2E6ICdET01PU0EnLFxyXG4gICAgICAgICAgICAgIGZhc2VzOiAnMycsXHJcbiAgICAgICAgICAgICAgdm9sdGFqZTogJzIwOCBWT0wnLFxyXG4gICAgICAgICAgICAgIGFtcGVyYWplOiAnODAwIEFNUCcsXHJcbiAgICAgICAgICAgICAgZnA6ICcnLFxyXG4gICAgICAgICAgICAgIGNvbWJ1c3RpYmxlOiAnR0FMT05FUycsXHJcbiAgICAgICAgICAgICAgaW50ZXJydXB0b3I6IHsgbWFyY2E6ICdDSElOVCcsIHRpcG86ICcnLCBhbXA6ICcxNjAwJywgY29uZEZhc2U6ICcyKDNYNTAwKScsIGNvbmROZXV0cm86ICc1MDAnIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcHJveWVjdG9JZDogJ3AtMScsXHJcbiAgICAgICAgICAgIGNvbXBhbnlJZDogJ2MtMScsXHJcbiAgICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgXSxcclxuICAgICAgICBpbnNwZWNjaW9uZXNTdWJlc3RhY2lvbjogW10sXHJcbiAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcclxuICAgICAgfVxyXG4gICAgXVxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6ICdjLTInLFxyXG4gICAgbm9tYnJlOiAnQWxpbWVudG9zIFBvbGFyIFBsYW50YSBUdXJtZXJvJyxcclxuICAgIHByb3llY3RvczogW11cclxuICB9XHJcbl07XHJcblxyXG5jb25zdCBnZXRJbml0aWFsVXNlciA9ICgpID0+IHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmF3ID0gdHlwZW9mIGxvY2FsU3RvcmFnZSAhPT0gJ3VuZGVmaW5lZCcgPyBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndXNlcicpIDogbnVsbDtcclxuICAgIHJldHVybiByYXcgPyBKU09OLnBhcnNlKHJhdykgOiBudWxsO1xyXG4gIH0gY2F0Y2ggKGUpIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufTtcclxuXHJcbmNvbnN0IGdldEluaXRpYWxUb2tlbiA9ICgpID0+IHtcclxuICB0cnkge1xyXG4gICAgcmV0dXJuIHR5cGVvZiBsb2NhbFN0b3JhZ2UgIT09ICd1bmRlZmluZWQnID8gKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0b2tlbicpIHx8IG51bGwpIDogbnVsbDtcclxuICB9IGNhdGNoIChlKSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgdXNlU3RvcmUgPSBjcmVhdGUoXHJcbiAgcGVyc2lzdChcclxuICAgIChzZXQsIGdldCkgPT4gKHtcclxuICAgICAgdXNlcjogZ2V0SW5pdGlhbFVzZXIoKSxcclxuICAgICAgdG9rZW46IGdldEluaXRpYWxUb2tlbigpLFxyXG4gICAgICB1c2Vyc0xpc3Q6IFtcclxuICAgICAgICB7IGlkOiAndS0xJywgdXNlcm5hbWU6ICdhZG1pbjEnLCByb2xlOiAnQURNSU4nIH0sXHJcbiAgICAgICAgeyBpZDogJ3UtMicsIHVzZXJuYW1lOiAnYWRtaW4yJywgcm9sZTogJ0FETUlOJyB9XHJcbiAgICAgIF0sXHJcbiAgICAgIGNvbXBhbmllczogaW5pdGlhbENvbXBhbmllcyxcclxuICAgICAgcHJveWVjdG9zTG9jYWxlczogW10sXHJcbiAgICAgIGVsZW1lbnRvc0xvY2FsZXM6IFtdLFxyXG4gICAgICBzdWJlc3RhY2lvbmVzTG9jYWxlczogW10sXHJcbiAgICAgIHN5bmNRdWV1ZTogW10sXHJcbiAgICAgIHNvY2tldDogbnVsbCxcclxuICAgICAgdG9hc3Q6IHsgc2hvdzogZmFsc2UsIG1lc3NhZ2U6ICcnLCB0eXBlOiAnc3VjY2VzcycsIGFjdGlvbjogbnVsbCB9LFxyXG4gICAgICBjb25mbGljdG9zQ2lyY3VpdG9zOiBbXSxcclxuICAgICAgaXNQYW5lbENvbmZsaWN0b3NPcGVuOiBmYWxzZSxcclxuXHJcbiAgICAgIHNob3dUb2FzdDogKG1lc3NhZ2UsIHR5cGUgPSAnc3VjY2VzcycsIGFjdGlvbiA9IG51bGwpID0+IHNldCh7IHRvYXN0OiB7IHNob3c6IHRydWUsIG1lc3NhZ2UsIHR5cGUsIGFjdGlvbiB9IH0pLFxyXG4gICAgICBoaWRlVG9hc3Q6ICgpID0+IHNldCgoc3RhdGUpID0+ICh7IHRvYXN0OiB7IC4uLnN0YXRlLnRvYXN0LCBzaG93OiBmYWxzZSB9IH0pKSxcclxuICAgICAgc2V0U29ja2V0OiAoc29ja2V0KSA9PiBzZXQoeyBzb2NrZXQgfSksXHJcbiAgICAgIHNldFBhbmVsQ29uZmxpY3Rvc09wZW46IChpc09wZW4pID0+IHNldCh7IGlzUGFuZWxDb25mbGljdG9zT3BlbjogaXNPcGVuIH0pLFxyXG5cclxuICAgICAgcmVnaXN0cmFyQ29uZmxpY3RvQ2lyY3VpdG86IChjb25mbGljdG8pID0+IHNldCgoc3RhdGUpID0+IHtcclxuICAgICAgICBjb25zdCBudWV2b0NvbmZsaWN0byA9IHtcclxuICAgICAgICAgIGlkOiBjb25mbGljdG8uaWQgfHwgYGNvbmZfJHtEYXRlLm5vdygpfV8ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cigyLCA1KX1gLFxyXG4gICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICByZXN1ZWx0bzogZmFsc2UsXHJcbiAgICAgICAgICAuLi5jb25mbGljdG9cclxuICAgICAgICB9O1xyXG4gICAgICAgIC8vIEV2aXRhciBkdXBsaWNhZG9zIGlkw6ludGljb3MgZW4gY29sYVxyXG4gICAgICAgIGNvbnN0IGZpbHRlcmVkID0gKHN0YXRlLmNvbmZsaWN0b3NDaXJjdWl0b3MgfHwgW10pLmZpbHRlcihjID0+IFxyXG4gICAgICAgICAgIShjLnRhYmxlcm9JZCA9PT0gbnVldm9Db25mbGljdG8udGFibGVyb0lkICYmIEpTT04uc3RyaW5naWZ5KGMucG9sb3MpID09PSBKU09OLnN0cmluZ2lmeShudWV2b0NvbmZsaWN0by5wb2xvcykpXHJcbiAgICAgICAgKTtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgY29uZmxpY3Rvc0NpcmN1aXRvczogW251ZXZvQ29uZmxpY3RvLCAuLi5maWx0ZXJlZF1cclxuICAgICAgICB9O1xyXG4gICAgICB9KSxcclxuXHJcbiAgICAgIHJlc29sdmVyQ29uZmxpY3RvQ2lyY3VpdG86IChpZCkgPT4gc2V0KChzdGF0ZSkgPT4gKHtcclxuICAgICAgICBjb25mbGljdG9zQ2lyY3VpdG9zOiAoc3RhdGUuY29uZmxpY3Rvc0NpcmN1aXRvcyB8fCBbXSkuZmlsdGVyKGMgPT4gYy5pZCAhPT0gaWQpXHJcbiAgICAgIH0pKSxcclxuXHJcbiAgICAgIGxpbXBpYXJDb25mbGljdG9zQ2lyY3VpdG9zOiAoKSA9PiBzZXQoeyBjb25mbGljdG9zQ2lyY3VpdG9zOiBbXSB9KSxcclxuXHJcbiAgICAgIGhhbmRsZUF1dGhFcnJvcjogKHN0YXR1cywgZXJyb3JNc2cgPSAnJykgPT4ge1xyXG4gICAgICAgIGlmIChcclxuICAgICAgICAgIHN0YXR1cyA9PT0gNDAxIHx8IFxyXG4gICAgICAgICAgc3RhdHVzID09PSA0MDMgfHwgXHJcbiAgICAgICAgICBlcnJvck1zZz8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcygnZXhwaXJhZG8nKSB8fCBcclxuICAgICAgICAgIGVycm9yTXNnPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCdpbnbDoWxpZG8nKSB8fCBcclxuICAgICAgICAgIGVycm9yTXNnPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCd0b2tlbicpXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndG9rZW4nKTtcclxuICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndXNlcicpO1xyXG4gICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd1c3VhcmlvJyk7XHJcbiAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2UuY2xlYXIoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgICBzZXQoeyB1c2VyOiBudWxsLCB0b2tlbjogbnVsbCB9KTtcclxuXHJcbiAgICAgICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lICE9PSAnL2xvZ2luJykge1xyXG4gICAgICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVwbGFjZSgnL2xvZ2luJyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG5cclxuICAgICAgZmV0Y2hVc2Vyc0xpc3Q6IGFzeW5jICgpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgeyB0b2tlbiB9ID0gZ2V0KCk7XHJcbiAgICAgICAgICBpZiAoIXRva2VuIHx8IHRva2VuID09PSAnbW9jay1vZmZsaW5lLXRva2VuJykgcmV0dXJuO1xyXG4gICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvdXNlcnNgLCB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAuLi4odG9rZW4gPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDEgfHwgcmVzLnN0YXR1cyA9PT0gNDAzKSB7XHJcbiAgICAgICAgICAgIGdldCgpLmhhbmRsZUF1dGhFcnJvcihyZXMuc3RhdHVzKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgICAgICBpZiAoZGF0YS5vaykge1xyXG4gICAgICAgICAgICBzZXQoeyB1c2Vyc0xpc3Q6IGRhdGEuZGF0YSB9KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBjYXJnYXIgbGlzdGEgZGUgdXN1YXJpb3M6JywgZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG5cclxuICAgICAgZmV0Y2hNZXNzYWdlc0xpc3Q6IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgeyB0b2tlbiB9ID0gZ2V0KCk7XHJcbiAgICAgICAgICBpZiAoIXRva2VuIHx8IHRva2VuID09PSAnbW9jay1vZmZsaW5lLXRva2VuJykgcmV0dXJuO1xyXG4gICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvbWVzc2FnZXMvJHt1c2VySWR9YCwge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgLi4uKHRva2VuID8geyAnQXV0aG9yaXphdGlvbic6IGBCZWFyZXIgJHt0b2tlbn1gIH0gOiB7fSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDAxIHx8IHJlcy5zdGF0dXMgPT09IDQwMykge1xyXG4gICAgICAgICAgICBnZXQoKS5oYW5kbGVBdXRoRXJyb3IocmVzLnN0YXR1cyk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgICAgICAgaWYgKGRhdGEub2spIHtcclxuICAgICAgICAgICAgc2V0KHsgbWVzc2FnZXM6IGRhdGEuZGF0YSB9KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBjYXJnYXIgbGlzdGEgZGUgbWVuc2FqZXM6JywgZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG5cclxuICAgICAgY2FyZ2FyRGF0b3NTZXJ2aWRvcjogYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBnZXQoKS5wdWxsSW5pdGlhbERhdGEoKTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIHB1bGxJbml0aWFsRGF0YTogYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHsgdG9rZW4sIHVzZXIgfSA9IGdldCgpO1xyXG4gICAgICAgIGlmICghdG9rZW4gfHwgIW5hdmlnYXRvci5vbkxpbmUgfHwgdG9rZW4gPT09ICdtb2NrLW9mZmxpbmUtdG9rZW4nKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAvLyAxLiBJbnRlbnRhciBkZXNjYXJnYXIgZGF0b3MgdsOtYSAvYXBpL3N5bmMvcHVsbFxyXG4gICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvc3luYy9wdWxsYCwge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiBgQmVhcmVyICR7dG9rZW59YFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDAxIHx8IHJlcy5zdGF0dXMgPT09IDQwMykge1xyXG4gICAgICAgICAgICBnZXQoKS5oYW5kbGVBdXRoRXJyb3IocmVzLnN0YXR1cyk7XHJcbiAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ1Rva2VuIGV4cGlyYWRvJyB9O1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGlmIChyZXMub2spIHtcclxuICAgICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgICAgICAgIGlmIChkYXRhLm9rICYmIEFycmF5LmlzQXJyYXkoZGF0YS5kYXRhKSAmJiBkYXRhLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgIGdldCgpLmltcG9ydENvbXBhbmllcyhkYXRhLmRhdGEpO1xyXG4gICAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNvdW50OiBkYXRhLmRhdGEubGVuZ3RoIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAvLyAyLiBGYWxsYmFjazogU2kgZXMgQURNSU4geSBwdWxsIG5vIGRldm9sdmnDsyBlbXByZXNhcywgaW50ZW50YXIgZXhwb3J0IGRlIGJhc2UgZGUgZGF0b3NcclxuICAgICAgICAgIGlmICh1c2VyICYmIHVzZXIucm9sZSA9PT0gJ0FETUlOJykge1xyXG4gICAgICAgICAgICBjb25zdCByZXNCYWNrdXAgPSBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9iYWNrdXAvZXhwb3J0YCwge1xyXG4gICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWBcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBpZiAocmVzQmFja3VwLnN0YXR1cyA9PT0gNDAxIHx8IHJlc0JhY2t1cC5zdGF0dXMgPT09IDQwMykge1xyXG4gICAgICAgICAgICAgIGdldCgpLmhhbmRsZUF1dGhFcnJvcihyZXNCYWNrdXAuc3RhdHVzKTtcclxuICAgICAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdUb2tlbiBleHBpcmFkbycgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAocmVzQmFja3VwLm9rKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgZGF0YUJhY2t1cCA9IGF3YWl0IHJlc0JhY2t1cC5qc29uKCk7XHJcbiAgICAgICAgICAgICAgaWYgKGRhdGFCYWNrdXAub2sgJiYgQXJyYXkuaXNBcnJheShkYXRhQmFja3VwLmRhdGEpICYmIGRhdGFCYWNrdXAuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICBnZXQoKS5pbXBvcnRDb21wYW5pZXMoZGF0YUJhY2t1cC5kYXRhKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNvdW50OiBkYXRhQmFja3VwLmRhdGEubGVuZ3RoIH07XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgc2luY3Jvbml6YXIgZGF0b3MgaW5pY2lhbGVzIGRlc2RlIGVsIHNlcnZpZG9yOicsIGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuXHJcbiAgICAgIGxvZ2luOiBhc3luYyAodXNlcm5hbWUsIHBhc3N3b3JkKSA9PiB7XHJcbiAgICAgICAgY29uc3QgY2xlYW5Vc2VybmFtZSA9ICh1c2VybmFtZSB8fCAnJykudHJpbSgpO1xyXG4gICAgICAgIGxldCBuZXR3b3JrRmFpbGVkID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgbmF2aWdhdG9yID09PSAndW5kZWZpbmVkJyB8fCBuYXZpZ2F0b3Iub25MaW5lKSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9sb2dpbmAsIHtcclxuICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHVzZXJuYW1lOiBjbGVhblVzZXJuYW1lLCBwYXNzd29yZCB9KVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpLmNhdGNoKCgpID0+ICh7fSkpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHJlcy5vayAmJiBkYXRhLm9rKSB7XHJcbiAgICAgICAgICAgICAgLy8gQ2FjaGVhciB1c3VhcmlvIHBhcmEgc29wb3J0ZSBvZmZsaW5lIHBvc3RlcmlvclxyXG4gICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRVc2VycyA9IGdldCgpLnVzZXJzTGlzdCB8fCBbXTtcclxuICAgICAgICAgICAgICBjb25zdCB1c2VySW5kZXggPSBjdXJyZW50VXNlcnMuZmluZEluZGV4KFxyXG4gICAgICAgICAgICAgICAgdSA9PiAodS51c2VybmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKSA9PT0gZGF0YS51c2VyLnVzZXJuYW1lLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIGxldCB1cGRhdGVkVXNlcnMgPSBbLi4uY3VycmVudFVzZXJzXTtcclxuICAgICAgICAgICAgICBjb25zdCB1c2VyRW50cnkgPSB7XHJcbiAgICAgICAgICAgICAgICBpZDogZGF0YS51c2VyLmlkLFxyXG4gICAgICAgICAgICAgICAgdXNlcm5hbWU6IGRhdGEudXNlci51c2VybmFtZSxcclxuICAgICAgICAgICAgICAgIHJvbGU6IGRhdGEudXNlci5yb2xlLFxyXG4gICAgICAgICAgICAgICAgY29tcGFueUlkOiBkYXRhLnVzZXIuY29tcGFueUlkLFxyXG4gICAgICAgICAgICAgICAgY2FjaGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgIGlmICh1c2VySW5kZXggPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgdXBkYXRlZFVzZXJzW3VzZXJJbmRleF0gPSB7IC4uLnVwZGF0ZWRVc2Vyc1t1c2VySW5kZXhdLCAuLi51c2VyRW50cnkgfTtcclxuICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdXBkYXRlZFVzZXJzLnB1c2godXNlckVudHJ5KTtcclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGxvY2FsU3RvcmFnZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3VzZXInLCBKU09OLnN0cmluZ2lmeShkYXRhLnVzZXIpKTtcclxuICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Rva2VuJywgZGF0YS50b2tlbik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgICAgICAgc2V0KHsgXHJcbiAgICAgICAgICAgICAgICB1c2VyOiBkYXRhLnVzZXIsIFxyXG4gICAgICAgICAgICAgICAgdG9rZW46IGRhdGEudG9rZW4sXHJcbiAgICAgICAgICAgICAgICB1c2Vyc0xpc3Q6IHVwZGF0ZWRVc2Vyc1xyXG4gICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICBnZXQoKS5mZXRjaE1lc3NhZ2VzTGlzdChkYXRhLnVzZXIuaWQpO1xyXG4gICAgICAgICAgICAgIGdldCgpLmZldGNoVXNlcnNMaXN0KCk7XHJcbiAgICAgICAgICAgICAgZ2V0KCkucHVsbEluaXRpYWxEYXRhKCk7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgdXNlcjogZGF0YS51c2VyIH07XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIFNpIGVsIHNlcnZpZG9yIHJlc3BvbmRpw7MgY29uIGVycm9yIGRlIGNyZWRlbmNpYWxlcyBleHBsw61jaXRvICg0MDEsIDQwMCwgNDAzKVxyXG4gICAgICAgICAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDAxIHx8IHJlcy5zdGF0dXMgPT09IDQwMCB8fCByZXMuc3RhdHVzID09PSA0MDMpIHtcclxuICAgICAgICAgICAgICByZXR1cm4geyBcclxuICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLCBcclxuICAgICAgICAgICAgICAgIGVycm9yOiBkYXRhLmVycm9yIHx8ICdVc3VhcmlvIG8gY29udHJhc2XDsWEgaW5jb3JyZWN0b3MuJyBcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAocmVzLnN0YXR1cyA+PSA1MDApIHtcclxuICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBlcnJvcjogZGF0YS5lcnJvciB8fCBgRXJyb3IgZW4gZWwgc2Vydmlkb3IgKCR7cmVzLnN0YXR1c30pLiBJbnRlbnRlIG51ZXZhbWVudGUuYFxyXG4gICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCfimqDvuI8gRXJyb3IgZGUgY29uZXhpw7NuIGNvbiBlbCBzZXJ2aWRvciBjZW50cmFsIGFsIGluaWNpYXIgc2VzacOzbjonLCBlKTtcclxuICAgICAgICAgICAgbmV0d29ya0ZhaWxlZCA9IHRydWU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIG5ldHdvcmtGYWlsZWQgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gRmFsbGJhY2sgb2ZmbGluZTogc29sbyBzaSBsYSByZWQgZmFsbMOzIG8gZWwgZGlzcG9zaXRpdm8gZXN0w6EgZGVzY29uZWN0YWRvXHJcbiAgICAgICAgaWYgKG5ldHdvcmtGYWlsZWQpIHtcclxuICAgICAgICAgIGNvbnN0IGxpc3QgPSBnZXQoKS51c2Vyc0xpc3QgfHwgW107XHJcbiAgICAgICAgICBjb25zdCBpbnB1dEtleSA9IGNsZWFuVXNlcm5hbWUudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgIGNvbnN0IGZvdW5kID0gbGlzdC5maW5kKCh1KSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IHVzZXJLZXkgPSAodS51c2VybmFtZSB8fCB1LmVtYWlsIHx8ICcnKS50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcclxuICAgICAgICAgICAgcmV0dXJuIHVzZXJLZXkgPT09IGlucHV0S2V5IHx8XHJcbiAgICAgICAgICAgICAgICAgICAodXNlcktleSA9PT0gJ2FkbWluMScgJiYgaW5wdXRLZXkgPT09ICdhZG1pbjFAc2VsZWN0cmljLmNvbScpIHx8XHJcbiAgICAgICAgICAgICAgICAgICAodXNlcktleSA9PT0gJ2FkbWluMUBzZWxlY3RyaWMuY29tJyAmJiBpbnB1dEtleSA9PT0gJ2FkbWluMScpO1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgaWYgKGZvdW5kKSB7XHJcbiAgICAgICAgICAgIHNldCh7IFxyXG4gICAgICAgICAgICAgIHVzZXI6IHsgaWQ6IGZvdW5kLmlkLCB1c2VybmFtZTogZm91bmQudXNlcm5hbWUsIHJvbGU6IGZvdW5kLnJvbGUsIGNvbXBhbnlJZDogZm91bmQuY29tcGFueUlkIH0sIFxyXG4gICAgICAgICAgICAgIHRva2VuOiAnbW9jay1vZmZsaW5lLXRva2VuJyBcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGdldCgpLnB1bGxJbml0aWFsRGF0YSgpO1xyXG4gICAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCB1c2VyOiBmb3VuZCwgaXNPZmZsaW5lOiB0cnVlIH07XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgcmV0dXJuIHsgXHJcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLCBcclxuICAgICAgICAgICAgZXJyb3I6ICdTaW4gY29uZXhpw7NuIGFsIHNlcnZpZG9yIGNlbnRyYWwuIEluaWNpZSBzZXNpw7NuIGNvbiBpbnRlcm5ldCBwb3IgcHJpbWVyYSB2ZXogcGFyYSBoYWJpbGl0YXIgZWwgbW9kbyBvZmZsaW5lIHBhcmEgZXN0ZSB1c3VhcmlvLicsXHJcbiAgICAgICAgICAgIGlzTmV0d29ya0Vycm9yOiB0cnVlIFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ1VzdWFyaW8gbyBjb250cmFzZcOxYSBpbmNvcnJlY3Rvcy4nIH07XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBsb2dvdXQ6ICgpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd0b2tlbicpO1xyXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndXNlcicpO1xyXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndXN1YXJpbycpO1xyXG4gICAgICAgICAgICBzZXNzaW9uU3RvcmFnZS5jbGVhcigpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgc2V0KHsgdXNlcjogbnVsbCwgdG9rZW46IG51bGwgfSk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSAhPT0gJy9sb2dpbicpIHtcclxuICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZXBsYWNlKCcvbG9naW4nKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBhZGRVc2VyOiBhc3luYyAodXNlck9iaikgPT4ge1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRVc2VyID0gZ2V0KCkudXNlcjtcclxuICAgICAgICBpZiAoIWN1cnJlbnRVc2VyIHx8IGN1cnJlbnRVc2VyLnJvbGUgIT09ICdBRE1JTicpIHtcclxuICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0FjY2nDs24gcGVybWl0aWRhIMO6bmljYW1lbnRlIHBhcmEgYWRtaW5pc3RyYWRvcmVzLicgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHVzZXJuYW1lTG93ZXIgPSB1c2VyT2JqLnVzZXJuYW1lLnRvTG93ZXJDYXNlKCkudHJpbSgpO1xyXG4gICAgICAgIGNvbnN0IGV4aXN0cyA9IChnZXQoKS51c2Vyc0xpc3QgfHwgW10pLnNvbWUoXHJcbiAgICAgICAgICAodSkgPT4gKHUudXNlcm5hbWUgfHwgdS5lbWFpbCB8fCAnJykudG9Mb3dlckNhc2UoKS50cmltKCkgPT09IHVzZXJuYW1lTG93ZXJcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChleGlzdHMpIHtcclxuICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ1lhIGV4aXN0ZSB1biB1c3VhcmlvIGNvbiBlc3RlIG5vbWJyZSBkZSB1c3VhcmlvLicgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IG5ld1VzZXIgPSB7XHJcbiAgICAgICAgICBpZDogYHVzZXItJHtEYXRlLm5vdygpfWAsXHJcbiAgICAgICAgICB1c2VybmFtZTogdXNlck9iai51c2VybmFtZS50cmltKCksXHJcbiAgICAgICAgICBwYXNzd29yZDogdXNlck9iai5wYXNzd29yZCxcclxuICAgICAgICAgIHJvbGU6IHVzZXJPYmoucm9sZSB8fCAnV09SS0VSJyxcclxuICAgICAgICAgIGNvbXBhbnlJZDogdXNlck9iai5yb2xlID09PSAnQ0xJRU5UJyA/IHVzZXJPYmouY29tcGFueUlkIDogbnVsbFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHNldCgoc3RhdGUpID0+ICh7XHJcbiAgICAgICAgICB1c2Vyc0xpc3Q6IFsuLi4oc3RhdGUudXNlcnNMaXN0IHx8IFtdKSwgbmV3VXNlcl1cclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCB7IHRva2VuIH0gPSBnZXQoKTtcclxuICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL3VzZXJzYCwge1xyXG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgLi4uKHRva2VuID8geyAnQXV0aG9yaXphdGlvbic6IGBCZWFyZXIgJHt0b2tlbn1gIH0gOiB7fSlcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkobmV3VXNlcilcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgICAgICBpZiAoZGF0YS5vaykge1xyXG4gICAgICAgICAgICBnZXQoKS5mZXRjaFVzZXJzTGlzdCgpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHNpbmNyb25pemFuZG8gbnVldm8gdXN1YXJpbzonLCBlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHVzZXI6IG5ld1VzZXIgfTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIHVwZGF0ZVVzZXI6IGFzeW5jICh1c2VySWQsIHVwZGF0ZWREYXRhKSA9PiB7XHJcbiAgICAgICAgY29uc3QgY3VycmVudFVzZXIgPSBnZXQoKS51c2VyO1xyXG4gICAgICAgIGlmICghY3VycmVudFVzZXIgfHwgY3VycmVudFVzZXIucm9sZSAhPT0gJ0FETUlOJykge1xyXG4gICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnQWNjacOzbiBwZXJtaXRpZGEgw7puaWNhbWVudGUgcGFyYSBhZG1pbmlzdHJhZG9yZXMuJyB9O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgdXNlcm5hbWVMb3dlciA9IHVwZGF0ZWREYXRhLnVzZXJuYW1lPy50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcclxuICAgICAgICBjb25zdCBleGlzdHNPdGhlciA9IChnZXQoKS51c2Vyc0xpc3QgfHwgW10pLnNvbWUoXHJcbiAgICAgICAgICAodSkgPT4gdS5pZCAhPT0gdXNlcklkICYmICh1LnVzZXJuYW1lIHx8IHUuZW1haWwgfHwgJycpLnRvTG93ZXJDYXNlKCkudHJpbSgpID09PSB1c2VybmFtZUxvd2VyXHJcbiAgICAgICAgKTtcclxuICAgICAgICBpZiAoZXhpc3RzT3RoZXIpIHtcclxuICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ1lhIGV4aXN0ZSBvdHJvIHVzdWFyaW8gY29uIGVzdGUgbm9tYnJlIGRlIHVzdWFyaW8uJyB9O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgbWVyZ2VkRGF0YSA9IHtcclxuICAgICAgICAgIC4uLnVwZGF0ZWREYXRhLFxyXG4gICAgICAgICAgY29tcGFueUlkOiB1cGRhdGVkRGF0YS5yb2xlID09PSAnQ0xJRU5UJyA/IHVwZGF0ZWREYXRhLmNvbXBhbnlJZCA6IG51bGxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBzZXQoKHN0YXRlKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCB1cGRhdGVkTGlzdCA9IChzdGF0ZS51c2Vyc0xpc3QgfHwgW10pLm1hcCgodSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAodS5pZCA9PT0gdXNlcklkKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHsgLi4udSwgLi4ubWVyZ2VkRGF0YSB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB1O1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgY29uc3QgY3VycmVudExvZ2dlZFVzZXIgPSB1cGRhdGVkTGlzdC5maW5kKCh1KSA9PiB1LmlkID09PSBzdGF0ZS51c2VyPy5pZCk7XHJcblxyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgdXNlcnNMaXN0OiB1cGRhdGVkTGlzdCxcclxuICAgICAgICAgICAgdXNlcjogY3VycmVudExvZ2dlZFVzZXIgfHwgc3RhdGUudXNlclxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IHsgdG9rZW4gfSA9IGdldCgpO1xyXG4gICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvdXNlcnMvJHt1c2VySWR9YCwge1xyXG4gICAgICAgICAgICBtZXRob2Q6ICdQVVQnLFxyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAuLi4odG9rZW4gPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShtZXJnZWREYXRhKVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgICAgIGlmIChkYXRhLm9rKSB7XHJcbiAgICAgICAgICAgIGdldCgpLmZldGNoVXNlcnNMaXN0KCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWN0dWFsaXphbmRvIHVzdWFyaW8gZW4gYmFzZSBkZSBkYXRvczonLCBlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIGRlbGV0ZVVzZXI6IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgICAgICBjb25zdCBjdXJyZW50VXNlciA9IGdldCgpLnVzZXI7XHJcbiAgICAgICAgaWYgKCFjdXJyZW50VXNlciB8fCBjdXJyZW50VXNlci5yb2xlICE9PSAnQURNSU4nKSB7XHJcbiAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdBY2Npw7NuIHBlcm1pdGlkYSDDum5pY2FtZW50ZSBwYXJhIGFkbWluaXN0cmFkb3Jlcy4nIH07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCB1c2VyVG9EZWxldGUgPSAoZ2V0KCkudXNlcnNMaXN0IHx8IFtdKS5maW5kKCh1KSA9PiB1LmlkID09PSB1c2VySWQpO1xyXG4gICAgICAgIGlmICh1c2VyVG9EZWxldGUgJiYgKHVzZXJUb0RlbGV0ZS51c2VybmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKSA9PT0gJ2FkbWluMScpIHtcclxuICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0VsIHVzdWFyaW8gYWRtaW5pc3RyYWRvciBwcmluY2lwYWwgKGFkbWluMSkgZXN0w6EgcHJvdGVnaWRvIHkgbm8gc2UgcHVlZGUgZWxpbWluYXIuJyB9O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGN1cnJlbnRVc2VyLmlkID09PSB1c2VySWQpIHtcclxuICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ05vIHB1ZWRlcyBlbGltaW5hciB0dSBwcm9waWEgY3VlbnRhIGRlIHVzdWFyaW8gYWN0aXZvLicgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldCgoc3RhdGUpID0+ICh7XHJcbiAgICAgICAgICB1c2Vyc0xpc3Q6IChzdGF0ZS51c2Vyc0xpc3QgfHwgW10pLmZpbHRlcigodSkgPT4gdS5pZCAhPT0gdXNlcklkKVxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IHsgdG9rZW4gfSA9IGdldCgpO1xyXG4gICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvdXNlcnMvJHt1c2VySWR9YCwge1xyXG4gICAgICAgICAgICBtZXRob2Q6ICdERUxFVEUnLFxyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgLi4uKHRva2VuID8geyAnQXV0aG9yaXphdGlvbic6IGBCZWFyZXIgJHt0b2tlbn1gIH0gOiB7fSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgICAgIGlmIChkYXRhLm9rKSB7XHJcbiAgICAgICAgICAgIGdldCgpLmZldGNoVXNlcnNMaXN0KCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZWxpbWluYW5kbyB1c3VhcmlvIGVuIGJhc2UgZGUgZGF0b3M6JywgZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICB1cGRhdGVFbXByZXNhOiBhc3luYyAoY29tcGFueUlkLCB1cGRhdGVkRGF0YSkgPT4ge1xyXG4gICAgICAgIHNldCgoc3RhdGUpID0+ICh7XHJcbiAgICAgICAgICBjb21wYW5pZXM6IHN0YXRlLmNvbXBhbmllcy5tYXAoKGMpID0+IHtcclxuICAgICAgICAgICAgaWYgKGMuaWQgPT09IGNvbXBhbnlJZCkge1xyXG4gICAgICAgICAgICAgIHJldHVybiB7IC4uLmMsIC4uLnVwZGF0ZWREYXRhIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIGM7XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgaWYgKG5hdmlnYXRvci5vbkxpbmUpIHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHsgdG9rZW4gfSA9IGdldCgpO1xyXG4gICAgICAgICAgICBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9lbXByZXNhcy8ke2NvbXBhbnlJZH1gLCB7XHJcbiAgICAgICAgICAgICAgbWV0aG9kOiAnUFVUJyxcclxuICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgLi4uKHRva2VuID8geyAnQXV0aG9yaXphdGlvbic6IGBCZWFyZXIgJHt0b2tlbn1gIH0gOiB7fSlcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHVwZGF0ZWREYXRhKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgYWN0dWFsaXphciBlbXByZXNhIGVuIGVsIHNlcnZpZG9yOicsIGUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuXHJcbiAgICAgIHVwZGF0ZVByb3llY3RvOiBhc3luYyAoY29tcGFueUlkLCBwcm95ZWN0b0lkLCB1cGRhdGVkRGF0YSkgPT4ge1xyXG4gICAgICAgIHNldCgoc3RhdGUpID0+ICh7XHJcbiAgICAgICAgICBjb21wYW5pZXM6IHN0YXRlLmNvbXBhbmllcy5tYXAoKGMpID0+IHtcclxuICAgICAgICAgICAgaWYgKGMuaWQgPT09IGNvbXBhbnlJZCkge1xyXG4gICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICAgICAgcHJveWVjdG9zOiAoYy5wcm95ZWN0b3MgfHwgW10pLm1hcCgocCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAocC5pZCA9PT0gcHJveWVjdG9JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLnAsIC4uLnVwZGF0ZWREYXRhIH07XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHA7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIGM7XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgaWYgKG5hdmlnYXRvci5vbkxpbmUpIHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHsgdG9rZW4gfSA9IGdldCgpO1xyXG4gICAgICAgICAgICBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9wcm95ZWN0b3MvJHtwcm95ZWN0b0lkfWAsIHtcclxuICAgICAgICAgICAgICBtZXRob2Q6ICdQVVQnLFxyXG4gICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAuLi4odG9rZW4gPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KVxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkodXBkYXRlZERhdGEpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBhY3R1YWxpemFyIHByb3llY3RvIGVuIGVsIHNlcnZpZG9yOicsIGUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuXHJcbiAgICAgIGZldGNoQWxpbWVudGFkb3JlczogYXN5bmMgKHByb3llY3RvSWQpID0+IHtcclxuICAgICAgICBpZiAobmF2aWdhdG9yLm9uTGluZSkge1xyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgeyB0b2tlbiB9ID0gZ2V0KCk7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2FsaW1lbnRhZG9yZXM/cHJveWVjdG9JZD0ke3Byb3llY3RvSWR9YCwge1xyXG4gICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgIC4uLih0b2tlbiA/IHsgJ0F1dGhvcml6YXRpb24nOiBgQmVhcmVyICR7dG9rZW59YCB9IDoge30pXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgICAgICAgIGlmIChkYXRhLm9rKSB7XHJcbiAgICAgICAgICAgICAgc2V0KChzdGF0ZSkgPT4gKHtcclxuICAgICAgICAgICAgICAgIGNvbXBhbmllczogc3RhdGUuY29tcGFuaWVzLm1hcCgoYykgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgLi4uYyxcclxuICAgICAgICAgICAgICAgICAgcHJveWVjdG9zOiAoYy5wcm95ZWN0b3MgfHwgW10pLm1hcCgocCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwLmlkID09PSBwcm95ZWN0b0lkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5wLCBhbGltZW50YWRvcmVzOiBkYXRhLmRhdGEgfTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHA7XHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgb2J0ZW5lciBhbGltZW50YWRvcmVzOicsIGUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuXHJcbiAgICAgIGFkZEFsaW1lbnRhZG9yOiBhc3luYyAoYWxpbWVudGFkb3JEYXRhKSA9PiB7XHJcbiAgICAgICAgY29uc3QgeyBwcm95ZWN0b0lkIH0gPSBhbGltZW50YWRvckRhdGE7XHJcbiAgICAgICAgY29uc3QgbmV3QWxpbWVudGFkb3IgPSB7XHJcbiAgICAgICAgICBpZDogYWxpbWVudGFkb3JEYXRhLmlkIHx8IGNyeXB0by5yYW5kb21VVUlEKCksXHJcbiAgICAgICAgICAuLi5hbGltZW50YWRvckRhdGFcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBzZXQoKHN0YXRlKSA9PiAoe1xyXG4gICAgICAgICAgY29tcGFuaWVzOiBzdGF0ZS5jb21wYW5pZXMubWFwKChjKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICBwcm95ZWN0b3M6IChjLnByb3llY3RvcyB8fCBbXSkubWFwKChwKSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKHAuaWQgPT09IHByb3llY3RvSWQpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRBbGltcyA9IHAuYWxpbWVudGFkb3JlcyB8fCBbXTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLnAsIGFsaW1lbnRhZG9yZXM6IFsuLi5jdXJyZW50QWxpbXMsIG5ld0FsaW1lbnRhZG9yXSB9O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICByZXR1cm4gcDtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH0pKVxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgaWYgKG5hdmlnYXRvci5vbkxpbmUpIHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHsgdG9rZW4gfSA9IGdldCgpO1xyXG4gICAgICAgICAgICBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9hbGltZW50YWRvcmVzYCwge1xyXG4gICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAuLi4odG9rZW4gPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KVxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkobmV3QWxpbWVudGFkb3IpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBndWFyZGFyIGFsaW1lbnRhZG9yOicsIGUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuXHJcbiAgICAgIGRlbGV0ZUFsaW1lbnRhZG9yOiBhc3luYyAocHJveWVjdG9JZCwgYWxpbWVudGFkb3JJZCkgPT4ge1xyXG4gICAgICAgIHNldCgoc3RhdGUpID0+ICh7XHJcbiAgICAgICAgICBjb21wYW5pZXM6IHN0YXRlLmNvbXBhbmllcy5tYXAoKGMpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLmMsXHJcbiAgICAgICAgICAgIHByb3llY3RvczogKGMucHJveWVjdG9zIHx8IFtdKS5tYXAoKHApID0+IHtcclxuICAgICAgICAgICAgICBpZiAocC5pZCA9PT0gcHJveWVjdG9JZCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgY3VycmVudEFsaW1zID0gcC5hbGltZW50YWRvcmVzIHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgLi4ucCwgYWxpbWVudGFkb3JlczogY3VycmVudEFsaW1zLmZpbHRlcihhID0+IGEuaWQgIT09IGFsaW1lbnRhZG9ySWQpIH07XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHJldHVybiBwO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfSkpXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICBpZiAobmF2aWdhdG9yLm9uTGluZSkge1xyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgeyB0b2tlbiB9ID0gZ2V0KCk7XHJcbiAgICAgICAgICAgIGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2FsaW1lbnRhZG9yZXMvJHthbGltZW50YWRvcklkfWAsIHtcclxuICAgICAgICAgICAgICBtZXRob2Q6ICdERUxFVEUnLFxyXG4gICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgIC4uLih0b2tlbiA/IHsgJ0F1dGhvcml6YXRpb24nOiBgQmVhcmVyICR7dG9rZW59YCB9IDoge30pXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgZWxpbWluYXIgYWxpbWVudGFkb3I6JywgZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG5cclxuICAgICAgdXBkYXRlVGFibGVyb0FsaW1lbnRhZG9yOiAocHJveWVjdG9JZCwgdGFibGVyb0lkLCBhbGltZW50YWRvcklkKSA9PiB7XHJcbiAgICAgICAgc2V0KChzdGF0ZSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgdXBkYXRlRWxlbWVudCA9IChlKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChlLmlkID09PSB0YWJsZXJvSWQpIHtcclxuICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uZSxcclxuICAgICAgICAgICAgICAgIGRhdG9zVGVjbmljb3M6IHtcclxuICAgICAgICAgICAgICAgICAgLi4uZS5kYXRvc1RlY25pY29zLFxyXG4gICAgICAgICAgICAgICAgICBhbGltZW50YWRvcklkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gZTtcclxuICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgY29uc3QgdXBkYXRlZENvbXBhbmllcyA9IHN0YXRlLmNvbXBhbmllcy5tYXAoKGMpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFwcm95ZWN0b0lkKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgbGlzdCA9IGMuZWxlbWVudG9zVW5pZmlsYXJlcyB8fCBbXTtcclxuICAgICAgICAgICAgICByZXR1cm4geyAuLi5jLCBlbGVtZW50b3NVbmlmaWxhcmVzOiBsaXN0Lm1hcCh1cGRhdGVFbGVtZW50KSB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgLi4uYyxcclxuICAgICAgICAgICAgICBwcm95ZWN0b3M6IChjLnByb3llY3RvcyB8fCBbXSkubWFwKChwKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAocC5pZCA9PT0gcHJveWVjdG9JZCkge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBsaXN0ID0gcC5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IHAudGFibGVyb3MgfHwgW107XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLnAsIGVsZW1lbnRvc1VuaWZpbGFyZXM6IGxpc3QubWFwKHVwZGF0ZUVsZW1lbnQpIH07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcDtcclxuICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgLy8gT2J0ZW5lciBlbCBlbGVtZW50byBsb2NhbGVzIHBhcmEgZW5jb2xhclxyXG4gICAgICAgICAgY29uc3QgYWxsRWxlbWVudHMgPSBzdGF0ZS5lbGVtZW50b3NMb2NhbGVzIHx8IFtdO1xyXG4gICAgICAgICAgY29uc3QgdXBkYXRlZEVsZW1lbnQgPSBhbGxFbGVtZW50cy5maW5kKGUgPT4gZS5pZCA9PT0gdGFibGVyb0lkKTtcclxuICAgICAgICAgIGxldCBwYXlsb2FkID0gbnVsbDtcclxuICAgICAgICAgIGlmICh1cGRhdGVkRWxlbWVudCkge1xyXG4gICAgICAgICAgICBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAgIC4uLnVwZGF0ZWRFbGVtZW50LFxyXG4gICAgICAgICAgICAgIGRhdG9zVGVjbmljb3M6IHtcclxuICAgICAgICAgICAgICAgIC4uLnVwZGF0ZWRFbGVtZW50LmRhdG9zVGVjbmljb3MsXHJcbiAgICAgICAgICAgICAgICBhbGltZW50YWRvcklkXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGNvbXBhbmllczogdXBkYXRlZENvbXBhbmllcyxcclxuICAgICAgICAgICAgZWxlbWVudG9zTG9jYWxlczogKHN0YXRlLmVsZW1lbnRvc0xvY2FsZXMgfHwgW10pLm1hcCh1cGRhdGVFbGVtZW50KSxcclxuICAgICAgICAgICAgc3luY1F1ZXVlOiBwYXlsb2FkID8gWy4uLnN0YXRlLnN5bmNRdWV1ZSwge1xyXG4gICAgICAgICAgICAgIGlkOiB0YWJsZXJvSWQsXHJcbiAgICAgICAgICAgICAgdGlwbzogJ0VMRU1FTlRPX1VOSUZJTEFSJyxcclxuICAgICAgICAgICAgICBjb21wYW55SWQ6IHVwZGF0ZWRFbGVtZW50ID8gKHVwZGF0ZWRFbGVtZW50LmNvbXBhbnlJZCB8fCB1cGRhdGVkRWxlbWVudC5lbXByZXNhSWQpIDogbnVsbCxcclxuICAgICAgICAgICAgICBwYXlsb2FkXHJcbiAgICAgICAgICAgIH1dIDogc3RhdGUuc3luY1F1ZXVlXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG5cclxuICAgICAgYWRkQ29tcGFueTogYXN5bmMgKGNvbXBhbnlEYXRhKSA9PiB7XHJcbiAgICAgICAgY29uc3QgbmV3Q29tcGFueSA9IHtcclxuICAgICAgICAgIGlkOiBjb21wYW55RGF0YS5pZCB8fCBgY29tcGFueS0ke0RhdGUubm93KCl9YCxcclxuICAgICAgICAgIG5vbWJyZTogY29tcGFueURhdGEubm9tYnJlLFxyXG4gICAgICAgICAgcmlmOiBjb21wYW55RGF0YS5yaWYsXHJcbiAgICAgICAgICBkaXJlY2Npb25GaXNjYWw6IGNvbXBhbnlEYXRhLmRpcmVjY2lvbkZpc2NhbCxcclxuICAgICAgICAgIGRpcmVjY2lvbjogY29tcGFueURhdGEuZGlyZWNjaW9uIHx8IGNvbXBhbnlEYXRhLmRpcmVjY2lvbkZpc2NhbCB8fCAnJyxcclxuICAgICAgICAgIGdlcmVudGUxTm9tYnJlOiBjb21wYW55RGF0YS5nZXJlbnRlMU5vbWJyZSB8fCBudWxsLFxyXG4gICAgICAgICAgZ2VyZW50ZTFUZWxlZm9ubzogY29tcGFueURhdGEuZ2VyZW50ZTFUZWxlZm9ubyB8fCBudWxsLFxyXG4gICAgICAgICAgZ2VyZW50ZTFFbWFpbDogY29tcGFueURhdGEuZ2VyZW50ZTFFbWFpbCB8fCBudWxsLFxyXG4gICAgICAgICAgZ2VyZW50ZTJOb21icmU6IGNvbXBhbnlEYXRhLmdlcmVudGUyTm9tYnJlIHx8IG51bGwsXHJcbiAgICAgICAgICBnZXJlbnRlMlRlbGVmb25vOiBjb21wYW55RGF0YS5nZXJlbnRlMlRlbGVmb25vIHx8IG51bGwsXHJcbiAgICAgICAgICBnZXJlbnRlMkVtYWlsOiBjb21wYW55RGF0YS5nZXJlbnRlMkVtYWlsIHx8IG51bGwsXHJcbiAgICAgICAgICBwcm95ZWN0b3M6IFtdXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgc2V0KChzdGF0ZSkgPT4gKHtcclxuICAgICAgICAgIGNvbXBhbmllczogWy4uLnN0YXRlLmNvbXBhbmllcywgbmV3Q29tcGFueV1cclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIGlmIChuYXZpZ2F0b3Iub25MaW5lKSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCB7IHRva2VuIH0gPSBnZXQoKTtcclxuICAgICAgICAgICAgYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvZW1wcmVzYXNgLCB7XHJcbiAgICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgIC4uLih0b2tlbiA/IHsgJ0F1dGhvcml6YXRpb24nOiBgQmVhcmVyICR7dG9rZW59YCB9IDoge30pXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShuZXdDb21wYW55KVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgcmVnaXN0cmFyIGVtcHJlc2EgZW4gZWwgc2Vydmlkb3I6JywgZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG5cclxuICAgICAgZGVsZXRlQ29tcGFueTogKGNvbXBhbnlJZCkgPT4ge1xyXG4gICAgICAgIHNldCgoc3RhdGUpID0+ICh7XHJcbiAgICAgICAgICBjb21wYW5pZXM6IHN0YXRlLmNvbXBhbmllcy5maWx0ZXIoKGMpID0+IGMuaWQgIT09IGNvbXBhbnlJZClcclxuICAgICAgICB9KSk7XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICB1cGRhdGVQcm95ZWN0bzogYXN5bmMgKGNvbXBhbnlJZCwgcHJveWVjdG9JZCwgdXBkYXRlZERhdGEpID0+IHtcclxuICAgICAgICBzZXQoKHN0YXRlKSA9PiAoe1xyXG4gICAgICAgICAgY29tcGFuaWVzOiBzdGF0ZS5jb21wYW5pZXMubWFwKChjKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChjLmlkID09PSBjb21wYW55SWQpIHtcclxuICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uYyxcclxuICAgICAgICAgICAgICAgIHByb3llY3RvczogKGMucHJveWVjdG9zIHx8IFtdKS5tYXAoKHApID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKHAuaWQgPT09IHByb3llY3RvSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5wLCAuLi51cGRhdGVkRGF0YSB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiBwO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBjO1xyXG4gICAgICAgICAgfSksXHJcbiAgICAgICAgICBwcm95ZWN0b3NMb2NhbGVzOiAoc3RhdGUucHJveWVjdG9zTG9jYWxlcyB8fCBbXSkubWFwKChwKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChwLmlkID09PSBwcm95ZWN0b0lkKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHsgLi4ucCwgLi4udXBkYXRlZERhdGEgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcDtcclxuICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgc3luY1F1ZXVlOiBbLi4uc3RhdGUuc3luY1F1ZXVlLCB7XHJcbiAgICAgICAgICAgIGlkOiBwcm95ZWN0b0lkLFxyXG4gICAgICAgICAgICB0aXBvOiAnUFJPWUVDVE8nLFxyXG4gICAgICAgICAgICBjb21wYW55SWQsXHJcbiAgICAgICAgICAgIHBheWxvYWQ6IHsgaWQ6IHByb3llY3RvSWQsIC4uLnVwZGF0ZWREYXRhLCBlbXByZXNhSWQ6IGNvbXBhbnlJZCB9XHJcbiAgICAgICAgICB9XVxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgaWYgKG5hdmlnYXRvci5vbkxpbmUpIHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHsgdG9rZW4gfSA9IGdldCgpO1xyXG4gICAgICAgICAgICBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9wcm95ZWN0b3MvJHtwcm95ZWN0b0lkfWAsIHtcclxuICAgICAgICAgICAgICBtZXRob2Q6ICdQVVQnLFxyXG4gICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAuLi4odG9rZW4gJiYgdG9rZW4gIT09ICdtb2NrLW9mZmxpbmUtdG9rZW4nID8geyAnQXV0aG9yaXphdGlvbic6IGBCZWFyZXIgJHt0b2tlbn1gIH0gOiB7fSlcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHVwZGF0ZWREYXRhKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgYWN0dWFsaXphciBwcm95ZWN0byBlbiBlbCBzZXJ2aWRvcjonLCBlKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBkZWxldGVQcm95ZWN0bzogYXN5bmMgKGNvbXBhbnlJZCwgcHJveWVjdG9JZCkgPT4ge1xyXG4gICAgICAgIHNldCgoc3RhdGUpID0+ICh7XHJcbiAgICAgICAgICBjb21wYW5pZXM6IHN0YXRlLmNvbXBhbmllcy5tYXAoKGMpID0+IHtcclxuICAgICAgICAgICAgaWYgKGMuaWQgPT09IGNvbXBhbnlJZCkge1xyXG4gICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICAgICAgcHJveWVjdG9zOiAoYy5wcm95ZWN0b3MgfHwgW10pLmZpbHRlcigocCkgPT4gcC5pZCAhPT0gcHJveWVjdG9JZClcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBjO1xyXG4gICAgICAgICAgfSksXHJcbiAgICAgICAgICBwcm95ZWN0b3NMb2NhbGVzOiAoc3RhdGUucHJveWVjdG9zTG9jYWxlcyB8fCBbXSkuZmlsdGVyKChwKSA9PiBwLmlkICE9PSBwcm95ZWN0b0lkKSxcclxuICAgICAgICAgIHN5bmNRdWV1ZTogc3RhdGUuc3luY1F1ZXVlLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5pZCAhPT0gcHJveWVjdG9JZClcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIGlmIChuYXZpZ2F0b3Iub25MaW5lKSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCB7IHRva2VuIH0gPSBnZXQoKTtcclxuICAgICAgICAgICAgYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvcHJveWVjdG9zLyR7cHJveWVjdG9JZH1gLCB7XHJcbiAgICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcclxuICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAuLi4odG9rZW4gPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGVsaW1pbmFyIHByb3llY3RvIGRlbCBzZXJ2aWRvcjonLCBlKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBpbXBvcnRDb21wYW5pZXM6IChjb21wYW5pZXNMaXN0KSA9PiB7XHJcbiAgICAgICAgY29uc3QgZW5yaWNoZWRMaXN0ID0gY29tcGFuaWVzTGlzdC5tYXAoKGMpID0+ICh7XHJcbiAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgcHJveWVjdG9zOiAoYy5wcm95ZWN0b3MgfHwgW10pLm1hcCgocCkgPT4gKHtcclxuICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgZWxlbWVudG9zVW5pZmlsYXJlczogcC5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IHAudGFibGVyb3MgfHwgW10sXHJcbiAgICAgICAgICAgIGluc3BlY2Npb25lc1N1YmVzdGFjaW9uOiBwLmluc3BlY2Npb25lc1N1YmVzdGFjaW9uIHx8IHAuc3ViZXN0YWNpb25lcyB8fCBbXSxcclxuICAgICAgICAgICAgcHVudG9zTWVkaWNpb246IHAucHVudG9zTWVkaWNpb24gfHwgW10sXHJcbiAgICAgICAgICAgIGNjbUxpc3Q6IHAuY2NtTGlzdCB8fCBbXVxyXG4gICAgICAgICAgfSkpXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldCh7IGNvbXBhbmllczogZW5yaWNoZWRMaXN0IH0pO1xyXG4gICAgICB9LFxyXG5cclxuICAgICAgYWRkUHJveWVjdG86IChub21icmUsIGRlc2NyaXBjaW9uLCBjb21wYW55SWQpID0+IHtcclxuICAgICAgICBjb25zdCB7IGNvbXBhbmllcyB9ID0gZ2V0KCk7XHJcbiAgICAgICAgY29uc3QgY29tcGFueSA9IGNvbXBhbmllcy5maW5kKChjKSA9PiBjLmlkID09PSBjb21wYW55SWQpO1xyXG4gICAgICAgIGlmICghY29tcGFueSkgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnRW1wcmVzYSBubyBlbmNvbnRyYWRhLicgfTtcclxuXHJcbiAgICAgICAgY29uc3QgdXVpZElkID0gY3J5cHRvLnJhbmRvbVVVSUQoKTtcclxuXHJcbiAgICAgICAgY29uc3QgbnVldm9Qcm95ZWN0byA9IHtcclxuICAgICAgICAgIGlkOiB1dWlkSWQsXHJcbiAgICAgICAgICBub21icmUsXHJcbiAgICAgICAgICBkZXNjcmlwY2lvbjogZGVzY3JpcGNpb24gfHwgJycsXHJcbiAgICAgICAgICBlbXByZXNhSWQ6IGNvbXBhbnlJZCxcclxuICAgICAgICAgIGVsZW1lbnRvc1VuaWZpbGFyZXM6IFtdLFxyXG4gICAgICAgICAgaW5zcGVjY2lvbmVzU3ViZXN0YWNpb246IFtdLFxyXG4gICAgICAgICAgcHVudG9zTWVkaWNpb246IFtdLFxyXG4gICAgICAgICAgY2NtTGlzdDogW10sXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHNldCgoc3RhdGUpID0+ICh7XHJcbiAgICAgICAgICBjb21wYW5pZXM6IHN0YXRlLmNvbXBhbmllcy5tYXAoKGMpID0+IHtcclxuICAgICAgICAgICAgaWYgKGMuaWQgPT09IGNvbXBhbnlJZCkge1xyXG4gICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICAgICAgcHJveWVjdG9zOiBbbnVldm9Qcm95ZWN0bywgLi4uKGMucHJveWVjdG9zIHx8IFtdKV1cclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBjO1xyXG4gICAgICAgICAgfSksXHJcbiAgICAgICAgICBwcm95ZWN0b3NMb2NhbGVzOiBbLi4uKHN0YXRlLnByb3llY3Rvc0xvY2FsZXMgfHwgW10pLCBudWV2b1Byb3llY3RvXSxcclxuICAgICAgICAgIHN5bmNRdWV1ZTogWy4uLnN0YXRlLnN5bmNRdWV1ZSwge1xyXG4gICAgICAgICAgICBpZDogdXVpZElkLFxyXG4gICAgICAgICAgICB0aXBvOiAnUFJPWUVDVE8nLFxyXG4gICAgICAgICAgICBjb21wYW55SWQsXHJcbiAgICAgICAgICAgIHBheWxvYWQ6IG51ZXZvUHJveWVjdG9cclxuICAgICAgICAgIH1dXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBwcm95ZWN0bzogbnVldm9Qcm95ZWN0byB9O1xyXG4gICAgICB9LFxyXG5cclxuICAgICAgLy8gTMOTR0lDQSBERSBDUkVBQ0nDk04gQURBUFRBVElWQSBERU5UUk8gWSBGVUVSQSBERSBQUk9ZRUNUT1xyXG4gICAgICBhZGRFbGVtZW50b1VuaWZpbGFyOiAoYXJnMSwgYXJnMikgPT4ge1xyXG4gICAgICAgIGxldCBwcm95ZWN0b0lkID0gdHlwZW9mIGFyZzEgPT09ICdzdHJpbmcnID8gYXJnMSA6IChhcmcxPy5wcm95ZWN0b0lkIHx8IGFyZzI/LnByb3llY3RvSWQpO1xyXG4gICAgICAgIGNvbnN0IGVsZW1lbnRvRGF0YSA9IHR5cGVvZiBhcmcxID09PSAnc3RyaW5nJyA/IGFyZzIgOiBhcmcxO1xyXG4gICAgICAgIGNvbnN0IGNvbXBhbnlJZCA9IGVsZW1lbnRvRGF0YT8uY29tcGFueUlkIHx8IGVsZW1lbnRvRGF0YT8uZW1wcmVzYUlkIHx8ICh0eXBlb2YgYXJnMSA9PT0gJ3N0cmluZycgPyBudWxsIDogYXJnMT8uY29tcGFueUlkKTtcclxuXHJcbiAgICAgICAgY29uc3QgeyBjb21wYW5pZXMgfSA9IGdldCgpO1xyXG4gICAgICAgIGxldCBwYXJlbnRDb21wYW55SWQgPSBjb21wYW55SWQ7XHJcbiAgICAgICAgbGV0IHRhcmdldFByb3llY3RvID0gbnVsbDtcclxuXHJcbiAgICAgICAgaWYgKHByb3llY3RvSWQpIHtcclxuICAgICAgICAgIGZvciAoY29uc3QgY29tcGFueSBvZiBjb21wYW5pZXMpIHtcclxuICAgICAgICAgICAgY29uc3QgcHJvaiA9IChjb21wYW55LnByb3llY3RvcyB8fCBbXSkuZmluZCgocCkgPT4gcC5pZCA9PT0gcHJveWVjdG9JZCk7XHJcbiAgICAgICAgICAgIGlmIChwcm9qKSB7XHJcbiAgICAgICAgICAgICAgcGFyZW50Q29tcGFueUlkID0gY29tcGFueS5pZDtcclxuICAgICAgICAgICAgICB0YXJnZXRQcm95ZWN0byA9IHByb2o7XHJcbiAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgLy8gSWYgbm8gcHJveWVjdG9JZCBpcyBnaXZlbiwgZGVmYXVsdCB0byB0aGUgY29tcGFueUlkIHByb3ZpZGVkXHJcbiAgICAgICAgICBpZiAoIXBhcmVudENvbXBhbnlJZCAmJiBjb21wYW5pZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBwYXJlbnRDb21wYW55SWQgPSBjb21wYW5pZXNbMF0uaWQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAocHJveWVjdG9JZCAmJiAhdGFyZ2V0UHJveWVjdG8pIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ1Byb3llY3RvIG5vIGVuY29udHJhZG8gZW4gbGEgYmFzZSBkZSBkYXRvcy4nIH07XHJcblxyXG4gICAgICAgIGxldCB1dWlkSWQgPSBlbGVtZW50b0RhdGEuaWQ7XHJcbiAgICAgICAgaWYgKCF1dWlkSWQgfHwgIXV1aWRJZC5pbmNsdWRlcygnLScpKSB7XHJcbiAgICAgICAgICB1dWlkSWQgPSBnZXROZXh0RWxlbWVudElkKGVsZW1lbnRvRGF0YS50aXBvRWxlbWVudG8gfHwgJ1RBQkxFUk8nLCBnZXQoKSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBub21icmVGaW5hbCA9IChlbGVtZW50b0RhdGEubm9tYnJlICYmIGVsZW1lbnRvRGF0YS5ub21icmUudHJpbSgpKVxyXG4gICAgICAgICAgPyBlbGVtZW50b0RhdGEubm9tYnJlLnRyaW0oKVxyXG4gICAgICAgICAgOiB1dWlkSWQ7XHJcblxyXG4gICAgICAgIGNvbnN0IG51ZXZvRWxlbWVudG8gPSB7XHJcbiAgICAgICAgICBpZDogdXVpZElkLFxyXG4gICAgICAgICAgbm9tYnJlOiBub21icmVGaW5hbCxcclxuICAgICAgICAgIHRpcG9FbGVtZW50bzogZWxlbWVudG9EYXRhLnRpcG9FbGVtZW50byB8fCAnVEFCTEVSTycsXHJcbiAgICAgICAgICB1YmljYWNpb246IGVsZW1lbnRvRGF0YS51YmljYWNpb24gfHwgJ1NpbiB1YmljYWNpw7NuJyxcclxuICAgICAgICAgIGFsaW1lbnRhZG9Qb3I6IGVsZW1lbnRvRGF0YS5hbGltZW50YWRvUG9yIHx8ICcnLFxyXG4gICAgICAgICAgZm90bzogZWxlbWVudG9EYXRhLmZvdG8gfHwgbnVsbCxcclxuICAgICAgICAgIGZvdG9CbG9iOiBlbGVtZW50b0RhdGEuZm90b0Jsb2IgfHwgbnVsbCxcclxuICAgICAgICAgIG9ic2VydmFjaW9uZXNHZW5lcmFsZXM6IGVsZW1lbnRvRGF0YS5vYnNlcnZhY2lvbmVzR2VuZXJhbGVzIHx8ICcnLFxyXG4gICAgICAgICAgZGF0b3NUZWNuaWNvczogZWxlbWVudG9EYXRhLmRhdG9zVGVjbmljb3MgfHwge30sXHJcbiAgICAgICAgICBwcm95ZWN0b0lkOiBwcm95ZWN0b0lkIHx8IG51bGwsXHJcbiAgICAgICAgICBlbXByZXNhSWQ6IHBhcmVudENvbXBhbnlJZCxcclxuICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgc2V0KChzdGF0ZSkgPT4gKHtcclxuICAgICAgICAgIGNvbXBhbmllczogc3RhdGUuY29tcGFuaWVzLm1hcCgoYykgPT4ge1xyXG4gICAgICAgICAgICBpZiAoYy5pZCA9PT0gcGFyZW50Q29tcGFueUlkKSB7XHJcbiAgICAgICAgICAgICAgaWYgKHByb3llY3RvSWQpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgIC4uLmMsXHJcbiAgICAgICAgICAgICAgICAgIHByb3llY3RvczogYy5wcm95ZWN0b3MubWFwKChwKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHAuaWQgPT09IHByb3llY3RvSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGVsZW1lbnRvcyA9IHAuZWxlbWVudG9zVW5pZmlsYXJlcyB8fCBwLnRhYmxlcm9zIHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudG9zVW5pZmlsYXJlczogWy4uLmVsZW1lbnRvcywgbnVldm9FbGVtZW50b11cclxuICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBwO1xyXG4gICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZWxlbWVudG9zQ29tcCA9IGMuZWxlbWVudG9zVW5pZmlsYXJlcyB8fCBbXTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgIC4uLmMsXHJcbiAgICAgICAgICAgICAgICAgIGVsZW1lbnRvc1VuaWZpbGFyZXM6IFsuLi5lbGVtZW50b3NDb21wLCBudWV2b0VsZW1lbnRvXVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIGM7XHJcbiAgICAgICAgICB9KSxcclxuICAgICAgICAgIGVsZW1lbnRvc0xvY2FsZXM6IFsuLi4oc3RhdGUuZWxlbWVudG9zTG9jYWxlcyB8fCBbXSksIG51ZXZvRWxlbWVudG9dLFxyXG4gICAgICAgICAgc3luY1F1ZXVlOiBbLi4uc3RhdGUuc3luY1F1ZXVlLCB7XHJcbiAgICAgICAgICAgIGlkOiB1dWlkSWQsXHJcbiAgICAgICAgICAgIHRpcG86ICdFTEVNRU5UT19VTklGSUxBUicsXHJcbiAgICAgICAgICAgIGNvbXBhbnlJZDogcGFyZW50Q29tcGFueUlkLFxyXG4gICAgICAgICAgICBwYXlsb2FkOiBudWV2b0VsZW1lbnRvXHJcbiAgICAgICAgICB9XVxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZWxlbWVudG86IG51ZXZvRWxlbWVudG8gfTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIHVwZGF0ZUVsZW1lbnRvVW5pZmlsYXI6IChwcm95ZWN0b0lkLCBlbGVtZW50b0lkLCB1cGRhdGVkRGF0YSkgPT4ge1xyXG4gICAgICAgIHNldCgoc3RhdGUpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHVwZGF0ZWRDb21wYW5pZXMgPSBzdGF0ZS5jb21wYW5pZXMubWFwKChjKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghcHJveWVjdG9JZCkge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGxpc3QgPSBjLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgW107XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLmMsXHJcbiAgICAgICAgICAgICAgICBlbGVtZW50b3NVbmlmaWxhcmVzOiBsaXN0Lm1hcCgoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAoZS5pZCA9PT0gZWxlbWVudG9JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7IC4uLmUsIC4uLnVwZGF0ZWREYXRhIH07XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGU7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICAgIHByb3llY3RvczogKGMucHJveWVjdG9zIHx8IFtdKS5tYXAoKHApID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChwLmlkID09PSBwcm95ZWN0b0lkKSB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGxpc3QgPSBwLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgcC50YWJsZXJvcyB8fCBbXTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5wLFxyXG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnRvc1VuaWZpbGFyZXM6IGxpc3QubWFwKChlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZS5pZCA9PT0gZWxlbWVudG9JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5lLCAuLi51cGRhdGVkRGF0YSB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGU7XHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJldHVybiBwO1xyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICBjb25zdCB1cGRhdGVkRWxlbWVudG9zTG9jYWxlcyA9IChzdGF0ZS5lbGVtZW50b3NMb2NhbGVzIHx8IFtdKS5tYXAoKGUpID0+IHtcclxuICAgICAgICAgICAgaWYgKGUuaWQgPT09IGVsZW1lbnRvSWQpIHtcclxuICAgICAgICAgICAgICByZXR1cm4geyAuLi5lLCAuLi51cGRhdGVkRGF0YSB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBlO1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgbGV0IGluUXVldWUgPSBmYWxzZTtcclxuICAgICAgICAgIGNvbnN0IHVwZGF0ZWRTeW5jUXVldWUgPSBzdGF0ZS5zeW5jUXVldWUubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpdGVtLmlkID09PSBlbGVtZW50b0lkICYmIChpdGVtLnRpcG8gPT09ICdFTEVNRU5UT19VTklGSUxBUicgfHwgaXRlbS50aXBvID09PSAnVEFCTEVSTycpKSB7XHJcbiAgICAgICAgICAgICAgaW5RdWV1ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHsgLi4uaXRlbSwgcGF5bG9hZDogeyAuLi5pdGVtLnBheWxvYWQsIC4uLnVwZGF0ZWREYXRhIH0gfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gaXRlbTtcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIGlmICghaW5RdWV1ZSkge1xyXG4gICAgICAgICAgICBsZXQgdXBkYXRlZEVsZW1lbnQgPSB1cGRhdGVkRWxlbWVudG9zTG9jYWxlcy5maW5kKGUgPT4gZS5pZCA9PT0gZWxlbWVudG9JZCk7XHJcbiAgICAgICAgICAgIGlmICghdXBkYXRlZEVsZW1lbnQpIHtcclxuICAgICAgICAgICAgICBmb3IgKGNvbnN0IGMgb2YgdXBkYXRlZENvbXBhbmllcykge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgbGlzdCA9IHByb3llY3RvSWQgXHJcbiAgICAgICAgICAgICAgICAgID8gKGMucHJveWVjdG9zPy5maW5kKHAgPT4gcC5pZCA9PT0gcHJveWVjdG9JZCk/LmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgW10pIFxyXG4gICAgICAgICAgICAgICAgICA6IChjLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgW10pO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZm91bmQgPSBsaXN0LmZpbmQoZSA9PiBlLmlkID09PSBlbGVtZW50b0lkKTtcclxuICAgICAgICAgICAgICAgIGlmIChmb3VuZCkge1xyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVkRWxlbWVudCA9IGZvdW5kO1xyXG4gICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHVwZGF0ZWRFbGVtZW50KSB7XHJcbiAgICAgICAgICAgICAgdXBkYXRlZFN5bmNRdWV1ZS5wdXNoKHtcclxuICAgICAgICAgICAgICAgIGlkOiBlbGVtZW50b0lkLFxyXG4gICAgICAgICAgICAgICAgdGlwbzogJ0VMRU1FTlRPX1VOSUZJTEFSJyxcclxuICAgICAgICAgICAgICAgIGNvbXBhbnlJZDogdXBkYXRlZEVsZW1lbnQuZW1wcmVzYUlkIHx8IHVwZGF0ZWRFbGVtZW50LmNvbXBhbnlJZCB8fCAoc3RhdGUuY29tcGFuaWVzWzBdPy5pZCB8fCBudWxsKSxcclxuICAgICAgICAgICAgICAgIHBheWxvYWQ6IHVwZGF0ZWRFbGVtZW50XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBjb21wYW5pZXM6IHVwZGF0ZWRDb21wYW5pZXMsXHJcbiAgICAgICAgICAgIGVsZW1lbnRvc0xvY2FsZXM6IHVwZGF0ZWRFbGVtZW50b3NMb2NhbGVzLFxyXG4gICAgICAgICAgICBzeW5jUXVldWU6IHVwZGF0ZWRTeW5jUXVldWVcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBkZWxldGVFbGVtZW50b1VuaWZpbGFyOiBhc3luYyAocHJveWVjdG9JZCwgZWxlbWVudG9JZCkgPT4ge1xyXG4gICAgICAgIHNldCgoc3RhdGUpID0+ICh7XHJcbiAgICAgICAgICBjb21wYW5pZXM6IHN0YXRlLmNvbXBhbmllcy5tYXAoKGMpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFwcm95ZWN0b0lkKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgbGlzdCA9IGMuZWxlbWVudG9zVW5pZmlsYXJlcyB8fCBbXTtcclxuICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uYyxcclxuICAgICAgICAgICAgICAgIGVsZW1lbnRvc1VuaWZpbGFyZXM6IGxpc3QuZmlsdGVyKChlKSA9PiBlLmlkICE9PSBlbGVtZW50b0lkKVxyXG4gICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICAgIHByb3llY3RvczogKGMucHJveWVjdG9zIHx8IFtdKS5tYXAoKHApID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChwLmlkID09PSBwcm95ZWN0b0lkKSB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGxpc3QgPSBwLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgcC50YWJsZXJvcyB8fCBbXTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5wLFxyXG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnRvc1VuaWZpbGFyZXM6IGxpc3QuZmlsdGVyKChlKSA9PiBlLmlkICE9PSBlbGVtZW50b0lkKVxyXG4gICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHA7XHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgZWxlbWVudG9zTG9jYWxlczogKHN0YXRlLmVsZW1lbnRvc0xvY2FsZXMgfHwgW10pLmZpbHRlcigoZSkgPT4gZS5pZCAhPT0gZWxlbWVudG9JZCksXHJcbiAgICAgICAgICBzeW5jUXVldWU6IHN0YXRlLnN5bmNRdWV1ZS5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uaWQgIT09IGVsZW1lbnRvSWQpXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICBpZiAobmF2aWdhdG9yLm9uTGluZSkge1xyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgeyB0b2tlbiB9ID0gZ2V0KCk7XHJcbiAgICAgICAgICAgIGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2VsZW1lbnRvcy11bmlmaWxhcmVzLyR7ZWxlbWVudG9JZH1gLCB7XHJcbiAgICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcclxuICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAuLi4odG9rZW4gPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGVsaW1pbmFyIGVsZW1lbnRvIHVuaWZpbGFyIGRlbCBzZXJ2aWRvcjonLCBlKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBhZGRUYWJsZXJvOiAocHJveWVjdG9JZCwgdGFibGVyb0RhdGEpID0+IHtcclxuICAgICAgICByZXR1cm4gZ2V0KCkuYWRkRWxlbWVudG9VbmlmaWxhcihwcm95ZWN0b0lkLCB7XHJcbiAgICAgICAgICAuLi50YWJsZXJvRGF0YSxcclxuICAgICAgICAgIHRpcG9FbGVtZW50bzogJ1RBQkxFUk8nLFxyXG4gICAgICAgICAgZGF0b3NUZWNuaWNvczoge1xyXG4gICAgICAgICAgICBtYXhQb2xlczogdGFibGVyb0RhdGEubWF4UG9sZXMgfHwgMjQsXHJcbiAgICAgICAgICAgIGJhcnJhc1ByaW5jaXBhbGVzOiB0YWJsZXJvRGF0YS5iYXJyYXNQcmluY2lwYWxlcyB8fCB7IGlhOiAnMCcsIGliOiAnMCcsIGljOiAnMCcgfSxcclxuICAgICAgICAgICAgYnJlYWtlclByaW5jaXBhbDogdGFibGVyb0RhdGEuYnJlYWtlclByaW5jaXBhbCB8fCB7IG1hcmNhOiAnJywgdGlwbzogJycsIGFtcDogJycgfSxcclxuICAgICAgICAgICAgdm9sdGFqZTogdGFibGVyb0RhdGEudm9sdGFqZSB8fCB7IHZhOiAnMjA4JywgdmI6ICcyMDUnLCB2YzogJzIwNScgfSxcclxuICAgICAgICAgICAgYWNvbWV0aWRhOiB0YWJsZXJvRGF0YS5hY29tZXRpZGEgfHwgJycsXHJcbiAgICAgICAgICAgIGNpcmN1aXRzOiB0YWJsZXJvRGF0YS5jaXJjdWl0cyB8fCBbXSxcclxuICAgICAgICAgICAgbmV1dHJvTGxlZ2FkYTogdGFibGVyb0RhdGEubmV1dHJvTGxlZ2FkYSB8fCB7IGNhbGlicmU6ICcnLCBvYnNlcnZhY2lvbmVzOiAnJyB9LFxyXG4gICAgICAgICAgICBwdWVzdGFUaWVycmE6IHRhYmxlcm9EYXRhLnB1ZXN0YVRpZXJyYSB8fCB7IGNhbGlicmU6ICcnLCBvYnNlcnZhY2lvbmVzOiAnJyB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICB1cGRhdGVUYWJsZXJvOiAocHJveWVjdG9JZCwgdGFibGVyb0lkLCB1cGRhdGVkRGF0YSkgPT4ge1xyXG4gICAgICAgIGdldCgpLnVwZGF0ZUVsZW1lbnRvVW5pZmlsYXIocHJveWVjdG9JZCwgdGFibGVyb0lkLCB1cGRhdGVkRGF0YSk7XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBkZWxldGVUYWJsZXJvOiAocHJveWVjdG9JZCwgdGFibGVyb0lkKSA9PiB7XHJcbiAgICAgICAgZ2V0KCkuZGVsZXRlRWxlbWVudG9VbmlmaWxhcihwcm95ZWN0b0lkLCB0YWJsZXJvSWQpO1xyXG4gICAgICB9LFxyXG5cclxuICAgICAgYWRkSW5zcGVjY2lvblN1YmVzdGFjaW9uOiAocHJveWVjdG9JZCwgcGF5bG9hZCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHsgY29tcGFuaWVzIH0gPSBnZXQoKTtcclxuXHJcbiAgICAgICAgbGV0IHBhcmVudENvbXBhbnlJZCA9IG51bGw7XHJcbiAgICAgICAgbGV0IHRhcmdldFByb3llY3RvID0gbnVsbDtcclxuXHJcbiAgICAgICAgZm9yIChjb25zdCBjb21wYW55IG9mIGNvbXBhbmllcykge1xyXG4gICAgICAgICAgY29uc3QgcHJvaiA9IChjb21wYW55LnByb3llY3RvcyB8fCBbXSkuZmluZCgocCkgPT4gcC5pZCA9PT0gcHJveWVjdG9JZCk7XHJcbiAgICAgICAgICBpZiAocHJvaikge1xyXG4gICAgICAgICAgICBwYXJlbnRDb21wYW55SWQgPSBjb21wYW55LmlkO1xyXG4gICAgICAgICAgICB0YXJnZXRQcm95ZWN0byA9IHByb2o7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCF0YXJnZXRQcm95ZWN0bykgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnUHJveWVjdG8gbm8gZW5jb250cmFkby4nIH07XHJcblxyXG4gICAgICAgIGxldCB1dWlkSWQgPSBwYXlsb2FkLmlkO1xyXG4gICAgICAgIGlmICghdXVpZElkIHx8ICF1dWlkSWQuaW5jbHVkZXMoJy0nKSkge1xyXG4gICAgICAgICAgdXVpZElkID0gZ2V0TmV4dEVsZW1lbnRJZCgnU1VCRVNUQUNJT04nLCBnZXQoKSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBub21icmVGaW5hbCA9IChwYXlsb2FkLm5vbWJyZSAmJiBwYXlsb2FkLm5vbWJyZS50cmltKCkpIFxyXG4gICAgICAgICAgPyBwYXlsb2FkLm5vbWJyZS50cmltKCkgXHJcbiAgICAgICAgICA6IHV1aWRJZDtcclxuXHJcbiAgICAgICAgY29uc3QgbnVldmFTdWJlc3RhY2lvbiA9IHtcclxuICAgICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgICBpZDogdXVpZElkLFxyXG4gICAgICAgICAgbm9tYnJlOiBub21icmVGaW5hbCxcclxuICAgICAgICAgIHByb3llY3RvSWQsXHJcbiAgICAgICAgICBlbXByZXNhSWQ6IHBhcmVudENvbXBhbnlJZCxcclxuICAgICAgICAgIHRpcG9QbGFudGlsbGE6ICdJTlNQRUNDSU9OX1NVQkVTVEFDSU9OJyxcclxuICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgc2V0KChzdGF0ZSkgPT4gKHtcclxuICAgICAgICAgIGNvbXBhbmllczogc3RhdGUuY29tcGFuaWVzLm1hcCgoYykgPT4ge1xyXG4gICAgICAgICAgICBpZiAoYy5pZCA9PT0gcGFyZW50Q29tcGFueUlkKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLmMsXHJcbiAgICAgICAgICAgICAgICBwcm95ZWN0b3M6IGMucHJveWVjdG9zLm1hcCgocCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAocC5pZCA9PT0gcHJveWVjdG9JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHN1YmVzdGFjaW9uZXMgPSBwLmluc3BlY2Npb25lc1N1YmVzdGFjaW9uIHx8IHAuc3ViZXN0YWNpb25lcyB8fCBbXTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgICAgICAgICAgIGluc3BlY2Npb25lc1N1YmVzdGFjaW9uOiBbLi4uc3ViZXN0YWNpb25lcywgbnVldmFTdWJlc3RhY2lvbl1cclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiBwO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBjO1xyXG4gICAgICAgICAgfSksXHJcbiAgICAgICAgICBzdWJlc3RhY2lvbmVzTG9jYWxlczogWy4uLihzdGF0ZS5zdWJlc3RhY2lvbmVzTG9jYWxlcyB8fCBbXSksIG51ZXZhU3ViZXN0YWNpb25dLFxyXG4gICAgICAgICAgc3luY1F1ZXVlOiBbLi4uc3RhdGUuc3luY1F1ZXVlLCB7XHJcbiAgICAgICAgICAgIGlkOiB1dWlkSWQsXHJcbiAgICAgICAgICAgIHRpcG86ICdTVUJFU1RBQ0lPTicsXHJcbiAgICAgICAgICAgIGNvbXBhbnlJZDogcGFyZW50Q29tcGFueUlkLFxyXG4gICAgICAgICAgICBwYXlsb2FkOiBudWV2YVN1YmVzdGFjaW9uXHJcbiAgICAgICAgICB9XVxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgc3ViZXN0YWNpb246IG51ZXZhU3ViZXN0YWNpb24gfTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIHVwZGF0ZVN1YmVzdGFjaW9uOiAocHJveWVjdG9JZCwgc3ViZXN0YWNpb25JZCwgdXBkYXRlZERhdGEpID0+IHtcclxuICAgICAgICBzZXQoKHN0YXRlKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCB1cGRhdGVkQ29tcGFuaWVzID0gc3RhdGUuY29tcGFuaWVzLm1hcCgoYykgPT4gKHtcclxuICAgICAgICAgICAgLi4uYyxcclxuICAgICAgICAgICAgcHJveWVjdG9zOiAoYy5wcm95ZWN0b3MgfHwgW10pLm1hcCgocCkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmIChwLmlkID09PSBwcm95ZWN0b0lkKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBzdWJlc3RhY2lvbmVzID0gcC5pbnNwZWNjaW9uZXNTdWJlc3RhY2lvbiB8fCBwLnN1YmVzdGFjaW9uZXMgfHwgW107XHJcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAuLi5wLFxyXG4gICAgICAgICAgICAgICAgICBpbnNwZWNjaW9uZXNTdWJlc3RhY2lvbjogc3ViZXN0YWNpb25lcy5tYXAoKHMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocy5pZCA9PT0gc3ViZXN0YWNpb25JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgLi4ucywgLi4udXBkYXRlZERhdGEgfTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHM7XHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICByZXR1cm4gcDtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgICBjb25zdCB1cGRhdGVkU3ViZXN0YWNpb25lc0xvY2FsZXMgPSAoc3RhdGUuc3ViZXN0YWNpb25lc0xvY2FsZXMgfHwgW10pLm1hcCgocykgPT4ge1xyXG4gICAgICAgICAgICBpZiAocy5pZCA9PT0gc3ViZXN0YWNpb25JZCkge1xyXG4gICAgICAgICAgICAgIHJldHVybiB7IC4uLnMsIC4uLnVwZGF0ZWREYXRhIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHM7XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICBjb25zdCB1cGRhdGVkU3luY1F1ZXVlID0gc3RhdGUuc3luY1F1ZXVlLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoaXRlbS5pZCA9PT0gc3ViZXN0YWNpb25JZCAmJiBpdGVtLnRpcG8gPT09ICdTVUJFU1RBQ0lPTicpIHtcclxuICAgICAgICAgICAgICByZXR1cm4geyAuLi5pdGVtLCBwYXlsb2FkOiB7IC4uLml0ZW0ucGF5bG9hZCwgLi4udXBkYXRlZERhdGEgfSB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBpdGVtO1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgY29tcGFuaWVzOiB1cGRhdGVkQ29tcGFuaWVzLFxyXG4gICAgICAgICAgICBzdWJlc3RhY2lvbmVzTG9jYWxlczogdXBkYXRlZFN1YmVzdGFjaW9uZXNMb2NhbGVzLFxyXG4gICAgICAgICAgICBzeW5jUXVldWU6IHVwZGF0ZWRTeW5jUXVldWVcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBkZWxldGVTdWJlc3RhY2lvbjogYXN5bmMgKHByb3llY3RvSWQsIHN1YmVzdGFjaW9uSWQpID0+IHtcclxuICAgICAgICBzZXQoKHN0YXRlKSA9PiAoe1xyXG4gICAgICAgICAgY29tcGFuaWVzOiBzdGF0ZS5jb21wYW5pZXMubWFwKChjKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICBwcm95ZWN0b3M6IChjLnByb3llY3RvcyB8fCBbXSkubWFwKChwKSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKHAuaWQgPT09IHByb3llY3RvSWQpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHN1YmVzdGFjaW9uZXMgPSBwLmluc3BlY2Npb25lc1N1YmVzdGFjaW9uIHx8IHAuc3ViZXN0YWNpb25lcyB8fCBbXTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgICAgICAgIGluc3BlY2Npb25lc1N1YmVzdGFjaW9uOiBzdWJlc3RhY2lvbmVzLmZpbHRlcigocykgPT4gcy5pZCAhPT0gc3ViZXN0YWNpb25JZClcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHJldHVybiBwO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfSkpLFxyXG4gICAgICAgICAgc3ViZXN0YWNpb25lc0xvY2FsZXM6IChzdGF0ZS5zdWJlc3RhY2lvbmVzTG9jYWxlcyB8fCBbXSkuZmlsdGVyKChzKSA9PiBzLmlkICE9PSBzdWJlc3RhY2lvbklkKSxcclxuICAgICAgICAgIHN5bmNRdWV1ZTogc3RhdGUuc3luY1F1ZXVlLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5pZCAhPT0gc3ViZXN0YWNpb25JZClcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIGlmIChuYXZpZ2F0b3Iub25MaW5lKSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCB7IHRva2VuIH0gPSBnZXQoKTtcclxuICAgICAgICAgICAgYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvc3ViZXN0YWNpb25lcy8ke3N1YmVzdGFjaW9uSWR9YCwge1xyXG4gICAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURScsXHJcbiAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgLi4uKHRva2VuID8geyAnQXV0aG9yaXphdGlvbic6IGBCZWFyZXIgJHt0b2tlbn1gIH0gOiB7fSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBlbGltaW5hciBpbnNwZWNjacOzbiBkZSBzdWJlc3RhY2nDs24gZGVsIHNlcnZpZG9yOicsIGUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuXHJcbiAgICAgIGFkZFB1bnRvTWVkaWNpb246IChwcm95ZWN0b0lkLCBwYXlsb2FkKSA9PiB7XHJcbiAgICAgICAgY29uc3QgeyBjb21wYW5pZXMgfSA9IGdldCgpO1xyXG5cclxuICAgICAgICBsZXQgcGFyZW50Q29tcGFueUlkID0gbnVsbDtcclxuICAgICAgICBsZXQgdGFyZ2V0UHJveWVjdG8gPSBudWxsO1xyXG5cclxuICAgICAgICBmb3IgKGNvbnN0IGNvbXBhbnkgb2YgY29tcGFuaWVzKSB7XHJcbiAgICAgICAgICBjb25zdCBwcm9qID0gKGNvbXBhbnkucHJveWVjdG9zIHx8IFtdKS5maW5kKChwKSA9PiBwLmlkID09PSBwcm95ZWN0b0lkKTtcclxuICAgICAgICAgIGlmIChwcm9qKSB7XHJcbiAgICAgICAgICAgIHBhcmVudENvbXBhbnlJZCA9IGNvbXBhbnkuaWQ7XHJcbiAgICAgICAgICAgIHRhcmdldFByb3llY3RvID0gcHJvajtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgdXVpZElkID0gcGF5bG9hZC5pZDtcclxuICAgICAgICBpZiAoIXV1aWRJZCB8fCAhdXVpZElkLmluY2x1ZGVzKCctJykpIHtcclxuICAgICAgICAgIHV1aWRJZCA9IGdldE5leHRFbGVtZW50SWQoJ1BVTlRPX01FRElDSU9OJywgZ2V0KCkpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3Qgbm9tYnJlRmluYWwgPSAocGF5bG9hZC5ub21icmUgJiYgcGF5bG9hZC5ub21icmUudHJpbSgpKSBcclxuICAgICAgICAgID8gcGF5bG9hZC5ub21icmUudHJpbSgpIFxyXG4gICAgICAgICAgOiB1dWlkSWQ7XHJcblxyXG4gICAgICAgIGNvbnN0IG51ZXZvUHVudG8gPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgaWQ6IHV1aWRJZCxcclxuICAgICAgICAgIG5vbWJyZTogbm9tYnJlRmluYWwsXHJcbiAgICAgICAgICBwcm95ZWN0b0lkLFxyXG4gICAgICAgICAgZW1wcmVzYUlkOiBwYXJlbnRDb21wYW55SWQsXHJcbiAgICAgICAgICB0aXBvUGxhbnRpbGxhOiAnUFVOVE9fTUVESUNJT04nLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBzZXQoKHN0YXRlKSA9PiAoe1xyXG4gICAgICAgICAgY29tcGFuaWVzOiBzdGF0ZS5jb21wYW5pZXMubWFwKChjKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChjLmlkID09PSBwYXJlbnRDb21wYW55SWQpIHtcclxuICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uYyxcclxuICAgICAgICAgICAgICAgIHByb3llY3RvczogYy5wcm95ZWN0b3MubWFwKChwKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGlmIChwLmlkID09PSBwcm95ZWN0b0lkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHVudG9zID0gcC5wdW50b3NNZWRpY2lvbiB8fCBbXTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgICAgICAgICAgIHB1bnRvc01lZGljaW9uOiBbLi4ucHVudG9zLCBudWV2b1B1bnRvXVxyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHA7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIGM7XHJcbiAgICAgICAgICB9KSxcclxuICAgICAgICAgIHB1bnRvc01lZGljaW9uTG9jYWxlczogWy4uLihzdGF0ZS5wdW50b3NNZWRpY2lvbkxvY2FsZXMgfHwgW10pLCBudWV2b1B1bnRvXSxcclxuICAgICAgICAgIHN5bmNRdWV1ZTogWy4uLnN0YXRlLnN5bmNRdWV1ZSwge1xyXG4gICAgICAgICAgICBpZDogdXVpZElkLFxyXG4gICAgICAgICAgICB0aXBvOiAnUFVOVE9fTUVESUNJT04nLFxyXG4gICAgICAgICAgICBjb21wYW55SWQ6IHBhcmVudENvbXBhbnlJZCxcclxuICAgICAgICAgICAgcGF5bG9hZDogbnVldm9QdW50b1xyXG4gICAgICAgICAgfV1cclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHB1bnRvTWVkaWNpb246IG51ZXZvUHVudG8gfTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIHVwZGF0ZVB1bnRvTWVkaWNpb246IChwcm95ZWN0b0lkLCBwdW50b0lkLCB1cGRhdGVkRGF0YSkgPT4ge1xyXG4gICAgICAgIHNldCgoc3RhdGUpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHVwZGF0ZWRDb21wYW5pZXMgPSBzdGF0ZS5jb21wYW5pZXMubWFwKChjKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICBlbGVtZW50b3NVbmlmaWxhcmVzOiAoYy5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IFtdKS5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICBpZiAoaXRlbS5pZCA9PT0gcHVudG9JZCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgLi4uaXRlbSwgLi4udXBkYXRlZERhdGEgfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgcmV0dXJuIGl0ZW07XHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICBwcm95ZWN0b3M6IChjLnByb3llY3RvcyB8fCBbXSkubWFwKChwKSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgbWF0Y2hlc1Byb2ogPSAhcHJveWVjdG9JZCB8fCBwLmlkID09PSBwcm95ZWN0b0lkO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHB1bnRvcyA9IHAucHVudG9zTWVkaWNpb24gfHwgW107XHJcbiAgICAgICAgICAgICAgY29uc3QgZWxlbWVudG9zID0gcC5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IFtdO1xyXG4gICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5wLFxyXG4gICAgICAgICAgICAgICAgcHVudG9zTWVkaWNpb246IHB1bnRvcy5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKGl0ZW0uaWQgPT09IHB1bnRvSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5pdGVtLCAuLi51cGRhdGVkRGF0YSB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiBpdGVtO1xyXG4gICAgICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgICAgICBlbGVtZW50b3NVbmlmaWxhcmVzOiBtYXRjaGVzUHJvaiA/IGVsZW1lbnRvcy5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKGl0ZW0uaWQgPT09IHB1bnRvSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5pdGVtLCAuLi51cGRhdGVkRGF0YSB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiBpdGVtO1xyXG4gICAgICAgICAgICAgICAgfSkgOiBlbGVtZW50b3NcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHVwZGF0ZWRQdW50b3NMb2NhbGVzID0gKHN0YXRlLnB1bnRvc01lZGljaW9uTG9jYWxlcyB8fCBbXSkubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpdGVtLmlkID09PSBwdW50b0lkKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHsgLi4uaXRlbSwgLi4udXBkYXRlZERhdGEgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gaXRlbTtcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHVwZGF0ZWRTeW5jUXVldWUgPSBzdGF0ZS5zeW5jUXVldWUubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpdGVtLmlkID09PSBwdW50b0lkICYmIChpdGVtLnRpcG8gPT09ICdQVU5UT19NRURJQ0lPTicgfHwgaXRlbS50aXBvID09PSAnRUxFTUVOVE9fVU5JRklMQVInKSkge1xyXG4gICAgICAgICAgICAgIHJldHVybiB7IC4uLml0ZW0sIHBheWxvYWQ6IHsgLi4uaXRlbS5wYXlsb2FkLCAuLi51cGRhdGVkRGF0YSB9IH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIGl0ZW07XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBjb21wYW5pZXM6IHVwZGF0ZWRDb21wYW5pZXMsXHJcbiAgICAgICAgICAgIHB1bnRvc01lZGljaW9uTG9jYWxlczogdXBkYXRlZFB1bnRvc0xvY2FsZXMsXHJcbiAgICAgICAgICAgIHN5bmNRdWV1ZTogdXBkYXRlZFN5bmNRdWV1ZVxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIGRlbGV0ZVB1bnRvTWVkaWNpb246IGFzeW5jIChwcm95ZWN0b0lkLCBwdW50b0lkKSA9PiB7XHJcbiAgICAgICAgc2V0KChzdGF0ZSkgPT4gKHtcclxuICAgICAgICAgIGNvbXBhbmllczogc3RhdGUuY29tcGFuaWVzLm1hcCgoYykgPT4gKHtcclxuICAgICAgICAgICAgLi4uYyxcclxuICAgICAgICAgICAgcHJveWVjdG9zOiAoYy5wcm95ZWN0b3MgfHwgW10pLm1hcCgocCkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmIChwLmlkID09PSBwcm95ZWN0b0lkKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBwdW50b3MgPSBwLnB1bnRvc01lZGljaW9uIHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgICAgICAgcHVudG9zTWVkaWNpb246IHB1bnRvcy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uaWQgIT09IHB1bnRvSWQpXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICByZXR1cm4gcDtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH0pKSxcclxuICAgICAgICAgIHB1bnRvc01lZGljaW9uTG9jYWxlczogKHN0YXRlLnB1bnRvc01lZGljaW9uTG9jYWxlcyB8fCBbXSkuZmlsdGVyKChpdGVtKSA9PiBpdGVtLmlkICE9PSBwdW50b0lkKSxcclxuICAgICAgICAgIHN5bmNRdWV1ZTogc3RhdGUuc3luY1F1ZXVlLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5pZCAhPT0gcHVudG9JZClcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIGlmIChuYXZpZ2F0b3Iub25MaW5lKSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCB7IHRva2VuIH0gPSBnZXQoKTtcclxuICAgICAgICAgICAgYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvcHVudG9zLW1lZGljaW9uLyR7cHVudG9JZH1gLCB7XHJcbiAgICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcclxuICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAuLi4odG9rZW4gPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGVsaW1pbmFyIHB1bnRvIGRlIG1lZGljacOzbiBkZWwgc2Vydmlkb3I6JywgZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG5cclxuICAgICAgYWRkQ2NtOiAocHJveWVjdG9JZCwgcGF5bG9hZCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHsgY29tcGFuaWVzIH0gPSBnZXQoKTtcclxuXHJcbiAgICAgICAgbGV0IHBhcmVudENvbXBhbnlJZCA9IG51bGw7XHJcbiAgICAgICAgbGV0IHRhcmdldFByb3llY3RvID0gbnVsbDtcclxuXHJcbiAgICAgICAgZm9yIChjb25zdCBjb21wYW55IG9mIGNvbXBhbmllcykge1xyXG4gICAgICAgICAgY29uc3QgcHJvaiA9IChjb21wYW55LnByb3llY3RvcyB8fCBbXSkuZmluZCgocCkgPT4gcC5pZCA9PT0gcHJveWVjdG9JZCk7XHJcbiAgICAgICAgICBpZiAocHJvaikge1xyXG4gICAgICAgICAgICBwYXJlbnRDb21wYW55SWQgPSBjb21wYW55LmlkO1xyXG4gICAgICAgICAgICB0YXJnZXRQcm95ZWN0byA9IHByb2o7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHV1aWRJZCA9IHBheWxvYWQuaWQ7XHJcbiAgICAgICAgaWYgKCF1dWlkSWQgfHwgIXV1aWRJZC5pbmNsdWRlcygnLScpKSB7XHJcbiAgICAgICAgICB1dWlkSWQgPSBnZXROZXh0RWxlbWVudElkKCdDQ00nLCBnZXQoKSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBub21icmVGaW5hbCA9IChwYXlsb2FkLm5vbWJyZSAmJiBwYXlsb2FkLm5vbWJyZS50cmltKCkpIFxyXG4gICAgICAgICAgPyBwYXlsb2FkLm5vbWJyZS50cmltKCkgXHJcbiAgICAgICAgICA6IHV1aWRJZDtcclxuXHJcbiAgICAgICAgY29uc3QgbnVldm9DY20gPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgaWQ6IHV1aWRJZCxcclxuICAgICAgICAgIG5vbWJyZTogbm9tYnJlRmluYWwsXHJcbiAgICAgICAgICBwcm95ZWN0b0lkLFxyXG4gICAgICAgICAgZW1wcmVzYUlkOiBwYXJlbnRDb21wYW55SWQsXHJcbiAgICAgICAgICB0aXBvUGxhbnRpbGxhOiAnQ0NNJyxcclxuICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgc2V0KChzdGF0ZSkgPT4gKHtcclxuICAgICAgICAgIGNvbXBhbmllczogc3RhdGUuY29tcGFuaWVzLm1hcCgoYykgPT4ge1xyXG4gICAgICAgICAgICBpZiAoYy5pZCA9PT0gcGFyZW50Q29tcGFueUlkKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLmMsXHJcbiAgICAgICAgICAgICAgICBwcm95ZWN0b3M6IGMucHJveWVjdG9zLm1hcCgocCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAocC5pZCA9PT0gcHJveWVjdG9JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNjbUl0ZW1zID0gcC5jY21MaXN0IHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wLFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2NtTGlzdDogWy4uLmNjbUl0ZW1zLCBudWV2b0NjbV1cclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiBwO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBjO1xyXG4gICAgICAgICAgfSksXHJcbiAgICAgICAgICBjY21Mb2NhbGVzOiBbLi4uKHN0YXRlLmNjbUxvY2FsZXMgfHwgW10pLCBudWV2b0NjbV0sXHJcbiAgICAgICAgICBzeW5jUXVldWU6IFsuLi5zdGF0ZS5zeW5jUXVldWUsIHtcclxuICAgICAgICAgICAgaWQ6IHV1aWRJZCxcclxuICAgICAgICAgICAgdGlwbzogJ0NDTScsXHJcbiAgICAgICAgICAgIGNvbXBhbnlJZDogcGFyZW50Q29tcGFueUlkLFxyXG4gICAgICAgICAgICBwYXlsb2FkOiBudWV2b0NjbVxyXG4gICAgICAgICAgfV1cclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNjbTogbnVldm9DY20gfTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIHVwZGF0ZUNjbTogKHByb3llY3RvSWQsIGNjbUlkLCB1cGRhdGVkRGF0YSkgPT4ge1xyXG4gICAgICAgIHNldCgoc3RhdGUpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHVwZGF0ZWRDb21wYW5pZXMgPSBzdGF0ZS5jb21wYW5pZXMubWFwKChjKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICBwcm95ZWN0b3M6IChjLnByb3llY3RvcyB8fCBbXSkubWFwKChwKSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKHAuaWQgPT09IHByb3llY3RvSWQpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGNjbUl0ZW1zID0gcC5jY21MaXN0IHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgICAgICAgY2NtTGlzdDogY2NtSXRlbXMubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGl0ZW0uaWQgPT09IGNjbUlkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyAuLi5pdGVtLCAuLi51cGRhdGVkRGF0YSB9O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaXRlbTtcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHJldHVybiBwO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHVwZGF0ZWRDY21Mb2NhbGVzID0gKHN0YXRlLmNjbUxvY2FsZXMgfHwgW10pLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoaXRlbS5pZCA9PT0gY2NtSWQpIHtcclxuICAgICAgICAgICAgICByZXR1cm4geyAuLi5pdGVtLCAuLi51cGRhdGVkRGF0YSB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBpdGVtO1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgY29uc3QgdXBkYXRlZFN5bmNRdWV1ZSA9IHN0YXRlLnN5bmNRdWV1ZS5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgaWYgKGl0ZW0uaWQgPT09IGNjbUlkICYmIGl0ZW0udGlwbyA9PT0gJ0NDTScpIHtcclxuICAgICAgICAgICAgICByZXR1cm4geyAuLi5pdGVtLCBwYXlsb2FkOiB7IC4uLml0ZW0ucGF5bG9hZCwgLi4udXBkYXRlZERhdGEgfSB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBpdGVtO1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgY29tcGFuaWVzOiB1cGRhdGVkQ29tcGFuaWVzLFxyXG4gICAgICAgICAgICBjY21Mb2NhbGVzOiB1cGRhdGVkQ2NtTG9jYWxlcyxcclxuICAgICAgICAgICAgc3luY1F1ZXVlOiB1cGRhdGVkU3luY1F1ZXVlXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG5cclxuICAgICAgZGVsZXRlQ2NtOiBhc3luYyAocHJveWVjdG9JZCwgY2NtSWQpID0+IHtcclxuICAgICAgICBzZXQoKHN0YXRlKSA9PiAoe1xyXG4gICAgICAgICAgY29tcGFuaWVzOiBzdGF0ZS5jb21wYW5pZXMubWFwKChjKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICBwcm95ZWN0b3M6IChjLnByb3llY3RvcyB8fCBbXSkubWFwKChwKSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKHAuaWQgPT09IHByb3llY3RvSWQpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGNjbUl0ZW1zID0gcC5jY21MaXN0IHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgICAgICAgY2NtTGlzdDogY2NtSXRlbXMuZmlsdGVyKChpdGVtKSA9PiBpdGVtLmlkICE9PSBjY21JZClcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHJldHVybiBwO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfSkpLFxyXG4gICAgICAgICAgY2NtTG9jYWxlczogKHN0YXRlLmNjbUxvY2FsZXMgfHwgW10pLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5pZCAhPT0gY2NtSWQpLFxyXG4gICAgICAgICAgc3luY1F1ZXVlOiBzdGF0ZS5zeW5jUXVldWUuZmlsdGVyKChpdGVtKSA9PiBpdGVtLmlkICE9PSBjY21JZClcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIGlmIChuYXZpZ2F0b3Iub25MaW5lKSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCB7IHRva2VuIH0gPSBnZXQoKTtcclxuICAgICAgICAgICAgYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvY2NtLyR7Y2NtSWR9YCwge1xyXG4gICAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURScsXHJcbiAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgLi4uKHRva2VuID8geyAnQXV0aG9yaXphdGlvbic6IGBCZWFyZXIgJHt0b2tlbn1gIH0gOiB7fSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBlbGltaW5hciBDQ00gZGVsIHNlcnZpZG9yOicsIGUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuXHJcbiAgICAgIHJlbW92ZUZyb21RdWV1ZTogKGlkKSA9PiB7XHJcbiAgICAgICAgc2V0KChzdGF0ZSkgPT4gKHtcclxuICAgICAgICAgIHN5bmNRdWV1ZTogc3RhdGUuc3luY1F1ZXVlLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5pZCAhPT0gaWQpLFxyXG4gICAgICAgICAgcHJveWVjdG9zTG9jYWxlczogKHN0YXRlLnByb3llY3Rvc0xvY2FsZXMgfHwgW10pLmZpbHRlcigocCkgPT4gcC5pZCAhPT0gaWQpLFxyXG4gICAgICAgICAgZWxlbWVudG9zTG9jYWxlczogKHN0YXRlLmVsZW1lbnRvc0xvY2FsZXMgfHwgW10pLmZpbHRlcigoZSkgPT4gZS5pZCAhPT0gaWQpLFxyXG4gICAgICAgICAgc3ViZXN0YWNpb25lc0xvY2FsZXM6IChzdGF0ZS5zdWJlc3RhY2lvbmVzTG9jYWxlcyB8fCBbXSkuZmlsdGVyKChzKSA9PiBzLmlkICE9PSBpZClcclxuICAgICAgICB9KSk7XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBwcm9jZXNzU3luY1F1ZXVlOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgeyBzeW5jUXVldWUsIHRva2VuIH0gPSBnZXQoKTtcclxuICAgICAgICBpZiAoIXRva2VuIHx8IHN5bmNRdWV1ZS5sZW5ndGggPT09IDApIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL3N5bmMvcHVzaGAsIHtcclxuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgIC4uLih0b2tlbiAmJiB0b2tlbiAhPT0gJ21vY2stb2ZmbGluZS10b2tlbicgPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IG11dGF0aW9uczogc3luY1F1ZXVlLm1hcChpdGVtID0+ICh7XHJcbiAgICAgICAgICAgICAgZW50aXR5OiBpdGVtLnRpcG8sXHJcbiAgICAgICAgICAgICAgaWQ6IGl0ZW0uaWQsXHJcbiAgICAgICAgICAgICAgb3BlcmF0aW9uOiAnQ1JFQVRFJyxcclxuICAgICAgICAgICAgICBkYXRhOiBpdGVtLnBheWxvYWRcclxuICAgICAgICAgICAgfSkpIH0pXHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDAxIHx8IHJlcy5zdGF0dXMgPT09IDQwMykge1xyXG4gICAgICAgICAgICBnZXQoKS5oYW5kbGVBdXRoRXJyb3IocmVzLnN0YXR1cyk7XHJcbiAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ1Rva2VuIGV4cGlyYWRvJyB9O1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgICAgICAgaWYgKHJlcy5vayAmJiBkYXRhLm9rKSB7XHJcbiAgICAgICAgICAgIC8vIExpbXBpYXIgbGEgY29sYSBsb2NhbG1lbnRlIHRyYXMgY29uZmlybWFjacOzbiBleGl0b3NhXHJcbiAgICAgICAgICAgIHNldCh7IHN5bmNRdWV1ZTogW10gfSk7XHJcbiAgICAgICAgICAgIGdldCgpLnB1bGxJbml0aWFsRGF0YSgpO1xyXG4gICAgICAgICAgICBnZXQoKS5zaG93VG9hc3QoJ1NpbmNyb25pemFjacOzbiBjb21wbGV0YWRhIGV4aXRvc2FtZW50ZScsICdzdWNjZXNzJyk7XHJcbiAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGdldCgpLnNob3dUb2FzdCgnRXJyb3IgZW4gc2luY3Jvbml6YWNpw7NuOiAnICsgKGRhdGEuZXJyb3IgfHwgJ3Vua25vd24nKSwgJ2Vycm9yJyk7XHJcbiAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZGF0YS5lcnJvciB9O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIHByb2Nlc2FyIGNvbGEgZGUgc2luY3Jvbml6YWNpw7NuOicsIGUpO1xyXG4gICAgICAgICAgZ2V0KCkuc2hvd1RvYXN0KCdFcnJvciBkZSByZWQgYWwgc2luY3Jvbml6YXInLCAnZXJyb3InKTtcclxuICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZS5tZXNzYWdlIH07XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG5cclxuICAgICAgc3luY1BlbmRpbmdEYXRhOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGdldCgpLnByb2Nlc3NTeW5jUXVldWUoKTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIGJhY2t1cERhdG9zOiBhc3luYyAodGlwbyA9ICdjb21wbGV0bycpID0+IHtcclxuICAgICAgICBjb25zdCB7IHVzZXIgfSA9IGdldCgpO1xyXG4gICAgICAgIGlmICghdXNlcikgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnTm8gaGEgaW5pY2lhZG8gc2VzacOzbicgfTtcclxuICAgICAgICBcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgZ2V0KCkuc2hvd1RvYXN0KCdHZW5lcmFuZG8gYmFja3VwICcgKyB0aXBvICsgJy4uLicsICdpbmZvJyk7XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2JhY2t1cC9sb2NhbGAsIHtcclxuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ0F1dGhvcml6YXRpb24nOiBgQmVhcmVyICR7dXNlci50b2tlbn1gIH0sXHJcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdGlwbyB9KVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgICAgICAgaWYgKGRhdGEuc3VjY2VzcyAmJiBkYXRhLmFyY2hpdm8pIHtcclxuICAgICAgICAgICAgLy8gR3VhcmRhciBhcmNoaXZvIGVuIGxvY2FsZm9yYWdlXHJcbiAgICAgICAgICAgIGNvbnN0IG5vbWJyZUFyY2hpdm8gPSBgYmFja3VwLSR7dGlwb30tJHtEYXRlLm5vdygpfS5qc29uYDtcclxuICAgICAgICAgICAgYXdhaXQgbG9jYWxmb3JhZ2Uuc2V0SXRlbShub21icmVBcmNoaXZvLCBkYXRhLmFyY2hpdm8pO1xyXG4gICAgICAgICAgICBnZXQoKS5zaG93VG9hc3QoJ0JhY2t1cCBndWFyZGFkbyBsb2NhbG1lbnRlIGNvbW86ICcgKyBub21icmVBcmNoaXZvLCAnc3VjY2VzcycpO1xyXG4gICAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBmaWxlbmFtZTogbm9tYnJlQXJjaGl2byB9O1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZ2V0KCkuc2hvd1RvYXN0KCdFcnJvciBnZW5lcmFuZG8gYmFja3VwOiAnICsgKGRhdGEuZXJyb3IgfHwgJ3Vua25vd24nKSwgJ2Vycm9yJyk7XHJcbiAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZGF0YS5lcnJvciB9O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGdlbmVyYXIgYmFja3VwOicsIGUpO1xyXG4gICAgICAgICAgZ2V0KCkuc2hvd1RvYXN0KCdFcnJvciBkZSByZWQgYWwgZ2VuZXJhciBiYWNrdXAnLCAnZXJyb3InKTtcclxuICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZS5tZXNzYWdlIH07XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG5cclxuICAgICAgcmVzcGFsZGFyRW5Mb2NhbFN0b3JhZ2U6IGFzeW5jIChub21icmUsIGNvbnRlbmlkb0pzb24pID0+IHtcclxuICAgICAgICAvLyBHdWFyZGFyIGJhY2t1cCBjb2RpZmljYWRvIGVuIGxvY2FsZm9yYWdlXHJcbiAgICAgICAgY29uc3QgY29udGVuaWRvQmxvYiA9IHR5cGVvZiBjb250ZW5pZG9Kc29uID09PSAnc3RyaW5nJyBcclxuICAgICAgICAgID8gY29udGVuaWRvSnNvbiBcclxuICAgICAgICAgIDogSlNPTi5zdHJpbmdpZnkoY29udGVuaWRvSnNvbiwgbnVsbCwgMik7XHJcbiAgICAgICAgXHJcbiAgICAgICAgYXdhaXQgbG9jYWxmb3JhZ2Uuc2V0SXRlbShub21icmUsIGNvbnRlbmlkb0Jsb2IpO1xyXG4gICAgICAgIGdldCgpLnNob3dUb2FzdCgnQmFja3VwIGd1YXJkYWRvIGVuIGFsbWFjZW5hbWllbnRvIGxvY2FsJywgJ3N1Y2Nlc3MnKTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIG9idGVuZXJSZXNwYWxkb0xvY2FsOiBhc3luYyAobm9tYnJlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGxvY2FsZm9yYWdlLmdldEl0ZW0obm9tYnJlKTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIGxpc3RhckJhY2t1cHNMb2NhbGVzOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qga2V5cyA9IGF3YWl0IGxvY2FsZm9yYWdlLmtleXMoKTtcclxuICAgICAgICBjb25zdCBiYWNrdXBzID0gW107XHJcbiAgICAgICAgXHJcbiAgICAgICAgZm9yIChjb25zdCBrZXkgb2Yga2V5cykge1xyXG4gICAgICAgICAgaWYgKGtleS5zdGFydHNXaXRoKCdiYWNrdXAtJykpIHtcclxuICAgICAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxvY2FsZm9yYWdlLmdldEl0ZW0oa2V5KTtcclxuICAgICAgICAgICAgYmFja3Vwcy5wdXNoKHtcclxuICAgICAgICAgICAgICBub21icmU6IGtleSxcclxuICAgICAgICAgICAgICBmZWNoYToga2V5LnJlcGxhY2UoJ2JhY2t1cC0nLCAnJykucmVwbGFjZSgnLmpzb24nLCAnJykgfHwgJ2Rlc2Nvbm9jaWRhJyxcclxuICAgICAgICAgICAgICBzaXplOiB0eXBlb2YgZGF0YSA9PT0gJ3N0cmluZycgPyBkYXRhLmxlbmd0aCA6IDBcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiBiYWNrdXBzO1xyXG4gICAgICB9LFxyXG5cclxuICAgICAgZWxpbWluYXJCYWNrdXBMb2NhbDogYXN5bmMgKG5vbWJyZSkgPT4ge1xyXG4gICAgICAgIGF3YWl0IGxvY2FsZm9yYWdlLnJlbW92ZUl0ZW0obm9tYnJlKTtcclxuICAgICAgfSxcclxuICAgICAgXHJcbiAgICAgIG1lc3NhZ2VzOiBbXSxcclxuICAgICAgc2VuZE1lc3NhZ2U6IGFzeW5jIChyZWNlaXZlcklkLCB0ZXh0KSA9PiB7XHJcbiAgICAgICAgY29uc3QgeyB1c2VyIH0gPSBnZXQoKTtcclxuICAgICAgICBpZiAoIXVzZXIpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ05vIGhhIGluaWNpYWRvIHNlc2nDs24uJyB9O1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnN0IG5ld01lc3NhZ2UgPSB7XHJcbiAgICAgICAgICBpZDogYG1zZy0ke0RhdGUubm93KCl9YCxcclxuICAgICAgICAgIHNlbmRlcklkOiB1c2VyLmlkLFxyXG4gICAgICAgICAgc2VuZGVyVXNlcm5hbWU6IHVzZXIudXNlcm5hbWUgfHwgdXNlci5lbWFpbCB8fCAnQW7Ds25pbW8nLFxyXG4gICAgICAgICAgcmVjZWl2ZXJJZCxcclxuICAgICAgICAgIHRleHQsXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgXHJcbiAgICAgICAgc2V0KChzdGF0ZSkgPT4gKHtcclxuICAgICAgICAgIG1lc3NhZ2VzOiBbLi4uKHN0YXRlLm1lc3NhZ2VzIHx8IFtdKSwgbmV3TWVzc2FnZV1cclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL21lc3NhZ2VzYCwge1xyXG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXHJcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KG5ld01lc3NhZ2UpXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgICAgICAgaWYgKGRhdGEub2spIHtcclxuICAgICAgICAgICAgc2V0KChzdGF0ZSkgPT4gKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlczogKHN0YXRlLm1lc3NhZ2VzIHx8IFtdKS5tYXAoKG0pID0+IG0uaWQgPT09IG5ld01lc3NhZ2UuaWQgPyBkYXRhLmRhdGEgOiBtKVxyXG4gICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgZW52aWFyIG1lbnNhamU6JywgZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBtZXNzYWdlOiBuZXdNZXNzYWdlIH07XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBhZGRJbmNvbWluZ01lc3NhZ2U6IChtc2cpID0+IHtcclxuICAgICAgICBjb25zdCBleGlzdHMgPSAoZ2V0KCkubWVzc2FnZXMgfHwgW10pLnNvbWUoKG0pID0+IG0uaWQgPT09IG1zZy5pZCk7XHJcbiAgICAgICAgaWYgKGV4aXN0cykgcmV0dXJuO1xyXG5cclxuICAgICAgICBzZXQoKHN0YXRlKSA9PiAoe1xyXG4gICAgICAgICAgbWVzc2FnZXM6IFsuLi4oc3RhdGUubWVzc2FnZXMgfHwgW10pLCBtc2ddXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICB9LFxyXG5cclxuICAgICAgbWFya01lc3NhZ2VzQXNSZWFkOiBhc3luYyAoc2VuZGVySWQpID0+IHtcclxuICAgICAgICBjb25zdCB7IHVzZXIgfSA9IGdldCgpO1xyXG4gICAgICAgIGlmICghdXNlcikgcmV0dXJuO1xyXG5cclxuICAgICAgICBzZXQoKHN0YXRlKSA9PiAoe1xyXG4gICAgICAgICAgbWVzc2FnZXM6IChzdGF0ZS5tZXNzYWdlcyB8fCBbXSkubWFwKChtKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChtLnNlbmRlcklkID09PSBzZW5kZXJJZCAmJiBtLnJlY2VpdmVySWQgPT09IHVzZXIuaWQgJiYgIW0ucmVhZCkge1xyXG4gICAgICAgICAgICAgIHJldHVybiB7IC4uLm0sIHJlYWQ6IHRydWUgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gbTtcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvbWVzc2FnZXMvcmVhZGAsIHtcclxuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxyXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHNlbmRlcklkLCByZWNlaXZlcklkOiB1c2VyLmlkIH0pXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBtYXJjYW5kbyBtZW5zYWplcyBjb21vIGxlw61kb3M6JywgZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG5cclxuICAgICAgdmluY3VsYXJKZXJhcnF1aWE6IChwcm95ZWN0b0lkLCBwYWRyZUlkLCBoaWpvSWQsIGRhdG9zRW5sYWNlID0ge30pID0+IHtcclxuICAgICAgICBzZXQoKHN0YXRlKSA9PiB7XHJcbiAgICAgICAgICBsZXQgbm9tYnJlUGFkcmUgPSAnJztcclxuICAgICAgICAgIGNvbnN0IG5ld0NvbXBhbmllcyA9IChzdGF0ZS5jb21wYW5pZXMgfHwgW10pLm1hcCgoYykgPT4gKHtcclxuICAgICAgICAgICAgLi4uYyxcclxuICAgICAgICAgICAgcHJveWVjdG9zOiAoYy5wcm95ZWN0b3MgfHwgW10pLm1hcCgocCkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmIChwLmlkICE9PSBwcm95ZWN0b0lkKSByZXR1cm4gcDtcclxuXHJcbiAgICAgICAgICAgICAgLy8gQnVzY2FyIG5vbWJyZSBkZWwgcGFkcmUgc2kgZXhpc3RlXHJcbiAgICAgICAgICAgICAgY29uc3QgbGlzdCA9IHAuZWxlbWVudG9zVW5pZmlsYXJlcyB8fCBbXTtcclxuICAgICAgICAgICAgICBjb25zdCBwYWRyZSA9IGxpc3QuZmluZCgoZSkgPT4gZS5pZCA9PT0gcGFkcmVJZCk7XHJcbiAgICAgICAgICAgICAgaWYgKHBhZHJlKSBub21icmVQYWRyZSA9IHBhZHJlLm5vbWJyZTtcclxuXHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgICAgICBlbGVtZW50b3NVbmlmaWxhcmVzOiAocC5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IFtdKS5tYXAoKGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKGUuaWQgPT09IGhpam9JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxpbWVudGFkb1BvcklkOiBwYWRyZUlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxpbWVudGFkb1Bvcjogbm9tYnJlUGFkcmUgPyBgJHtub21icmVQYWRyZX0gKCR7ZGF0b3NFbmxhY2UuY2lyY3VpdG9PcmlnZW4gfHwgJ1NhbGlkYSd9KWAgOiBlLmFsaW1lbnRhZG9Qb3IsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaXJjdWl0b09yaWdlbjogZGF0b3NFbmxhY2UuY2lyY3VpdG9PcmlnZW4gfHwgZS5jaXJjdWl0b09yaWdlbixcclxuICAgICAgICAgICAgICAgICAgICAgIGNhbGlicmVDb25kdWN0b3I6IGRhdG9zRW5sYWNlLmNhbGlicmVDb25kdWN0b3IgfHwgZS5jYWxpYnJlQ29uZHVjdG9yLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYnJlYWtlckFtcGVyYWplOiBkYXRvc0VubGFjZS5icmVha2VyQW1wZXJhamUgfHwgZS5icmVha2VyQW1wZXJhamUsXHJcbiAgICAgICAgICAgICAgICAgICAgICBicmVha2VyTWFyY2E6IGRhdG9zRW5sYWNlLmJyZWFrZXJNYXJjYSB8fCBlLmJyZWFrZXJNYXJjYSxcclxuICAgICAgICAgICAgICAgICAgICAgIGJyZWFrZXJUaXBvOiBkYXRvc0VubGFjZS5icmVha2VyVGlwbyB8fCBlLmJyZWFrZXJUaXBvLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZXN0YWRvVmluY3VsbzogJ0FDVElWTydcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiBlO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgcmV0dXJuIHsgY29tcGFuaWVzOiBuZXdDb21wYW5pZXMgfTtcclxuICAgICAgICB9KTtcclxuICAgICAgfSxcclxuXHJcbiAgICAgIGRlc3ZpbmN1bGFySmVyYXJxdWlhOiAocHJveWVjdG9JZCwgaGlqb0lkKSA9PiB7XHJcbiAgICAgICAgc2V0KChzdGF0ZSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgbmV3Q29tcGFuaWVzID0gKHN0YXRlLmNvbXBhbmllcyB8fCBbXSkubWFwKChjKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5jLFxyXG4gICAgICAgICAgICBwcm95ZWN0b3M6IChjLnByb3llY3RvcyB8fCBbXSkubWFwKChwKSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKHAuaWQgIT09IHByb3llY3RvSWQpIHJldHVybiBwO1xyXG4gICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5wLFxyXG4gICAgICAgICAgICAgICAgZWxlbWVudG9zVW5pZmlsYXJlczogKHAuZWxlbWVudG9zVW5pZmlsYXJlcyB8fCBbXSkubWFwKChlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGlmIChlLmlkID09PSBoaWpvSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4uZSxcclxuICAgICAgICAgICAgICAgICAgICAgIGFsaW1lbnRhZG9Qb3JJZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICAgIGFsaW1lbnRhZG9Qb3I6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaXJjdWl0b09yaWdlbjogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICAgIGVzdGFkb1ZpbmN1bG86ICdBQ1RJVk8nXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gZTtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH0pKTtcclxuICAgICAgICAgIHJldHVybiB7IGNvbXBhbmllczogbmV3Q29tcGFuaWVzIH07XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBjcmVhckVsZW1lbnRvUHJvdmlzaW9uYWw6IChwcm95ZWN0b0lkLCBkYXRvc1Byb3Zpc2lvbmFsID0ge30pID0+IHtcclxuICAgICAgICBjb25zdCBzdGF0ZSA9IGdldCgpO1xyXG4gICAgICAgIGNvbnN0IHRpcG8gPSBkYXRvc1Byb3Zpc2lvbmFsLnRpcG9FbGVtZW50byB8fCAnVEFCTEVSTyc7XHJcbiAgICAgICAgY29uc3QgbmV3SWQgPSBkYXRvc1Byb3Zpc2lvbmFsLmlkIHx8IGdldE5leHRFbGVtZW50SWQodGlwbywgc3RhdGUpO1xyXG5cclxuICAgICAgICBjb25zdCBwcm92aXNpb25hbE9iaiA9IHtcclxuICAgICAgICAgIGlkOiBuZXdJZCxcclxuICAgICAgICAgIG5vbWJyZTogZGF0b3NQcm92aXNpb25hbC5ub21icmUgfHwgYFJFU0VSVkEgKCR7bmV3SWR9KWAsXHJcbiAgICAgICAgICB0aXBvRWxlbWVudG86IHRpcG8sXHJcbiAgICAgICAgICB1YmljYWNpb246ICdSRVNFUlZBIChQZW5kaWVudGUgcG9yIENyZWFyKScsXHJcbiAgICAgICAgICBhbGltZW50YWRvUG9yOiBkYXRvc1Byb3Zpc2lvbmFsLmNpcmN1aXRvT3JpZ2VuID8gYENpcmN1aXRvICR7ZGF0b3NQcm92aXNpb25hbC5jaXJjdWl0b09yaWdlbn1gIDogbnVsbCxcclxuICAgICAgICAgIGNpcmN1aXRvT3JpZ2VuOiBkYXRvc1Byb3Zpc2lvbmFsLmNpcmN1aXRvT3JpZ2VuIHx8IG51bGwsXHJcbiAgICAgICAgICBlc3RhZG9WaW5jdWxvOiAnUEVORElFTlRFX0NSRUFSJyxcclxuICAgICAgICAgIG9ic2VydmFjaW9uZXNHZW5lcmFsZXM6ICdOb2RvIHJlZ2lzdHJhZG8gZW4gZXN0YWRvIHByb3Zpc2lvbmFsIGNvbW8gUmVzZXJ2YSBhY3RpdmEuJyxcclxuICAgICAgICAgIGRhdG9zVGVjbmljb3M6IHt9LFxyXG4gICAgICAgICAgcHJveWVjdG9JZFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGdldCgpLmFkZEVsZW1lbnRvVW5pZmlsYXIocHJveWVjdG9JZCwgcHJvdmlzaW9uYWxPYmopO1xyXG4gICAgICAgIHJldHVybiBwcm92aXNpb25hbE9iajtcclxuICAgICAgfVxyXG4gICAgfSksXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6ICd0YWJsZXJvc2VsZWN0cmljb196dXN0YW5kX3N0b3JlJyxcclxuICAgICAgc3RvcmFnZTogbG9jYWxGb3JhZ2VTdG9yYWdlLFxyXG4gICAgICBwYXJ0aWFsaXplOiAoc3RhdGUpID0+ICh7XHJcbiAgICAgICAgdXNlcjogc3RhdGUudXNlcixcclxuICAgICAgICB0b2tlbjogc3RhdGUudG9rZW4sXHJcbiAgICAgICAgdXNlcnNMaXN0OiBzdGF0ZS51c2Vyc0xpc3QgfHwgW10sXHJcbiAgICAgICAgbWVzc2FnZXM6IHN0YXRlLm1lc3NhZ2VzIHx8IFtdLFxyXG4gICAgICAgIGNvbXBhbmllczogc3RhdGUuY29tcGFuaWVzLFxyXG4gICAgICAgIHByb3llY3Rvc0xvY2FsZXM6IHN0YXRlLnByb3llY3Rvc0xvY2FsZXMgfHwgW10sXHJcbiAgICAgICAgZWxlbWVudG9zTG9jYWxlczogc3RhdGUuZWxlbWVudG9zTG9jYWxlcyB8fCBbXSxcclxuICAgICAgICBzdWJlc3RhY2lvbmVzTG9jYWxlczogc3RhdGUuc3ViZXN0YWNpb25lc0xvY2FsZXMgfHwgW10sXHJcbiAgICAgICAgY29uZmxpY3Rvc0NpcmN1aXRvczogc3RhdGUuY29uZmxpY3Rvc0NpcmN1aXRvcyB8fCBbXSxcclxuICAgICAgICBzeW5jUXVldWU6IHN0YXRlLnN5bmNRdWV1ZVxyXG4gICAgICB9KSxcclxuICAgICAgb25SZWh5ZHJhdGVTdG9yYWdlOiAoKSA9PiAoc3RhdGUpID0+IHtcclxuICAgICAgICBpZiAoc3RhdGUgJiYgc3RhdGUudG9rZW4gJiYgc3RhdGUudG9rZW4gIT09ICdtb2NrLW9mZmxpbmUtdG9rZW4nICYmIHR5cGVvZiBuYXZpZ2F0b3IgIT09ICd1bmRlZmluZWQnICYmIG5hdmlnYXRvci5vbkxpbmUpIHtcclxuICAgICAgICAgIC8vIERlc2NhcmdhIGF1dG9tw6F0aWNhIHRyYW5zcGFyZW50ZSBkZXNkZSBQb3N0Z3JlU1FMIHRyYXMgcmVzdGF1cmFyIHNlc2nDs24gcGVyc2lzdGlkYVxyXG4gICAgICAgICAgc3RhdGUucHVsbEluaXRpYWxEYXRhPy4oKTtcclxuICAgICAgICAgIHN0YXRlLmZldGNoVXNlcnNMaXN0Py4oKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICApXHJcbik7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdG9yZTtcclxuIl19