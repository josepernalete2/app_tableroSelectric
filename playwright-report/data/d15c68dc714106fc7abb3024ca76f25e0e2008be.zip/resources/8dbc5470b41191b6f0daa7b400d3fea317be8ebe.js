const StrictMode = __vite__cjsImport0_react["StrictMode"];const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=f49807c8";
import "/src/index.css?t=1790794222382";
import App from "/src/App.jsx?t=1790793862643";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/main.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
// Registro del Service Worker para PWA y Notificaciones Push
if (typeof window !== "undefined" && "serviceWorker" in navigator) {
	window.addEventListener("load", () => {
		navigator.serviceWorker.register("/sw.js").then((reg) => {
			// Forzar chequeo de actualización al cargar
			reg.update().catch(() => {});
			reg.onupdatefound = () => {
				const installingWorker = reg.installing;
				if (installingWorker) {
					installingWorker.onstatechange = () => {
						if (installingWorker.state === "installed" && navigator.serviceWorker.controller) {
							console.log("🔄 Nueva versión PWA v2.3.0 disponible. Recargando para actualizar scripts...");
						}
					};
				}
			};
		}).catch((err) => {
			console.warn("⚠️ No se pudo registrar el Service Worker:", err);
		});
	});
}
createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 31,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 30,
	columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTztBQUNQLE9BQU8sU0FBUzs7OztBQUdoQixJQUFJLE9BQU8sV0FBVyxlQUFlLG1CQUFtQixXQUFXO0NBQ2pFLE9BQU8saUJBQWlCLGNBQWM7RUFDcEMsVUFBVSxjQUFjLFNBQVMsUUFBUSxDQUFDLENBQUMsTUFBTSxRQUFROztHQUV2RCxJQUFJLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0dBRTNCLElBQUksc0JBQXNCO0lBQ3hCLE1BQU0sbUJBQW1CLElBQUk7SUFDN0IsSUFBSSxrQkFBa0I7S0FDcEIsaUJBQWlCLHNCQUFzQjtNQUNyQyxJQUFJLGlCQUFpQixVQUFVLGVBQWUsVUFBVSxjQUFjLFlBQVk7T0FDaEYsUUFBUSxJQUFJLCtFQUErRTtNQUM3RjtLQUNGO0lBQ0Y7R0FDRjtFQUNGLENBQUMsQ0FBQyxDQUFDLE9BQU8sUUFBUTtHQUNoQixRQUFRLEtBQUssOENBQThDLEdBQUc7RUFDaEUsQ0FBQztDQUNILENBQUM7QUFDSDtBQUVBLFdBQVcsU0FBUyxlQUFlLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FDMUMsd0JBQUMsWUFBRCxZQUNFLHdCQUFDLEtBQUQsQ0FBTTs7OztTQUNJOzs7O1FBQ2QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibWFpbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3RyaWN0TW9kZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCdcclxuaW1wb3J0ICcuL2luZGV4LmNzcydcclxuaW1wb3J0IEFwcCBmcm9tICcuL0FwcC5qc3gnXHJcblxyXG4vLyBSZWdpc3RybyBkZWwgU2VydmljZSBXb3JrZXIgcGFyYSBQV0EgeSBOb3RpZmljYWNpb25lcyBQdXNoXHJcbmlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiAnc2VydmljZVdvcmtlcicgaW4gbmF2aWdhdG9yKSB7XHJcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCAoKSA9PiB7XHJcbiAgICBuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5yZWdpc3RlcignL3N3LmpzJykudGhlbigocmVnKSA9PiB7XHJcbiAgICAgIC8vIEZvcnphciBjaGVxdWVvIGRlIGFjdHVhbGl6YWNpw7NuIGFsIGNhcmdhclxyXG4gICAgICByZWcudXBkYXRlKCkuY2F0Y2goKCkgPT4ge30pO1xyXG4gICAgICBcclxuICAgICAgcmVnLm9udXBkYXRlZm91bmQgPSAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaW5zdGFsbGluZ1dvcmtlciA9IHJlZy5pbnN0YWxsaW5nO1xyXG4gICAgICAgIGlmIChpbnN0YWxsaW5nV29ya2VyKSB7XHJcbiAgICAgICAgICBpbnN0YWxsaW5nV29ya2VyLm9uc3RhdGVjaGFuZ2UgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnN0YWxsaW5nV29ya2VyLnN0YXRlID09PSAnaW5zdGFsbGVkJyAmJiBuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5jb250cm9sbGVyKSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coJ/CflIQgTnVldmEgdmVyc2nDs24gUFdBIHYyLjMuMCBkaXNwb25pYmxlLiBSZWNhcmdhbmRvIHBhcmEgYWN0dWFsaXphciBzY3JpcHRzLi4uJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICB9O1xyXG4gICAgfSkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICBjb25zb2xlLndhcm4oJ+KaoO+4jyBObyBzZSBwdWRvIHJlZ2lzdHJhciBlbCBTZXJ2aWNlIFdvcmtlcjonLCBlcnIpO1xyXG4gICAgfSk7XHJcbiAgfSk7XHJcbn1cclxuXHJcbmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSkucmVuZGVyKFxyXG4gIDxTdHJpY3RNb2RlPlxyXG4gICAgPEFwcCAvPlxyXG4gIDwvU3RyaWN0TW9kZT4sXHJcbilcclxuXHJcblxyXG4iXX0=