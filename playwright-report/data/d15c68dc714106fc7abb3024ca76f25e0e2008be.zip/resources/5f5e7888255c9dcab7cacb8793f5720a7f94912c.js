import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/EditableCell.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/EditableCell.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
/**
* Reusable cell component that implements "Tap-to-Edit" logic.
* It displays clean text, and morphs into a form control on click.
*/
export const EditableCell = ({ value = "", onSave, type = "text", options = [], className = "", inputClassName = "", placeholder = "", disabled = false }) => {
	_s();
	const [isEditing, setIsEditing] = useState(false);
	const [editValue, setEditValue] = useState(value);
	const inputRef = useRef(null);
	// Sync editValue when parent value changes
	useEffect(() => {
		setEditValue(value);
	}, [value]);
	// Focus the input when editing starts
	useEffect(() => {
		if (isEditing && inputRef.current) {
			inputRef.current.focus();
			// For text inputs, select the text for easier replacement
			if (type === "text" || type === "number") {
				inputRef.current.select?.();
			}
		}
	}, [isEditing, type]);
	// Normalización de texto: recorta espacios y convierte a mayúsculas para evitar duplicados como "sql" y "SQL"
	const normalizeText = (text) => {
		if (typeof text !== "string") return text;
		return text.trim().replace(/\s+/g, " ").toUpperCase();
	};
	const handleKeyDown = (e) => {
		if (e.key === "Enter") {
			setIsEditing(false);
			onSave(normalizeText(editValue));
		} else if (e.key === "Escape") {
			setIsEditing(false);
			setEditValue(value);
		}
	};
	const handleBlur = () => {
		setIsEditing(false);
		onSave(normalizeText(editValue));
	};
	if (disabled) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: `p-1.5 min-h-[1.75rem] text-slate-800 dark:text-slate-200 select-none ${className}`,
			children: value || /* @__PURE__ */ _jsxDEV("span", {
				className: "opacity-30",
				children: "—"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 19
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 7
		}, this);
	}
	if (isEditing) {
		if (type === "textarea") {
			return /* @__PURE__ */ _jsxDEV("textarea", {
				ref: inputRef,
				value: editValue,
				onChange: (e) => setEditValue(e.target.value),
				onBlur: handleBlur,
				onKeyDown: (e) => {
					if (e.key === "Enter" && !e.shiftKey) {
						e.preventDefault();
						setIsEditing(false);
						onSave(normalizeText(editValue));
					} else if (e.key === "Escape") {
						setIsEditing(false);
						setEditValue(value);
					}
				},
				className: `w-full p-1 text-xs text-slate-900 bg-amber-50 dark:bg-slate-800 dark:text-slate-100 border border-amber-300 focus:outline-none focus:ring-1 focus:ring-amber-500 rounded min-h-[3rem] resize-y ${inputClassName}`,
				placeholder
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 9
			}, this);
		}
		return /* @__PURE__ */ _jsxDEV("input", {
			ref: inputRef,
			type: type === "number" ? "text" : type,
			value: editValue,
			onChange: (e) => setEditValue(e.target.value),
			onBlur: handleBlur,
			onKeyDown: handleKeyDown,
			placeholder,
			className: `w-full px-1.5 py-0.5 text-xs text-slate-900 bg-amber-50 dark:bg-slate-800 dark:text-slate-100 border border-amber-300 focus:outline-none focus:ring-1 focus:ring-amber-500 rounded h-7 font-sans ${inputClassName}`
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 91,
			columnNumber: 7
		}, this);
	}
	// Display mode
	const displayVal = value !== undefined && value !== null ? String(value) : "";
	const isEmpty = displayVal.trim() === "";
	return /* @__PURE__ */ _jsxDEV("div", {
		onClick: () => setIsEditing(true),
		className: `p-1.5 min-h-[1.75rem] transition-colors duration-150 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800/50 break-words ${isEmpty ? "text-slate-400 dark:text-slate-600 italic" : "text-slate-900 dark:text-slate-100 font-mono"} ${className}`,
		children: isEmpty ? placeholder || "—" : displayVal
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 109,
		columnNumber: 5
	}, this);
};
_s(EditableCell, "AFDJeLurbAmk3hj46ZkiD2wtbCI=");
_c = EditableCell;
export default EditableCell;
var _c;
$RefreshReg$(_c, "EditableCell");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/EditableCell.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/EditableCell.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/EditableCell.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/EditableCell.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxjQUFjOzs7Ozs7OztBQU1uRCxPQUFPLE1BQU0sZ0JBQWdCLEVBQzNCLFFBQVEsSUFDUixRQUNBLE9BQU8sUUFDUCxVQUFVLENBQUMsR0FDWCxZQUFZLElBQ1osaUJBQWlCLElBQ2pCLGNBQWMsSUFDZCxXQUFXLFlBQ1A7O0NBQ0osTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sV0FBVyxPQUFPLElBQUk7O0NBRzVCLGdCQUFnQjtFQUNkLGFBQWEsS0FBSztDQUNwQixHQUFHLENBQUMsS0FBSyxDQUFDOztDQUdWLGdCQUFnQjtFQUNkLElBQUksYUFBYSxTQUFTLFNBQVM7R0FDakMsU0FBUyxRQUFRLE1BQU07O0dBRXZCLElBQUksU0FBUyxVQUFVLFNBQVMsVUFBVTtJQUN4QyxTQUFTLFFBQVEsU0FBUztHQUM1QjtFQUNGO0NBQ0YsR0FBRyxDQUFDLFdBQVcsSUFBSSxDQUFDOztDQUdwQixNQUFNLGlCQUFpQixTQUFTO0VBQzlCLElBQUksT0FBTyxTQUFTLFVBQVUsT0FBTztFQUNyQyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsUUFBUSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFlBQVk7Q0FDdEQ7Q0FFQSxNQUFNLGlCQUFpQixNQUFNO0VBQzNCLElBQUksRUFBRSxRQUFRLFNBQVM7R0FDckIsYUFBYSxLQUFLO0dBQ2xCLE9BQU8sY0FBYyxTQUFTLENBQUM7RUFDakMsT0FBTyxJQUFJLEVBQUUsUUFBUSxVQUFVO0dBQzdCLGFBQWEsS0FBSztHQUNsQixhQUFhLEtBQUs7RUFDcEI7Q0FDRjtDQUVBLE1BQU0sbUJBQW1CO0VBQ3ZCLGFBQWEsS0FBSztFQUNsQixPQUFPLGNBQWMsU0FBUyxDQUFDO0NBQ2pDO0NBRUEsSUFBSSxVQUFVO0VBQ1osT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVyx3RUFBd0U7YUFDckYsU0FBUyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFhO0dBQU87Ozs7O0VBQzNDOzs7OztDQUVUO0NBRUEsSUFBSSxXQUFXO0VBQ2IsSUFBSSxTQUFTLFlBQVk7R0FDdkIsT0FDRSx3QkFBQyxZQUFEO0lBQ0UsS0FBSztJQUNMLE9BQU87SUFDUCxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztJQUM1QyxRQUFRO0lBQ1IsWUFBWSxNQUFNO0tBQ2hCLElBQUksRUFBRSxRQUFRLFdBQVcsQ0FBQyxFQUFFLFVBQVU7TUFDcEMsRUFBRSxlQUFlO01BQ2pCLGFBQWEsS0FBSztNQUNsQixPQUFPLGNBQWMsU0FBUyxDQUFDO0tBQ2pDLE9BQU8sSUFBSSxFQUFFLFFBQVEsVUFBVTtNQUM3QixhQUFhLEtBQUs7TUFDbEIsYUFBYSxLQUFLO0tBQ3BCO0lBQ0Y7SUFDQSxXQUFXLGtNQUFrTTtJQUNoTTtHQUNkOzs7OztFQUVMO0VBRUEsT0FDRSx3QkFBQyxTQUFEO0dBQ0UsS0FBSztHQUNMLE1BQU0sU0FBUyxXQUFXLFNBQVM7R0FDbkMsT0FBTztHQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO0dBQzVDLFFBQVE7R0FDUixXQUFXO0dBQ0U7R0FDYixXQUFXLG9NQUFvTTtFQUNoTjs7Ozs7Q0FFTDs7Q0FHQSxNQUFNLGFBQWEsVUFBVSxhQUFhLFVBQVUsT0FBTyxPQUFPLEtBQUssSUFBSTtDQUMzRSxNQUFNLFVBQVUsV0FBVyxLQUFLLE1BQU07Q0FFdEMsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsZUFBZSxhQUFhLElBQUk7RUFDaEMsV0FBVyxpSUFDVCxVQUFVLDhDQUE4QywrQ0FDekQsR0FBRztZQUVILFVBQVcsZUFBZSxNQUFPO0NBQy9COzs7OztBQUVUOzs7QUFDQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkVkaXRhYmxlQ2VsbC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcclxuXHJcbi8qKlxyXG4gKiBSZXVzYWJsZSBjZWxsIGNvbXBvbmVudCB0aGF0IGltcGxlbWVudHMgXCJUYXAtdG8tRWRpdFwiIGxvZ2ljLlxyXG4gKiBJdCBkaXNwbGF5cyBjbGVhbiB0ZXh0LCBhbmQgbW9ycGhzIGludG8gYSBmb3JtIGNvbnRyb2wgb24gY2xpY2suXHJcbiAqL1xyXG5leHBvcnQgY29uc3QgRWRpdGFibGVDZWxsID0gKHtcclxuICB2YWx1ZSA9ICcnLFxyXG4gIG9uU2F2ZSxcclxuICB0eXBlID0gJ3RleHQnLFxyXG4gIG9wdGlvbnMgPSBbXSxcclxuICBjbGFzc05hbWUgPSAnJyxcclxuICBpbnB1dENsYXNzTmFtZSA9ICcnLFxyXG4gIHBsYWNlaG9sZGVyID0gJycsXHJcbiAgZGlzYWJsZWQgPSBmYWxzZSxcclxufSkgPT4ge1xyXG4gIGNvbnN0IFtpc0VkaXRpbmcsIHNldElzRWRpdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2VkaXRWYWx1ZSwgc2V0RWRpdFZhbHVlXSA9IHVzZVN0YXRlKHZhbHVlKTtcclxuICBjb25zdCBpbnB1dFJlZiA9IHVzZVJlZihudWxsKTtcclxuXHJcbiAgLy8gU3luYyBlZGl0VmFsdWUgd2hlbiBwYXJlbnQgdmFsdWUgY2hhbmdlc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRFZGl0VmFsdWUodmFsdWUpO1xyXG4gIH0sIFt2YWx1ZV0pO1xyXG5cclxuICAvLyBGb2N1cyB0aGUgaW5wdXQgd2hlbiBlZGl0aW5nIHN0YXJ0c1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaXNFZGl0aW5nICYmIGlucHV0UmVmLmN1cnJlbnQpIHtcclxuICAgICAgaW5wdXRSZWYuY3VycmVudC5mb2N1cygpO1xyXG4gICAgICAvLyBGb3IgdGV4dCBpbnB1dHMsIHNlbGVjdCB0aGUgdGV4dCBmb3IgZWFzaWVyIHJlcGxhY2VtZW50XHJcbiAgICAgIGlmICh0eXBlID09PSAndGV4dCcgfHwgdHlwZSA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICBpbnB1dFJlZi5jdXJyZW50LnNlbGVjdD8uKCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9LCBbaXNFZGl0aW5nLCB0eXBlXSk7XHJcblxyXG4gIC8vIE5vcm1hbGl6YWNpw7NuIGRlIHRleHRvOiByZWNvcnRhIGVzcGFjaW9zIHkgY29udmllcnRlIGEgbWF5w7pzY3VsYXMgcGFyYSBldml0YXIgZHVwbGljYWRvcyBjb21vIFwic3FsXCIgeSBcIlNRTFwiXHJcbiAgY29uc3Qgbm9ybWFsaXplVGV4dCA9ICh0ZXh0KSA9PiB7XHJcbiAgICBpZiAodHlwZW9mIHRleHQgIT09ICdzdHJpbmcnKSByZXR1cm4gdGV4dDtcclxuICAgIHJldHVybiB0ZXh0LnRyaW0oKS5yZXBsYWNlKC9cXHMrL2csICcgJykudG9VcHBlckNhc2UoKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGUpID0+IHtcclxuICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJykge1xyXG4gICAgICBzZXRJc0VkaXRpbmcoZmFsc2UpO1xyXG4gICAgICBvblNhdmUobm9ybWFsaXplVGV4dChlZGl0VmFsdWUpKTtcclxuICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09ICdFc2NhcGUnKSB7XHJcbiAgICAgIHNldElzRWRpdGluZyhmYWxzZSk7XHJcbiAgICAgIHNldEVkaXRWYWx1ZSh2YWx1ZSk7IC8vIHJldmVydCBjaGFuZ2VzXHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQmx1ciA9ICgpID0+IHtcclxuICAgIHNldElzRWRpdGluZyhmYWxzZSk7XHJcbiAgICBvblNhdmUobm9ybWFsaXplVGV4dChlZGl0VmFsdWUpKTtcclxuICB9O1xyXG5cclxuICBpZiAoZGlzYWJsZWQpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0xLjUgbWluLWgtWzEuNzVyZW1dIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgc2VsZWN0LW5vbmUgJHtjbGFzc05hbWV9YH0+XHJcbiAgICAgICAge3ZhbHVlIHx8IDxzcGFuIGNsYXNzTmFtZT1cIm9wYWNpdHktMzBcIj7igJQ8L3NwYW4+fVxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAoaXNFZGl0aW5nKSB7XHJcbiAgICBpZiAodHlwZSA9PT0gJ3RleHRhcmVhJykge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgcmVmPXtpbnB1dFJlZn1cclxuICAgICAgICAgIHZhbHVlPXtlZGl0VmFsdWV9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRWYWx1ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBvbkJsdXI9e2hhbmRsZUJsdXJ9XHJcbiAgICAgICAgICBvbktleURvd249eyhlKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJyAmJiAhZS5zaGlmdEtleSkge1xyXG4gICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICBzZXRJc0VkaXRpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgICAgIG9uU2F2ZShub3JtYWxpemVUZXh0KGVkaXRWYWx1ZSkpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnRXNjYXBlJykge1xyXG4gICAgICAgICAgICAgIHNldElzRWRpdGluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgc2V0RWRpdFZhbHVlKHZhbHVlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBwLTEgdGV4dC14cyB0ZXh0LXNsYXRlLTkwMCBiZy1hbWJlci01MCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGJvcmRlciBib3JkZXItYW1iZXItMzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZCBtaW4taC1bM3JlbV0gcmVzaXplLXkgJHtpbnB1dENsYXNzTmFtZX1gfVxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9e3BsYWNlaG9sZGVyfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgcmVmPXtpbnB1dFJlZn1cclxuICAgICAgICB0eXBlPXt0eXBlID09PSAnbnVtYmVyJyA/ICd0ZXh0JyA6IHR5cGV9XHJcbiAgICAgICAgdmFsdWU9e2VkaXRWYWx1ZX1cclxuICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRWYWx1ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgb25CbHVyPXtoYW5kbGVCbHVyfVxyXG4gICAgICAgIG9uS2V5RG93bj17aGFuZGxlS2V5RG93bn1cclxuICAgICAgICBwbGFjZWhvbGRlcj17cGxhY2Vob2xkZXJ9XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTEuNSBweS0wLjUgdGV4dC14cyB0ZXh0LXNsYXRlLTkwMCBiZy1hbWJlci01MCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGJvcmRlciBib3JkZXItYW1iZXItMzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZCBoLTcgZm9udC1zYW5zICR7aW5wdXRDbGFzc05hbWV9YH1cclxuICAgICAgLz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICAvLyBEaXNwbGF5IG1vZGVcclxuICBjb25zdCBkaXNwbGF5VmFsID0gdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gbnVsbCA/IFN0cmluZyh2YWx1ZSkgOiAnJztcclxuICBjb25zdCBpc0VtcHR5ID0gZGlzcGxheVZhbC50cmltKCkgPT09ICcnO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0VkaXRpbmcodHJ1ZSl9XHJcbiAgICAgIGNsYXNzTmFtZT17YHAtMS41IG1pbi1oLVsxLjc1cmVtXSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgY3Vyc29yLXBvaW50ZXIgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzUwIGJyZWFrLXdvcmRzICR7XHJcbiAgICAgICAgaXNFbXB0eSA/ICd0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNjAwIGl0YWxpYycgOiAndGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBmb250LW1vbm8nXHJcbiAgICAgIH0gJHtjbGFzc05hbWV9YH1cclxuICAgID5cclxuICAgICAge2lzRW1wdHkgPyAocGxhY2Vob2xkZXIgfHwgJ+KAlCcpIDogZGlzcGxheVZhbH1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IEVkaXRhYmxlQ2VsbDtcclxuIl19