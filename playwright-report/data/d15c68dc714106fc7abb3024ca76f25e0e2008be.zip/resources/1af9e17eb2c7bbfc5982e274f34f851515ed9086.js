import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DiagramaUnifilarBlueprint.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { ZoomIn, ZoomOut, RotateCcw, Link2 } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/DiagramaUnifilarBlueprint.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function DiagramaUnifilarBlueprint({ elementos = [], companyName = "EMPRESA", projectName = "PROYECTO", interactive = false, selectedNodeId = null, onNodeSelect = null }) {
	_s();
	const containerRef = useRef(null);
	const { updateElementoUnifilar } = useStore();
	const [zoom, setZoom] = useState(1);
	const [pan, setPan] = useState({
		x: 0,
		y: 0
	});
	const [isPanning, setIsPanning] = useState(false);
	const [panStart, setPanStart] = useState({
		x: 0,
		y: 0
	});
	// Estados de arrastre de Nodos individuales
	const [activeDragNodeId, setActiveDragNodeId] = useState(null);
	const [dragStartMouse, setDragStartMouse] = useState({
		x: 0,
		y: 0
	});
	const [dragStartNodePos, setDragStartNodePos] = useState({
		x: 0,
		y: 0
	});
	const [tempNodePositions, setTempNodePositions] = useState({});
	// 1. Procesar jerarquía, enlaces SSOT y fuentes de emergencia para ATS
	const { nodes, levels, maxNodesInLevel, depth, emergencyLinks } = useMemo(() => {
		if (!elementos || elementos.length === 0) {
			return {
				nodes: [],
				levels: {},
				maxNodesInLevel: 0,
				depth: 0,
				emergencyLinks: []
			};
		}
		const nameToNodeMap = new Map();
		const idToNodeMap = new Map();
		elementos.forEach((el) => {
			if (el.nombre) {
				nameToNodeMap.set(el.nombre.toLowerCase().trim(), el);
			}
			if (el.id) {
				idToNodeMap.set(el.id.toLowerCase().trim(), el);
				nameToNodeMap.set(el.id.toLowerCase().trim(), el);
			}
		});
		// Helper para extraer ID de un texto con formato "Nombre (ID: TAB-1)"
		const extractIdFromText = (text) => {
			if (!text || typeof text !== "string") return null;
			const match = text.match(/\((?:ID:\s*)?([A-Z0-9_-]+)\)/i);
			return match ? match[1].toLowerCase().trim() : null;
		};
		// Mapa de enlaces derivados de circuitos (ej. Tablero Principal alimenta Tablero Hidroneumático)
		const circuitFeedsMap = new Map();
		elementos.forEach((parentEl) => {
			const circuits = parentEl.circuits || parentEl.datosTecnicos?.circuits || [];
			if (Array.isArray(circuits)) {
				circuits.forEach((c) => {
					const destId = c.elementoDestinoId || c.vinculadoId || extractIdFromText(c.equipo);
					if (destId) {
						circuitFeedsMap.set(destId.toLowerCase().trim(), parentEl.id);
					}
					if (c.equipo && typeof c.equipo === "string") {
						const cleanEquipo = c.equipo.toLowerCase().trim();
						const matchingNode = nameToNodeMap.get(cleanEquipo);
						if (matchingNode) {
							circuitFeedsMap.set(matchingNode.id.toLowerCase().trim(), parentEl.id);
						}
					}
				});
			}
		});
		const emergencyLinksList = [];
		const processedNodes = elementos.map((el) => {
			const dt = typeof el.datosTecnicos === "string" ? JSON.parse(el.datosTecnicos || "{}") : el.datosTecnicos || {};
			// Resolución jerárquica de alimentación primaria (SSOT)
			let resolvedParentId = null;
			// 1. Verificar si el elemento tiene ID de alimentador directo
			if (el.alimentadoPorId && idToNodeMap.has(el.alimentadoPorId.toLowerCase().trim())) {
				resolvedParentId = idToNodeMap.get(el.alimentadoPorId.toLowerCase().trim()).id;
			} else if (el.origenId && idToNodeMap.has(el.origenId.toLowerCase().trim())) {
				resolvedParentId = idToNodeMap.get(el.origenId.toLowerCase().trim()).id;
			}
			// 2. Verificar por campo alimentadoPor (nombre o ID incrustado)
			if (!resolvedParentId && el.alimentadoPor) {
				const idFromAlim = extractIdFromText(el.alimentadoPor);
				if (idFromAlim && idToNodeMap.has(idFromAlim)) {
					resolvedParentId = idToNodeMap.get(idFromAlim).id;
				} else {
					const cleanAlim = el.alimentadoPor.toLowerCase().trim();
					const parentByName = nameToNodeMap.get(cleanAlim);
					if (parentByName) {
						resolvedParentId = parentByName.id;
					}
				}
			}
			// 3. Para ATS/Transferencia: verificar fuente normal
			const isTransfer = el.tipoElemento === "TRANSFER" || el.tipo === "TRANSFER";
			if (isTransfer) {
				const fuenteNormal = dt.fuenteNormalNombre || dt.fuenteNormalId || el.fuenteNormal;
				if (fuenteNormal) {
					const idFromNorm = extractIdFromText(fuenteNormal);
					if (idFromNorm && idToNodeMap.has(idFromNorm)) {
						resolvedParentId = idToNodeMap.get(idFromNorm).id;
					} else {
						const parentNorm = nameToNodeMap.get(String(fuenteNormal).toLowerCase().trim());
						if (parentNorm) resolvedParentId = parentNorm.id;
					}
				}
				// Resolución de la fuente de Emergencia (Generador -> ATS) (Observación 18)
				const fuenteEmergencia = dt.fuenteEmergenciaNombre || dt.fuenteEmergenciaId || dt.generadorId || dt.alimentacionGenerador1;
				let genNode = null;
				if (fuenteEmergencia) {
					const idFromEmerg = extractIdFromText(fuenteEmergencia);
					if (idFromEmerg && idToNodeMap.has(idFromEmerg)) {
						genNode = idToNodeMap.get(idFromEmerg);
					} else {
						genNode = nameToNodeMap.get(String(fuenteEmergencia).toLowerCase().trim());
					}
				}
				// Fallback: Si no está explícito en el ATS, buscar si existe un Generador en el proyecto
				if (!genNode) {
					genNode = elementos.find((e) => (e.tipoElemento === "GENERADOR" || e.tipo === "GENERADOR") && e.id !== el.id);
				}
				if (genNode && genNode.id !== el.id) {
					emergencyLinksList.push({
						id: `emerg-${genNode.id}-${el.id}`,
						sourceId: genNode.id,
						targetId: el.id,
						label: "EMERGENCIA (GEN)"
					});
				}
			}
			// 4. Si aún no tiene padre, verificar si está derivado de un circuito aguas arriba (Obs 25 - Hidroneumático)
			if (!resolvedParentId && circuitFeedsMap.has(el.id.toLowerCase().trim())) {
				resolvedParentId = circuitFeedsMap.get(el.id.toLowerCase().trim());
			}
			// Evitar auto-referencias circulares
			if (resolvedParentId === el.id) {
				resolvedParentId = null;
			}
			return {
				...el,
				datosTecnicos: dt,
				parentId: resolvedParentId,
				children: []
			};
		});
		const nodeMap = new Map(processedNodes.map((n) => [n.id, n]));
		const roots = [];
		processedNodes.forEach((node) => {
			if (node.parentId && nodeMap.has(node.parentId)) {
				nodeMap.get(node.parentId).children.push(node.id);
			} else {
				roots.push(node.id);
			}
		});
		const levelsMap = {};
		const nodeLevels = {};
		const queue = roots.map((id) => ({
			id,
			level: 0
		}));
		while (queue.length > 0) {
			const { id, level } = queue.shift();
			const node = nodeMap.get(id);
			if (!node) continue;
			nodeLevels[id] = level;
			if (!levelsMap[level]) levelsMap[level] = [];
			levelsMap[level].push(id);
			node.children.forEach((childId) => {
				queue.push({
					id: childId,
					level: level + 1
				});
			});
		}
		const finalNodes = processedNodes.map((n) => ({
			...n,
			level: nodeLevels[n.id] !== undefined ? nodeLevels[n.id] : 0
		}));
		let maxCount = 0;
		Object.keys(levelsMap).forEach((lvl) => {
			maxCount = Math.max(maxCount, levelsMap[lvl].length);
		});
		return {
			nodes: finalNodes,
			levels: levelsMap,
			maxNodesInLevel: maxCount,
			depth: Object.keys(levelsMap).length,
			emergencyLinks: emergencyLinksList
		};
	}, [elementos]);
	// Dimensiones fijas del lienzo CAD para libre posicionamiento (expandible si hay muchos niveles)
	const width = Math.max(1600, maxNodesInLevel * 250 + 200);
	const height = Math.max(1200, depth * 220 + 200);
	// Coordenadas calculadas de auto-layout (como fallback)
	const autoLayoutCoords = useMemo(() => {
		const coords = {};
		Object.keys(levels).forEach((lvlStr) => {
			const lvl = parseInt(lvlStr, 10);
			const lvlNodes = levels[lvl];
			const count = lvlNodes.length;
			const y = 120 + lvl * 180;
			lvlNodes.forEach((id, idx) => {
				const x = (idx + .5) * (width / count);
				coords[id] = {
					x,
					y
				};
			});
		});
		return coords;
	}, [levels, width]);
	// Obtener coordenadas finales de un nodo (prioriza temp -> custom -> auto)
	const getNodeCoords = (nodeId) => {
		if (tempNodePositions[nodeId]) {
			return tempNodePositions[nodeId];
		}
		const node = nodes.find((n) => n.id === nodeId);
		if (node && node.datosTecnicos?.positionX !== undefined && node.datosTecnicos?.positionY !== undefined) {
			return {
				x: parseFloat(node.datosTecnicos.positionX),
				y: parseFloat(node.datosTecnicos.positionY)
			};
		}
		return autoLayoutCoords[nodeId] || {
			x: 200,
			y: 200
		};
	};
	// PANNING (Arrastrar lienzo completo)
	const handleCanvasMouseDown = (e) => {
		if (!interactive) return;
		if (e.button !== 0) return;
		if (e.target.closest(".node-element")) return;
		setIsPanning(true);
		setPanStart({
			x: e.clientX - pan.x,
			y: e.clientY - pan.y
		});
	};
	const handleCanvasMouseMove = (e) => {
		if (interactive && isPanning) {
			setPan({
				x: e.clientX - panStart.x,
				y: e.clientY - panStart.y
			});
		}
		// Manejar arrastre activo del nodo
		if (interactive && activeDragNodeId) {
			const deltaX = (e.clientX - dragStartMouse.x) / zoom;
			const deltaY = (e.clientY - dragStartMouse.y) / zoom;
			setTempNodePositions((prev) => ({
				...prev,
				[activeDragNodeId]: {
					x: dragStartNodePos.x + deltaX,
					y: dragStartNodePos.y + deltaY
				}
			}));
		}
	};
	const handleCanvasMouseUp = () => {
		setIsPanning(false);
		// Finalizar arrastre de nodo y guardar
		if (activeDragNodeId) {
			const finalPos = tempNodePositions[activeDragNodeId];
			if (finalPos) {
				// Snapping a la rejilla de 20px
				const snappedX = Math.round(finalPos.x / 20) * 20;
				const snappedY = Math.round(finalPos.y / 20) * 20;
				const node = nodes.find((n) => n.id === activeDragNodeId);
				if (node) {
					updateElementoUnifilar(node.proyectoId, activeDragNodeId, { datosTecnicos: {
						...node.datosTecnicos,
						positionX: snappedX,
						positionY: snappedY
					} });
				}
			}
			setActiveDragNodeId(null);
		}
	};
	// TOUCH SUPPORT para móviles e iPads
	const handleTouchStart = (e) => {
		if (!interactive) return;
		const touch = e.touches[0];
		if (e.target.closest(".node-element")) {
			const nodeEl = e.target.closest(".node-element");
			const nodeId = nodeEl.dataset.nodeid;
			const startPos = getNodeCoords(nodeId);
			setActiveDragNodeId(nodeId);
			setDragStartMouse({
				x: touch.clientX,
				y: touch.clientY
			});
			setDragStartNodePos(startPos);
		} else {
			setIsPanning(true);
			setPanStart({
				x: touch.clientX - pan.x,
				y: touch.clientY - pan.y
			});
		}
	};
	const handleTouchMove = (e) => {
		if (!interactive) return;
		const touch = e.touches[0];
		if (activeDragNodeId) {
			const deltaX = (touch.clientX - dragStartMouse.x) / zoom;
			const deltaY = (touch.clientY - dragStartMouse.y) / zoom;
			setTempNodePositions((prev) => ({
				...prev,
				[activeDragNodeId]: {
					x: dragStartNodePos.x + deltaX,
					y: dragStartNodePos.y + deltaY
				}
			}));
		} else if (isPanning) {
			setPan({
				x: touch.clientX - panStart.x,
				y: touch.clientY - panStart.y
			});
		}
	};
	// WHEEL ZOOM
	const handleWheel = (e) => {
		if (!interactive) return;
		e.preventDefault();
		const scaleFactor = 1.1;
		if (e.deltaY < 0) {
			setZoom((prev) => Math.min(3, prev * scaleFactor));
		} else {
			setZoom((prev) => Math.max(.3, prev / scaleFactor));
		}
	};
	const resetView = () => {
		setZoom(1);
		setPan({
			x: 0,
			y: 0
		});
		setTempNodePositions({});
	};
	// RENDERIZADO DE SÍMBOLOS ELÉCTRICOS
	const renderNodeSymbol = (type, isPrint) => {
		const accentColor = isPrint ? "#000000" : "#f59e0b";
		const trafoColor = isPrint ? "#000000" : "#8b5cf6";
		const transferColor = isPrint ? "#000000" : "#10b981";
		const capacitorColor = isPrint ? "#000000" : "#06b6d4";
		const subColor = isPrint ? "#000000" : "#ec4899";
		const activeFill = isPrint ? "none" : undefined;
		switch (type) {
			case "GENERADOR": return /* @__PURE__ */ _jsxDEV("g", { children: [/* @__PURE__ */ _jsxDEV("circle", {
				cx: "0",
				cy: "0",
				r: "20",
				fill: activeFill || "#1e1b4b",
				stroke: accentColor,
				strokeWidth: "2.5"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 378,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("text", {
				x: "0",
				y: "5",
				textAnchor: "middle",
				fill: accentColor,
				className: "text-sm font-black font-mono",
				children: "G"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 379,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 377,
				columnNumber: 11
			}, this);
			case "TRANSFORMADOR": return /* @__PURE__ */ _jsxDEV("g", {
				transform: "scale(1)",
				children: [/* @__PURE__ */ _jsxDEV("circle", {
					cx: "0",
					cy: "-8",
					r: "14",
					fill: "none",
					stroke: trafoColor,
					strokeWidth: "2.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 385,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("circle", {
					cx: "0",
					cy: "8",
					r: "14",
					fill: "none",
					stroke: trafoColor,
					strokeWidth: "2.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 386,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 384,
				columnNumber: 11
			}, this);
			case "TRANSFER": return /* @__PURE__ */ _jsxDEV("g", { children: [/* @__PURE__ */ _jsxDEV("rect", {
				x: "-24",
				y: "-14",
				width: "48",
				height: "28",
				rx: "5",
				fill: activeFill || "#022c22",
				stroke: transferColor,
				strokeWidth: "2.5"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 392,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("text", {
				x: "0",
				y: "4",
				textAnchor: "middle",
				fill: transferColor,
				className: "text-[9px] font-black font-mono",
				children: "ATS"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 393,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 391,
				columnNumber: 11
			}, this);
			case "PUESTA_TIERRA": return /* @__PURE__ */ _jsxDEV("g", {
				transform: "scale(0.9)",
				children: [
					/* @__PURE__ */ _jsxDEV("line", {
						x1: "0",
						y1: "-18",
						x2: "0",
						y2: "4",
						stroke: transferColor,
						strokeWidth: "2.5"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 399,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("line", {
						x1: "-14",
						y1: "4",
						x2: "14",
						y2: "4",
						stroke: transferColor,
						strokeWidth: "2.5"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 400,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("line", {
						x1: "-9",
						y1: "10",
						x2: "9",
						y2: "10",
						stroke: transferColor,
						strokeWidth: "2"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 401,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("line", {
						x1: "-4",
						y1: "16",
						x2: "4",
						y2: "16",
						stroke: transferColor,
						strokeWidth: "1.5"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 402,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 398,
				columnNumber: 11
			}, this);
			case "SUBESTACION": return /* @__PURE__ */ _jsxDEV("g", { children: [/* @__PURE__ */ _jsxDEV("polygon", {
				points: "0,-20 18,-6 11,16 -11,16 -18,-6",
				fill: activeFill || "#311042",
				stroke: subColor,
				strokeWidth: "2.5"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 408,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("rect", {
				x: "-6",
				y: "-6",
				width: "12",
				height: "12",
				fill: "none",
				stroke: subColor,
				strokeWidth: "1.5"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 409,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 407,
				columnNumber: 11
			}, this);
			case "BANCO_CONDENSADOR":
			case "OTRO": return /* @__PURE__ */ _jsxDEV("g", { children: [
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "0",
					cy: "0",
					r: "18",
					fill: activeFill || "#083344",
					stroke: capacitorColor,
					strokeWidth: "2.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 416,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("line", {
					x1: "-5",
					y1: "-8",
					x2: "-5",
					y2: "8",
					stroke: capacitorColor,
					strokeWidth: "2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 417,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("line", {
					x1: "5",
					y1: "-8",
					x2: "5",
					y2: "8",
					stroke: capacitorColor,
					strokeWidth: "2"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 418,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("line", {
					x1: "-12",
					y1: "0",
					x2: "-5",
					y2: "0",
					stroke: capacitorColor,
					strokeWidth: "1.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 419,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("line", {
					x1: "5",
					y1: "0",
					x2: "12",
					y2: "0",
					stroke: capacitorColor,
					strokeWidth: "1.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 420,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 415,
				columnNumber: 11
			}, this);
			case "TABLERO":
			default: return /* @__PURE__ */ _jsxDEV("g", { children: [
				/* @__PURE__ */ _jsxDEV("rect", {
					x: "-26",
					y: "-18",
					width: "52",
					height: "36",
					rx: "4",
					fill: activeFill || "#082f49",
					stroke: isPrint ? "#000000" : "#0ea5e9",
					strokeWidth: "2.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 427,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("line", {
					x1: "0",
					y1: "-14",
					x2: "0",
					y2: "14",
					stroke: isPrint ? "#000000" : "#0ea5e9",
					strokeWidth: "1",
					strokeDasharray: "3,3"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 428,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("rect", {
					x: "-18",
					y: "-11",
					width: "8",
					height: "5",
					fill: isPrint ? "#000000" : "#0ea5e9"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 429,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("rect", {
					x: "10",
					y: "-3",
					width: "8",
					height: "5",
					fill: isPrint ? "#000000" : "#0ea5e9"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 430,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("rect", {
					x: "-18",
					y: "5",
					width: "8",
					height: "5",
					fill: isPrint ? "#000000" : "#0ea5e9"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 431,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 426,
				columnNumber: 11
			}, this);
		}
	};
	const isDarkTheme = interactive;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `w-full select-none ${isDarkTheme ? "bg-slate-950 text-slate-100 flex flex-col h-full" : "bg-white text-black p-4 border-2 border-black rounded-lg page-break"}`,
		children: [
			isDarkTheme && /* @__PURE__ */ _jsxDEV("div", {
				className: "flex justify-between items-center p-2.5 border-b border-slate-900 bg-slate-950 no-print shrink-0",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-[9.5px] font-mono font-bold text-slate-500 uppercase tracking-wider",
					children: "Arrastra elementos para moverlos • Arrastra el fondo para desplazar • Doble clic para reiniciar vista"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 450,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-0.5 rounded-lg",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setZoom((prev) => Math.max(.3, prev - .15)),
							className: "p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors cursor-pointer",
							title: "Alejar",
							children: /* @__PURE__ */ _jsxDEV(ZoomOut, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 459,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 454,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[9px] font-mono font-bold px-2 text-slate-400",
							children: [Math.round(zoom * 100), "%"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 461,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setZoom((prev) => Math.min(3, prev + .15)),
							className: "p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors cursor-pointer",
							title: "Acercar",
							children: /* @__PURE__ */ _jsxDEV(ZoomIn, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 469,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 464,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: resetView,
							className: "p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors cursor-pointer",
							title: "Restablecer",
							children: /* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 476,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 471,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 453,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 449,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				ref: containerRef,
				onMouseDown: handleCanvasMouseDown,
				onMouseMove: handleCanvasMouseMove,
				onMouseUp: handleCanvasMouseUp,
				onMouseLeave: handleCanvasMouseUp,
				onTouchStart: handleTouchStart,
				onTouchMove: handleTouchMove,
				onTouchEnd: handleCanvasMouseUp,
				onWheel: handleWheel,
				onDoubleClick: resetView,
				className: `relative overflow-hidden flex-1 flex items-center justify-center ${isDarkTheme ? "bg-slate-950/95 cursor-grab active:cursor-grabbing" : "bg-white p-2 min-h-[550px]"}`,
				children: nodes.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "text-center p-8 text-xs text-slate-600 font-mono",
					children: "No hay elementos unifilares en el diagrama. Agrega algunos desde la barra lateral izquierda."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 499,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					style: isDarkTheme ? {
						transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
						transformOrigin: "center center",
						transition: activeDragNodeId || isPanning ? "none" : "transform 0.15s ease-out"
					} : {
						width: "100%",
						height: "auto"
					},
					className: "w-full flex items-center justify-center",
					children: /* @__PURE__ */ _jsxDEV("svg", {
						viewBox: `0 0 ${width} ${height}`,
						width: isDarkTheme ? width : "100%",
						height: isDarkTheme ? height : "100%",
						className: "overflow-visible font-mono select-none",
						children: [
							/* @__PURE__ */ _jsxDEV("defs", { children: [
								isDarkTheme && /* @__PURE__ */ _jsxDEV("pattern", {
									id: "cad-grid",
									width: "40",
									height: "40",
									patternUnits: "userSpaceOnUse",
									children: [
										/* @__PURE__ */ _jsxDEV("circle", {
											cx: "20",
											cy: "20",
											r: "1",
											fill: "#1e293b"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 525,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("line", {
											x1: "0",
											y1: "0",
											x2: "40",
											y2: "0",
											stroke: "#0f172a",
											strokeWidth: "0.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 526,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("line", {
											x1: "0",
											y1: "0",
											x2: "0",
											y2: "40",
											stroke: "#0f172a",
											strokeWidth: "0.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 527,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 524,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("marker", {
									id: "arrow-black",
									viewBox: "0 0 10 10",
									refX: "22",
									refY: "5",
									markerWidth: "5",
									markerHeight: "5",
									orient: "auto-start-reverse",
									children: /* @__PURE__ */ _jsxDEV("path", {
										d: "M 0 1.5 L 8 5 L 0 8.5 z",
										fill: "#000000"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 541,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 532,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("marker", {
									id: "arrow-slate",
									viewBox: "0 0 10 10",
									refX: "22",
									refY: "5",
									markerWidth: "5",
									markerHeight: "5",
									orient: "auto-start-reverse",
									children: /* @__PURE__ */ _jsxDEV("path", {
										d: "M 0 1.5 L 8 5 L 0 8.5 z",
										fill: "#64748b"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 552,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 543,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("marker", {
									id: "arrow-amber",
									viewBox: "0 0 10 10",
									refX: "22",
									refY: "5",
									markerWidth: "5",
									markerHeight: "5",
									orient: "auto-start-reverse",
									children: /* @__PURE__ */ _jsxDEV("path", {
										d: "M 0 1.5 L 8 5 L 0 8.5 z",
										fill: "#f59e0b"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 563,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 554,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 521,
								columnNumber: 15
							}, this),
							isDarkTheme && /* @__PURE__ */ _jsxDEV("rect", {
								width,
								height,
								fill: "url(#cad-grid)",
								rx: "8"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 569,
								columnNumber: 17
							}, this),
							nodes.map((node) => {
								if (!node.parentId) return null;
								const parentCoords = getNodeCoords(node.parentId);
								const childCoords = getNodeCoords(node.id);
								// Línea con ángulo de 90° (Ortogonal)
								const midY = (parentCoords.y + childCoords.y) / 2;
								const pathData = `M ${parentCoords.x} ${parentCoords.y} L ${parentCoords.x} ${midY} L ${childCoords.x} ${midY} L ${childCoords.x} ${childCoords.y}`;
								return /* @__PURE__ */ _jsxDEV("g", { children: [/* @__PURE__ */ _jsxDEV("path", {
									d: pathData,
									fill: "none",
									stroke: "transparent",
									strokeWidth: "10"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 584,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("path", {
									d: pathData,
									fill: "none",
									stroke: isDarkTheme ? "#475569" : "#000000",
									strokeWidth: isDarkTheme ? "2.5" : "1.5",
									markerEnd: isDarkTheme ? "url(#arrow-slate)" : "url(#arrow-black)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 590,
									columnNumber: 21
								}, this)] }, `link-${node.id}`, true, {
									fileName: _jsxFileName,
									lineNumber: 583,
									columnNumber: 19
								}, this);
							}),
							emergencyLinks.map((link) => {
								const genCoords = getNodeCoords(link.sourceId);
								const atsCoords = getNodeCoords(link.targetId);
								// Conectar desde el lado derecho del Generador hacia la entrada de emergencia del ATS
								const midX = (genCoords.x + atsCoords.x) / 2;
								const midY = (genCoords.y + atsCoords.y) / 2;
								const pathData = `M ${genCoords.x} ${genCoords.y} L ${midX} ${genCoords.y} L ${midX} ${atsCoords.y} L ${atsCoords.x} ${atsCoords.y}`;
								return /* @__PURE__ */ _jsxDEV("g", { children: [
									/* @__PURE__ */ _jsxDEV("path", {
										d: pathData,
										fill: "none",
										stroke: isDarkTheme ? "#f59e0b" : "#d97706",
										strokeWidth: isDarkTheme ? "2.5" : "2",
										strokeDasharray: "6,4",
										markerEnd: "url(#arrow-amber)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 614,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("rect", {
										x: midX - 38,
										y: midY - 8,
										width: "76",
										height: "16",
										rx: "4",
										fill: isDarkTheme ? "#1e1b4b" : "#fef3c7",
										stroke: "#f59e0b",
										strokeWidth: "1"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 623,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("text", {
										x: midX,
										y: midY + 3,
										textAnchor: "middle",
										fontSize: "7.5",
										fontWeight: "black",
										fill: "#f59e0b",
										className: "font-mono select-none",
										children: "EMERGENCIA (G)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 633,
										columnNumber: 21
									}, this)
								] }, link.id, true, {
									fileName: _jsxFileName,
									lineNumber: 612,
									columnNumber: 19
								}, this);
							}),
							nodes.map((node) => {
								const coords = getNodeCoords(node.id);
								const isSelected = selectedNodeId === node.id;
								return /* @__PURE__ */ _jsxDEV("g", {
									transform: `translate(${coords.x}, ${coords.y})`,
									"data-nodeid": node.id,
									className: "node-element group cursor-grab active:cursor-grabbing",
									onClick: (e) => {
										e.stopPropagation();
										if (onNodeSelect) onNodeSelect(node);
									},
									onMouseDown: (e) => {
										if (!interactive) return;
										e.stopPropagation();
										setActiveDragNodeId(node.id);
										setDragStartMouse({
											x: e.clientX,
											y: e.clientY
										});
										setDragStartNodePos(coords);
									},
									children: [
										isDarkTheme && isSelected && /* @__PURE__ */ _jsxDEV("rect", {
											x: "-34",
											y: "-26",
											width: "68",
											height: "52",
											rx: "8",
											fill: "none",
											stroke: "#f59e0b",
											strokeWidth: "2.5",
											strokeDasharray: "4,3",
											className: "animate-pulse"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 673,
											columnNumber: 23
										}, this),
										renderNodeSymbol(node.tipoElemento, !isDarkTheme),
										/* @__PURE__ */ _jsxDEV("text", {
											x: "0",
											y: "36",
											textAnchor: "middle",
											fontSize: "9.5",
											fontWeight: "black",
											fill: isDarkTheme ? isSelected ? "#f59e0b" : "#cbd5e1" : "#000000",
											className: "font-sans select-none tracking-wide",
											children: node.nombre.length > 22 ? `${node.nombre.slice(0, 20)}...` : node.nombre
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 691,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("text", {
											x: "0",
											y: "-28",
											textAnchor: "middle",
											fontSize: "8",
											fontWeight: "bold",
											fill: isDarkTheme ? "#64748b" : "#334155",
											className: "font-mono select-none",
											children: node.id
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 704,
											columnNumber: 21
										}, this)
									]
								}, node.id, true, {
									fileName: _jsxFileName,
									lineNumber: 654,
									columnNumber: 19
								}, this);
							})
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 514,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 503,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 483,
				columnNumber: 7
			}, this),
			!isDarkTheme && /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 border-t-2 border-black pt-4 font-mono text-black text-[10px] uppercase",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "md:col-span-2 border border-black p-3 rounded bg-white",
					children: [/* @__PURE__ */ _jsxDEV("h4", {
						className: "font-black text-xs border-b border-black pb-1 mb-2",
						children: "Leyenda Unifilar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 729,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 sm:grid-cols-3 gap-2.5",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									width: "24",
									height: "24",
									className: "overflow-visible shrink-0",
									children: [/* @__PURE__ */ _jsxDEV("rect", {
										x: "2",
										y: "2",
										width: "20",
										height: "20",
										fill: "none",
										stroke: "black",
										strokeWidth: "1.5"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 733,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("line", {
										x1: "12",
										y1: "2",
										x2: "12",
										y2: "22",
										stroke: "black",
										strokeWidth: "1",
										strokeDasharray: "1,1"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 734,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 732,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Tablero / Panel" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 736,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 731,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									width: "24",
									height: "24",
									className: "overflow-visible shrink-0",
									children: [/* @__PURE__ */ _jsxDEV("circle", {
										cx: "12",
										cy: "7",
										r: "8",
										fill: "none",
										stroke: "black",
										strokeWidth: "1.5"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 740,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("circle", {
										cx: "12",
										cy: "17",
										r: "8",
										fill: "none",
										stroke: "black",
										strokeWidth: "1.5"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 741,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 739,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Transformador" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 743,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 738,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									width: "24",
									height: "24",
									className: "overflow-visible shrink-0",
									children: [/* @__PURE__ */ _jsxDEV("circle", {
										cx: "12",
										cy: "12",
										r: "10",
										fill: "none",
										stroke: "black",
										strokeWidth: "1.5"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 747,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("text", {
										x: "12",
										y: "15",
										textAnchor: "middle",
										fontSize: "10",
										fontWeight: "bold",
										children: "G"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 748,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 746,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Generador" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 750,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 745,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									width: "24",
									height: "24",
									className: "overflow-visible shrink-0",
									children: [/* @__PURE__ */ _jsxDEV("rect", {
										x: "2",
										y: "5",
										width: "20",
										height: "14",
										fill: "none",
										stroke: "black",
										strokeWidth: "1.5"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 754,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("text", {
										x: "12",
										y: "15",
										textAnchor: "middle",
										fontSize: "7",
										fontWeight: "bold",
										children: "ATS"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 755,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 753,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Transfer (ATS)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 757,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 752,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									width: "24",
									height: "24",
									className: "overflow-visible shrink-0",
									children: [
										/* @__PURE__ */ _jsxDEV("circle", {
											cx: "12",
											cy: "12",
											r: "9",
											fill: "none",
											stroke: "black",
											strokeWidth: "1.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 761,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("line", {
											x1: "9",
											y1: "8",
											x2: "9",
											y2: "16",
											stroke: "black",
											strokeWidth: "1.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 762,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("line", {
											x1: "15",
											y1: "8",
											x2: "15",
											y2: "16",
											stroke: "black",
											strokeWidth: "1.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 763,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 760,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Banco Condens." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 765,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 759,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									width: "24",
									height: "24",
									className: "overflow-visible shrink-0",
									children: [
										/* @__PURE__ */ _jsxDEV("line", {
											x1: "12",
											y1: "2",
											x2: "12",
											y2: "14",
											stroke: "black",
											strokeWidth: "1.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 769,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("line", {
											x1: "4",
											y1: "14",
											x2: "20",
											y2: "14",
											stroke: "black",
											strokeWidth: "1.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 770,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("line", {
											x1: "8",
											y1: "18",
											x2: "16",
											y2: "18",
											stroke: "black",
											strokeWidth: "1.5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 771,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 768,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Puesta a Tierra" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 773,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 767,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 730,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 728,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "border border-black p-3 rounded bg-white flex flex-col justify-between space-y-1",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border-b border-black pb-1 mb-1.5 flex justify-between items-center",
							children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "font-black text-xs",
								children: "Datos del Plano"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 782,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[8px] bg-black text-white px-1.5 py-0.5 rounded font-sans",
								children: "CAD"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 783,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 781,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "truncate",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", {
									className: "text-slate-600",
									children: "Empresa:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 785,
									columnNumber: 39
								}, this),
								" ",
								companyName
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 785,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "truncate",
							children: [
								/* @__PURE__ */ _jsxDEV("strong", {
									className: "text-slate-600",
									children: "Proyecto:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 786,
									columnNumber: 39
								}, this),
								" ",
								projectName
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 786,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "truncate",
							children: [/* @__PURE__ */ _jsxDEV("strong", {
								className: "text-slate-600",
								children: "Contenido:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 787,
								columnNumber: 39
							}, this), " Diagrama Unifilar"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 787,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 780,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "border-t border-black/30 pt-1.5 text-[8px] flex justify-between items-center text-slate-600 font-sans",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Fecha: ", new Date().toLocaleDateString("es-ES")] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 791,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "font-mono text-black font-bold text-[9px] border border-black px-1",
							children: "PLANO N° IE-01"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 792,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 790,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 779,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 725,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 440,
		columnNumber: 5
	}, this);
}
_s(DiagramaUnifilarBlueprint, "XzBKiLh0FIC1zaiXY6Ji+7RzPzw=", false, function() {
	return [useStore];
});
_c = DiagramaUnifilarBlueprint;
var _c;
$RefreshReg$(_c, "DiagramaUnifilarBlueprint");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/DiagramaUnifilarBlueprint.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/DiagramaUnifilarBlueprint.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/DiagramaUnifilarBlueprint.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/DiagramaUnifilarBlueprint.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsU0FBUyxRQUFRLGlCQUFpQjtBQUM1RCxTQUFTLFFBQVEsU0FBUyxXQUFXLGFBQWE7QUFDbEQsT0FBTyxjQUFjOzs7O0FBRXJCLGVBQWUsU0FBUywwQkFBMEIsRUFDaEQsWUFBWSxDQUFDLEdBQ2IsY0FBYyxXQUNkLGNBQWMsWUFDZCxjQUFjLE9BQ2QsaUJBQWlCLE1BQ2pCLGVBQWUsUUFDZDs7Q0FDRCxNQUFNLGVBQWUsT0FBTyxJQUFJO0NBQ2hDLE1BQU0sRUFBRSwyQkFBMkIsU0FBUztDQUU1QyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsQ0FBQztDQUNsQyxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQVM7RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFLENBQUM7Q0FDN0MsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVM7RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFLENBQUM7O0NBR3ZELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsSUFBSTtDQUM3RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTO0VBQUUsR0FBRztFQUFHLEdBQUc7Q0FBRSxDQUFDO0NBQ25FLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVM7RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFLENBQUM7Q0FDdkUsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxDQUFDLENBQUM7O0NBRzdELE1BQU0sRUFBRSxPQUFPLFFBQVEsaUJBQWlCLE9BQU8sbUJBQW1CLGNBQWM7RUFDOUUsSUFBSSxDQUFDLGFBQWEsVUFBVSxXQUFXLEdBQUc7R0FDeEMsT0FBTztJQUFFLE9BQU8sQ0FBQztJQUFHLFFBQVEsQ0FBQztJQUFHLGlCQUFpQjtJQUFHLE9BQU87SUFBRyxnQkFBZ0IsQ0FBQztHQUFFO0VBQ25GO0VBRUEsTUFBTSxnQkFBZ0IsSUFBSSxJQUFJO0VBQzlCLE1BQU0sY0FBYyxJQUFJLElBQUk7RUFFNUIsVUFBVSxTQUFTLE9BQU87R0FDeEIsSUFBSSxHQUFHLFFBQVE7SUFDYixjQUFjLElBQUksR0FBRyxPQUFPLFlBQVksQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO0dBQ3REO0dBQ0EsSUFBSSxHQUFHLElBQUk7SUFDVCxZQUFZLElBQUksR0FBRyxHQUFHLFlBQVksQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO0lBQzlDLGNBQWMsSUFBSSxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7R0FDbEQ7RUFDRixDQUFDOztFQUdELE1BQU0scUJBQXFCLFNBQVM7R0FDbEMsSUFBSSxDQUFDLFFBQVEsT0FBTyxTQUFTLFVBQVUsT0FBTztHQUM5QyxNQUFNLFFBQVEsS0FBSyxNQUFNLCtCQUErQjtHQUN4RCxPQUFPLFFBQVEsTUFBTSxFQUFFLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxJQUFJO0VBQ2pEOztFQUdBLE1BQU0sa0JBQWtCLElBQUksSUFBSTtFQUNoQyxVQUFVLFNBQVMsYUFBYTtHQUM5QixNQUFNLFdBQVcsU0FBUyxZQUFZLFNBQVMsZUFBZSxZQUFZLENBQUM7R0FDM0UsSUFBSSxNQUFNLFFBQVEsUUFBUSxHQUFHO0lBQzNCLFNBQVMsU0FBUyxNQUFNO0tBQ3RCLE1BQU0sU0FBUyxFQUFFLHFCQUFxQixFQUFFLGVBQWUsa0JBQWtCLEVBQUUsTUFBTTtLQUNqRixJQUFJLFFBQVE7TUFDVixnQkFBZ0IsSUFBSSxPQUFPLFlBQVksQ0FBQyxDQUFDLEtBQUssR0FBRyxTQUFTLEVBQUU7S0FDOUQ7S0FDQSxJQUFJLEVBQUUsVUFBVSxPQUFPLEVBQUUsV0FBVyxVQUFVO01BQzVDLE1BQU0sY0FBYyxFQUFFLE9BQU8sWUFBWSxDQUFDLENBQUMsS0FBSztNQUNoRCxNQUFNLGVBQWUsY0FBYyxJQUFJLFdBQVc7TUFDbEQsSUFBSSxjQUFjO09BQ2hCLGdCQUFnQixJQUFJLGFBQWEsR0FBRyxZQUFZLENBQUMsQ0FBQyxLQUFLLEdBQUcsU0FBUyxFQUFFO01BQ3ZFO0tBQ0Y7SUFDRixDQUFDO0dBQ0g7RUFDRixDQUFDO0VBRUQsTUFBTSxxQkFBcUIsQ0FBQztFQUU1QixNQUFNLGlCQUFpQixVQUFVLEtBQUssT0FBTztHQUMzQyxNQUFNLEtBQUssT0FBTyxHQUFHLGtCQUFrQixXQUNuQyxLQUFLLE1BQU0sR0FBRyxpQkFBaUIsSUFBSSxJQUNsQyxHQUFHLGlCQUFpQixDQUFDOztHQUcxQixJQUFJLG1CQUFtQjs7R0FHdkIsSUFBSSxHQUFHLG1CQUFtQixZQUFZLElBQUksR0FBRyxnQkFBZ0IsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUc7SUFDbEYsbUJBQW1CLFlBQVksSUFBSSxHQUFHLGdCQUFnQixZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0dBQzlFLE9BQU8sSUFBSSxHQUFHLFlBQVksWUFBWSxJQUFJLEdBQUcsU0FBUyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRztJQUMzRSxtQkFBbUIsWUFBWSxJQUFJLEdBQUcsU0FBUyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0dBQ3ZFOztHQUdBLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxlQUFlO0lBQ3pDLE1BQU0sYUFBYSxrQkFBa0IsR0FBRyxhQUFhO0lBQ3JELElBQUksY0FBYyxZQUFZLElBQUksVUFBVSxHQUFHO0tBQzdDLG1CQUFtQixZQUFZLElBQUksVUFBVSxDQUFDLENBQUM7SUFDakQsT0FBTztLQUNMLE1BQU0sWUFBWSxHQUFHLGNBQWMsWUFBWSxDQUFDLENBQUMsS0FBSztLQUN0RCxNQUFNLGVBQWUsY0FBYyxJQUFJLFNBQVM7S0FDaEQsSUFBSSxjQUFjO01BQ2hCLG1CQUFtQixhQUFhO0tBQ2xDO0lBQ0Y7R0FDRjs7R0FHQSxNQUFNLGFBQWEsR0FBRyxpQkFBaUIsY0FBYyxHQUFHLFNBQVM7R0FDakUsSUFBSSxZQUFZO0lBQ2QsTUFBTSxlQUFlLEdBQUcsc0JBQXNCLEdBQUcsa0JBQWtCLEdBQUc7SUFDdEUsSUFBSSxjQUFjO0tBQ2hCLE1BQU0sYUFBYSxrQkFBa0IsWUFBWTtLQUNqRCxJQUFJLGNBQWMsWUFBWSxJQUFJLFVBQVUsR0FBRztNQUM3QyxtQkFBbUIsWUFBWSxJQUFJLFVBQVUsQ0FBQyxDQUFDO0tBQ2pELE9BQU87TUFDTCxNQUFNLGFBQWEsY0FBYyxJQUFJLE9BQU8sWUFBWSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDO01BQzlFLElBQUksWUFBWSxtQkFBbUIsV0FBVztLQUNoRDtJQUNGOztJQUdBLE1BQU0sbUJBQW1CLEdBQUcsMEJBQTBCLEdBQUcsc0JBQXNCLEdBQUcsZUFBZSxHQUFHO0lBQ3BHLElBQUksVUFBVTtJQUNkLElBQUksa0JBQWtCO0tBQ3BCLE1BQU0sY0FBYyxrQkFBa0IsZ0JBQWdCO0tBQ3RELElBQUksZUFBZSxZQUFZLElBQUksV0FBVyxHQUFHO01BQy9DLFVBQVUsWUFBWSxJQUFJLFdBQVc7S0FDdkMsT0FBTztNQUNMLFVBQVUsY0FBYyxJQUFJLE9BQU8sZ0JBQWdCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUM7S0FDM0U7SUFDRjs7SUFHQSxJQUFJLENBQUMsU0FBUztLQUNaLFVBQVUsVUFBVSxNQUFLLE9BQU0sRUFBRSxpQkFBaUIsZUFBZSxFQUFFLFNBQVMsZ0JBQWdCLEVBQUUsT0FBTyxHQUFHLEVBQUU7SUFDNUc7SUFFQSxJQUFJLFdBQVcsUUFBUSxPQUFPLEdBQUcsSUFBSTtLQUNuQyxtQkFBbUIsS0FBSztNQUN0QixJQUFJLFNBQVMsUUFBUSxHQUFHLEdBQUcsR0FBRztNQUM5QixVQUFVLFFBQVE7TUFDbEIsVUFBVSxHQUFHO01BQ2IsT0FBTztLQUNULENBQUM7SUFDSDtHQUNGOztHQUdBLElBQUksQ0FBQyxvQkFBb0IsZ0JBQWdCLElBQUksR0FBRyxHQUFHLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHO0lBQ3hFLG1CQUFtQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDO0dBQ25FOztHQUdBLElBQUkscUJBQXFCLEdBQUcsSUFBSTtJQUM5QixtQkFBbUI7R0FDckI7R0FFQSxPQUFPO0lBQ0wsR0FBRztJQUNILGVBQWU7SUFDZixVQUFVO0lBQ1YsVUFBVSxDQUFDO0dBQ2I7RUFDRixDQUFDO0VBRUQsTUFBTSxVQUFVLElBQUksSUFBSSxlQUFlLEtBQUksTUFBSyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUMxRCxNQUFNLFFBQVEsQ0FBQztFQUVmLGVBQWUsU0FBUyxTQUFTO0dBQy9CLElBQUksS0FBSyxZQUFZLFFBQVEsSUFBSSxLQUFLLFFBQVEsR0FBRztJQUMvQyxRQUFRLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxTQUFTLEtBQUssS0FBSyxFQUFFO0dBQ2xELE9BQU87SUFDTCxNQUFNLEtBQUssS0FBSyxFQUFFO0dBQ3BCO0VBQ0YsQ0FBQztFQUVELE1BQU0sWUFBWSxDQUFDO0VBQ25CLE1BQU0sYUFBYSxDQUFDO0VBQ3BCLE1BQU0sUUFBUSxNQUFNLEtBQUksUUFBTztHQUFFO0dBQUksT0FBTztFQUFFLEVBQUU7RUFFaEQsT0FBTyxNQUFNLFNBQVMsR0FBRztHQUN2QixNQUFNLEVBQUUsSUFBSSxVQUFVLE1BQU0sTUFBTTtHQUNsQyxNQUFNLE9BQU8sUUFBUSxJQUFJLEVBQUU7R0FDM0IsSUFBSSxDQUFDLE1BQU07R0FFWCxXQUFXLE1BQU07R0FDakIsSUFBSSxDQUFDLFVBQVUsUUFBUSxVQUFVLFNBQVMsQ0FBQztHQUMzQyxVQUFVLE1BQU0sQ0FBQyxLQUFLLEVBQUU7R0FFeEIsS0FBSyxTQUFTLFNBQVEsWUFBVztJQUMvQixNQUFNLEtBQUs7S0FBRSxJQUFJO0tBQVMsT0FBTyxRQUFRO0lBQUUsQ0FBQztHQUM5QyxDQUFDO0VBQ0g7RUFFQSxNQUFNLGFBQWEsZUFBZSxLQUFJLE9BQU07R0FDMUMsR0FBRztHQUNILE9BQU8sV0FBVyxFQUFFLFFBQVEsWUFBWSxXQUFXLEVBQUUsTUFBTTtFQUM3RCxFQUFFO0VBRUYsSUFBSSxXQUFXO0VBQ2YsT0FBTyxLQUFLLFNBQVMsQ0FBQyxDQUFDLFNBQVEsUUFBTztHQUNwQyxXQUFXLEtBQUssSUFBSSxVQUFVLFVBQVUsSUFBSSxDQUFDLE1BQU07RUFDckQsQ0FBQztFQUVELE9BQU87R0FDTCxPQUFPO0dBQ1AsUUFBUTtHQUNSLGlCQUFpQjtHQUNqQixPQUFPLE9BQU8sS0FBSyxTQUFTLENBQUMsQ0FBQztHQUM5QixnQkFBZ0I7RUFDbEI7Q0FDRixHQUFHLENBQUMsU0FBUyxDQUFDOztDQUdkLE1BQU0sUUFBUSxLQUFLLElBQUksTUFBTSxrQkFBa0IsTUFBTSxHQUFHO0NBQ3hELE1BQU0sU0FBUyxLQUFLLElBQUksTUFBTSxRQUFRLE1BQU0sR0FBRzs7Q0FHL0MsTUFBTSxtQkFBbUIsY0FBYztFQUNyQyxNQUFNLFNBQVMsQ0FBQztFQUNoQixPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsU0FBUyxXQUFXO0dBQ3RDLE1BQU0sTUFBTSxTQUFTLFFBQVEsRUFBRTtHQUMvQixNQUFNLFdBQVcsT0FBTztHQUN4QixNQUFNLFFBQVEsU0FBUztHQUN2QixNQUFNLElBQUksTUFBTSxNQUFNO0dBRXRCLFNBQVMsU0FBUyxJQUFJLFFBQVE7SUFDNUIsTUFBTSxLQUFLLE1BQU0sT0FBUSxRQUFRO0lBQ2pDLE9BQU8sTUFBTTtLQUFFO0tBQUc7SUFBRTtHQUN0QixDQUFDO0VBQ0gsQ0FBQztFQUNELE9BQU87Q0FDVCxHQUFHLENBQUMsUUFBUSxLQUFLLENBQUM7O0NBR2xCLE1BQU0saUJBQWlCLFdBQVc7RUFDaEMsSUFBSSxrQkFBa0IsU0FBUztHQUM3QixPQUFPLGtCQUFrQjtFQUMzQjtFQUNBLE1BQU0sT0FBTyxNQUFNLE1BQUssTUFBSyxFQUFFLE9BQU8sTUFBTTtFQUM1QyxJQUFJLFFBQVEsS0FBSyxlQUFlLGNBQWMsYUFBYSxLQUFLLGVBQWUsY0FBYyxXQUFXO0dBQ3RHLE9BQU87SUFDTCxHQUFHLFdBQVcsS0FBSyxjQUFjLFNBQVM7SUFDMUMsR0FBRyxXQUFXLEtBQUssY0FBYyxTQUFTO0dBQzVDO0VBQ0Y7RUFDQSxPQUFPLGlCQUFpQixXQUFXO0dBQUUsR0FBRztHQUFLLEdBQUc7RUFBSTtDQUN0RDs7Q0FHQSxNQUFNLHlCQUF5QixNQUFNO0VBQ25DLElBQUksQ0FBQyxhQUFhO0VBQ2xCLElBQUksRUFBRSxXQUFXLEdBQUc7RUFDcEIsSUFBSSxFQUFFLE9BQU8sUUFBUSxlQUFlLEdBQUc7RUFFdkMsYUFBYSxJQUFJO0VBQ2pCLFlBQVk7R0FBRSxHQUFHLEVBQUUsVUFBVSxJQUFJO0dBQUcsR0FBRyxFQUFFLFVBQVUsSUFBSTtFQUFFLENBQUM7Q0FDNUQ7Q0FFQSxNQUFNLHlCQUF5QixNQUFNO0VBQ25DLElBQUksZUFBZSxXQUFXO0dBQzVCLE9BQU87SUFDTCxHQUFHLEVBQUUsVUFBVSxTQUFTO0lBQ3hCLEdBQUcsRUFBRSxVQUFVLFNBQVM7R0FDMUIsQ0FBQztFQUNIOztFQUdBLElBQUksZUFBZSxrQkFBa0I7R0FDbkMsTUFBTSxVQUFVLEVBQUUsVUFBVSxlQUFlLEtBQUs7R0FDaEQsTUFBTSxVQUFVLEVBQUUsVUFBVSxlQUFlLEtBQUs7R0FFaEQsc0JBQXFCLFVBQVM7SUFDNUIsR0FBRztLQUNGLG1CQUFtQjtLQUNsQixHQUFHLGlCQUFpQixJQUFJO0tBQ3hCLEdBQUcsaUJBQWlCLElBQUk7SUFDMUI7R0FDRixFQUFFO0VBQ0o7Q0FDRjtDQUVBLE1BQU0sNEJBQTRCO0VBQ2hDLGFBQWEsS0FBSzs7RUFHbEIsSUFBSSxrQkFBa0I7R0FDcEIsTUFBTSxXQUFXLGtCQUFrQjtHQUNuQyxJQUFJLFVBQVU7O0lBRVosTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTLElBQUksRUFBRSxJQUFJO0lBQy9DLE1BQU0sV0FBVyxLQUFLLE1BQU0sU0FBUyxJQUFJLEVBQUUsSUFBSTtJQUUvQyxNQUFNLE9BQU8sTUFBTSxNQUFLLE1BQUssRUFBRSxPQUFPLGdCQUFnQjtJQUN0RCxJQUFJLE1BQU07S0FDUix1QkFBdUIsS0FBSyxZQUFZLGtCQUFrQixFQUN4RCxlQUFlO01BQ2IsR0FBRyxLQUFLO01BQ1IsV0FBVztNQUNYLFdBQVc7S0FDYixFQUNGLENBQUM7SUFDSDtHQUNGO0dBQ0Esb0JBQW9CLElBQUk7RUFDMUI7Q0FDRjs7Q0FHQSxNQUFNLG9CQUFvQixNQUFNO0VBQzlCLElBQUksQ0FBQyxhQUFhO0VBQ2xCLE1BQU0sUUFBUSxFQUFFLFFBQVE7RUFDeEIsSUFBSSxFQUFFLE9BQU8sUUFBUSxlQUFlLEdBQUc7R0FDckMsTUFBTSxTQUFTLEVBQUUsT0FBTyxRQUFRLGVBQWU7R0FDL0MsTUFBTSxTQUFTLE9BQU8sUUFBUTtHQUM5QixNQUFNLFdBQVcsY0FBYyxNQUFNO0dBRXJDLG9CQUFvQixNQUFNO0dBQzFCLGtCQUFrQjtJQUFFLEdBQUcsTUFBTTtJQUFTLEdBQUcsTUFBTTtHQUFRLENBQUM7R0FDeEQsb0JBQW9CLFFBQVE7RUFDOUIsT0FBTztHQUNMLGFBQWEsSUFBSTtHQUNqQixZQUFZO0lBQUUsR0FBRyxNQUFNLFVBQVUsSUFBSTtJQUFHLEdBQUcsTUFBTSxVQUFVLElBQUk7R0FBRSxDQUFDO0VBQ3BFO0NBQ0Y7Q0FFQSxNQUFNLG1CQUFtQixNQUFNO0VBQzdCLElBQUksQ0FBQyxhQUFhO0VBQ2xCLE1BQU0sUUFBUSxFQUFFLFFBQVE7RUFFeEIsSUFBSSxrQkFBa0I7R0FDcEIsTUFBTSxVQUFVLE1BQU0sVUFBVSxlQUFlLEtBQUs7R0FDcEQsTUFBTSxVQUFVLE1BQU0sVUFBVSxlQUFlLEtBQUs7R0FDcEQsc0JBQXFCLFVBQVM7SUFDNUIsR0FBRztLQUNGLG1CQUFtQjtLQUNsQixHQUFHLGlCQUFpQixJQUFJO0tBQ3hCLEdBQUcsaUJBQWlCLElBQUk7SUFDMUI7R0FDRixFQUFFO0VBQ0osT0FBTyxJQUFJLFdBQVc7R0FDcEIsT0FBTztJQUNMLEdBQUcsTUFBTSxVQUFVLFNBQVM7SUFDNUIsR0FBRyxNQUFNLFVBQVUsU0FBUztHQUM5QixDQUFDO0VBQ0g7Q0FDRjs7Q0FHQSxNQUFNLGVBQWUsTUFBTTtFQUN6QixJQUFJLENBQUMsYUFBYTtFQUNsQixFQUFFLGVBQWU7RUFDakIsTUFBTSxjQUFjO0VBQ3BCLElBQUksRUFBRSxTQUFTLEdBQUc7R0FDaEIsU0FBUSxTQUFRLEtBQUssSUFBSSxHQUFHLE9BQU8sV0FBVyxDQUFDO0VBQ2pELE9BQU87R0FDTCxTQUFRLFNBQVEsS0FBSyxJQUFJLElBQUssT0FBTyxXQUFXLENBQUM7RUFDbkQ7Q0FDRjtDQUVBLE1BQU0sa0JBQWtCO0VBQ3RCLFFBQVEsQ0FBQztFQUNULE9BQU87R0FBRSxHQUFHO0dBQUcsR0FBRztFQUFFLENBQUM7RUFDckIscUJBQXFCLENBQUMsQ0FBQztDQUN6Qjs7Q0FHQSxNQUFNLG9CQUFvQixNQUFNLFlBQVk7RUFDMUMsTUFBTSxjQUFjLFVBQVUsWUFBWTtFQUMxQyxNQUFNLGFBQWEsVUFBVSxZQUFZO0VBQ3pDLE1BQU0sZ0JBQWdCLFVBQVUsWUFBWTtFQUM1QyxNQUFNLGlCQUFpQixVQUFVLFlBQVk7RUFDN0MsTUFBTSxXQUFXLFVBQVUsWUFBWTtFQUN2QyxNQUFNLGFBQWEsVUFBVSxTQUFTO0VBRXRDLFFBQVEsTUFBUjtHQUNFLEtBQUssYUFDSCxPQUNFLHdCQUFDLEtBQUQsYUFDRSx3QkFBQyxVQUFEO0lBQVEsSUFBRztJQUFJLElBQUc7SUFBSSxHQUFFO0lBQUssTUFBTSxjQUFjO0lBQVcsUUFBUTtJQUFhLGFBQVk7R0FBTzs7OzthQUNwRyx3QkFBQyxRQUFEO0lBQU0sR0FBRTtJQUFJLEdBQUU7SUFBSSxZQUFXO0lBQVMsTUFBTTtJQUFhLFdBQVU7Y0FBK0I7R0FBTzs7OztXQUN4Rzs7Ozs7R0FFUCxLQUFLLGlCQUNILE9BQ0Usd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYixDQUNFLHdCQUFDLFVBQUQ7S0FBUSxJQUFHO0tBQUksSUFBRztLQUFLLEdBQUU7S0FBSyxNQUFLO0tBQU8sUUFBUTtLQUFZLGFBQVk7SUFBTzs7OztjQUNqRix3QkFBQyxVQUFEO0tBQVEsSUFBRztLQUFJLElBQUc7S0FBSSxHQUFFO0tBQUssTUFBSztLQUFPLFFBQVE7S0FBWSxhQUFZO0lBQU87Ozs7WUFDL0U7Ozs7OztHQUVQLEtBQUssWUFDSCxPQUNFLHdCQUFDLEtBQUQsYUFDRSx3QkFBQyxRQUFEO0lBQU0sR0FBRTtJQUFNLEdBQUU7SUFBTSxPQUFNO0lBQUssUUFBTztJQUFLLElBQUc7SUFBSSxNQUFNLGNBQWM7SUFBVyxRQUFRO0lBQWUsYUFBWTtHQUFPOzs7O2FBQzdILHdCQUFDLFFBQUQ7SUFBTSxHQUFFO0lBQUksR0FBRTtJQUFJLFlBQVc7SUFBUyxNQUFNO0lBQWUsV0FBVTtjQUFrQztHQUFTOzs7O1dBQy9HOzs7OztHQUVQLEtBQUssaUJBQ0gsT0FDRSx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFiO0tBQ0Usd0JBQUMsUUFBRDtNQUFNLElBQUc7TUFBSSxJQUFHO01BQU0sSUFBRztNQUFJLElBQUc7TUFBSSxRQUFRO01BQWUsYUFBWTtLQUFPOzs7OztLQUM5RSx3QkFBQyxRQUFEO01BQU0sSUFBRztNQUFNLElBQUc7TUFBSSxJQUFHO01BQUssSUFBRztNQUFJLFFBQVE7TUFBZSxhQUFZO0tBQU87Ozs7O0tBQy9FLHdCQUFDLFFBQUQ7TUFBTSxJQUFHO01BQUssSUFBRztNQUFLLElBQUc7TUFBSSxJQUFHO01BQUssUUFBUTtNQUFlLGFBQVk7S0FBSzs7Ozs7S0FDN0Usd0JBQUMsUUFBRDtNQUFNLElBQUc7TUFBSyxJQUFHO01BQUssSUFBRztNQUFJLElBQUc7TUFBSyxRQUFRO01BQWUsYUFBWTtLQUFPOzs7OztJQUM5RTs7Ozs7O0dBRVAsS0FBSyxlQUNILE9BQ0Usd0JBQUMsS0FBRCxhQUNFLHdCQUFDLFdBQUQ7SUFBUyxRQUFPO0lBQWtDLE1BQU0sY0FBYztJQUFXLFFBQVE7SUFBVSxhQUFZO0dBQU87Ozs7YUFDdEgsd0JBQUMsUUFBRDtJQUFNLEdBQUU7SUFBSyxHQUFFO0lBQUssT0FBTTtJQUFLLFFBQU87SUFBSyxNQUFLO0lBQU8sUUFBUTtJQUFVLGFBQVk7R0FBTzs7OztXQUMzRjs7Ozs7R0FFUCxLQUFLO0dBQ0wsS0FBSyxRQUNILE9BQ0Usd0JBQUMsS0FBRDtJQUNFLHdCQUFDLFVBQUQ7S0FBUSxJQUFHO0tBQUksSUFBRztLQUFJLEdBQUU7S0FBSyxNQUFNLGNBQWM7S0FBVyxRQUFRO0tBQWdCLGFBQVk7SUFBTzs7Ozs7SUFDdkcsd0JBQUMsUUFBRDtLQUFNLElBQUc7S0FBSyxJQUFHO0tBQUssSUFBRztLQUFLLElBQUc7S0FBSSxRQUFRO0tBQWdCLGFBQVk7SUFBSzs7Ozs7SUFDOUUsd0JBQUMsUUFBRDtLQUFNLElBQUc7S0FBSSxJQUFHO0tBQUssSUFBRztLQUFJLElBQUc7S0FBSSxRQUFRO0tBQWdCLGFBQVk7SUFBSzs7Ozs7SUFDNUUsd0JBQUMsUUFBRDtLQUFNLElBQUc7S0FBTSxJQUFHO0tBQUksSUFBRztLQUFLLElBQUc7S0FBSSxRQUFRO0tBQWdCLGFBQVk7SUFBTzs7Ozs7SUFDaEYsd0JBQUMsUUFBRDtLQUFNLElBQUc7S0FBSSxJQUFHO0tBQUksSUFBRztLQUFLLElBQUc7S0FBSSxRQUFRO0tBQWdCLGFBQVk7SUFBTzs7Ozs7R0FDN0U7Ozs7O0dBRVAsS0FBSztHQUNMLFNBQ0UsT0FDRSx3QkFBQyxLQUFEO0lBQ0Usd0JBQUMsUUFBRDtLQUFNLEdBQUU7S0FBTSxHQUFFO0tBQU0sT0FBTTtLQUFLLFFBQU87S0FBSyxJQUFHO0tBQUksTUFBTSxjQUFjO0tBQVcsUUFBUSxVQUFVLFlBQVk7S0FBVyxhQUFZO0lBQU87Ozs7O0lBQy9JLHdCQUFDLFFBQUQ7S0FBTSxJQUFHO0tBQUksSUFBRztLQUFNLElBQUc7S0FBSSxJQUFHO0tBQUssUUFBUSxVQUFVLFlBQVk7S0FBVyxhQUFZO0tBQUksaUJBQWdCO0lBQU87Ozs7O0lBQ3JILHdCQUFDLFFBQUQ7S0FBTSxHQUFFO0tBQU0sR0FBRTtLQUFNLE9BQU07S0FBSSxRQUFPO0tBQUksTUFBTSxVQUFVLFlBQVk7SUFBWTs7Ozs7SUFDbkYsd0JBQUMsUUFBRDtLQUFNLEdBQUU7S0FBSyxHQUFFO0tBQUssT0FBTTtLQUFJLFFBQU87S0FBSSxNQUFNLFVBQVUsWUFBWTtJQUFZOzs7OztJQUNqRix3QkFBQyxRQUFEO0tBQU0sR0FBRTtLQUFNLEdBQUU7S0FBSSxPQUFNO0tBQUksUUFBTztLQUFJLE1BQU0sVUFBVSxZQUFZO0lBQVk7Ozs7O0dBQ2hGOzs7OztFQUVUO0NBQ0Y7Q0FFQSxNQUFNLGNBQWM7Q0FFcEIsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsV0FBVyxzQkFDVCxjQUNJLHFEQUNBO1lBSlI7R0FRRyxlQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUEyRTtJQUVyRjs7OztjQUNOLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSxTQUFRLFNBQVEsS0FBSyxJQUFJLElBQUssT0FBTyxHQUFJLENBQUM7T0FDekQsV0FBVTtPQUNWLE9BQU07aUJBRU4sd0JBQUMsU0FBRCxFQUFTLFdBQVUsY0FBZTs7Ozs7TUFDNUI7Ozs7O01BQ1Isd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0csS0FBSyxNQUFNLE9BQU8sR0FBRyxHQUFFLEdBQ3BCOzs7Ozs7TUFDTix3QkFBQyxVQUFEO09BQ0UsZUFBZSxTQUFRLFNBQVEsS0FBSyxJQUFJLEdBQUcsT0FBTyxHQUFJLENBQUM7T0FDdkQsV0FBVTtPQUNWLE9BQU07aUJBRU4sd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7Ozs7TUFDM0I7Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxXQUFVO09BQ1YsT0FBTTtpQkFFTix3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7OztNQUM5Qjs7Ozs7S0FDTDs7Ozs7WUFDRjs7Ozs7O0dBSVAsd0JBQUMsT0FBRDtJQUNFLEtBQUs7SUFDTCxhQUFhO0lBQ2IsYUFBYTtJQUNiLFdBQVc7SUFDWCxjQUFjO0lBQ2QsY0FBYztJQUNkLGFBQWE7SUFDYixZQUFZO0lBQ1osU0FBUztJQUNULGVBQWU7SUFDZixXQUFXLG9FQUNULGNBQWMsdURBQXVEO2NBR3RFLE1BQU0sV0FBVyxJQUNoQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFtRDtJQUU3RDs7OztlQUVMLHdCQUFDLE9BQUQ7S0FDRSxPQUFPLGNBQWM7TUFDbkIsV0FBVyxhQUFhLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxZQUFZLEtBQUs7TUFDM0QsaUJBQWlCO01BQ2pCLFlBQVksb0JBQW9CLFlBQVksU0FBUztLQUN2RCxJQUFJO01BQ0YsT0FBTztNQUNQLFFBQVE7S0FDVjtLQUNBLFdBQVU7ZUFFVix3QkFBQyxPQUFEO01BQ0UsU0FBUyxPQUFPLE1BQU0sR0FBRztNQUN6QixPQUFPLGNBQWMsUUFBUTtNQUM3QixRQUFRLGNBQWMsU0FBUztNQUMvQixXQUFVO2dCQUpaO09BT0Usd0JBQUMsUUFBRDtRQUVHLGVBQ0Msd0JBQUMsV0FBRDtTQUFTLElBQUc7U0FBVyxPQUFNO1NBQUssUUFBTztTQUFLLGNBQWE7bUJBQTNEO1VBQ0Usd0JBQUMsVUFBRDtXQUFRLElBQUc7V0FBSyxJQUFHO1dBQUssR0FBRTtXQUFJLE1BQUs7VUFBVzs7Ozs7VUFDOUMsd0JBQUMsUUFBRDtXQUFNLElBQUc7V0FBSSxJQUFHO1dBQUksSUFBRztXQUFLLElBQUc7V0FBSSxRQUFPO1dBQVUsYUFBWTtVQUFPOzs7OztVQUN2RSx3QkFBQyxRQUFEO1dBQU0sSUFBRztXQUFJLElBQUc7V0FBSSxJQUFHO1dBQUksSUFBRztXQUFLLFFBQU87V0FBVSxhQUFZO1VBQU87Ozs7O1NBQ2hFOzs7Ozs7UUFJWCx3QkFBQyxVQUFEO1NBQ0UsSUFBRztTQUNILFNBQVE7U0FDUixNQUFLO1NBQ0wsTUFBSztTQUNMLGFBQVk7U0FDWixjQUFhO1NBQ2IsUUFBTzttQkFFUCx3QkFBQyxRQUFEO1VBQU0sR0FBRTtVQUEwQixNQUFLO1NBQVc7Ozs7O1FBQzVDOzs7OztRQUNSLHdCQUFDLFVBQUQ7U0FDRSxJQUFHO1NBQ0gsU0FBUTtTQUNSLE1BQUs7U0FDTCxNQUFLO1NBQ0wsYUFBWTtTQUNaLGNBQWE7U0FDYixRQUFPO21CQUVQLHdCQUFDLFFBQUQ7VUFBTSxHQUFFO1VBQTBCLE1BQUs7U0FBVzs7Ozs7UUFDNUM7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLElBQUc7U0FDSCxTQUFRO1NBQ1IsTUFBSztTQUNMLE1BQUs7U0FDTCxhQUFZO1NBQ1osY0FBYTtTQUNiLFFBQU87bUJBRVAsd0JBQUMsUUFBRDtVQUFNLEdBQUU7VUFBMEIsTUFBSztTQUFXOzs7OztRQUM1Qzs7Ozs7T0FDSjs7Ozs7T0FHTCxlQUNDLHdCQUFDLFFBQUQ7UUFBYTtRQUFlO1FBQVEsTUFBSztRQUFpQixJQUFHO09BQUs7Ozs7O09BSW5FLE1BQU0sS0FBSyxTQUFTO1FBQ25CLElBQUksQ0FBQyxLQUFLLFVBQVUsT0FBTztRQUMzQixNQUFNLGVBQWUsY0FBYyxLQUFLLFFBQVE7UUFDaEQsTUFBTSxjQUFjLGNBQWMsS0FBSyxFQUFFOztRQUd6QyxNQUFNLFFBQVEsYUFBYSxJQUFJLFlBQVksS0FBSztRQUNoRCxNQUFNLFdBQVcsS0FBSyxhQUFhLEVBQUUsR0FBRyxhQUFhLEVBQUUsS0FBSyxhQUFhLEVBQUUsR0FBRyxLQUFLLEtBQUssWUFBWSxFQUFFLEdBQUcsS0FBSyxLQUFLLFlBQVksRUFBRSxHQUFHLFlBQVk7UUFFaEosT0FDRSx3QkFBQyxLQUFELGFBQ0Usd0JBQUMsUUFBRDtTQUNFLEdBQUc7U0FDSCxNQUFLO1NBQ0wsUUFBTztTQUNQLGFBQVk7UUFDYjs7OztrQkFDRCx3QkFBQyxRQUFEO1NBQ0UsR0FBRztTQUNILE1BQUs7U0FDTCxRQUFRLGNBQWMsWUFBWTtTQUNsQyxhQUFhLGNBQWMsUUFBUTtTQUNuQyxXQUFXLGNBQWMsc0JBQXNCO1FBQ2hEOzs7O2dCQUNBLEtBZEssUUFBUSxLQUFLOzs7O2VBY2xCO09BRVAsQ0FBQztPQUdBLGVBQWUsS0FBSyxTQUFTO1FBQzVCLE1BQU0sWUFBWSxjQUFjLEtBQUssUUFBUTtRQUM3QyxNQUFNLFlBQVksY0FBYyxLQUFLLFFBQVE7O1FBRzdDLE1BQU0sUUFBUSxVQUFVLElBQUksVUFBVSxLQUFLO1FBQzNDLE1BQU0sUUFBUSxVQUFVLElBQUksVUFBVSxLQUFLO1FBQzNDLE1BQU0sV0FBVyxLQUFLLFVBQVUsRUFBRSxHQUFHLFVBQVUsRUFBRSxLQUFLLEtBQUssR0FBRyxVQUFVLEVBQUUsS0FBSyxLQUFLLEdBQUcsVUFBVSxFQUFFLEtBQUssVUFBVSxFQUFFLEdBQUcsVUFBVTtRQUVqSSxPQUNFLHdCQUFDLEtBQUQ7U0FFRSx3QkFBQyxRQUFEO1VBQ0UsR0FBRztVQUNILE1BQUs7VUFDTCxRQUFRLGNBQWMsWUFBWTtVQUNsQyxhQUFhLGNBQWMsUUFBUTtVQUNuQyxpQkFBZ0I7VUFDaEIsV0FBVTtTQUNYOzs7OztTQUVELHdCQUFDLFFBQUQ7VUFDRSxHQUFHLE9BQU87VUFDVixHQUFHLE9BQU87VUFDVixPQUFNO1VBQ04sUUFBTztVQUNQLElBQUc7VUFDSCxNQUFNLGNBQWMsWUFBWTtVQUNoQyxRQUFPO1VBQ1AsYUFBWTtTQUNiOzs7OztTQUNELHdCQUFDLFFBQUQ7VUFDRSxHQUFHO1VBQ0gsR0FBRyxPQUFPO1VBQ1YsWUFBVztVQUNYLFVBQVM7VUFDVCxZQUFXO1VBQ1gsTUFBSztVQUNMLFdBQVU7b0JBQ1g7U0FFSzs7Ozs7UUFDTCxLQWhDSyxLQUFLOzs7O2VBZ0NWO09BRVAsQ0FBQztPQUdBLE1BQU0sS0FBSyxTQUFTO1FBQ25CLE1BQU0sU0FBUyxjQUFjLEtBQUssRUFBRTtRQUNwQyxNQUFNLGFBQWEsbUJBQW1CLEtBQUs7UUFFM0MsT0FDRSx3QkFBQyxLQUFEO1NBRUUsV0FBVyxhQUFhLE9BQU8sRUFBRSxJQUFJLE9BQU8sRUFBRTtTQUM5QyxlQUFhLEtBQUs7U0FDbEIsV0FBVTtTQUNWLFVBQVUsTUFBTTtVQUNkLEVBQUUsZ0JBQWdCO1VBQ2xCLElBQUksY0FBYyxhQUFhLElBQUk7U0FDckM7U0FDQSxjQUFjLE1BQU07VUFDbEIsSUFBSSxDQUFDLGFBQWE7VUFDbEIsRUFBRSxnQkFBZ0I7VUFDbEIsb0JBQW9CLEtBQUssRUFBRTtVQUMzQixrQkFBa0I7V0FBRSxHQUFHLEVBQUU7V0FBUyxHQUFHLEVBQUU7VUFBUSxDQUFDO1VBQ2hELG9CQUFvQixNQUFNO1NBQzVCO21CQWZGO1VBa0JHLGVBQWUsY0FDZCx3QkFBQyxRQUFEO1dBQ0UsR0FBRTtXQUNGLEdBQUU7V0FDRixPQUFNO1dBQ04sUUFBTztXQUNQLElBQUc7V0FDSCxNQUFLO1dBQ0wsUUFBTztXQUNQLGFBQVk7V0FDWixpQkFBZ0I7V0FDaEIsV0FBVTtVQUNYOzs7OztVQUlGLGlCQUFpQixLQUFLLGNBQWMsQ0FBQyxXQUFXO1VBR2pELHdCQUFDLFFBQUQ7V0FDRSxHQUFFO1dBQ0YsR0FBRTtXQUNGLFlBQVc7V0FDWCxVQUFTO1dBQ1QsWUFBVztXQUNYLE1BQU0sY0FBZSxhQUFhLFlBQVksWUFBYTtXQUMzRCxXQUFVO3FCQUVULEtBQUssT0FBTyxTQUFTLEtBQUssR0FBRyxLQUFLLE9BQU8sTUFBTSxHQUFHLEVBQUUsRUFBRSxPQUFPLEtBQUs7VUFDL0Q7Ozs7O1VBR04sd0JBQUMsUUFBRDtXQUNFLEdBQUU7V0FDRixHQUFFO1dBQ0YsWUFBVztXQUNYLFVBQVM7V0FDVCxZQUFXO1dBQ1gsTUFBTSxjQUFjLFlBQVk7V0FDaEMsV0FBVTtxQkFFVCxLQUFLO1VBQ0Y7Ozs7O1NBQ0w7V0E1REksS0FBSzs7OztlQTREVDtPQUVQLENBQUM7TUFDRTs7Ozs7O0lBQ0Y7Ozs7O0dBRUo7Ozs7O0dBR0osQ0FBQyxlQUNBLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FHRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXFEO0tBQW9COzs7O2VBQ3ZGLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssT0FBTTtTQUFLLFFBQU87U0FBSyxXQUFVO21CQUF0QyxDQUNFLHdCQUFDLFFBQUQ7VUFBTSxHQUFFO1VBQUksR0FBRTtVQUFJLE9BQU07VUFBSyxRQUFPO1VBQUssTUFBSztVQUFPLFFBQU87VUFBUSxhQUFZO1NBQU87Ozs7bUJBQ3ZGLHdCQUFDLFFBQUQ7VUFBTSxJQUFHO1VBQUssSUFBRztVQUFJLElBQUc7VUFBSyxJQUFHO1VBQUssUUFBTztVQUFRLGFBQVk7VUFBSSxpQkFBZ0I7U0FBTzs7OztpQkFDeEY7Ozs7O2tCQUNMLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7Z0JBQ3hCOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxPQUFNO1NBQUssUUFBTztTQUFLLFdBQVU7bUJBQXRDLENBQ0Usd0JBQUMsVUFBRDtVQUFRLElBQUc7VUFBSyxJQUFHO1VBQUksR0FBRTtVQUFJLE1BQUs7VUFBTyxRQUFPO1VBQVEsYUFBWTtTQUFPOzs7O21CQUMzRSx3QkFBQyxVQUFEO1VBQVEsSUFBRztVQUFLLElBQUc7VUFBSyxHQUFFO1VBQUksTUFBSztVQUFPLFFBQU87VUFBUSxhQUFZO1NBQU87Ozs7aUJBQ3pFOzs7OztrQkFDTCx3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7O2dCQUN0Qjs7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssT0FBTTtTQUFLLFFBQU87U0FBSyxXQUFVO21CQUF0QyxDQUNFLHdCQUFDLFVBQUQ7VUFBUSxJQUFHO1VBQUssSUFBRztVQUFLLEdBQUU7VUFBSyxNQUFLO1VBQU8sUUFBTztVQUFRLGFBQVk7U0FBTzs7OzttQkFDN0Usd0JBQUMsUUFBRDtVQUFNLEdBQUU7VUFBSyxHQUFFO1VBQUssWUFBVztVQUFTLFVBQVM7VUFBSyxZQUFXO29CQUFPO1NBQU87Ozs7aUJBQzVFOzs7OztrQkFDTCx3QkFBQyxRQUFELFlBQU0sWUFBZTs7OztnQkFDbEI7Ozs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLE9BQU07U0FBSyxRQUFPO1NBQUssV0FBVTttQkFBdEMsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sR0FBRTtVQUFJLEdBQUU7VUFBSSxPQUFNO1VBQUssUUFBTztVQUFLLE1BQUs7VUFBTyxRQUFPO1VBQVEsYUFBWTtTQUFPOzs7O21CQUN2Rix3QkFBQyxRQUFEO1VBQU0sR0FBRTtVQUFLLEdBQUU7VUFBSyxZQUFXO1VBQVMsVUFBUztVQUFJLFlBQVc7b0JBQU87U0FBUzs7OztpQkFDN0U7Ozs7O2tCQUNMLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7Z0JBQ3ZCOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxPQUFNO1NBQUssUUFBTztTQUFLLFdBQVU7bUJBQXRDO1VBQ0Usd0JBQUMsVUFBRDtXQUFRLElBQUc7V0FBSyxJQUFHO1dBQUssR0FBRTtXQUFJLE1BQUs7V0FBTyxRQUFPO1dBQVEsYUFBWTtVQUFPOzs7OztVQUM1RSx3QkFBQyxRQUFEO1dBQU0sSUFBRztXQUFJLElBQUc7V0FBSSxJQUFHO1dBQUksSUFBRztXQUFLLFFBQU87V0FBUSxhQUFZO1VBQU87Ozs7O1VBQ3JFLHdCQUFDLFFBQUQ7V0FBTSxJQUFHO1dBQUssSUFBRztXQUFJLElBQUc7V0FBSyxJQUFHO1dBQUssUUFBTztXQUFRLGFBQVk7VUFBTzs7Ozs7U0FDcEU7Ozs7O2tCQUNMLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7Z0JBQ3ZCOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxPQUFNO1NBQUssUUFBTztTQUFLLFdBQVU7bUJBQXRDO1VBQ0Usd0JBQUMsUUFBRDtXQUFNLElBQUc7V0FBSyxJQUFHO1dBQUksSUFBRztXQUFLLElBQUc7V0FBSyxRQUFPO1dBQVEsYUFBWTtVQUFPOzs7OztVQUN2RSx3QkFBQyxRQUFEO1dBQU0sSUFBRztXQUFJLElBQUc7V0FBSyxJQUFHO1dBQUssSUFBRztXQUFLLFFBQU87V0FBUSxhQUFZO1VBQU87Ozs7O1VBQ3ZFLHdCQUFDLFFBQUQ7V0FBTSxJQUFHO1dBQUksSUFBRztXQUFLLElBQUc7V0FBSyxJQUFHO1dBQUssUUFBTztXQUFRLGFBQVk7VUFBTzs7Ozs7U0FDcEU7Ozs7O2tCQUNMLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7Z0JBQ3hCOzs7Ozs7TUFDRjs7Ozs7YUFDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXFCO09BQW1COzs7O2lCQUN0RCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaUU7T0FBUzs7OztlQUN2Rjs7Ozs7O01BQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBd0Isd0JBQUMsVUFBRDtTQUFRLFdBQVU7bUJBQWlCO1FBQWdCOzs7OztRQUFDO1FBQUU7T0FBZTs7Ozs7O01BQzdGLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQXdCLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO21CQUFpQjtRQUFpQjs7Ozs7UUFBQztRQUFFO09BQWU7Ozs7OztNQUM5Rix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYixDQUF3Qix3QkFBQyxVQUFEO1FBQVEsV0FBVTtrQkFBaUI7T0FBa0I7Ozs7aUJBQUMsb0JBQXFCOzs7Ozs7S0FDaEc7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQsYUFBTSxXQUFRLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLE9BQU8sQ0FBUTs7OztnQkFDM0Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXFFO01BQW9COzs7O2NBQ3RHOzs7OzthQUNGOzs7OztZQUVGOzs7Ozs7RUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGlhZ3JhbWFVbmlmaWxhckJsdWVwcmludC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VNZW1vLCB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFpvb21JbiwgWm9vbU91dCwgUm90YXRlQ2N3LCBMaW5rMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgdXNlU3RvcmUgZnJvbSAnLi4vc3RvcmUvdXNlU3RvcmUnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEaWFncmFtYVVuaWZpbGFyQmx1ZXByaW50KHsgXG4gIGVsZW1lbnRvcyA9IFtdLCBcbiAgY29tcGFueU5hbWUgPSAnRU1QUkVTQScsIFxuICBwcm9qZWN0TmFtZSA9ICdQUk9ZRUNUTycsIFxuICBpbnRlcmFjdGl2ZSA9IGZhbHNlLFxuICBzZWxlY3RlZE5vZGVJZCA9IG51bGwsXG4gIG9uTm9kZVNlbGVjdCA9IG51bGxcbn0pIHtcbiAgY29uc3QgY29udGFpbmVyUmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCB7IHVwZGF0ZUVsZW1lbnRvVW5pZmlsYXIgfSA9IHVzZVN0b3JlKCk7XG5cbiAgY29uc3QgW3pvb20sIHNldFpvb21dID0gdXNlU3RhdGUoMSk7XG4gIGNvbnN0IFtwYW4sIHNldFBhbl0gPSB1c2VTdGF0ZSh7IHg6IDAsIHk6IDAgfSk7XG4gIGNvbnN0IFtpc1Bhbm5pbmcsIHNldElzUGFubmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtwYW5TdGFydCwgc2V0UGFuU3RhcnRdID0gdXNlU3RhdGUoeyB4OiAwLCB5OiAwIH0pO1xuXG4gIC8vIEVzdGFkb3MgZGUgYXJyYXN0cmUgZGUgTm9kb3MgaW5kaXZpZHVhbGVzXG4gIGNvbnN0IFthY3RpdmVEcmFnTm9kZUlkLCBzZXRBY3RpdmVEcmFnTm9kZUlkXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbZHJhZ1N0YXJ0TW91c2UsIHNldERyYWdTdGFydE1vdXNlXSA9IHVzZVN0YXRlKHsgeDogMCwgeTogMCB9KTtcbiAgY29uc3QgW2RyYWdTdGFydE5vZGVQb3MsIHNldERyYWdTdGFydE5vZGVQb3NdID0gdXNlU3RhdGUoeyB4OiAwLCB5OiAwIH0pO1xuICBjb25zdCBbdGVtcE5vZGVQb3NpdGlvbnMsIHNldFRlbXBOb2RlUG9zaXRpb25zXSA9IHVzZVN0YXRlKHt9KTsgLy8geyBbbm9kZUlkXTogeyB4LCB5IH0gfVxuXG4gIC8vIDEuIFByb2Nlc2FyIGplcmFycXXDrWEsIGVubGFjZXMgU1NPVCB5IGZ1ZW50ZXMgZGUgZW1lcmdlbmNpYSBwYXJhIEFUU1xuICBjb25zdCB7IG5vZGVzLCBsZXZlbHMsIG1heE5vZGVzSW5MZXZlbCwgZGVwdGgsIGVtZXJnZW5jeUxpbmtzIH0gPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoIWVsZW1lbnRvcyB8fCBlbGVtZW50b3MubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4geyBub2RlczogW10sIGxldmVsczoge30sIG1heE5vZGVzSW5MZXZlbDogMCwgZGVwdGg6IDAsIGVtZXJnZW5jeUxpbmtzOiBbXSB9O1xuICAgIH1cblxuICAgIGNvbnN0IG5hbWVUb05vZGVNYXAgPSBuZXcgTWFwKCk7XG4gICAgY29uc3QgaWRUb05vZGVNYXAgPSBuZXcgTWFwKCk7XG5cbiAgICBlbGVtZW50b3MuZm9yRWFjaCgoZWwpID0+IHtcbiAgICAgIGlmIChlbC5ub21icmUpIHtcbiAgICAgICAgbmFtZVRvTm9kZU1hcC5zZXQoZWwubm9tYnJlLnRvTG93ZXJDYXNlKCkudHJpbSgpLCBlbCk7XG4gICAgICB9XG4gICAgICBpZiAoZWwuaWQpIHtcbiAgICAgICAgaWRUb05vZGVNYXAuc2V0KGVsLmlkLnRvTG93ZXJDYXNlKCkudHJpbSgpLCBlbCk7XG4gICAgICAgIG5hbWVUb05vZGVNYXAuc2V0KGVsLmlkLnRvTG93ZXJDYXNlKCkudHJpbSgpLCBlbCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBIZWxwZXIgcGFyYSBleHRyYWVyIElEIGRlIHVuIHRleHRvIGNvbiBmb3JtYXRvIFwiTm9tYnJlIChJRDogVEFCLTEpXCJcbiAgICBjb25zdCBleHRyYWN0SWRGcm9tVGV4dCA9ICh0ZXh0KSA9PiB7XG4gICAgICBpZiAoIXRleHQgfHwgdHlwZW9mIHRleHQgIT09ICdzdHJpbmcnKSByZXR1cm4gbnVsbDtcbiAgICAgIGNvbnN0IG1hdGNoID0gdGV4dC5tYXRjaCgvXFwoKD86SUQ6XFxzKik/KFtBLVowLTlfLV0rKVxcKS9pKTtcbiAgICAgIHJldHVybiBtYXRjaCA/IG1hdGNoWzFdLnRvTG93ZXJDYXNlKCkudHJpbSgpIDogbnVsbDtcbiAgICB9O1xuXG4gICAgLy8gTWFwYSBkZSBlbmxhY2VzIGRlcml2YWRvcyBkZSBjaXJjdWl0b3MgKGVqLiBUYWJsZXJvIFByaW5jaXBhbCBhbGltZW50YSBUYWJsZXJvIEhpZHJvbmV1bcOhdGljbylcbiAgICBjb25zdCBjaXJjdWl0RmVlZHNNYXAgPSBuZXcgTWFwKCk7IC8vIGNoaWxkSWQgLT4gcGFyZW50SWRcbiAgICBlbGVtZW50b3MuZm9yRWFjaCgocGFyZW50RWwpID0+IHtcbiAgICAgIGNvbnN0IGNpcmN1aXRzID0gcGFyZW50RWwuY2lyY3VpdHMgfHwgcGFyZW50RWwuZGF0b3NUZWNuaWNvcz8uY2lyY3VpdHMgfHwgW107XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShjaXJjdWl0cykpIHtcbiAgICAgICAgY2lyY3VpdHMuZm9yRWFjaCgoYykgPT4ge1xuICAgICAgICAgIGNvbnN0IGRlc3RJZCA9IGMuZWxlbWVudG9EZXN0aW5vSWQgfHwgYy52aW5jdWxhZG9JZCB8fCBleHRyYWN0SWRGcm9tVGV4dChjLmVxdWlwbyk7XG4gICAgICAgICAgaWYgKGRlc3RJZCkge1xuICAgICAgICAgICAgY2lyY3VpdEZlZWRzTWFwLnNldChkZXN0SWQudG9Mb3dlckNhc2UoKS50cmltKCksIHBhcmVudEVsLmlkKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGMuZXF1aXBvICYmIHR5cGVvZiBjLmVxdWlwbyA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIGNvbnN0IGNsZWFuRXF1aXBvID0gYy5lcXVpcG8udG9Mb3dlckNhc2UoKS50cmltKCk7XG4gICAgICAgICAgICBjb25zdCBtYXRjaGluZ05vZGUgPSBuYW1lVG9Ob2RlTWFwLmdldChjbGVhbkVxdWlwbyk7XG4gICAgICAgICAgICBpZiAobWF0Y2hpbmdOb2RlKSB7XG4gICAgICAgICAgICAgIGNpcmN1aXRGZWVkc01hcC5zZXQobWF0Y2hpbmdOb2RlLmlkLnRvTG93ZXJDYXNlKCkudHJpbSgpLCBwYXJlbnRFbC5pZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGNvbnN0IGVtZXJnZW5jeUxpbmtzTGlzdCA9IFtdO1xuXG4gICAgY29uc3QgcHJvY2Vzc2VkTm9kZXMgPSBlbGVtZW50b3MubWFwKChlbCkgPT4ge1xuICAgICAgY29uc3QgZHQgPSB0eXBlb2YgZWwuZGF0b3NUZWNuaWNvcyA9PT0gJ3N0cmluZydcbiAgICAgICAgPyBKU09OLnBhcnNlKGVsLmRhdG9zVGVjbmljb3MgfHwgJ3t9JylcbiAgICAgICAgOiAoZWwuZGF0b3NUZWNuaWNvcyB8fCB7fSk7XG5cbiAgICAgIC8vIFJlc29sdWNpw7NuIGplcsOhcnF1aWNhIGRlIGFsaW1lbnRhY2nDs24gcHJpbWFyaWEgKFNTT1QpXG4gICAgICBsZXQgcmVzb2x2ZWRQYXJlbnRJZCA9IG51bGw7XG5cbiAgICAgIC8vIDEuIFZlcmlmaWNhciBzaSBlbCBlbGVtZW50byB0aWVuZSBJRCBkZSBhbGltZW50YWRvciBkaXJlY3RvXG4gICAgICBpZiAoZWwuYWxpbWVudGFkb1BvcklkICYmIGlkVG9Ob2RlTWFwLmhhcyhlbC5hbGltZW50YWRvUG9ySWQudG9Mb3dlckNhc2UoKS50cmltKCkpKSB7XG4gICAgICAgIHJlc29sdmVkUGFyZW50SWQgPSBpZFRvTm9kZU1hcC5nZXQoZWwuYWxpbWVudGFkb1BvcklkLnRvTG93ZXJDYXNlKCkudHJpbSgpKS5pZDtcbiAgICAgIH0gZWxzZSBpZiAoZWwub3JpZ2VuSWQgJiYgaWRUb05vZGVNYXAuaGFzKGVsLm9yaWdlbklkLnRvTG93ZXJDYXNlKCkudHJpbSgpKSkge1xuICAgICAgICByZXNvbHZlZFBhcmVudElkID0gaWRUb05vZGVNYXAuZ2V0KGVsLm9yaWdlbklkLnRvTG93ZXJDYXNlKCkudHJpbSgpKS5pZDtcbiAgICAgIH1cblxuICAgICAgLy8gMi4gVmVyaWZpY2FyIHBvciBjYW1wbyBhbGltZW50YWRvUG9yIChub21icmUgbyBJRCBpbmNydXN0YWRvKVxuICAgICAgaWYgKCFyZXNvbHZlZFBhcmVudElkICYmIGVsLmFsaW1lbnRhZG9Qb3IpIHtcbiAgICAgICAgY29uc3QgaWRGcm9tQWxpbSA9IGV4dHJhY3RJZEZyb21UZXh0KGVsLmFsaW1lbnRhZG9Qb3IpO1xuICAgICAgICBpZiAoaWRGcm9tQWxpbSAmJiBpZFRvTm9kZU1hcC5oYXMoaWRGcm9tQWxpbSkpIHtcbiAgICAgICAgICByZXNvbHZlZFBhcmVudElkID0gaWRUb05vZGVNYXAuZ2V0KGlkRnJvbUFsaW0pLmlkO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IGNsZWFuQWxpbSA9IGVsLmFsaW1lbnRhZG9Qb3IudG9Mb3dlckNhc2UoKS50cmltKCk7XG4gICAgICAgICAgY29uc3QgcGFyZW50QnlOYW1lID0gbmFtZVRvTm9kZU1hcC5nZXQoY2xlYW5BbGltKTtcbiAgICAgICAgICBpZiAocGFyZW50QnlOYW1lKSB7XG4gICAgICAgICAgICByZXNvbHZlZFBhcmVudElkID0gcGFyZW50QnlOYW1lLmlkO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyAzLiBQYXJhIEFUUy9UcmFuc2ZlcmVuY2lhOiB2ZXJpZmljYXIgZnVlbnRlIG5vcm1hbFxuICAgICAgY29uc3QgaXNUcmFuc2ZlciA9IGVsLnRpcG9FbGVtZW50byA9PT0gJ1RSQU5TRkVSJyB8fCBlbC50aXBvID09PSAnVFJBTlNGRVInO1xuICAgICAgaWYgKGlzVHJhbnNmZXIpIHtcbiAgICAgICAgY29uc3QgZnVlbnRlTm9ybWFsID0gZHQuZnVlbnRlTm9ybWFsTm9tYnJlIHx8IGR0LmZ1ZW50ZU5vcm1hbElkIHx8IGVsLmZ1ZW50ZU5vcm1hbDtcbiAgICAgICAgaWYgKGZ1ZW50ZU5vcm1hbCkge1xuICAgICAgICAgIGNvbnN0IGlkRnJvbU5vcm0gPSBleHRyYWN0SWRGcm9tVGV4dChmdWVudGVOb3JtYWwpO1xuICAgICAgICAgIGlmIChpZEZyb21Ob3JtICYmIGlkVG9Ob2RlTWFwLmhhcyhpZEZyb21Ob3JtKSkge1xuICAgICAgICAgICAgcmVzb2x2ZWRQYXJlbnRJZCA9IGlkVG9Ob2RlTWFwLmdldChpZEZyb21Ob3JtKS5pZDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgcGFyZW50Tm9ybSA9IG5hbWVUb05vZGVNYXAuZ2V0KFN0cmluZyhmdWVudGVOb3JtYWwpLnRvTG93ZXJDYXNlKCkudHJpbSgpKTtcbiAgICAgICAgICAgIGlmIChwYXJlbnROb3JtKSByZXNvbHZlZFBhcmVudElkID0gcGFyZW50Tm9ybS5pZDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBSZXNvbHVjacOzbiBkZSBsYSBmdWVudGUgZGUgRW1lcmdlbmNpYSAoR2VuZXJhZG9yIC0+IEFUUykgKE9ic2VydmFjacOzbiAxOClcbiAgICAgICAgY29uc3QgZnVlbnRlRW1lcmdlbmNpYSA9IGR0LmZ1ZW50ZUVtZXJnZW5jaWFOb21icmUgfHwgZHQuZnVlbnRlRW1lcmdlbmNpYUlkIHx8IGR0LmdlbmVyYWRvcklkIHx8IGR0LmFsaW1lbnRhY2lvbkdlbmVyYWRvcjE7XG4gICAgICAgIGxldCBnZW5Ob2RlID0gbnVsbDtcbiAgICAgICAgaWYgKGZ1ZW50ZUVtZXJnZW5jaWEpIHtcbiAgICAgICAgICBjb25zdCBpZEZyb21FbWVyZyA9IGV4dHJhY3RJZEZyb21UZXh0KGZ1ZW50ZUVtZXJnZW5jaWEpO1xuICAgICAgICAgIGlmIChpZEZyb21FbWVyZyAmJiBpZFRvTm9kZU1hcC5oYXMoaWRGcm9tRW1lcmcpKSB7XG4gICAgICAgICAgICBnZW5Ob2RlID0gaWRUb05vZGVNYXAuZ2V0KGlkRnJvbUVtZXJnKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZ2VuTm9kZSA9IG5hbWVUb05vZGVNYXAuZ2V0KFN0cmluZyhmdWVudGVFbWVyZ2VuY2lhKS50b0xvd2VyQ2FzZSgpLnRyaW0oKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gRmFsbGJhY2s6IFNpIG5vIGVzdMOhIGV4cGzDrWNpdG8gZW4gZWwgQVRTLCBidXNjYXIgc2kgZXhpc3RlIHVuIEdlbmVyYWRvciBlbiBlbCBwcm95ZWN0b1xuICAgICAgICBpZiAoIWdlbk5vZGUpIHtcbiAgICAgICAgICBnZW5Ob2RlID0gZWxlbWVudG9zLmZpbmQoZSA9PiAoZS50aXBvRWxlbWVudG8gPT09ICdHRU5FUkFET1InIHx8IGUudGlwbyA9PT0gJ0dFTkVSQURPUicpICYmIGUuaWQgIT09IGVsLmlkKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChnZW5Ob2RlICYmIGdlbk5vZGUuaWQgIT09IGVsLmlkKSB7XG4gICAgICAgICAgZW1lcmdlbmN5TGlua3NMaXN0LnB1c2goe1xuICAgICAgICAgICAgaWQ6IGBlbWVyZy0ke2dlbk5vZGUuaWR9LSR7ZWwuaWR9YCxcbiAgICAgICAgICAgIHNvdXJjZUlkOiBnZW5Ob2RlLmlkLFxuICAgICAgICAgICAgdGFyZ2V0SWQ6IGVsLmlkLFxuICAgICAgICAgICAgbGFiZWw6ICdFTUVSR0VOQ0lBIChHRU4pJ1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIDQuIFNpIGHDum4gbm8gdGllbmUgcGFkcmUsIHZlcmlmaWNhciBzaSBlc3TDoSBkZXJpdmFkbyBkZSB1biBjaXJjdWl0byBhZ3VhcyBhcnJpYmEgKE9icyAyNSAtIEhpZHJvbmV1bcOhdGljbylcbiAgICAgIGlmICghcmVzb2x2ZWRQYXJlbnRJZCAmJiBjaXJjdWl0RmVlZHNNYXAuaGFzKGVsLmlkLnRvTG93ZXJDYXNlKCkudHJpbSgpKSkge1xuICAgICAgICByZXNvbHZlZFBhcmVudElkID0gY2lyY3VpdEZlZWRzTWFwLmdldChlbC5pZC50b0xvd2VyQ2FzZSgpLnRyaW0oKSk7XG4gICAgICB9XG5cbiAgICAgIC8vIEV2aXRhciBhdXRvLXJlZmVyZW5jaWFzIGNpcmN1bGFyZXNcbiAgICAgIGlmIChyZXNvbHZlZFBhcmVudElkID09PSBlbC5pZCkge1xuICAgICAgICByZXNvbHZlZFBhcmVudElkID0gbnVsbDtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uZWwsXG4gICAgICAgIGRhdG9zVGVjbmljb3M6IGR0LFxuICAgICAgICBwYXJlbnRJZDogcmVzb2x2ZWRQYXJlbnRJZCxcbiAgICAgICAgY2hpbGRyZW46IFtdXG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgY29uc3Qgbm9kZU1hcCA9IG5ldyBNYXAocHJvY2Vzc2VkTm9kZXMubWFwKG4gPT4gW24uaWQsIG5dKSk7XG4gICAgY29uc3Qgcm9vdHMgPSBbXTtcblxuICAgIHByb2Nlc3NlZE5vZGVzLmZvckVhY2goKG5vZGUpID0+IHtcbiAgICAgIGlmIChub2RlLnBhcmVudElkICYmIG5vZGVNYXAuaGFzKG5vZGUucGFyZW50SWQpKSB7XG4gICAgICAgIG5vZGVNYXAuZ2V0KG5vZGUucGFyZW50SWQpLmNoaWxkcmVuLnB1c2gobm9kZS5pZCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByb290cy5wdXNoKG5vZGUuaWQpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgY29uc3QgbGV2ZWxzTWFwID0ge307XG4gICAgY29uc3Qgbm9kZUxldmVscyA9IHt9O1xuICAgIGNvbnN0IHF1ZXVlID0gcm9vdHMubWFwKGlkID0+ICh7IGlkLCBsZXZlbDogMCB9KSk7XG5cbiAgICB3aGlsZSAocXVldWUubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgeyBpZCwgbGV2ZWwgfSA9IHF1ZXVlLnNoaWZ0KCk7XG4gICAgICBjb25zdCBub2RlID0gbm9kZU1hcC5nZXQoaWQpO1xuICAgICAgaWYgKCFub2RlKSBjb250aW51ZTtcblxuICAgICAgbm9kZUxldmVsc1tpZF0gPSBsZXZlbDtcbiAgICAgIGlmICghbGV2ZWxzTWFwW2xldmVsXSkgbGV2ZWxzTWFwW2xldmVsXSA9IFtdO1xuICAgICAgbGV2ZWxzTWFwW2xldmVsXS5wdXNoKGlkKTtcblxuICAgICAgbm9kZS5jaGlsZHJlbi5mb3JFYWNoKGNoaWxkSWQgPT4ge1xuICAgICAgICBxdWV1ZS5wdXNoKHsgaWQ6IGNoaWxkSWQsIGxldmVsOiBsZXZlbCArIDEgfSk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zdCBmaW5hbE5vZGVzID0gcHJvY2Vzc2VkTm9kZXMubWFwKG4gPT4gKHtcbiAgICAgIC4uLm4sXG4gICAgICBsZXZlbDogbm9kZUxldmVsc1tuLmlkXSAhPT0gdW5kZWZpbmVkID8gbm9kZUxldmVsc1tuLmlkXSA6IDBcbiAgICB9KSk7XG5cbiAgICBsZXQgbWF4Q291bnQgPSAwO1xuICAgIE9iamVjdC5rZXlzKGxldmVsc01hcCkuZm9yRWFjaChsdmwgPT4ge1xuICAgICAgbWF4Q291bnQgPSBNYXRoLm1heChtYXhDb3VudCwgbGV2ZWxzTWFwW2x2bF0ubGVuZ3RoKTtcbiAgICB9KTtcblxuICAgIHJldHVybiB7XG4gICAgICBub2RlczogZmluYWxOb2RlcyxcbiAgICAgIGxldmVsczogbGV2ZWxzTWFwLFxuICAgICAgbWF4Tm9kZXNJbkxldmVsOiBtYXhDb3VudCxcbiAgICAgIGRlcHRoOiBPYmplY3Qua2V5cyhsZXZlbHNNYXApLmxlbmd0aCxcbiAgICAgIGVtZXJnZW5jeUxpbmtzOiBlbWVyZ2VuY3lMaW5rc0xpc3RcbiAgICB9O1xuICB9LCBbZWxlbWVudG9zXSk7XG5cbiAgLy8gRGltZW5zaW9uZXMgZmlqYXMgZGVsIGxpZW56byBDQUQgcGFyYSBsaWJyZSBwb3NpY2lvbmFtaWVudG8gKGV4cGFuZGlibGUgc2kgaGF5IG11Y2hvcyBuaXZlbGVzKVxuICBjb25zdCB3aWR0aCA9IE1hdGgubWF4KDE2MDAsIG1heE5vZGVzSW5MZXZlbCAqIDI1MCArIDIwMCk7XG4gIGNvbnN0IGhlaWdodCA9IE1hdGgubWF4KDEyMDAsIGRlcHRoICogMjIwICsgMjAwKTtcblxuICAvLyBDb29yZGVuYWRhcyBjYWxjdWxhZGFzIGRlIGF1dG8tbGF5b3V0IChjb21vIGZhbGxiYWNrKVxuICBjb25zdCBhdXRvTGF5b3V0Q29vcmRzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3QgY29vcmRzID0ge307XG4gICAgT2JqZWN0LmtleXMobGV2ZWxzKS5mb3JFYWNoKChsdmxTdHIpID0+IHtcbiAgICAgIGNvbnN0IGx2bCA9IHBhcnNlSW50KGx2bFN0ciwgMTApO1xuICAgICAgY29uc3QgbHZsTm9kZXMgPSBsZXZlbHNbbHZsXTtcbiAgICAgIGNvbnN0IGNvdW50ID0gbHZsTm9kZXMubGVuZ3RoO1xuICAgICAgY29uc3QgeSA9IDEyMCArIGx2bCAqIDE4MDtcblxuICAgICAgbHZsTm9kZXMuZm9yRWFjaCgoaWQsIGlkeCkgPT4ge1xuICAgICAgICBjb25zdCB4ID0gKGlkeCArIDAuNSkgKiAod2lkdGggLyBjb3VudCk7XG4gICAgICAgIGNvb3Jkc1tpZF0gPSB7IHgsIHkgfTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIHJldHVybiBjb29yZHM7XG4gIH0sIFtsZXZlbHMsIHdpZHRoXSk7XG5cbiAgLy8gT2J0ZW5lciBjb29yZGVuYWRhcyBmaW5hbGVzIGRlIHVuIG5vZG8gKHByaW9yaXphIHRlbXAgLT4gY3VzdG9tIC0+IGF1dG8pXG4gIGNvbnN0IGdldE5vZGVDb29yZHMgPSAobm9kZUlkKSA9PiB7XG4gICAgaWYgKHRlbXBOb2RlUG9zaXRpb25zW25vZGVJZF0pIHtcbiAgICAgIHJldHVybiB0ZW1wTm9kZVBvc2l0aW9uc1tub2RlSWRdO1xuICAgIH1cbiAgICBjb25zdCBub2RlID0gbm9kZXMuZmluZChuID0+IG4uaWQgPT09IG5vZGVJZCk7XG4gICAgaWYgKG5vZGUgJiYgbm9kZS5kYXRvc1RlY25pY29zPy5wb3NpdGlvblggIT09IHVuZGVmaW5lZCAmJiBub2RlLmRhdG9zVGVjbmljb3M/LnBvc2l0aW9uWSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4geyBcbiAgICAgICAgeDogcGFyc2VGbG9hdChub2RlLmRhdG9zVGVjbmljb3MucG9zaXRpb25YKSwgXG4gICAgICAgIHk6IHBhcnNlRmxvYXQobm9kZS5kYXRvc1RlY25pY29zLnBvc2l0aW9uWSkgXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gYXV0b0xheW91dENvb3Jkc1tub2RlSWRdIHx8IHsgeDogMjAwLCB5OiAyMDAgfTtcbiAgfTtcblxuICAvLyBQQU5OSU5HIChBcnJhc3RyYXIgbGllbnpvIGNvbXBsZXRvKVxuICBjb25zdCBoYW5kbGVDYW52YXNNb3VzZURvd24gPSAoZSkgPT4ge1xuICAgIGlmICghaW50ZXJhY3RpdmUpIHJldHVybjtcbiAgICBpZiAoZS5idXR0b24gIT09IDApIHJldHVybjsgLy8gc29sbyBjbGljayBpenF1aWVyZG9cbiAgICBpZiAoZS50YXJnZXQuY2xvc2VzdCgnLm5vZGUtZWxlbWVudCcpKSByZXR1cm47IC8vIE5vIGhhY2VyIHBhbiBzaSBhcnJhc3RyYW1vcyB1biBub2RvXG4gICAgXG4gICAgc2V0SXNQYW5uaW5nKHRydWUpO1xuICAgIHNldFBhblN0YXJ0KHsgeDogZS5jbGllbnRYIC0gcGFuLngsIHk6IGUuY2xpZW50WSAtIHBhbi55IH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNhbnZhc01vdXNlTW92ZSA9IChlKSA9PiB7XG4gICAgaWYgKGludGVyYWN0aXZlICYmIGlzUGFubmluZykge1xuICAgICAgc2V0UGFuKHtcbiAgICAgICAgeDogZS5jbGllbnRYIC0gcGFuU3RhcnQueCxcbiAgICAgICAgeTogZS5jbGllbnRZIC0gcGFuU3RhcnQueVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gTWFuZWphciBhcnJhc3RyZSBhY3Rpdm8gZGVsIG5vZG9cbiAgICBpZiAoaW50ZXJhY3RpdmUgJiYgYWN0aXZlRHJhZ05vZGVJZCkge1xuICAgICAgY29uc3QgZGVsdGFYID0gKGUuY2xpZW50WCAtIGRyYWdTdGFydE1vdXNlLngpIC8gem9vbTtcbiAgICAgIGNvbnN0IGRlbHRhWSA9IChlLmNsaWVudFkgLSBkcmFnU3RhcnRNb3VzZS55KSAvIHpvb207XG4gICAgICBcbiAgICAgIHNldFRlbXBOb2RlUG9zaXRpb25zKHByZXYgPT4gKHtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAgW2FjdGl2ZURyYWdOb2RlSWRdOiB7XG4gICAgICAgICAgeDogZHJhZ1N0YXJ0Tm9kZVBvcy54ICsgZGVsdGFYLFxuICAgICAgICAgIHk6IGRyYWdTdGFydE5vZGVQb3MueSArIGRlbHRhWVxuICAgICAgICB9XG4gICAgICB9KSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNhbnZhc01vdXNlVXAgPSAoKSA9PiB7XG4gICAgc2V0SXNQYW5uaW5nKGZhbHNlKTtcblxuICAgIC8vIEZpbmFsaXphciBhcnJhc3RyZSBkZSBub2RvIHkgZ3VhcmRhclxuICAgIGlmIChhY3RpdmVEcmFnTm9kZUlkKSB7XG4gICAgICBjb25zdCBmaW5hbFBvcyA9IHRlbXBOb2RlUG9zaXRpb25zW2FjdGl2ZURyYWdOb2RlSWRdO1xuICAgICAgaWYgKGZpbmFsUG9zKSB7XG4gICAgICAgIC8vIFNuYXBwaW5nIGEgbGEgcmVqaWxsYSBkZSAyMHB4XG4gICAgICAgIGNvbnN0IHNuYXBwZWRYID0gTWF0aC5yb3VuZChmaW5hbFBvcy54IC8gMjApICogMjA7XG4gICAgICAgIGNvbnN0IHNuYXBwZWRZID0gTWF0aC5yb3VuZChmaW5hbFBvcy55IC8gMjApICogMjA7XG4gICAgICAgIFxuICAgICAgICBjb25zdCBub2RlID0gbm9kZXMuZmluZChuID0+IG4uaWQgPT09IGFjdGl2ZURyYWdOb2RlSWQpO1xuICAgICAgICBpZiAobm9kZSkge1xuICAgICAgICAgIHVwZGF0ZUVsZW1lbnRvVW5pZmlsYXIobm9kZS5wcm95ZWN0b0lkLCBhY3RpdmVEcmFnTm9kZUlkLCB7XG4gICAgICAgICAgICBkYXRvc1RlY25pY29zOiB7XG4gICAgICAgICAgICAgIC4uLm5vZGUuZGF0b3NUZWNuaWNvcyxcbiAgICAgICAgICAgICAgcG9zaXRpb25YOiBzbmFwcGVkWCxcbiAgICAgICAgICAgICAgcG9zaXRpb25ZOiBzbmFwcGVkWVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBzZXRBY3RpdmVEcmFnTm9kZUlkKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICAvLyBUT1VDSCBTVVBQT1JUIHBhcmEgbcOzdmlsZXMgZSBpUGFkc1xuICBjb25zdCBoYW5kbGVUb3VjaFN0YXJ0ID0gKGUpID0+IHtcbiAgICBpZiAoIWludGVyYWN0aXZlKSByZXR1cm47XG4gICAgY29uc3QgdG91Y2ggPSBlLnRvdWNoZXNbMF07XG4gICAgaWYgKGUudGFyZ2V0LmNsb3Nlc3QoJy5ub2RlLWVsZW1lbnQnKSkge1xuICAgICAgY29uc3Qgbm9kZUVsID0gZS50YXJnZXQuY2xvc2VzdCgnLm5vZGUtZWxlbWVudCcpO1xuICAgICAgY29uc3Qgbm9kZUlkID0gbm9kZUVsLmRhdGFzZXQubm9kZWlkO1xuICAgICAgY29uc3Qgc3RhcnRQb3MgPSBnZXROb2RlQ29vcmRzKG5vZGVJZCk7XG4gICAgICBcbiAgICAgIHNldEFjdGl2ZURyYWdOb2RlSWQobm9kZUlkKTtcbiAgICAgIHNldERyYWdTdGFydE1vdXNlKHsgeDogdG91Y2guY2xpZW50WCwgeTogdG91Y2guY2xpZW50WSB9KTtcbiAgICAgIHNldERyYWdTdGFydE5vZGVQb3Moc3RhcnRQb3MpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRJc1Bhbm5pbmcodHJ1ZSk7XG4gICAgICBzZXRQYW5TdGFydCh7IHg6IHRvdWNoLmNsaWVudFggLSBwYW4ueCwgeTogdG91Y2guY2xpZW50WSAtIHBhbi55IH0pO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVUb3VjaE1vdmUgPSAoZSkgPT4ge1xuICAgIGlmICghaW50ZXJhY3RpdmUpIHJldHVybjtcbiAgICBjb25zdCB0b3VjaCA9IGUudG91Y2hlc1swXTtcblxuICAgIGlmIChhY3RpdmVEcmFnTm9kZUlkKSB7XG4gICAgICBjb25zdCBkZWx0YVggPSAodG91Y2guY2xpZW50WCAtIGRyYWdTdGFydE1vdXNlLngpIC8gem9vbTtcbiAgICAgIGNvbnN0IGRlbHRhWSA9ICh0b3VjaC5jbGllbnRZIC0gZHJhZ1N0YXJ0TW91c2UueSkgLyB6b29tO1xuICAgICAgc2V0VGVtcE5vZGVQb3NpdGlvbnMocHJldiA9PiAoe1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICBbYWN0aXZlRHJhZ05vZGVJZF06IHtcbiAgICAgICAgICB4OiBkcmFnU3RhcnROb2RlUG9zLnggKyBkZWx0YVgsXG4gICAgICAgICAgeTogZHJhZ1N0YXJ0Tm9kZVBvcy55ICsgZGVsdGFZXG4gICAgICAgIH1cbiAgICAgIH0pKTtcbiAgICB9IGVsc2UgaWYgKGlzUGFubmluZykge1xuICAgICAgc2V0UGFuKHtcbiAgICAgICAgeDogdG91Y2guY2xpZW50WCAtIHBhblN0YXJ0LngsXG4gICAgICAgIHk6IHRvdWNoLmNsaWVudFkgLSBwYW5TdGFydC55XG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgLy8gV0hFRUwgWk9PTVxuICBjb25zdCBoYW5kbGVXaGVlbCA9IChlKSA9PiB7XG4gICAgaWYgKCFpbnRlcmFjdGl2ZSkgcmV0dXJuO1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCBzY2FsZUZhY3RvciA9IDEuMTtcbiAgICBpZiAoZS5kZWx0YVkgPCAwKSB7XG4gICAgICBzZXRab29tKHByZXYgPT4gTWF0aC5taW4oMywgcHJldiAqIHNjYWxlRmFjdG9yKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldFpvb20ocHJldiA9PiBNYXRoLm1heCgwLjMsIHByZXYgLyBzY2FsZUZhY3RvcikpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCByZXNldFZpZXcgPSAoKSA9PiB7XG4gICAgc2V0Wm9vbSgxKTtcbiAgICBzZXRQYW4oeyB4OiAwLCB5OiAwIH0pO1xuICAgIHNldFRlbXBOb2RlUG9zaXRpb25zKHt9KTtcbiAgfTtcblxuICAvLyBSRU5ERVJJWkFETyBERSBTw41NQk9MT1MgRUzDiUNUUklDT1NcbiAgY29uc3QgcmVuZGVyTm9kZVN5bWJvbCA9ICh0eXBlLCBpc1ByaW50KSA9PiB7XG4gICAgY29uc3QgYWNjZW50Q29sb3IgPSBpc1ByaW50ID8gJyMwMDAwMDAnIDogJyNmNTllMGInO1xuICAgIGNvbnN0IHRyYWZvQ29sb3IgPSBpc1ByaW50ID8gJyMwMDAwMDAnIDogJyM4YjVjZjYnO1xuICAgIGNvbnN0IHRyYW5zZmVyQ29sb3IgPSBpc1ByaW50ID8gJyMwMDAwMDAnIDogJyMxMGI5ODEnO1xuICAgIGNvbnN0IGNhcGFjaXRvckNvbG9yID0gaXNQcmludCA/ICcjMDAwMDAwJyA6ICcjMDZiNmQ0JztcbiAgICBjb25zdCBzdWJDb2xvciA9IGlzUHJpbnQgPyAnIzAwMDAwMCcgOiAnI2VjNDg5OSc7XG4gICAgY29uc3QgYWN0aXZlRmlsbCA9IGlzUHJpbnQgPyAnbm9uZScgOiB1bmRlZmluZWQ7XG5cbiAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgIGNhc2UgJ0dFTkVSQURPUic6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPGc+XG4gICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMFwiIGN5PVwiMFwiIHI9XCIyMFwiIGZpbGw9e2FjdGl2ZUZpbGwgfHwgJyMxZTFiNGInfSBzdHJva2U9e2FjY2VudENvbG9yfSBzdHJva2VXaWR0aD1cIjIuNVwiIC8+XG4gICAgICAgICAgICA8dGV4dCB4PVwiMFwiIHk9XCI1XCIgdGV4dEFuY2hvcj1cIm1pZGRsZVwiIGZpbGw9e2FjY2VudENvbG9yfSBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYmxhY2sgZm9udC1tb25vXCI+RzwvdGV4dD5cbiAgICAgICAgICA8L2c+XG4gICAgICAgICk7XG4gICAgICBjYXNlICdUUkFOU0ZPUk1BRE9SJzpcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8ZyB0cmFuc2Zvcm09XCJzY2FsZSgxKVwiPlxuICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjBcIiBjeT1cIi04XCIgcj1cIjE0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9e3RyYWZvQ29sb3J9IHN0cm9rZVdpZHRoPVwiMi41XCIgLz5cbiAgICAgICAgICAgIDxjaXJjbGUgY3g9XCIwXCIgY3k9XCI4XCIgcj1cIjE0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9e3RyYWZvQ29sb3J9IHN0cm9rZVdpZHRoPVwiMi41XCIgLz5cbiAgICAgICAgICA8L2c+XG4gICAgICAgICk7XG4gICAgICBjYXNlICdUUkFOU0ZFUic6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPGc+XG4gICAgICAgICAgICA8cmVjdCB4PVwiLTI0XCIgeT1cIi0xNFwiIHdpZHRoPVwiNDhcIiBoZWlnaHQ9XCIyOFwiIHJ4PVwiNVwiIGZpbGw9e2FjdGl2ZUZpbGwgfHwgJyMwMjJjMjInfSBzdHJva2U9e3RyYW5zZmVyQ29sb3J9IHN0cm9rZVdpZHRoPVwiMi41XCIgLz5cbiAgICAgICAgICAgIDx0ZXh0IHg9XCIwXCIgeT1cIjRcIiB0ZXh0QW5jaG9yPVwibWlkZGxlXCIgZmlsbD17dHJhbnNmZXJDb2xvcn0gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LWJsYWNrIGZvbnQtbW9ub1wiPkFUUzwvdGV4dD5cbiAgICAgICAgICA8L2c+XG4gICAgICAgICk7XG4gICAgICBjYXNlICdQVUVTVEFfVElFUlJBJzpcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8ZyB0cmFuc2Zvcm09XCJzY2FsZSgwLjkpXCI+XG4gICAgICAgICAgICA8bGluZSB4MT1cIjBcIiB5MT1cIi0xOFwiIHgyPVwiMFwiIHkyPVwiNFwiIHN0cm9rZT17dHJhbnNmZXJDb2xvcn0gc3Ryb2tlV2lkdGg9XCIyLjVcIiAvPlxuICAgICAgICAgICAgPGxpbmUgeDE9XCItMTRcIiB5MT1cIjRcIiB4Mj1cIjE0XCIgeTI9XCI0XCIgc3Ryb2tlPXt0cmFuc2ZlckNvbG9yfSBzdHJva2VXaWR0aD1cIjIuNVwiIC8+XG4gICAgICAgICAgICA8bGluZSB4MT1cIi05XCIgeTE9XCIxMFwiIHgyPVwiOVwiIHkyPVwiMTBcIiBzdHJva2U9e3RyYW5zZmVyQ29sb3J9IHN0cm9rZVdpZHRoPVwiMlwiIC8+XG4gICAgICAgICAgICA8bGluZSB4MT1cIi00XCIgeTE9XCIxNlwiIHgyPVwiNFwiIHkyPVwiMTZcIiBzdHJva2U9e3RyYW5zZmVyQ29sb3J9IHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICA8L2c+XG4gICAgICAgICk7XG4gICAgICBjYXNlICdTVUJFU1RBQ0lPTic6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPGc+XG4gICAgICAgICAgICA8cG9seWdvbiBwb2ludHM9XCIwLC0yMCAxOCwtNiAxMSwxNiAtMTEsMTYgLTE4LC02XCIgZmlsbD17YWN0aXZlRmlsbCB8fCAnIzMxMTA0Mid9IHN0cm9rZT17c3ViQ29sb3J9IHN0cm9rZVdpZHRoPVwiMi41XCIgLz5cbiAgICAgICAgICAgIDxyZWN0IHg9XCItNlwiIHk9XCItNlwiIHdpZHRoPVwiMTJcIiBoZWlnaHQ9XCIxMlwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPXtzdWJDb2xvcn0gc3Ryb2tlV2lkdGg9XCIxLjVcIiAvPlxuICAgICAgICAgIDwvZz5cbiAgICAgICAgKTtcbiAgICAgIGNhc2UgJ0JBTkNPX0NPTkRFTlNBRE9SJzpcbiAgICAgIGNhc2UgJ09UUk8nOlxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxnPlxuICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjBcIiBjeT1cIjBcIiByPVwiMThcIiBmaWxsPXthY3RpdmVGaWxsIHx8ICcjMDgzMzQ0J30gc3Ryb2tlPXtjYXBhY2l0b3JDb2xvcn0gc3Ryb2tlV2lkdGg9XCIyLjVcIiAvPlxuICAgICAgICAgICAgPGxpbmUgeDE9XCItNVwiIHkxPVwiLThcIiB4Mj1cIi01XCIgeTI9XCI4XCIgc3Ryb2tlPXtjYXBhY2l0b3JDb2xvcn0gc3Ryb2tlV2lkdGg9XCIyXCIgLz5cbiAgICAgICAgICAgIDxsaW5lIHgxPVwiNVwiIHkxPVwiLThcIiB4Mj1cIjVcIiB5Mj1cIjhcIiBzdHJva2U9e2NhcGFjaXRvckNvbG9yfSBzdHJva2VXaWR0aD1cIjJcIiAvPlxuICAgICAgICAgICAgPGxpbmUgeDE9XCItMTJcIiB5MT1cIjBcIiB4Mj1cIi01XCIgeTI9XCIwXCIgc3Ryb2tlPXtjYXBhY2l0b3JDb2xvcn0gc3Ryb2tlV2lkdGg9XCIxLjVcIiAvPlxuICAgICAgICAgICAgPGxpbmUgeDE9XCI1XCIgeTE9XCIwXCIgeDI9XCIxMlwiIHkyPVwiMFwiIHN0cm9rZT17Y2FwYWNpdG9yQ29sb3J9IHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICA8L2c+XG4gICAgICAgICk7XG4gICAgICBjYXNlICdUQUJMRVJPJzpcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPGc+XG4gICAgICAgICAgICA8cmVjdCB4PVwiLTI2XCIgeT1cIi0xOFwiIHdpZHRoPVwiNTJcIiBoZWlnaHQ9XCIzNlwiIHJ4PVwiNFwiIGZpbGw9e2FjdGl2ZUZpbGwgfHwgJyMwODJmNDknfSBzdHJva2U9e2lzUHJpbnQgPyAnIzAwMDAwMCcgOiAnIzBlYTVlOSd9IHN0cm9rZVdpZHRoPVwiMi41XCIgLz5cbiAgICAgICAgICAgIDxsaW5lIHgxPVwiMFwiIHkxPVwiLTE0XCIgeDI9XCIwXCIgeTI9XCIxNFwiIHN0cm9rZT17aXNQcmludCA/ICcjMDAwMDAwJyA6ICcjMGVhNWU5J30gc3Ryb2tlV2lkdGg9XCIxXCIgc3Ryb2tlRGFzaGFycmF5PVwiMywzXCIgLz5cbiAgICAgICAgICAgIDxyZWN0IHg9XCItMThcIiB5PVwiLTExXCIgd2lkdGg9XCI4XCIgaGVpZ2h0PVwiNVwiIGZpbGw9e2lzUHJpbnQgPyAnIzAwMDAwMCcgOiAnIzBlYTVlOSd9IC8+XG4gICAgICAgICAgICA8cmVjdCB4PVwiMTBcIiB5PVwiLTNcIiB3aWR0aD1cIjhcIiBoZWlnaHQ9XCI1XCIgZmlsbD17aXNQcmludCA/ICcjMDAwMDAwJyA6ICcjMGVhNWU5J30gLz5cbiAgICAgICAgICAgIDxyZWN0IHg9XCItMThcIiB5PVwiNVwiIHdpZHRoPVwiOFwiIGhlaWdodD1cIjVcIiBmaWxsPXtpc1ByaW50ID8gJyMwMDAwMDAnIDogJyMwZWE1ZTknfSAvPlxuICAgICAgICAgIDwvZz5cbiAgICAgICAgKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaXNEYXJrVGhlbWUgPSBpbnRlcmFjdGl2ZTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgXG4gICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgc2VsZWN0LW5vbmUgJHtcbiAgICAgICAgaXNEYXJrVGhlbWUgXG4gICAgICAgICAgPyAnYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wgaC1mdWxsJyBcbiAgICAgICAgICA6ICdiZy13aGl0ZSB0ZXh0LWJsYWNrIHAtNCBib3JkZXItMiBib3JkZXItYmxhY2sgcm91bmRlZC1sZyBwYWdlLWJyZWFrJ1xuICAgICAgfWB9XG4gICAgPlxuICAgICAgey8qIEJhcnJhIGRlIENvbnRyb2wgZGUgTmF2ZWdhY2nDs24gZGVsIExpZW56byAqL31cbiAgICAgIHtpc0RhcmtUaGVtZSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS05MDAgYmctc2xhdGUtOTUwIG5vLXByaW50IHNocmluay0wXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOS41cHhdIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICBBcnJhc3RyYSBlbGVtZW50b3MgcGFyYSBtb3ZlcmxvcyDigKIgQXJyYXN0cmEgZWwgZm9uZG8gcGFyYSBkZXNwbGF6YXIg4oCiIERvYmxlIGNsaWMgcGFyYSByZWluaWNpYXIgdmlzdGFcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTAuNSByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRab29tKHByZXYgPT4gTWF0aC5tYXgoMC4zLCBwcmV2IC0gMC4xNSkpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgIHRpdGxlPVwiQWxlamFyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFpvb21PdXQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIGZvbnQtbW9ubyBmb250LWJvbGQgcHgtMiB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICB7TWF0aC5yb3VuZCh6b29tICogMTAwKX0lXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRab29tKHByZXYgPT4gTWF0aC5taW4oMywgcHJldiArIDAuMTUpKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIGhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICB0aXRsZT1cIkFjZXJjYXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Wm9vbUluIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgb25DbGljaz17cmVzZXRWaWV3fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgIHRpdGxlPVwiUmVzdGFibGVjZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBSZWppbGxhIHkgTGllbnpvIFNWRyAqL31cbiAgICAgIDxkaXYgXG4gICAgICAgIHJlZj17Y29udGFpbmVyUmVmfVxuICAgICAgICBvbk1vdXNlRG93bj17aGFuZGxlQ2FudmFzTW91c2VEb3dufVxuICAgICAgICBvbk1vdXNlTW92ZT17aGFuZGxlQ2FudmFzTW91c2VNb3ZlfVxuICAgICAgICBvbk1vdXNlVXA9e2hhbmRsZUNhbnZhc01vdXNlVXB9XG4gICAgICAgIG9uTW91c2VMZWF2ZT17aGFuZGxlQ2FudmFzTW91c2VVcH1cbiAgICAgICAgb25Ub3VjaFN0YXJ0PXtoYW5kbGVUb3VjaFN0YXJ0fVxuICAgICAgICBvblRvdWNoTW92ZT17aGFuZGxlVG91Y2hNb3ZlfVxuICAgICAgICBvblRvdWNoRW5kPXtoYW5kbGVDYW52YXNNb3VzZVVwfVxuICAgICAgICBvbldoZWVsPXtoYW5kbGVXaGVlbH1cbiAgICAgICAgb25Eb3VibGVDbGljaz17cmVzZXRWaWV3fVxuICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyICR7XG4gICAgICAgICAgaXNEYXJrVGhlbWUgPyAnYmctc2xhdGUtOTUwLzk1IGN1cnNvci1ncmFiIGFjdGl2ZTpjdXJzb3ItZ3JhYmJpbmcnIDogJ2JnLXdoaXRlIHAtMiBtaW4taC1bNTUwcHhdJ1xuICAgICAgICB9YH1cbiAgICAgID5cbiAgICAgICAge25vZGVzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtOCB0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgTm8gaGF5IGVsZW1lbnRvcyB1bmlmaWxhcmVzIGVuIGVsIGRpYWdyYW1hLiBBZ3JlZ2EgYWxndW5vcyBkZXNkZSBsYSBiYXJyYSBsYXRlcmFsIGl6cXVpZXJkYS5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBzdHlsZT17aXNEYXJrVGhlbWUgPyB7XG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogYHRyYW5zbGF0ZSgke3Bhbi54fXB4LCAke3Bhbi55fXB4KSBzY2FsZSgke3pvb219KWAsXG4gICAgICAgICAgICAgIHRyYW5zZm9ybU9yaWdpbjogJ2NlbnRlciBjZW50ZXInLFxuICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBhY3RpdmVEcmFnTm9kZUlkIHx8IGlzUGFubmluZyA/ICdub25lJyA6ICd0cmFuc2Zvcm0gMC4xNXMgZWFzZS1vdXQnXG4gICAgICAgICAgICB9IDoge1xuICAgICAgICAgICAgICB3aWR0aDogJzEwMCUnLFxuICAgICAgICAgICAgICBoZWlnaHQ6ICdhdXRvJ1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHN2ZyBcbiAgICAgICAgICAgICAgdmlld0JveD17YDAgMCAke3dpZHRofSAke2hlaWdodH1gfSBcbiAgICAgICAgICAgICAgd2lkdGg9e2lzRGFya1RoZW1lID8gd2lkdGggOiAnMTAwJSd9XG4gICAgICAgICAgICAgIGhlaWdodD17aXNEYXJrVGhlbWUgPyBoZWlnaHQgOiAnMTAwJSd9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm92ZXJmbG93LXZpc2libGUgZm9udC1tb25vIHNlbGVjdC1ub25lXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgey8qIERlZnMgcGFyYSBSZWppbGxhIENBRCB5IE1hcmNhZG9yZXMgKi99XG4gICAgICAgICAgICAgIDxkZWZzPlxuICAgICAgICAgICAgICAgIHsvKiBSZWppbGxhIENBRCAqL31cbiAgICAgICAgICAgICAgICB7aXNEYXJrVGhlbWUgJiYgKFxuICAgICAgICAgICAgICAgICAgPHBhdHRlcm4gaWQ9XCJjYWQtZ3JpZFwiIHdpZHRoPVwiNDBcIiBoZWlnaHQ9XCI0MFwiIHBhdHRlcm5Vbml0cz1cInVzZXJTcGFjZU9uVXNlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxjaXJjbGUgY3g9XCIyMFwiIGN5PVwiMjBcIiByPVwiMVwiIGZpbGw9XCIjMWUyOTNiXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGxpbmUgeDE9XCIwXCIgeTE9XCIwXCIgeDI9XCI0MFwiIHkyPVwiMFwiIHN0cm9rZT1cIiMwZjE3MmFcIiBzdHJva2VXaWR0aD1cIjAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxsaW5lIHgxPVwiMFwiIHkxPVwiMFwiIHgyPVwiMFwiIHkyPVwiNDBcIiBzdHJva2U9XCIjMGYxNzJhXCIgc3Ryb2tlV2lkdGg9XCIwLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9wYXR0ZXJuPlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7LyogRmxlY2hhcyAqL31cbiAgICAgICAgICAgICAgICA8bWFya2VyIFxuICAgICAgICAgICAgICAgICAgaWQ9XCJhcnJvdy1ibGFja1wiIFxuICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAxMCAxMFwiIFxuICAgICAgICAgICAgICAgICAgcmVmWD1cIjIyXCIgXG4gICAgICAgICAgICAgICAgICByZWZZPVwiNVwiIFxuICAgICAgICAgICAgICAgICAgbWFya2VyV2lkdGg9XCI1XCIgXG4gICAgICAgICAgICAgICAgICBtYXJrZXJIZWlnaHQ9XCI1XCIgXG4gICAgICAgICAgICAgICAgICBvcmllbnQ9XCJhdXRvLXN0YXJ0LXJldmVyc2VcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNIDAgMS41IEwgOCA1IEwgMCA4LjUgelwiIGZpbGw9XCIjMDAwMDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8L21hcmtlcj5cbiAgICAgICAgICAgICAgICA8bWFya2VyIFxuICAgICAgICAgICAgICAgICAgaWQ9XCJhcnJvdy1zbGF0ZVwiIFxuICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAxMCAxMFwiIFxuICAgICAgICAgICAgICAgICAgcmVmWD1cIjIyXCIgXG4gICAgICAgICAgICAgICAgICByZWZZPVwiNVwiIFxuICAgICAgICAgICAgICAgICAgbWFya2VyV2lkdGg9XCI1XCIgXG4gICAgICAgICAgICAgICAgICBtYXJrZXJIZWlnaHQ9XCI1XCIgXG4gICAgICAgICAgICAgICAgICBvcmllbnQ9XCJhdXRvLXN0YXJ0LXJldmVyc2VcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNIDAgMS41IEwgOCA1IEwgMCA4LjUgelwiIGZpbGw9XCIjNjQ3NDhiXCIgLz5cbiAgICAgICAgICAgICAgICA8L21hcmtlcj5cbiAgICAgICAgICAgICAgICA8bWFya2VyIFxuICAgICAgICAgICAgICAgICAgaWQ9XCJhcnJvdy1hbWJlclwiIFxuICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAxMCAxMFwiIFxuICAgICAgICAgICAgICAgICAgcmVmWD1cIjIyXCIgXG4gICAgICAgICAgICAgICAgICByZWZZPVwiNVwiIFxuICAgICAgICAgICAgICAgICAgbWFya2VyV2lkdGg9XCI1XCIgXG4gICAgICAgICAgICAgICAgICBtYXJrZXJIZWlnaHQ9XCI1XCIgXG4gICAgICAgICAgICAgICAgICBvcmllbnQ9XCJhdXRvLXN0YXJ0LXJldmVyc2VcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNIDAgMS41IEwgOCA1IEwgMCA4LjUgelwiIGZpbGw9XCIjZjU5ZTBiXCIgLz5cbiAgICAgICAgICAgICAgICA8L21hcmtlcj5cbiAgICAgICAgICAgICAgPC9kZWZzPlxuXG4gICAgICAgICAgICAgIHsvKiBGb25kbyBSZWppbGxhIENBRCAqL31cbiAgICAgICAgICAgICAge2lzRGFya1RoZW1lICYmIChcbiAgICAgICAgICAgICAgICA8cmVjdCB3aWR0aD17d2lkdGh9IGhlaWdodD17aGVpZ2h0fSBmaWxsPVwidXJsKCNjYWQtZ3JpZClcIiByeD1cIjhcIiAvPlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiAxLiBMw61uZWFzIENvbmVjdG9yYXMgUHJpbWFyaWFzIC8gTm9ybWFsZXMgKENBRCBPcnRvZ29uYWwgY29uIGZsZWNoYXMpICovfVxuICAgICAgICAgICAgICB7bm9kZXMubWFwKChub2RlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFub2RlLnBhcmVudElkKSByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgICBjb25zdCBwYXJlbnRDb29yZHMgPSBnZXROb2RlQ29vcmRzKG5vZGUucGFyZW50SWQpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGNoaWxkQ29vcmRzID0gZ2V0Tm9kZUNvb3Jkcyhub2RlLmlkKTtcblxuICAgICAgICAgICAgICAgIC8vIEzDrW5lYSBjb24gw6FuZ3VsbyBkZSA5MMKwIChPcnRvZ29uYWwpXG4gICAgICAgICAgICAgICAgY29uc3QgbWlkWSA9IChwYXJlbnRDb29yZHMueSArIGNoaWxkQ29vcmRzLnkpIC8gMjtcbiAgICAgICAgICAgICAgICBjb25zdCBwYXRoRGF0YSA9IGBNICR7cGFyZW50Q29vcmRzLnh9ICR7cGFyZW50Q29vcmRzLnl9IEwgJHtwYXJlbnRDb29yZHMueH0gJHttaWRZfSBMICR7Y2hpbGRDb29yZHMueH0gJHttaWRZfSBMICR7Y2hpbGRDb29yZHMueH0gJHtjaGlsZENvb3Jkcy55fWA7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPGcga2V5PXtgbGluay0ke25vZGUuaWR9YH0+XG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIFxuICAgICAgICAgICAgICAgICAgICAgIGQ9e3BhdGhEYXRhfSBcbiAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiIFxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cInRyYW5zcGFyZW50XCIgXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIxMFwiIFxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBcbiAgICAgICAgICAgICAgICAgICAgICBkPXtwYXRoRGF0YX0gXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIiBcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9e2lzRGFya1RoZW1lID8gJyM0NzU1NjknIDogJyMwMDAwMDAnfSBcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17aXNEYXJrVGhlbWUgPyAnMi41JyA6ICcxLjUnfSBcbiAgICAgICAgICAgICAgICAgICAgICBtYXJrZXJFbmQ9e2lzRGFya1RoZW1lID8gJ3VybCgjYXJyb3ctc2xhdGUpJyA6ICd1cmwoI2Fycm93LWJsYWNrKSd9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2c+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgey8qIDEuMiBMw61uZWFzIENvbmVjdG9yYXMgZGUgRW1lcmdlbmNpYSAoR2VuZXJhZG9yIC0+IEFUUy9NVFMpIChPYnNlcnZhY2nDs24gMTgpICovfVxuICAgICAgICAgICAgICB7ZW1lcmdlbmN5TGlua3MubWFwKChsaW5rKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgZ2VuQ29vcmRzID0gZ2V0Tm9kZUNvb3JkcyhsaW5rLnNvdXJjZUlkKTtcbiAgICAgICAgICAgICAgICBjb25zdCBhdHNDb29yZHMgPSBnZXROb2RlQ29vcmRzKGxpbmsudGFyZ2V0SWQpO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIC8vIENvbmVjdGFyIGRlc2RlIGVsIGxhZG8gZGVyZWNobyBkZWwgR2VuZXJhZG9yIGhhY2lhIGxhIGVudHJhZGEgZGUgZW1lcmdlbmNpYSBkZWwgQVRTXG4gICAgICAgICAgICAgICAgY29uc3QgbWlkWCA9IChnZW5Db29yZHMueCArIGF0c0Nvb3Jkcy54KSAvIDI7XG4gICAgICAgICAgICAgICAgY29uc3QgbWlkWSA9IChnZW5Db29yZHMueSArIGF0c0Nvb3Jkcy55KSAvIDI7XG4gICAgICAgICAgICAgICAgY29uc3QgcGF0aERhdGEgPSBgTSAke2dlbkNvb3Jkcy54fSAke2dlbkNvb3Jkcy55fSBMICR7bWlkWH0gJHtnZW5Db29yZHMueX0gTCAke21pZFh9ICR7YXRzQ29vcmRzLnl9IEwgJHthdHNDb29yZHMueH0gJHthdHNDb29yZHMueX1gO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxnIGtleT17bGluay5pZH0+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBMw61uZWEgZGlzY29udGludWEgZGUgZW1lcmdlbmNpYSAqL31cbiAgICAgICAgICAgICAgICAgICAgPHBhdGggXG4gICAgICAgICAgICAgICAgICAgICAgZD17cGF0aERhdGF9IFxuICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCIgXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPXtpc0RhcmtUaGVtZSA/ICcjZjU5ZTBiJyA6ICcjZDk3NzA2J30gXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9e2lzRGFya1RoZW1lID8gJzIuNScgOiAnMid9IFxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZURhc2hhcnJheT1cIjYsNFwiXG4gICAgICAgICAgICAgICAgICAgICAgbWFya2VyRW5kPVwidXJsKCNhcnJvdy1hbWJlcilcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICB7LyogQmFkZ2UgZGUgRW1lcmdlbmNpYSAqL31cbiAgICAgICAgICAgICAgICAgICAgPHJlY3QgXG4gICAgICAgICAgICAgICAgICAgICAgeD17bWlkWCAtIDM4fSBcbiAgICAgICAgICAgICAgICAgICAgICB5PXttaWRZIC0gOH0gXG4gICAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI3NlwiIFxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjE2XCIgXG4gICAgICAgICAgICAgICAgICAgICAgcng9XCI0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD17aXNEYXJrVGhlbWUgPyAnIzFlMWI0YicgOiAnI2ZlZjNjNyd9IFxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cIiNmNTllMGJcIiBcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjFcIiBcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPHRleHQgXG4gICAgICAgICAgICAgICAgICAgICAgeD17bWlkWH0gXG4gICAgICAgICAgICAgICAgICAgICAgeT17bWlkWSArIDN9IFxuICAgICAgICAgICAgICAgICAgICAgIHRleHRBbmNob3I9XCJtaWRkbGVcIiBcbiAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cIjcuNVwiIFxuICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ9XCJibGFja1wiIFxuICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZjU5ZTBiXCIgXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tb25vIHNlbGVjdC1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEVNRVJHRU5DSUEgKEcpXG4gICAgICAgICAgICAgICAgICAgIDwvdGV4dD5cbiAgICAgICAgICAgICAgICAgIDwvZz5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICB9KX1cblxuICAgICAgICAgICAgICB7LyogMi4gRGlidWphciBOb2RvcyAqL31cbiAgICAgICAgICAgICAge25vZGVzLm1hcCgobm9kZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvb3JkcyA9IGdldE5vZGVDb29yZHMobm9kZS5pZCk7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHNlbGVjdGVkTm9kZUlkID09PSBub2RlLmlkO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxnIFxuICAgICAgICAgICAgICAgICAgICBrZXk9e25vZGUuaWR9IFxuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm09e2B0cmFuc2xhdGUoJHtjb29yZHMueH0sICR7Y29vcmRzLnl9KWB9XG4gICAgICAgICAgICAgICAgICAgIGRhdGEtbm9kZWlkPXtub2RlLmlkfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJub2RlLWVsZW1lbnQgZ3JvdXAgY3Vyc29yLWdyYWIgYWN0aXZlOmN1cnNvci1ncmFiYmluZ1wiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAob25Ob2RlU2VsZWN0KSBvbk5vZGVTZWxlY3Qobm9kZSk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIG9uTW91c2VEb3duPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGlmICghaW50ZXJhY3RpdmUpIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZURyYWdOb2RlSWQobm9kZS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0RHJhZ1N0YXJ0TW91c2UoeyB4OiBlLmNsaWVudFgsIHk6IGUuY2xpZW50WSB9KTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXREcmFnU3RhcnROb2RlUG9zKGNvb3Jkcyk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBPdXRsaW5lIGRlIFNlbGVjY2nDs24gKEVzdGlsbyBDQUQgZmx1b3Jlc2NlbnRlKSAqL31cbiAgICAgICAgICAgICAgICAgICAge2lzRGFya1RoZW1lICYmIGlzU2VsZWN0ZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxyZWN0IFxuICAgICAgICAgICAgICAgICAgICAgICAgeD1cIi0zNFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgeT1cIi0yNlwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI2OFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiNTJcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIHJ4PVwiOFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cIiNmNTllMGJcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMi41XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VEYXNoYXJyYXk9XCI0LDNcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFuaW1hdGUtcHVsc2VcIiBcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTw61tYm9sbyBkZSBDb21wb25lbnRlICovfVxuICAgICAgICAgICAgICAgICAgICB7cmVuZGVyTm9kZVN5bWJvbChub2RlLnRpcG9FbGVtZW50bywgIWlzRGFya1RoZW1lKX1cblxuICAgICAgICAgICAgICAgICAgICB7LyogVGV4dG8gZGVsIE5vbWJyZSBkZWwgRXF1aXBvICovfVxuICAgICAgICAgICAgICAgICAgICA8dGV4dCBcbiAgICAgICAgICAgICAgICAgICAgICB4PVwiMFwiIFxuICAgICAgICAgICAgICAgICAgICAgIHk9XCIzNlwiIFxuICAgICAgICAgICAgICAgICAgICAgIHRleHRBbmNob3I9XCJtaWRkbGVcIiBcbiAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cIjkuNVwiXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodD1cImJsYWNrXCJcbiAgICAgICAgICAgICAgICAgICAgICBmaWxsPXtpc0RhcmtUaGVtZSA/IChpc1NlbGVjdGVkID8gJyNmNTllMGInIDogJyNjYmQ1ZTEnKSA6ICcjMDAwMDAwJ31cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LXNhbnMgc2VsZWN0LW5vbmUgdHJhY2tpbmctd2lkZVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7bm9kZS5ub21icmUubGVuZ3RoID4gMjIgPyBgJHtub2RlLm5vbWJyZS5zbGljZSgwLCAyMCl9Li4uYCA6IG5vZGUubm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICA8L3RleHQ+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIElkZW50aWZpY2Fkb3IgKElEKSBkZWwgRXF1aXBvICovfVxuICAgICAgICAgICAgICAgICAgICA8dGV4dCBcbiAgICAgICAgICAgICAgICAgICAgICB4PVwiMFwiIFxuICAgICAgICAgICAgICAgICAgICAgIHk9XCItMjhcIiBcbiAgICAgICAgICAgICAgICAgICAgICB0ZXh0QW5jaG9yPVwibWlkZGxlXCIgXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCI4XCJcbiAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0PVwiYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD17aXNEYXJrVGhlbWUgPyAnIzY0NzQ4YicgOiAnIzMzNDE1NSd9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tb25vIHNlbGVjdC1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtub2RlLmlkfVxuICAgICAgICAgICAgICAgICAgICA8L3RleHQ+XG4gICAgICAgICAgICAgICAgICA8L2c+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTGV5ZW5kYSB5IENhamV0w61uIGVuIGxhIHBhcnRlIGluZmVyaW9yIHBhcmEgZWwgSW5mb3JtZSB5IFBERiBpbXByZXNvICovfVxuICAgICAgeyFpc0RhcmtUaGVtZSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00IGJvcmRlci10LTIgYm9yZGVyLWJsYWNrIHB0LTQgZm9udC1tb25vIHRleHQtYmxhY2sgdGV4dC1bMTBweF0gdXBwZXJjYXNlXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIENvbHVtbmEgMSB5IDI6IExFWUVOREEgVMOJQ05JQ0EgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yIGJvcmRlciBib3JkZXItYmxhY2sgcC0zIHJvdW5kZWQgYmctd2hpdGVcIj5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJsYWNrIHRleHQteHMgYm9yZGVyLWIgYm9yZGVyLWJsYWNrIHBiLTEgbWItMlwiPkxleWVuZGEgVW5pZmlsYXI8L2g0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy0zIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgY2xhc3NOYW1lPVwib3ZlcmZsb3ctdmlzaWJsZSBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgPHJlY3QgeD1cIjJcIiB5PVwiMlwiIHdpZHRoPVwiMjBcIiBoZWlnaHQ9XCIyMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiYmxhY2tcIiBzdHJva2VXaWR0aD1cIjEuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjEyXCIgeTE9XCIyXCIgeDI9XCIxMlwiIHkyPVwiMjJcIiBzdHJva2U9XCJibGFja1wiIHN0cm9rZVdpZHRoPVwiMVwiIHN0cm9rZURhc2hhcnJheT1cIjEsMVwiIC8+XG4gICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgPHNwYW4+VGFibGVybyAvIFBhbmVsPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgY2xhc3NOYW1lPVwib3ZlcmZsb3ctdmlzaWJsZSBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCI3XCIgcj1cIjhcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImJsYWNrXCIgc3Ryb2tlV2lkdGg9XCIxLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxN1wiIHI9XCI4XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJibGFja1wiIHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5UcmFuc2Zvcm1hZG9yPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgY2xhc3NOYW1lPVwib3ZlcmZsb3ctdmlzaWJsZSBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIxMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiYmxhY2tcIiBzdHJva2VXaWR0aD1cIjEuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiMTJcIiB5PVwiMTVcIiB0ZXh0QW5jaG9yPVwibWlkZGxlXCIgZm9udFNpemU9XCIxMFwiIGZvbnRXZWlnaHQ9XCJib2xkXCI+RzwvdGV4dD5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5HZW5lcmFkb3I8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjI0XCIgaGVpZ2h0PVwiMjRcIiBjbGFzc05hbWU9XCJvdmVyZmxvdy12aXNpYmxlIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICA8cmVjdCB4PVwiMlwiIHk9XCI1XCIgd2lkdGg9XCIyMFwiIGhlaWdodD1cIjE0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJibGFja1wiIHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCIxMlwiIHk9XCIxNVwiIHRleHRBbmNob3I9XCJtaWRkbGVcIiBmb250U2l6ZT1cIjdcIiBmb250V2VpZ2h0PVwiYm9sZFwiPkFUUzwvdGV4dD5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5UcmFuc2ZlciAoQVRTKTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIGNsYXNzTmFtZT1cIm92ZXJmbG93LXZpc2libGUgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiOVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiYmxhY2tcIiBzdHJva2VXaWR0aD1cIjEuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjlcIiB5MT1cIjhcIiB4Mj1cIjlcIiB5Mj1cIjE2XCIgc3Ryb2tlPVwiYmxhY2tcIiBzdHJva2VXaWR0aD1cIjEuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjE1XCIgeTE9XCI4XCIgeDI9XCIxNVwiIHkyPVwiMTZcIiBzdHJva2U9XCJibGFja1wiIHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5CYW5jbyBDb25kZW5zLjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIGNsYXNzTmFtZT1cIm92ZXJmbG93LXZpc2libGUgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgIDxsaW5lIHgxPVwiMTJcIiB5MT1cIjJcIiB4Mj1cIjEyXCIgeTI9XCIxNFwiIHN0cm9rZT1cImJsYWNrXCIgc3Ryb2tlV2lkdGg9XCIxLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPGxpbmUgeDE9XCI0XCIgeTE9XCIxNFwiIHgyPVwiMjBcIiB5Mj1cIjE0XCIgc3Ryb2tlPVwiYmxhY2tcIiBzdHJva2VXaWR0aD1cIjEuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjhcIiB5MT1cIjE4XCIgeDI9XCIxNlwiIHkyPVwiMThcIiBzdHJva2U9XCJibGFja1wiIHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5QdWVzdGEgYSBUaWVycmE8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ29sdW1uYSAzOiBDQUpFVMONTiBERSBEQVRPUyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItYmxhY2sgcC0zIHJvdW5kZWQgYmctd2hpdGUgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteS0xXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ibGFjayBwYi0xIG1iLTEuNSBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ibGFjayB0ZXh0LXhzXCI+RGF0b3MgZGVsIFBsYW5vPC9oND5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs4cHhdIGJnLWJsYWNrIHRleHQtd2hpdGUgcHgtMS41IHB5LTAuNSByb3VuZGVkIGZvbnQtc2Fuc1wiPkNBRDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+PHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMFwiPkVtcHJlc2E6PC9zdHJvbmc+IHtjb21wYW55TmFtZX08L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+PHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMFwiPlByb3llY3RvOjwvc3Ryb25nPiB7cHJvamVjdE5hbWV9PC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPjxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDBcIj5Db250ZW5pZG86PC9zdHJvbmc+IERpYWdyYW1hIFVuaWZpbGFyPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWJsYWNrLzMwIHB0LTEuNSB0ZXh0LVs4cHhdIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB0ZXh0LXNsYXRlLTYwMCBmb250LXNhbnNcIj5cbiAgICAgICAgICAgICAgPHNwYW4+RmVjaGE6IHtuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZygnZXMtRVMnKX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWJsYWNrIGZvbnQtYm9sZCB0ZXh0LVs5cHhdIGJvcmRlciBib3JkZXItYmxhY2sgcHgtMVwiPlBMQU5PIE7CsCBJRS0wMTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==