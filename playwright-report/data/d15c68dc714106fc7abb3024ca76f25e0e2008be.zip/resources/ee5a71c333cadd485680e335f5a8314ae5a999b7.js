import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/ConfirmContext.jsx");const React = __vite__cjsImport0_react; const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import ModalConfirmacion from "/src/components/ModalConfirmacion.jsx";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/context/ConfirmContext.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const ConfirmContext = createContext(null);
_c = ConfirmContext;
export const ConfirmProvider = ({ children }) => {
	_s();
	const [modalState, setModalState] = useState({
		isOpen: false,
		title: "",
		message: "",
		type: "danger",
		confirmText: "Confirmar",
		cancelText: "Cancelar",
		isAlert: false
	});
	// Referencia a la función de resolución de la Promesa
	const resolverRef = useRef(null);
	/**
	* confirm: Abre un diálogo de confirmación asíncrono que retorna una Promesa booleana.
	* @param {string|object} options - Mensaje en texto o configuración completa
	*/
	const confirm = useCallback((options) => {
		return new Promise((resolve) => {
			resolverRef.current = resolve;
			if (typeof options === "string") {
				setModalState({
					isOpen: true,
					title: "Confirmar acción",
					message: options,
					type: "danger",
					confirmText: "Confirmar",
					cancelText: "Cancelar",
					isAlert: false
				});
			} else {
				const { title = "Confirmar acción", message = "", type = "danger", confirmText = "Confirmar", cancelText = "Cancelar" } = options || {};
				setModalState({
					isOpen: true,
					title,
					message,
					type,
					confirmText,
					cancelText,
					isAlert: false
				});
			}
		});
	}, []);
	/**
	* alert: Abre un diálogo de alerta asíncrono estilizado con un solo botón de aceptación.
	* @param {string|object} options - Mensaje en texto o configuración completa
	*/
	const alert = useCallback((options) => {
		return new Promise((resolve) => {
			resolverRef.current = resolve;
			if (typeof options === "string") {
				setModalState({
					isOpen: true,
					title: "Notificación",
					message: options,
					type: "warning",
					confirmText: "Entendido",
					cancelText: "",
					isAlert: true
				});
			} else {
				const { title = "Notificación", message = "", type = "warning", confirmText = "Entendido" } = options || {};
				setModalState({
					isOpen: true,
					title,
					message,
					type,
					confirmText,
					cancelText: "",
					isAlert: true
				});
			}
		});
	}, []);
	const handleConfirm = useCallback(() => {
		setModalState((prev) => ({
			...prev,
			isOpen: false
		}));
		if (resolverRef.current) {
			resolverRef.current(true);
			resolverRef.current = null;
		}
	}, []);
	const handleCancel = useCallback(() => {
		setModalState((prev) => ({
			...prev,
			isOpen: false
		}));
		if (resolverRef.current) {
			resolverRef.current(false);
			resolverRef.current = null;
		}
	}, []);
	return /* @__PURE__ */ _jsxDEV(ConfirmContext.Provider, {
		value: {
			confirm,
			alert
		},
		children: [children, /* @__PURE__ */ _jsxDEV(ModalConfirmacion, {
			isOpen: modalState.isOpen,
			title: modalState.title,
			message: modalState.message,
			type: modalState.type,
			confirmText: modalState.confirmText,
			cancelText: modalState.cancelText,
			isAlert: modalState.isAlert,
			onConfirm: handleConfirm,
			onCancel: handleCancel
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 118,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 116,
		columnNumber: 5
	}, this);
};
_s(ConfirmProvider, "Cxx9zYlUAIYtgOMDftNX/IsXEUI=");
_c2 = ConfirmProvider;
export const useConfirm = () => {
	_s2();
	const context = useContext(ConfirmContext);
	if (!context) {
		throw new Error("useConfirm debe ser utilizado dentro de un ConfirmProvider");
	}
	return context;
};
_s2(useConfirm, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
export default ConfirmContext;
var _c, _c2;
$RefreshReg$(_c, "ConfirmContext");
$RefreshReg$(_c2, "ConfirmProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/ConfirmContext.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/context/ConfirmContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/context/ConfirmContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/context/ConfirmContext.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGVBQWUsWUFBWSxVQUFVLGFBQWEsY0FBYztBQUNoRixPQUFPLHVCQUF1Qjs7OztBQUU5QixNQUFNLGlCQUFpQixjQUFjLElBQUk7O0FBRXpDLE9BQU8sTUFBTSxtQkFBbUIsRUFBRSxlQUFlOztDQUMvQyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUztFQUMzQyxRQUFRO0VBQ1IsT0FBTztFQUNQLFNBQVM7RUFDVCxNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixTQUFTO0NBQ1gsQ0FBQzs7Q0FHRCxNQUFNLGNBQWMsT0FBTyxJQUFJOzs7OztDQU0vQixNQUFNLFVBQVUsYUFBYSxZQUFZO0VBQ3ZDLE9BQU8sSUFBSSxTQUFTLFlBQVk7R0FDOUIsWUFBWSxVQUFVO0dBRXRCLElBQUksT0FBTyxZQUFZLFVBQVU7SUFDL0IsY0FBYztLQUNaLFFBQVE7S0FDUixPQUFPO0tBQ1AsU0FBUztLQUNULE1BQU07S0FDTixhQUFhO0tBQ2IsWUFBWTtLQUNaLFNBQVM7SUFDWCxDQUFDO0dBQ0gsT0FBTztJQUNMLE1BQU0sRUFDSixRQUFRLG9CQUNSLFVBQVUsSUFDVixPQUFPLFVBQ1AsY0FBYyxhQUNkLGFBQWEsZUFDWCxXQUFXLENBQUM7SUFFaEIsY0FBYztLQUNaLFFBQVE7S0FDUjtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0EsU0FBUztJQUNYLENBQUM7R0FDSDtFQUNGLENBQUM7Q0FDSCxHQUFHLENBQUMsQ0FBQzs7Ozs7Q0FNTCxNQUFNLFFBQVEsYUFBYSxZQUFZO0VBQ3JDLE9BQU8sSUFBSSxTQUFTLFlBQVk7R0FDOUIsWUFBWSxVQUFVO0dBRXRCLElBQUksT0FBTyxZQUFZLFVBQVU7SUFDL0IsY0FBYztLQUNaLFFBQVE7S0FDUixPQUFPO0tBQ1AsU0FBUztLQUNULE1BQU07S0FDTixhQUFhO0tBQ2IsWUFBWTtLQUNaLFNBQVM7SUFDWCxDQUFDO0dBQ0gsT0FBTztJQUNMLE1BQU0sRUFDSixRQUFRLGdCQUNSLFVBQVUsSUFDVixPQUFPLFdBQ1AsY0FBYyxnQkFDWixXQUFXLENBQUM7SUFFaEIsY0FBYztLQUNaLFFBQVE7S0FDUjtLQUNBO0tBQ0E7S0FDQTtLQUNBLFlBQVk7S0FDWixTQUFTO0lBQ1gsQ0FBQztHQUNIO0VBQ0YsQ0FBQztDQUNILEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxnQkFBZ0Isa0JBQWtCO0VBQ3RDLGVBQWUsVUFBVTtHQUFFLEdBQUc7R0FBTSxRQUFRO0VBQU0sRUFBRTtFQUNwRCxJQUFJLFlBQVksU0FBUztHQUN2QixZQUFZLFFBQVEsSUFBSTtHQUN4QixZQUFZLFVBQVU7RUFDeEI7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sZUFBZSxrQkFBa0I7RUFDckMsZUFBZSxVQUFVO0dBQUUsR0FBRztHQUFNLFFBQVE7RUFBTSxFQUFFO0VBQ3BELElBQUksWUFBWSxTQUFTO0dBQ3ZCLFlBQVksUUFBUSxLQUFLO0dBQ3pCLFlBQVksVUFBVTtFQUN4QjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsT0FDRSx3QkFBQyxlQUFlLFVBQWhCO0VBQXlCLE9BQU87R0FBRTtHQUFTO0VBQU07WUFBakQsQ0FDRyxVQUNELHdCQUFDLG1CQUFEO0dBQ0UsUUFBUSxXQUFXO0dBQ25CLE9BQU8sV0FBVztHQUNsQixTQUFTLFdBQVc7R0FDcEIsTUFBTSxXQUFXO0dBQ2pCLGFBQWEsV0FBVztHQUN4QixZQUFZLFdBQVc7R0FDdkIsU0FBUyxXQUFXO0dBQ3BCLFdBQVc7R0FDWCxVQUFVO0VBQ1g7Ozs7VUFDc0I7Ozs7OztBQUU3Qjs7O0FBRUEsT0FBTyxNQUFNLG1CQUFtQjs7Q0FDOUIsTUFBTSxVQUFVLFdBQVcsY0FBYztDQUN6QyxJQUFJLENBQUMsU0FBUztFQUNaLE1BQU0sSUFBSSxNQUFNLDREQUE0RDtDQUM5RTtDQUNBLE9BQU87QUFDVDs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNvbmZpcm1Db250ZXh0LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrLCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgTW9kYWxDb25maXJtYWNpb24gZnJvbSAnLi4vY29tcG9uZW50cy9Nb2RhbENvbmZpcm1hY2lvbic7XG5cbmNvbnN0IENvbmZpcm1Db250ZXh0ID0gY3JlYXRlQ29udGV4dChudWxsKTtcblxuZXhwb3J0IGNvbnN0IENvbmZpcm1Qcm92aWRlciA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgY29uc3QgW21vZGFsU3RhdGUsIHNldE1vZGFsU3RhdGVdID0gdXNlU3RhdGUoe1xuICAgIGlzT3BlbjogZmFsc2UsXG4gICAgdGl0bGU6ICcnLFxuICAgIG1lc3NhZ2U6ICcnLFxuICAgIHR5cGU6ICdkYW5nZXInLCAvLyAnZGFuZ2VyJyB8ICd3YXJuaW5nJyB8ICdpbmZvJ1xuICAgIGNvbmZpcm1UZXh0OiAnQ29uZmlybWFyJyxcbiAgICBjYW5jZWxUZXh0OiAnQ2FuY2VsYXInLFxuICAgIGlzQWxlcnQ6IGZhbHNlLFxuICB9KTtcblxuICAvLyBSZWZlcmVuY2lhIGEgbGEgZnVuY2nDs24gZGUgcmVzb2x1Y2nDs24gZGUgbGEgUHJvbWVzYVxuICBjb25zdCByZXNvbHZlclJlZiA9IHVzZVJlZihudWxsKTtcblxuICAvKipcbiAgICogY29uZmlybTogQWJyZSB1biBkacOhbG9nbyBkZSBjb25maXJtYWNpw7NuIGFzw61uY3Jvbm8gcXVlIHJldG9ybmEgdW5hIFByb21lc2EgYm9vbGVhbmEuXG4gICAqIEBwYXJhbSB7c3RyaW5nfG9iamVjdH0gb3B0aW9ucyAtIE1lbnNhamUgZW4gdGV4dG8gbyBjb25maWd1cmFjacOzbiBjb21wbGV0YVxuICAgKi9cbiAgY29uc3QgY29uZmlybSA9IHVzZUNhbGxiYWNrKChvcHRpb25zKSA9PiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICByZXNvbHZlclJlZi5jdXJyZW50ID0gcmVzb2x2ZTtcblxuICAgICAgaWYgKHR5cGVvZiBvcHRpb25zID09PSAnc3RyaW5nJykge1xuICAgICAgICBzZXRNb2RhbFN0YXRlKHtcbiAgICAgICAgICBpc09wZW46IHRydWUsXG4gICAgICAgICAgdGl0bGU6ICdDb25maXJtYXIgYWNjacOzbicsXG4gICAgICAgICAgbWVzc2FnZTogb3B0aW9ucyxcbiAgICAgICAgICB0eXBlOiAnZGFuZ2VyJyxcbiAgICAgICAgICBjb25maXJtVGV4dDogJ0NvbmZpcm1hcicsXG4gICAgICAgICAgY2FuY2VsVGV4dDogJ0NhbmNlbGFyJyxcbiAgICAgICAgICBpc0FsZXJ0OiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgdGl0bGUgPSAnQ29uZmlybWFyIGFjY2nDs24nLFxuICAgICAgICAgIG1lc3NhZ2UgPSAnJyxcbiAgICAgICAgICB0eXBlID0gJ2RhbmdlcicsXG4gICAgICAgICAgY29uZmlybVRleHQgPSAnQ29uZmlybWFyJyxcbiAgICAgICAgICBjYW5jZWxUZXh0ID0gJ0NhbmNlbGFyJyxcbiAgICAgICAgfSA9IG9wdGlvbnMgfHwge307XG5cbiAgICAgICAgc2V0TW9kYWxTdGF0ZSh7XG4gICAgICAgICAgaXNPcGVuOiB0cnVlLFxuICAgICAgICAgIHRpdGxlLFxuICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgdHlwZSxcbiAgICAgICAgICBjb25maXJtVGV4dCxcbiAgICAgICAgICBjYW5jZWxUZXh0LFxuICAgICAgICAgIGlzQWxlcnQ6IGZhbHNlLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSwgW10pO1xuXG4gIC8qKlxuICAgKiBhbGVydDogQWJyZSB1biBkacOhbG9nbyBkZSBhbGVydGEgYXPDrW5jcm9ubyBlc3RpbGl6YWRvIGNvbiB1biBzb2xvIGJvdMOzbiBkZSBhY2VwdGFjacOzbi5cbiAgICogQHBhcmFtIHtzdHJpbmd8b2JqZWN0fSBvcHRpb25zIC0gTWVuc2FqZSBlbiB0ZXh0byBvIGNvbmZpZ3VyYWNpw7NuIGNvbXBsZXRhXG4gICAqL1xuICBjb25zdCBhbGVydCA9IHVzZUNhbGxiYWNrKChvcHRpb25zKSA9PiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICByZXNvbHZlclJlZi5jdXJyZW50ID0gcmVzb2x2ZTtcblxuICAgICAgaWYgKHR5cGVvZiBvcHRpb25zID09PSAnc3RyaW5nJykge1xuICAgICAgICBzZXRNb2RhbFN0YXRlKHtcbiAgICAgICAgICBpc09wZW46IHRydWUsXG4gICAgICAgICAgdGl0bGU6ICdOb3RpZmljYWNpw7NuJyxcbiAgICAgICAgICBtZXNzYWdlOiBvcHRpb25zLFxuICAgICAgICAgIHR5cGU6ICd3YXJuaW5nJyxcbiAgICAgICAgICBjb25maXJtVGV4dDogJ0VudGVuZGlkbycsXG4gICAgICAgICAgY2FuY2VsVGV4dDogJycsXG4gICAgICAgICAgaXNBbGVydDogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgdGl0bGUgPSAnTm90aWZpY2FjacOzbicsXG4gICAgICAgICAgbWVzc2FnZSA9ICcnLFxuICAgICAgICAgIHR5cGUgPSAnd2FybmluZycsXG4gICAgICAgICAgY29uZmlybVRleHQgPSAnRW50ZW5kaWRvJyxcbiAgICAgICAgfSA9IG9wdGlvbnMgfHwge307XG5cbiAgICAgICAgc2V0TW9kYWxTdGF0ZSh7XG4gICAgICAgICAgaXNPcGVuOiB0cnVlLFxuICAgICAgICAgIHRpdGxlLFxuICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgdHlwZSxcbiAgICAgICAgICBjb25maXJtVGV4dCxcbiAgICAgICAgICBjYW5jZWxUZXh0OiAnJyxcbiAgICAgICAgICBpc0FsZXJ0OiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGhhbmRsZUNvbmZpcm0gPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgc2V0TW9kYWxTdGF0ZSgocHJldikgPT4gKHsgLi4ucHJldiwgaXNPcGVuOiBmYWxzZSB9KSk7XG4gICAgaWYgKHJlc29sdmVyUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJlc29sdmVyUmVmLmN1cnJlbnQodHJ1ZSk7XG4gICAgICByZXNvbHZlclJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gIH0sIFtdKTtcblxuICBjb25zdCBoYW5kbGVDYW5jZWwgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgc2V0TW9kYWxTdGF0ZSgocHJldikgPT4gKHsgLi4ucHJldiwgaXNPcGVuOiBmYWxzZSB9KSk7XG4gICAgaWYgKHJlc29sdmVyUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJlc29sdmVyUmVmLmN1cnJlbnQoZmFsc2UpO1xuICAgICAgcmVzb2x2ZXJSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8Q29uZmlybUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgY29uZmlybSwgYWxlcnQgfX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgICA8TW9kYWxDb25maXJtYWNpb25cbiAgICAgICAgaXNPcGVuPXttb2RhbFN0YXRlLmlzT3Blbn1cbiAgICAgICAgdGl0bGU9e21vZGFsU3RhdGUudGl0bGV9XG4gICAgICAgIG1lc3NhZ2U9e21vZGFsU3RhdGUubWVzc2FnZX1cbiAgICAgICAgdHlwZT17bW9kYWxTdGF0ZS50eXBlfVxuICAgICAgICBjb25maXJtVGV4dD17bW9kYWxTdGF0ZS5jb25maXJtVGV4dH1cbiAgICAgICAgY2FuY2VsVGV4dD17bW9kYWxTdGF0ZS5jYW5jZWxUZXh0fVxuICAgICAgICBpc0FsZXJ0PXttb2RhbFN0YXRlLmlzQWxlcnR9XG4gICAgICAgIG9uQ29uZmlybT17aGFuZGxlQ29uZmlybX1cbiAgICAgICAgb25DYW5jZWw9e2hhbmRsZUNhbmNlbH1cbiAgICAgIC8+XG4gICAgPC9Db25maXJtQ29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn07XG5cbmV4cG9ydCBjb25zdCB1c2VDb25maXJtID0gKCkgPT4ge1xuICBjb25zdCBjb250ZXh0ID0gdXNlQ29udGV4dChDb25maXJtQ29udGV4dCk7XG4gIGlmICghY29udGV4dCkge1xuICAgIHRocm93IG5ldyBFcnJvcigndXNlQ29uZmlybSBkZWJlIHNlciB1dGlsaXphZG8gZGVudHJvIGRlIHVuIENvbmZpcm1Qcm92aWRlcicpO1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQ29uZmlybUNvbnRleHQ7XG4iXX0=