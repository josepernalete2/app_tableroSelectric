import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PuntoMedicionComponent.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { Zap, Building2, FileText, ShieldCheck, Gauge, AlertCircle, Printer, User, Calendar, Clock, CheckSquare, Activity, Settings, RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import ModalEdicionCircuito from "/src/components/ModalEdicionCircuito.jsx?t=1790793566895";
import MetrologiaElectricaSection from "/src/components/MetrologiaElectricaSection.jsx";
import { TENSIONES_COVENIN_TODAS } from "/src/utils/constants.js";
import useStore from "/src/store/useStore.js?t=1790792337841";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/PuntoMedicionComponent.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function PuntoMedicionComponent({ puntoData, onUpdate, readOnly }) {
	_s();
	const { crearElementoProvisional } = useStore();
	const [modalJerarquiaOpen, setModalJerarquiaOpen] = useState(false);
	const [circuitDataWizard, setCircuitDataWizard] = useState(null);
	const [wizardModo, setWizardModo] = useState("ENTRADA");
	if (!puntoData) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center p-8 text-slate-400",
			children: "No hay datos de punto de medición seleccionados."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 12
		}, this);
	}
	const { id, nombre = "", fecha = "", hora = "", inspector = "", nombreUsuario = "", numeroContrato = "", empresaDistribuidora = "", nivelTensionContrato = "", tensionNominal = "", potenciaContratada = "", tarifaAplicable = "", codigoElementoPrincipal = "", tipoAcometida = "", puntoConexionPCC = "", conductorAcometida = "", longitudAcometida = "", elementoManiobra = "", capacidadInterrupcion = "", ubicacionTransformador = "", propiedadTransformador = "", usoTransformador = "", ubicacionMedidor = "", tipoMedicion = "", marcaModeloMedidor = "", numeroSerieAno = "", observaciones = "", firmaInspector = "", firmaSupervisor = "" } = puntoData;
	const updateField = (field, value) => {
		if (readOnly) return;
		onUpdate({
			...puntoData,
			[field]: value
		});
	};
	const handleLimpiarFormulario = () => {
		if (readOnly) return;
		onUpdate({
			id: puntoData.id,
			nombre: puntoData.nombre || "",
			fecha: "",
			hora: "",
			inspector: "",
			nombreUsuario: "",
			numeroContrato: "",
			empresaDistribuidora: "",
			nivelTensionContrato: "",
			tensionNominal: "",
			potenciaContratada: "",
			tarifaAplicable: "",
			codigoElementoPrincipal: "",
			tipoAcometida: "",
			puntoConexionPCC: "",
			conductorAcometida: "",
			longitudAcometida: "",
			elementoManiobra: "",
			capacidadInterrupcion: "",
			ubicacionTransformador: "",
			propiedadTransformador: "",
			usoTransformador: "",
			ubicacionMedidor: "",
			tipoMedicion: "",
			marcaModeloMedidor: "",
			numeroSerieAno: "",
			mediciones: {},
			observaciones: "",
			firmaInspector: "",
			firmaSupervisor: ""
		});
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `w-full text-slate-100 bg-slate-900/60 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl backdrop-blur-md select-text max-w-5xl mx-auto space-y-8 print-card print:bg-white print:text-slate-900 print:border-none print:shadow-none print:p-0 print:m-0 ${readOnly ? "opacity-90" : ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-slate-800 print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-amber-500 font-extrabold uppercase tracking-widest print:text-amber-700",
						children: "Formato de Levantamiento"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl md:text-2xl font-extrabold text-slate-100 tracking-wide mt-1 print:text-slate-900",
						children: "Punto de Medición y Suministro de Energía Eléctrica"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 11
					}, this),
					nombre && /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs font-semibold text-slate-400 mt-1 print:text-slate-600",
						children: ["Identificador: ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-amber-400 print:text-slate-900",
							children: nombre
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 30
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [
						!readOnly && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleLimpiarFormulario,
							className: "no-print bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-400 font-bold px-3 py-2 rounded-xl flex items-center gap-1.5 text-xs transition-all border border-slate-700 cursor-pointer",
							title: "Reiniciar todos los campos del formulario a blanco",
							children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 15
							}, this), " Limpiar"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => window.print(),
							className: "no-print bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-2 rounded-xl flex items-center gap-2 text-xs transition-all cursor-pointer shadow-md",
							title: "Guardar como PDF o Imprimir este Formato",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 13
							}, this), " Guardar PDF"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "inline-flex items-center justify-center font-mono font-black text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/30 text-xs shadow-sm",
							children: ["ID: ", id]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 122,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-slate-50 print:border-gray-300",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-3 gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1 print:text-slate-700",
								children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 165,
									columnNumber: 15
								}, this), " Nombre del Inspector"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: inspector ?? "",
								onChange: (e) => updateField("inspector", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. Ing. Juan Pérez"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1 print:text-slate-700",
								children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 178,
									columnNumber: 15
								}, this), " Fecha del Levantamiento"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "date",
								disabled: readOnly,
								value: fecha ?? "",
								onChange: (e) => updateField("fecha", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1 print:text-slate-700",
								children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 15
								}, this), " Hora"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "time",
								disabled: readOnly,
								value: hora ?? "",
								onChange: (e) => updateField("hora", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 192,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 162,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 161,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-2.5 flex items-center gap-2 print:text-slate-900 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 206,
						columnNumber: 11
					}, this), " 1. Datos Generales de la Acometida y Suministro"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 205,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-5",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Nombre del Usuario / Razón Social"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: nombreUsuario ?? "",
								onChange: (e) => updateField("nombreUsuario", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. Industrias Eléctricas C.A."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 213,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 211,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "N° de Contrato / Cuenta / NIC"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 225,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: numeroContrato ?? "",
								onChange: (e) => updateField("numeroContrato", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. NIC-84920491"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Empresa Distribuidora (ED) / Suministrador"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 238,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: empresaDistribuidora ?? "",
								onChange: (e) => updateField("empresaDistribuidora", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. CORPOELEC / Suministrador Local"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 239,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 237,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Nivel de Tensión de Contrato"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 251,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									"Alta Tensión",
									"Media Tensión",
									"Baja Tensión"
								].map((nivel) => {
									const isSelected = nivelTensionContrato === nivel;
									return /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										disabled: readOnly,
										onClick: () => updateField("nivelTensionContrato", nivel),
										className: `py-2 px-2 text-center rounded-xl border text-[11px] font-bold transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-gray-50 print:text-slate-700 print:border-gray-300"}`,
										children: [
											"[ ",
											isSelected ? "✓" : " ",
											" ] ",
											nivel
										]
									}, nivel, true, {
										fileName: _jsxFileName,
										lineNumber: 256,
										columnNumber: 19
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 252,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 250,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
									children: "Tensión Nominal de Suministro (COVENIN 159)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 276,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									disabled: readOnly,
									list: "covenin-voltajes-medicion",
									value: tensionNominal ?? "",
									onChange: (e) => updateField("tensionNominal", e.target.value),
									className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
									placeholder: "Ej. 13.8 kV o 120/208 V (3Φ - 4 hilos)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 277,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("datalist", {
									id: "covenin-voltajes-medicion",
									children: TENSIONES_COVENIN_TODAS.map((v) => /* @__PURE__ */ _jsxDEV("option", {
										value: v,
										children: v
									}, v, false, {
										fileName: _jsxFileName,
										lineNumber: 287,
										columnNumber: 49
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 286,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 275,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Potencia Contratada / Conectada (kVA)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 293,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: potenciaContratada ?? "",
								onChange: (e) => updateField("potenciaContratada", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. 500 kVA"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 292,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Tarifa / Régimen Tarifario Aplicable"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 306,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: tarifaAplicable ?? "",
								onChange: (e) => updateField("tarifaAplicable", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. Tarifa Industrial General T-2"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 305,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Código del Elemento Principal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 319,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: codigoElementoPrincipal ?? "",
								onChange: (e) => updateField("codigoElementoPrincipal", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. ELEM-MED-01"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 320,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 318,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 209,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 204,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-2.5 flex items-center justify-between print:text-slate-900 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 336,
							columnNumber: 13
						}, this), " 2. Punto de Acometida e Infraestructura de Entrada"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						disabled: readOnly,
						onClick: () => {
							setWizardModo("ENTRADA");
							setCircuitDataWizard({
								id: "PCC_ACOMETIDA",
								nombre: "Punto de Conexión PCC / Acometida Entrada",
								equipo: puntoConexionPCC || "",
								poles: [3],
								breaker: {
									amp: "",
									marca: "",
									tipo: ""
								}
							});
							setModalJerarquiaOpen(true);
						},
						className: "no-print inline-flex items-center gap-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all shadow-sm disabled:opacity-60",
						title: "Configurar Conexión de Jerarquía (Wizard)",
						children: [/* @__PURE__ */ _jsxDEV(Settings, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 355,
							columnNumber: 13
						}, this), " Configurar Jerarquía"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 338,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 334,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-5",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5 md:col-span-2",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Tipo de Acometida"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 362,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-3 gap-3",
								children: [
									"Aérea",
									"Subterránea",
									"Mixta"
								].map((tipo) => {
									const isSelected = tipoAcometida === tipo;
									return /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										disabled: readOnly,
										onClick: () => updateField("tipoAcometida", tipo),
										className: `py-2 px-3 text-center rounded-xl border text-[11px] font-bold transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-gray-50 print:text-slate-700 print:border-gray-300"}`,
										children: [
											"[ ",
											isSelected ? "✓" : " ",
											" ] ",
											tipo
										]
									}, tipo, true, {
										fileName: _jsxFileName,
										lineNumber: 367,
										columnNumber: 19
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 363,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 361,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Punto de Conexión (PCC)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 387,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: puntoConexionPCC ?? "",
								onChange: (e) => updateField("puntoConexionPCC", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Tag / Código de Poste, Celda o Subestación"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 388,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 386,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Conductor de Acometida (Tipo / Calibre)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 400,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: conductorAcometida ?? "",
								onChange: (e) => updateField("conductorAcometida", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. 3x(1x500 kcmil) Cu TTU"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 401,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 399,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Longitud Acometida (metros)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 413,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: longitudAcometida ?? "",
								onChange: (e) => updateField("longitudAcometida", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. 45 m / 3 Fases + N"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 414,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 412,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5 md:col-span-2",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Elemento de Maniobra / Protección General"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 426,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 md:grid-cols-4 gap-2.5",
								children: [
									"Breaker",
									"Cortacircuito Fusible",
									"Seccionador",
									"Interruptor en Vacío/SF6"
								].map((elem) => {
									const isSelected = elementoManiobra === elem;
									return /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										disabled: readOnly,
										onClick: () => updateField("elementoManiobra", elem),
										className: `py-2 px-2.5 text-center rounded-xl border text-[10px] font-bold transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-gray-50 print:text-slate-700 print:border-gray-300"}`,
										children: [
											"[ ",
											isSelected ? "✓" : " ",
											" ] ",
											elem
										]
									}, elem, true, {
										fileName: _jsxFileName,
										lineNumber: 431,
										columnNumber: 19
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 427,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 425,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5 md:col-span-2",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Capacidad de Interrupción General (Marca / Modelo / Amperaje)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 451,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: capacidadInterrupcion ?? "",
								onChange: (e) => updateField("capacidadInterrupcion", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. Square D / Masterpact NW16 / 1600A - 65kA"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 452,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 450,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 359,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 333,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-2.5 flex items-center gap-2 print:text-slate-900 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 467,
						columnNumber: 11
					}, this), " 3. Sistema de Transformación (Si aplica)"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 466,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-3 gap-5",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-2",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Ubicación del Transformador"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 473,
								columnNumber: 13
							}, this), ["Intemperie (Poste/Padmounted)", "Subestación Interior / Caseta"].map((ubic) => {
								const isSelected = ubicacionTransformador === ubic;
								return /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									disabled: readOnly,
									onClick: () => updateField("ubicacionTransformador", ubic),
									className: `py-2 px-3 text-left rounded-xl border text-[10px] font-bold transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-gray-50 print:text-slate-700 print:border-gray-300"}`,
									children: [
										"[ ",
										isSelected ? "✓" : " ",
										" ] ",
										ubic
									]
								}, ubic, true, {
									fileName: _jsxFileName,
									lineNumber: 480,
									columnNumber: 17
								}, this);
							})]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 472,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-2",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Propiedad del Transformador"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 499,
								columnNumber: 13
							}, this), ["Empresa Distribuidora", "Cliente Privado"].map((prop) => {
								const isSelected = propiedadTransformador === prop;
								return /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									disabled: readOnly,
									onClick: () => updateField("propiedadTransformador", prop),
									className: `py-2 px-3 text-left rounded-xl border text-[10px] font-bold transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-gray-50 print:text-slate-700 print:border-gray-300"}`,
									children: [
										"[ ",
										isSelected ? "✓" : " ",
										" ] ",
										prop
									]
								}, prop, true, {
									fileName: _jsxFileName,
									lineNumber: 506,
									columnNumber: 17
								}, this);
							})]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 498,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-2",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Uso del Transformador"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 525,
								columnNumber: 13
							}, this), ["Exclusivo", "Compartido"].map((uso) => {
								const isSelected = usoTransformador === uso;
								return /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									disabled: readOnly,
									onClick: () => updateField("usoTransformador", uso),
									className: `py-2 px-3 text-left rounded-xl border text-[10px] font-bold transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-gray-50 print:text-slate-700 print:border-gray-300"}`,
									children: [
										"[ ",
										isSelected ? "✓" : " ",
										" ] ",
										uso
									]
								}, uso, true, {
									fileName: _jsxFileName,
									lineNumber: 532,
									columnNumber: 17
								}, this);
							})]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 524,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 470,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 465,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-2.5 flex items-center gap-2 print:text-slate-900 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV(Gauge, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 554,
						columnNumber: 11
					}, this), " 4. Especificaciones del Sistema de Medición"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 553,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-5",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Ubicación del Medidor"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 560,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-2",
								children: ["Lado de Alta/Media Tensión", "Lado de Baja Tensión"].map((ubic) => {
									const isSelected = ubicacionMedidor === ubic;
									return /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										disabled: readOnly,
										onClick: () => updateField("ubicacionMedidor", ubic),
										className: `py-2 px-2 text-center rounded-xl border text-[10px] font-bold transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-gray-50 print:text-slate-700 print:border-gray-300"}`,
										children: [
											"[ ",
											isSelected ? "✓" : " ",
											" ] ",
											ubic
										]
									}, ubic, true, {
										fileName: _jsxFileName,
										lineNumber: 568,
										columnNumber: 19
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 561,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 559,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Tipo de Medición"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 588,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-2",
								children: ["Directa", "Indirecta"].map((tipo) => {
									const isSelected = tipoMedicion === tipo;
									return /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										disabled: readOnly,
										onClick: () => updateField("tipoMedicion", tipo),
										className: `py-2 px-2 text-center rounded-xl border text-[10px] font-bold transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-gray-50 print:text-slate-700 print:border-gray-300"}`,
										children: [
											"[ ",
											isSelected ? "✓" : " ",
											" ] ",
											tipo
										]
									}, tipo, true, {
										fileName: _jsxFileName,
										lineNumber: 596,
										columnNumber: 19
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 589,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 587,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "Marca / Modelo del Medidor"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 616,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: marcaModeloMedidor ?? "",
								onChange: (e) => updateField("marcaModeloMedidor", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. Elster A1800 ALPHA / ION7650"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 617,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 615,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[11px] font-bold text-slate-400 print:text-slate-700",
								children: "N° de Serie / Año de Fabricación"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 629,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: readOnly,
								value: numeroSerieAno ?? "",
								onChange: (e) => updateField("numeroSerieAno", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300 disabled:opacity-60",
								placeholder: "Ej. SN-7492019 / 2022"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 630,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 628,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 557,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 552,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(MetrologiaElectricaSection, {
				mediciones: puntoData.mediciones || {},
				onChange: (nuevasMediciones, field, val) => {
					if (typeof nuevasMediciones === "object" && nuevasMediciones !== null) {
						updateField("mediciones", nuevasMediciones);
					} else if (typeof nuevasMediciones === "string") {
						updateField("mediciones", {
							...puntoData.mediciones || {},
							[nuevasMediciones]: val
						});
					}
				},
				titulo: "4.1 Metrología Eléctrica en Punto de Suministro",
				subtitulo: "Tensiones Línea-Línea, Línea-Neutro y 5 Canales de Corriente (COVENIN 159)",
				readOnly
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 643,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-2.5 flex items-center gap-2 print:text-slate-900 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 663,
						columnNumber: 11
					}, this), " 5. Anomalías u observaciones"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 662,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("textarea", {
					value: observaciones,
					onChange: (e) => updateField("observaciones", e.target.value),
					rows: 4,
					className: "w-full bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl p-3.5 text-xs text-slate-100 outline-none transition-all placeholder-slate-600 font-sans print:bg-white print:text-slate-900 print:border-gray-300",
					placeholder: "Escriba aquí las observaciones, hallazgos o anomalías detectadas en la acometida, transformador o equipo de medición..."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 666,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 661,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-slate-50 print:border-gray-300 print:mt-4",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-900 pb-2.5 print:text-slate-700 print:border-gray-300",
					children: "Cierre del Levantamiento y Validez Técnica"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 677,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1.5 items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-700",
								children: "Firma del Inspector / Técnico"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 684,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: firmaInspector,
								onChange: (e) => updateField("firmaInspector", e.target.value),
								className: "w-full max-w-xs bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all text-center no-print",
								placeholder: "Nombre / Iniciales del Inspector"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 685,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "hidden print:block text-xs font-bold text-slate-900 mt-1 h-6",
								children: firmaInspector || "___________________________"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 692,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "hidden print:block w-48 border-b border-gray-400 mt-6 h-1" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 695,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 683,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1.5 items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-700",
								children: "Firma / Sello de la Empresa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 700,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: firmaSupervisor,
								onChange: (e) => updateField("firmaSupervisor", e.target.value),
								className: "w-full max-w-xs bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all text-center no-print",
								placeholder: "Nombre / Sello de la Empresa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 701,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "hidden print:block text-xs font-bold text-slate-900 mt-1 h-6",
								children: firmaSupervisor || "___________________________"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 708,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "hidden print:block w-48 border-b border-gray-400 mt-6 h-1" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 711,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 699,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 681,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 676,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ModalEdicionCircuito, {
				isOpen: modalJerarquiaOpen,
				onClose: () => setModalJerarquiaOpen(false),
				circuitData: circuitDataWizard,
				modo: wizardModo,
				tipoOrigen: "PUNTO_MEDICION",
				elementosCreados: [],
				onSave: (circuitId, updated) => {
					if (updated.tipoDestino === "SUB_TABLERO_PENDIENTE" && puntoData?.proyectoId) {
						const existingProvId = updated.elementoDestinoId || updated.vinculadoId;
						if (!existingProvId) {
							crearElementoProvisional(puntoData.proyectoId, {
								nombre: updated.equipo && updated.equipo !== "RESERVA (Pendiente por Crear)" ? updated.equipo : `Sub-Tablero Alimentado (${circuitId})`,
								tipoElemento: "TABLERO",
								circuitoOrigen: circuitId
							});
						}
					}
					if (wizardModo === "ENTRADA") {
						updateField("puntoConexionPCC", updated.equipo);
					}
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 716,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 119,
		columnNumber: 5
	}, this);
}
_s(PuntoMedicionComponent, "8fEXqbT2yHYNc5nLtmWpAt174CM=", false, function() {
	return [useStore];
});
_c = PuntoMedicionComponent;
var _c;
$RefreshReg$(_c, "PuntoMedicionComponent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PuntoMedicionComponent.jsx?t=1790793566895";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/PuntoMedicionComponent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/PuntoMedicionComponent.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/PuntoMedicionComponent.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLEtBQ0EsV0FDQSxVQUNBLGFBQ0EsT0FDQSxhQUNBLFNBQ0EsTUFDQSxVQUNBLE9BQ0EsYUFDQSxVQUNBLFVBQ0EsaUJBQ0s7QUFDUCxPQUFPLDBCQUEwQjtBQUNqQyxPQUFPLGdDQUFnQztBQUN2QyxTQUFTLCtCQUErQjtBQUN4QyxPQUFPLGNBQWM7Ozs7QUFFckIsZUFBZSxTQUFTLHVCQUF1QixFQUFFLFdBQVcsVUFBVSxZQUFZOztDQUNoRixNQUFNLEVBQUUsNkJBQTZCLFNBQVM7Q0FDOUMsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBUyxLQUFLO0NBQ2xFLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsSUFBSTtDQUMvRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxTQUFTO0NBQ3RELElBQUksQ0FBQyxXQUFXO0VBQ2QsT0FBTyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFpQztFQUFxRDs7Ozs7Q0FDOUc7Q0FFQSxNQUFNLEVBQ0osSUFDQSxTQUFTLElBQ1QsUUFBUSxJQUNSLE9BQU8sSUFDUCxZQUFZLElBR1osZ0JBQWdCLElBQ2hCLGlCQUFpQixJQUNqQix1QkFBdUIsSUFDdkIsdUJBQXVCLElBQ3ZCLGlCQUFpQixJQUNqQixxQkFBcUIsSUFDckIsa0JBQWtCLElBQ2xCLDBCQUEwQixJQUcxQixnQkFBZ0IsSUFDaEIsbUJBQW1CLElBQ25CLHFCQUFxQixJQUNyQixvQkFBb0IsSUFDcEIsbUJBQW1CLElBQ25CLHdCQUF3QixJQUd4Qix5QkFBeUIsSUFDekIseUJBQXlCLElBQ3pCLG1CQUFtQixJQUduQixtQkFBbUIsSUFDbkIsZUFBZSxJQUNmLHFCQUFxQixJQUNyQixpQkFBaUIsSUFHakIsZ0JBQWdCLElBQ2hCLGlCQUFpQixJQUNqQixrQkFBa0IsT0FDaEI7Q0FFSixNQUFNLGVBQWUsT0FBTyxVQUFVO0VBQ3BDLElBQUksVUFBVTtFQUNkLFNBQVM7R0FDUCxHQUFHO0lBQ0YsUUFBUTtFQUNYLENBQUM7Q0FDSDtDQUVBLE1BQU0sZ0NBQWdDO0VBQ3BDLElBQUksVUFBVTtFQUNkLFNBQVM7R0FDUCxJQUFJLFVBQVU7R0FDZCxRQUFRLFVBQVUsVUFBVTtHQUM1QixPQUFPO0dBQ1AsTUFBTTtHQUNOLFdBQVc7R0FDWCxlQUFlO0dBQ2YsZ0JBQWdCO0dBQ2hCLHNCQUFzQjtHQUN0QixzQkFBc0I7R0FDdEIsZ0JBQWdCO0dBQ2hCLG9CQUFvQjtHQUNwQixpQkFBaUI7R0FDakIseUJBQXlCO0dBQ3pCLGVBQWU7R0FDZixrQkFBa0I7R0FDbEIsb0JBQW9CO0dBQ3BCLG1CQUFtQjtHQUNuQixrQkFBa0I7R0FDbEIsdUJBQXVCO0dBQ3ZCLHdCQUF3QjtHQUN4Qix3QkFBd0I7R0FDeEIsa0JBQWtCO0dBQ2xCLGtCQUFrQjtHQUNsQixjQUFjO0dBQ2Qsb0JBQW9CO0dBQ3BCLGdCQUFnQjtHQUNoQixZQUFZLENBQUM7R0FDYixlQUFlO0dBQ2YsZ0JBQWdCO0dBQ2hCLGlCQUFpQjtFQUNuQixDQUFDO0NBQ0g7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFXLGtRQUFrUSxXQUFXLGVBQWU7WUFBNVM7R0FHRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUEyRjtLQUVyRzs7Ozs7S0FDTix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBNEY7S0FFdEc7Ozs7O0tBQ0gsVUFDQyx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUE4RSxtQkFDN0Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXVDO01BQWE7Ozs7Y0FDbEY7Ozs7OztJQUVGOzs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNHLENBQUMsWUFDQSx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFNBQVM7T0FDVCxXQUFVO09BQ1YsT0FBTTtpQkFKUixDQU1FLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDZCQUE4Qjs7OztpQkFBQyxVQUM5Qzs7Ozs7O01BRVYsd0JBQUMsVUFBRDtPQUNFLGVBQWUsT0FBTyxNQUFNO09BQzVCLFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7OztpQkFBQyxjQUN6Qjs7Ozs7O01BQ1Isd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQWtMLFFBQzNLLEVBQ0Q7Ozs7OztLQUNIOzs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLDZCQUE4Qjs7OztrQkFBQyx1QkFDM0M7Ozs7O2lCQUNOLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVTtRQUNWLE9BQU8sYUFBYTtRQUNwQixXQUFXLE1BQU0sWUFBWSxhQUFhLEVBQUUsT0FBTyxLQUFLO1FBQ3hELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7ZUFDRTs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSw2QkFBOEI7Ozs7a0JBQUMsMEJBQy9DOzs7OztpQkFDTix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPLFNBQVM7UUFDaEIsV0FBVyxNQUFNLFlBQVksU0FBUyxFQUFFLE9BQU8sS0FBSztRQUNwRCxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSw2QkFBOEI7Ozs7a0JBQUMsT0FDNUM7Ozs7O2lCQUNOLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVTtRQUNWLE9BQU8sUUFBUTtRQUNmLFdBQVcsTUFBTSxZQUFZLFFBQVEsRUFBRSxPQUFPLEtBQUs7UUFDbkQsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7OztLQUNGOzs7Ozs7R0FDRjs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHlCQUEwQjs7OztlQUFDLGtEQUM5Qzs7Ozs7Y0FFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBd0M7Ozs7aUJBQ3JILHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVTtRQUNWLE9BQU8saUJBQWlCO1FBQ3hCLFdBQVcsTUFBTSxZQUFZLGlCQUFpQixFQUFFLE9BQU8sS0FBSztRQUM1RCxXQUFVO1FBQ1YsYUFBWTtPQUNiOzs7O2VBQ0U7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTREO09BQW9DOzs7O2lCQUNqSCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPLGtCQUFrQjtRQUN6QixXQUFXLE1BQU0sWUFBWSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7UUFDN0QsV0FBVTtRQUNWLGFBQVk7T0FDYjs7OztlQUNFOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0RDtPQUFpRDs7OztpQkFDOUgsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxVQUFVO1FBQ1YsT0FBTyx3QkFBd0I7UUFDL0IsV0FBVyxNQUFNLFlBQVksd0JBQXdCLEVBQUUsT0FBTyxLQUFLO1FBQ25FLFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7ZUFDRTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBbUM7Ozs7aUJBQ2hILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaO1NBQUM7U0FBZ0I7U0FBaUI7UUFBYyxDQUFDLENBQUMsS0FBSyxVQUFVO1NBQ2hFLE1BQU0sYUFBYSx5QkFBeUI7U0FDNUMsT0FDRSx3QkFBQyxVQUFEO1VBRUUsTUFBSztVQUNMLFVBQVU7VUFDVixlQUFlLFlBQVksd0JBQXdCLEtBQUs7VUFDeEQsV0FBVywrSUFDVCxhQUNJLDBIQUNBO29CQVJSO1dBVUM7V0FDSSxhQUFhLE1BQU07V0FBSTtXQUFJO1VBQ3hCO1lBWEQ7Ozs7Z0JBV0M7UUFFWixDQUFDO09BQ0U7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEQ7UUFBa0Q7Ozs7O1FBQy9ILHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsVUFBVTtTQUNWLE1BQUs7U0FDTCxPQUFPLGtCQUFrQjtTQUN6QixXQUFXLE1BQU0sWUFBWSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7U0FDN0QsV0FBVTtTQUNWLGFBQVk7UUFDYjs7Ozs7UUFDRCx3QkFBQyxZQUFEO1NBQVUsSUFBRzttQkFDVix3QkFBd0IsS0FBSSxNQUFLLHdCQUFDLFVBQUQ7VUFBZ0IsT0FBTztvQkFBSTtTQUFVLEdBQXhCOzs7O2dCQUF3QixDQUFDO1FBQ2hFOzs7OztPQUNQOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0RDtPQUE0Qzs7OztpQkFDekgsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxVQUFVO1FBQ1YsT0FBTyxzQkFBc0I7UUFDN0IsV0FBVyxNQUFNLFlBQVksc0JBQXNCLEVBQUUsT0FBTyxLQUFLO1FBQ2pFLFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7ZUFDRTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBMkM7Ozs7aUJBQ3hILHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVTtRQUNWLE9BQU8sbUJBQW1CO1FBQzFCLFdBQVcsTUFBTSxZQUFZLG1CQUFtQixFQUFFLE9BQU8sS0FBSztRQUM5RCxXQUFVO1FBQ1YsYUFBWTtPQUNiOzs7O2VBQ0U7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTREO09BQW9DOzs7O2lCQUNqSCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPLDJCQUEyQjtRQUNsQyxXQUFXLE1BQU0sWUFBWSwyQkFBMkIsRUFBRSxPQUFPLEtBQUs7UUFDdEUsV0FBVTtRQUNWLGFBQVk7T0FDYjs7OztlQUNFOzs7Ozs7S0FDRjs7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7Z0JBQUMscURBQ3RDOzs7OztlQUNOLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsVUFBVTtNQUNWLGVBQWU7T0FDYixjQUFjLFNBQVM7T0FDdkIscUJBQXFCO1FBQ25CLElBQUk7UUFDSixRQUFRO1FBQ1IsUUFBUSxvQkFBb0I7UUFDNUIsT0FBTyxDQUFDLENBQUM7UUFDVCxTQUFTO1NBQUUsS0FBSztTQUFJLE9BQU87U0FBSSxNQUFNO1FBQUc7T0FDMUMsQ0FBQztPQUNELHNCQUFzQixJQUFJO01BQzVCO01BQ0EsV0FBVTtNQUNWLE9BQU07Z0JBZlIsQ0FpQkUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsNkJBQThCOzs7O2dCQUFDLHVCQUM3Qzs7Ozs7YUFDTjs7Ozs7Y0FFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBd0I7Ozs7aUJBQ3JHLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaO1NBQUM7U0FBUztTQUFlO1FBQU8sQ0FBQyxDQUFDLEtBQUssU0FBUztTQUMvQyxNQUFNLGFBQWEsa0JBQWtCO1NBQ3JDLE9BQ0Usd0JBQUMsVUFBRDtVQUVFLE1BQUs7VUFDTCxVQUFVO1VBQ1YsZUFBZSxZQUFZLGlCQUFpQixJQUFJO1VBQ2hELFdBQVcsK0lBQ1QsYUFDSSwwSEFDQTtvQkFSUjtXQVVDO1dBQ0ksYUFBYSxNQUFNO1dBQUk7V0FBSTtVQUN4QjtZQVhEOzs7O2dCQVdDO1FBRVosQ0FBQztPQUNFOzs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTREO09BQThCOzs7O2lCQUMzRyx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPLG9CQUFvQjtRQUMzQixXQUFXLE1BQU0sWUFBWSxvQkFBb0IsRUFBRSxPQUFPLEtBQUs7UUFDL0QsV0FBVTtRQUNWLGFBQVk7T0FDYjs7OztlQUNFOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0RDtPQUE4Qzs7OztpQkFDM0gsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxVQUFVO1FBQ1YsT0FBTyxzQkFBc0I7UUFDN0IsV0FBVyxNQUFNLFlBQVksc0JBQXNCLEVBQUUsT0FBTyxLQUFLO1FBQ2pFLFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7ZUFDRTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBa0M7Ozs7aUJBQy9HLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVTtRQUNWLE9BQU8scUJBQXFCO1FBQzVCLFdBQVcsTUFBTSxZQUFZLHFCQUFxQixFQUFFLE9BQU8sS0FBSztRQUNoRSxXQUFVO1FBQ1YsYUFBWTtPQUNiOzs7O2VBQ0U7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTREO09BQWdEOzs7O2lCQUM3SCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWjtTQUFDO1NBQVc7U0FBeUI7U0FBZTtRQUEwQixDQUFDLENBQUMsS0FBSyxTQUFTO1NBQzdGLE1BQU0sYUFBYSxxQkFBcUI7U0FDeEMsT0FDRSx3QkFBQyxVQUFEO1VBRUUsTUFBSztVQUNMLFVBQVU7VUFDVixlQUFlLFlBQVksb0JBQW9CLElBQUk7VUFDbkQsV0FBVyxpSkFDVCxhQUNJLDBIQUNBO29CQVJSO1dBVUM7V0FDSSxhQUFhLE1BQU07V0FBSTtXQUFJO1VBQ3hCO1lBWEQ7Ozs7Z0JBV0M7UUFFWixDQUFDO09BQ0U7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBb0U7Ozs7aUJBQ2pKLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVTtRQUNWLE9BQU8seUJBQXlCO1FBQ2hDLFdBQVcsTUFBTSxZQUFZLHlCQUF5QixFQUFFLE9BQU8sS0FBSztRQUNwRSxXQUFVO1FBQ1YsYUFBWTtPQUNiOzs7O2VBQ0U7Ozs7OztLQUNGOzs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OztlQUFDLDJDQUM3Qzs7Ozs7Y0FFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBa0M7Ozs7aUJBQzlHLENBQ0MsaUNBQ0EsK0JBQ0YsQ0FBQyxDQUFDLEtBQUssU0FBUztRQUNkLE1BQU0sYUFBYSwyQkFBMkI7UUFDOUMsT0FDRSx3QkFBQyxVQUFEO1NBRUUsTUFBSztTQUNMLFVBQVU7U0FDVixlQUFlLFlBQVksMEJBQTBCLElBQUk7U0FDekQsV0FBVyw2SUFDVCxhQUNJLDBIQUNBO21CQVJSO1VBVUM7VUFDSSxhQUFhLE1BQU07VUFBSTtVQUFJO1NBQ3hCO1dBWEQ7Ozs7ZUFXQztPQUVaLENBQUMsQ0FDRTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBa0M7Ozs7aUJBQzlHLENBQ0MseUJBQ0EsaUJBQ0YsQ0FBQyxDQUFDLEtBQUssU0FBUztRQUNkLE1BQU0sYUFBYSwyQkFBMkI7UUFDOUMsT0FDRSx3QkFBQyxVQUFEO1NBRUUsTUFBSztTQUNMLFVBQVU7U0FDVixlQUFlLFlBQVksMEJBQTBCLElBQUk7U0FDekQsV0FBVyw2SUFDVCxhQUNJLDBIQUNBO21CQVJSO1VBVUM7VUFDSSxhQUFhLE1BQU07VUFBSTtVQUFJO1NBQ3hCO1dBWEQ7Ozs7ZUFXQztPQUVaLENBQUMsQ0FDRTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBNEI7Ozs7aUJBQ3hHLENBQ0MsYUFDQSxZQUNGLENBQUMsQ0FBQyxLQUFLLFFBQVE7UUFDYixNQUFNLGFBQWEscUJBQXFCO1FBQ3hDLE9BQ0Usd0JBQUMsVUFBRDtTQUVFLE1BQUs7U0FDTCxVQUFVO1NBQ1YsZUFBZSxZQUFZLG9CQUFvQixHQUFHO1NBQ2xELFdBQVcsNklBQ1QsYUFDSSwwSEFDQTttQkFSUjtVQVVDO1VBQ0ksYUFBYSxNQUFNO1VBQUk7VUFBSTtTQUN4QjtXQVhEOzs7O2VBV0M7T0FFWixDQUFDLENBQ0U7Ozs7OztLQUNGOzs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7OztlQUFDLDhDQUMxQzs7Ozs7Y0FFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBNEI7Ozs7aUJBQ3pHLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLENBQ0MsOEJBQ0Esc0JBQ0YsQ0FBQyxDQUFDLEtBQUssU0FBUztTQUNkLE1BQU0sYUFBYSxxQkFBcUI7U0FDeEMsT0FDRSx3QkFBQyxVQUFEO1VBRUUsTUFBSztVQUNMLFVBQVU7VUFDVixlQUFlLFlBQVksb0JBQW9CLElBQUk7VUFDbkQsV0FBVywrSUFDVCxhQUNJLDBIQUNBO29CQVJSO1dBVUM7V0FDSSxhQUFhLE1BQU07V0FBSTtXQUFJO1VBQ3hCO1lBWEQ7Ozs7Z0JBV0M7UUFFWixDQUFDO09BQ0U7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FBdUI7Ozs7aUJBQ3BHLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLENBQ0MsV0FDQSxXQUNGLENBQUMsQ0FBQyxLQUFLLFNBQVM7U0FDZCxNQUFNLGFBQWEsaUJBQWlCO1NBQ3BDLE9BQ0Usd0JBQUMsVUFBRDtVQUVFLE1BQUs7VUFDTCxVQUFVO1VBQ1YsZUFBZSxZQUFZLGdCQUFnQixJQUFJO1VBQy9DLFdBQVcsK0lBQ1QsYUFDSSwwSEFDQTtvQkFSUjtXQVVDO1dBQ0ksYUFBYSxNQUFNO1dBQUk7V0FBSTtVQUN4QjtZQVhEOzs7O2dCQVdDO1FBRVosQ0FBQztPQUNFOzs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTREO09BQWlDOzs7O2lCQUM5Ryx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPLHNCQUFzQjtRQUM3QixXQUFXLE1BQU0sWUFBWSxzQkFBc0IsRUFBRSxPQUFPLEtBQUs7UUFDakUsV0FBVTtRQUNWLGFBQVk7T0FDYjs7OztlQUNFOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0RDtPQUF1Qzs7OztpQkFDcEgsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxVQUFVO1FBQ1YsT0FBTyxrQkFBa0I7UUFDekIsV0FBVyxNQUFNLFlBQVksa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1FBQzdELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7ZUFDRTs7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLDRCQUFEO0lBQ0UsWUFBWSxVQUFVLGNBQWMsQ0FBQztJQUNyQyxXQUFXLGtCQUFrQixPQUFPLFFBQVE7S0FDMUMsSUFBSSxPQUFPLHFCQUFxQixZQUFZLHFCQUFxQixNQUFNO01BQ3JFLFlBQVksY0FBYyxnQkFBZ0I7S0FDNUMsT0FBTyxJQUFJLE9BQU8scUJBQXFCLFVBQVU7TUFDL0MsWUFBWSxjQUFjO09BQ3hCLEdBQUksVUFBVSxjQUFjLENBQUM7UUFDNUIsbUJBQW1CO01BQ3RCLENBQUM7S0FDSDtJQUNGO0lBQ0EsUUFBTztJQUNQLFdBQVU7SUFDQTtHQUNYOzs7OztHQUdELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUseUJBQTBCOzs7O2VBQUMsK0JBQ2hEOzs7OztjQUVKLHdCQUFDLFlBQUQ7S0FDRSxPQUFPO0tBQ1AsV0FBVyxNQUFNLFlBQVksaUJBQWlCLEVBQUUsT0FBTyxLQUFLO0tBQzVELE1BQU07S0FDTixXQUFVO0tBQ1YsYUFBWTtJQUNiOzs7O1lBQ0U7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUF3STtJQUVsSjs7OztjQUVKLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFvRjtPQUFtQzs7Ozs7T0FDdkksd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1FBQzdELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7O09BQ0Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2Isa0JBQWtCO09BQ2Y7Ozs7O09BQ04sd0JBQUMsT0FBRCxFQUFLLFdBQVUsNERBQWlFOzs7OztNQUM3RTs7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFvRjtPQUFpQzs7Ozs7T0FDckksd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1FBQzlELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7O09BQ0Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsbUJBQW1CO09BQ2hCOzs7OztPQUNOLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDREQUFpRTs7Ozs7TUFDN0U7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUVMLHdCQUFDLHNCQUFEO0lBQ0UsUUFBUTtJQUNSLGVBQWUsc0JBQXNCLEtBQUs7SUFDMUMsYUFBYTtJQUNiLE1BQU07SUFDTixZQUFXO0lBQ1gsa0JBQWtCLENBQUM7SUFDbkIsU0FBUyxXQUFXLFlBQVk7S0FDOUIsSUFBSSxRQUFRLGdCQUFnQiwyQkFBMkIsV0FBVyxZQUFZO01BQzVFLE1BQU0saUJBQWlCLFFBQVEscUJBQXFCLFFBQVE7TUFDNUQsSUFBSSxDQUFDLGdCQUFnQjtPQUNuQix5QkFBeUIsVUFBVSxZQUFZO1FBQzdDLFFBQVEsUUFBUSxVQUFVLFFBQVEsV0FBVyxrQ0FBa0MsUUFBUSxTQUFTLDJCQUEyQixVQUFVO1FBQ3JJLGNBQWM7UUFDZCxnQkFBZ0I7T0FDbEIsQ0FBQztNQUNIO0tBQ0Y7S0FDQSxJQUFJLGVBQWUsV0FBVztNQUM1QixZQUFZLG9CQUFvQixRQUFRLE1BQU07S0FDaEQ7SUFDRjtHQUNEOzs7OztFQUNFOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQdW50b01lZGljaW9uQ29tcG9uZW50LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgWmFwLCBcbiAgQnVpbGRpbmcyLCBcbiAgRmlsZVRleHQsIFxuICBTaGllbGRDaGVjaywgXG4gIEdhdWdlLCBcbiAgQWxlcnRDaXJjbGUsIFxuICBQcmludGVyLCBcbiAgVXNlciwgXG4gIENhbGVuZGFyLCBcbiAgQ2xvY2ssIFxuICBDaGVja1NxdWFyZSxcbiAgQWN0aXZpdHksXG4gIFNldHRpbmdzLFxuICBSb3RhdGVDY3dcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBNb2RhbEVkaWNpb25DaXJjdWl0byBmcm9tICcuL01vZGFsRWRpY2lvbkNpcmN1aXRvJztcbmltcG9ydCBNZXRyb2xvZ2lhRWxlY3RyaWNhU2VjdGlvbiBmcm9tICcuL01ldHJvbG9naWFFbGVjdHJpY2FTZWN0aW9uJztcbmltcG9ydCB7IFRFTlNJT05FU19DT1ZFTklOX1RPREFTIH0gZnJvbSAnLi4vdXRpbHMvY29uc3RhbnRzJztcbmltcG9ydCB1c2VTdG9yZSBmcm9tICcuLi9zdG9yZS91c2VTdG9yZSc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFB1bnRvTWVkaWNpb25Db21wb25lbnQoeyBwdW50b0RhdGEsIG9uVXBkYXRlLCByZWFkT25seSB9KSB7XG4gIGNvbnN0IHsgY3JlYXJFbGVtZW50b1Byb3Zpc2lvbmFsIH0gPSB1c2VTdG9yZSgpO1xuICBjb25zdCBbbW9kYWxKZXJhcnF1aWFPcGVuLCBzZXRNb2RhbEplcmFycXVpYU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbY2lyY3VpdERhdGFXaXphcmQsIHNldENpcmN1aXREYXRhV2l6YXJkXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbd2l6YXJkTW9kbywgc2V0V2l6YXJkTW9kb10gPSB1c2VTdGF0ZSgnRU5UUkFEQScpO1xuICBpZiAoIXB1bnRvRGF0YSkge1xuICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtOCB0ZXh0LXNsYXRlLTQwMFwiPk5vIGhheSBkYXRvcyBkZSBwdW50byBkZSBtZWRpY2nDs24gc2VsZWNjaW9uYWRvcy48L2Rpdj47XG4gIH1cblxuICBjb25zdCB7XG4gICAgaWQsXG4gICAgbm9tYnJlID0gJycsXG4gICAgZmVjaGEgPSAnJyxcbiAgICBob3JhID0gJycsXG4gICAgaW5zcGVjdG9yID0gJycsXG5cbiAgICAvLyAxLiBEYXRvcyBHZW5lcmFsZXNcbiAgICBub21icmVVc3VhcmlvID0gJycsXG4gICAgbnVtZXJvQ29udHJhdG8gPSAnJyxcbiAgICBlbXByZXNhRGlzdHJpYnVpZG9yYSA9ICcnLFxuICAgIG5pdmVsVGVuc2lvbkNvbnRyYXRvID0gJycsXG4gICAgdGVuc2lvbk5vbWluYWwgPSAnJyxcbiAgICBwb3RlbmNpYUNvbnRyYXRhZGEgPSAnJyxcbiAgICB0YXJpZmFBcGxpY2FibGUgPSAnJyxcbiAgICBjb2RpZ29FbGVtZW50b1ByaW5jaXBhbCA9ICcnLFxuXG4gICAgLy8gMi4gUHVudG8gZGUgQWNvbWV0aWRhXG4gICAgdGlwb0Fjb21ldGlkYSA9ICcnLFxuICAgIHB1bnRvQ29uZXhpb25QQ0MgPSAnJyxcbiAgICBjb25kdWN0b3JBY29tZXRpZGEgPSAnJyxcbiAgICBsb25naXR1ZEFjb21ldGlkYSA9ICcnLFxuICAgIGVsZW1lbnRvTWFuaW9icmEgPSAnJyxcbiAgICBjYXBhY2lkYWRJbnRlcnJ1cGNpb24gPSAnJyxcblxuICAgIC8vIDMuIFNpc3RlbWEgZGUgVHJhbnNmb3JtYWNpw7NuXG4gICAgdWJpY2FjaW9uVHJhbnNmb3JtYWRvciA9ICcnLFxuICAgIHByb3BpZWRhZFRyYW5zZm9ybWFkb3IgPSAnJyxcbiAgICB1c29UcmFuc2Zvcm1hZG9yID0gJycsXG5cbiAgICAvLyA0LiBTaXN0ZW1hIGRlIE1lZGljacOzblxuICAgIHViaWNhY2lvbk1lZGlkb3IgPSAnJyxcbiAgICB0aXBvTWVkaWNpb24gPSAnJyxcbiAgICBtYXJjYU1vZGVsb01lZGlkb3IgPSAnJyxcbiAgICBudW1lcm9TZXJpZUFubyA9ICcnLFxuXG4gICAgLy8gNS4gT2JzZXJ2YWNpb25lcyB5IEZpcm1hc1xuICAgIG9ic2VydmFjaW9uZXMgPSAnJyxcbiAgICBmaXJtYUluc3BlY3RvciA9ICcnLFxuICAgIGZpcm1hU3VwZXJ2aXNvciA9ICcnXG4gIH0gPSBwdW50b0RhdGE7XG5cbiAgY29uc3QgdXBkYXRlRmllbGQgPSAoZmllbGQsIHZhbHVlKSA9PiB7XG4gICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgb25VcGRhdGUoe1xuICAgICAgLi4ucHVudG9EYXRhLFxuICAgICAgW2ZpZWxkXTogdmFsdWVcbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVMaW1waWFyRm9ybXVsYXJpbyA9ICgpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBvblVwZGF0ZSh7XG4gICAgICBpZDogcHVudG9EYXRhLmlkLFxuICAgICAgbm9tYnJlOiBwdW50b0RhdGEubm9tYnJlIHx8ICcnLFxuICAgICAgZmVjaGE6ICcnLFxuICAgICAgaG9yYTogJycsXG4gICAgICBpbnNwZWN0b3I6ICcnLFxuICAgICAgbm9tYnJlVXN1YXJpbzogJycsXG4gICAgICBudW1lcm9Db250cmF0bzogJycsXG4gICAgICBlbXByZXNhRGlzdHJpYnVpZG9yYTogJycsXG4gICAgICBuaXZlbFRlbnNpb25Db250cmF0bzogJycsXG4gICAgICB0ZW5zaW9uTm9taW5hbDogJycsXG4gICAgICBwb3RlbmNpYUNvbnRyYXRhZGE6ICcnLFxuICAgICAgdGFyaWZhQXBsaWNhYmxlOiAnJyxcbiAgICAgIGNvZGlnb0VsZW1lbnRvUHJpbmNpcGFsOiAnJyxcbiAgICAgIHRpcG9BY29tZXRpZGE6ICcnLFxuICAgICAgcHVudG9Db25leGlvblBDQzogJycsXG4gICAgICBjb25kdWN0b3JBY29tZXRpZGE6ICcnLFxuICAgICAgbG9uZ2l0dWRBY29tZXRpZGE6ICcnLFxuICAgICAgZWxlbWVudG9NYW5pb2JyYTogJycsXG4gICAgICBjYXBhY2lkYWRJbnRlcnJ1cGNpb246ICcnLFxuICAgICAgdWJpY2FjaW9uVHJhbnNmb3JtYWRvcjogJycsXG4gICAgICBwcm9waWVkYWRUcmFuc2Zvcm1hZG9yOiAnJyxcbiAgICAgIHVzb1RyYW5zZm9ybWFkb3I6ICcnLFxuICAgICAgdWJpY2FjaW9uTWVkaWRvcjogJycsXG4gICAgICB0aXBvTWVkaWNpb246ICcnLFxuICAgICAgbWFyY2FNb2RlbG9NZWRpZG9yOiAnJyxcbiAgICAgIG51bWVyb1NlcmllQW5vOiAnJyxcbiAgICAgIG1lZGljaW9uZXM6IHt9LFxuICAgICAgb2JzZXJ2YWNpb25lczogJycsXG4gICAgICBmaXJtYUluc3BlY3RvcjogJycsXG4gICAgICBmaXJtYVN1cGVydmlzb3I6ICcnXG4gICAgfSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YHctZnVsbCB0ZXh0LXNsYXRlLTEwMCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IG1kOnAtOCBzaGFkb3cteGwgYmFja2Ryb3AtYmx1ci1tZCBzZWxlY3QtdGV4dCBtYXgtdy01eGwgbXgtYXV0byBzcGFjZS15LTggcHJpbnQtY2FyZCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItbm9uZSBwcmludDpzaGFkb3ctbm9uZSBwcmludDpwLTAgcHJpbnQ6bS0wICR7cmVhZE9ubHkgPyAnb3BhY2l0eS05MCcgOiAnJ31gfT5cbiAgICAgIFxuICAgICAgey8qIEVuY2FiZXphZG8gR2VuZXJhbCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWQ6aXRlbXMtY2VudGVyIGdhcC00IHBiLTYgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTUwMCBmb250LWV4dHJhYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHByaW50OnRleHQtYW1iZXItNzAwXCI+XG4gICAgICAgICAgICBGb3JtYXRvIGRlIExldmFudGFtaWVudG9cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgbWQ6dGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS0xMDAgdHJhY2tpbmctd2lkZSBtdC0xIHByaW50OnRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICBQdW50byBkZSBNZWRpY2nDs24geSBTdW1pbmlzdHJvIGRlIEVuZXJnw61hIEVsw6ljdHJpY2FcbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIHtub21icmUgJiYgKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNDAwIG10LTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5cbiAgICAgICAgICAgICAgSWRlbnRpZmljYWRvcjogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hbWJlci00MDAgcHJpbnQ6dGV4dC1zbGF0ZS05MDBcIj57bm9tYnJlfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIHshcmVhZE9ubHkgJiYgKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTGltcGlhckZvcm11bGFyaW99XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm5vLXByaW50IGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC1hbWJlci00MDAgZm9udC1ib2xkIHB4LTMgcHktMiByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0cmFuc2l0aW9uLWFsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgIHRpdGxlPVwiUmVpbmljaWFyIHRvZG9zIGxvcyBjYW1wb3MgZGVsIGZvcm11bGFyaW8gYSBibGFuY29cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNTAwXCIgLz4gTGltcGlhclxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB3aW5kb3cucHJpbnQoKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm5vLXByaW50IGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ibGFjayBweC00IHB5LTIgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHNoYWRvdy1tZFwiXG4gICAgICAgICAgICB0aXRsZT1cIkd1YXJkYXIgY29tbyBQREYgbyBJbXByaW1pciBlc3RlIEZvcm1hdG9cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBHdWFyZGFyIFBERlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LW1vbm8gZm9udC1ibGFjayB0ZXh0LWFtYmVyLTQwMCBiZy1hbWJlci01MDAvMTAgcHgtMi41IHB5LTEgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCB0ZXh0LXhzIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgSUQ6IHtpZH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBEYXRvcyBkZWwgSW5zcGVjdG9yIHkgRmVjaGEgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MC80MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCByb3VuZGVkLTJ4bCBwLTUgc3BhY2UteS00IHByaW50OmJnLXNsYXRlLTUwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTFcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTUwMFwiIC8+IE5vbWJyZSBkZWwgSW5zcGVjdG9yXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgIHZhbHVlPXtpbnNwZWN0b3IgPz8gJyd9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ2luc3BlY3RvcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBJbmcuIEp1YW4gUMOpcmV6XCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNTAwXCIgLz4gRmVjaGEgZGVsIExldmFudGFtaWVudG9cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkT25seX1cbiAgICAgICAgICAgICAgdmFsdWU9e2ZlY2hhID8/ICcnfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUZpZWxkKCdmZWNoYScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgZm9udC1tb25vIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNTAwXCIgLz4gSG9yYVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0aW1lXCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRPbmx5fVxuICAgICAgICAgICAgICB2YWx1ZT17aG9yYSA/PyAnJ31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnaG9yYScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgZm9udC1tb25vIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTRUNDScOTTiAxOiBEYXRvcyBHZW5lcmFsZXMgZGUgbGEgQWNvbWV0aWRhIHkgU3VtaW5pc3RybyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHJvdW5kZWQtMnhsIHAtNSBzcGFjZS15LTQgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci01MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0yLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz4gMS4gRGF0b3MgR2VuZXJhbGVzIGRlIGxhIEFjb21ldGlkYSB5IFN1bWluaXN0cm9cbiAgICAgICAgPC9oMz5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTVcIj5cbiAgICAgICAgICB7LyogTm9tYnJlIFVzdWFyaW8gLyBSYXrDs24gU29jaWFsICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41XCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+Tm9tYnJlIGRlbCBVc3VhcmlvIC8gUmF6w7NuIFNvY2lhbDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgIHZhbHVlPXtub21icmVVc3VhcmlvID8/ICcnfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUZpZWxkKCdub21icmVVc3VhcmlvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBJbmR1c3RyaWFzIEVsw6ljdHJpY2FzIEMuQS5cIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBOwrAgZGUgQ29udHJhdG8gLyBDdWVudGEgLyBOSUMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5OwrAgZGUgQ29udHJhdG8gLyBDdWVudGEgLyBOSUM8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRPbmx5fVxuICAgICAgICAgICAgICB2YWx1ZT17bnVtZXJvQ29udHJhdG8gPz8gJyd9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ251bWVyb0NvbnRyYXRvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgZm9udC1tb25vIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gTklDLTg0OTIwNDkxXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRW1wcmVzYSBEaXN0cmlidWlkb3JhICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41XCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+RW1wcmVzYSBEaXN0cmlidWlkb3JhIChFRCkgLyBTdW1pbmlzdHJhZG9yPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkT25seX1cbiAgICAgICAgICAgICAgdmFsdWU9e2VtcHJlc2FEaXN0cmlidWlkb3JhID8/ICcnfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUZpZWxkKCdlbXByZXNhRGlzdHJpYnVpZG9yYScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0zLjUgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gQ09SUE9FTEVDIC8gU3VtaW5pc3RyYWRvciBMb2NhbFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE5pdmVsIGRlIFRlbnNpw7NuIGRlIENvbnRyYXRvICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41XCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+Tml2ZWwgZGUgVGVuc2nDs24gZGUgQ29udHJhdG88L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yXCI+XG4gICAgICAgICAgICAgIHtbJ0FsdGEgVGVuc2nDs24nLCAnTWVkaWEgVGVuc2nDs24nLCAnQmFqYSBUZW5zacOzbiddLm1hcCgobml2ZWwpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gbml2ZWxUZW5zaW9uQ29udHJhdG8gPT09IG5pdmVsO1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGtleT17bml2ZWx9XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUZpZWxkKCduaXZlbFRlbnNpb25Db250cmF0bycsIG5pdmVsKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMiBweC0yIHRleHQtY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTYwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCAke1xuICAgICAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBib3JkZXItYW1iZXItNTAwIHNoYWRvdy1tZCBwcmludDpiZy1hbWJlci0xMDAgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWFtYmVyLTYwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAgcHJpbnQ6YmctZ3JheS01MCBwcmludDp0ZXh0LXNsYXRlLTcwMCBwcmludDpib3JkZXItZ3JheS0zMDAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBbIHtpc1NlbGVjdGVkID8gJ+KckycgOiAnICd9IF0ge25pdmVsfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBUZW5zacOzbiBOb21pbmFsIGRlIFN1bWluaXN0cm8gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5UZW5zacOzbiBOb21pbmFsIGRlIFN1bWluaXN0cm8gKENPVkVOSU4gMTU5KTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgIGxpc3Q9XCJjb3ZlbmluLXZvbHRhamVzLW1lZGljaW9uXCJcbiAgICAgICAgICAgICAgdmFsdWU9e3RlbnNpb25Ob21pbmFsID8/ICcnfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUZpZWxkKCd0ZW5zaW9uTm9taW5hbCcsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0zLjUgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIGZvbnQtbW9ubyBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDAgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDEzLjgga1YgbyAxMjAvMjA4IFYgKDPOpiAtIDQgaGlsb3MpXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8ZGF0YWxpc3QgaWQ9XCJjb3ZlbmluLXZvbHRhamVzLW1lZGljaW9uXCI+XG4gICAgICAgICAgICAgIHtURU5TSU9ORVNfQ09WRU5JTl9UT0RBUy5tYXAodiA9PiA8b3B0aW9uIGtleT17dn0gdmFsdWU9e3Z9Pnt2fTwvb3B0aW9uPil9XG4gICAgICAgICAgICA8L2RhdGFsaXN0PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFBvdGVuY2lhIENvbnRyYXRhZGEgLyBDb25lY3RhZGEgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5Qb3RlbmNpYSBDb250cmF0YWRhIC8gQ29uZWN0YWRhIChrVkEpPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkT25seX1cbiAgICAgICAgICAgICAgdmFsdWU9e3BvdGVuY2lhQ29udHJhdGFkYSA/PyAnJ31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgncG90ZW5jaWFDb250cmF0YWRhJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgZm9udC1tb25vIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gNTAwIGtWQVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFRhcmlmYSAvIFLDqWdpbWVuIFRhcmlmYXJpbyBBcGxpY2FibGUgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5UYXJpZmEgLyBSw6lnaW1lbiBUYXJpZmFyaW8gQXBsaWNhYmxlPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkT25seX1cbiAgICAgICAgICAgICAgdmFsdWU9e3RhcmlmYUFwbGljYWJsZSA/PyAnJ31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgndGFyaWZhQXBsaWNhYmxlJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBUYXJpZmEgSW5kdXN0cmlhbCBHZW5lcmFsIFQtMlwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEPDs2RpZ28gZGVsIEVsZW1lbnRvIHByaW5jaXBhbCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPkPDs2RpZ28gZGVsIEVsZW1lbnRvIFByaW5jaXBhbDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgIHZhbHVlPXtjb2RpZ29FbGVtZW50b1ByaW5jaXBhbCA/PyAnJ31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnY29kaWdvRWxlbWVudG9QcmluY2lwYWwnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCBmb250LW1vbm8gcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBFTEVNLU1FRC0wMVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogU0VDQ0nDk04gMjogUHVudG8gZGUgQWNvbWV0aWRhIGUgSW5mcmFlc3RydWN0dXJhIGRlIEVudHJhZGEgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MC80MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCByb3VuZGVkLTJ4bCBwLTUgc3BhY2UteS00IHByaW50OmJnLXdoaXRlIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNTAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItMi41IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz4gMi4gUHVudG8gZGUgQWNvbWV0aWRhIGUgSW5mcmFlc3RydWN0dXJhIGRlIEVudHJhZGFcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgIHNldFdpemFyZE1vZG8oJ0VOVFJBREEnKTtcbiAgICAgICAgICAgICAgc2V0Q2lyY3VpdERhdGFXaXphcmQoe1xuICAgICAgICAgICAgICAgIGlkOiAnUENDX0FDT01FVElEQScsXG4gICAgICAgICAgICAgICAgbm9tYnJlOiAnUHVudG8gZGUgQ29uZXhpw7NuIFBDQyAvIEFjb21ldGlkYSBFbnRyYWRhJyxcbiAgICAgICAgICAgICAgICBlcXVpcG86IHB1bnRvQ29uZXhpb25QQ0MgfHwgJycsXG4gICAgICAgICAgICAgICAgcG9sZXM6IFszXSxcbiAgICAgICAgICAgICAgICBicmVha2VyOiB7IGFtcDogJycsIG1hcmNhOiAnJywgdGlwbzogJycgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgc2V0TW9kYWxKZXJhcnF1aWFPcGVuKHRydWUpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm5vLXByaW50IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBiZy1hbWJlci01MDAvMTAgaG92ZXI6YmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItNDAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXNtIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgdGl0bGU9XCJDb25maWd1cmFyIENvbmV4acOzbiBkZSBKZXJhcnF1w61hIChXaXphcmQpXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8U2V0dGluZ3MgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci00MDBcIiAvPiBDb25maWd1cmFyIEplcmFycXXDrWFcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9oMz5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTVcIj5cbiAgICAgICAgICB7LyogVGlwbyBkZSBBY29tZXRpZGEgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjUgbWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPlRpcG8gZGUgQWNvbWV0aWRhPC9sYWJlbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtM1wiPlxuICAgICAgICAgICAgICB7WydBw6lyZWEnLCAnU3VidGVycsOhbmVhJywgJ01peHRhJ10ubWFwKCh0aXBvKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHRpcG9BY29tZXRpZGEgPT09IHRpcG87XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAga2V5PXt0aXBvfVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRPbmx5fVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB1cGRhdGVGaWVsZCgndGlwb0Fjb21ldGlkYScsIHRpcG8pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTMgdGV4dC1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkICR7XG4gICAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGJvcmRlci1hbWJlci01MDAgc2hhZG93LW1kIHByaW50OmJnLWFtYmVyLTEwMCBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItYW1iZXItNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCBwcmludDpiZy1ncmF5LTUwIHByaW50OnRleHQtc2xhdGUtNzAwIHByaW50OmJvcmRlci1ncmF5LTMwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFsge2lzU2VsZWN0ZWQgPyAn4pyTJyA6ICcgJ30gXSB7dGlwb31cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUHVudG8gZGUgQ29uZXhpw7NuIChQQ0MpICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41XCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+UHVudG8gZGUgQ29uZXhpw7NuIChQQ0MpPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkT25seX1cbiAgICAgICAgICAgICAgdmFsdWU9e3B1bnRvQ29uZXhpb25QQ0MgPz8gJyd9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ3B1bnRvQ29uZXhpb25QQ0MnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDAgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVGFnIC8gQ8OzZGlnbyBkZSBQb3N0ZSwgQ2VsZGEgbyBTdWJlc3RhY2nDs25cIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDb25kdWN0b3IgZGUgQWNvbWV0aWRhICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41XCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+Q29uZHVjdG9yIGRlIEFjb21ldGlkYSAoVGlwbyAvIENhbGlicmUpPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkT25seX1cbiAgICAgICAgICAgICAgdmFsdWU9e2NvbmR1Y3RvckFjb21ldGlkYSA/PyAnJ31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnY29uZHVjdG9yQWNvbWV0aWRhJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgZm9udC1tb25vIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gM3goMXg1MDAga2NtaWwpIEN1IFRUVVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIExvbmdpdHVkIEFjb21ldGlkYSAvIE7CsCBGYXNlcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPkxvbmdpdHVkIEFjb21ldGlkYSAobWV0cm9zKTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgIHZhbHVlPXtsb25naXR1ZEFjb21ldGlkYSA/PyAnJ31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnbG9uZ2l0dWRBY29tZXRpZGEnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMy41IHB5LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCBmb250LW1vbm8gcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiA0NSBtIC8gMyBGYXNlcyArIE5cIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBFbGVtZW50byBkZSBNYW5pb2JyYSAvIFByb3RlY2Npw7NuIEdlbmVyYWwgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjUgbWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPkVsZW1lbnRvIGRlIE1hbmlvYnJhIC8gUHJvdGVjY2nDs24gR2VuZXJhbDwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICB7WydCcmVha2VyJywgJ0NvcnRhY2lyY3VpdG8gRnVzaWJsZScsICdTZWNjaW9uYWRvcicsICdJbnRlcnJ1cHRvciBlbiBWYWPDrW8vU0Y2J10ubWFwKChlbGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IGVsZW1lbnRvTWFuaW9icmEgPT09IGVsZW07XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAga2V5PXtlbGVtfVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRPbmx5fVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB1cGRhdGVGaWVsZCgnZWxlbWVudG9NYW5pb2JyYScsIGVsZW0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTIuNSB0ZXh0LWNlbnRlciByb3VuZGVkLXhsIGJvcmRlciB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS02MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgJHtcbiAgICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgYm9yZGVyLWFtYmVyLTUwMCBzaGFkb3ctbWQgcHJpbnQ6YmctYW1iZXItMTAwIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1hbWJlci02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItc2xhdGUtNzAwIHByaW50OmJnLWdyYXktNTAgcHJpbnQ6dGV4dC1zbGF0ZS03MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgWyB7aXNTZWxlY3RlZCA/ICfinJMnIDogJyAnfSBdIHtlbGVtfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDYXBhY2lkYWQgZGUgSW50ZXJydXBjacOzbiBHZW5lcmFsICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41IG1kOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5DYXBhY2lkYWQgZGUgSW50ZXJydXBjacOzbiBHZW5lcmFsIChNYXJjYSAvIE1vZGVsbyAvIEFtcGVyYWplKTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgIHZhbHVlPXtjYXBhY2lkYWRJbnRlcnJ1cGNpb24gPz8gJyd9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ2NhcGFjaWRhZEludGVycnVwY2lvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0zLjUgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIGZvbnQtbW9ubyBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDAgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIFNxdWFyZSBEIC8gTWFzdGVycGFjdCBOVzE2IC8gMTYwMEEgLSA2NWtBXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTRUNDScOTTiAzOiBTaXN0ZW1hIGRlIFRyYW5zZm9ybWFjacOzbiAoU2kgYXBsaWNhKSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHJvdW5kZWQtMnhsIHAtNSBzcGFjZS15LTQgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci01MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0yLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgPEFjdGl2aXR5IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPiAzLiBTaXN0ZW1hIGRlIFRyYW5zZm9ybWFjacOzbiAoU2kgYXBsaWNhKVxuICAgICAgICA8L2gzPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNVwiPlxuICAgICAgICAgIHsvKiBVYmljYWNpw7NuIGRlbCBUcmFuc2Zvcm1hZG9yICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMlwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPlViaWNhY2nDs24gZGVsIFRyYW5zZm9ybWFkb3I8L2xhYmVsPlxuICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgJ0ludGVtcGVyaWUgKFBvc3RlL1BhZG1vdW50ZWQpJyxcbiAgICAgICAgICAgICAgJ1N1YmVzdGFjacOzbiBJbnRlcmlvciAvIENhc2V0YSdcbiAgICAgICAgICAgIF0ubWFwKCh1YmljKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSB1YmljYWNpb25UcmFuc2Zvcm1hZG9yID09PSB1YmljO1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGtleT17dWJpY31cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRPbmx5fVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlRmllbGQoJ3ViaWNhY2lvblRyYW5zZm9ybWFkb3InLCB1YmljKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTIgcHgtMyB0ZXh0LWxlZnQgcm91bmRlZC14bCBib3JkZXIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkICR7XG4gICAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgYm9yZGVyLWFtYmVyLTUwMCBzaGFkb3ctbWQgcHJpbnQ6YmctYW1iZXItMTAwIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1hbWJlci02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCBwcmludDpiZy1ncmF5LTUwIHByaW50OnRleHQtc2xhdGUtNzAwIHByaW50OmJvcmRlci1ncmF5LTMwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFsge2lzU2VsZWN0ZWQgPyAn4pyTJyA6ICcgJ30gXSB7dWJpY31cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFByb3BpZWRhZCBkZWwgVHJhbnNmb3JtYWRvciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5Qcm9waWVkYWQgZGVsIFRyYW5zZm9ybWFkb3I8L2xhYmVsPlxuICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgJ0VtcHJlc2EgRGlzdHJpYnVpZG9yYScsXG4gICAgICAgICAgICAgICdDbGllbnRlIFByaXZhZG8nXG4gICAgICAgICAgICBdLm1hcCgocHJvcCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gcHJvcGllZGFkVHJhbnNmb3JtYWRvciA9PT0gcHJvcDtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3Byb3B9XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkT25seX1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUZpZWxkKCdwcm9waWVkYWRUcmFuc2Zvcm1hZG9yJywgcHJvcCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTMgdGV4dC1sZWZ0IHJvdW5kZWQteGwgYm9yZGVyIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTYwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCAke1xuICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGJvcmRlci1hbWJlci01MDAgc2hhZG93LW1kIHByaW50OmJnLWFtYmVyLTEwMCBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItYW1iZXItNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAgcHJpbnQ6YmctZ3JheS01MCBwcmludDp0ZXh0LXNsYXRlLTcwMCBwcmludDpib3JkZXItZ3JheS0zMDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBbIHtpc1NlbGVjdGVkID8gJ+KckycgOiAnICd9IF0ge3Byb3B9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBVc28gZGVsIHRyYW5zZm9ybWFkb3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+VXNvIGRlbCBUcmFuc2Zvcm1hZG9yPC9sYWJlbD5cbiAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgICdFeGNsdXNpdm8nLFxuICAgICAgICAgICAgICAnQ29tcGFydGlkbydcbiAgICAgICAgICAgIF0ubWFwKCh1c28pID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHVzb1RyYW5zZm9ybWFkb3IgPT09IHVzbztcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3Vzb31cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRPbmx5fVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlRmllbGQoJ3Vzb1RyYW5zZm9ybWFkb3InLCB1c28pfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMiBweC0zIHRleHQtbGVmdCByb3VuZGVkLXhsIGJvcmRlciB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS02MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgJHtcbiAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBib3JkZXItYW1iZXItNTAwIHNoYWRvdy1tZCBwcmludDpiZy1hbWJlci0xMDAgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWFtYmVyLTYwMCdcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItc2xhdGUtNzAwIHByaW50OmJnLWdyYXktNTAgcHJpbnQ6dGV4dC1zbGF0ZS03MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgWyB7aXNTZWxlY3RlZCA/ICfinJMnIDogJyAnfSBdIHt1c299XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFNFQ0NJw5NOIDQ6IEVzcGVjaWZpY2FjaW9uZXMgZGVsIFNpc3RlbWEgZGUgTWVkaWNpw7NuICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgcm91bmRlZC0yeGwgcC01IHNwYWNlLXktNCBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWFtYmVyLTUwMCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTIuNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICA8R2F1Z2UgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+IDQuIEVzcGVjaWZpY2FjaW9uZXMgZGVsIFNpc3RlbWEgZGUgTWVkaWNpw7NuXG4gICAgICAgIDwvaDM+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC01XCI+XG4gICAgICAgICAgey8qIFViaWNhY2nDs24gZGVsIE1lZGlkb3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5VYmljYWNpw7NuIGRlbCBNZWRpZG9yPC9sYWJlbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiPlxuICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgICdMYWRvIGRlIEFsdGEvTWVkaWEgVGVuc2nDs24nLFxuICAgICAgICAgICAgICAgICdMYWRvIGRlIEJhamEgVGVuc2nDs24nXG4gICAgICAgICAgICAgIF0ubWFwKCh1YmljKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHViaWNhY2lvbk1lZGlkb3IgPT09IHViaWM7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAga2V5PXt1YmljfVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRPbmx5fVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB1cGRhdGVGaWVsZCgndWJpY2FjaW9uTWVkaWRvcicsIHViaWMpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTIgdGV4dC1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkICR7XG4gICAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGJvcmRlci1hbWJlci01MDAgc2hhZG93LW1kIHByaW50OmJnLWFtYmVyLTEwMCBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItYW1iZXItNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCBwcmludDpiZy1ncmF5LTUwIHByaW50OnRleHQtc2xhdGUtNzAwIHByaW50OmJvcmRlci1ncmF5LTMwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFsge2lzU2VsZWN0ZWQgPyAn4pyTJyA6ICcgJ30gXSB7dWJpY31cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVGlwbyBkZSBNZWRpY2nDs24gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5UaXBvIGRlIE1lZGljacOzbjwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAnRGlyZWN0YScsXG4gICAgICAgICAgICAgICAgJ0luZGlyZWN0YSdcbiAgICAgICAgICAgICAgXS5tYXAoKHRpcG8pID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gdGlwb01lZGljaW9uID09PSB0aXBvO1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGtleT17dGlwb31cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkT25seX1cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlRmllbGQoJ3RpcG9NZWRpY2lvbicsIHRpcG8pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTIgdGV4dC1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNjAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkICR7XG4gICAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGJvcmRlci1hbWJlci01MDAgc2hhZG93LW1kIHByaW50OmJnLWFtYmVyLTEwMCBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItYW1iZXItNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCBwcmludDpiZy1ncmF5LTUwIHByaW50OnRleHQtc2xhdGUtNzAwIHByaW50OmJvcmRlci1ncmF5LTMwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFsge2lzU2VsZWN0ZWQgPyAn4pyTJyA6ICcgJ30gXSB7dGlwb31cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogTWFyY2EgLyBNb2RlbG8gZGVsIE1lZGlkb3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5NYXJjYSAvIE1vZGVsbyBkZWwgTWVkaWRvcjwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgIHZhbHVlPXttYXJjYU1vZGVsb01lZGlkb3IgPz8gJyd9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ21hcmNhTW9kZWxvTWVkaWRvcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0zLjUgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gRWxzdGVyIEExODAwIEFMUEhBIC8gSU9ONzY1MFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE7CsCBkZSBTZXJpZSAvIEHDsW8gZGUgRmFicmljYWNpw7NuICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41XCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+TsKwIGRlIFNlcmllIC8gQcOxbyBkZSBGYWJyaWNhY2nDs248L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRPbmx5fVxuICAgICAgICAgICAgICB2YWx1ZT17bnVtZXJvU2VyaWVBbm8gPz8gJyd9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ251bWVyb1NlcmllQW5vJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgZm9udC1tb25vIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gU04tNzQ5MjAxOSAvIDIwMjJcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFNFQ0NJw5NOIDQuMTogTWV0cm9sb2fDrWEgRWzDqWN0cmljYSB5IFRlbnNpb25lcyBOb3JtYWxpemFkYXMgKi99XG4gICAgICA8TWV0cm9sb2dpYUVsZWN0cmljYVNlY3Rpb25cbiAgICAgICAgbWVkaWNpb25lcz17cHVudG9EYXRhLm1lZGljaW9uZXMgfHwge319XG4gICAgICAgIG9uQ2hhbmdlPXsobnVldmFzTWVkaWNpb25lcywgZmllbGQsIHZhbCkgPT4ge1xuICAgICAgICAgIGlmICh0eXBlb2YgbnVldmFzTWVkaWNpb25lcyA9PT0gJ29iamVjdCcgJiYgbnVldmFzTWVkaWNpb25lcyAhPT0gbnVsbCkge1xuICAgICAgICAgICAgdXBkYXRlRmllbGQoJ21lZGljaW9uZXMnLCBudWV2YXNNZWRpY2lvbmVzKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBudWV2YXNNZWRpY2lvbmVzID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgdXBkYXRlRmllbGQoJ21lZGljaW9uZXMnLCB7XG4gICAgICAgICAgICAgIC4uLihwdW50b0RhdGEubWVkaWNpb25lcyB8fCB7fSksXG4gICAgICAgICAgICAgIFtudWV2YXNNZWRpY2lvbmVzXTogdmFsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH19XG4gICAgICAgIHRpdHVsbz1cIjQuMSBNZXRyb2xvZ8OtYSBFbMOpY3RyaWNhIGVuIFB1bnRvIGRlIFN1bWluaXN0cm9cIlxuICAgICAgICBzdWJ0aXR1bG89XCJUZW5zaW9uZXMgTMOtbmVhLUzDrW5lYSwgTMOtbmVhLU5ldXRybyB5IDUgQ2FuYWxlcyBkZSBDb3JyaWVudGUgKENPVkVOSU4gMTU5KVwiXG4gICAgICAgIHJlYWRPbmx5PXtyZWFkT25seX1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBTRUNDScOTTiA1OiBBbm9tYWzDrWFzIHUgb2JzZXJ2YWNpb25lcyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHJvdW5kZWQtMnhsIHAtNSBzcGFjZS15LTQgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci01MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0yLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPiA1LiBBbm9tYWzDrWFzIHUgb2JzZXJ2YWNpb25lc1xuICAgICAgICA8L2gzPlxuXG4gICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgIHZhbHVlPXtvYnNlcnZhY2lvbmVzfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ29ic2VydmFjaW9uZXMnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgcm93cz17NH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgcC0zLjUgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbi1hbGwgcGxhY2Vob2xkZXItc2xhdGUtNjAwIGZvbnQtc2FucyBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXNjcmliYSBhcXXDrSBsYXMgb2JzZXJ2YWNpb25lcywgaGFsbGF6Z29zIG8gYW5vbWFsw61hcyBkZXRlY3RhZGFzIGVuIGxhIGFjb21ldGlkYSwgdHJhbnNmb3JtYWRvciBvIGVxdWlwbyBkZSBtZWRpY2nDs24uLi5cIlxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBDaWVycmUgeSBGaXJtYXMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MC80MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCByb3VuZGVkLTJ4bCBwLTUgc3BhY2UteS00IHByaW50OmJnLXNsYXRlLTUwIHByaW50OmJvcmRlci1ncmF5LTMwMCBwcmludDptdC00XCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMCBwYi0yLjUgcHJpbnQ6dGV4dC1zbGF0ZS03MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgQ2llcnJlIGRlbCBMZXZhbnRhbWllbnRvIHkgVmFsaWRleiBUw6ljbmljYVxuICAgICAgICA8L2gzPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxuICAgICAgICAgIHsvKiBGaXJtYSBJbnNwZWN0b3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjUgaXRlbXMtY2VudGVyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5GaXJtYSBkZWwgSW5zcGVjdG9yIC8gVMOpY25pY288L3NwYW4+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17ZmlybWFJbnNwZWN0b3J9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ2Zpcm1hSW5zcGVjdG9yJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCB0ZXh0LWNlbnRlciBuby1wcmludFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tYnJlIC8gSW5pY2lhbGVzIGRlbCBJbnNwZWN0b3JcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBwcmludDpibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtdC0xIGgtNlwiPlxuICAgICAgICAgICAgICB7ZmlybWFJbnNwZWN0b3IgfHwgJ19fX19fX19fX19fX19fX19fX19fX19fX19fXyd9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBwcmludDpibG9jayB3LTQ4IGJvcmRlci1iIGJvcmRlci1ncmF5LTQwMCBtdC02IGgtMVwiPjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEZpcm1hIFN1cGVydmlzb3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjUgaXRlbXMtY2VudGVyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5GaXJtYSAvIFNlbGxvIGRlIGxhIEVtcHJlc2E8L3NwYW4+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17ZmlybWFTdXBlcnZpc29yfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUZpZWxkKCdmaXJtYVN1cGVydmlzb3InLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy14cyBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyIG5vLXByaW50XCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb21icmUgLyBTZWxsbyBkZSBsYSBFbXByZXNhXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gcHJpbnQ6YmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbXQtMSBoLTZcIj5cbiAgICAgICAgICAgICAge2Zpcm1hU3VwZXJ2aXNvciB8fCAnX19fX19fX19fX19fX19fX19fX19fX19fX19fJ31cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHByaW50OmJsb2NrIHctNDggYm9yZGVyLWIgYm9yZGVyLWdyYXktNDAwIG10LTYgaC0xXCI+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxNb2RhbEVkaWNpb25DaXJjdWl0b1xuICAgICAgICBpc09wZW49e21vZGFsSmVyYXJxdWlhT3Blbn1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0TW9kYWxKZXJhcnF1aWFPcGVuKGZhbHNlKX1cbiAgICAgICAgY2lyY3VpdERhdGE9e2NpcmN1aXREYXRhV2l6YXJkfVxuICAgICAgICBtb2RvPXt3aXphcmRNb2RvfVxuICAgICAgICB0aXBvT3JpZ2VuPVwiUFVOVE9fTUVESUNJT05cIlxuICAgICAgICBlbGVtZW50b3NDcmVhZG9zPXtbXX1cbiAgICAgICAgb25TYXZlPXsoY2lyY3VpdElkLCB1cGRhdGVkKSA9PiB7XG4gICAgICAgICAgaWYgKHVwZGF0ZWQudGlwb0Rlc3Rpbm8gPT09ICdTVUJfVEFCTEVST19QRU5ESUVOVEUnICYmIHB1bnRvRGF0YT8ucHJveWVjdG9JZCkge1xuICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdQcm92SWQgPSB1cGRhdGVkLmVsZW1lbnRvRGVzdGlub0lkIHx8IHVwZGF0ZWQudmluY3VsYWRvSWQ7XG4gICAgICAgICAgICBpZiAoIWV4aXN0aW5nUHJvdklkKSB7XG4gICAgICAgICAgICAgIGNyZWFyRWxlbWVudG9Qcm92aXNpb25hbChwdW50b0RhdGEucHJveWVjdG9JZCwge1xuICAgICAgICAgICAgICAgIG5vbWJyZTogdXBkYXRlZC5lcXVpcG8gJiYgdXBkYXRlZC5lcXVpcG8gIT09ICdSRVNFUlZBIChQZW5kaWVudGUgcG9yIENyZWFyKScgPyB1cGRhdGVkLmVxdWlwbyA6IGBTdWItVGFibGVybyBBbGltZW50YWRvICgke2NpcmN1aXRJZH0pYCxcbiAgICAgICAgICAgICAgICB0aXBvRWxlbWVudG86ICdUQUJMRVJPJyxcbiAgICAgICAgICAgICAgICBjaXJjdWl0b09yaWdlbjogY2lyY3VpdElkXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAod2l6YXJkTW9kbyA9PT0gJ0VOVFJBREEnKSB7XG4gICAgICAgICAgICB1cGRhdGVGaWVsZCgncHVudG9Db25leGlvblBDQycsIHVwZGF0ZWQuZXF1aXBvKTtcbiAgICAgICAgICB9XG4gICAgICAgIH19XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl19