import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/HelpModal.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { X, HelpCircle, ShieldCheck, Key, Lock, BookOpen, FileCode, Zap, AlertTriangle, CheckCircle2, Info } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/HelpModal.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function HelpModal({ isOpen, onClose }) {
	_s();
	const [activeTab, setActiveTab] = useState("roles");
	if (!isOpen) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400",
							children: /* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 29,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 28,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-bold text-slate-100",
							children: "Manual de Usuario y Centro de Ayuda"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Guía operativa, normativas eléctricas y seguridad del sistema"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "text-slate-400 hover:text-slate-100 p-2 rounded-lg hover:bg-slate-800 transition-colors",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 40,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex border-b border-slate-800 bg-slate-950/30 px-6 gap-2 overflow-x-auto text-xs font-semibold",
					children: [
						{
							id: "roles",
							label: "Roles y Permisos",
							icon: ShieldCheck
						},
						{
							id: "security",
							label: "Seguridad y 2FA",
							icon: Lock
						},
						{
							id: "normativa",
							label: "Normativa Eléctrica",
							icon: Zap
						},
						{
							id: "dxf",
							label: "Exportación DXF / CAD",
							icon: FileCode
						},
						{
							id: "auditoria",
							label: "Auditoría y Alarmas",
							icon: AlertTriangle
						}
					].map((tab) => {
						const Icon = tab.icon;
						const active = activeTab === tab.id;
						return /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab(tab.id),
							className: `py-3 px-3 flex items-center gap-2 border-b-2 transition-all whitespace-nowrap ${active ? "border-amber-500 text-amber-400 font-bold bg-amber-500/5" : "border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700"}`,
							children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 17
							}, this), tab.label]
						}, tab.id, true, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-6 overflow-y-auto space-y-6 text-xs leading-relaxed text-slate-300",
					children: [
						activeTab === "roles" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-amber-400 flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 17
								}, this), " Matriz de Roles y Permisos (RBAC)"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-3 gap-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "px-2 py-0.5 w-max rounded bg-purple-500/20 text-purple-400 font-bold text-[10px] border border-purple-500/30",
												children: "ADMIN"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 83,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("h4", {
												className: "font-bold text-slate-100",
												children: "Administrador Total"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 84,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("ul", {
												className: "space-y-1 text-slate-400 list-disc list-inside",
												children: [
													/* @__PURE__ */ _jsxDEV("li", { children: "Crear, editar y eliminar empresas y proyectos." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 86,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", { children: "Gestión de usuarios y asignación de roles." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 87,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", { children: "Respaldos JSON y sincronización Google Drive." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 88,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", { children: "Eliminación de tableros y circuitos." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 89,
														columnNumber: 21
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 85,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 82,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "px-2 py-0.5 w-max rounded bg-blue-500/20 text-blue-400 font-bold text-[10px] border border-blue-500/30",
												children: "WORKER"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 94,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("h4", {
												className: "font-bold text-slate-100",
												children: "Ingeniero / Inspector"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 95,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("ul", {
												className: "space-y-1 text-slate-400 list-disc list-inside",
												children: [
													/* @__PURE__ */ _jsxDEV("li", { children: "Levantamiento de tableros y circuitos en campo." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 97,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", { children: "Cálculo de balance de fases y factor de potencia." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 98,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", { children: "Registro de inspecciones técnicas (Termografía, Tierras)." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 99,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", { children: "Exportación de informes y diagramas DXF." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 100,
														columnNumber: 21
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 96,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 93,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "px-2 py-0.5 w-max rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px] border border-emerald-500/30",
												children: "CLIENT"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 105,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("h4", {
												className: "font-bold text-slate-100",
												children: "Cliente / Observador"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 106,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("ul", {
												className: "space-y-1 text-slate-400 list-disc list-inside",
												children: [
													/* @__PURE__ */ _jsxDEV("li", { children: "Acceso exclusivo a su empresa asociada (Multitenancy)." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 108,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", { children: "Modo solo lectura de tableros y diagramas." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 109,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", { children: "Visualización y descarga de informes compilados." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 110,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", { children: "Revisión de alarmas y estado de red." }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 111,
														columnNumber: 21
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 107,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 104,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 13
						}, this),
						activeTab === "security" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-amber-400 flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Lock, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 17
								}, this), " Recuperación de Contraseña y Autenticación 2FA"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("h4", {
										className: "font-bold text-slate-100 flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(Key, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 127,
											columnNumber: 21
										}, this), " Solicitud de Restablecimiento de Clave"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-400",
										children: [
											"Si olvidó sus credenciales, puede solicitar el enlace de reseteo mediante el endpoint seguro",
											/* @__PURE__ */ _jsxDEV("code", {
												className: "mx-1 px-1.5 py-0.5 bg-slate-900 border border-slate-700 rounded text-amber-400",
												children: "POST /api/users/request-reset"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 131,
												columnNumber: 21
											}, this),
											"con su nombre de usuario. Se generará un token JWT con vigencia de 1 hora."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 129,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("h4", {
										className: "font-bold text-slate-100 flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 138,
											columnNumber: 21
										}, this), " Verificación de Dos Factores (2FA)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 137,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-400",
										children: [
											"Para elevar la seguridad en operaciones críticas (exportación masiva, reseteo de red), se valida el código OTP de 6 dígitos mediante ",
											/* @__PURE__ */ _jsxDEV("code", {
												className: "mx-1 px-1.5 py-0.5 bg-slate-900 border border-slate-700 rounded text-amber-400",
												children: "POST /api/users/verify-2fa"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 142,
												columnNumber: 67
											}, this),
											"."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 140,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 13
						}, this),
						activeTab === "normativa" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-amber-400 flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 153,
									columnNumber: 17
								}, this), " Criterios Normativos (NEC / Fondonorma / COVENIN)"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start gap-3",
										children: [/* @__PURE__ */ _jsxDEV(Info, { className: "w-5 h-5 text-blue-400 shrink-0 mt-0.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 157,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-200 block",
											children: "Límite de Desbalance de Fases: Máx 15%"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 159,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400",
											children: [
												"Calculado con la fórmula estandarizada: ",
												/* @__PURE__ */ _jsxDEV("code", { children: "% Desbalance = (Máxima desviación de corriente / Corriente promedio) * 100" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 161,
													columnNumber: 63
												}, this),
												". Valores mayores al 15% reducen la vida útil del transformador y provocan calentamiento en el conductor neutro."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 160,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 158,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 156,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start gap-3",
										children: [/* @__PURE__ */ _jsxDEV(Info, { className: "w-5 h-5 text-amber-400 shrink-0 mt-0.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 168,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-200 block",
											children: "Régimen de Carga Continua: Máx 80%"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 170,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400",
											children: "Para cargas activas durante más de 3 horas continuas, la corriente de fase no debe superar el 80% de la capacidad nominal del interruptor principal (Art. 210-20 NEC)."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 171,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 169,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 167,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start gap-3",
										children: [/* @__PURE__ */ _jsxDEV(Info, { className: "w-5 h-5 text-emerald-400 shrink-0 mt-0.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 178,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-200 block",
											children: "Factor de Potencia Óptimo: FP >= 0.90"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 180,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400",
											children: [
												"Cálculo de potencia reactiva requerida: ",
												/* @__PURE__ */ _jsxDEV("code", { children: "kVAR = kVA * √(1 - FP²)" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 182,
													columnNumber: 63
												}, this),
												" para compensación con bancos de condensadores."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 181,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 179,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 177,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 13
						}, this),
						activeTab === "dxf" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-bold text-amber-400 flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(FileCode, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 194,
										columnNumber: 17
									}, this), " Exportación DXF a AutoCAD (Capa 3)"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 193,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-400",
									children: "El sistema genera archivos en formato estándar **ASCII DXF Release 12 (AC1009)**, compatibles con cualquier versión de AutoCAD, LibreCAD, ZWCAD o Visio."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 sm:grid-cols-4 gap-3 text-center",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 font-bold",
											children: "Fase A (Rojo)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-2.5 rounded-lg bg-yellow-500/10 border border-yellow-500/30 text-yellow-400 font-bold",
											children: "Fase B (Amarillo)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 201,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-2.5 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 font-bold",
											children: "Fase C (Azul)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 202,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold",
											children: "Tierra (Verde)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 203,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 199,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-400 text-[11px]",
									children: [
										"💡 Para exportar, presione el botón ",
										/* @__PURE__ */ _jsxDEV("strong", { children: "\"Descargar DXF\"" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 206,
											columnNumber: 53
										}, this),
										" ubicado en la cabecera de cualquier tablero eléctrico."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 205,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 13
						}, this),
						activeTab === "auditoria" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-amber-400 flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 215,
									columnNumber: 17
								}, this), " Motor de Auditoría y Alarmas Eléctricas (Capas 5 y 8)"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 214,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2 text-slate-400",
								children: [/* @__PURE__ */ _jsxDEV("p", { children: "El motor de auditoría evalúa en tiempo real:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("ul", {
									className: "list-disc list-inside space-y-1 text-slate-300",
									children: [
										/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Elementos Huérfanos:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 220,
											columnNumber: 23
										}, this), " Equipos sin conexión aguas arriba ni aguas abajo en la red jerárquica."] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 220,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Tableros Sin Carga:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 221,
											columnNumber: 23
										}, this), " Tableros activos con 0 VA o sin circuitos operativos registrados."] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 221,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Alarmas de Desbalance:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 222,
											columnNumber: 23
										}, this), " Disparo automático cuando el desbalance entre fases supera el 15%."] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 222,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Alarmas de Sobrecarga:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 223,
											columnNumber: 23
										}, this), " Alerta inmediata ante sobrepaso del 80% o 100% de la capacidad del interruptor."] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 223,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 219,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 213,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-3 border-t border-slate-800 bg-slate-950/60 flex justify-end",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition-colors",
						children: "Entendido"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 232,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
}
_s(HelpModal, "2NZtoe9XKbX04Ijy5BmVtF6POVM=");
_c = HelpModal;
var _c;
$RefreshReg$(_c, "HelpModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/HelpModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/HelpModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/HelpModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/HelpModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLEdBQ0EsWUFDQSxhQUNBLEtBQ0EsTUFDQSxVQUNBLFVBQ0EsS0FDQSxlQUNBLGNBQ0EsWUFDSzs7OztBQUVQLGVBQWUsU0FBUyxVQUFVLEVBQUUsUUFBUSxXQUFXOztDQUNyRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxPQUFPO0NBRWxELElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFHRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7OztNQUM5Qjs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXFDO01BQXVDOzs7O2dCQUMxRix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUI7TUFBZ0U7Ozs7Y0FDbkc7Ozs7Y0FDRjs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7S0FDbEI7Ozs7YUFDTDs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWjtNQUNDO09BQUUsSUFBSTtPQUFTLE9BQU87T0FBb0IsTUFBTTtNQUFZO01BQzVEO09BQUUsSUFBSTtPQUFZLE9BQU87T0FBbUIsTUFBTTtNQUFLO01BQ3ZEO09BQUUsSUFBSTtPQUFhLE9BQU87T0FBdUIsTUFBTTtNQUFJO01BQzNEO09BQUUsSUFBSTtPQUFPLE9BQU87T0FBeUIsTUFBTTtNQUFTO01BQzVEO09BQUUsSUFBSTtPQUFhLE9BQU87T0FBdUIsTUFBTTtNQUFjO0tBQ3ZFLENBQUMsQ0FBQyxLQUFJLFFBQU87TUFDWCxNQUFNLE9BQU8sSUFBSTtNQUNqQixNQUFNLFNBQVMsY0FBYyxJQUFJO01BQ2pDLE9BQ0Usd0JBQUMsVUFBRDtPQUVFLGVBQWUsYUFBYSxJQUFJLEVBQUU7T0FDbEMsV0FBVyxpRkFDVCxTQUNJLDZEQUNBO2lCQU5SLENBU0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7OztpQkFDMUIsSUFBSSxLQUNDO1NBVkQsSUFBSTs7OzthQVVIO0tBRVosQ0FBQztJQUNFOzs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFHRyxjQUFjLFdBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7a0JBQUMsb0NBQ2pDOzs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQStHO1dBQVU7Ozs7O1dBQ3hJLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUEyQjtXQUF1Qjs7Ozs7V0FDaEUsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQ7YUFDRSx3QkFBQyxNQUFELFlBQUksaURBQWtEOzs7OzthQUN0RCx3QkFBQyxNQUFELFlBQUksNkNBQThDOzs7OzthQUNsRCx3QkFBQyxNQUFELFlBQUksZ0RBQWlEOzs7OzthQUNyRCx3QkFBQyxNQUFELFlBQUksdUNBQXdDOzs7OztZQUMxQzs7Ozs7O1VBQ0Q7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQXlHO1dBQVc7Ozs7O1dBQ25JLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUEyQjtXQUF5Qjs7Ozs7V0FDbEUsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQ7YUFDRSx3QkFBQyxNQUFELFlBQUksa0RBQW1EOzs7OzthQUN2RCx3QkFBQyxNQUFELFlBQUksb0RBQXFEOzs7OzthQUN6RCx3QkFBQyxNQUFELFlBQUksNERBQTZEOzs7OzthQUNqRSx3QkFBQyxNQUFELFlBQUksMkNBQTRDOzs7OztZQUM5Qzs7Ozs7O1VBQ0Q7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWtIO1dBQVc7Ozs7O1dBQzVJLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUEyQjtXQUF3Qjs7Ozs7V0FDakUsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQ7YUFDRSx3QkFBQyxNQUFELFlBQUkseURBQTBEOzs7OzthQUM5RCx3QkFBQyxNQUFELFlBQUksNkNBQThDOzs7OzthQUNsRCx3QkFBQyxNQUFELFlBQUksbURBQW9EOzs7OzthQUN4RCx3QkFBQyxNQUFELFlBQUksdUNBQXdDOzs7OztZQUMxQzs7Ozs7O1VBQ0Q7Ozs7OztRQUNGOzs7OztlQUNGOzs7Ozs7TUFJTixjQUFjLGNBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7a0JBQUMsaURBQzFCOzs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7b0JBQUMseUNBQ3hDOzs7OzttQkFDSix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYjtXQUE4QjtXQUU1Qix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUY7V0FBbUM7Ozs7O1dBQUM7VUFFcEk7Ozs7O2lCQUNBOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUsMkJBQTRCOzs7O29CQUFDLHFDQUNuRDs7Ozs7bUJBQ0osd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWI7V0FBOEI7V0FFa0Isd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWlGO1dBQWdDOzs7OztXQUFDO1VBQy9LOzs7OztpQkFDQTs7Ozs7Z0JBQ0Y7Ozs7O2VBQ0Y7Ozs7OztNQUlOLGNBQWMsZUFDYix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsS0FBRCxFQUFLLFdBQVUsVUFBVzs7OztrQkFBQyxvREFDekI7Ozs7O2lCQUNKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSx3Q0FBeUM7Ozs7b0JBQ3pELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxVQUFEO1dBQVEsV0FBVTtxQkFBdUI7VUFBOEM7Ozs7b0JBQ3ZGLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQjtZQUFpQztZQUNTLHdCQUFDLFFBQUQsWUFBTSw2RUFBZ0Y7Ozs7O1lBQUM7V0FFM0g7Ozs7O2tCQUNIOzs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHlDQUEwQzs7OztvQkFDMUQsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFVBQUQ7V0FBUSxXQUFVO3FCQUF1QjtVQUEwQzs7OztvQkFDbkYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWlCO1VBRTNCOzs7O2tCQUNIOzs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLDJDQUE0Qzs7OztvQkFDNUQsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFVBQUQ7V0FBUSxXQUFVO3FCQUF1QjtVQUFnRDs7OztvQkFDekYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCO1lBQWlDO1lBQ1Msd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7Ozs7WUFBQztXQUN4RTs7Ozs7a0JBQ0g7Ozs7a0JBQ0Y7Ozs7OztRQUNGOzs7OztlQUNGOzs7Ozs7TUFJTixjQUFjLFNBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7bUJBQUMscUNBQzlCOzs7Ozs7UUFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBaUI7UUFFM0I7Ozs7O1FBQ0gsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBaUY7VUFBa0I7Ozs7O1VBQ2xILHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUEwRjtVQUFzQjs7Ozs7VUFDL0gsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQW9GO1VBQWtCOzs7OztVQUNySCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBNkY7VUFBbUI7Ozs7O1NBQzVIOzs7Ozs7UUFDTCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUEwQztVQUNKLHdCQUFDLFVBQUQsWUFBUSxvQkFBdUI7Ozs7O1VBQUM7U0FDbkU7Ozs7OztPQUNBOzs7Ozs7TUFJTixjQUFjLGVBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLFVBQVc7Ozs7a0JBQUMsd0RBQ25DOzs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLEtBQUQsWUFBRywrQ0FBK0M7Ozs7a0JBQ2xELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkO1VBQ0Usd0JBQUMsTUFBRCxhQUFJLHdCQUFDLFVBQUQsWUFBUSx1QkFBNEI7Ozs7b0JBQUMseUVBQTJFOzs7OztVQUNwSCx3QkFBQyxNQUFELGFBQUksd0JBQUMsVUFBRCxZQUFRLHNCQUEyQjs7OztvQkFBQyxvRUFBc0U7Ozs7O1VBQzlHLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxVQUFELFlBQVEseUJBQThCOzs7O29CQUFDLHFFQUF1RTs7Ozs7VUFDbEgsd0JBQUMsTUFBRCxhQUFJLHdCQUFDLFVBQUQsWUFBUSx5QkFBOEI7Ozs7b0JBQUMsa0ZBQW9GOzs7OztTQUM3SDs7Ozs7Z0JBQ0Q7Ozs7O2VBQ0Y7Ozs7OztLQUdKOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7OztJQUNMOzs7OztHQUVGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIZWxwTW9kYWwuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBYLCBcbiAgSGVscENpcmNsZSwgXG4gIFNoaWVsZENoZWNrLCBcbiAgS2V5LCBcbiAgTG9jaywgXG4gIEJvb2tPcGVuLCBcbiAgRmlsZUNvZGUsIFxuICBaYXAsIFxuICBBbGVydFRyaWFuZ2xlLCBcbiAgQ2hlY2tDaXJjbGUyLCBcbiAgSW5mbyBcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSGVscE1vZGFsKHsgaXNPcGVuLCBvbkNsb3NlIH0pIHtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKCdyb2xlcycpO1xuXG4gIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay83NSBiYWNrZHJvcC1ibHVyLXhzXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCB3LWZ1bGwgbWF4LXctNHhsIG1heC1oLVs4NXZoXSBmbGV4IGZsZXgtY29sIHNoYWRvdy0yeGwgb3ZlcmZsb3ctaGlkZGVuIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICBcbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYmctc2xhdGUtOTUwLzYwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQteGwgYmctYW1iZXItNTAwLzEwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtYW1iZXItNDAwXCI+XG4gICAgICAgICAgICAgIDxIZWxwQ2lyY2xlIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMFwiPk1hbnVhbCBkZSBVc3VhcmlvIHkgQ2VudHJvIGRlIEF5dWRhPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkd1w61hIG9wZXJhdGl2YSwgbm9ybWF0aXZhcyBlbMOpY3RyaWNhcyB5IHNlZ3VyaWRhZCBkZWwgc2lzdGVtYTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0xMDAgcC0yIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFRhYnMgZGUgTmF2ZWdhY2nDs24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTk1MC8zMCBweC02IGdhcC0yIG92ZXJmbG93LXgtYXV0byB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICB7W1xuICAgICAgICAgICAgeyBpZDogJ3JvbGVzJywgbGFiZWw6ICdSb2xlcyB5IFBlcm1pc29zJywgaWNvbjogU2hpZWxkQ2hlY2sgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdzZWN1cml0eScsIGxhYmVsOiAnU2VndXJpZGFkIHkgMkZBJywgaWNvbjogTG9jayB9LFxuICAgICAgICAgICAgeyBpZDogJ25vcm1hdGl2YScsIGxhYmVsOiAnTm9ybWF0aXZhIEVsw6ljdHJpY2EnLCBpY29uOiBaYXAgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdkeGYnLCBsYWJlbDogJ0V4cG9ydGFjacOzbiBEWEYgLyBDQUQnLCBpY29uOiBGaWxlQ29kZSB9LFxuICAgICAgICAgICAgeyBpZDogJ2F1ZGl0b3JpYScsIGxhYmVsOiAnQXVkaXRvcsOtYSB5IEFsYXJtYXMnLCBpY29uOiBBbGVydFRyaWFuZ2xlIH1cbiAgICAgICAgICBdLm1hcCh0YWIgPT4ge1xuICAgICAgICAgICAgY29uc3QgSWNvbiA9IHRhYi5pY29uO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlID0gYWN0aXZlVGFiID09PSB0YWIuaWQ7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXt0YWIuaWR9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKHRhYi5pZCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMyBweC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlci1iLTIgdHJhbnNpdGlvbi1hbGwgd2hpdGVzcGFjZS1ub3dyYXAgJHtcbiAgICAgICAgICAgICAgICAgIGFjdGl2ZSBcbiAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWFtYmVyLTUwMCB0ZXh0LWFtYmVyLTQwMCBmb250LWJvbGQgYmctYW1iZXItNTAwLzUnIFxuICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIHt0YWIubGFiZWx9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENvbnRlbmlkbyBkZWwgVGFiICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBvdmVyZmxvdy15LWF1dG8gc3BhY2UteS02IHRleHQteHMgbGVhZGluZy1yZWxheGVkIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIFRBQiAxOiBST0xFUyAqL31cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAncm9sZXMnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gTWF0cml6IGRlIFJvbGVzIHkgUGVybWlzb3MgKFJCQUMpXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctc2xhdGUtOTUwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSB3LW1heCByb3VuZGVkIGJnLXB1cnBsZS01MDAvMjAgdGV4dC1wdXJwbGUtNDAwIGZvbnQtYm9sZCB0ZXh0LVsxMHB4XSBib3JkZXIgYm9yZGVyLXB1cnBsZS01MDAvMzBcIj5BRE1JTjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMFwiPkFkbWluaXN0cmFkb3IgVG90YWw8L2g0PlxuICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMSB0ZXh0LXNsYXRlLTQwMCBsaXN0LWRpc2MgbGlzdC1pbnNpZGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxpPkNyZWFyLCBlZGl0YXIgeSBlbGltaW5hciBlbXByZXNhcyB5IHByb3llY3Rvcy48L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+R2VzdGnDs24gZGUgdXN1YXJpb3MgeSBhc2lnbmFjacOzbiBkZSByb2xlcy48L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+UmVzcGFsZG9zIEpTT04geSBzaW5jcm9uaXphY2nDs24gR29vZ2xlIERyaXZlLjwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5FbGltaW5hY2nDs24gZGUgdGFibGVyb3MgeSBjaXJjdWl0b3MuPC9saT5cbiAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdy1tYXggcm91bmRlZCBiZy1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtNDAwIGZvbnQtYm9sZCB0ZXh0LVsxMHB4XSBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzMwXCI+V09SS0VSPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwXCI+SW5nZW5pZXJvIC8gSW5zcGVjdG9yPC9oND5cbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTEgdGV4dC1zbGF0ZS00MDAgbGlzdC1kaXNjIGxpc3QtaW5zaWRlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5MZXZhbnRhbWllbnRvIGRlIHRhYmxlcm9zIHkgY2lyY3VpdG9zIGVuIGNhbXBvLjwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5Dw6FsY3VsbyBkZSBiYWxhbmNlIGRlIGZhc2VzIHkgZmFjdG9yIGRlIHBvdGVuY2lhLjwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5SZWdpc3RybyBkZSBpbnNwZWNjaW9uZXMgdMOpY25pY2FzIChUZXJtb2dyYWbDrWEsIFRpZXJyYXMpLjwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5FeHBvcnRhY2nDs24gZGUgaW5mb3JtZXMgeSBkaWFncmFtYXMgRFhGLjwvbGk+XG4gICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHctbWF4IHJvdW5kZWQgYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGQgdGV4dC1bMTBweF0gYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMFwiPkNMSUVOVDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMFwiPkNsaWVudGUgLyBPYnNlcnZhZG9yPC9oND5cbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTEgdGV4dC1zbGF0ZS00MDAgbGlzdC1kaXNjIGxpc3QtaW5zaWRlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsaT5BY2Nlc28gZXhjbHVzaXZvIGEgc3UgZW1wcmVzYSBhc29jaWFkYSAoTXVsdGl0ZW5hbmN5KS48L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+TW9kbyBzb2xvIGxlY3R1cmEgZGUgdGFibGVyb3MgeSBkaWFncmFtYXMuPC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGxpPlZpc3VhbGl6YWNpw7NuIHkgZGVzY2FyZ2EgZGUgaW5mb3JtZXMgY29tcGlsYWRvcy48L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+UmV2aXNpw7NuIGRlIGFsYXJtYXMgeSBlc3RhZG8gZGUgcmVkLjwvbGk+XG4gICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogVEFCIDI6IFNFR1VSSURBRCAmIDJGQSAqL31cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnc2VjdXJpdHknICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxMb2NrIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBSZWN1cGVyYWNpw7NuIGRlIENvbnRyYXNlw7FhIHkgQXV0ZW50aWNhY2nDs24gMkZBXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxLZXkgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTQwMFwiIC8+IFNvbGljaXR1ZCBkZSBSZXN0YWJsZWNpbWllbnRvIGRlIENsYXZlXG4gICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgU2kgb2x2aWTDsyBzdXMgY3JlZGVuY2lhbGVzLCBwdWVkZSBzb2xpY2l0YXIgZWwgZW5sYWNlIGRlIHJlc2V0ZW8gbWVkaWFudGUgZWwgZW5kcG9pbnQgc2VndXJvIFxuICAgICAgICAgICAgICAgICAgICA8Y29kZSBjbGFzc05hbWU9XCJteC0xIHB4LTEuNSBweS0wLjUgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1hbWJlci00MDBcIj5QT1NUIC9hcGkvdXNlcnMvcmVxdWVzdC1yZXNldDwvY29kZT4gXG4gICAgICAgICAgICAgICAgICAgIGNvbiBzdSBub21icmUgZGUgdXN1YXJpby4gU2UgZ2VuZXJhcsOhIHVuIHRva2VuIEpXVCBjb24gdmlnZW5jaWEgZGUgMSBob3JhLlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNDAwXCIgLz4gVmVyaWZpY2FjacOzbiBkZSBEb3MgRmFjdG9yZXMgKDJGQSlcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBQYXJhIGVsZXZhciBsYSBzZWd1cmlkYWQgZW4gb3BlcmFjaW9uZXMgY3LDrXRpY2FzIChleHBvcnRhY2nDs24gbWFzaXZhLCByZXNldGVvIGRlIHJlZCksIFxuICAgICAgICAgICAgICAgICAgICBzZSB2YWxpZGEgZWwgY8OzZGlnbyBPVFAgZGUgNiBkw61naXRvcyBtZWRpYW50ZSA8Y29kZSBjbGFzc05hbWU9XCJteC0xIHB4LTEuNSBweS0wLjUgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC1hbWJlci00MDBcIj5QT1NUIC9hcGkvdXNlcnMvdmVyaWZ5LTJmYTwvY29kZT4uXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBUQUIgMzogTk9STUFUSVZBIEVMw4lDVFJJQ0EgKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ25vcm1hdGl2YScgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gQ3JpdGVyaW9zIE5vcm1hdGl2b3MgKE5FQyAvIEZvbmRvbm9ybWEgLyBDT1ZFTklOKVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgPEluZm8gY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWJsdWUtNDAwIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIGJsb2NrXCI+TMOtbWl0ZSBkZSBEZXNiYWxhbmNlIGRlIEZhc2VzOiBNw6F4IDE1JTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIENhbGN1bGFkbyBjb24gbGEgZsOzcm11bGEgZXN0YW5kYXJpemFkYTogPGNvZGU+JSBEZXNiYWxhbmNlID0gKE3DoXhpbWEgZGVzdmlhY2nDs24gZGUgY29ycmllbnRlIC8gQ29ycmllbnRlIHByb21lZGlvKSAqIDEwMDwvY29kZT4uXG4gICAgICAgICAgICAgICAgICAgICAgVmFsb3JlcyBtYXlvcmVzIGFsIDE1JSByZWR1Y2VuIGxhIHZpZGEgw7p0aWwgZGVsIHRyYW5zZm9ybWFkb3IgeSBwcm92b2NhbiBjYWxlbnRhbWllbnRvIGVuIGVsIGNvbmR1Y3RvciBuZXV0cm8uXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8SW5mbyBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNDAwIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIGJsb2NrXCI+UsOpZ2ltZW4gZGUgQ2FyZ2EgQ29udGludWE6IE3DoXggODAlPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgUGFyYSBjYXJnYXMgYWN0aXZhcyBkdXJhbnRlIG3DoXMgZGUgMyBob3JhcyBjb250aW51YXMsIGxhIGNvcnJpZW50ZSBkZSBmYXNlIG5vIGRlYmUgc3VwZXJhciBlbCA4MCUgZGUgbGEgY2FwYWNpZGFkIG5vbWluYWwgZGVsIGludGVycnVwdG9yIHByaW5jaXBhbCAoQXJ0LiAyMTAtMjAgTkVDKS5cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQteGwgYmctc2xhdGUtOTUwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxJbmZvIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1lbWVyYWxkLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBibG9ja1wiPkZhY3RvciBkZSBQb3RlbmNpYSDDk3B0aW1vOiBGUCAmZ3Q7PSAwLjkwPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgQ8OhbGN1bG8gZGUgcG90ZW5jaWEgcmVhY3RpdmEgcmVxdWVyaWRhOiA8Y29kZT5rVkFSID0ga1ZBICog4oiaKDEgLSBGUMKyKTwvY29kZT4gcGFyYSBjb21wZW5zYWNpw7NuIGNvbiBiYW5jb3MgZGUgY29uZGVuc2Fkb3Jlcy5cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBUQUIgNDogRFhGICovfVxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdkeGYnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxGaWxlQ29kZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gRXhwb3J0YWNpw7NuIERYRiBhIEF1dG9DQUQgKENhcGEgMylcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICBFbCBzaXN0ZW1hIGdlbmVyYSBhcmNoaXZvcyBlbiBmb3JtYXRvIGVzdMOhbmRhciAqKkFTQ0lJIERYRiBSZWxlYXNlIDEyIChBQzEwMDkpKiosIGNvbXBhdGlibGVzIGNvbiBjdWFscXVpZXIgdmVyc2nDs24gZGUgQXV0b0NBRCwgTGlicmVDQUQsIFpXQ0FEIG8gVmlzaW8uXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0zIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSByb3VuZGVkLWxnIGJnLXJlZC01MDAvMTAgYm9yZGVyIGJvcmRlci1yZWQtNTAwLzMwIHRleHQtcmVkLTQwMCBmb250LWJvbGRcIj5GYXNlIEEgKFJvam8pPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSByb3VuZGVkLWxnIGJnLXllbGxvdy01MDAvMTAgYm9yZGVyIGJvcmRlci15ZWxsb3ctNTAwLzMwIHRleHQteWVsbG93LTQwMCBmb250LWJvbGRcIj5GYXNlIEIgKEFtYXJpbGxvKTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgcm91bmRlZC1sZyBiZy1ibHVlLTUwMC8xMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzMwIHRleHQtYmx1ZS00MDAgZm9udC1ib2xkXCI+RmFzZSBDIChBenVsKTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgcm91bmRlZC1sZyBiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkXCI+VGllcnJhIChWZXJkZSk8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAg8J+SoSBQYXJhIGV4cG9ydGFyLCBwcmVzaW9uZSBlbCBib3TDs24gPHN0cm9uZz5cIkRlc2NhcmdhciBEWEZcIjwvc3Ryb25nPiB1YmljYWRvIGVuIGxhIGNhYmVjZXJhIGRlIGN1YWxxdWllciB0YWJsZXJvIGVsw6ljdHJpY28uXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogVEFCIDU6IEFVRElUT1LDjUEgKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2F1ZGl0b3JpYScgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IE1vdG9yIGRlIEF1ZGl0b3LDrWEgeSBBbGFybWFzIEVsw6ljdHJpY2FzIChDYXBhcyA1IHkgOClcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICA8cD5FbCBtb3RvciBkZSBhdWRpdG9yw61hIGV2YWzDumEgZW4gdGllbXBvIHJlYWw6PC9wPlxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LWRpc2MgbGlzdC1pbnNpZGUgc3BhY2UteS0xIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICA8bGk+PHN0cm9uZz5FbGVtZW50b3MgSHXDqXJmYW5vczo8L3N0cm9uZz4gRXF1aXBvcyBzaW4gY29uZXhpw7NuIGFndWFzIGFycmliYSBuaSBhZ3VhcyBhYmFqbyBlbiBsYSByZWQgamVyw6FycXVpY2EuPC9saT5cbiAgICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPlRhYmxlcm9zIFNpbiBDYXJnYTo8L3N0cm9uZz4gVGFibGVyb3MgYWN0aXZvcyBjb24gMCBWQSBvIHNpbiBjaXJjdWl0b3Mgb3BlcmF0aXZvcyByZWdpc3RyYWRvcy48L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPjxzdHJvbmc+QWxhcm1hcyBkZSBEZXNiYWxhbmNlOjwvc3Ryb25nPiBEaXNwYXJvIGF1dG9tw6F0aWNvIGN1YW5kbyBlbCBkZXNiYWxhbmNlIGVudHJlIGZhc2VzIHN1cGVyYSBlbCAxNSUuPC9saT5cbiAgICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPkFsYXJtYXMgZGUgU29icmVjYXJnYTo8L3N0cm9uZz4gQWxlcnRhIGlubWVkaWF0YSBhbnRlIHNvYnJlcGFzbyBkZWwgODAlIG8gMTAwJSBkZSBsYSBjYXBhY2lkYWQgZGVsIGludGVycnVwdG9yLjwvbGk+XG4gICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBGb290ZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgYmctc2xhdGUtOTUwLzYwIGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ib2xkIHJvdW5kZWQteGwgdGV4dC14cyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgRW50ZW5kaWRvXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==