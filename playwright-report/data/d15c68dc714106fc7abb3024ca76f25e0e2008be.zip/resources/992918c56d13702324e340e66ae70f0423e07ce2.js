import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SyncStatusBanner.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { useSync } from "/src/utils/useSync.js?t=1790792337841";
import { Wifi, WifiOff, RefreshCw } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SyncStatusBanner.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function SyncStatusBanner() {
	_s();
	const { isOnline, isSyncing, pendingCount, triggerSync } = useSync();
	if (!isOnline) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-amber-500/10 border-b border-amber-500/20 text-amber-500 px-4 py-2 flex items-center justify-between w-full text-xs font-bold shadow-sm animate-pulse no-print",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { className: "w-32 hidden sm:block" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 12,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-center gap-2 flex-1 text-center min-w-0",
					children: [/* @__PURE__ */ _jsxDEV(WifiOff, { className: "w-4 h-4 text-amber-500 shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "truncate",
						children: "Modo Offline: Los datos de inspección se guardarán de forma local en la tableta."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "w-32 flex justify-end shrink-0",
					children: pendingCount > 0 && /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded text-[10px] font-mono border border-amber-500/30",
						children: [
							pendingCount,
							" pendiente",
							pendingCount > 1 ? "s" : ""
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this);
	}
	if (isSyncing) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-blue-500/10 border-b border-blue-500/20 text-blue-400 px-4 py-2 flex items-center justify-between w-full text-xs font-semibold shadow-sm no-print",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { className: "w-32 hidden sm:block" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-center gap-2 flex-1 text-center min-w-0",
					children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-4 h-4 animate-spin text-blue-400 shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "truncate",
						children: [
							"Sincronizando ",
							pendingCount,
							" inspección",
							pendingCount > 1 ? "es" : "",
							" con el servidor central..."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "w-32 flex justify-end shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 7
		}, this);
	}
	if (pendingCount > 0) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-amber-500/10 border-b border-amber-500/20 text-amber-500 px-4 py-2 flex items-center justify-between w-full text-xs font-bold shadow-sm no-print",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { className: "w-32 hidden sm:block" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-center gap-2 flex-1 text-center min-w-0",
					children: [/* @__PURE__ */ _jsxDEV(Wifi, { className: "w-4 h-4 shrink-0 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "truncate",
						children: "Conexión restablecida. Tienes datos pendientes por sincronizar."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "w-32 flex justify-end shrink-0",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: triggerSync,
						className: "flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 px-3 py-1 rounded text-[10px] font-extrabold transition-all cursor-pointer shadow-sm shrink-0",
						children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-3 h-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 13
						}, this), " Sincronizar Ahora"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 7
		}, this);
	}
	// Si está online y todo está sincronizado
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-emerald-500/10 border-b border-emerald-500/20 text-emerald-500 px-4 py-1.5 flex items-center justify-between w-full text-xs font-semibold shadow-sm transition-all duration-300 no-print",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "w-12 hidden sm:block" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-center gap-2 flex-1 text-center min-w-0",
				children: [/* @__PURE__ */ _jsxDEV(Wifi, { className: "w-4 h-4 text-emerald-500 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "truncate",
					children: "Conectado. Todos los datos están sincronizados con el servidor."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "w-12 hidden sm:block" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 77,
		columnNumber: 5
	}, this);
}
_s(SyncStatusBanner, "zDXRhSRmomnVJfqL1wd3ZULYH50=", false, function() {
	return [useSync];
});
_c = SyncStatusBanner;
var _c;
$RefreshReg$(_c, "SyncStatusBanner");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SyncStatusBanner.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SyncStatusBanner.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SyncStatusBanner.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SyncStatusBanner.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZUFBZTtBQUN4QixTQUFTLE1BQU0sU0FBUyxpQkFBaUI7Ozs7QUFFekMsZUFBZSxTQUFTLG1CQUFtQjs7Q0FDekMsTUFBTSxFQUFFLFVBQVUsV0FBVyxjQUFjLGdCQUFnQixRQUFRO0NBRW5FLElBQUksQ0FBQyxVQUFVO0VBQ2IsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUUsd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUJBQXdCOzs7OztJQUd2Qyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsa0NBQW1DOzs7O2VBQ3RELHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFXO0tBQXNGOzs7O2FBQzlHOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLGVBQWUsS0FDZCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FDRztPQUFhO09BQVcsZUFBZSxJQUFJLE1BQU07TUFDOUM7Ozs7OztJQUVMOzs7OztHQUNGOzs7Ozs7Q0FFVDtDQUVBLElBQUksV0FBVztFQUNiLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUVFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHVCQUF3Qjs7Ozs7SUFHdkMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDhDQUErQzs7OztlQUNwRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FBMkI7T0FBZTtPQUFhO09BQVksZUFBZSxJQUFJLE9BQU87T0FBRztNQUFpQzs7Ozs7YUFDOUg7Ozs7OztJQUdMLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGlDQUFrQzs7Ozs7R0FDOUM7Ozs7OztDQUVUO0NBRUEsSUFBSSxlQUFlLEdBQUc7RUFDcEIsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUUsd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUJBQXdCOzs7OztJQUd2Qyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsa0NBQW1DOzs7O2VBQ25ELHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFXO0tBQXFFOzs7O2FBQzdGOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7Z0JBQUMsb0JBQzNCOzs7Ozs7SUFDTDs7Ozs7R0FDRjs7Ozs7O0NBRVQ7O0NBR0EsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUJBQXdCOzs7OztHQUd2Qyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsb0NBQXFDOzs7O2NBQ3JELHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQVc7SUFBcUU7Ozs7WUFDN0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHVCQUF3Qjs7Ozs7RUFDcEM7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlN5bmNTdGF0dXNCYW5uZXIuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZVN5bmMgfSBmcm9tICcuLi91dGlscy91c2VTeW5jJztcclxuaW1wb3J0IHsgV2lmaSwgV2lmaU9mZiwgUmVmcmVzaEN3IH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFN5bmNTdGF0dXNCYW5uZXIoKSB7XHJcbiAgY29uc3QgeyBpc09ubGluZSwgaXNTeW5jaW5nLCBwZW5kaW5nQ291bnQsIHRyaWdnZXJTeW5jIH0gPSB1c2VTeW5jKCk7XHJcblxyXG4gIGlmICghaXNPbmxpbmUpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwLzEwIGJvcmRlci1iIGJvcmRlci1hbWJlci01MDAvMjAgdGV4dC1hbWJlci01MDAgcHgtNCBweS0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB3LWZ1bGwgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LXNtIGFuaW1hdGUtcHVsc2Ugbm8tcHJpbnRcIj5cclxuICAgICAgICB7LyogRXNwYWNpYWRvciBpenF1aWVyZG8gcGFyYSBjZW50cmFyIGVsIGJsb3F1ZSBkZWwgbWVuc2FqZSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMzIgaGlkZGVuIHNtOmJsb2NrXCIgLz5cclxuICAgICAgICBcclxuICAgICAgICB7LyogQ29udGVuaWRvIGNlbnRyYWRvIGRlIGVzdGFkbyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGZsZXgtMSB0ZXh0LWNlbnRlciBtaW4tdy0wXCI+XHJcbiAgICAgICAgICA8V2lmaU9mZiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwIHNocmluay0wXCIgLz5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+TW9kbyBPZmZsaW5lOiBMb3MgZGF0b3MgZGUgaW5zcGVjY2nDs24gc2UgZ3VhcmRhcsOhbiBkZSBmb3JtYSBsb2NhbCBlbiBsYSB0YWJsZXRhLjwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICB7LyogRXNwYWNpYWRvci9CYWRnZSBhIGxhIGRlcmVjaGEgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTMyIGZsZXgganVzdGlmeS1lbmQgc2hyaW5rLTBcIj5cclxuICAgICAgICAgIHtwZW5kaW5nQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItNDAwIHB4LTIgcHktMC41IHJvdW5kZWQgdGV4dC1bMTBweF0gZm9udC1tb25vIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwXCI+XHJcbiAgICAgICAgICAgICAge3BlbmRpbmdDb3VudH0gcGVuZGllbnRle3BlbmRpbmdDb3VudCA+IDEgPyAncycgOiAnJ31cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgaWYgKGlzU3luY2luZykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwMC8xMCBib3JkZXItYiBib3JkZXItYmx1ZS01MDAvMjAgdGV4dC1ibHVlLTQwMCBweC00IHB5LTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHctZnVsbCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgc2hhZG93LXNtIG5vLXByaW50XCI+XHJcbiAgICAgICAgey8qIEVzcGFjaWFkb3IgaXpxdWllcmRvIHBhcmEgY2VudHJhciBlbCBibG9xdWUgZGVsIG1lbnNhamUgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTMyIGhpZGRlbiBzbTpibG9ja1wiIC8+XHJcbiAgICAgICAgXHJcbiAgICAgICAgey8qIENvbnRlbmlkbyBjZW50cmFkbyBkZSBlc3RhZG8gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBmbGV4LTEgdGV4dC1jZW50ZXIgbWluLXctMFwiPlxyXG4gICAgICAgICAgPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpbiB0ZXh0LWJsdWUtNDAwIHNocmluay0wXCIgLz5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+U2luY3Jvbml6YW5kbyB7cGVuZGluZ0NvdW50fSBpbnNwZWNjacOzbntwZW5kaW5nQ291bnQgPiAxID8gJ2VzJyA6ICcnfSBjb24gZWwgc2Vydmlkb3IgY2VudHJhbC4uLjwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICB7LyogRXNwYWNpYWRvciBhIGxhIGRlcmVjaGEgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTMyIGZsZXgganVzdGlmeS1lbmQgc2hyaW5rLTBcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAocGVuZGluZ0NvdW50ID4gMCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hbWJlci01MDAvMTAgYm9yZGVyLWIgYm9yZGVyLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTUwMCBweC00IHB5LTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHctZnVsbCB0ZXh0LXhzIGZvbnQtYm9sZCBzaGFkb3ctc20gbm8tcHJpbnRcIj5cclxuICAgICAgICB7LyogRXNwYWNpYWRvciBpenF1aWVyZG8gcGFyYSBjZW50cmFyIGVsIGJsb3F1ZSBkZWwgbWVuc2FqZSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMzIgaGlkZGVuIHNtOmJsb2NrXCIgLz5cclxuICAgICAgICBcclxuICAgICAgICB7LyogQ29udGVuaWRvIGNlbnRyYWRvIGRlIGVzdGFkbyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGZsZXgtMSB0ZXh0LWNlbnRlciBtaW4tdy0wXCI+XHJcbiAgICAgICAgICA8V2lmaSBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wIHRleHQtYW1iZXItNTAwXCIgLz5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+Q29uZXhpw7NuIHJlc3RhYmxlY2lkYS4gVGllbmVzIGRhdG9zIHBlbmRpZW50ZXMgcG9yIHNpbmNyb25pemFyLjwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICB7LyogQm90w7NuIGRlIGFjY2nDs24gYSBsYSBkZXJlY2hhICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0zMiBmbGV4IGp1c3RpZnktZW5kIHNocmluay0wXCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e3RyaWdnZXJTeW5jfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgYWN0aXZlOnNjYWxlLTk1IHRleHQtc2xhdGUtOTUwIHB4LTMgcHktMSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtZXh0cmFib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHNoYWRvdy1zbSBzaHJpbmstMFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+IFNpbmNyb25pemFyIEFob3JhXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gU2kgZXN0w6Egb25saW5lIHkgdG9kbyBlc3TDoSBzaW5jcm9uaXphZG9cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXItYiBib3JkZXItZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTUwMCBweC00IHB5LTEuNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdy1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBzaGFkb3ctc20gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG5vLXByaW50XCI+XHJcbiAgICAgIHsvKiBFc3BhY2lhZG9yIGl6cXVpZXJkbyBwYXJhIGNlbnRyYXIgZWwgYmxvcXVlIGRlbCBtZW5zYWplICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaGlkZGVuIHNtOmJsb2NrXCIgLz5cclxuICAgICAgXHJcbiAgICAgIHsvKiBDb250ZW5pZG8gY2VudHJhZG8gZGUgZXN0YWRvICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGZsZXgtMSB0ZXh0LWNlbnRlciBtaW4tdy0wXCI+XHJcbiAgICAgICAgPFdpZmkgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNTAwIHNocmluay0wXCIgLz5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPkNvbmVjdGFkby4gVG9kb3MgbG9zIGRhdG9zIGVzdMOhbiBzaW5jcm9uaXphZG9zIGNvbiBlbCBzZXJ2aWRvci48L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICBcclxuICAgICAgey8qIEVzcGFjaWFkb3IgYSBsYSBkZXJlY2hhICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaGlkZGVuIHNtOmJsb2NrXCIgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19