import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TableroComponent.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import EditableCell from "/src/components/EditableCell.jsx";
import { Plus, Minus, Grid, Columns, Settings, RefreshCw, Zap, Image, ClipboardList, Camera, X, Printer, Pencil, Download } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
import { API_BASE_URL } from "/src/utils/api.js";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/TableroComponent.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
// Componente para renderizar Blobs de forma segura evitando fugas de memoria
const SafeImage = ({ blob, src, alt, className }) => {
	_s();
	const [objectUrl, setObjectUrl] = useState(null);
	useEffect(() => {
		if (blob) {
			const url = URL.createObjectURL(blob);
			setObjectUrl(url);
			return () => {
				URL.revokeObjectURL(url);
			};
		} else {
			setObjectUrl(null);
		}
	}, [blob]);
	const finalSrc = objectUrl || src;
	if (!finalSrc) return null;
	return /* @__PURE__ */ _jsxDEV("img", {
		src: finalSrc,
		alt,
		className
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 10
	}, this);
};
_s(SafeImage, "Q4ugJUn5miWrvY9z1+S4+H7NbYg=");
_c = SafeImage;
import ModalEdicionCircuito from "/src/components/ModalEdicionCircuito.jsx?t=1790793566895";
import SelectorAlimentadorJerarquico from "/src/components/SelectorAlimentadorJerarquico.jsx?t=1790792337841";
import { AMP_OPTIONS, COND_OPTIONS, MARCA_OPTIONS, TIPO_OPTIONS, TENSIONES_COVENIN_159_BT } from "/src/utils/constants.js";
export const TableroComponent = ({ tableroData, onUpdateTablero, readOnly }) => {
	_s2();
	const [editingCircuit, setEditingCircuit] = useState(null);
	const [elementosPorCrear, setElementosPorCrear] = useState(tableroData?.elementosPorCrear || tableroData?.datosTecnicos?.elementosPorCrear || []);
	const { companies, updateTableroAlimentador, crearElementoProvisional, registrarConflictoCircuito, showToast, setPanelConflictosOpen } = useStore();
	const { alert: customAlert } = useConfirm();
	const project = React.useMemo(() => {
		if (!tableroData?.id) return null;
		for (const c of companies) {
			if (c.proyectos) {
				for (const p of c.proyectos) {
					const tableros = p.elementosUnifilares || p.tableros || [];
					if (tableros.some((t) => t.id === tableroData.id)) {
						return p;
					}
				}
			}
		}
		return null;
	}, [companies, tableroData?.id]);
	const alimentadores = React.useMemo(() => {
		if (!project) return [];
		return (project.elementosUnifilares || project.tableros || []).filter((e) => e.id !== tableroData?.id);
	}, [project, tableroData?.id]);
	const todosElementosCreados = React.useMemo(() => {
		if (!project) return [];
		const unifilares = (project.elementosUnifilares || project.tableros || []).map((e) => ({
			id: e.id,
			nombre: e.nombre,
			tipo: e.tipoElemento || "TABLERO"
		}));
		const subestaciones = (project.subestaciones || project.inspeccionesSubestacion || []).map((s) => ({
			id: s.id,
			nombre: s.nombre,
			tipo: "SUBESTACION"
		}));
		const puntos = (project.puntosMedicion || []).map((p) => ({
			id: p.id,
			nombre: p.nombre,
			tipo: "PUNTO_MEDICION"
		}));
		const ccms = (project.ccmList || []).map((c) => ({
			id: c.id,
			nombre: c.nombre,
			tipo: "CCM"
		}));
		return [
			...unifilares,
			...subestaciones,
			...puntos,
			...ccms
		].filter((e) => e.id !== tableroData?.id);
	}, [project, tableroData?.id]);
	const renderCircuitEquipo = (equipoText, vinculadoId, elementoDestinoId, tipoDestino, tipoElementoDestino) => {
		if (!equipoText || equipoText === "RESERVA") {
			return /* @__PURE__ */ _jsxDEV("span", {
				className: "text-xs text-slate-400 dark:text-slate-600 italic font-mono",
				children: "RESERVA"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 14
			}, this);
		}
		let cleanName = equipoText;
		let elementId = elementoDestinoId || vinculadoId || null;
		let elementType = tipoElementoDestino || tipoDestino || null;
		const match = String(equipoText).match(/^(.*?)(?:\s*\((?:ID:\s*)?([A-Z0-9_-]+)\))?$/i);
		if (match) {
			if (match[1]) cleanName = match[1].trim();
			if (match[2] && !elementId) elementId = match[2].trim();
		}
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col gap-0.5",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "text-xs font-bold text-slate-900 dark:text-slate-100",
				children: cleanName
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 111,
				columnNumber: 9
			}, this), elementId && /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center w-max px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-500/10 text-amber-500 border border-amber-500/30",
				children: [elementType && elementType !== "SUB_TABLERO" && elementType !== "TABLERO" ? `${elementType}: ` : "", elementId]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 110,
			columnNumber: 7
		}, this);
	};
	const renderTipoDestinoBadge = (tipoDestino, tipoElementoDestino) => {
		const t = (tipoElementoDestino || tipoDestino || "").toUpperCase();
		if (!t) return null;
		if (t === "ARTEFACTO" || t === "CARGA_DIRECTA") {
			return /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center w-max px-1 py-0.5 rounded text-[8px] font-bold bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 mt-1",
				children: "🔌 ARTEFACTO"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 127,
				columnNumber: 9
			}, this);
		}
		if (t === "TRANSFER" || t === "ATS" || t === "MTS") {
			return /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center w-max px-1 py-0.5 rounded text-[8px] font-bold bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300 mt-1",
				children: "🔄 TRANSFERENCIA (ATS)"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 134,
				columnNumber: 9
			}, this);
		}
		if (t === "GENERADOR" || t === "GEN" || t === "PLANTA") {
			return /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center w-max px-1 py-0.5 rounded text-[8px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300 mt-1",
				children: "⚡ GENERADOR"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 141,
				columnNumber: 9
			}, this);
		}
		if (t === "CCM" || t === "MOTOR") {
			return /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center w-max px-1 py-0.5 rounded text-[8px] font-bold bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300 mt-1",
				children: "⚙️ CCM"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 148,
				columnNumber: 9
			}, this);
		}
		if (t === "SUBESTACION" || t === "SE") {
			return /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center w-max px-1 py-0.5 rounded text-[8px] font-bold bg-sky-100 text-sky-800 dark:bg-sky-900/30 dark:text-sky-300 mt-1",
				children: "🏛️ SUBESTACIÓN"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 9
			}, this);
		}
		if (t === "TRANSFORMADOR" || t === "TRAFO") {
			return /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center w-max px-1 py-0.5 rounded text-[8px] font-bold bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300 mt-1",
				children: "🔌 TRANSFORMADOR"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 162,
				columnNumber: 9
			}, this);
		}
		if (t === "PUNTO_MEDICION" || t === "MEDIDOR") {
			return /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center w-max px-1 py-0.5 rounded text-[8px] font-bold bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-300 mt-1",
				children: "📊 MEDIDOR"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 169,
				columnNumber: 9
			}, this);
		}
		if (t === "SUB_TABLERO" || t === "TABLERO") {
			return /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center w-max px-1 py-0.5 rounded text-[8px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300 mt-1",
				children: "🏢 SUB-TABLERO"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 176,
				columnNumber: 9
			}, this);
		}
		if (t === "SUB_TABLERO_PENDIENTE") {
			return /* @__PURE__ */ _jsxDEV("span", {
				className: "inline-flex items-center w-max px-1 py-0.5 rounded text-[8px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300 mt-1",
				children: "⏳ RESERVA PENDIENTE"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 183,
				columnNumber: 9
			}, this);
		}
		return /* @__PURE__ */ _jsxDEV("span", {
			className: "inline-flex items-center w-max px-1 py-0.5 rounded text-[8px] font-bold bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300 mt-1",
			children: ["🔗 ", t]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 189,
			columnNumber: 7
		}, this);
	};
	// Normalize circuits: ensure all poles from 1 to maxPoles are represented exactly once
	const maxPoles = tableroData?.maxPoles || 30;
	const circuits = tableroData?.circuits || [];
	const normalizedCircuits = React.useMemo(() => {
		if (!tableroData) return [];
		const list = circuits.map((c) => {
			const firstPole = Array.isArray(c.poles) && c.poles.length > 0 ? c.poles[0] : 1;
			const customLabel = c.codigoPolo || c.polo_label || c.poloLabel || tableroData.poleLabels && tableroData.poleLabels[firstPole] || "";
			return {
				...c,
				poles: Array.isArray(c.poles) && c.poles.length > 0 ? c.poles : [1],
				breaker: c.breaker || {
					marca: "",
					tipo: "",
					amp: ""
				},
				codigoPolo: customLabel,
				polo_label: customLabel
			};
		});
		const coveredPoles = new Set();
		list.forEach((c) => {
			if (Array.isArray(c.poles)) {
				c.poles.forEach((p) => coveredPoles.add(p));
			}
		});
		// Fill in missing poles
		for (let pole = 1; pole <= maxPoles; pole++) {
			if (!coveredPoles.has(pole)) {
				const customLabel = tableroData.poleLabels && tableroData.poleLabels[pole] || "";
				list.push({
					id: `auto_${pole}`,
					side: pole % 2 === 1 ? "left" : "right",
					poles: [pole],
					equipo: "RESERVA",
					breaker: {
						marca: "",
						tipo: "",
						amp: ""
					},
					conductor: "",
					codigoPolo: customLabel,
					polo_label: customLabel
				});
			}
		}
		// Sort circuits by their first pole number
		return list.sort((a, b) => {
			const minA = Array.isArray(a.poles) && a.poles.length > 0 ? Math.min(...a.poles) : 0;
			const minB = Array.isArray(b.poles) && b.poles.length > 0 ? Math.min(...b.poles) : 0;
			return minA - minB;
		});
	}, [
		circuits,
		maxPoles,
		tableroData
	]);
	if (!tableroData) return /* @__PURE__ */ _jsxDEV("div", {
		className: "text-center p-8",
		children: "No hay datos de tablero seleccionados."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 247,
		columnNumber: 28
	}, this);
	const { id, ubicacion, alimentadoPor, tipo, foto, fotoBlob, barrasPrincipales = {}, breakerPrincipal = {}, voltaje = {}, acometida, neutroLlegada = {}, puestaTierra = {}, observacionesGenerales = "" } = tableroData;
	// Update specific fields of the main tablero structure
	const updateField = (path, value) => {
		if (readOnly) return;
		const newData = { ...tableroData };
		if (path.includes(".")) {
			const [parent, child] = path.split(".");
			newData[parent] = {
				...newData[parent],
				[child]: value
			};
		} else {
			newData[path] = value;
		}
		onUpdateTablero(newData);
	};
	// Update a single circuit's properties
	const updateCircuit = (circuitId, field, value) => {
		if (readOnly) return;
		const newData = { ...tableroData };
		newData.circuits = normalizedCircuits.map((c) => {
			if (c.id === circuitId) {
				if (field.startsWith("breaker.")) {
					const [_, subField] = field.split(".");
					return {
						...c,
						breaker: {
							...c.breaker,
							[subField]: value
						}
					};
				}
				return {
					...c,
					[field]: value
				};
			}
			return c;
		});
		onUpdateTablero(newData);
	};
	// Update or assign a custom pole label / nomenclature
	const handleUpdatePoleLabel = (poleNumber, newLabel) => {
		if (readOnly) return;
		const newData = { ...tableroData };
		let currentCircuits = [...tableroData.circuits || []];
		// Actualizar mapa global de etiquetas de polo
		newData.poleLabels = {
			...tableroData.poleLabels || {},
			[poleNumber]: newLabel
		};
		// Buscar si ya existe un circuito que contenga este polo
		const existingIndex = currentCircuits.findIndex((c) => Array.isArray(c.poles) && c.poles.includes(poleNumber));
		if (existingIndex >= 0) {
			currentCircuits[existingIndex] = {
				...currentCircuits[existingIndex],
				codigoPolo: newLabel,
				polo_label: newLabel,
				poloLabel: newLabel
			};
		} else {
			// Si era un polo vacío/auto, crear circuito para persistir su etiqueta personalizada
			currentCircuits.push({
				id: `circ_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
				side: poleNumber % 2 === 1 ? "left" : "right",
				poles: [poleNumber],
				equipo: "RESERVA",
				breaker: {
					marca: "",
					tipo: "",
					amp: ""
				},
				conductor: "",
				codigoPolo: newLabel,
				polo_label: newLabel,
				poloLabel: newLabel
			});
		}
		newData.circuits = currentCircuits.filter((c) => {
			const hasBreaker = c.breaker && (c.breaker.marca || c.breaker.tipo || c.breaker.amp);
			const hasConductor = c.conductor && c.conductor !== "N/A" && c.conductor !== "N/D" && c.conductor !== "";
			const hasEquipo = c.equipo && c.equipo !== "RESERVA" && c.equipo !== "DISPONIBLE";
			const hasFicha = c.ficha && (c.ficha.descripcion || c.ficha.potenciaWatts);
			const isMultiPole = Array.isArray(c.poles) && c.poles.length > 1;
			const hasPoleLabel = !!(c.codigoPolo || c.polo_label || c.poloLabel);
			return hasBreaker || hasConductor || hasEquipo || c.fotografia || c.tipoDestino || c.vinculadoId || hasFicha || isMultiPole || hasPoleLabel;
		});
		onUpdateTablero(newData);
	};
	const saveCircuitFromModal = (circuitId, updatedFields) => {
		if (readOnly) return;
		const newData = { ...tableroData };
		if (updatedFields && (updatedFields.tipoDestino === "SUB_TABLERO_PENDIENTE" || updatedFields.tipoDestino === "ELEMENTO_PENDIENTE") && project?.id) {
			const existingProvId = updatedFields.elementoDestinoId || updatedFields.vinculadoId;
			let prov = null;
			if (existingProvId) {
				prov = (project.elementosUnifilares || project.tableros || []).find((e) => e.id === existingProvId);
			}
			if (!prov) {
				const polesStr = Array.isArray(updatedFields.poles) && updatedFields.poles.length > 0 ? updatedFields.poles.join(", ") : updatedFields.posicionPolo || circuitId;
				const provType = updatedFields.tipoElementoProvisional || updatedFields.tipoElementoDestino || "TABLERO";
				const defaultName = `${provType} Alimentado (Polo ${polesStr})`;
				const provName = updatedFields.nombreProvisional || updatedFields.equipo || defaultName;
				prov = crearElementoProvisional(project.id, {
					nombre: provName && provName !== "RESERVA (Pendiente por Crear)" ? provName : defaultName,
					tipoElemento: provType,
					circuitoOrigen: circuitId
				});
			}
			if (prov) {
				updatedFields.vinculadoId = prov.id;
				updatedFields.elementoDestinoId = prov.id;
				updatedFields.tipoElementoDestino = prov.tipoElemento || updatedFields.tipoElementoProvisional || "TABLERO";
				updatedFields.equipo = `${prov.nombre} (ID: ${prov.id})`;
				updatedFields.tipoDestino = prov.tipoElemento === "TABLERO" ? "SUB_TABLERO" : "ELEMENTO_VINCULADO";
				const pendingItem = {
					id: prov.id,
					nombre: prov.nombre,
					tipoElemento: prov.tipoElemento,
					circuitoId
				};
				const filteredPendientes = (elementosPorCrear || []).filter((item) => item.circuitoId !== circuitId && item.id !== prov.id);
				const updatedList = [...filteredPendientes, pendingItem];
				setElementosPorCrear(updatedList);
				newData.elementosPorCrear = updatedList;
			}
		}
		let currentCircuits = [...tableroData.circuits || []];
		if (updatedFields === null) {
			// Remove from custom circuits list so it falls back to auto-generated RESERVA
			currentCircuits = currentCircuits.filter((c) => c.id !== circuitId && !c.id.startsWith("auto_"));
		} else {
			const isAuto = circuitId.startsWith("auto_");
			if (isAuto) {
				// Create new custom circuit
				currentCircuits.push({
					id: `circ_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
					...updatedFields
				});
			} else {
				// Update existing custom circuit
				currentCircuits = currentCircuits.map((c) => {
					if (c.id === circuitId) {
						return {
							...c,
							...updatedFields
						};
					}
					return c;
				});
			}
		}
		// Filter out completely empty default circuits to prevent database bloat
		newData.circuits = currentCircuits.filter((c) => {
			const hasBreaker = c.breaker && (c.breaker.marca || c.breaker.tipo || c.breaker.amp);
			const hasConductor = c.conductor && c.conductor !== "N/A" && c.conductor !== "N/D" && c.conductor !== "";
			const hasEquipo = c.equipo && c.equipo !== "RESERVA" && c.equipo !== "DISPONIBLE";
			const hasFicha = c.ficha && (c.ficha.descripcion || c.ficha.potenciaWatts);
			const isMultiPole = Array.isArray(c.poles) && c.poles.length > 1;
			const hasPoleLabel = !!(c.codigoPolo || c.polo_label || c.poloLabel);
			const hasDestino = !!(c.elementoDestinoId || c.vinculadoId || c.tipoElementoDestino || c.tipoDestino);
			return hasBreaker || hasConductor || hasEquipo || c.fotografia || hasDestino || hasFicha || isMultiPole || hasPoleLabel;
		});
		onUpdateTablero(newData);
	};
	// Group a pole with the next pole on the same side (maximum 3 poles)
	const groupWithNext = (circuitId) => {
		if (readOnly) return;
		const circuit = normalizedCircuits.find((c) => c.id === circuitId);
		if (!circuit) return;
		if (circuit.poles.length >= 3) {
			showToast("El número máximo de polos agrupados es 3.", "warning");
			return;
		}
		const currentMaxPole = Math.max(...circuit.poles);
		const targetPole = currentMaxPole + 2;
		if (targetPole > maxPoles) return;
		// Helper to determine if a circuit is actually occupied by customized data
		const isOccupiedByRealCircuit = (c) => {
			const hasBreaker = c.breaker && (c.breaker.marca || c.breaker.tipo || c.breaker.amp);
			const hasConductor = c.conductor && c.conductor !== "N/A" && c.conductor !== "N/D" && c.conductor !== "";
			const hasRealName = c.equipo && c.equipo !== "RESERVA" && c.equipo !== "DISPONIBLE" && !c.equipo.startsWith("RESERVA") && !c.equipo.startsWith("DISPONIBLE");
			return hasBreaker || hasConductor || hasRealName || c.fotografia || c.tipoDestino;
		};
		const targetOccupied = (tableroData.circuits || []).find((c) => c.id !== circuitId && c.poles.includes(targetPole));
		if (targetOccupied && isOccupiedByRealCircuit(targetOccupied)) {
			registrarConflictoCircuito({
				tableroId: tableroData.id,
				tableroNombre: tableroData.nombre || "Tablero Eléctrico",
				empresaId: project?.empresaId || project?.companyId || tableroData.empresaId,
				proyectoId: project?.id || tableroData.proyectoId,
				polos: [targetPole],
				circuitoId: circuit.id,
				circuitoNombre: circuit.equipo || `Circuito Polo ${circuit.poles[0]}`,
				equipoExistente: targetOccupied.equipo,
				equipoNuevo: circuit.equipo,
				descripcion: `Unión de polos [${[...circuit.poles, targetPole].join(", ")}] absorbe el polo ${targetPole} ocupado previamente por "${targetOccupied.equipo}".`,
				tipo: "SOLAPAMIENTO_POLOS"
			});
			showToast(`Conflicto en polo ${targetPole}. Incidencia agregada a la cola.`, "warning", {
				label: "Ver Conflicto",
				onClick: () => setPanelConflictosOpen(true)
			});
		}
		const newData = { ...tableroData };
		let existingCircuits = [...tableroData.circuits || []];
		// If the target pole was occupied by an empty custom circuit, filter it out to absorb it
		if (targetOccupied) {
			existingCircuits = existingCircuits.filter((c) => c.id !== targetOccupied.id);
		}
		const targetCircuit = existingCircuits.find((c) => c.id === circuitId);
		const newPoles = [...circuit.poles, targetPole].sort((a, b) => a - b);
		if (targetCircuit) {
			newData.circuits = existingCircuits.map((c) => {
				if (c.id === circuitId) {
					return {
						...c,
						poles: newPoles,
						numPolos: newPoles.length
					};
				}
				return c;
			});
		} else {
			newData.circuits = [...existingCircuits, {
				id: `circ_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
				side: circuit.side,
				poles: newPoles,
				numPolos: newPoles.length,
				equipo: circuit.equipo || "RESERVA",
				breaker: circuit.breaker || {
					marca: "",
					tipo: "",
					amp: ""
				},
				conductor: circuit.conductor || ""
			}];
		}
		onUpdateTablero(newData);
	};
	// Split a multi-pole circuit: preserves the primary circuit on minPole and releases joined poles
	const splitCircuit = (circuitId) => {
		if (readOnly) return;
		const circuit = normalizedCircuits.find((c) => c.id === circuitId);
		const newData = { ...tableroData };
		if (circuit && Array.isArray(circuit.poles) && circuit.poles.length > 1) {
			const minPole = Math.min(...circuit.poles);
			const isCustomId = !circuit.id.startsWith("auto_");
			if (isCustomId) {
				newData.circuits = (tableroData.circuits || []).map((c) => {
					if (c.id === circuitId) {
						return {
							...c,
							poles: [minPole],
							numPolos: 1,
							posicionPolo: minPole
						};
					}
					return c;
				});
			} else {
				newData.circuits = (tableroData.circuits || []).filter((c) => c.id !== circuitId);
			}
			showToast(`Circuito desacoplado. Se conservaron los datos en el polo principal ${minPole}.`, "info");
		} else {
			newData.circuits = (tableroData.circuits || []).filter((c) => c.id !== circuitId);
		}
		onUpdateTablero(newData);
	};
	// Split rendering rows into left (odd) and right (even) poles
	const oddPoles = Array.from({ length: Math.ceil(maxPoles / 2) }, (_, i) => 2 * i + 1);
	// Find circuit by pole number
	const findCircuitByPole = (pole) => {
		return normalizedCircuits.find((c) => c.poles.includes(pole));
	};
	const handleExportDXF = async () => {
		try {
			const tableroId = tableroData?.id;
			if (!tableroId) {
				customAlert("ID de tablero no disponible.");
				return;
			}
			const token = useStore.getState().token || localStorage.getItem("token");
			const headers = { ...token ? { "Authorization": `Bearer ${token}` } : {} };
			let response = await fetch(`${API_BASE_URL}/api/tableros/${tableroId}/dxf`, { headers });
			// Fallback a POST con datos locales si la búsqueda por ID en la BD primaria no lo localiza
			if (!response.ok) {
				response = await fetch(`${API_BASE_URL}/api/tableros/dxf/export-custom`, {
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						...headers
					},
					body: JSON.stringify({ tablero: tableroData })
				});
			}
			if (!response.ok) {
				throw new Error(`Error en el servidor (HTTP ${response.status})`);
			}
			const blob = await response.blob();
			const url = window.URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = `unifilar_${(tableroData.nombre || "tablero").replace(/[^a-zA-Z0-9_-]/g, "_").toLowerCase()}.dxf`;
			document.body.appendChild(a);
			a.click();
			window.URL.revokeObjectURL(url);
			document.body.removeChild(a);
		} catch (err) {
			console.error("Error al descargar DXF:", err);
			customAlert("No se pudo descargar el archivo DXF: " + err.message);
		}
	};
	const handlePrintPDF = () => {
		window.print();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `w-full text-slate-900 dark:text-slate-100 print-card font-sans select-text ${readOnly ? "pointer-events-none opacity-90" : ""}`,
		children: [/* @__PURE__ */ _jsxDEV("div", { children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-4 print:grid-cols-4 gap-4 mb-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-3 print:col-span-3",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full border-collapse border-2 border-slate-800 dark:border-slate-700 text-xs table-fixed mb-0",
						children: /* @__PURE__ */ _jsxDEV("tbody", { children: [
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/80",
								children: /* @__PURE__ */ _jsxDEV("td", {
									colSpan: 7,
									className: "p-0 font-bold text-sm tracking-wide",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-row items-center justify-between gap-4 py-2.5 px-4 uppercase font-bold text-slate-800 dark:text-slate-200 w-full",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 min-w-0",
											children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-amber-500 fill-amber-500/20 shrink-0" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 619,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-mono font-black tracking-wide text-xs sm:text-sm",
												children: "INFORMACIÓN GENERAL DE PANEL ELÉCTRICO / TABLERO"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 620,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 618,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 no-print",
											children: [/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: handleExportDXF,
												className: "flex items-center gap-1.5 px-2.5 py-1 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-400 border border-cyan-500/40 rounded-lg text-xs font-bold transition cursor-pointer",
												title: "Descargar diagrama unifilar en formato AutoCAD DXF",
												children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 629,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Descargar DXF" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 630,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 623,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: handlePrintPDF,
												className: "flex items-center gap-1.5 px-2.5 py-1 bg-violet-600/20 hover:bg-violet-600/30 text-violet-400 border border-violet-500/40 rounded-lg text-xs font-bold transition cursor-pointer",
												title: "Imprimir o guardar como PDF",
												children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 638,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Imprimir / PDF" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 639,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 632,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 622,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 617,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 616,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 615,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 dark:border-slate-700",
								children: [/* @__PURE__ */ _jsxDEV("td", {
									className: "w-24 p-2 bg-slate-50 dark:bg-slate-800/40 font-semibold border-r border-slate-800 dark:border-slate-700 uppercase",
									children: "Ubicación:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 648,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("td", {
									colSpan: 6,
									className: "p-0 font-medium",
									children: /* @__PURE__ */ _jsxDEV(EditableCell, {
										value: ubicacion,
										onSave: (val) => updateField("ubicacion", val),
										placeholder: "Indique la ubicación física detallada del tablero...",
										className: "px-3"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 652,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 651,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 647,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 dark:border-slate-700",
								children: [/* @__PURE__ */ _jsxDEV("td", {
									className: "w-28 p-2.5 bg-slate-50 dark:bg-slate-800/40 font-semibold border-r border-slate-800 dark:border-slate-700 uppercase text-xs",
									children: "Alimentado Por:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 663,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("td", {
									colSpan: 6,
									className: "p-2.5 font-medium",
									children: /* @__PURE__ */ _jsxDEV(SelectorAlimentadorJerarquico, {
										proyectoId: project?.id,
										tableroActualId: tableroData?.id,
										value: alimentadoPor,
										onChange: (val, selectedObj) => {
											updateField("alimentadoPor", val);
											if (selectedObj?.tipoElemento === "ALIMENTADOR") {
												updateField("datosTecnicos.alimentadorId", selectedObj.id);
												updateTableroAlimentador(project?.id, tableroData.id, selectedObj.id);
											} else {
												updateField("datosTecnicos.alimentadorId", selectedObj?.id !== "CUSTOM" ? selectedObj?.id || null : null);
												updateTableroAlimentador(project?.id, tableroData.id, selectedObj?.id !== "CUSTOM" ? selectedObj?.id || null : null);
											}
										},
										label: "",
										placeholder: "Seleccionar Subestación, Transformador, CCM, Tablero o Acometida..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 667,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 666,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 662,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 dark:border-slate-700",
								children: [/* @__PURE__ */ _jsxDEV("td", {
									className: "w-24 p-2 bg-slate-50 dark:bg-slate-800/40 font-semibold border-r border-slate-800 dark:border-slate-700 uppercase",
									children: "Parámetros Panel:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 689,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("td", {
									colSpan: 6,
									className: "p-2 font-medium",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-wrap items-center gap-6 text-xs",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 bg-slate-100 dark:bg-slate-900/60 p-1.5 rounded-lg border border-slate-200 dark:border-slate-800",
												children: [
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-slate-500 dark:text-slate-400 uppercase font-bold shrink-0",
														children: "Capacidad Gabinete:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 695,
														columnNumber: 19
													}, this),
													/* @__PURE__ */ _jsxDEV("input", {
														type: "number",
														value: maxPoles,
														disabled: readOnly,
														onChange: (e) => {
															const val = parseInt(e.target.value, 10) || 0;
															const maxCircPosition = circuits.reduce((acc, c) => {
																const maxVal = Math.max(...c.poles);
																return maxVal > acc ? maxVal : acc;
															}, 0);
															if (val < maxCircPosition) {
																customAlert(`No se puede reducir la capacidad a ${val} polos porque hay circuitos ocupando posiciones hasta el polo ${maxCircPosition}.`);
																return;
															}
															updateField("maxPoles", val);
														},
														className: "bg-transparent text-slate-900 dark:text-amber-400 font-bold border-none text-[11px] focus:outline-none w-10 text-center"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 696,
														columnNumber: 19
													}, this),
													/* @__PURE__ */ _jsxDEV("select", {
														value: maxPoles,
														disabled: readOnly,
														onChange: (e) => {
															const val = parseInt(e.target.value, 10);
															if (!val) return;
															const maxCircPosition = circuits.reduce((acc, c) => {
																const maxVal = Math.max(...c.poles);
																return maxVal > acc ? maxVal : acc;
															}, 0);
															if (val < maxCircPosition) {
																customAlert(`No se puede reducir la capacidad a ${val} polos porque hay circuitos ocupando posiciones hasta el polo ${maxCircPosition}.`);
																return;
															}
															updateField("maxPoles", val);
														},
														className: "bg-transparent text-slate-500 dark:text-slate-400 font-medium border-none text-[10px] focus:outline-none cursor-pointer",
														children: [/* @__PURE__ */ _jsxDEV("option", {
															value: "",
															className: "bg-slate-900 text-slate-100",
															children: "-- Estándar --"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 732,
															columnNumber: 21
														}, this), [
															12,
															24,
															30,
															42,
															48,
															60,
															72,
															84,
															96
														].map((opt) => /* @__PURE__ */ _jsxDEV("option", {
															value: opt,
															className: "bg-slate-900 text-slate-100",
															children: [opt, " Polos"]
														}, opt, true, {
															fileName: _jsxFileName,
															lineNumber: 734,
															columnNumber: 23
														}, this))]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 714,
														columnNumber: 19
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 694,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1.5",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-slate-500 dark:text-slate-400 uppercase font-bold",
													children: "Fases:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 740,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("select", {
													value: tableroData.fases !== undefined ? tableroData.fases : 3,
													onChange: (e) => updateField("fases", parseInt(e.target.value, 10)),
													className: "bg-transparent text-slate-900 dark:text-slate-100 font-bold border-none text-[11px] focus:outline-none cursor-pointer",
													children: [
														1,
														2,
														3
													].map((opt) => /* @__PURE__ */ _jsxDEV("option", {
														value: opt,
														className: "bg-slate-900 text-slate-100",
														children: [opt, " Fase(s)"]
													}, opt, true, {
														fileName: _jsxFileName,
														lineNumber: 747,
														columnNumber: 23
													}, this))
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 741,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 739,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1.5",
												children: [
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-slate-500 dark:text-slate-400 uppercase font-bold",
														children: "Tensión Nominal (COVENIN 159):"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 753,
														columnNumber: 19
													}, this),
													/* @__PURE__ */ _jsxDEV("input", {
														type: "text",
														list: "covenin-voltajes-tablero",
														value: tableroData.tension || "",
														disabled: readOnly,
														onChange: (e) => updateField("tension", e.target.value),
														placeholder: "Ej: 120/208 V (3Φ - 4 hilos)",
														className: "bg-transparent text-slate-900 dark:text-amber-400 font-bold border border-slate-300 dark:border-slate-700 rounded px-2 py-0.5 text-[11px] focus:outline-none w-56 font-mono"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 754,
														columnNumber: 19
													}, this),
													/* @__PURE__ */ _jsxDEV("datalist", {
														id: "covenin-voltajes-tablero",
														children: TENSIONES_COVENIN_159_BT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
															value: v,
															children: v
														}, v, false, {
															fileName: _jsxFileName,
															lineNumber: 764,
															columnNumber: 56
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 763,
														columnNumber: 19
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 752,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 693,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 692,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 688,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 dark:border-slate-700 text-center font-semibold bg-slate-50 dark:bg-slate-800/60",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										colSpan: 2,
										className: "border-r border-slate-800 dark:border-slate-700 p-1 uppercase",
										children: "Barras Principales"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 773,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										colSpan: 3,
										className: "border-r border-slate-800 dark:border-slate-700 p-0 uppercase",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between px-2 py-1 bg-slate-100 dark:bg-slate-800 border-b border-slate-800 dark:border-slate-700",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px]",
												children: "Tipo de Tablero"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 778,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex gap-3",
												children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "flex items-center gap-1 cursor-pointer select-none",
													children: [/* @__PURE__ */ _jsxDEV("input", {
														type: "radio",
														checked: tipo === "superficial",
														onChange: () => updateField("tipo", "superficial"),
														className: "accent-amber-500 w-3 h-3 cursor-pointer"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 781,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: tipo === "superficial" ? "font-bold text-amber-500" : "",
														children: "Superficial"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 787,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 780,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("label", {
													className: "flex items-center gap-1 cursor-pointer select-none",
													children: [/* @__PURE__ */ _jsxDEV("input", {
														type: "radio",
														checked: tipo === "empotrado",
														onChange: () => updateField("tipo", "empotrado"),
														className: "accent-amber-500 w-3 h-3 cursor-pointer"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 790,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: tipo === "empotrado" ? "font-bold text-amber-500" : "",
														children: "Empotrado"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 796,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 789,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 779,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 777,
											columnNumber: 15
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "py-1",
											children: "BREAKER PRINCIPAL"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 800,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 776,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "border-r border-slate-800 dark:border-slate-700 p-1 uppercase w-20",
										children: "Voltaje"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 802,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-1 uppercase",
										children: "Acometida"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 805,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 772,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 dark:border-slate-700 text-center font-bold text-[10px] bg-slate-100 dark:bg-slate-800/80",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										colSpan: 2,
										className: "border-r border-slate-800 dark:border-slate-700 p-0.5",
										children: "FASE / AMPERIOS"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 812,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "border-r border-slate-800 dark:border-slate-700 p-0.5 w-24",
										children: "MARCA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 813,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "border-r border-slate-800 dark:border-slate-700 p-0.5 w-20",
										children: "TIPO"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 814,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "border-r border-slate-800 dark:border-slate-700 p-0.5 w-20",
										children: "AMP"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 815,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "border-r border-slate-800 dark:border-slate-700 p-0.5",
										children: "V-FASE"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 816,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-0.5",
										children: "CALIBRE/DETALLES"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 817,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 811,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 dark:border-slate-700",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "w-12 text-center bg-slate-50 dark:bg-slate-800/30 border-r border-slate-800 dark:border-slate-700 font-bold font-mono",
										children: "IA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 822,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "w-20 p-0 border-r border-slate-800 dark:border-slate-700 text-center",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: barrasPrincipales.ia,
											onSave: (val) => updateField("barrasPrincipales.ia", val),
											placeholder: "0",
											className: "text-center font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 824,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 823,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: 3,
										className: "p-0 border-r border-slate-800 dark:border-slate-700 text-center align-middle font-medium bg-amber-500/5",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: breakerPrincipal.marca,
											onSave: (val) => updateField("breakerPrincipal.marca", val),
											type: "select",
											options: MARCA_OPTIONS,
											placeholder: "Marca",
											className: "text-center font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 833,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 832,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: 3,
										className: "p-0 border-r border-slate-800 dark:border-slate-700 text-center align-middle bg-amber-500/5",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: breakerPrincipal.tipo,
											onSave: (val) => updateField("breakerPrincipal.tipo", val),
											placeholder: "Tipo",
											className: "text-center"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 844,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 843,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: 3,
										className: "p-0 border-r border-slate-800 dark:border-slate-700 text-center align-middle font-bold bg-amber-500/5",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: breakerPrincipal.amp,
											onSave: (val) => updateField("breakerPrincipal.amp", val),
											type: "select",
											options: AMP_OPTIONS,
											placeholder: "Amp",
											className: "text-center font-mono text-amber-600 dark:text-amber-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 853,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 852,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-0 border-r border-slate-800 dark:border-slate-700 text-center",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: voltaje.va,
											onSave: (val) => updateField("voltaje.va", val),
											placeholder: "0",
											className: "text-center font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 863,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 862,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: 3,
										className: "p-0 text-center align-middle font-medium bg-slate-50/50 dark:bg-slate-900/30",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: acometida,
											onSave: (val) => updateField("acometida", val),
											placeholder: "3X 3/0...",
											className: "text-center font-mono text-blue-600 dark:text-blue-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 872,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 871,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 821,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 dark:border-slate-700",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "text-center bg-slate-50 dark:bg-slate-800/30 border-r border-slate-800 dark:border-slate-700 font-bold font-mono",
										children: "IB"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 883,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-0 border-r border-slate-800 dark:border-slate-700 text-center",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: barrasPrincipales.ib,
											onSave: (val) => updateField("barrasPrincipales.ib", val),
											placeholder: "0",
											className: "text-center font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 885,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 884,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-0 border-r border-slate-800 dark:border-slate-700 text-center",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: voltaje.vb,
											onSave: (val) => updateField("voltaje.vb", val),
											placeholder: "0",
											className: "text-center font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 893,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 892,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 882,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "text-center bg-slate-50 dark:bg-slate-800/30 border-r border-slate-800 dark:border-slate-700 font-bold font-mono",
									children: "IC"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 904,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-0 border-r border-slate-800 dark:border-slate-700 text-center",
									children: /* @__PURE__ */ _jsxDEV(EditableCell, {
										value: barrasPrincipales.ic,
										onSave: (val) => updateField("barrasPrincipales.ic", val),
										placeholder: "0",
										className: "text-center font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 906,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 905,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-0 border-r border-slate-800 dark:border-slate-700 text-center",
									children: /* @__PURE__ */ _jsxDEV(EditableCell, {
										value: voltaje.vc,
										onSave: (val) => updateField("voltaje.vc", val),
										placeholder: "0",
										className: "text-center font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 914,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 913,
									columnNumber: 13
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 903,
								columnNumber: 11
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 613,
							columnNumber: 9
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 612,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 611,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "md:col-span-1 print:col-span-1 border-2 border-slate-800 dark:border-slate-700 bg-slate-950/40 rounded-lg p-3 flex flex-col justify-between h-full",
					style: { minHeight: `${tableroData.fotoScale || 220}px` },
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2",
							children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 933,
								columnNumber: 11
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Foto de Inspección" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 934,
								columnNumber: 11
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 932,
							columnNumber: 9
						}, this),
						fotoBlob || foto ? /* @__PURE__ */ _jsxDEV("div", {
							className: "relative rounded overflow-hidden border border-slate-800 bg-slate-900 flex items-center justify-center group shadow w-full",
							style: { height: `${tableroData.fotoScale || 220}px` },
							children: [/* @__PURE__ */ _jsxDEV(SafeImage, {
								blob: fotoBlob,
								src: foto,
								alt: "Inspección del tablero",
								className: "w-full h-full object-cover",
								style: { maxHeight: `${tableroData.fotoScale || 220}px` }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 942,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									onUpdateTablero({
										...tableroData,
										fotoBlob: null,
										foto: null
									});
								},
								className: "no-print absolute top-1 right-1 p-1 bg-red-600 hover:bg-red-500 text-white rounded cursor-pointer transition-colors shadow",
								title: "Eliminar foto",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 961,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 949,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 938,
							columnNumber: 11
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 flex flex-col items-center justify-center gap-2 p-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "flex items-center justify-center gap-1.5 w-full py-2.5 px-3 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold cursor-pointer transition-all active:scale-95 shadow-sm",
								children: [
									/* @__PURE__ */ _jsxDEV(Camera, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 967,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Cámara en Vivo" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 968,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										accept: "image/*",
										capture: "environment",
										onChange: (e) => {
											const file = e.target.files[0];
											if (!file) return;
											if (file.size > 10 * 1024 * 1024) {
												customAlert("La imagen es demasiado grande. Máximo 10MB.");
												return;
											}
											onUpdateTablero({
												...tableroData,
												fotoBlob: file,
												foto: null
											});
										},
										className: "hidden"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 969,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 966,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("label", {
								className: "flex items-center justify-center gap-1.5 w-full py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-750 rounded-xl text-xs font-semibold cursor-pointer transition-all active:scale-95",
								children: [
									/* @__PURE__ */ _jsxDEV(Image, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 990,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Galería / Archivos" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 991,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										accept: "image/*",
										onChange: (e) => {
											const file = e.target.files[0];
											if (!file) return;
											if (file.size > 10 * 1024 * 1024) {
												customAlert("La imagen es demasiado grande. Máximo 10MB.");
												return;
											}
											onUpdateTablero({
												...tableroData,
												fotoBlob: file,
												foto: null
											});
										},
										className: "hidden"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 992,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 989,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 965,
							columnNumber: 11
						}, this),
						(fotoBlob || foto) && /* @__PURE__ */ _jsxDEV("div", {
							className: "no-print mt-3 pt-3 border-t border-slate-850 space-y-1.5",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-center text-[9px] font-bold text-slate-400 uppercase",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ajustar tamaño en PDF" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1018,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-amber-500 font-mono",
									children: [tableroData.fotoScale || 220, "px"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1019,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1017,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "range",
								min: "120",
								max: "350",
								value: tableroData.fotoScale || 220,
								onChange: (e) => updateField("fotoScale", parseInt(e.target.value)),
								className: "w-full h-1 bg-slate-850 rounded-lg appearance-none cursor-pointer accent-amber-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1021,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1016,
							columnNumber: 11
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 931,
						columnNumber: 7
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-[9px] text-slate-500 mt-2 leading-relaxed border-t border-slate-900 pt-2 no-print",
						children: "Sube o captura la foto del cableado/gabinete para documentar el tablero."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1033,
						columnNumber: 7
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 927,
					columnNumber: 5
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 608,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full border-collapse border-2 border-slate-800 dark:border-slate-700 border-t-0 text-[10px] md:text-[11px] table-fixed min-w-[750px]",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: [/* @__PURE__ */ _jsxDEV("tr", {
						className: "border-b border-slate-800 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-center font-bold text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("th", {
								rowSpan: 2,
								className: "border-r border-slate-800 dark:border-slate-700 p-2 w-[22%]",
								children: "EQUIPO QUE ALIMENTA"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1046,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								colSpan: 3,
								className: "border-r border-slate-800 dark:border-slate-700 p-1",
								children: "PROTECCIÓN (BREAKER)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1047,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								rowSpan: 2,
								className: "border-r border-slate-800 dark:border-slate-700 p-2 w-[8%]",
								children: "COND."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1048,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								rowSpan: 2,
								className: "border-r border-2 border-slate-800 dark:border-slate-700 p-2 w-[4%] bg-amber-500/10 text-amber-600 dark:text-amber-400 font-mono font-bold text-center",
								children: "#"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1049,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								rowSpan: 2,
								className: "border-r border-slate-800 dark:border-slate-700 p-2 w-[4%] bg-amber-500/10 text-amber-600 dark:text-amber-400 font-mono font-bold text-center",
								children: "#"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1050,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								rowSpan: 2,
								className: "border-r border-slate-800 dark:border-slate-700 p-2 w-[8%]",
								children: "COND."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1051,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								colSpan: 3,
								className: "border-r border-slate-800 dark:border-slate-700 p-1",
								children: "PROTECCIÓN (BREAKER)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1052,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								rowSpan: 2,
								className: "p-2 w-[22%]",
								children: "EQUIPO QUE ALIMENTA"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1053,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1045,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tr", {
						className: "border-b border-2 border-slate-800 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-center font-bold text-[9px] uppercase tracking-wider",
						children: [
							/* @__PURE__ */ _jsxDEV("th", {
								className: "border-r border-slate-800 dark:border-slate-700 p-1 w-[8%]",
								children: "MARCA"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1058,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "border-r border-slate-800 dark:border-slate-700 p-1 w-[7%]",
								children: "TIPO"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1059,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "border-r border-slate-800 dark:border-slate-700 p-1 w-[6%]",
								children: "AMP."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1060,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "border-r border-slate-800 dark:border-slate-700 p-1 w-[6%]",
								children: "AMP."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1062,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "border-r border-slate-800 dark:border-slate-700 p-1 w-[7%]",
								children: "TIPO"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1063,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "border-r border-slate-800 dark:border-slate-700 p-1 w-[8%]",
								children: "MARCA"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1064,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1056,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1043,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: oddPoles.map((oddPole, rowIndex) => {
						const evenPole = oddPole + 1;
						// Find circuit representing the current left (odd) and right (even) poles
						const cLeft = findCircuitByPole(oddPole);
						const cRight = findCircuitByPole(evenPole);
						// Determine if this is the first pole of a multi-pole group to apply rowSpan
						const isFirstLeft = cLeft && Math.min(...cLeft.poles) === oddPole;
						const isFirstRight = cRight && Math.min(...cRight.poles) === evenPole;
						// Calculate rowSpan counts
						const rowSpanLeft = cLeft ? cLeft.poles.length : 1;
						const rowSpanRight = cRight ? cRight.poles.length : 1;
						return /* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b border-slate-800 dark:border-slate-700 hover:bg-slate-50/20 dark:hover:bg-slate-800/10 min-h-[32px]",
							children: [
								isFirstLeft && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: rowSpanLeft,
										className: "border-r border-slate-800 dark:border-slate-700 p-1.5 font-medium align-middle cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-colors relative group/cell",
										onClick: () => setEditingCircuit(cLeft),
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-col justify-center min-h-[2rem] pr-6",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between",
												children: [renderCircuitEquipo(cLeft.equipo, cLeft.vinculadoId, cLeft.elementoDestinoId, cLeft.tipoDestino, cLeft.tipoElementoDestino), cLeft.fotografia && /* @__PURE__ */ _jsxDEV(Image, { className: "w-3.5 h-3.5 text-amber-500 shrink-0 ml-1" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1101,
													columnNumber: 31
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1098,
												columnNumber: 27
											}, this), renderTipoDestinoBadge(cLeft.tipoDestino, cLeft.tipoElementoDestino)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1097,
											columnNumber: 25
										}, this), rowSpanLeft > 1 && /* @__PURE__ */ _jsxDEV("button", {
											onClick: (e) => {
												e.stopPropagation();
												splitCircuit(cLeft.id);
											},
											title: "Separar Polos",
											className: "no-print absolute right-1 top-1/2 -translate-y-1/2 p-0.5 opacity-80 hover:opacity-100 bg-red-500 hover:bg-red-600 text-white rounded cursor-pointer shadow-sm transition-opacity z-10",
											children: /* @__PURE__ */ _jsxDEV(Minus, { className: "w-3 h-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1117,
												columnNumber: 29
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1109,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1092,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: rowSpanLeft,
										className: "border-r border-slate-800 dark:border-slate-700 p-0 text-center align-middle",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: cLeft.breaker.marca,
											onSave: (val) => updateCircuit(cLeft.id, "breaker.marca", val),
											type: "select",
											options: MARCA_OPTIONS,
											placeholder: "",
											className: "text-center font-bold font-sans"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1127,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1123,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: rowSpanLeft,
										className: "border-r border-slate-800 dark:border-slate-700 p-0 text-center align-middle",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: cLeft.breaker.tipo,
											onSave: (val) => updateCircuit(cLeft.id, "breaker.tipo", val),
											type: "select",
											options: TIPO_OPTIONS,
											placeholder: "",
											className: "text-center"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1142,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1138,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: rowSpanLeft,
										className: "border-r border-slate-800 dark:border-slate-700 p-0 text-center align-middle font-bold",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: cLeft.breaker.amp,
											onSave: (val) => updateCircuit(cLeft.id, "breaker.amp", val),
											type: "select",
											options: AMP_OPTIONS,
											placeholder: "",
											className: "text-center font-mono text-amber-600 dark:text-amber-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1157,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1153,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: rowSpanLeft,
										className: "border-r border-slate-800 dark:border-slate-700 p-0 text-center align-middle font-medium",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: cLeft.conductor,
											onSave: (val) => updateCircuit(cLeft.id, "conductor", val),
											type: "select",
											options: COND_OPTIONS,
											placeholder: "",
											className: "text-center font-mono text-slate-700 dark:text-slate-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1172,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1168,
										columnNumber: 23
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1090,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "border-r-2 border-slate-800 dark:border-slate-700 p-0 text-center font-mono font-bold bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 align-middle select-none relative group/pole cursor-default",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-center min-h-[1.75rem] px-1",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-slate-700 dark:text-slate-300 select-none",
											children: oddPole
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1187,
											columnNumber: 23
										}, this), oddPole < maxPoles - 1 && isFirstLeft && rowSpanLeft === 1 && /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => groupWithNext(cLeft.id, "left"),
											title: "Agrupar con siguiente polo",
											className: "no-print absolute bottom-0 left-1/2 -translate-x-1/2 opacity-80 hover:opacity-100 p-0.5 bg-amber-500 hover:bg-amber-600 text-white rounded-full cursor-pointer shadow transition-opacity",
											children: /* @__PURE__ */ _jsxDEV(Plus, { className: "w-2.5 h-2.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1195,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1190,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1186,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1185,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "border-r border-slate-800 dark:border-slate-700 p-0 text-center font-mono font-bold bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 align-middle select-none relative group/pole-right cursor-default",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-center min-h-[1.75rem] px-1",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-slate-700 dark:text-slate-300 select-none",
											children: evenPole
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1205,
											columnNumber: 23
										}, this), evenPole < maxPoles && isFirstRight && rowSpanRight === 1 && /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => groupWithNext(cRight.id, "right"),
											title: "Agrupar con siguiente polo",
											className: "no-print absolute bottom-0 left-1/2 -translate-x-1/2 opacity-80 hover:opacity-100 p-0.5 bg-amber-500 hover:bg-amber-600 text-white rounded-full cursor-pointer shadow transition-opacity",
											children: /* @__PURE__ */ _jsxDEV(Plus, { className: "w-2.5 h-2.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1213,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1208,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1204,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1203,
									columnNumber: 19
								}, this),
								isFirstRight && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: rowSpanRight,
										className: "border-r border-slate-800 dark:border-slate-700 p-0 text-center align-middle font-medium",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: cRight.conductor,
											onSave: (val) => updateCircuit(cRight.id, "conductor", val),
											type: "select",
											options: COND_OPTIONS,
											placeholder: "",
											className: "text-center font-mono text-slate-700 dark:text-slate-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1226,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1222,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: rowSpanRight,
										className: "border-r border-slate-800 dark:border-slate-700 p-0 text-center align-middle font-bold",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: cRight.breaker.amp,
											onSave: (val) => updateCircuit(cRight.id, "breaker.amp", val),
											type: "select",
											options: AMP_OPTIONS,
											placeholder: "",
											className: "text-center font-mono text-amber-600 dark:text-amber-400"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1241,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1237,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: rowSpanRight,
										className: "border-r border-slate-800 dark:border-slate-700 p-0 text-center align-middle",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: cRight.breaker.tipo,
											onSave: (val) => updateCircuit(cRight.id, "breaker.tipo", val),
											type: "select",
											options: TIPO_OPTIONS,
											placeholder: "",
											className: "text-center"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1256,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1252,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: rowSpanRight,
										className: "border-r border-slate-800 dark:border-slate-700 p-0 text-center align-middle",
										children: /* @__PURE__ */ _jsxDEV(EditableCell, {
											value: cRight.breaker.marca,
											onSave: (val) => updateCircuit(cRight.id, "breaker.marca", val),
											type: "select",
											options: MARCA_OPTIONS,
											placeholder: "",
											className: "text-center font-bold font-sans"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1271,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1267,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										rowSpan: rowSpanRight,
										className: "p-1.5 font-medium align-middle cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-colors relative group/cell",
										onClick: () => setEditingCircuit(cRight),
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-col justify-center min-h-[2rem] pr-6",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between",
												children: [renderCircuitEquipo(cRight.equipo, cRight.vinculadoId, cRight.elementoDestinoId, cRight.tipoDestino, cRight.tipoElementoDestino), cRight.fotografia && /* @__PURE__ */ _jsxDEV(Image, { className: "w-3.5 h-3.5 text-amber-500 shrink-0 ml-1" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1291,
													columnNumber: 31
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1288,
												columnNumber: 27
											}, this), renderTipoDestinoBadge(cRight.tipoDestino, cRight.tipoElementoDestino)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1287,
											columnNumber: 25
										}, this), rowSpanRight > 1 && /* @__PURE__ */ _jsxDEV("button", {
											onClick: (e) => {
												e.stopPropagation();
												splitCircuit(cRight.id);
											},
											title: "Separar Polos",
											className: "no-print absolute right-1 top-1/2 -translate-y-1/2 p-0.5 opacity-80 hover:opacity-100 bg-red-500 hover:bg-red-600 text-white rounded cursor-pointer shadow-sm transition-opacity z-10",
											children: /* @__PURE__ */ _jsxDEV(Minus, { className: "w-3 h-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1307,
												columnNumber: 29
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1299,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1282,
										columnNumber: 23
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1220,
									columnNumber: 21
								}, this)
							]
						}, rowIndex, true, {
							fileName: _jsxFileName,
							lineNumber: 1084,
							columnNumber: 17
						}, this);
					}) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1067,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1042,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1041,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("table", {
				className: "w-full border-collapse border-2 border-slate-800 dark:border-slate-700 border-t-0 text-xs table-fixed mb-0",
				children: /* @__PURE__ */ _jsxDEV("tbody", { children: [
					/* @__PURE__ */ _jsxDEV("tr", {
						className: "border-b border-slate-800 dark:border-slate-700",
						children: [
							/* @__PURE__ */ _jsxDEV("td", {
								className: "w-[30%] p-2 font-bold bg-slate-50 dark:bg-slate-800/40 border-r border-slate-800 dark:border-slate-700 uppercase",
								children: "Neutro de Llegada"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1325,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "w-[15%] p-0 border-r border-slate-800 dark:border-slate-700 text-center font-semibold uppercase",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] text-slate-500 font-bold bg-slate-100 dark:bg-slate-800 border-b border-slate-800 dark:border-slate-700 p-0.5",
									children: "Calib Cond."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1329,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(EditableCell, {
									value: neutroLlegada.calibre,
									onSave: (val) => updateField("neutroLlegada.calibre", val),
									type: "select",
									options: COND_OPTIONS,
									placeholder: "Calibre",
									className: "text-center font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1330,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1328,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("td", { className: "w-[5%] border-r border-slate-800 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/50" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1339,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "p-0",
								children: /* @__PURE__ */ _jsxDEV(EditableCell, {
									value: neutroLlegada.observaciones,
									onSave: (val) => updateField("neutroLlegada.observaciones", val),
									placeholder: "Observaciones de Neutro (ej: Color de cable, barra)...",
									className: "px-3 text-slate-700 dark:text-slate-300 font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1341,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1340,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1324,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("tr", {
						className: "border-b border-slate-800 dark:border-slate-700",
						children: [
							/* @__PURE__ */ _jsxDEV("td", {
								className: "p-2 font-bold bg-slate-50 dark:bg-slate-800/40 border-r border-slate-800 dark:border-slate-700 uppercase",
								children: "Puesta a Tierra"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1352,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "p-0 border-r border-slate-800 dark:border-slate-700 text-center font-semibold uppercase",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] text-slate-500 font-bold bg-slate-100 dark:bg-slate-800 border-b border-slate-800 dark:border-slate-700 p-0.5",
									children: "Calib Cond."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1356,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(EditableCell, {
									value: puestaTierra.calibre,
									onSave: (val) => updateField("puestaTierra.calibre", val),
									type: "select",
									options: COND_OPTIONS,
									placeholder: "Calibre",
									className: "text-center font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1357,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1355,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("td", { className: "border-r border-slate-800 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/50" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1366,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "p-0",
								children: /* @__PURE__ */ _jsxDEV(EditableCell, {
									value: puestaTierra.observaciones,
									onSave: (val) => updateField("puestaTierra.observaciones", val),
									placeholder: "Observaciones de Puesta a Tierra (ej: Malla, malla del edificio)...",
									className: "px-3 text-slate-700 dark:text-slate-300 font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1368,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1367,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1351,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
						colSpan: 4,
						className: "p-0 align-top",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-100 dark:bg-slate-800 px-3 py-1 font-bold border-b border-slate-800 dark:border-slate-700 uppercase tracking-wide text-[10px] text-slate-600 dark:text-slate-400",
							children: "Observaciones Generales"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1380,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(EditableCell, {
							value: observacionesGenerales,
							onSave: (val) => updateField("observacionesGenerales", val),
							type: "textarea",
							placeholder: "Describa el estado general del tablero, hallazgos, reparaciones pendientes o recomendaciones...",
							className: "px-3 py-2 text-slate-800 dark:text-slate-200 min-h-[4rem] font-sans"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1383,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1379,
						columnNumber: 13
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1378,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1322,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1321,
				columnNumber: 7
			}, this),
			elementosPorCrear.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-8 p-6 bg-slate-50 dark:bg-slate-800/20 border border-slate-200 dark:border-slate-800 rounded-2xl no-print shadow-sm",
				children: [/* @__PURE__ */ _jsxDEV("h4", {
					className: "text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider mb-3 flex items-center gap-2",
					children: [
						/* @__PURE__ */ _jsxDEV(ClipboardList, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1399,
							columnNumber: 13
						}, this),
						" Lista de Elementos por Crear (",
						elementosPorCrear.length,
						")"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1398,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3",
					children: elementosPorCrear.map((item, idx) => /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold text-slate-800 dark:text-slate-200",
							children: item.nombre
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1408,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[10px] text-slate-400 mt-0.5 font-mono",
							children: ["Polo Circuito: ", item.circuitoId.replace("auto_", "")]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1409,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1407,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "px-2 py-0.5 rounded text-[8px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
							children: "PENDIENTE"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1411,
							columnNumber: 17
						}, this)]
					}, idx, true, {
						fileName: _jsxFileName,
						lineNumber: 1403,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1401,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1397,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(ModalEdicionCircuito, {
				isOpen: !!editingCircuit,
				onClose: () => setEditingCircuit(null),
				circuitData: editingCircuit,
				tableroCircuits: circuits,
				maxPolos: maxPoles,
				onSave: saveCircuitFromModal,
				elementosCreados: todosElementosCreados
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1421,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "fixed bottom-6 right-6 z-40 no-print",
				children: /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => window.print(),
					className: "flex items-center justify-center w-14 h-14 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 rounded-full shadow-2xl transition-all cursor-pointer group hover:rotate-6",
					title: "Imprimir / Guardar PDF",
					children: /* @__PURE__ */ _jsxDEV(Printer, { className: "w-6 h-6 group-hover:scale-110 transition-transform" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1438,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1433,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1432,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-8 bg-slate-100 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 print:bg-slate-50 print:border-gray-300 print:mt-3",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700 pb-2.5",
					children: "Firma y Cierre de Inspección"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1444,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1.5 items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide",
								children: "Firma del Inspector"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1451,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: tableroData.firmaInspector || "",
								onChange: (e) => updateField("firmaInspector", e.target.value),
								className: "w-full max-w-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-750 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-100 outline-none h-10 transition-all text-center no-print",
								placeholder: "Nombre del Inspector"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1452,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "hidden print:block text-xs font-bold text-slate-900 mt-1 h-6",
								children: tableroData.firmaInspector || "___________________________"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1459,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "hidden print:block w-48 border-b border-gray-400 mt-6 h-1" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1462,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1450,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1.5 items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide",
								children: "Firma / Sello de la Empresa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1467,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: tableroData.firmaSupervisor || "",
								onChange: (e) => updateField("firmaSupervisor", e.target.value),
								className: "w-full max-w-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-750 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-100 outline-none h-10 transition-all text-center no-print",
								placeholder: "Nombre / Sello de la Empresa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1468,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "hidden print:block text-xs font-bold text-slate-900 mt-1 h-6",
								children: tableroData.firmaSupervisor || "___________________________"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1475,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "hidden print:block w-48 border-b border-gray-400 mt-6 h-1" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1478,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1466,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1448,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1443,
				columnNumber: 7
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 606,
			columnNumber: 7
		}, this), " "]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 603,
		columnNumber: 5
	}, this);
};
_s2(TableroComponent, "12Wo8rtSmCeQgUDNH1LC8JBFiEw=", false, function() {
	return [useStore, useConfirm];
});
_c2 = TableroComponent;
export default TableroComponent;
var _c, _c2;
$RefreshReg$(_c, "SafeImage");
$RefreshReg$(_c2, "TableroComponent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TableroComponent.jsx?t=1790793566895";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/TableroComponent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/TableroComponent.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/TableroComponent.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLE9BQU8sa0JBQWtCO0FBQ3pCLFNBQVMsTUFBTSxPQUFPLE1BQU0sU0FBUyxVQUFVLFdBQVcsS0FBSyxPQUFPLGVBQWUsUUFBUSxHQUFHLFNBQVMsUUFBUSxnQkFBZ0I7QUFDakksT0FBTyxjQUFjO0FBQ3JCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsb0JBQW9COzs7OztBQUc3QixNQUFNLGFBQWEsRUFBRSxNQUFNLEtBQUssS0FBSyxnQkFBZ0I7O0NBQ25ELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLElBQUk7Q0FFL0MsZ0JBQWdCO0VBQ2QsSUFBSSxNQUFNO0dBQ1IsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7R0FDcEMsYUFBYSxHQUFHO0dBQ2hCLGFBQWE7SUFDWCxJQUFJLGdCQUFnQixHQUFHO0dBQ3pCO0VBQ0YsT0FBTztHQUNMLGFBQWEsSUFBSTtFQUNuQjtDQUNGLEdBQUcsQ0FBQyxJQUFJLENBQUM7Q0FFVCxNQUFNLFdBQVcsYUFBYTtDQUM5QixJQUFJLENBQUMsVUFBVSxPQUFPO0NBRXRCLE9BQU8sd0JBQUMsT0FBRDtFQUFLLEtBQUs7RUFBZTtFQUFnQjtDQUFZOzs7OztBQUM5RDs7O0FBQ0EsT0FBTywwQkFBMEI7QUFDakMsT0FBTyxtQ0FBbUM7QUFDMUMsU0FBUyxhQUFhLGNBQWMsZUFBZSxjQUFjLGdDQUFnQztBQUVqRyxPQUFPLE1BQU0sb0JBQW9CLEVBQUUsYUFBYSxpQkFBaUIsZUFBZTs7Q0FDOUUsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxJQUFJO0NBQ3pELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQ2hELGFBQWEscUJBQXFCLGFBQWEsZUFBZSxxQkFBcUIsQ0FBQyxDQUN0RjtDQUVBLE1BQU0sRUFDSixXQUNBLDBCQUNBLDBCQUNBLDRCQUNBLFdBQ0EsMkJBQ0UsU0FBUztDQUNiLE1BQU0sRUFBRSxPQUFPLGdCQUFnQixXQUFXO0NBRTFDLE1BQU0sVUFBVSxNQUFNLGNBQWM7RUFDbEMsSUFBSSxDQUFDLGFBQWEsSUFBSSxPQUFPO0VBQzdCLEtBQUssTUFBTSxLQUFLLFdBQVc7R0FDekIsSUFBSSxFQUFFLFdBQVc7SUFDZixLQUFLLE1BQU0sS0FBSyxFQUFFLFdBQVc7S0FDM0IsTUFBTSxXQUFXLEVBQUUsdUJBQXVCLEVBQUUsWUFBWSxDQUFDO0tBQ3pELElBQUksU0FBUyxNQUFLLE1BQUssRUFBRSxPQUFPLFlBQVksRUFBRSxHQUFHO01BQy9DLE9BQU87S0FDVDtJQUNGO0dBQ0Y7RUFDRjtFQUNBLE9BQU87Q0FDVCxHQUFHLENBQUMsV0FBVyxhQUFhLEVBQUUsQ0FBQztDQUUvQixNQUFNLGdCQUFnQixNQUFNLGNBQWM7RUFDeEMsSUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDO0VBQ3RCLFFBQVEsUUFBUSx1QkFBdUIsUUFBUSxZQUFZLENBQUMsRUFBQyxDQUFFLFFBQU8sTUFBSyxFQUFFLE9BQU8sYUFBYSxFQUFFO0NBQ3JHLEdBQUcsQ0FBQyxTQUFTLGFBQWEsRUFBRSxDQUFDO0NBRTdCLE1BQU0sd0JBQXdCLE1BQU0sY0FBYztFQUNoRCxJQUFJLENBQUMsU0FBUyxPQUFPLENBQUM7RUFDdEIsTUFBTSxjQUFjLFFBQVEsdUJBQXVCLFFBQVEsWUFBWSxDQUFDLEVBQUMsQ0FBRSxLQUFJLE9BQU07R0FDbkYsSUFBSSxFQUFFO0dBQ04sUUFBUSxFQUFFO0dBQ1YsTUFBTSxFQUFFLGdCQUFnQjtFQUMxQixFQUFFO0VBQ0YsTUFBTSxpQkFBaUIsUUFBUSxpQkFBaUIsUUFBUSwyQkFBMkIsQ0FBQyxFQUFDLENBQUUsS0FBSSxPQUFNO0dBQy9GLElBQUksRUFBRTtHQUNOLFFBQVEsRUFBRTtHQUNWLE1BQU07RUFDUixFQUFFO0VBQ0YsTUFBTSxVQUFVLFFBQVEsa0JBQWtCLENBQUMsRUFBQyxDQUFFLEtBQUksT0FBTTtHQUN0RCxJQUFJLEVBQUU7R0FDTixRQUFRLEVBQUU7R0FDVixNQUFNO0VBQ1IsRUFBRTtFQUNGLE1BQU0sUUFBUSxRQUFRLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSSxPQUFNO0dBQzdDLElBQUksRUFBRTtHQUNOLFFBQVEsRUFBRTtHQUNWLE1BQU07RUFDUixFQUFFO0VBQ0YsT0FBTztHQUFDLEdBQUc7R0FBWSxHQUFHO0dBQWUsR0FBRztHQUFRLEdBQUc7RUFBSSxDQUFDLENBQUMsUUFBTyxNQUFLLEVBQUUsT0FBTyxhQUFhLEVBQUU7Q0FDbkcsR0FBRyxDQUFDLFNBQVMsYUFBYSxFQUFFLENBQUM7Q0FFN0IsTUFBTSx1QkFBdUIsWUFBWSxhQUFhLG1CQUFtQixhQUFhLHdCQUF3QjtFQUM1RyxJQUFJLENBQUMsY0FBYyxlQUFlLFdBQVc7R0FDM0MsT0FBTyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUE4RDtHQUFhOzs7OztFQUNwRztFQUVBLElBQUksWUFBWTtFQUNoQixJQUFJLFlBQVkscUJBQXFCLGVBQWU7RUFDcEQsSUFBSSxjQUFjLHVCQUF1QixlQUFlO0VBRXhELE1BQU0sUUFBUSxPQUFPLFVBQVUsQ0FBQyxDQUFDLE1BQU0sOENBQThDO0VBQ3JGLElBQUksT0FBTztHQUNULElBQUksTUFBTSxJQUFJLFlBQVksTUFBTSxFQUFFLENBQUMsS0FBSztHQUN4QyxJQUFJLE1BQU0sTUFBTSxDQUFDLFdBQVcsWUFBWSxNQUFNLEVBQUUsQ0FBQyxLQUFLO0VBQ3hEO0VBRUEsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBd0Q7R0FBZ0I7Ozs7YUFDdkYsYUFDQyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQixDQUNHLGVBQWUsZ0JBQWdCLGlCQUFpQixnQkFBZ0IsWUFBWSxHQUFHLFlBQVksTUFBTSxJQUFJLFNBQ2xHOzs7OztXQUVMOzs7Ozs7Q0FFVDtDQUVBLE1BQU0sMEJBQTBCLGFBQWEsd0JBQXdCO0VBQ25FLE1BQU0sS0FBSyx1QkFBdUIsZUFBZSxHQUFFLENBQUUsWUFBWTtFQUNqRSxJQUFJLENBQUMsR0FBRyxPQUFPO0VBRWYsSUFBSSxNQUFNLGVBQWUsTUFBTSxpQkFBaUI7R0FDOUMsT0FDRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFvSjtHQUU5Sjs7Ozs7RUFFVjtFQUNBLElBQUksTUFBTSxjQUFjLE1BQU0sU0FBUyxNQUFNLE9BQU87R0FDbEQsT0FDRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUF3SjtHQUVsSzs7Ozs7RUFFVjtFQUNBLElBQUksTUFBTSxlQUFlLE1BQU0sU0FBUyxNQUFNLFVBQVU7R0FDdEQsT0FDRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUE0SjtHQUV0Szs7Ozs7RUFFVjtFQUNBLElBQUksTUFBTSxTQUFTLE1BQU0sU0FBUztHQUNoQyxPQUNFLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQXdKO0dBRWxLOzs7OztFQUVWO0VBQ0EsSUFBSSxNQUFNLGlCQUFpQixNQUFNLE1BQU07R0FDckMsT0FDRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUE0STtHQUV0Sjs7Ozs7RUFFVjtFQUNBLElBQUksTUFBTSxtQkFBbUIsTUFBTSxTQUFTO0dBQzFDLE9BQ0Usd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBd0o7R0FFbEs7Ozs7O0VBRVY7RUFDQSxJQUFJLE1BQU0sb0JBQW9CLE1BQU0sV0FBVztHQUM3QyxPQUNFLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWdKO0dBRTFKOzs7OztFQUVWO0VBQ0EsSUFBSSxNQUFNLGlCQUFpQixNQUFNLFdBQVc7R0FDMUMsT0FDRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFnSjtHQUUxSjs7Ozs7RUFFVjtFQUNBLElBQUksTUFBTSx5QkFBeUI7R0FDakMsT0FDRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFvSjtHQUU5Sjs7Ozs7RUFFVjtFQUNBLE9BQ0Usd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBaEIsQ0FBaUssT0FDM0osQ0FDQTs7Ozs7O0NBRVY7O0NBR0EsTUFBTSxXQUFXLGFBQWEsWUFBWTtDQUMxQyxNQUFNLFdBQVcsYUFBYSxZQUFZLENBQUM7Q0FFM0MsTUFBTSxxQkFBcUIsTUFBTSxjQUFjO0VBQzdDLElBQUksQ0FBQyxhQUFhLE9BQU8sQ0FBQztFQUMxQixNQUFNLE9BQU8sU0FBUyxLQUFJLE1BQUs7R0FDN0IsTUFBTSxZQUFZLE1BQU0sUUFBUSxFQUFFLEtBQUssS0FBSyxFQUFFLE1BQU0sU0FBUyxJQUFJLEVBQUUsTUFBTSxLQUFLO0dBQzlFLE1BQU0sY0FBYyxFQUFFLGNBQWMsRUFBRSxjQUFjLEVBQUUsYUFBYyxZQUFZLGNBQWMsWUFBWSxXQUFXLGNBQWU7R0FDcEksT0FBTztJQUNMLEdBQUc7SUFDSCxPQUFPLE1BQU0sUUFBUSxFQUFFLEtBQUssS0FBSyxFQUFFLE1BQU0sU0FBUyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDbEUsU0FBUyxFQUFFLFdBQVc7S0FBRSxPQUFPO0tBQUksTUFBTTtLQUFJLEtBQUs7SUFBRztJQUNyRCxZQUFZO0lBQ1osWUFBWTtHQUNkO0VBQ0YsQ0FBQztFQUVELE1BQU0sZUFBZSxJQUFJLElBQUk7RUFDN0IsS0FBSyxTQUFRLE1BQUs7R0FDaEIsSUFBSSxNQUFNLFFBQVEsRUFBRSxLQUFLLEdBQUc7SUFDMUIsRUFBRSxNQUFNLFNBQVEsTUFBSyxhQUFhLElBQUksQ0FBQyxDQUFDO0dBQzFDO0VBQ0YsQ0FBQzs7RUFHRCxLQUFLLElBQUksT0FBTyxHQUFHLFFBQVEsVUFBVSxRQUFRO0dBQzNDLElBQUksQ0FBQyxhQUFhLElBQUksSUFBSSxHQUFHO0lBQzNCLE1BQU0sY0FBZSxZQUFZLGNBQWMsWUFBWSxXQUFXLFNBQVU7SUFDaEYsS0FBSyxLQUFLO0tBQ1IsSUFBSSxRQUFRO0tBQ1osTUFBTSxPQUFPLE1BQU0sSUFBSSxTQUFTO0tBQ2hDLE9BQU8sQ0FBQyxJQUFJO0tBQ1osUUFBUTtLQUNSLFNBQVM7TUFBRSxPQUFPO01BQUksTUFBTTtNQUFJLEtBQUs7S0FBRztLQUN4QyxXQUFXO0tBQ1gsWUFBWTtLQUNaLFlBQVk7SUFDZCxDQUFDO0dBQ0g7RUFDRjs7RUFHQSxPQUFPLEtBQUssTUFBTSxHQUFHLE1BQU07R0FDekIsTUFBTSxPQUFPLE1BQU0sUUFBUSxFQUFFLEtBQUssS0FBSyxFQUFFLE1BQU0sU0FBUyxJQUFJLEtBQUssSUFBSSxHQUFHLEVBQUUsS0FBSyxJQUFJO0dBQ25GLE1BQU0sT0FBTyxNQUFNLFFBQVEsRUFBRSxLQUFLLEtBQUssRUFBRSxNQUFNLFNBQVMsSUFBSSxLQUFLLElBQUksR0FBRyxFQUFFLEtBQUssSUFBSTtHQUNuRixPQUFPLE9BQU87RUFDaEIsQ0FBQztDQUNILEdBQUc7RUFBQztFQUFVO0VBQVU7Q0FBVyxDQUFDO0NBSXBDLElBQUksQ0FBQyxhQUFhLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBa0I7Q0FBMkM7Ozs7O0NBRXJHLE1BQU0sRUFDSixJQUNBLFdBQ0EsZUFDQSxNQUNBLE1BQ0EsVUFDQSxvQkFBb0IsQ0FBQyxHQUNyQixtQkFBbUIsQ0FBQyxHQUNwQixVQUFVLENBQUMsR0FDWCxXQUNBLGdCQUFnQixDQUFDLEdBQ2pCLGVBQWUsQ0FBQyxHQUNoQix5QkFBeUIsT0FDdkI7O0NBR0osTUFBTSxlQUFlLE1BQU0sVUFBVTtFQUNuQyxJQUFJLFVBQVU7RUFDZCxNQUFNLFVBQVUsRUFBRSxHQUFHLFlBQVk7RUFFakMsSUFBSSxLQUFLLFNBQVMsR0FBRyxHQUFHO0dBQ3RCLE1BQU0sQ0FBQyxRQUFRLFNBQVMsS0FBSyxNQUFNLEdBQUc7R0FDdEMsUUFBUSxVQUFVO0lBQUUsR0FBRyxRQUFRO0tBQVUsUUFBUTtHQUFNO0VBQ3pELE9BQU87R0FDTCxRQUFRLFFBQVE7RUFDbEI7RUFFQSxnQkFBZ0IsT0FBTztDQUN6Qjs7Q0FHQSxNQUFNLGlCQUFpQixXQUFXLE9BQU8sVUFBVTtFQUNqRCxJQUFJLFVBQVU7RUFDZCxNQUFNLFVBQVUsRUFBRSxHQUFHLFlBQVk7RUFDakMsUUFBUSxXQUFXLG1CQUFtQixLQUFJLE1BQUs7R0FDN0MsSUFBSSxFQUFFLE9BQU8sV0FBVztJQUN0QixJQUFJLE1BQU0sV0FBVyxVQUFVLEdBQUc7S0FDaEMsTUFBTSxDQUFDLEdBQUcsWUFBWSxNQUFNLE1BQU0sR0FBRztLQUNyQyxPQUFPO01BQ0wsR0FBRztNQUNILFNBQVM7T0FBRSxHQUFHLEVBQUU7UUFBVSxXQUFXO01BQU07S0FDN0M7SUFDRjtJQUNBLE9BQU87S0FBRSxHQUFHO01BQUksUUFBUTtJQUFNO0dBQ2hDO0dBQ0EsT0FBTztFQUNULENBQUM7RUFDRCxnQkFBZ0IsT0FBTztDQUN6Qjs7Q0FHQSxNQUFNLHlCQUF5QixZQUFZLGFBQWE7RUFDdEQsSUFBSSxVQUFVO0VBQ2QsTUFBTSxVQUFVLEVBQUUsR0FBRyxZQUFZO0VBQ2pDLElBQUksa0JBQWtCLENBQUMsR0FBSSxZQUFZLFlBQVksQ0FBQyxDQUFFOztFQUd0RCxRQUFRLGFBQWE7R0FDbkIsR0FBSSxZQUFZLGNBQWMsQ0FBQztJQUM5QixhQUFhO0VBQ2hCOztFQUdBLE1BQU0sZ0JBQWdCLGdCQUFnQixXQUFVLE1BQUssTUFBTSxRQUFRLEVBQUUsS0FBSyxLQUFLLEVBQUUsTUFBTSxTQUFTLFVBQVUsQ0FBQztFQUUzRyxJQUFJLGlCQUFpQixHQUFHO0dBQ3RCLGdCQUFnQixpQkFBaUI7SUFDL0IsR0FBRyxnQkFBZ0I7SUFDbkIsWUFBWTtJQUNaLFlBQVk7SUFDWixXQUFXO0dBQ2I7RUFDRixPQUFPOztHQUVMLGdCQUFnQixLQUFLO0lBQ25CLElBQUksUUFBUSxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQztJQUNoRSxNQUFNLGFBQWEsTUFBTSxJQUFJLFNBQVM7SUFDdEMsT0FBTyxDQUFDLFVBQVU7SUFDbEIsUUFBUTtJQUNSLFNBQVM7S0FBRSxPQUFPO0tBQUksTUFBTTtLQUFJLEtBQUs7SUFBRztJQUN4QyxXQUFXO0lBQ1gsWUFBWTtJQUNaLFlBQVk7SUFDWixXQUFXO0dBQ2IsQ0FBQztFQUNIO0VBRUEsUUFBUSxXQUFXLGdCQUFnQixRQUFPLE1BQUs7R0FDN0MsTUFBTSxhQUFhLEVBQUUsWUFBWSxFQUFFLFFBQVEsU0FBUyxFQUFFLFFBQVEsUUFBUSxFQUFFLFFBQVE7R0FDaEYsTUFBTSxlQUFlLEVBQUUsYUFBYSxFQUFFLGNBQWMsU0FBUyxFQUFFLGNBQWMsU0FBUyxFQUFFLGNBQWM7R0FDdEcsTUFBTSxZQUFZLEVBQUUsVUFBVSxFQUFFLFdBQVcsYUFBYSxFQUFFLFdBQVc7R0FDckUsTUFBTSxXQUFXLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxFQUFFLE1BQU07R0FDNUQsTUFBTSxjQUFjLE1BQU0sUUFBUSxFQUFFLEtBQUssS0FBSyxFQUFFLE1BQU0sU0FBUztHQUMvRCxNQUFNLGVBQWUsQ0FBQyxFQUFFLEVBQUUsY0FBYyxFQUFFLGNBQWMsRUFBRTtHQUMxRCxPQUFPLGNBQWMsZ0JBQWdCLGFBQWEsRUFBRSxjQUFjLEVBQUUsZUFBZSxFQUFFLGVBQWUsWUFBWSxlQUFlO0VBQ2pJLENBQUM7RUFFRCxnQkFBZ0IsT0FBTztDQUN6QjtDQUVBLE1BQU0sd0JBQXdCLFdBQVcsa0JBQWtCO0VBQ3pELElBQUksVUFBVTtFQUNkLE1BQU0sVUFBVSxFQUFFLEdBQUcsWUFBWTtFQUVqQyxJQUFJLGtCQUFrQixjQUFjLGdCQUFnQiwyQkFBMkIsY0FBYyxnQkFBZ0IseUJBQXlCLFNBQVMsSUFBSTtHQUNqSixNQUFNLGlCQUFpQixjQUFjLHFCQUFxQixjQUFjO0dBQ3hFLElBQUksT0FBTztHQUNYLElBQUksZ0JBQWdCO0lBQ2xCLFFBQVEsUUFBUSx1QkFBdUIsUUFBUSxZQUFZLENBQUMsRUFBQyxDQUFFLE1BQUssTUFBSyxFQUFFLE9BQU8sY0FBYztHQUNsRztHQUNBLElBQUksQ0FBQyxNQUFNO0lBQ1QsTUFBTSxXQUFXLE1BQU0sUUFBUSxjQUFjLEtBQUssS0FBSyxjQUFjLE1BQU0sU0FBUyxJQUNoRixjQUFjLE1BQU0sS0FBSyxJQUFJLElBQzVCLGNBQWMsZ0JBQWdCO0lBRW5DLE1BQU0sV0FBVyxjQUFjLDJCQUEyQixjQUFjLHVCQUF1QjtJQUMvRixNQUFNLGNBQWMsR0FBRyxTQUFTLG9CQUFvQixTQUFTO0lBQzdELE1BQU0sV0FBVyxjQUFjLHFCQUFxQixjQUFjLFVBQVU7SUFFNUUsT0FBTyx5QkFBeUIsUUFBUSxJQUFJO0tBQzFDLFFBQVEsWUFBWSxhQUFhLGtDQUFrQyxXQUFXO0tBQzlFLGNBQWM7S0FDZCxnQkFBZ0I7SUFDbEIsQ0FBQztHQUNIO0dBRUEsSUFBSSxNQUFNO0lBQ1IsY0FBYyxjQUFjLEtBQUs7SUFDakMsY0FBYyxvQkFBb0IsS0FBSztJQUN2QyxjQUFjLHNCQUFzQixLQUFLLGdCQUFnQixjQUFjLDJCQUEyQjtJQUNsRyxjQUFjLFNBQVMsR0FBRyxLQUFLLE9BQU8sUUFBUSxLQUFLLEdBQUc7SUFDdEQsY0FBYyxjQUFjLEtBQUssaUJBQWlCLFlBQVksZ0JBQWdCO0lBRTlFLE1BQU0sY0FBYztLQUFFLElBQUksS0FBSztLQUFJLFFBQVEsS0FBSztLQUFRLGNBQWMsS0FBSztLQUFjO0lBQVc7SUFDcEcsTUFBTSxzQkFBc0IscUJBQXFCLENBQUMsRUFBQyxDQUFFLFFBQU8sU0FBUSxLQUFLLGVBQWUsYUFBYSxLQUFLLE9BQU8sS0FBSyxFQUFFO0lBQ3hILE1BQU0sY0FBYyxDQUFDLEdBQUcsb0JBQW9CLFdBQVc7SUFDdkQscUJBQXFCLFdBQVc7SUFDaEMsUUFBUSxvQkFBb0I7R0FDOUI7RUFDRjtFQUVBLElBQUksa0JBQWtCLENBQUMsR0FBSSxZQUFZLFlBQVksQ0FBQyxDQUFFO0VBRXRELElBQUksa0JBQWtCLE1BQU07O0dBRTFCLGtCQUFrQixnQkFBZ0IsUUFBTyxNQUFLLEVBQUUsT0FBTyxhQUFhLENBQUMsRUFBRSxHQUFHLFdBQVcsT0FBTyxDQUFDO0VBQy9GLE9BQU87R0FDTCxNQUFNLFNBQVMsVUFBVSxXQUFXLE9BQU87R0FDM0MsSUFBSSxRQUFROztJQUVWLGdCQUFnQixLQUFLO0tBQ25CLElBQUksUUFBUSxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQztLQUNoRSxHQUFHO0lBQ0wsQ0FBQztHQUNILE9BQU87O0lBRUwsa0JBQWtCLGdCQUFnQixLQUFJLE1BQUs7S0FDekMsSUFBSSxFQUFFLE9BQU8sV0FBVztNQUN0QixPQUFPO09BQUUsR0FBRztPQUFHLEdBQUc7TUFBYztLQUNsQztLQUNBLE9BQU87SUFDVCxDQUFDO0dBQ0g7RUFDRjs7RUFHQSxRQUFRLFdBQVcsZ0JBQWdCLFFBQU8sTUFBSztHQUM3QyxNQUFNLGFBQWEsRUFBRSxZQUFZLEVBQUUsUUFBUSxTQUFTLEVBQUUsUUFBUSxRQUFRLEVBQUUsUUFBUTtHQUNoRixNQUFNLGVBQWUsRUFBRSxhQUFhLEVBQUUsY0FBYyxTQUFTLEVBQUUsY0FBYyxTQUFTLEVBQUUsY0FBYztHQUN0RyxNQUFNLFlBQVksRUFBRSxVQUFVLEVBQUUsV0FBVyxhQUFhLEVBQUUsV0FBVztHQUNyRSxNQUFNLFdBQVcsRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLEVBQUUsTUFBTTtHQUM1RCxNQUFNLGNBQWMsTUFBTSxRQUFRLEVBQUUsS0FBSyxLQUFLLEVBQUUsTUFBTSxTQUFTO0dBQy9ELE1BQU0sZUFBZSxDQUFDLEVBQUUsRUFBRSxjQUFjLEVBQUUsY0FBYyxFQUFFO0dBQzFELE1BQU0sYUFBYSxDQUFDLEVBQUUsRUFBRSxxQkFBcUIsRUFBRSxlQUFlLEVBQUUsdUJBQXVCLEVBQUU7R0FDekYsT0FBTyxjQUFjLGdCQUFnQixhQUFhLEVBQUUsY0FBYyxjQUFjLFlBQVksZUFBZTtFQUM3RyxDQUFDO0VBRUQsZ0JBQWdCLE9BQU87Q0FDekI7O0NBR0EsTUFBTSxpQkFBaUIsY0FBYztFQUNuQyxJQUFJLFVBQVU7RUFDZCxNQUFNLFVBQVUsbUJBQW1CLE1BQUssTUFBSyxFQUFFLE9BQU8sU0FBUztFQUMvRCxJQUFJLENBQUMsU0FBUztFQUVkLElBQUksUUFBUSxNQUFNLFVBQVUsR0FBRztHQUM3QixVQUFVLDZDQUE2QyxTQUFTO0dBQ2hFO0VBQ0Y7RUFFQSxNQUFNLGlCQUFpQixLQUFLLElBQUksR0FBRyxRQUFRLEtBQUs7RUFDaEQsTUFBTSxhQUFhLGlCQUFpQjtFQUNwQyxJQUFJLGFBQWEsVUFBVTs7RUFHM0IsTUFBTSwyQkFBMkIsTUFBTTtHQUNyQyxNQUFNLGFBQWEsRUFBRSxZQUFZLEVBQUUsUUFBUSxTQUFTLEVBQUUsUUFBUSxRQUFRLEVBQUUsUUFBUTtHQUNoRixNQUFNLGVBQWUsRUFBRSxhQUFhLEVBQUUsY0FBYyxTQUFTLEVBQUUsY0FBYyxTQUFTLEVBQUUsY0FBYztHQUN0RyxNQUFNLGNBQWMsRUFBRSxVQUFVLEVBQUUsV0FBVyxhQUFhLEVBQUUsV0FBVyxnQkFBZ0IsQ0FBQyxFQUFFLE9BQU8sV0FBVyxTQUFTLEtBQUssQ0FBQyxFQUFFLE9BQU8sV0FBVyxZQUFZO0dBQzNKLE9BQU8sY0FBYyxnQkFBZ0IsZUFBZSxFQUFFLGNBQWMsRUFBRTtFQUN4RTtFQUVBLE1BQU0sa0JBQWtCLFlBQVksWUFBWSxDQUFDLEVBQUMsQ0FBRSxNQUFLLE1BQUssRUFBRSxPQUFPLGFBQWEsRUFBRSxNQUFNLFNBQVMsVUFBVSxDQUFDO0VBQ2hILElBQUksa0JBQWtCLHdCQUF3QixjQUFjLEdBQUc7R0FDN0QsMkJBQTJCO0lBQ3pCLFdBQVcsWUFBWTtJQUN2QixlQUFlLFlBQVksVUFBVTtJQUNyQyxXQUFXLFNBQVMsYUFBYSxTQUFTLGFBQWEsWUFBWTtJQUNuRSxZQUFZLFNBQVMsTUFBTSxZQUFZO0lBQ3ZDLE9BQU8sQ0FBQyxVQUFVO0lBQ2xCLFlBQVksUUFBUTtJQUNwQixnQkFBZ0IsUUFBUSxVQUFVLGlCQUFpQixRQUFRLE1BQU07SUFDakUsaUJBQWlCLGVBQWU7SUFDaEMsYUFBYSxRQUFRO0lBQ3JCLGFBQWEsbUJBQW1CLENBQUMsR0FBRyxRQUFRLE9BQU8sVUFBVSxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsb0JBQW9CLFdBQVcsNEJBQTRCLGVBQWUsT0FBTztJQUMzSixNQUFNO0dBQ1IsQ0FBQztHQUNELFVBQVUscUJBQXFCLFdBQVcsbUNBQW1DLFdBQVc7SUFDdEYsT0FBTztJQUNQLGVBQWUsdUJBQXVCLElBQUk7R0FDNUMsQ0FBQztFQUNIO0VBRUEsTUFBTSxVQUFVLEVBQUUsR0FBRyxZQUFZO0VBQ2pDLElBQUksbUJBQW1CLENBQUMsR0FBSSxZQUFZLFlBQVksQ0FBQyxDQUFFOztFQUd2RCxJQUFJLGdCQUFnQjtHQUNsQixtQkFBbUIsaUJBQWlCLFFBQU8sTUFBSyxFQUFFLE9BQU8sZUFBZSxFQUFFO0VBQzVFO0VBRUEsTUFBTSxnQkFBZ0IsaUJBQWlCLE1BQUssTUFBSyxFQUFFLE9BQU8sU0FBUztFQUNuRSxNQUFNLFdBQVcsQ0FBQyxHQUFHLFFBQVEsT0FBTyxVQUFVLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUM7RUFFcEUsSUFBSSxlQUFlO0dBQ2pCLFFBQVEsV0FBVyxpQkFBaUIsS0FBSSxNQUFLO0lBQzNDLElBQUksRUFBRSxPQUFPLFdBQVc7S0FDdEIsT0FBTztNQUFFLEdBQUc7TUFBRyxPQUFPO01BQVUsVUFBVSxTQUFTO0tBQU87SUFDNUQ7SUFDQSxPQUFPO0dBQ1QsQ0FBQztFQUNILE9BQU87R0FDTCxRQUFRLFdBQVcsQ0FDakIsR0FBRyxrQkFDSDtJQUNFLElBQUksUUFBUSxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQztJQUNoRSxNQUFNLFFBQVE7SUFDZCxPQUFPO0lBQ1AsVUFBVSxTQUFTO0lBQ25CLFFBQVEsUUFBUSxVQUFVO0lBQzFCLFNBQVMsUUFBUSxXQUFXO0tBQUUsT0FBTztLQUFJLE1BQU07S0FBSSxLQUFLO0lBQUc7SUFDM0QsV0FBVyxRQUFRLGFBQWE7R0FDbEMsQ0FDRjtFQUNGO0VBRUEsZ0JBQWdCLE9BQU87Q0FDekI7O0NBR0EsTUFBTSxnQkFBZ0IsY0FBYztFQUNsQyxJQUFJLFVBQVU7RUFDZCxNQUFNLFVBQVUsbUJBQW1CLE1BQUssTUFBSyxFQUFFLE9BQU8sU0FBUztFQUMvRCxNQUFNLFVBQVUsRUFBRSxHQUFHLFlBQVk7RUFFakMsSUFBSSxXQUFXLE1BQU0sUUFBUSxRQUFRLEtBQUssS0FBSyxRQUFRLE1BQU0sU0FBUyxHQUFHO0dBQ3ZFLE1BQU0sVUFBVSxLQUFLLElBQUksR0FBRyxRQUFRLEtBQUs7R0FDekMsTUFBTSxhQUFhLENBQUMsUUFBUSxHQUFHLFdBQVcsT0FBTztHQUVqRCxJQUFJLFlBQVk7SUFDZCxRQUFRLFlBQVksWUFBWSxZQUFZLENBQUMsRUFBQyxDQUFFLEtBQUksTUFBSztLQUN2RCxJQUFJLEVBQUUsT0FBTyxXQUFXO01BQ3RCLE9BQU87T0FDTCxHQUFHO09BQ0gsT0FBTyxDQUFDLE9BQU87T0FDZixVQUFVO09BQ1YsY0FBYztNQUNoQjtLQUNGO0tBQ0EsT0FBTztJQUNULENBQUM7R0FDSCxPQUFPO0lBQ0wsUUFBUSxZQUFZLFlBQVksWUFBWSxDQUFDLEVBQUMsQ0FBRSxRQUFPLE1BQUssRUFBRSxPQUFPLFNBQVM7R0FDaEY7R0FFQSxVQUFVLHVFQUF1RSxRQUFRLElBQUksTUFBTTtFQUNyRyxPQUFPO0dBQ0wsUUFBUSxZQUFZLFlBQVksWUFBWSxDQUFDLEVBQUMsQ0FBRSxRQUFPLE1BQUssRUFBRSxPQUFPLFNBQVM7RUFDaEY7RUFFQSxnQkFBZ0IsT0FBTztDQUN6Qjs7Q0FHQSxNQUFNLFdBQVcsTUFBTSxLQUFLLEVBQUUsUUFBUSxLQUFLLEtBQUssV0FBVyxDQUFDLEVBQUUsSUFBSSxHQUFHLE1BQU0sSUFBSSxJQUFJLENBQUM7O0NBR3BGLE1BQU0scUJBQXFCLFNBQVM7RUFDbEMsT0FBTyxtQkFBbUIsTUFBSyxNQUFLLEVBQUUsTUFBTSxTQUFTLElBQUksQ0FBQztDQUM1RDtDQUVBLE1BQU0sa0JBQWtCLFlBQVk7RUFDbEMsSUFBSTtHQUNGLE1BQU0sWUFBWSxhQUFhO0dBQy9CLElBQUksQ0FBQyxXQUFXO0lBQ2QsWUFBWSw4QkFBOEI7SUFDMUM7R0FDRjtHQUNBLE1BQU0sUUFBUSxTQUFTLFNBQVMsQ0FBQyxDQUFDLFNBQVMsYUFBYSxRQUFRLE9BQU87R0FDdkUsTUFBTSxVQUFVLEVBQ2QsR0FBSSxRQUFRLEVBQUUsaUJBQWlCLFVBQVUsUUFBUSxJQUFJLENBQUMsRUFDeEQ7R0FFQSxJQUFJLFdBQVcsTUFBTSxNQUFNLEdBQUcsYUFBYSxnQkFBZ0IsVUFBVSxPQUFPLEVBQUUsUUFBUSxDQUFDOztHQUd2RixJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLFdBQVcsTUFBTSxNQUFNLEdBQUcsYUFBYSxrQ0FBa0M7S0FDdkUsUUFBUTtLQUNSLFNBQVM7TUFDUCxnQkFBZ0I7TUFDaEIsR0FBRztLQUNMO0tBQ0EsTUFBTSxLQUFLLFVBQVUsRUFBRSxTQUFTLFlBQVksQ0FBQztJQUMvQyxDQUFDO0dBQ0g7R0FFQSxJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLE1BQU0sSUFBSSxNQUFNLDhCQUE4QixTQUFTLE9BQU8sRUFBRTtHQUNsRTtHQUVBLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztHQUNqQyxNQUFNLE1BQU0sT0FBTyxJQUFJLGdCQUFnQixJQUFJO0dBQzNDLE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztHQUNwQyxFQUFFLE9BQU87R0FDVCxFQUFFLFdBQVcsYUFBYSxZQUFZLFVBQVUsVUFBUyxDQUFFLFFBQVEsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLFlBQVksRUFBRTtHQUN6RyxTQUFTLEtBQUssWUFBWSxDQUFDO0dBQzNCLEVBQUUsTUFBTTtHQUNSLE9BQU8sSUFBSSxnQkFBZ0IsR0FBRztHQUM5QixTQUFTLEtBQUssWUFBWSxDQUFDO0VBQzdCLFNBQVMsS0FBSztHQUNaLFFBQVEsTUFBTSwyQkFBMkIsR0FBRztHQUM1QyxZQUFZLDBDQUEwQyxJQUFJLE9BQU87RUFDbkU7Q0FDRjtDQUdBLE1BQU0sdUJBQXVCO0VBQzNCLE9BQU8sTUFBTTtDQUNmO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVyw4RUFBOEUsV0FBVyxtQ0FBbUM7WUFBNUksQ0FHRSx3QkFBQyxPQUFEO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUdBLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQ25CLHdCQUFDLFNBQUQ7T0FFRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWix3QkFBQyxNQUFEO1NBQUksU0FBUztTQUFHLFdBQVU7bUJBQ3hCLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSxvREFBcUQ7Ozs7cUJBQ3BFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUF3RDtXQUFzRDs7OzttQkFDM0g7Ozs7O29CQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsVUFBRDtZQUNFLE1BQUs7WUFDTCxTQUFTO1lBQ1QsV0FBVTtZQUNWLE9BQU07c0JBSlIsQ0FNRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O3NCQUNuQyx3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7O29CQUNuQjs7Ozs7cUJBQ1Isd0JBQUMsVUFBRDtZQUNFLE1BQUs7WUFDTCxTQUFTO1lBQ1QsV0FBVTtZQUNWLE9BQU07c0JBSlIsQ0FNRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxjQUFlOzs7O3NCQUNsQyx3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7O29CQUNwQjs7Ozs7bUJBQ0w7Ozs7O2tCQUNGOzs7Ozs7UUFDSDs7Ozs7T0FDRjs7Ozs7T0FHSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFvSDtRQUU5SDs7OztrQkFDSix3QkFBQyxNQUFEO1NBQUksU0FBUztTQUFHLFdBQVU7bUJBQ3hCLHdCQUFDLGNBQUQ7VUFDRSxPQUFPO1VBQ1AsU0FBUyxRQUFRLFlBQVksYUFBYSxHQUFHO1VBQzdDLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7O1FBQ0M7Ozs7Z0JBQ0Y7Ozs7OztPQUdKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQThIO1FBRXhJOzs7O2tCQUNKLHdCQUFDLE1BQUQ7U0FBSSxTQUFTO1NBQUcsV0FBVTttQkFDeEIsd0JBQUMsK0JBQUQ7VUFDRSxZQUFZLFNBQVM7VUFDckIsaUJBQWlCLGFBQWE7VUFDOUIsT0FBTztVQUNQLFdBQVcsS0FBSyxnQkFBZ0I7V0FDOUIsWUFBWSxpQkFBaUIsR0FBRztXQUNoQyxJQUFJLGFBQWEsaUJBQWlCLGVBQWU7WUFDL0MsWUFBWSwrQkFBK0IsWUFBWSxFQUFFO1lBQ3pELHlCQUF5QixTQUFTLElBQUksWUFBWSxJQUFJLFlBQVksRUFBRTtXQUN0RSxPQUFPO1lBQ0wsWUFBWSwrQkFBK0IsYUFBYSxPQUFPLFdBQVksYUFBYSxNQUFNLE9BQVEsSUFBSTtZQUMxRyx5QkFBeUIsU0FBUyxJQUFJLFlBQVksSUFBSSxhQUFhLE9BQU8sV0FBWSxhQUFhLE1BQU0sT0FBUSxJQUFJO1dBQ3ZIO1VBQ0Y7VUFDQSxPQUFNO1VBQ04sYUFBWTtTQUNiOzs7OztRQUNDOzs7O2dCQUNGOzs7Ozs7T0FHSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFvSDtRQUU5SDs7OztrQkFDSix3QkFBQyxNQUFEO1NBQUksU0FBUztTQUFHLFdBQVU7bUJBQ3hCLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFDRSx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBOEU7YUFBeUI7Ozs7O2FBQ3ZILHdCQUFDLFNBQUQ7Y0FDRSxNQUFLO2NBQ0wsT0FBTztjQUNQLFVBQVU7Y0FDVixXQUFXLE1BQU07ZUFDZixNQUFNLE1BQU0sU0FBUyxFQUFFLE9BQU8sT0FBTyxFQUFFLEtBQUs7ZUFDNUMsTUFBTSxrQkFBa0IsU0FBUyxRQUFRLEtBQUssTUFBTTtnQkFDbEQsTUFBTSxTQUFTLEtBQUssSUFBSSxHQUFHLEVBQUUsS0FBSztnQkFDbEMsT0FBTyxTQUFTLE1BQU0sU0FBUztlQUNqQyxHQUFHLENBQUM7ZUFDSixJQUFJLE1BQU0saUJBQWlCO2dCQUN6QixZQUFZLHNDQUFzQyxJQUFJLGdFQUFnRSxnQkFBZ0IsRUFBRTtnQkFDeEk7ZUFDRjtlQUNBLFlBQVksWUFBWSxHQUFHO2NBQzdCO2NBQ0EsV0FBVTthQUNYOzs7OzthQUNELHdCQUFDLFVBQUQ7Y0FDRSxPQUFPO2NBQ1AsVUFBVTtjQUNWLFdBQVcsTUFBTTtlQUNmLE1BQU0sTUFBTSxTQUFTLEVBQUUsT0FBTyxPQUFPLEVBQUU7ZUFDdkMsSUFBSSxDQUFDLEtBQUs7ZUFDVixNQUFNLGtCQUFrQixTQUFTLFFBQVEsS0FBSyxNQUFNO2dCQUNsRCxNQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsRUFBRSxLQUFLO2dCQUNsQyxPQUFPLFNBQVMsTUFBTSxTQUFTO2VBQ2pDLEdBQUcsQ0FBQztlQUNKLElBQUksTUFBTSxpQkFBaUI7Z0JBQ3pCLFlBQVksc0NBQXNDLElBQUksZ0VBQWdFLGdCQUFnQixFQUFFO2dCQUN4STtlQUNGO2VBQ0EsWUFBWSxZQUFZLEdBQUc7Y0FDN0I7Y0FDQSxXQUFVO3dCQWhCWixDQWtCRSx3QkFBQyxVQUFEO2VBQVEsT0FBTTtlQUFHLFdBQVU7eUJBQThCO2NBQXNCOzs7O3dCQUM5RTtlQUFDO2VBQUk7ZUFBSTtlQUFJO2VBQUk7ZUFBSTtlQUFJO2VBQUk7ZUFBSTtjQUFFLENBQUMsQ0FBQyxLQUFJLFFBQ3hDLHdCQUFDLFVBQUQ7ZUFBa0IsT0FBTztlQUFLLFdBQVU7eUJBQXhDLENBQXVFLEtBQUksUUFBYztpQkFBNUU7Ozs7cUJBQTRFLENBQzFGLENBQ0s7Ozs7OztZQUNMOzs7Ozs7V0FFTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFxRTtZQUFZOzs7O3NCQUNqRyx3QkFBQyxVQUFEO2FBQ0UsT0FBTyxZQUFZLFVBQVUsWUFBWSxZQUFZLFFBQVE7YUFDN0QsV0FBVyxNQUFNLFlBQVksU0FBUyxTQUFTLEVBQUUsT0FBTyxPQUFPLEVBQUUsQ0FBQzthQUNsRSxXQUFVO3VCQUVUO2NBQUM7Y0FBRztjQUFHO2FBQUMsQ0FBQyxDQUFDLEtBQUksUUFDYix3QkFBQyxVQUFEO2NBQWtCLE9BQU87Y0FBSyxXQUFVO3dCQUF4QyxDQUF1RSxLQUFJLFVBQWdCO2dCQUE5RTs7OztvQkFBOEUsQ0FDNUY7WUFDSzs7OztvQkFDTDs7Ozs7O1dBRUwsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFDRSx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBcUU7YUFBb0M7Ozs7O2FBQ3pILHdCQUFDLFNBQUQ7Y0FDRSxNQUFLO2NBQ0wsTUFBSztjQUNMLE9BQU8sWUFBWSxXQUFXO2NBQzlCLFVBQVU7Y0FDVixXQUFXLE1BQU0sWUFBWSxXQUFXLEVBQUUsT0FBTyxLQUFLO2NBQ3RELGFBQVk7Y0FDWixXQUFVO2FBQ1g7Ozs7O2FBQ0Qsd0JBQUMsWUFBRDtjQUFVLElBQUc7d0JBQ1YseUJBQXlCLEtBQUksTUFBSyx3QkFBQyxVQUFEO2VBQWdCLE9BQU87eUJBQUk7Y0FBVSxHQUF4Qjs7OztxQkFBd0IsQ0FBQzthQUNqRTs7Ozs7WUFDUDs7Ozs7O1VBQ0Y7Ozs7OztRQUNIOzs7O2dCQUNGOzs7Ozs7T0FHSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxTQUFTO1VBQUcsV0FBVTtvQkFBZ0U7U0FFdEY7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFNBQVM7VUFBRyxXQUFVO29CQUExQixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWM7V0FBcUI7Ozs7cUJBQ25ELHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsU0FBRDthQUFPLFdBQVU7dUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtjQUNFLE1BQUs7Y0FDTCxTQUFTLFNBQVM7Y0FDbEIsZ0JBQWdCLFlBQVksUUFBUSxhQUFhO2NBQ2pELFdBQVU7YUFDWDs7Ozt1QkFDRCx3QkFBQyxRQUFEO2NBQU0sV0FBVyxTQUFTLGdCQUFnQiw2QkFBNkI7d0JBQUk7YUFBaUI7Ozs7cUJBQ3ZGOzs7OztzQkFDUCx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBakIsQ0FDRSx3QkFBQyxTQUFEO2NBQ0UsTUFBSztjQUNMLFNBQVMsU0FBUztjQUNsQixnQkFBZ0IsWUFBWSxRQUFRLFdBQVc7Y0FDL0MsV0FBVTthQUNYOzs7O3VCQUNELHdCQUFDLFFBQUQ7Y0FBTSxXQUFXLFNBQVMsY0FBYyw2QkFBNkI7d0JBQUk7YUFBZTs7OztxQkFDbkY7Ozs7O29CQUNKOzs7OzttQkFDRjs7Ozs7b0JBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQU87VUFBc0I7Ozs7a0JBQzFDOzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBcUU7U0FFL0U7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWdCO1NBRTFCOzs7OztRQUNGOzs7Ozs7T0FHSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxTQUFTO1VBQUcsV0FBVTtvQkFBd0Q7U0FBbUI7Ozs7O1NBQ3JHLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE2RDtTQUFTOzs7OztTQUNwRix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBNkQ7U0FBUTs7Ozs7U0FDbkYsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQTZEO1NBQU87Ozs7O1NBQ2xGLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUF3RDtTQUFVOzs7OztTQUNoRix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBUTtTQUFvQjs7Ozs7UUFDeEM7Ozs7OztPQUdKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXdIO1NBQU07Ozs7O1NBQzVJLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNaLHdCQUFDLGNBQUQ7V0FDRSxPQUFPLGtCQUFrQjtXQUN6QixTQUFTLFFBQVEsWUFBWSx3QkFBd0IsR0FBRztXQUN4RCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztTQUNDOzs7OztTQUVKLHdCQUFDLE1BQUQ7VUFBSSxTQUFTO1VBQUcsV0FBVTtvQkFDeEIsd0JBQUMsY0FBRDtXQUNFLE9BQU8saUJBQWlCO1dBQ3hCLFNBQVMsUUFBUSxZQUFZLDBCQUEwQixHQUFHO1dBQzFELE1BQUs7V0FDTCxTQUFTO1dBQ1QsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7U0FDQzs7Ozs7U0FFSix3QkFBQyxNQUFEO1VBQUksU0FBUztVQUFHLFdBQVU7b0JBQ3hCLHdCQUFDLGNBQUQ7V0FDRSxPQUFPLGlCQUFpQjtXQUN4QixTQUFTLFFBQVEsWUFBWSx5QkFBeUIsR0FBRztXQUN6RCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztTQUNDOzs7OztTQUVKLHdCQUFDLE1BQUQ7VUFBSSxTQUFTO1VBQUcsV0FBVTtvQkFDeEIsd0JBQUMsY0FBRDtXQUNFLE9BQU8saUJBQWlCO1dBQ3hCLFNBQVMsUUFBUSxZQUFZLHdCQUF3QixHQUFHO1dBQ3hELE1BQUs7V0FDTCxTQUFTO1dBQ1QsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7U0FDQzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxjQUFEO1dBQ0UsT0FBTyxRQUFRO1dBQ2YsU0FBUyxRQUFRLFlBQVksY0FBYyxHQUFHO1dBQzlDLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7O1NBQ0M7Ozs7O1NBRUosd0JBQUMsTUFBRDtVQUFJLFNBQVM7VUFBRyxXQUFVO29CQUN4Qix3QkFBQyxjQUFEO1dBQ0UsT0FBTztXQUNQLFNBQVMsUUFBUSxZQUFZLGFBQWEsR0FBRztXQUM3QyxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztTQUNDOzs7OztRQUNGOzs7Ozs7T0FHSix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFtSDtTQUFNOzs7OztTQUN2SSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxjQUFEO1dBQ0UsT0FBTyxrQkFBa0I7V0FDekIsU0FBUyxRQUFRLFlBQVksd0JBQXdCLEdBQUc7V0FDeEQsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7U0FDQzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxjQUFEO1dBQ0UsT0FBTyxRQUFRO1dBQ2YsU0FBUyxRQUFRLFlBQVksY0FBYyxHQUFHO1dBQzlDLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7O1NBQ0M7Ozs7O1FBQ0Y7Ozs7OztPQUdKLHdCQUFDLE1BQUQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUg7UUFBTTs7Ozs7UUFDdkksd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1osd0JBQUMsY0FBRDtVQUNFLE9BQU8sa0JBQWtCO1VBQ3pCLFNBQVMsUUFBUSxZQUFZLHdCQUF3QixHQUFHO1VBQ3hELGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7O1FBQ0M7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1osd0JBQUMsY0FBRDtVQUNFLE9BQU8sUUFBUTtVQUNmLFNBQVMsUUFBUSxZQUFZLGNBQWMsR0FBRztVQUM5QyxhQUFZO1VBQ1osV0FBVTtTQUNYOzs7OztRQUNDOzs7OztPQUNGOzs7OztNQUNDOzs7OztLQUNGOzs7OztJQUNKOzs7O2NBR0wsd0JBQUMsT0FBRDtLQUNFLFdBQVU7S0FDVixPQUFPLEVBQUUsV0FBVyxHQUFHLFlBQVksYUFBYSxJQUFJLElBQUk7ZUFGMUQsQ0FJRSx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSw2QkFBOEI7Ozs7aUJBQ2hELHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7ZUFDM0I7Ozs7OztNQUVKLFlBQVksT0FDWCx3QkFBQyxPQUFEO09BQ0UsV0FBVTtPQUNWLE9BQU8sRUFBRSxRQUFRLEdBQUcsWUFBWSxhQUFhLElBQUksSUFBSTtpQkFGdkQsQ0FJRSx3QkFBQyxXQUFEO1FBQ0UsTUFBTTtRQUNOLEtBQUs7UUFDTCxLQUFJO1FBQ0osV0FBVTtRQUNWLE9BQU8sRUFBRSxXQUFXLEdBQUcsWUFBWSxhQUFhLElBQUksSUFBSTtPQUN6RDs7OztpQkFDRCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWU7U0FDYixnQkFBZ0I7VUFDZCxHQUFHO1VBQ0gsVUFBVTtVQUNWLE1BQU07U0FDUixDQUFDO1FBQ0g7UUFDQSxXQUFVO1FBQ1YsT0FBTTtrQkFFTix3QkFBQyxHQUFELEVBQUcsV0FBVSxjQUFlOzs7OztPQUN0Qjs7OztlQUNMOzs7OztpQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQjtTQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHlCQUEwQjs7Ozs7U0FDNUMsd0JBQUMsUUFBRCxZQUFNLGlCQUFvQjs7Ozs7U0FDMUIsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxRQUFPO1VBQ1AsU0FBUTtVQUNSLFdBQVcsTUFBTTtXQUNmLE1BQU0sT0FBTyxFQUFFLE9BQU8sTUFBTTtXQUM1QixJQUFJLENBQUMsTUFBTTtXQUNYLElBQUksS0FBSyxPQUFPLEtBQUssT0FBTyxNQUFNO1lBQ2hDLFlBQVksNkNBQTZDO1lBQ3pEO1dBQ0Y7V0FDQSxnQkFBZ0I7WUFDZCxHQUFHO1lBQ0gsVUFBVTtZQUNWLE1BQU07V0FDUixDQUFDO1VBQ0g7VUFDQSxXQUFVO1NBQ1g7Ozs7O1FBQ0k7Ozs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQjtTQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7Ozs7U0FDM0Msd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7Ozs7U0FDOUIsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxRQUFPO1VBQ1AsV0FBVyxNQUFNO1dBQ2YsTUFBTSxPQUFPLEVBQUUsT0FBTyxNQUFNO1dBQzVCLElBQUksQ0FBQyxNQUFNO1dBQ1gsSUFBSSxLQUFLLE9BQU8sS0FBSyxPQUFPLE1BQU07WUFDaEMsWUFBWSw2Q0FBNkM7WUFDekQ7V0FDRjtXQUNBLGdCQUFnQjtZQUNkLEdBQUc7WUFDSCxVQUFVO1lBQ1YsTUFBTTtXQUNSLENBQUM7VUFDSDtVQUNBLFdBQVU7U0FDWDs7Ozs7UUFDSTs7Ozs7ZUFDSjs7Ozs7O09BSUwsWUFBWSxTQUNaLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7O2tCQUNqQyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBNEMsWUFBWSxhQUFhLEtBQUksSUFBUTs7Ozs7Z0JBQzlFOzs7OztpQkFDTCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLEtBQUk7UUFDSixLQUFJO1FBQ0osT0FBTyxZQUFZLGFBQWE7UUFDaEMsV0FBVyxNQUFNLFlBQVksYUFBYSxTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUM7UUFDbEUsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7OztLQUVKOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQXlGO0tBRW5HOzs7O2FBQ0Y7Ozs7O1lBRUY7Ozs7OztHQUdELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBakIsQ0FDRSx3QkFBQyxTQUFELGFBRUUsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksU0FBUztRQUFHLFdBQVU7a0JBQThEO09BQXVCOzs7OztPQUMvRyx3QkFBQyxNQUFEO1FBQUksU0FBUztRQUFHLFdBQVU7a0JBQXNEO09BQXdCOzs7OztPQUN4Ryx3QkFBQyxNQUFEO1FBQUksU0FBUztRQUFHLFdBQVU7a0JBQTZEO09BQVM7Ozs7O09BQ2hHLHdCQUFDLE1BQUQ7UUFBSSxTQUFTO1FBQUcsV0FBVTtrQkFBeUo7T0FBSzs7Ozs7T0FDeEwsd0JBQUMsTUFBRDtRQUFJLFNBQVM7UUFBRyxXQUFVO2tCQUFnSjtPQUFLOzs7OztPQUMvSyx3QkFBQyxNQUFEO1FBQUksU0FBUztRQUFHLFdBQVU7a0JBQTZEO09BQVM7Ozs7O09BQ2hHLHdCQUFDLE1BQUQ7UUFBSSxTQUFTO1FBQUcsV0FBVTtrQkFBc0Q7T0FBd0I7Ozs7O09BQ3hHLHdCQUFDLE1BQUQ7UUFBSSxTQUFTO1FBQUcsV0FBVTtrQkFBYztPQUF1Qjs7Ozs7TUFDN0Q7Ozs7O2VBRUosd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQ7T0FFRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBNkQ7T0FBUzs7Ozs7T0FDcEYsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQTZEO09BQVE7Ozs7O09BQ25GLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUE2RDtPQUFROzs7OztPQUVuRix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBNkQ7T0FBUTs7Ozs7T0FDbkYsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQTZEO09BQVE7Ozs7O09BQ25GLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUE2RDtPQUFTOzs7OztNQUNsRjs7Ozs7YUFDQzs7OztlQUNQLHdCQUFDLFNBQUQsWUFDRyxTQUFTLEtBQUssU0FBUyxhQUFhO01BQ25DLE1BQU0sV0FBVyxVQUFVOztNQUczQixNQUFNLFFBQVEsa0JBQWtCLE9BQU87TUFDdkMsTUFBTSxTQUFTLGtCQUFrQixRQUFROztNQUd6QyxNQUFNLGNBQWMsU0FBUyxLQUFLLElBQUksR0FBRyxNQUFNLEtBQUssTUFBTTtNQUMxRCxNQUFNLGVBQWUsVUFBVSxLQUFLLElBQUksR0FBRyxPQUFPLEtBQUssTUFBTTs7TUFHN0QsTUFBTSxjQUFjLFFBQVEsTUFBTSxNQUFNLFNBQVM7TUFDakQsTUFBTSxlQUFlLFNBQVMsT0FBTyxNQUFNLFNBQVM7TUFFcEQsT0FDRSx3QkFBQyxNQUFEO09BRUUsV0FBVTtpQkFGWjtRQUtHLGVBQ0M7U0FFRSx3QkFBQyxNQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7VUFDVixlQUFlLGtCQUFrQixLQUFLO29CQUh4QyxDQUtFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRyxvQkFBb0IsTUFBTSxRQUFRLE1BQU0sYUFBYSxNQUFNLG1CQUFtQixNQUFNLGFBQWEsTUFBTSxtQkFBbUIsR0FDMUgsTUFBTSxjQUNMLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDJDQUE0Qzs7OztvQkFFNUQ7Ozs7O3FCQUdKLHVCQUF1QixNQUFNLGFBQWEsTUFBTSxtQkFBbUIsQ0FDakU7Ozs7O29CQUNKLGNBQWMsS0FDYix3QkFBQyxVQUFEO1dBQ0UsVUFBVSxNQUFNO1lBQ2QsRUFBRSxnQkFBZ0I7WUFDbEIsYUFBYSxNQUFNLEVBQUU7V0FDdkI7V0FDQSxPQUFNO1dBQ04sV0FBVTtxQkFFVix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OztVQUN0Qjs7OztrQkFFUjs7Ozs7O1NBR0osd0JBQUMsTUFBRDtVQUNFLFNBQVM7VUFDVCxXQUFVO29CQUVWLHdCQUFDLGNBQUQ7V0FDRSxPQUFPLE1BQU0sUUFBUTtXQUNyQixTQUFTLFFBQVEsY0FBYyxNQUFNLElBQUksaUJBQWlCLEdBQUc7V0FDN0QsTUFBSztXQUNMLFNBQVM7V0FDVCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztTQUNDOzs7OztTQUdKLHdCQUFDLE1BQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtvQkFFVix3QkFBQyxjQUFEO1dBQ0UsT0FBTyxNQUFNLFFBQVE7V0FDckIsU0FBUyxRQUFRLGNBQWMsTUFBTSxJQUFJLGdCQUFnQixHQUFHO1dBQzVELE1BQUs7V0FDTCxTQUFTO1dBQ1QsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7U0FDQzs7Ozs7U0FHSix3QkFBQyxNQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7b0JBRVYsd0JBQUMsY0FBRDtXQUNFLE9BQU8sTUFBTSxRQUFRO1dBQ3JCLFNBQVMsUUFBUSxjQUFjLE1BQU0sSUFBSSxlQUFlLEdBQUc7V0FDM0QsTUFBSztXQUNMLFNBQVM7V0FDVCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztTQUNDOzs7OztTQUdKLHdCQUFDLE1BQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtvQkFFVix3QkFBQyxjQUFEO1dBQ0UsT0FBTyxNQUFNO1dBQ2IsU0FBUyxRQUFRLGNBQWMsTUFBTSxJQUFJLGFBQWEsR0FBRztXQUN6RCxNQUFLO1dBQ0wsU0FBUztXQUNULGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7O1NBQ0M7Ozs7O1FBQ0o7Ozs7O1FBSUosd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1osd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBb0U7VUFBYzs7OztvQkFFakcsVUFBVSxXQUFXLEtBQUssZUFBZSxnQkFBZ0IsS0FDeEQsd0JBQUMsVUFBRDtXQUNFLGVBQWUsY0FBYyxNQUFNLElBQUksTUFBTTtXQUM3QyxPQUFNO1dBQ04sV0FBVTtxQkFFVix3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7OztVQUN6Qjs7OztrQkFFUDs7Ozs7O1FBQ0g7Ozs7O1FBSUosd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1osd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBb0U7VUFBZTs7OztvQkFFbEcsV0FBVyxZQUFZLGdCQUFnQixpQkFBaUIsS0FDdkQsd0JBQUMsVUFBRDtXQUNFLGVBQWUsY0FBYyxPQUFPLElBQUksT0FBTztXQUMvQyxPQUFNO1dBQ04sV0FBVTtxQkFFVix3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7OztVQUN6Qjs7OztrQkFFUDs7Ozs7O1FBQ0g7Ozs7O1FBRUgsZ0JBQ0M7U0FFRSx3QkFBQyxNQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7b0JBRVYsd0JBQUMsY0FBRDtXQUNFLE9BQU8sT0FBTztXQUNkLFNBQVMsUUFBUSxjQUFjLE9BQU8sSUFBSSxhQUFhLEdBQUc7V0FDMUQsTUFBSztXQUNMLFNBQVM7V0FDVCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztTQUNDOzs7OztTQUdKLHdCQUFDLE1BQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtvQkFFVix3QkFBQyxjQUFEO1dBQ0UsT0FBTyxPQUFPLFFBQVE7V0FDdEIsU0FBUyxRQUFRLGNBQWMsT0FBTyxJQUFJLGVBQWUsR0FBRztXQUM1RCxNQUFLO1dBQ0wsU0FBUztXQUNULGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7O1NBQ0M7Ozs7O1NBR0osd0JBQUMsTUFBRDtVQUNFLFNBQVM7VUFDVCxXQUFVO29CQUVWLHdCQUFDLGNBQUQ7V0FDRSxPQUFPLE9BQU8sUUFBUTtXQUN0QixTQUFTLFFBQVEsY0FBYyxPQUFPLElBQUksZ0JBQWdCLEdBQUc7V0FDN0QsTUFBSztXQUNMLFNBQVM7V0FDVCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztTQUNDOzs7OztTQUdKLHdCQUFDLE1BQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtvQkFFVix3QkFBQyxjQUFEO1dBQ0UsT0FBTyxPQUFPLFFBQVE7V0FDdEIsU0FBUyxRQUFRLGNBQWMsT0FBTyxJQUFJLGlCQUFpQixHQUFHO1dBQzlELE1BQUs7V0FDTCxTQUFTO1dBQ1QsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7U0FDQzs7Ozs7U0FHSix3QkFBQyxNQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7VUFDVixlQUFlLGtCQUFrQixNQUFNO29CQUh6QyxDQUtFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRyxvQkFBb0IsT0FBTyxRQUFRLE9BQU8sYUFBYSxPQUFPLG1CQUFtQixPQUFPLGFBQWEsT0FBTyxtQkFBbUIsR0FDL0gsT0FBTyxjQUNOLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDJDQUE0Qzs7OztvQkFFNUQ7Ozs7O3FCQUdKLHVCQUF1QixPQUFPLGFBQWEsT0FBTyxtQkFBbUIsQ0FDbkU7Ozs7O29CQUNKLGVBQWUsS0FDZCx3QkFBQyxVQUFEO1dBQ0UsVUFBVSxNQUFNO1lBQ2QsRUFBRSxnQkFBZ0I7WUFDbEIsYUFBYSxPQUFPLEVBQUU7V0FDeEI7V0FDQSxPQUFNO1dBQ04sV0FBVTtxQkFFVix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OztVQUN0Qjs7OztrQkFFUjs7Ozs7O1FBQ0o7Ozs7O09BRUY7U0FwT0c7Ozs7YUFvT0g7S0FFUixDQUFDLEVBQ0k7Ozs7YUFDRjs7Ozs7O0dBQ0o7Ozs7O0dBR0wsd0JBQUMsU0FBRDtJQUFPLFdBQVU7Y0FDZix3QkFBQyxTQUFEO0tBRUUsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBbUg7T0FFN0g7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBNEg7UUFBZ0I7Ozs7a0JBQzNKLHdCQUFDLGNBQUQ7U0FDRSxPQUFPLGNBQWM7U0FDckIsU0FBUyxRQUFRLFlBQVkseUJBQXlCLEdBQUc7U0FDekQsTUFBSztTQUNMLFNBQVM7U0FDVCxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2dCQUNDOzs7Ozs7T0FDSix3QkFBQyxNQUFELEVBQUksV0FBVSwyRkFBK0Y7Ozs7O09BQzdHLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNaLHdCQUFDLGNBQUQ7U0FDRSxPQUFPLGNBQWM7U0FDckIsU0FBUyxRQUFRLFlBQVksK0JBQStCLEdBQUc7U0FDL0QsYUFBWTtTQUNaLFdBQVU7UUFDWDs7Ozs7T0FDQzs7Ozs7TUFDRjs7Ozs7O0tBR0osd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBMkc7T0FFckg7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBNEg7UUFBZ0I7Ozs7a0JBQzNKLHdCQUFDLGNBQUQ7U0FDRSxPQUFPLGFBQWE7U0FDcEIsU0FBUyxRQUFRLFlBQVksd0JBQXdCLEdBQUc7U0FDeEQsTUFBSztTQUNMLFNBQVM7U0FDVCxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2dCQUNDOzs7Ozs7T0FDSix3QkFBQyxNQUFELEVBQUksV0FBVSxvRkFBd0Y7Ozs7O09BQ3RHLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNaLHdCQUFDLGNBQUQ7U0FDRSxPQUFPLGFBQWE7U0FDcEIsU0FBUyxRQUFRLFlBQVksOEJBQThCLEdBQUc7U0FDOUQsYUFBWTtTQUNaLFdBQVU7UUFDWDs7Ozs7T0FDQzs7Ozs7TUFDRjs7Ozs7O0tBR0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7TUFBSSxTQUFTO01BQUcsV0FBVTtnQkFBMUIsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBNEs7TUFFdEw7Ozs7Z0JBQ0wsd0JBQUMsY0FBRDtPQUNFLE9BQU87T0FDUCxTQUFTLFFBQVEsWUFBWSwwQkFBMEIsR0FBRztPQUMxRCxNQUFLO09BQ0wsYUFBWTtPQUNaLFdBQVU7TUFDWDs7OztjQUNDOzs7OztjQUNGOzs7OztJQUNDOzs7OztHQUNGOzs7OztHQUdOLGtCQUFrQixTQUFTLEtBQzFCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkO01BQ0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUseUJBQTBCOzs7OztNQUFDO01BQWdDLGtCQUFrQjtNQUFPO0tBQzNHOzs7OztjQUNKLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osa0JBQWtCLEtBQUssTUFBTSxRQUM1Qix3QkFBQyxPQUFEO01BRUUsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBd0QsS0FBSztNQUFVOzs7O2dCQUNwRix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYixDQUEyRCxtQkFBZ0IsS0FBSyxXQUFXLFFBQVEsU0FBUyxFQUFFLENBQUs7Ozs7O2NBQ2hIOzs7O2dCQUNMLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFnSDtNQUUxSDs7OztjQUNIO1FBVkU7Ozs7WUFVRixDQUNOO0lBQ0U7Ozs7WUFDRjs7Ozs7O0dBSVAsd0JBQUMsc0JBQUQ7SUFDRSxRQUFRLENBQUMsQ0FBQztJQUNWLGVBQWUsa0JBQWtCLElBQUk7SUFDckMsYUFBYTtJQUNiLGlCQUFpQjtJQUNqQixVQUFVO0lBQ1YsUUFBUTtJQUNSLGtCQUFrQjtHQUNuQjs7Ozs7R0FHRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFVBQUQ7S0FDRSxlQUFlLE9BQU8sTUFBTTtLQUM1QixXQUFVO0tBQ1YsT0FBTTtlQUVOLHdCQUFDLFNBQUQsRUFBUyxXQUFVLHFEQUFzRDs7Ozs7SUFDbkU7Ozs7O0dBQ0w7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQXVJO0lBRWpKOzs7O2NBRUosd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQStEO09BQXlCOzs7OztPQUN4Ryx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU8sWUFBWSxrQkFBa0I7UUFDckMsV0FBVyxNQUFNLFlBQVksa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1FBQzdELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7O09BQ0Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsWUFBWSxrQkFBa0I7T0FDM0I7Ozs7O09BQ04sd0JBQUMsT0FBRCxFQUFLLFdBQVUsNERBQWlFOzs7OztNQUM3RTs7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUErRDtPQUFpQzs7Ozs7T0FDaEgsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPLFlBQVksbUJBQW1CO1FBQ3RDLFdBQVcsTUFBTSxZQUFZLG1CQUFtQixFQUFFLE9BQU8sS0FBSztRQUM5RCxXQUFVO1FBQ1YsYUFBWTtPQUNiOzs7OztPQUNELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLFlBQVksbUJBQW1CO09BQzVCOzs7OztPQUNOLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDREQUFpRTs7Ozs7TUFDN0U7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztFQUVBOzs7O1lBQUMsR0FDSDs7Ozs7O0FBRVQ7Ozs7O0FBQ0EsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUYWJsZXJvQ29tcG9uZW50LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBFZGl0YWJsZUNlbGwgZnJvbSAnLi9FZGl0YWJsZUNlbGwnO1xuaW1wb3J0IHsgUGx1cywgTWludXMsIEdyaWQsIENvbHVtbnMsIFNldHRpbmdzLCBSZWZyZXNoQ3csIFphcCwgSW1hZ2UsIENsaXBib2FyZExpc3QsIENhbWVyYSwgWCwgUHJpbnRlciwgUGVuY2lsLCBEb3dubG9hZCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgdXNlU3RvcmUgZnJvbSAnLi4vc3RvcmUvdXNlU3RvcmUnO1xuaW1wb3J0IHsgdXNlQ29uZmlybSB9IGZyb20gJy4uL2NvbnRleHQvQ29uZmlybUNvbnRleHQnO1xuaW1wb3J0IHsgQVBJX0JBU0VfVVJMIH0gZnJvbSAnLi4vdXRpbHMvYXBpJztcblxuLy8gQ29tcG9uZW50ZSBwYXJhIHJlbmRlcml6YXIgQmxvYnMgZGUgZm9ybWEgc2VndXJhIGV2aXRhbmRvIGZ1Z2FzIGRlIG1lbW9yaWFcbmNvbnN0IFNhZmVJbWFnZSA9ICh7IGJsb2IsIHNyYywgYWx0LCBjbGFzc05hbWUgfSkgPT4ge1xuICBjb25zdCBbb2JqZWN0VXJsLCBzZXRPYmplY3RVcmxdID0gdXNlU3RhdGUobnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoYmxvYikge1xuICAgICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICAgIHNldE9iamVjdFVybCh1cmwpO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0T2JqZWN0VXJsKG51bGwpO1xuICAgIH1cbiAgfSwgW2Jsb2JdKTtcblxuICBjb25zdCBmaW5hbFNyYyA9IG9iamVjdFVybCB8fCBzcmM7XG4gIGlmICghZmluYWxTcmMpIHJldHVybiBudWxsO1xuXG4gIHJldHVybiA8aW1nIHNyYz17ZmluYWxTcmN9IGFsdD17YWx0fSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gLz47XG59O1xuaW1wb3J0IE1vZGFsRWRpY2lvbkNpcmN1aXRvIGZyb20gJy4vTW9kYWxFZGljaW9uQ2lyY3VpdG8nO1xuaW1wb3J0IFNlbGVjdG9yQWxpbWVudGFkb3JKZXJhcnF1aWNvIGZyb20gJy4vU2VsZWN0b3JBbGltZW50YWRvckplcmFycXVpY28nO1xuaW1wb3J0IHsgQU1QX09QVElPTlMsIENPTkRfT1BUSU9OUywgTUFSQ0FfT1BUSU9OUywgVElQT19PUFRJT05TLCBURU5TSU9ORVNfQ09WRU5JTl8xNTlfQlQgfSBmcm9tICcuLi91dGlscy9jb25zdGFudHMnO1xuXG5leHBvcnQgY29uc3QgVGFibGVyb0NvbXBvbmVudCA9ICh7IHRhYmxlcm9EYXRhLCBvblVwZGF0ZVRhYmxlcm8sIHJlYWRPbmx5IH0pID0+IHtcbiAgY29uc3QgW2VkaXRpbmdDaXJjdWl0LCBzZXRFZGl0aW5nQ2lyY3VpdF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2VsZW1lbnRvc1BvckNyZWFyLCBzZXRFbGVtZW50b3NQb3JDcmVhcl0gPSB1c2VTdGF0ZShcbiAgICB0YWJsZXJvRGF0YT8uZWxlbWVudG9zUG9yQ3JlYXIgfHwgdGFibGVyb0RhdGE/LmRhdG9zVGVjbmljb3M/LmVsZW1lbnRvc1BvckNyZWFyIHx8IFtdXG4gICk7XG5cbiAgY29uc3QgeyBcbiAgICBjb21wYW5pZXMsIFxuICAgIHVwZGF0ZVRhYmxlcm9BbGltZW50YWRvciwgXG4gICAgY3JlYXJFbGVtZW50b1Byb3Zpc2lvbmFsLFxuICAgIHJlZ2lzdHJhckNvbmZsaWN0b0NpcmN1aXRvLFxuICAgIHNob3dUb2FzdCxcbiAgICBzZXRQYW5lbENvbmZsaWN0b3NPcGVuXG4gIH0gPSB1c2VTdG9yZSgpO1xuICBjb25zdCB7IGFsZXJ0OiBjdXN0b21BbGVydCB9ID0gdXNlQ29uZmlybSgpO1xuXG4gIGNvbnN0IHByb2plY3QgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoIXRhYmxlcm9EYXRhPy5pZCkgcmV0dXJuIG51bGw7XG4gICAgZm9yIChjb25zdCBjIG9mIGNvbXBhbmllcykge1xuICAgICAgaWYgKGMucHJveWVjdG9zKSB7XG4gICAgICAgIGZvciAoY29uc3QgcCBvZiBjLnByb3llY3Rvcykge1xuICAgICAgICAgIGNvbnN0IHRhYmxlcm9zID0gcC5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IHAudGFibGVyb3MgfHwgW107XG4gICAgICAgICAgaWYgKHRhYmxlcm9zLnNvbWUodCA9PiB0LmlkID09PSB0YWJsZXJvRGF0YS5pZCkpIHtcbiAgICAgICAgICAgIHJldHVybiBwO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfSwgW2NvbXBhbmllcywgdGFibGVyb0RhdGE/LmlkXSk7XG5cbiAgY29uc3QgYWxpbWVudGFkb3JlcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGlmICghcHJvamVjdCkgcmV0dXJuIFtdO1xuICAgIHJldHVybiAocHJvamVjdC5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IHByb2plY3QudGFibGVyb3MgfHwgW10pLmZpbHRlcihlID0+IGUuaWQgIT09IHRhYmxlcm9EYXRhPy5pZCk7XG4gIH0sIFtwcm9qZWN0LCB0YWJsZXJvRGF0YT8uaWRdKTtcblxuICBjb25zdCB0b2Rvc0VsZW1lbnRvc0NyZWFkb3MgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoIXByb2plY3QpIHJldHVybiBbXTtcbiAgICBjb25zdCB1bmlmaWxhcmVzID0gKHByb2plY3QuZWxlbWVudG9zVW5pZmlsYXJlcyB8fCBwcm9qZWN0LnRhYmxlcm9zIHx8IFtdKS5tYXAoZSA9PiAoe1xuICAgICAgaWQ6IGUuaWQsXG4gICAgICBub21icmU6IGUubm9tYnJlLFxuICAgICAgdGlwbzogZS50aXBvRWxlbWVudG8gfHwgJ1RBQkxFUk8nXG4gICAgfSkpO1xuICAgIGNvbnN0IHN1YmVzdGFjaW9uZXMgPSAocHJvamVjdC5zdWJlc3RhY2lvbmVzIHx8IHByb2plY3QuaW5zcGVjY2lvbmVzU3ViZXN0YWNpb24gfHwgW10pLm1hcChzID0+ICh7XG4gICAgICBpZDogcy5pZCxcbiAgICAgIG5vbWJyZTogcy5ub21icmUsXG4gICAgICB0aXBvOiAnU1VCRVNUQUNJT04nXG4gICAgfSkpO1xuICAgIGNvbnN0IHB1bnRvcyA9IChwcm9qZWN0LnB1bnRvc01lZGljaW9uIHx8IFtdKS5tYXAocCA9PiAoe1xuICAgICAgaWQ6IHAuaWQsXG4gICAgICBub21icmU6IHAubm9tYnJlLFxuICAgICAgdGlwbzogJ1BVTlRPX01FRElDSU9OJ1xuICAgIH0pKTtcbiAgICBjb25zdCBjY21zID0gKHByb2plY3QuY2NtTGlzdCB8fCBbXSkubWFwKGMgPT4gKHtcbiAgICAgIGlkOiBjLmlkLFxuICAgICAgbm9tYnJlOiBjLm5vbWJyZSxcbiAgICAgIHRpcG86ICdDQ00nXG4gICAgfSkpO1xuICAgIHJldHVybiBbLi4udW5pZmlsYXJlcywgLi4uc3ViZXN0YWNpb25lcywgLi4ucHVudG9zLCAuLi5jY21zXS5maWx0ZXIoZSA9PiBlLmlkICE9PSB0YWJsZXJvRGF0YT8uaWQpO1xuICB9LCBbcHJvamVjdCwgdGFibGVyb0RhdGE/LmlkXSk7XG5cbiAgY29uc3QgcmVuZGVyQ2lyY3VpdEVxdWlwbyA9IChlcXVpcG9UZXh0LCB2aW5jdWxhZG9JZCwgZWxlbWVudG9EZXN0aW5vSWQsIHRpcG9EZXN0aW5vLCB0aXBvRWxlbWVudG9EZXN0aW5vKSA9PiB7XG4gICAgaWYgKCFlcXVpcG9UZXh0IHx8IGVxdWlwb1RleHQgPT09ICdSRVNFUlZBJykge1xuICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTYwMCBpdGFsaWMgZm9udC1tb25vXCI+UkVTRVJWQTwvc3Bhbj47XG4gICAgfVxuXG4gICAgbGV0IGNsZWFuTmFtZSA9IGVxdWlwb1RleHQ7XG4gICAgbGV0IGVsZW1lbnRJZCA9IGVsZW1lbnRvRGVzdGlub0lkIHx8IHZpbmN1bGFkb0lkIHx8IG51bGw7XG4gICAgbGV0IGVsZW1lbnRUeXBlID0gdGlwb0VsZW1lbnRvRGVzdGlubyB8fCB0aXBvRGVzdGlubyB8fCBudWxsO1xuXG4gICAgY29uc3QgbWF0Y2ggPSBTdHJpbmcoZXF1aXBvVGV4dCkubWF0Y2goL14oLio/KSg/OlxccypcXCgoPzpJRDpcXHMqKT8oW0EtWjAtOV8tXSspXFwpKT8kL2kpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgaWYgKG1hdGNoWzFdKSBjbGVhbk5hbWUgPSBtYXRjaFsxXS50cmltKCk7XG4gICAgICBpZiAobWF0Y2hbMl0gJiYgIWVsZW1lbnRJZCkgZWxlbWVudElkID0gbWF0Y2hbMl0udHJpbSgpO1xuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTAuNVwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+e2NsZWFuTmFtZX08L3NwYW4+XG4gICAgICAgIHtlbGVtZW50SWQgJiYgKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciB3LW1heCBweC0xLjUgcHktMC41IHJvdW5kZWQgdGV4dC1bOXB4XSBmb250LW1vbm8gZm9udC1ib2xkIGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTUwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMFwiPlxuICAgICAgICAgICAge2VsZW1lbnRUeXBlICYmIGVsZW1lbnRUeXBlICE9PSAnU1VCX1RBQkxFUk8nICYmIGVsZW1lbnRUeXBlICE9PSAnVEFCTEVSTycgPyBgJHtlbGVtZW50VHlwZX06IGAgOiAnJ317ZWxlbWVudElkfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH07XG5cbiAgY29uc3QgcmVuZGVyVGlwb0Rlc3Rpbm9CYWRnZSA9ICh0aXBvRGVzdGlubywgdGlwb0VsZW1lbnRvRGVzdGlubykgPT4ge1xuICAgIGNvbnN0IHQgPSAodGlwb0VsZW1lbnRvRGVzdGlubyB8fCB0aXBvRGVzdGlubyB8fCAnJykudG9VcHBlckNhc2UoKTtcbiAgICBpZiAoIXQpIHJldHVybiBudWxsO1xuXG4gICAgaWYgKHQgPT09ICdBUlRFRkFDVE8nIHx8IHQgPT09ICdDQVJHQV9ESVJFQ1RBJykge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHctbWF4IHB4LTEgcHktMC41IHJvdW5kZWQgdGV4dC1bOHB4XSBmb250LWJvbGQgYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwIGRhcms6YmctZ3JlZW4tOTAwLzMwIGRhcms6dGV4dC1ncmVlbi0zMDAgbXQtMVwiPlxuICAgICAgICAgIPCflIwgQVJURUZBQ1RPXG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICk7XG4gICAgfVxuICAgIGlmICh0ID09PSAnVFJBTlNGRVInIHx8IHQgPT09ICdBVFMnIHx8IHQgPT09ICdNVFMnKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgdy1tYXggcHgtMSBweS0wLjUgcm91bmRlZCB0ZXh0LVs4cHhdIGZvbnQtYm9sZCBiZy1wdXJwbGUtMTAwIHRleHQtcHVycGxlLTgwMCBkYXJrOmJnLXB1cnBsZS05MDAvMzAgZGFyazp0ZXh0LXB1cnBsZS0zMDAgbXQtMVwiPlxuICAgICAgICAgIPCflIQgVFJBTlNGRVJFTkNJQSAoQVRTKVxuICAgICAgICA8L3NwYW4+XG4gICAgICApO1xuICAgIH1cbiAgICBpZiAodCA9PT0gJ0dFTkVSQURPUicgfHwgdCA9PT0gJ0dFTicgfHwgdCA9PT0gJ1BMQU5UQScpIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciB3LW1heCBweC0xIHB5LTAuNSByb3VuZGVkIHRleHQtWzhweF0gZm9udC1ib2xkIGJnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC04MDAgZGFyazpiZy1lbWVyYWxkLTkwMC8zMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgbXQtMVwiPlxuICAgICAgICAgIOKaoSBHRU5FUkFET1JcbiAgICAgICAgPC9zcGFuPlxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHQgPT09ICdDQ00nIHx8IHQgPT09ICdNT1RPUicpIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciB3LW1heCBweC0xIHB5LTAuNSByb3VuZGVkIHRleHQtWzhweF0gZm9udC1ib2xkIGJnLW9yYW5nZS0xMDAgdGV4dC1vcmFuZ2UtODAwIGRhcms6Ymctb3JhbmdlLTkwMC8zMCBkYXJrOnRleHQtb3JhbmdlLTMwMCBtdC0xXCI+XG4gICAgICAgICAg4pqZ77iPIENDTVxuICAgICAgICA8L3NwYW4+XG4gICAgICApO1xuICAgIH1cbiAgICBpZiAodCA9PT0gJ1NVQkVTVEFDSU9OJyB8fCB0ID09PSAnU0UnKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgdy1tYXggcHgtMSBweS0wLjUgcm91bmRlZCB0ZXh0LVs4cHhdIGZvbnQtYm9sZCBiZy1za3ktMTAwIHRleHQtc2t5LTgwMCBkYXJrOmJnLXNreS05MDAvMzAgZGFyazp0ZXh0LXNreS0zMDAgbXQtMVwiPlxuICAgICAgICAgIPCfj5vvuI8gU1VCRVNUQUNJw5NOXG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICk7XG4gICAgfVxuICAgIGlmICh0ID09PSAnVFJBTlNGT1JNQURPUicgfHwgdCA9PT0gJ1RSQUZPJykge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHctbWF4IHB4LTEgcHktMC41IHJvdW5kZWQgdGV4dC1bOHB4XSBmb250LWJvbGQgYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy04MDAgZGFyazpiZy15ZWxsb3ctOTAwLzMwIGRhcms6dGV4dC15ZWxsb3ctMzAwIG10LTFcIj5cbiAgICAgICAgICDwn5SMIFRSQU5TRk9STUFET1JcbiAgICAgICAgPC9zcGFuPlxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHQgPT09ICdQVU5UT19NRURJQ0lPTicgfHwgdCA9PT0gJ01FRElET1InKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgdy1tYXggcHgtMSBweS0wLjUgcm91bmRlZCB0ZXh0LVs4cHhdIGZvbnQtYm9sZCBiZy10ZWFsLTEwMCB0ZXh0LXRlYWwtODAwIGRhcms6YmctdGVhbC05MDAvMzAgZGFyazp0ZXh0LXRlYWwtMzAwIG10LTFcIj5cbiAgICAgICAgICDwn5OKIE1FRElET1JcbiAgICAgICAgPC9zcGFuPlxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHQgPT09ICdTVUJfVEFCTEVSTycgfHwgdCA9PT0gJ1RBQkxFUk8nKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgdy1tYXggcHgtMSBweS0wLjUgcm91bmRlZCB0ZXh0LVs4cHhdIGZvbnQtYm9sZCBiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtODAwIGRhcms6YmctYmx1ZS05MDAvMzAgZGFyazp0ZXh0LWJsdWUtMzAwIG10LTFcIj5cbiAgICAgICAgICDwn4+iIFNVQi1UQUJMRVJPXG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICk7XG4gICAgfVxuICAgIGlmICh0ID09PSAnU1VCX1RBQkxFUk9fUEVORElFTlRFJykge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHctbWF4IHB4LTEgcHktMC41IHJvdW5kZWQgdGV4dC1bOHB4XSBmb250LWJvbGQgYmctYW1iZXItMTAwIHRleHQtYW1iZXItODAwIGRhcms6YmctYW1iZXItOTAwLzMwIGRhcms6dGV4dC1hbWJlci0zMDAgbXQtMVwiPlxuICAgICAgICAgIOKPsyBSRVNFUlZBIFBFTkRJRU5URVxuICAgICAgICA8L3NwYW4+XG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gKFxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHctbWF4IHB4LTEgcHktMC41IHJvdW5kZWQgdGV4dC1bOHB4XSBmb250LWJvbGQgYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtODAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbXQtMVwiPlxuICAgICAgICDwn5SXIHt0fVxuICAgICAgPC9zcGFuPlxuICAgICk7XG4gIH07XG5cbiAgLy8gTm9ybWFsaXplIGNpcmN1aXRzOiBlbnN1cmUgYWxsIHBvbGVzIGZyb20gMSB0byBtYXhQb2xlcyBhcmUgcmVwcmVzZW50ZWQgZXhhY3RseSBvbmNlXG4gIGNvbnN0IG1heFBvbGVzID0gdGFibGVyb0RhdGE/Lm1heFBvbGVzIHx8IDMwO1xuICBjb25zdCBjaXJjdWl0cyA9IHRhYmxlcm9EYXRhPy5jaXJjdWl0cyB8fCBbXTtcblxuICBjb25zdCBub3JtYWxpemVkQ2lyY3VpdHMgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoIXRhYmxlcm9EYXRhKSByZXR1cm4gW107XG4gICAgY29uc3QgbGlzdCA9IGNpcmN1aXRzLm1hcChjID0+IHtcbiAgICAgIGNvbnN0IGZpcnN0UG9sZSA9IEFycmF5LmlzQXJyYXkoYy5wb2xlcykgJiYgYy5wb2xlcy5sZW5ndGggPiAwID8gYy5wb2xlc1swXSA6IDE7XG4gICAgICBjb25zdCBjdXN0b21MYWJlbCA9IGMuY29kaWdvUG9sbyB8fCBjLnBvbG9fbGFiZWwgfHwgYy5wb2xvTGFiZWwgfHwgKHRhYmxlcm9EYXRhLnBvbGVMYWJlbHMgJiYgdGFibGVyb0RhdGEucG9sZUxhYmVsc1tmaXJzdFBvbGVdKSB8fCAnJztcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLmMsXG4gICAgICAgIHBvbGVzOiBBcnJheS5pc0FycmF5KGMucG9sZXMpICYmIGMucG9sZXMubGVuZ3RoID4gMCA/IGMucG9sZXMgOiBbMV0sXG4gICAgICAgIGJyZWFrZXI6IGMuYnJlYWtlciB8fCB7IG1hcmNhOiAnJywgdGlwbzogJycsIGFtcDogJycgfSxcbiAgICAgICAgY29kaWdvUG9sbzogY3VzdG9tTGFiZWwsXG4gICAgICAgIHBvbG9fbGFiZWw6IGN1c3RvbUxhYmVsXG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgY29uc3QgY292ZXJlZFBvbGVzID0gbmV3IFNldCgpO1xuICAgIGxpc3QuZm9yRWFjaChjID0+IHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGMucG9sZXMpKSB7XG4gICAgICAgIGMucG9sZXMuZm9yRWFjaChwID0+IGNvdmVyZWRQb2xlcy5hZGQocCkpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gRmlsbCBpbiBtaXNzaW5nIHBvbGVzXG4gICAgZm9yIChsZXQgcG9sZSA9IDE7IHBvbGUgPD0gbWF4UG9sZXM7IHBvbGUrKykge1xuICAgICAgaWYgKCFjb3ZlcmVkUG9sZXMuaGFzKHBvbGUpKSB7XG4gICAgICAgIGNvbnN0IGN1c3RvbUxhYmVsID0gKHRhYmxlcm9EYXRhLnBvbGVMYWJlbHMgJiYgdGFibGVyb0RhdGEucG9sZUxhYmVsc1twb2xlXSkgfHwgJyc7XG4gICAgICAgIGxpc3QucHVzaCh7XG4gICAgICAgICAgaWQ6IGBhdXRvXyR7cG9sZX1gLFxuICAgICAgICAgIHNpZGU6IHBvbGUgJSAyID09PSAxID8gJ2xlZnQnIDogJ3JpZ2h0JyxcbiAgICAgICAgICBwb2xlczogW3BvbGVdLFxuICAgICAgICAgIGVxdWlwbzogJ1JFU0VSVkEnLFxuICAgICAgICAgIGJyZWFrZXI6IHsgbWFyY2E6ICcnLCB0aXBvOiAnJywgYW1wOiAnJyB9LFxuICAgICAgICAgIGNvbmR1Y3RvcjogJycsXG4gICAgICAgICAgY29kaWdvUG9sbzogY3VzdG9tTGFiZWwsXG4gICAgICAgICAgcG9sb19sYWJlbDogY3VzdG9tTGFiZWxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gU29ydCBjaXJjdWl0cyBieSB0aGVpciBmaXJzdCBwb2xlIG51bWJlclxuICAgIHJldHVybiBsaXN0LnNvcnQoKGEsIGIpID0+IHtcbiAgICAgIGNvbnN0IG1pbkEgPSBBcnJheS5pc0FycmF5KGEucG9sZXMpICYmIGEucG9sZXMubGVuZ3RoID4gMCA/IE1hdGgubWluKC4uLmEucG9sZXMpIDogMDtcbiAgICAgIGNvbnN0IG1pbkIgPSBBcnJheS5pc0FycmF5KGIucG9sZXMpICYmIGIucG9sZXMubGVuZ3RoID4gMCA/IE1hdGgubWluKC4uLmIucG9sZXMpIDogMDtcbiAgICAgIHJldHVybiBtaW5BIC0gbWluQjtcbiAgICB9KTtcbiAgfSwgW2NpcmN1aXRzLCBtYXhQb2xlcywgdGFibGVyb0RhdGFdKTtcblxuXG5cbiAgaWYgKCF0YWJsZXJvRGF0YSkgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC04XCI+Tm8gaGF5IGRhdG9zIGRlIHRhYmxlcm8gc2VsZWNjaW9uYWRvcy48L2Rpdj47XG5cbiAgY29uc3Qge1xuICAgIGlkLFxuICAgIHViaWNhY2lvbixcbiAgICBhbGltZW50YWRvUG9yLFxuICAgIHRpcG8sXG4gICAgZm90byxcbiAgICBmb3RvQmxvYixcbiAgICBiYXJyYXNQcmluY2lwYWxlcyA9IHt9LFxuICAgIGJyZWFrZXJQcmluY2lwYWwgPSB7fSxcbiAgICB2b2x0YWplID0ge30sXG4gICAgYWNvbWV0aWRhLFxuICAgIG5ldXRyb0xsZWdhZGEgPSB7fSxcbiAgICBwdWVzdGFUaWVycmEgPSB7fSxcbiAgICBvYnNlcnZhY2lvbmVzR2VuZXJhbGVzID0gXCJcIixcbiAgfSA9IHRhYmxlcm9EYXRhO1xuXG4gIC8vIFVwZGF0ZSBzcGVjaWZpYyBmaWVsZHMgb2YgdGhlIG1haW4gdGFibGVybyBzdHJ1Y3R1cmVcbiAgY29uc3QgdXBkYXRlRmllbGQgPSAocGF0aCwgdmFsdWUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBuZXdEYXRhID0geyAuLi50YWJsZXJvRGF0YSB9O1xuICAgIFxuICAgIGlmIChwYXRoLmluY2x1ZGVzKCcuJykpIHtcbiAgICAgIGNvbnN0IFtwYXJlbnQsIGNoaWxkXSA9IHBhdGguc3BsaXQoJy4nKTtcbiAgICAgIG5ld0RhdGFbcGFyZW50XSA9IHsgLi4ubmV3RGF0YVtwYXJlbnRdLCBbY2hpbGRdOiB2YWx1ZSB9O1xuICAgIH0gZWxzZSB7XG4gICAgICBuZXdEYXRhW3BhdGhdID0gdmFsdWU7XG4gICAgfVxuICAgIFxuICAgIG9uVXBkYXRlVGFibGVybyhuZXdEYXRhKTtcbiAgfTtcblxuICAvLyBVcGRhdGUgYSBzaW5nbGUgY2lyY3VpdCdzIHByb3BlcnRpZXNcbiAgY29uc3QgdXBkYXRlQ2lyY3VpdCA9IChjaXJjdWl0SWQsIGZpZWxkLCB2YWx1ZSkgPT4ge1xuICAgIGlmIChyZWFkT25seSkgcmV0dXJuO1xuICAgIGNvbnN0IG5ld0RhdGEgPSB7IC4uLnRhYmxlcm9EYXRhIH07XG4gICAgbmV3RGF0YS5jaXJjdWl0cyA9IG5vcm1hbGl6ZWRDaXJjdWl0cy5tYXAoYyA9PiB7XG4gICAgICBpZiAoYy5pZCA9PT0gY2lyY3VpdElkKSB7XG4gICAgICAgIGlmIChmaWVsZC5zdGFydHNXaXRoKCdicmVha2VyLicpKSB7XG4gICAgICAgICAgY29uc3QgW18sIHN1YkZpZWxkXSA9IGZpZWxkLnNwbGl0KCcuJyk7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLmMsXG4gICAgICAgICAgICBicmVha2VyOiB7IC4uLmMuYnJlYWtlciwgW3N1YkZpZWxkXTogdmFsdWUgfVxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgLi4uYywgW2ZpZWxkXTogdmFsdWUgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjO1xuICAgIH0pO1xuICAgIG9uVXBkYXRlVGFibGVybyhuZXdEYXRhKTtcbiAgfTtcblxuICAvLyBVcGRhdGUgb3IgYXNzaWduIGEgY3VzdG9tIHBvbGUgbGFiZWwgLyBub21lbmNsYXR1cmVcbiAgY29uc3QgaGFuZGxlVXBkYXRlUG9sZUxhYmVsID0gKHBvbGVOdW1iZXIsIG5ld0xhYmVsKSA9PiB7XG4gICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgY29uc3QgbmV3RGF0YSA9IHsgLi4udGFibGVyb0RhdGEgfTtcbiAgICBsZXQgY3VycmVudENpcmN1aXRzID0gWy4uLih0YWJsZXJvRGF0YS5jaXJjdWl0cyB8fCBbXSldO1xuXG4gICAgLy8gQWN0dWFsaXphciBtYXBhIGdsb2JhbCBkZSBldGlxdWV0YXMgZGUgcG9sb1xuICAgIG5ld0RhdGEucG9sZUxhYmVscyA9IHtcbiAgICAgIC4uLih0YWJsZXJvRGF0YS5wb2xlTGFiZWxzIHx8IHt9KSxcbiAgICAgIFtwb2xlTnVtYmVyXTogbmV3TGFiZWxcbiAgICB9O1xuXG4gICAgLy8gQnVzY2FyIHNpIHlhIGV4aXN0ZSB1biBjaXJjdWl0byBxdWUgY29udGVuZ2EgZXN0ZSBwb2xvXG4gICAgY29uc3QgZXhpc3RpbmdJbmRleCA9IGN1cnJlbnRDaXJjdWl0cy5maW5kSW5kZXgoYyA9PiBBcnJheS5pc0FycmF5KGMucG9sZXMpICYmIGMucG9sZXMuaW5jbHVkZXMocG9sZU51bWJlcikpO1xuXG4gICAgaWYgKGV4aXN0aW5nSW5kZXggPj0gMCkge1xuICAgICAgY3VycmVudENpcmN1aXRzW2V4aXN0aW5nSW5kZXhdID0ge1xuICAgICAgICAuLi5jdXJyZW50Q2lyY3VpdHNbZXhpc3RpbmdJbmRleF0sXG4gICAgICAgIGNvZGlnb1BvbG86IG5ld0xhYmVsLFxuICAgICAgICBwb2xvX2xhYmVsOiBuZXdMYWJlbCxcbiAgICAgICAgcG9sb0xhYmVsOiBuZXdMYWJlbFxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gU2kgZXJhIHVuIHBvbG8gdmFjw61vL2F1dG8sIGNyZWFyIGNpcmN1aXRvIHBhcmEgcGVyc2lzdGlyIHN1IGV0aXF1ZXRhIHBlcnNvbmFsaXphZGFcbiAgICAgIGN1cnJlbnRDaXJjdWl0cy5wdXNoKHtcbiAgICAgICAgaWQ6IGBjaXJjXyR7RGF0ZS5ub3coKX1fJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHIoMiwgNSl9YCxcbiAgICAgICAgc2lkZTogcG9sZU51bWJlciAlIDIgPT09IDEgPyAnbGVmdCcgOiAncmlnaHQnLFxuICAgICAgICBwb2xlczogW3BvbGVOdW1iZXJdLFxuICAgICAgICBlcXVpcG86ICdSRVNFUlZBJyxcbiAgICAgICAgYnJlYWtlcjogeyBtYXJjYTogJycsIHRpcG86ICcnLCBhbXA6ICcnIH0sXG4gICAgICAgIGNvbmR1Y3RvcjogJycsXG4gICAgICAgIGNvZGlnb1BvbG86IG5ld0xhYmVsLFxuICAgICAgICBwb2xvX2xhYmVsOiBuZXdMYWJlbCxcbiAgICAgICAgcG9sb0xhYmVsOiBuZXdMYWJlbFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgbmV3RGF0YS5jaXJjdWl0cyA9IGN1cnJlbnRDaXJjdWl0cy5maWx0ZXIoYyA9PiB7XG4gICAgICBjb25zdCBoYXNCcmVha2VyID0gYy5icmVha2VyICYmIChjLmJyZWFrZXIubWFyY2EgfHwgYy5icmVha2VyLnRpcG8gfHwgYy5icmVha2VyLmFtcCk7XG4gICAgICBjb25zdCBoYXNDb25kdWN0b3IgPSBjLmNvbmR1Y3RvciAmJiBjLmNvbmR1Y3RvciAhPT0gJ04vQScgJiYgYy5jb25kdWN0b3IgIT09ICdOL0QnICYmIGMuY29uZHVjdG9yICE9PSAnJztcbiAgICAgIGNvbnN0IGhhc0VxdWlwbyA9IGMuZXF1aXBvICYmIGMuZXF1aXBvICE9PSAnUkVTRVJWQScgJiYgYy5lcXVpcG8gIT09ICdESVNQT05JQkxFJztcbiAgICAgIGNvbnN0IGhhc0ZpY2hhID0gYy5maWNoYSAmJiAoYy5maWNoYS5kZXNjcmlwY2lvbiB8fCBjLmZpY2hhLnBvdGVuY2lhV2F0dHMpO1xuICAgICAgY29uc3QgaXNNdWx0aVBvbGUgPSBBcnJheS5pc0FycmF5KGMucG9sZXMpICYmIGMucG9sZXMubGVuZ3RoID4gMTtcbiAgICAgIGNvbnN0IGhhc1BvbGVMYWJlbCA9ICEhKGMuY29kaWdvUG9sbyB8fCBjLnBvbG9fbGFiZWwgfHwgYy5wb2xvTGFiZWwpO1xuICAgICAgcmV0dXJuIGhhc0JyZWFrZXIgfHwgaGFzQ29uZHVjdG9yIHx8IGhhc0VxdWlwbyB8fCBjLmZvdG9ncmFmaWEgfHwgYy50aXBvRGVzdGlubyB8fCBjLnZpbmN1bGFkb0lkIHx8IGhhc0ZpY2hhIHx8IGlzTXVsdGlQb2xlIHx8IGhhc1BvbGVMYWJlbDtcbiAgICB9KTtcblxuICAgIG9uVXBkYXRlVGFibGVybyhuZXdEYXRhKTtcbiAgfTtcblxuICBjb25zdCBzYXZlQ2lyY3VpdEZyb21Nb2RhbCA9IChjaXJjdWl0SWQsIHVwZGF0ZWRGaWVsZHMpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBuZXdEYXRhID0geyAuLi50YWJsZXJvRGF0YSB9O1xuXG4gICAgaWYgKHVwZGF0ZWRGaWVsZHMgJiYgKHVwZGF0ZWRGaWVsZHMudGlwb0Rlc3Rpbm8gPT09ICdTVUJfVEFCTEVST19QRU5ESUVOVEUnIHx8IHVwZGF0ZWRGaWVsZHMudGlwb0Rlc3Rpbm8gPT09ICdFTEVNRU5UT19QRU5ESUVOVEUnKSAmJiBwcm9qZWN0Py5pZCkge1xuICAgICAgY29uc3QgZXhpc3RpbmdQcm92SWQgPSB1cGRhdGVkRmllbGRzLmVsZW1lbnRvRGVzdGlub0lkIHx8IHVwZGF0ZWRGaWVsZHMudmluY3VsYWRvSWQ7XG4gICAgICBsZXQgcHJvdiA9IG51bGw7XG4gICAgICBpZiAoZXhpc3RpbmdQcm92SWQpIHtcbiAgICAgICAgcHJvdiA9IChwcm9qZWN0LmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgcHJvamVjdC50YWJsZXJvcyB8fCBbXSkuZmluZChlID0+IGUuaWQgPT09IGV4aXN0aW5nUHJvdklkKTtcbiAgICAgIH1cbiAgICAgIGlmICghcHJvdikge1xuICAgICAgICBjb25zdCBwb2xlc1N0ciA9IEFycmF5LmlzQXJyYXkodXBkYXRlZEZpZWxkcy5wb2xlcykgJiYgdXBkYXRlZEZpZWxkcy5wb2xlcy5sZW5ndGggPiAwXG4gICAgICAgICAgPyB1cGRhdGVkRmllbGRzLnBvbGVzLmpvaW4oJywgJylcbiAgICAgICAgICA6ICh1cGRhdGVkRmllbGRzLnBvc2ljaW9uUG9sbyB8fCBjaXJjdWl0SWQpO1xuXG4gICAgICAgIGNvbnN0IHByb3ZUeXBlID0gdXBkYXRlZEZpZWxkcy50aXBvRWxlbWVudG9Qcm92aXNpb25hbCB8fCB1cGRhdGVkRmllbGRzLnRpcG9FbGVtZW50b0Rlc3Rpbm8gfHwgJ1RBQkxFUk8nO1xuICAgICAgICBjb25zdCBkZWZhdWx0TmFtZSA9IGAke3Byb3ZUeXBlfSBBbGltZW50YWRvIChQb2xvICR7cG9sZXNTdHJ9KWA7XG4gICAgICAgIGNvbnN0IHByb3ZOYW1lID0gdXBkYXRlZEZpZWxkcy5ub21icmVQcm92aXNpb25hbCB8fCB1cGRhdGVkRmllbGRzLmVxdWlwbyB8fCBkZWZhdWx0TmFtZTtcblxuICAgICAgICBwcm92ID0gY3JlYXJFbGVtZW50b1Byb3Zpc2lvbmFsKHByb2plY3QuaWQsIHtcbiAgICAgICAgICBub21icmU6IHByb3ZOYW1lICYmIHByb3ZOYW1lICE9PSAnUkVTRVJWQSAoUGVuZGllbnRlIHBvciBDcmVhciknID8gcHJvdk5hbWUgOiBkZWZhdWx0TmFtZSxcbiAgICAgICAgICB0aXBvRWxlbWVudG86IHByb3ZUeXBlLFxuICAgICAgICAgIGNpcmN1aXRvT3JpZ2VuOiBjaXJjdWl0SWRcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGlmIChwcm92KSB7XG4gICAgICAgIHVwZGF0ZWRGaWVsZHMudmluY3VsYWRvSWQgPSBwcm92LmlkO1xuICAgICAgICB1cGRhdGVkRmllbGRzLmVsZW1lbnRvRGVzdGlub0lkID0gcHJvdi5pZDtcbiAgICAgICAgdXBkYXRlZEZpZWxkcy50aXBvRWxlbWVudG9EZXN0aW5vID0gcHJvdi50aXBvRWxlbWVudG8gfHwgdXBkYXRlZEZpZWxkcy50aXBvRWxlbWVudG9Qcm92aXNpb25hbCB8fCAnVEFCTEVSTyc7XG4gICAgICAgIHVwZGF0ZWRGaWVsZHMuZXF1aXBvID0gYCR7cHJvdi5ub21icmV9IChJRDogJHtwcm92LmlkfSlgO1xuICAgICAgICB1cGRhdGVkRmllbGRzLnRpcG9EZXN0aW5vID0gcHJvdi50aXBvRWxlbWVudG8gPT09ICdUQUJMRVJPJyA/ICdTVUJfVEFCTEVSTycgOiAnRUxFTUVOVE9fVklOQ1VMQURPJztcblxuICAgICAgICBjb25zdCBwZW5kaW5nSXRlbSA9IHsgaWQ6IHByb3YuaWQsIG5vbWJyZTogcHJvdi5ub21icmUsIHRpcG9FbGVtZW50bzogcHJvdi50aXBvRWxlbWVudG8sIGNpcmN1aXRvSWQgfTtcbiAgICAgICAgY29uc3QgZmlsdGVyZWRQZW5kaWVudGVzID0gKGVsZW1lbnRvc1BvckNyZWFyIHx8IFtdKS5maWx0ZXIoaXRlbSA9PiBpdGVtLmNpcmN1aXRvSWQgIT09IGNpcmN1aXRJZCAmJiBpdGVtLmlkICE9PSBwcm92LmlkKTtcbiAgICAgICAgY29uc3QgdXBkYXRlZExpc3QgPSBbLi4uZmlsdGVyZWRQZW5kaWVudGVzLCBwZW5kaW5nSXRlbV07XG4gICAgICAgIHNldEVsZW1lbnRvc1BvckNyZWFyKHVwZGF0ZWRMaXN0KTtcbiAgICAgICAgbmV3RGF0YS5lbGVtZW50b3NQb3JDcmVhciA9IHVwZGF0ZWRMaXN0O1xuICAgICAgfVxuICAgIH1cblxuICAgIGxldCBjdXJyZW50Q2lyY3VpdHMgPSBbLi4uKHRhYmxlcm9EYXRhLmNpcmN1aXRzIHx8IFtdKV07XG5cbiAgICBpZiAodXBkYXRlZEZpZWxkcyA9PT0gbnVsbCkge1xuICAgICAgLy8gUmVtb3ZlIGZyb20gY3VzdG9tIGNpcmN1aXRzIGxpc3Qgc28gaXQgZmFsbHMgYmFjayB0byBhdXRvLWdlbmVyYXRlZCBSRVNFUlZBXG4gICAgICBjdXJyZW50Q2lyY3VpdHMgPSBjdXJyZW50Q2lyY3VpdHMuZmlsdGVyKGMgPT4gYy5pZCAhPT0gY2lyY3VpdElkICYmICFjLmlkLnN0YXJ0c1dpdGgoJ2F1dG9fJykpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBpc0F1dG8gPSBjaXJjdWl0SWQuc3RhcnRzV2l0aCgnYXV0b18nKTtcbiAgICAgIGlmIChpc0F1dG8pIHtcbiAgICAgICAgLy8gQ3JlYXRlIG5ldyBjdXN0b20gY2lyY3VpdFxuICAgICAgICBjdXJyZW50Q2lyY3VpdHMucHVzaCh7XG4gICAgICAgICAgaWQ6IGBjaXJjXyR7RGF0ZS5ub3coKX1fJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHIoMiwgNSl9YCxcbiAgICAgICAgICAuLi51cGRhdGVkRmllbGRzXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gVXBkYXRlIGV4aXN0aW5nIGN1c3RvbSBjaXJjdWl0XG4gICAgICAgIGN1cnJlbnRDaXJjdWl0cyA9IGN1cnJlbnRDaXJjdWl0cy5tYXAoYyA9PiB7XG4gICAgICAgICAgaWYgKGMuaWQgPT09IGNpcmN1aXRJZCkge1xuICAgICAgICAgICAgcmV0dXJuIHsgLi4uYywgLi4udXBkYXRlZEZpZWxkcyB9O1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gYztcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gRmlsdGVyIG91dCBjb21wbGV0ZWx5IGVtcHR5IGRlZmF1bHQgY2lyY3VpdHMgdG8gcHJldmVudCBkYXRhYmFzZSBibG9hdFxuICAgIG5ld0RhdGEuY2lyY3VpdHMgPSBjdXJyZW50Q2lyY3VpdHMuZmlsdGVyKGMgPT4ge1xuICAgICAgY29uc3QgaGFzQnJlYWtlciA9IGMuYnJlYWtlciAmJiAoYy5icmVha2VyLm1hcmNhIHx8IGMuYnJlYWtlci50aXBvIHx8IGMuYnJlYWtlci5hbXApO1xuICAgICAgY29uc3QgaGFzQ29uZHVjdG9yID0gYy5jb25kdWN0b3IgJiYgYy5jb25kdWN0b3IgIT09ICdOL0EnICYmIGMuY29uZHVjdG9yICE9PSAnTi9EJyAmJiBjLmNvbmR1Y3RvciAhPT0gJyc7XG4gICAgICBjb25zdCBoYXNFcXVpcG8gPSBjLmVxdWlwbyAmJiBjLmVxdWlwbyAhPT0gJ1JFU0VSVkEnICYmIGMuZXF1aXBvICE9PSAnRElTUE9OSUJMRSc7XG4gICAgICBjb25zdCBoYXNGaWNoYSA9IGMuZmljaGEgJiYgKGMuZmljaGEuZGVzY3JpcGNpb24gfHwgYy5maWNoYS5wb3RlbmNpYVdhdHRzKTtcbiAgICAgIGNvbnN0IGlzTXVsdGlQb2xlID0gQXJyYXkuaXNBcnJheShjLnBvbGVzKSAmJiBjLnBvbGVzLmxlbmd0aCA+IDE7XG4gICAgICBjb25zdCBoYXNQb2xlTGFiZWwgPSAhIShjLmNvZGlnb1BvbG8gfHwgYy5wb2xvX2xhYmVsIHx8IGMucG9sb0xhYmVsKTtcbiAgICAgIGNvbnN0IGhhc0Rlc3Rpbm8gPSAhIShjLmVsZW1lbnRvRGVzdGlub0lkIHx8IGMudmluY3VsYWRvSWQgfHwgYy50aXBvRWxlbWVudG9EZXN0aW5vIHx8IGMudGlwb0Rlc3Rpbm8pO1xuICAgICAgcmV0dXJuIGhhc0JyZWFrZXIgfHwgaGFzQ29uZHVjdG9yIHx8IGhhc0VxdWlwbyB8fCBjLmZvdG9ncmFmaWEgfHwgaGFzRGVzdGlubyB8fCBoYXNGaWNoYSB8fCBpc011bHRpUG9sZSB8fCBoYXNQb2xlTGFiZWw7XG4gICAgfSk7XG5cbiAgICBvblVwZGF0ZVRhYmxlcm8obmV3RGF0YSk7XG4gIH07XG5cbiAgLy8gR3JvdXAgYSBwb2xlIHdpdGggdGhlIG5leHQgcG9sZSBvbiB0aGUgc2FtZSBzaWRlIChtYXhpbXVtIDMgcG9sZXMpXG4gIGNvbnN0IGdyb3VwV2l0aE5leHQgPSAoY2lyY3VpdElkKSA9PiB7XG4gICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgY29uc3QgY2lyY3VpdCA9IG5vcm1hbGl6ZWRDaXJjdWl0cy5maW5kKGMgPT4gYy5pZCA9PT0gY2lyY3VpdElkKTtcbiAgICBpZiAoIWNpcmN1aXQpIHJldHVybjtcblxuICAgIGlmIChjaXJjdWl0LnBvbGVzLmxlbmd0aCA+PSAzKSB7XG4gICAgICBzaG93VG9hc3QoXCJFbCBuw7ptZXJvIG3DoXhpbW8gZGUgcG9sb3MgYWdydXBhZG9zIGVzIDMuXCIsIFwid2FybmluZ1wiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBjdXJyZW50TWF4UG9sZSA9IE1hdGgubWF4KC4uLmNpcmN1aXQucG9sZXMpO1xuICAgIGNvbnN0IHRhcmdldFBvbGUgPSBjdXJyZW50TWF4UG9sZSArIDI7IC8vIE5leHQgcG9sZSBvbiB0aGUgc2FtZSBzaWRlXG4gICAgaWYgKHRhcmdldFBvbGUgPiBtYXhQb2xlcykgcmV0dXJuO1xuXG4gICAgLy8gSGVscGVyIHRvIGRldGVybWluZSBpZiBhIGNpcmN1aXQgaXMgYWN0dWFsbHkgb2NjdXBpZWQgYnkgY3VzdG9taXplZCBkYXRhXG4gICAgY29uc3QgaXNPY2N1cGllZEJ5UmVhbENpcmN1aXQgPSAoYykgPT4ge1xuICAgICAgY29uc3QgaGFzQnJlYWtlciA9IGMuYnJlYWtlciAmJiAoYy5icmVha2VyLm1hcmNhIHx8IGMuYnJlYWtlci50aXBvIHx8IGMuYnJlYWtlci5hbXApO1xuICAgICAgY29uc3QgaGFzQ29uZHVjdG9yID0gYy5jb25kdWN0b3IgJiYgYy5jb25kdWN0b3IgIT09ICdOL0EnICYmIGMuY29uZHVjdG9yICE9PSAnTi9EJyAmJiBjLmNvbmR1Y3RvciAhPT0gJyc7XG4gICAgICBjb25zdCBoYXNSZWFsTmFtZSA9IGMuZXF1aXBvICYmIGMuZXF1aXBvICE9PSAnUkVTRVJWQScgJiYgYy5lcXVpcG8gIT09ICdESVNQT05JQkxFJyAmJiAhYy5lcXVpcG8uc3RhcnRzV2l0aCgnUkVTRVJWQScpICYmICFjLmVxdWlwby5zdGFydHNXaXRoKCdESVNQT05JQkxFJyk7XG4gICAgICByZXR1cm4gaGFzQnJlYWtlciB8fCBoYXNDb25kdWN0b3IgfHwgaGFzUmVhbE5hbWUgfHwgYy5mb3RvZ3JhZmlhIHx8IGMudGlwb0Rlc3Rpbm87XG4gICAgfTtcblxuICAgIGNvbnN0IHRhcmdldE9jY3VwaWVkID0gKHRhYmxlcm9EYXRhLmNpcmN1aXRzIHx8IFtdKS5maW5kKGMgPT4gYy5pZCAhPT0gY2lyY3VpdElkICYmIGMucG9sZXMuaW5jbHVkZXModGFyZ2V0UG9sZSkpO1xuICAgIGlmICh0YXJnZXRPY2N1cGllZCAmJiBpc09jY3VwaWVkQnlSZWFsQ2lyY3VpdCh0YXJnZXRPY2N1cGllZCkpIHtcbiAgICAgIHJlZ2lzdHJhckNvbmZsaWN0b0NpcmN1aXRvKHtcbiAgICAgICAgdGFibGVyb0lkOiB0YWJsZXJvRGF0YS5pZCxcbiAgICAgICAgdGFibGVyb05vbWJyZTogdGFibGVyb0RhdGEubm9tYnJlIHx8ICdUYWJsZXJvIEVsw6ljdHJpY28nLFxuICAgICAgICBlbXByZXNhSWQ6IHByb2plY3Q/LmVtcHJlc2FJZCB8fCBwcm9qZWN0Py5jb21wYW55SWQgfHwgdGFibGVyb0RhdGEuZW1wcmVzYUlkLFxuICAgICAgICBwcm95ZWN0b0lkOiBwcm9qZWN0Py5pZCB8fCB0YWJsZXJvRGF0YS5wcm95ZWN0b0lkLFxuICAgICAgICBwb2xvczogW3RhcmdldFBvbGVdLFxuICAgICAgICBjaXJjdWl0b0lkOiBjaXJjdWl0LmlkLFxuICAgICAgICBjaXJjdWl0b05vbWJyZTogY2lyY3VpdC5lcXVpcG8gfHwgYENpcmN1aXRvIFBvbG8gJHtjaXJjdWl0LnBvbGVzWzBdfWAsXG4gICAgICAgIGVxdWlwb0V4aXN0ZW50ZTogdGFyZ2V0T2NjdXBpZWQuZXF1aXBvLFxuICAgICAgICBlcXVpcG9OdWV2bzogY2lyY3VpdC5lcXVpcG8sXG4gICAgICAgIGRlc2NyaXBjaW9uOiBgVW5pw7NuIGRlIHBvbG9zIFske1suLi5jaXJjdWl0LnBvbGVzLCB0YXJnZXRQb2xlXS5qb2luKCcsICcpfV0gYWJzb3JiZSBlbCBwb2xvICR7dGFyZ2V0UG9sZX0gb2N1cGFkbyBwcmV2aWFtZW50ZSBwb3IgXCIke3RhcmdldE9jY3VwaWVkLmVxdWlwb31cIi5gLFxuICAgICAgICB0aXBvOiAnU09MQVBBTUlFTlRPX1BPTE9TJ1xuICAgICAgfSk7XG4gICAgICBzaG93VG9hc3QoYENvbmZsaWN0byBlbiBwb2xvICR7dGFyZ2V0UG9sZX0uIEluY2lkZW5jaWEgYWdyZWdhZGEgYSBsYSBjb2xhLmAsICd3YXJuaW5nJywge1xuICAgICAgICBsYWJlbDogJ1ZlciBDb25mbGljdG8nLFxuICAgICAgICBvbkNsaWNrOiAoKSA9PiBzZXRQYW5lbENvbmZsaWN0b3NPcGVuKHRydWUpXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zdCBuZXdEYXRhID0geyAuLi50YWJsZXJvRGF0YSB9O1xuICAgIGxldCBleGlzdGluZ0NpcmN1aXRzID0gWy4uLih0YWJsZXJvRGF0YS5jaXJjdWl0cyB8fCBbXSldO1xuICAgIFxuICAgIC8vIElmIHRoZSB0YXJnZXQgcG9sZSB3YXMgb2NjdXBpZWQgYnkgYW4gZW1wdHkgY3VzdG9tIGNpcmN1aXQsIGZpbHRlciBpdCBvdXQgdG8gYWJzb3JiIGl0XG4gICAgaWYgKHRhcmdldE9jY3VwaWVkKSB7XG4gICAgICBleGlzdGluZ0NpcmN1aXRzID0gZXhpc3RpbmdDaXJjdWl0cy5maWx0ZXIoYyA9PiBjLmlkICE9PSB0YXJnZXRPY2N1cGllZC5pZCk7XG4gICAgfVxuXG4gICAgY29uc3QgdGFyZ2V0Q2lyY3VpdCA9IGV4aXN0aW5nQ2lyY3VpdHMuZmluZChjID0+IGMuaWQgPT09IGNpcmN1aXRJZCk7XG4gICAgY29uc3QgbmV3UG9sZXMgPSBbLi4uY2lyY3VpdC5wb2xlcywgdGFyZ2V0UG9sZV0uc29ydCgoYSwgYikgPT4gYSAtIGIpO1xuXG4gICAgaWYgKHRhcmdldENpcmN1aXQpIHtcbiAgICAgIG5ld0RhdGEuY2lyY3VpdHMgPSBleGlzdGluZ0NpcmN1aXRzLm1hcChjID0+IHtcbiAgICAgICAgaWYgKGMuaWQgPT09IGNpcmN1aXRJZCkge1xuICAgICAgICAgIHJldHVybiB7IC4uLmMsIHBvbGVzOiBuZXdQb2xlcywgbnVtUG9sb3M6IG5ld1BvbGVzLmxlbmd0aCB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5ld0RhdGEuY2lyY3VpdHMgPSBbXG4gICAgICAgIC4uLmV4aXN0aW5nQ2lyY3VpdHMsXG4gICAgICAgIHtcbiAgICAgICAgICBpZDogYGNpcmNfJHtEYXRlLm5vdygpfV8ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cigyLCA1KX1gLFxuICAgICAgICAgIHNpZGU6IGNpcmN1aXQuc2lkZSxcbiAgICAgICAgICBwb2xlczogbmV3UG9sZXMsXG4gICAgICAgICAgbnVtUG9sb3M6IG5ld1BvbGVzLmxlbmd0aCxcbiAgICAgICAgICBlcXVpcG86IGNpcmN1aXQuZXF1aXBvIHx8ICdSRVNFUlZBJyxcbiAgICAgICAgICBicmVha2VyOiBjaXJjdWl0LmJyZWFrZXIgfHwgeyBtYXJjYTogJycsIHRpcG86ICcnLCBhbXA6ICcnIH0sXG4gICAgICAgICAgY29uZHVjdG9yOiBjaXJjdWl0LmNvbmR1Y3RvciB8fCAnJyxcbiAgICAgICAgfVxuICAgICAgXTtcbiAgICB9XG5cbiAgICBvblVwZGF0ZVRhYmxlcm8obmV3RGF0YSk7XG4gIH07XG5cbiAgLy8gU3BsaXQgYSBtdWx0aS1wb2xlIGNpcmN1aXQ6IHByZXNlcnZlcyB0aGUgcHJpbWFyeSBjaXJjdWl0IG9uIG1pblBvbGUgYW5kIHJlbGVhc2VzIGpvaW5lZCBwb2xlc1xuICBjb25zdCBzcGxpdENpcmN1aXQgPSAoY2lyY3VpdElkKSA9PiB7XG4gICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgY29uc3QgY2lyY3VpdCA9IG5vcm1hbGl6ZWRDaXJjdWl0cy5maW5kKGMgPT4gYy5pZCA9PT0gY2lyY3VpdElkKTtcbiAgICBjb25zdCBuZXdEYXRhID0geyAuLi50YWJsZXJvRGF0YSB9O1xuXG4gICAgaWYgKGNpcmN1aXQgJiYgQXJyYXkuaXNBcnJheShjaXJjdWl0LnBvbGVzKSAmJiBjaXJjdWl0LnBvbGVzLmxlbmd0aCA+IDEpIHtcbiAgICAgIGNvbnN0IG1pblBvbGUgPSBNYXRoLm1pbiguLi5jaXJjdWl0LnBvbGVzKTtcbiAgICAgIGNvbnN0IGlzQ3VzdG9tSWQgPSAhY2lyY3VpdC5pZC5zdGFydHNXaXRoKCdhdXRvXycpO1xuXG4gICAgICBpZiAoaXNDdXN0b21JZCkge1xuICAgICAgICBuZXdEYXRhLmNpcmN1aXRzID0gKHRhYmxlcm9EYXRhLmNpcmN1aXRzIHx8IFtdKS5tYXAoYyA9PiB7XG4gICAgICAgICAgaWYgKGMuaWQgPT09IGNpcmN1aXRJZCkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgLi4uYyxcbiAgICAgICAgICAgICAgcG9sZXM6IFttaW5Qb2xlXSxcbiAgICAgICAgICAgICAgbnVtUG9sb3M6IDEsXG4gICAgICAgICAgICAgIHBvc2ljaW9uUG9sbzogbWluUG9sZVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGM7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmV3RGF0YS5jaXJjdWl0cyA9ICh0YWJsZXJvRGF0YS5jaXJjdWl0cyB8fCBbXSkuZmlsdGVyKGMgPT4gYy5pZCAhPT0gY2lyY3VpdElkKTtcbiAgICAgIH1cblxuICAgICAgc2hvd1RvYXN0KGBDaXJjdWl0byBkZXNhY29wbGFkby4gU2UgY29uc2VydmFyb24gbG9zIGRhdG9zIGVuIGVsIHBvbG8gcHJpbmNpcGFsICR7bWluUG9sZX0uYCwgJ2luZm8nKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbmV3RGF0YS5jaXJjdWl0cyA9ICh0YWJsZXJvRGF0YS5jaXJjdWl0cyB8fCBbXSkuZmlsdGVyKGMgPT4gYy5pZCAhPT0gY2lyY3VpdElkKTtcbiAgICB9XG5cbiAgICBvblVwZGF0ZVRhYmxlcm8obmV3RGF0YSk7XG4gIH07XG5cbiAgLy8gU3BsaXQgcmVuZGVyaW5nIHJvd3MgaW50byBsZWZ0IChvZGQpIGFuZCByaWdodCAoZXZlbikgcG9sZXNcbiAgY29uc3Qgb2RkUG9sZXMgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBNYXRoLmNlaWwobWF4UG9sZXMgLyAyKSB9LCAoXywgaSkgPT4gMiAqIGkgKyAxKTtcbiAgXG4gIC8vIEZpbmQgY2lyY3VpdCBieSBwb2xlIG51bWJlclxuICBjb25zdCBmaW5kQ2lyY3VpdEJ5UG9sZSA9IChwb2xlKSA9PiB7XG4gICAgcmV0dXJuIG5vcm1hbGl6ZWRDaXJjdWl0cy5maW5kKGMgPT4gYy5wb2xlcy5pbmNsdWRlcyhwb2xlKSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRXhwb3J0RFhGID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0YWJsZXJvSWQgPSB0YWJsZXJvRGF0YT8uaWQ7XG4gICAgICBpZiAoIXRhYmxlcm9JZCkge1xuICAgICAgICBjdXN0b21BbGVydChcIklEIGRlIHRhYmxlcm8gbm8gZGlzcG9uaWJsZS5cIik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHRva2VuID0gdXNlU3RvcmUuZ2V0U3RhdGUoKS50b2tlbiB8fCBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKTtcbiAgICAgIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgICAgIC4uLih0b2tlbiA/IHsgJ0F1dGhvcml6YXRpb24nOiBgQmVhcmVyICR7dG9rZW59YCB9IDoge30pXG4gICAgICB9O1xuXG4gICAgICBsZXQgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS90YWJsZXJvcy8ke3RhYmxlcm9JZH0vZHhmYCwgeyBoZWFkZXJzIH0pO1xuXG4gICAgICAvLyBGYWxsYmFjayBhIFBPU1QgY29uIGRhdG9zIGxvY2FsZXMgc2kgbGEgYsO6c3F1ZWRhIHBvciBJRCBlbiBsYSBCRCBwcmltYXJpYSBubyBsbyBsb2NhbGl6YVxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL3RhYmxlcm9zL2R4Zi9leHBvcnQtY3VzdG9tYCwge1xuICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgICAuLi5oZWFkZXJzXG4gICAgICAgICAgfSxcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHRhYmxlcm86IHRhYmxlcm9EYXRhIH0pXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgRXJyb3IgZW4gZWwgc2Vydmlkb3IgKEhUVFAgJHtyZXNwb25zZS5zdGF0dXN9KWApO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzcG9uc2UuYmxvYigpO1xuICAgICAgY29uc3QgdXJsID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgICAgYS5ocmVmID0gdXJsO1xuICAgICAgYS5kb3dubG9hZCA9IGB1bmlmaWxhcl8keyh0YWJsZXJvRGF0YS5ub21icmUgfHwgJ3RhYmxlcm8nKS5yZXBsYWNlKC9bXmEtekEtWjAtOV8tXS9nLCAnXycpLnRvTG93ZXJDYXNlKCl9LmR4ZmA7XG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xuICAgICAgYS5jbGljaygpO1xuICAgICAgd2luZG93LlVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbiAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoYSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBkZXNjYXJnYXIgRFhGOicsIGVycik7XG4gICAgICBjdXN0b21BbGVydCgnTm8gc2UgcHVkbyBkZXNjYXJnYXIgZWwgYXJjaGl2byBEWEY6ICcgKyBlcnIubWVzc2FnZSk7XG4gICAgfVxuICB9O1xuXG5cbiAgY29uc3QgaGFuZGxlUHJpbnRQREYgPSAoKSA9PiB7XG4gICAgd2luZG93LnByaW50KCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YHctZnVsbCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIHByaW50LWNhcmQgZm9udC1zYW5zIHNlbGVjdC10ZXh0ICR7cmVhZE9ubHkgPyAncG9pbnRlci1ldmVudHMtbm9uZSBvcGFjaXR5LTkwJyA6ICcnfWB9PlxuICAgICAgXG4gICAgICB7LyogVklTVEEgREUgRURJQ0nDk04gRU4gUEFOVEFMTEEgKE9DVUxUQSBFTiBJTVBSRVNJw5NOKSAqL31cbiAgICAgIDxkaXY+XG4gICAgICAgIHsvKiBHcmlsbGEgU3VwZXJpb3IgRGl2aWRpZGE6IFRhYmxhIGEgbGEgSXpxdWllcmRhLCBGb3RvIGEgbGEgRGVyZWNoYSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy00IHByaW50OmdyaWQtY29scy00IGdhcC00IG1iLTRcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBMYWRvIEl6cXVpZXJkbyAoMy80IGRlIGFuY2hvKTogVGFibGEgR2VuZXJhbCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0zIHByaW50OmNvbC1zcGFuLTNcIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlci1jb2xsYXBzZSBib3JkZXItMiBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXhzIHRhYmxlLWZpeGVkIG1iLTBcIj5cbiAgICAgICAgPHRib2R5PlxuICAgICAgICAgIHsvKiBGaWxhIDE6IFTDrXR1bG8gR2VuZXJhbCAqL31cbiAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwLzgwXCI+XG4gICAgICAgICAgICA8dGQgY29sU3Bhbj17N30gY2xhc3NOYW1lPVwicC0wIGZvbnQtYm9sZCB0ZXh0LXNtIHRyYWNraW5nLXdpZGVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgcHktMi41IHB4LTQgdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHctZnVsbFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwIGZpbGwtYW1iZXItNTAwLzIwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJsYWNrIHRyYWNraW5nLXdpZGUgdGV4dC14cyBzbTp0ZXh0LXNtXCI+SU5GT1JNQUNJw5NOIEdFTkVSQUwgREUgUEFORUwgRUzDiUNUUklDTyAvIFRBQkxFUk88L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBuby1wcmludFwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0RFhGfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0xIGJnLWN5YW4tNjAwLzIwIGhvdmVyOmJnLWN5YW4tNjAwLzMwIHRleHQtY3lhbi00MDAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC80MCByb3VuZGVkLWxnIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRlc2NhcmdhciBkaWFncmFtYSB1bmlmaWxhciBlbiBmb3JtYXRvIEF1dG9DQUQgRFhGXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+RGVzY2FyZ2FyIERYRjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJpbnRQREZ9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTEgYmctdmlvbGV0LTYwMC8yMCBob3ZlcjpiZy12aW9sZXQtNjAwLzMwIHRleHQtdmlvbGV0LTQwMCBib3JkZXIgYm9yZGVyLXZpb2xldC01MDAvNDAgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJJbXByaW1pciBvIGd1YXJkYXIgY29tbyBQREZcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkltcHJpbWlyIC8gUERGPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8L3RyPlxuXG4gICAgICAgICAgey8qIEZpbGEgMjogVWJpY2FjacOzbiAqL31cbiAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJ3LTI0IHAtMiBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCBmb250LXNlbWlib2xkIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICBVYmljYWNpw7NuOlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs2fSBjbGFzc05hbWU9XCJwLTAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgPEVkaXRhYmxlQ2VsbFxuICAgICAgICAgICAgICAgIHZhbHVlPXt1YmljYWNpb259XG4gICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVGaWVsZCgndWJpY2FjaW9uJywgdmFsKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkluZGlxdWUgbGEgdWJpY2FjacOzbiBmw61zaWNhIGRldGFsbGFkYSBkZWwgdGFibGVyby4uLlwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtM1wiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDwvdHI+XG5cbiAgICAgICAgICB7LyogRmlsYSAzOiBBbGltZW50YWRvIFBvciBKZXLDoXJxdWljbyBEaW7DoW1pY28gKi99XG4gICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwidy0yOCBwLTIuNSBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCBmb250LXNlbWlib2xkIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHVwcGVyY2FzZSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIEFsaW1lbnRhZG8gUG9yOlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs2fSBjbGFzc05hbWU9XCJwLTIuNSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICA8U2VsZWN0b3JBbGltZW50YWRvckplcmFycXVpY29cbiAgICAgICAgICAgICAgICBwcm95ZWN0b0lkPXtwcm9qZWN0Py5pZH1cbiAgICAgICAgICAgICAgICB0YWJsZXJvQWN0dWFsSWQ9e3RhYmxlcm9EYXRhPy5pZH1cbiAgICAgICAgICAgICAgICB2YWx1ZT17YWxpbWVudGFkb1Bvcn1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCwgc2VsZWN0ZWRPYmopID0+IHtcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZUZpZWxkKCdhbGltZW50YWRvUG9yJywgdmFsKTtcbiAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZE9iaj8udGlwb0VsZW1lbnRvID09PSAnQUxJTUVOVEFET1InKSB7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZpZWxkKCdkYXRvc1RlY25pY29zLmFsaW1lbnRhZG9ySWQnLCBzZWxlY3RlZE9iai5pZCk7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZVRhYmxlcm9BbGltZW50YWRvcihwcm9qZWN0Py5pZCwgdGFibGVyb0RhdGEuaWQsIHNlbGVjdGVkT2JqLmlkKTtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZpZWxkKCdkYXRvc1RlY25pY29zLmFsaW1lbnRhZG9ySWQnLCBzZWxlY3RlZE9iaj8uaWQgIT09ICdDVVNUT00nID8gKHNlbGVjdGVkT2JqPy5pZCB8fCBudWxsKSA6IG51bGwpO1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVUYWJsZXJvQWxpbWVudGFkb3IocHJvamVjdD8uaWQsIHRhYmxlcm9EYXRhLmlkLCBzZWxlY3RlZE9iaj8uaWQgIT09ICdDVVNUT00nID8gKHNlbGVjdGVkT2JqPy5pZCB8fCBudWxsKSA6IG51bGwpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgbGFiZWw9XCJcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWNjaW9uYXIgU3ViZXN0YWNpw7NuLCBUcmFuc2Zvcm1hZG9yLCBDQ00sIFRhYmxlcm8gbyBBY29tZXRpZGEuLi5cIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8L3RyPlxuXG4gICAgICAgICAgey8qIEZpbGEgT3BjaW9uYWw6IENhcGFjaWRhZCwgRmFzZXMgeSBUZW5zacOzbiAqL31cbiAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJ3LTI0IHAtMiBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCBmb250LXNlbWlib2xkIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICBQYXLDoW1ldHJvcyBQYW5lbDpcbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8dGQgY29sU3Bhbj17Nn0gY2xhc3NOYW1lPVwicC0yIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC02IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTkwMC82MCBwLTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgZm9udC1ib2xkIHNocmluay0wXCI+Q2FwYWNpZGFkIEdhYmluZXRlOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21heFBvbGVzfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlLCAxMCkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtYXhDaXJjUG9zaXRpb24gPSBjaXJjdWl0cy5yZWR1Y2UoKGFjYywgYykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbWF4VmFsID0gTWF0aC5tYXgoLi4uYy5wb2xlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbWF4VmFsID4gYWNjID8gbWF4VmFsIDogYWNjO1xuICAgICAgICAgICAgICAgICAgICAgIH0sIDApO1xuICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWwgPCBtYXhDaXJjUG9zaXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RvbUFsZXJ0KGBObyBzZSBwdWVkZSByZWR1Y2lyIGxhIGNhcGFjaWRhZCBhICR7dmFsfSBwb2xvcyBwb3JxdWUgaGF5IGNpcmN1aXRvcyBvY3VwYW5kbyBwb3NpY2lvbmVzIGhhc3RhIGVsIHBvbG8gJHttYXhDaXJjUG9zaXRpb259LmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGaWVsZCgnbWF4UG9sZXMnLCB2YWwpO1xuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtYW1iZXItNDAwIGZvbnQtYm9sZCBib3JkZXItbm9uZSB0ZXh0LVsxMXB4XSBmb2N1czpvdXRsaW5lLW5vbmUgdy0xMCB0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bWF4UG9sZXN9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkT25seX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsID0gcGFyc2VJbnQoZS50YXJnZXQudmFsdWUsIDEwKTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoIXZhbCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG1heENpcmNQb3NpdGlvbiA9IGNpcmN1aXRzLnJlZHVjZSgoYWNjLCBjKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtYXhWYWwgPSBNYXRoLm1heCguLi5jLnBvbGVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBtYXhWYWwgPiBhY2MgPyBtYXhWYWwgOiBhY2M7XG4gICAgICAgICAgICAgICAgICAgICAgfSwgMCk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbCA8IG1heENpcmNQb3NpdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY3VzdG9tQWxlcnQoYE5vIHNlIHB1ZWRlIHJlZHVjaXIgbGEgY2FwYWNpZGFkIGEgJHt2YWx9IHBvbG9zIHBvcnF1ZSBoYXkgY2lyY3VpdG9zIG9jdXBhbmRvIHBvc2ljaW9uZXMgaGFzdGEgZWwgcG9sbyAke21heENpcmNQb3NpdGlvbn0uYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZpZWxkKCdtYXhQb2xlcycsIHZhbCk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW0gYm9yZGVyLW5vbmUgdGV4dC1bMTBweF0gZm9jdXM6b3V0bGluZS1ub25lIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTEwMFwiPi0tIEVzdMOhbmRhciAtLTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICB7WzEyLCAyNCwgMzAsIDQyLCA0OCwgNjAsIDcyLCA4NCwgOTZdLm1hcChvcHQgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtvcHR9IHZhbHVlPXtvcHR9IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTEwMFwiPntvcHR9IFBvbG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIGZvbnQtYm9sZFwiPkZhc2VzOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhYmxlcm9EYXRhLmZhc2VzICE9PSB1bmRlZmluZWQgPyB0YWJsZXJvRGF0YS5mYXNlcyA6IDN9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ2Zhc2VzJywgcGFyc2VJbnQoZS50YXJnZXQudmFsdWUsIDEwKSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIGJvcmRlci1ub25lIHRleHQtWzExcHhdIGZvY3VzOm91dGxpbmUtbm9uZSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtbMSwgMiwgM10ubWFwKG9wdCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e29wdH0gdmFsdWU9e29wdH0gY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMTAwXCI+e29wdH0gRmFzZShzKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LWJvbGRcIj5UZW5zacOzbiBOb21pbmFsIChDT1ZFTklOIDE1OSk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgbGlzdD1cImNvdmVuaW4tdm9sdGFqZXMtdGFibGVyb1wiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0YWJsZXJvRGF0YS50ZW5zaW9uIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ3RlbnNpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWo6IDEyMC8yMDggViAoM86mIC0gNCBoaWxvcylcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtYW1iZXItNDAwIGZvbnQtYm9sZCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTAuNSB0ZXh0LVsxMXB4XSBmb2N1czpvdXRsaW5lLW5vbmUgdy01NiBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxkYXRhbGlzdCBpZD1cImNvdmVuaW4tdm9sdGFqZXMtdGFibGVyb1wiPlxuICAgICAgICAgICAgICAgICAgICB7VEVOU0lPTkVTX0NPVkVOSU5fMTU5X0JULm1hcCh2ID0+IDxvcHRpb24ga2V5PXt2fSB2YWx1ZT17dn0+e3Z9PC9vcHRpb24+KX1cbiAgICAgICAgICAgICAgICAgIDwvZGF0YWxpc3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8L3RyPlxuXG4gICAgICAgICAgey8qIEZpbGEgNDogRW5jYWJlemFkb3MgZGUgUGFyw6FtZXRyb3MgKi99XG4gICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtY2VudGVyIGZvbnQtc2VtaWJvbGQgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjBcIj5cbiAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXsyfSBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTEgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICAgIEJhcnJhcyBQcmluY2lwYWxlc1xuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXszfSBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTAgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTIgcHktMSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XVwiPlRpcG8gZGUgVGFibGVybzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBjdXJzb3ItcG9pbnRlciBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxuICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RpcG8gPT09ICdzdXBlcmZpY2lhbCd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHVwZGF0ZUZpZWxkKCd0aXBvJywgJ3N1cGVyZmljaWFsJyl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWNjZW50LWFtYmVyLTUwMCB3LTMgaC0zIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXt0aXBvID09PSAnc3VwZXJmaWNpYWwnID8gJ2ZvbnQtYm9sZCB0ZXh0LWFtYmVyLTUwMCcgOiAnJ30+U3VwZXJmaWNpYWw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGN1cnNvci1wb2ludGVyIHNlbGVjdC1ub25lXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGlwbyA9PT0gJ2VtcG90cmFkbyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHVwZGF0ZUZpZWxkKCd0aXBvJywgJ2VtcG90cmFkbycpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFjY2VudC1hbWJlci01MDAgdy0zIGgtMyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dGlwbyA9PT0gJ2VtcG90cmFkbycgPyAnZm9udC1ib2xkIHRleHQtYW1iZXItNTAwJyA6ICcnfT5FbXBvdHJhZG88L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xXCI+QlJFQUtFUiBQUklOQ0lQQUw8L2Rpdj5cbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcC0xIHVwcGVyY2FzZSB3LTIwXCI+XG4gICAgICAgICAgICAgIFZvbHRhamVcbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0xIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICBBY29tZXRpZGFcbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgPC90cj5cblxuICAgICAgICAgIHsvKiBGaWxhIDU6IFN1Yi1lbmNhYmV6YWRvcyBkZSBCcmVha2VyICovfVxuICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC1bMTBweF0gYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwLzgwXCI+XG4gICAgICAgICAgICA8dGQgY29sU3Bhbj17Mn0gY2xhc3NOYW1lPVwiYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcC0wLjVcIj5GQVNFIC8gQU1QRVJJT1M8L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMC41IHctMjRcIj5NQVJDQTwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcC0wLjUgdy0yMFwiPlRJUE88L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMC41IHctMjBcIj5BTVA8L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMC41XCI+Vi1GQVNFPC90ZD5cbiAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTAuNVwiPkNBTElCUkUvREVUQUxMRVM8L3RkPlxuICAgICAgICAgIDwvdHI+XG5cbiAgICAgICAgICB7LyogRmlsYSA2IChJQSkgKi99XG4gICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwidy0xMiB0ZXh0LWNlbnRlciBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC8zMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBmb250LWJvbGQgZm9udC1tb25vXCI+SUE8L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInctMjAgcC0wIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17YmFycmFzUHJpbmNpcGFsZXMuaWF9XG4gICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVGaWVsZCgnYmFycmFzUHJpbmNpcGFsZXMuaWEnLCB2YWwpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICB7LyogQnJlYWtlciBQcmluY2lwYWwgTWFyY2EgKHNwYW5zIDMgcm93cykgKi99XG4gICAgICAgICAgICA8dGQgcm93U3Bhbj17M30gY2xhc3NOYW1lPVwicC0wIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtY2VudGVyIGFsaWduLW1pZGRsZSBmb250LW1lZGl1bSBiZy1hbWJlci01MDAvNVwiPlxuICAgICAgICAgICAgICA8RWRpdGFibGVDZWxsXG4gICAgICAgICAgICAgICAgdmFsdWU9e2JyZWFrZXJQcmluY2lwYWwubWFyY2F9XG4gICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVGaWVsZCgnYnJlYWtlclByaW5jaXBhbC5tYXJjYScsIHZhbCl9XG4gICAgICAgICAgICAgICAgdHlwZT1cInNlbGVjdFwiXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17TUFSQ0FfT1BUSU9OU31cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1hcmNhXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgIHsvKiBCcmVha2VyIFByaW5jaXBhbCBUaXBvIChzcGFucyAzIHJvd3MpICovfVxuICAgICAgICAgICAgPHRkIHJvd1NwYW49ezN9IGNsYXNzTmFtZT1cInAtMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LWNlbnRlciBhbGlnbi1taWRkbGUgYmctYW1iZXItNTAwLzVcIj5cbiAgICAgICAgICAgICAgPEVkaXRhYmxlQ2VsbFxuICAgICAgICAgICAgICAgIHZhbHVlPXticmVha2VyUHJpbmNpcGFsLnRpcG99XG4gICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVGaWVsZCgnYnJlYWtlclByaW5jaXBhbC50aXBvJywgdmFsKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlRpcG9cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICB7LyogQnJlYWtlciBQcmluY2lwYWwgQW1wIChzcGFucyAzIHJvd3MpICovfVxuICAgICAgICAgICAgPHRkIHJvd1NwYW49ezN9IGNsYXNzTmFtZT1cInAtMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LWNlbnRlciBhbGlnbi1taWRkbGUgZm9udC1ib2xkIGJnLWFtYmVyLTUwMC81XCI+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17YnJlYWtlclByaW5jaXBhbC5hbXB9XG4gICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVGaWVsZCgnYnJlYWtlclByaW5jaXBhbC5hbXAnLCB2YWwpfVxuICAgICAgICAgICAgICAgIHR5cGU9XCJzZWxlY3RcIlxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e0FNUF9PUFRJT05TfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQW1wXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmb250LW1vbm8gdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMCBib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8RWRpdGFibGVDZWxsXG4gICAgICAgICAgICAgICAgdmFsdWU9e3ZvbHRhamUudmF9XG4gICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVGaWVsZCgndm9sdGFqZS52YScsIHZhbCl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgIHsvKiBBY29tZXRpZGEgKHNwYW5zIDMgcm93cykgKi99XG4gICAgICAgICAgICA8dGQgcm93U3Bhbj17M30gY2xhc3NOYW1lPVwicC0wIHRleHQtY2VudGVyIGFsaWduLW1pZGRsZSBmb250LW1lZGl1bSBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTkwMC8zMFwiPlxuICAgICAgICAgICAgICA8RWRpdGFibGVDZWxsXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Fjb21ldGlkYX1cbiAgICAgICAgICAgICAgICBvblNhdmU9eyh2YWwpID0+IHVwZGF0ZUZpZWxkKCdhY29tZXRpZGEnLCB2YWwpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiM1ggMy8wLi4uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmb250LW1vbm8gdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtYmx1ZS00MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8L3RyPlxuXG4gICAgICAgICAgey8qIEZpbGEgNyAoSUIpICovfVxuICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzMwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGZvbnQtYm9sZCBmb250LW1vbm9cIj5JQjwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0wIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17YmFycmFzUHJpbmNpcGFsZXMuaWJ9XG4gICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVGaWVsZCgnYmFycmFzUHJpbmNpcGFsZXMuaWInLCB2YWwpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0wIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17dm9sdGFqZS52Yn1cbiAgICAgICAgICAgICAgICBvblNhdmU9eyh2YWwpID0+IHVwZGF0ZUZpZWxkKCd2b2x0YWplLnZiJywgdmFsKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDwvdHI+XG5cbiAgICAgICAgICB7LyogRmlsYSA4IChJQykgKi99XG4gICAgICAgICAgPHRyPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzMwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGZvbnQtYm9sZCBmb250LW1vbm9cIj5JQzwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0wIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17YmFycmFzUHJpbmNpcGFsZXMuaWN9XG4gICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVGaWVsZCgnYmFycmFzUHJpbmNpcGFsZXMuaWMnLCB2YWwpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0wIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17dm9sdGFqZS52Y31cbiAgICAgICAgICAgICAgICBvblNhdmU9eyh2YWwpID0+IHVwZGF0ZUZpZWxkKCd2b2x0YWplLnZjJywgdmFsKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDwvdHI+XG4gICAgICAgIDwvdGJvZHk+XG4gICAgICA8L3RhYmxlPlxuICAgIDwvZGl2PlxuXG4gICAgey8qIExhZG8gRGVyZWNobyAoMS80IGRlIGFuY2hvKTogRm90byBkZSBJbnNwZWNjacOzbiAqL31cbiAgICA8ZGl2IFxuICAgICAgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMSBwcmludDpjb2wtc3Bhbi0xIGJvcmRlci0yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTk1MC80MCByb3VuZGVkLWxnIHAtMyBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBoLWZ1bGxcIlxuICAgICAgc3R5bGU9e3sgbWluSGVpZ2h0OiBgJHt0YWJsZXJvRGF0YS5mb3RvU2NhbGUgfHwgMjIwfXB4YCB9fVxuICAgID5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTJcIj5cbiAgICAgICAgICA8Q2FtZXJhIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNTAwXCIgLz5cbiAgICAgICAgICA8c3Bhbj5Gb3RvIGRlIEluc3BlY2Npw7NuPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgXG4gICAgICAgIHtmb3RvQmxvYiB8fCBmb3RvID8gKFxuICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSByb3VuZGVkIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS05MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ3JvdXAgc2hhZG93IHctZnVsbFwiXG4gICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IGAke3RhYmxlcm9EYXRhLmZvdG9TY2FsZSB8fCAyMjB9cHhgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNhZmVJbWFnZSBcbiAgICAgICAgICAgICAgYmxvYj17Zm90b0Jsb2J9IFxuICAgICAgICAgICAgICBzcmM9e2ZvdG99IFxuICAgICAgICAgICAgICBhbHQ9XCJJbnNwZWNjacOzbiBkZWwgdGFibGVyb1wiIFxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIFxuICAgICAgICAgICAgICBzdHlsZT17eyBtYXhIZWlnaHQ6IGAke3RhYmxlcm9EYXRhLmZvdG9TY2FsZSB8fCAyMjB9cHhgIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIG9uVXBkYXRlVGFibGVybyh7XG4gICAgICAgICAgICAgICAgICAuLi50YWJsZXJvRGF0YSxcbiAgICAgICAgICAgICAgICAgIGZvdG9CbG9iOiBudWxsLFxuICAgICAgICAgICAgICAgICAgZm90bzogbnVsbFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJuby1wcmludCBhYnNvbHV0ZSB0b3AtMSByaWdodC0xIHAtMSBiZy1yZWQtNjAwIGhvdmVyOmJnLXJlZC01MDAgdGV4dC13aGl0ZSByb3VuZGVkIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzIHNoYWRvd1wiXG4gICAgICAgICAgICAgIHRpdGxlPVwiRWxpbWluYXIgZm90b1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHAtMVwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgdy1mdWxsIHB5LTIuNSBweC0zIGJnLWFtYmVyLTUwMC8xNSBob3ZlcjpiZy1hbWJlci01MDAvMjUgdGV4dC1hbWJlci0zMDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvNDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCBhY3RpdmU6c2NhbGUtOTUgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkPDoW1hcmEgZW4gVml2bzwvc3Bhbj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxuICAgICAgICAgICAgICAgIGNhcHR1cmU9XCJlbnZpcm9ubWVudFwiXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXNbMF07XG4gICAgICAgICAgICAgICAgICBpZiAoIWZpbGUpIHJldHVybjtcbiAgICAgICAgICAgICAgICAgIGlmIChmaWxlLnNpemUgPiAxMCAqIDEwMjQgKiAxMDI0KSB7XG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbUFsZXJ0KFwiTGEgaW1hZ2VuIGVzIGRlbWFzaWFkbyBncmFuZGUuIE3DoXhpbW8gMTBNQi5cIik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIG9uVXBkYXRlVGFibGVybyh7XG4gICAgICAgICAgICAgICAgICAgIC4uLnRhYmxlcm9EYXRhLFxuICAgICAgICAgICAgICAgICAgICBmb3RvQmxvYjogZmlsZSxcbiAgICAgICAgICAgICAgICAgICAgZm90bzogbnVsbFxuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHctZnVsbCBweS0yLjUgcHgtMyBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGJvcmRlciBib3JkZXItc2xhdGUtNzUwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsIGFjdGl2ZTpzY2FsZS05NVwiPlxuICAgICAgICAgICAgICA8SW1hZ2UgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkdhbGVyw61hIC8gQXJjaGl2b3M8L3NwYW4+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlc1swXTtcbiAgICAgICAgICAgICAgICAgIGlmICghZmlsZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgaWYgKGZpbGUuc2l6ZSA+IDEwICogMTAyNCAqIDEwMjQpIHtcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tQWxlcnQoXCJMYSBpbWFnZW4gZXMgZGVtYXNpYWRvIGdyYW5kZS4gTcOheGltbyAxME1CLlwiKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgb25VcGRhdGVUYWJsZXJvKHtcbiAgICAgICAgICAgICAgICAgICAgLi4udGFibGVyb0RhdGEsXG4gICAgICAgICAgICAgICAgICAgIGZvdG9CbG9iOiBmaWxlLFxuICAgICAgICAgICAgICAgICAgICBmb3RvOiBudWxsXG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBTbGlkZXIgZGUgYWp1c3RlIGRlIHRhbWHDsW8gKHNvbG8gdmlzaWJsZSBzaSBoYXkgZm90byB5IGVuIHBhbnRhbGxhKSAqL31cbiAgICAgICAgeyhmb3RvQmxvYiB8fCBmb3RvKSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuby1wcmludCBtdC0zIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTg1MCBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICAgIDxzcGFuPkFqdXN0YXIgdGFtYcOxbyBlbiBQREY8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYW1iZXItNTAwIGZvbnQtbW9ub1wiPnt0YWJsZXJvRGF0YS5mb3RvU2NhbGUgfHwgMjIwfXB4PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgbWluPVwiMTIwXCJcbiAgICAgICAgICAgICAgbWF4PVwiMzUwXCJcbiAgICAgICAgICAgICAgdmFsdWU9e3RhYmxlcm9EYXRhLmZvdG9TY2FsZSB8fCAyMjB9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ2ZvdG9TY2FsZScsIHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEgYmctc2xhdGUtODUwIHJvdW5kZWQtbGcgYXBwZWFyYW5jZS1ub25lIGN1cnNvci1wb2ludGVyIGFjY2VudC1hbWJlci01MDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgICAgXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1zbGF0ZS01MDAgbXQtMiBsZWFkaW5nLXJlbGF4ZWQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMCBwdC0yIG5vLXByaW50XCI+XG4gICAgICAgIFN1YmUgbyBjYXB0dXJhIGxhIGZvdG8gZGVsIGNhYmxlYWRvL2dhYmluZXRlIHBhcmEgZG9jdW1lbnRhciBlbCB0YWJsZXJvLlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG5cbiAgPC9kaXY+XG5cbiAgICAgIHsvKiAyLiBHUklEIERFIENJUkNVSVRPUyAoU0lNRVRSw41BIENPTVBMRVRBKSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyLWNvbGxhcHNlIGJvcmRlci0yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJvcmRlci10LTAgdGV4dC1bMTBweF0gbWQ6dGV4dC1bMTFweF0gdGFibGUtZml4ZWQgbWluLXctWzc1MHB4XVwiPlxuICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgIHsvKiBFbmNhYmV6YWRvIE5pdmVsIDEgKi99XG4gICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtY2VudGVyIGZvbnQtYm9sZCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDx0aCByb3dTcGFuPXsyfSBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTIgdy1bMjIlXVwiPkVRVUlQTyBRVUUgQUxJTUVOVEE8L3RoPlxuICAgICAgICAgICAgICA8dGggY29sU3Bhbj17M30gY2xhc3NOYW1lPVwiYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcC0xXCI+UFJPVEVDQ0nDk04gKEJSRUFLRVIpPC90aD5cbiAgICAgICAgICAgICAgPHRoIHJvd1NwYW49ezJ9IGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMiB3LVs4JV1cIj5DT05ELjwvdGg+XG4gICAgICAgICAgICAgIDx0aCByb3dTcGFuPXsyfSBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItMiBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTIgdy1bNCVdIGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1jZW50ZXJcIj4jPC90aD5cbiAgICAgICAgICAgICAgPHRoIHJvd1NwYW49ezJ9IGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMiB3LVs0JV0gYmctYW1iZXItNTAwLzEwIHRleHQtYW1iZXItNjAwIGRhcms6dGV4dC1hbWJlci00MDAgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWNlbnRlclwiPiM8L3RoPlxuICAgICAgICAgICAgICA8dGggcm93U3Bhbj17Mn0gY2xhc3NOYW1lPVwiYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcC0yIHctWzglXVwiPkNPTkQuPC90aD5cbiAgICAgICAgICAgICAgPHRoIGNvbFNwYW49ezN9IGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMVwiPlBST1RFQ0NJw5NOIChCUkVBS0VSKTwvdGg+XG4gICAgICAgICAgICAgIDx0aCByb3dTcGFuPXsyfSBjbGFzc05hbWU9XCJwLTIgdy1bMjIlXVwiPkVRVUlQTyBRVUUgQUxJTUVOVEE8L3RoPlxuICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIHsvKiBFbmNhYmV6YWRvIE5pdmVsIDIgKi99XG4gICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgdGV4dC1jZW50ZXIgZm9udC1ib2xkIHRleHQtWzlweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgIHsvKiBMZWZ0IEJyZWFrZXIgc3ViaGVhZGVycyAqL31cbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMSB3LVs4JV1cIj5NQVJDQTwvdGg+XG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTEgdy1bNyVdXCI+VElQTzwvdGg+XG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTEgdy1bNiVdXCI+QU1QLjwvdGg+XG4gICAgICAgICAgICAgIHsvKiBSaWdodCBCcmVha2VyIHN1YmhlYWRlcnMgKEFNUC4sIFRJUE8sIE1BUkNBIGZvciBzeW1tZXRyeSkgKi99XG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTEgdy1bNiVdXCI+QU1QLjwvdGg+XG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTEgdy1bNyVdXCI+VElQTzwvdGg+XG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTEgdy1bOCVdXCI+TUFSQ0E8L3RoPlxuICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgIHtvZGRQb2xlcy5tYXAoKG9kZFBvbGUsIHJvd0luZGV4KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGV2ZW5Qb2xlID0gb2RkUG9sZSArIDE7XG5cbiAgICAgICAgICAgICAgLy8gRmluZCBjaXJjdWl0IHJlcHJlc2VudGluZyB0aGUgY3VycmVudCBsZWZ0IChvZGQpIGFuZCByaWdodCAoZXZlbikgcG9sZXNcbiAgICAgICAgICAgICAgY29uc3QgY0xlZnQgPSBmaW5kQ2lyY3VpdEJ5UG9sZShvZGRQb2xlKTtcbiAgICAgICAgICAgICAgY29uc3QgY1JpZ2h0ID0gZmluZENpcmN1aXRCeVBvbGUoZXZlblBvbGUpO1xuXG4gICAgICAgICAgICAgIC8vIERldGVybWluZSBpZiB0aGlzIGlzIHRoZSBmaXJzdCBwb2xlIG9mIGEgbXVsdGktcG9sZSBncm91cCB0byBhcHBseSByb3dTcGFuXG4gICAgICAgICAgICAgIGNvbnN0IGlzRmlyc3RMZWZ0ID0gY0xlZnQgJiYgTWF0aC5taW4oLi4uY0xlZnQucG9sZXMpID09PSBvZGRQb2xlO1xuICAgICAgICAgICAgICBjb25zdCBpc0ZpcnN0UmlnaHQgPSBjUmlnaHQgJiYgTWF0aC5taW4oLi4uY1JpZ2h0LnBvbGVzKSA9PT0gZXZlblBvbGU7XG5cbiAgICAgICAgICAgICAgLy8gQ2FsY3VsYXRlIHJvd1NwYW4gY291bnRzXG4gICAgICAgICAgICAgIGNvbnN0IHJvd1NwYW5MZWZ0ID0gY0xlZnQgPyBjTGVmdC5wb2xlcy5sZW5ndGggOiAxO1xuICAgICAgICAgICAgICBjb25zdCByb3dTcGFuUmlnaHQgPSBjUmlnaHQgPyBjUmlnaHQucG9sZXMubGVuZ3RoIDogMTtcblxuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDx0clxuICAgICAgICAgICAgICAgICAga2V5PXtyb3dJbmRleH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJnLXNsYXRlLTUwLzIwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzEwIG1pbi1oLVszMnB4XVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgey8qID09PSBMQURPIElaUVVJRVJETyAoSU1QQVIpID09PSAqL31cbiAgICAgICAgICAgICAgICAgIHtpc0ZpcnN0TGVmdCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgey8qIEVxdWlwbyBxdWUgQWxpbWVudGEgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dTcGFuPXtyb3dTcGFuTGVmdH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMS41IGZvbnQtbWVkaXVtIGFsaWduLW1pZGRsZSBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNTAgdHJhbnNpdGlvbi1jb2xvcnMgcmVsYXRpdmUgZ3JvdXAvY2VsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFZGl0aW5nQ2lyY3VpdChjTGVmdCl9XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIG1pbi1oLVsycmVtXSBwci02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlckNpcmN1aXRFcXVpcG8oY0xlZnQuZXF1aXBvLCBjTGVmdC52aW5jdWxhZG9JZCwgY0xlZnQuZWxlbWVudG9EZXN0aW5vSWQsIGNMZWZ0LnRpcG9EZXN0aW5vLCBjTGVmdC50aXBvRWxlbWVudG9EZXN0aW5vKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y0xlZnQuZm90b2dyYWZpYSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2UgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci01MDAgc2hyaW5rLTAgbWwtMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQmFkZ2VzIGJhc2VkIG9uIHRpcG9EZXN0aW5vIC8gdGlwb0VsZW1lbnRvRGVzdGlubyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlclRpcG9EZXN0aW5vQmFkZ2UoY0xlZnQudGlwb0Rlc3Rpbm8sIGNMZWZ0LnRpcG9FbGVtZW50b0Rlc3Rpbm8pfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cm93U3BhbkxlZnQgPiAxICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3BsaXRDaXJjdWl0KGNMZWZ0LmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU2VwYXJhciBQb2xvc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibm8tcHJpbnQgYWJzb2x1dGUgcmlnaHQtMSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgcC0wLjUgb3BhY2l0eS04MCBob3ZlcjpvcGFjaXR5LTEwMCBiZy1yZWQtNTAwIGhvdmVyOmJnLXJlZC02MDAgdGV4dC13aGl0ZSByb3VuZGVkIGN1cnNvci1wb2ludGVyIHNoYWRvdy1zbSB0cmFuc2l0aW9uLW9wYWNpdHkgei0xMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWludXMgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEJyZWFrZXIgTWFyY2EgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dTcGFuPXtyb3dTcGFuTGVmdH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMCB0ZXh0LWNlbnRlciBhbGlnbi1taWRkbGVcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NMZWZ0LmJyZWFrZXIubWFyY2F9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2F2ZT17KHZhbCkgPT4gdXBkYXRlQ2lyY3VpdChjTGVmdC5pZCwgJ2JyZWFrZXIubWFyY2EnLCB2YWwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2VsZWN0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17TUFSQ0FfT1BUSU9OU31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmb250LWJvbGQgZm9udC1zYW5zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBCcmVha2VyIFRpcG8gKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dTcGFuPXtyb3dTcGFuTGVmdH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMCB0ZXh0LWNlbnRlciBhbGlnbi1taWRkbGVcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NMZWZ0LmJyZWFrZXIudGlwb31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVDaXJjdWl0KGNMZWZ0LmlkLCAnYnJlYWtlci50aXBvJywgdmFsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInNlbGVjdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1RJUE9fT1BUSU9OU31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQnJlYWtlciBBbXAgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dTcGFuPXtyb3dTcGFuTGVmdH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMCB0ZXh0LWNlbnRlciBhbGlnbi1taWRkbGUgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RWRpdGFibGVDZWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjTGVmdC5icmVha2VyLmFtcH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVDaXJjdWl0KGNMZWZ0LmlkLCAnYnJlYWtlci5hbXAnLCB2YWwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2VsZWN0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17QU1QX09QVElPTlN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZm9udC1tb25vIHRleHQtYW1iZXItNjAwIGRhcms6dGV4dC1hbWJlci00MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIENvbmR1Y3RvciBjYWxpYnJlICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZFxuICAgICAgICAgICAgICAgICAgICAgICAgcm93U3Bhbj17cm93U3BhbkxlZnR9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTAgdGV4dC1jZW50ZXIgYWxpZ24tbWlkZGxlIGZvbnQtbWVkaXVtXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RWRpdGFibGVDZWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjTGVmdC5jb25kdWN0b3J9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uU2F2ZT17KHZhbCkgPT4gdXBkYXRlQ2lyY3VpdChjTGVmdC5pZCwgJ2NvbmR1Y3RvcicsIHZhbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzZWxlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtDT05EX09QVElPTlN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZm9udC1tb25vIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBOw7ptZXJvIGRlIFBvbG8gSW1wYXIgKEJhcnJhIENvbGVjdG9yYSBGw61zaWNhIEZpamEpICovfVxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlci1yLTIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcC0wIHRleHQtY2VudGVyIGZvbnQtbW9ubyBmb250LWJvbGQgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwLzgwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYWxpZ24tbWlkZGxlIHNlbGVjdC1ub25lIHJlbGF0aXZlIGdyb3VwL3BvbGUgY3Vyc29yLWRlZmF1bHRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1bMS43NXJlbV0gcHgtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgc2VsZWN0LW5vbmVcIj57b2RkUG9sZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgey8qIEludGVyYWN0aXZlIEdyb3VwIENvbnRyb2wgKi99XG4gICAgICAgICAgICAgICAgICAgICAge29kZFBvbGUgPCBtYXhQb2xlcyAtIDEgJiYgaXNGaXJzdExlZnQgJiYgcm93U3BhbkxlZnQgPT09IDEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBncm91cFdpdGhOZXh0KGNMZWZ0LmlkLCAnbGVmdCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkFncnVwYXIgY29uIHNpZ3VpZW50ZSBwb2xvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibm8tcHJpbnQgYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiBvcGFjaXR5LTgwIGhvdmVyOm9wYWNpdHktMTAwIHAtMC41IGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWZ1bGwgY3Vyc29yLXBvaW50ZXIgc2hhZG93IHRyYW5zaXRpb24tb3BhY2l0eVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctMi41IGgtMi41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgey8qID09PSBMQURPIERFUkVDSE8gKFBBUikgPT09ICovfVxuICAgICAgICAgICAgICAgICAgey8qIE7Dum1lcm8gZGUgUG9sbyBQYXIgKEJhcnJhIENvbGVjdG9yYSBGw61zaWNhIEZpamEpICovfVxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMCB0ZXh0LWNlbnRlciBmb250LW1vbm8gZm9udC1ib2xkIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMC84MCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGFsaWduLW1pZGRsZSBzZWxlY3Qtbm9uZSByZWxhdGl2ZSBncm91cC9wb2xlLXJpZ2h0IGN1cnNvci1kZWZhdWx0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWluLWgtWzEuNzVyZW1dIHB4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHNlbGVjdC1ub25lXCI+e2V2ZW5Qb2xlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogSW50ZXJhY3RpdmUgR3JvdXAgQ29udHJvbCAqL31cbiAgICAgICAgICAgICAgICAgICAgICB7ZXZlblBvbGUgPCBtYXhQb2xlcyAmJiBpc0ZpcnN0UmlnaHQgJiYgcm93U3BhblJpZ2h0ID09PSAxICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZ3JvdXBXaXRoTmV4dChjUmlnaHQuaWQsICdyaWdodCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkFncnVwYXIgY29uIHNpZ3VpZW50ZSBwb2xvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibm8tcHJpbnQgYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiBvcGFjaXR5LTgwIGhvdmVyOm9wYWNpdHktMTAwIHAtMC41IGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWZ1bGwgY3Vyc29yLXBvaW50ZXIgc2hhZG93IHRyYW5zaXRpb24tb3BhY2l0eVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctMi41IGgtMi41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAge2lzRmlyc3RSaWdodCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgey8qIENvbmR1Y3RvciBjYWxpYnJlICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZFxuICAgICAgICAgICAgICAgICAgICAgICAgcm93U3Bhbj17cm93U3BhblJpZ2h0fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcC0wIHRleHQtY2VudGVyIGFsaWduLW1pZGRsZSBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEVkaXRhYmxlQ2VsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y1JpZ2h0LmNvbmR1Y3Rvcn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVDaXJjdWl0KGNSaWdodC5pZCwgJ2NvbmR1Y3RvcicsIHZhbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzZWxlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtDT05EX09QVElPTlN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZm9udC1tb25vIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEJyZWFrZXIgQW1wICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZFxuICAgICAgICAgICAgICAgICAgICAgICAgcm93U3Bhbj17cm93U3BhblJpZ2h0fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcC0wIHRleHQtY2VudGVyIGFsaWduLW1pZGRsZSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NSaWdodC5icmVha2VyLmFtcH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVDaXJjdWl0KGNSaWdodC5pZCwgJ2JyZWFrZXIuYW1wJywgdmFsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInNlbGVjdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e0FNUF9PUFRJT05TfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZvbnQtbW9ubyB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBCcmVha2VyIFRpcG8gKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dTcGFuPXtyb3dTcGFuUmlnaHR9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItciBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTAgdGV4dC1jZW50ZXIgYWxpZ24tbWlkZGxlXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RWRpdGFibGVDZWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjUmlnaHQuYnJlYWtlci50aXBvfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvblNhdmU9eyh2YWwpID0+IHVwZGF0ZUNpcmN1aXQoY1JpZ2h0LmlkLCAnYnJlYWtlci50aXBvJywgdmFsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInNlbGVjdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1RJUE9fT1BUSU9OU31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQnJlYWtlciBNYXJjYSAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8dGRcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvd1NwYW49e3Jvd1NwYW5SaWdodH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHAtMCB0ZXh0LWNlbnRlciBhbGlnbi1taWRkbGVcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NSaWdodC5icmVha2VyLm1hcmNhfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvblNhdmU9eyh2YWwpID0+IHVwZGF0ZUNpcmN1aXQoY1JpZ2h0LmlkLCAnYnJlYWtlci5tYXJjYScsIHZhbCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzZWxlY3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtNQVJDQV9PUFRJT05TfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZvbnQtYm9sZCBmb250LXNhbnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEVxdWlwbyBxdWUgQWxpbWVudGEgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dTcGFuPXtyb3dTcGFuUmlnaHR9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBmb250LW1lZGl1bSBhbGlnbi1taWRkbGUgY3Vyc29yLXBvaW50ZXIgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzUwIHRyYW5zaXRpb24tY29sb3JzIHJlbGF0aXZlIGdyb3VwL2NlbGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RWRpdGluZ0NpcmN1aXQoY1JpZ2h0KX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgbWluLWgtWzJyZW1dIHByLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVuZGVyQ2lyY3VpdEVxdWlwbyhjUmlnaHQuZXF1aXBvLCBjUmlnaHQudmluY3VsYWRvSWQsIGNSaWdodC5lbGVtZW50b0Rlc3Rpbm9JZCwgY1JpZ2h0LnRpcG9EZXN0aW5vLCBjUmlnaHQudGlwb0VsZW1lbnRvRGVzdGlubyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NSaWdodC5mb3RvZ3JhZmlhICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTUwMCBzaHJpbmstMCBtbC0xXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCYWRnZXMgYmFzZWQgb24gdGlwb0Rlc3Rpbm8gLyB0aXBvRWxlbWVudG9EZXN0aW5vICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVuZGVyVGlwb0Rlc3Rpbm9CYWRnZShjUmlnaHQudGlwb0Rlc3Rpbm8sIGNSaWdodC50aXBvRWxlbWVudG9EZXN0aW5vKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAge3Jvd1NwYW5SaWdodCA+IDEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcGxpdENpcmN1aXQoY1JpZ2h0LmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU2VwYXJhciBQb2xvc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibm8tcHJpbnQgYWJzb2x1dGUgcmlnaHQtMSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgcC0wLjUgb3BhY2l0eS04MCBob3ZlcjpvcGFjaXR5LTEwMCBiZy1yZWQtNTAwIGhvdmVyOmJnLXJlZC02MDAgdGV4dC13aGl0ZSByb3VuZGVkIGN1cnNvci1wb2ludGVyIHNoYWRvdy1zbSB0cmFuc2l0aW9uLW9wYWNpdHkgei0xMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWludXMgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgIDwvdGFibGU+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIDMuIFNFQ0NJw5NOIFBJRSBERSBQw4FHSU5BICovfVxuICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXItY29sbGFwc2UgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYm9yZGVyLXQtMCB0ZXh0LXhzIHRhYmxlLWZpeGVkIG1iLTBcIj5cbiAgICAgICAgPHRib2R5PlxuICAgICAgICAgIHsvKiBOZXV0cm8gZGUgbGxlZ2FkYSAqL31cbiAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJ3LVszMCVdIHAtMiBmb250LWJvbGQgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICAgIE5ldXRybyBkZSBMbGVnYWRhXG4gICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInctWzE1JV0gcC0wIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtY2VudGVyIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTAuNVwiPkNhbGliIENvbmQuPC9kaXY+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17bmV1dHJvTGxlZ2FkYS5jYWxpYnJlfVxuICAgICAgICAgICAgICAgIG9uU2F2ZT17KHZhbCkgPT4gdXBkYXRlRmllbGQoJ25ldXRyb0xsZWdhZGEuY2FsaWJyZScsIHZhbCl9XG4gICAgICAgICAgICAgICAgdHlwZT1cInNlbGVjdFwiXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17Q09ORF9PUFRJT05TfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ2FsaWJyZVwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwidy1bNSVdIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMC81MFwiPjwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0wXCI+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17bmV1dHJvTGxlZ2FkYS5vYnNlcnZhY2lvbmVzfVxuICAgICAgICAgICAgICAgIG9uU2F2ZT17KHZhbCkgPT4gdXBkYXRlRmllbGQoJ25ldXRyb0xsZWdhZGEub2JzZXJ2YWNpb25lcycsIHZhbCl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJPYnNlcnZhY2lvbmVzIGRlIE5ldXRybyAoZWo6IENvbG9yIGRlIGNhYmxlLCBiYXJyYSkuLi5cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8L3RyPlxuXG4gICAgICAgICAgey8qIFB1ZXN0YSBhIHRpZXJyYSAqL31cbiAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgZm9udC1ib2xkIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzQwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICBQdWVzdGEgYSBUaWVycmFcbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0wIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQtY2VudGVyIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBwLTAuNVwiPkNhbGliIENvbmQuPC9kaXY+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17cHVlc3RhVGllcnJhLmNhbGlicmV9XG4gICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVGaWVsZCgncHVlc3RhVGllcnJhLmNhbGlicmUnLCB2YWwpfVxuICAgICAgICAgICAgICAgIHR5cGU9XCJzZWxlY3RcIlxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e0NPTkRfT1BUSU9OU31cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNhbGlicmVcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMC81MFwiPjwvdGQ+XG4gICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0wXCI+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17cHVlc3RhVGllcnJhLm9ic2VydmFjaW9uZXN9XG4gICAgICAgICAgICAgICAgb25TYXZlPXsodmFsKSA9PiB1cGRhdGVGaWVsZCgncHVlc3RhVGllcnJhLm9ic2VydmFjaW9uZXMnLCB2YWwpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiT2JzZXJ2YWNpb25lcyBkZSBQdWVzdGEgYSBUaWVycmEgKGVqOiBNYWxsYSwgbWFsbGEgZGVsIGVkaWZpY2lvKS4uLlwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDwvdHI+XG5cbiAgICAgICAgICB7LyogT2JzZXJ2YWNpb25lcyBnZW5lcmFsZXMgKi99XG4gICAgICAgICAgPHRyPlxuICAgICAgICAgICAgPHRkIGNvbFNwYW49ezR9IGNsYXNzTmFtZT1cInAtMCBhbGlnbi10b3BcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcHgtMyBweS0xIGZvbnQtYm9sZCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgT2JzZXJ2YWNpb25lcyBHZW5lcmFsZXNcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxFZGl0YWJsZUNlbGxcbiAgICAgICAgICAgICAgICB2YWx1ZT17b2JzZXJ2YWNpb25lc0dlbmVyYWxlc31cbiAgICAgICAgICAgICAgICBvblNhdmU9eyh2YWwpID0+IHVwZGF0ZUZpZWxkKCdvYnNlcnZhY2lvbmVzR2VuZXJhbGVzJywgdmFsKX1cbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dGFyZWFcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3JpYmEgZWwgZXN0YWRvIGdlbmVyYWwgZGVsIHRhYmxlcm8sIGhhbGxhemdvcywgcmVwYXJhY2lvbmVzIHBlbmRpZW50ZXMgbyByZWNvbWVuZGFjaW9uZXMuLi5cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIG1pbi1oLVs0cmVtXSBmb250LXNhbnNcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8L3RyPlxuICAgICAgICA8L3Rib2R5PlxuICAgICAgPC90YWJsZT5cblxuICAgICAgey8qIExpc3RhIGRlIEVsZW1lbnRvcyBwb3IgQ3JlYXIgKHNlZ3VuIERpYWdyYW1hIGRlIEZsdWpvOiBDcmVhciBFbGVtZW50bykgKi99XG4gICAgICB7ZWxlbWVudG9zUG9yQ3JlYXIubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBwLTYgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvMjAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIG5vLXByaW50IHNoYWRvdy1zbVwiPlxuICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8Q2xpcGJvYXJkTGlzdCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz4gTGlzdGEgZGUgRWxlbWVudG9zIHBvciBDcmVhciAoe2VsZW1lbnRvc1BvckNyZWFyLmxlbmd0aH0pXG4gICAgICAgICAgPC9oND5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTNcIj5cbiAgICAgICAgICAgIHtlbGVtZW50b3NQb3JDcmVhci5tYXAoKGl0ZW0sIGlkeCkgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgIGtleT17aWR4fSBcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgc2hhZG93LXhzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPntpdGVtLm5vbWJyZX08L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBtdC0wLjUgZm9udC1tb25vXCI+UG9sbyBDaXJjdWl0bzoge2l0ZW0uY2lyY3VpdG9JZC5yZXBsYWNlKCdhdXRvXycsICcnKX08L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZCB0ZXh0LVs4cHhdIGZvbnQtYm9sZCBiZy1hbWJlci0xMDAgdGV4dC1hbWJlci04MDAgZGFyazpiZy1hbWJlci05MDAvMzAgZGFyazp0ZXh0LWFtYmVyLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgUEVORElFTlRFXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNb2RhbCBpbnRlcmFjdGl2byBkZSBFZGljacOzbiBDb25kaWNpb25hbCBkZSBDaXJjdWl0b3MgKi99XG4gICAgICA8TW9kYWxFZGljaW9uQ2lyY3VpdG9cbiAgICAgICAgaXNPcGVuPXshIWVkaXRpbmdDaXJjdWl0fVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRFZGl0aW5nQ2lyY3VpdChudWxsKX1cbiAgICAgICAgY2lyY3VpdERhdGE9e2VkaXRpbmdDaXJjdWl0fVxuICAgICAgICB0YWJsZXJvQ2lyY3VpdHM9e2NpcmN1aXRzfVxuICAgICAgICBtYXhQb2xvcz17bWF4UG9sZXN9XG4gICAgICAgIG9uU2F2ZT17c2F2ZUNpcmN1aXRGcm9tTW9kYWx9XG4gICAgICAgIGVsZW1lbnRvc0NyZWFkb3M9e3RvZG9zRWxlbWVudG9zQ3JlYWRvc31cbiAgICAgIC8+XG5cbiAgICAgICAgICAgIHsvKiBCb3TDs24gZmxvdGFudGUgcGFyYSBleHBvcnRhciBhIFBERiAobm8tcHJpbnQpICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tNiByaWdodC02IHotNDAgbm8tcHJpbnRcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5wcmludCgpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTQgaC0xNCBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIGFjdGl2ZTpzY2FsZS05NSB0ZXh0LXNsYXRlLTk1MCByb3VuZGVkLWZ1bGwgc2hhZG93LTJ4bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBncm91cCBob3Zlcjpyb3RhdGUtNlwiXG4gICAgICAgICAgdGl0bGU9XCJJbXByaW1pciAvIEd1YXJkYXIgUERGXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctNiBoLTYgZ3JvdXAtaG92ZXI6c2NhbGUtMTEwIHRyYW5zaXRpb24tdHJhbnNmb3JtXCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIENpZXJyZSAvIEZpcm1hcyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzcGFjZS15LTQgcHJpbnQ6Ymctc2xhdGUtNTAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwIHByaW50Om10LTNcIj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHBiLTIuNVwiPlxuICAgICAgICAgIEZpcm1hIHkgQ2llcnJlIGRlIEluc3BlY2Npw7NuXG4gICAgICAgIDwvaDM+XG4gICAgICAgIFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cbiAgICAgICAgICB7LyogRmlybWEgSW5zcGVjdG9yICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41IGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+RmlybWEgZGVsIEluc3BlY3Rvcjwvc3Bhbj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXt0YWJsZXJvRGF0YS5maXJtYUluc3BlY3RvciB8fCAnJ31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnZmlybWFJbnNwZWN0b3InLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy14cyBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03NTAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyIG5vLXByaW50XCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb21icmUgZGVsIEluc3BlY3RvclwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHByaW50OmJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG10LTEgaC02XCI+XG4gICAgICAgICAgICAgIHt0YWJsZXJvRGF0YS5maXJtYUluc3BlY3RvciB8fCAnX19fX19fX19fX19fX19fX19fX19fX19fX19fJ31cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHByaW50OmJsb2NrIHctNDggYm9yZGVyLWIgYm9yZGVyLWdyYXktNDAwIG10LTYgaC0xXCI+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRmlybWEgLyBTZWxsbyBkZSBsYSBFbXByZXNhICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41IGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+RmlybWEgLyBTZWxsbyBkZSBsYSBFbXByZXNhPC9zcGFuPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e3RhYmxlcm9EYXRhLmZpcm1hU3VwZXJ2aXNvciB8fCAnJ31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnZmlybWFTdXBlcnZpc29yJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzUwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCB0ZXh0LWNlbnRlciBuby1wcmludFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tYnJlIC8gU2VsbG8gZGUgbGEgRW1wcmVzYVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHByaW50OmJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG10LTEgaC02XCI+XG4gICAgICAgICAgICAgIHt0YWJsZXJvRGF0YS5maXJtYVN1cGVydmlzb3IgfHwgJ19fX19fX19fX19fX19fX19fX19fX19fX19fXyd9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBwcmludDpibG9jayB3LTQ4IGJvcmRlci1iIGJvcmRlci1ncmF5LTQwMCBtdC02IGgtMVwiPjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj4gey8qIEZpbiBkZSBzY3JlZW4tY29udGFpbmVyICovfVxuICAgIDwvZGl2PlxuICApO1xufTtcbmV4cG9ydCBkZWZhdWx0IFRhYmxlcm9Db21wb25lbnQ7XG4iXX0=