const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { API_BASE_URL } from "/src/utils/api.js";
export function useSync() {
	const { syncQueue, removeFromQueue } = useStore();
	const [isOnline, setIsOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
	const [isSyncing, setIsSyncing] = useState(false);
	// Semáforo de bloqueo para impedir la ejecución concurrente de la cola de sincronización
	const isSyncingRef = useRef(false);
	const getFreshToken = () => {
		return useStore.getState().token || (typeof localStorage !== "undefined" ? localStorage.getItem("token") : "") || "";
	};
	const getAuthHeaders = (extra = {}) => {
		const token = getFreshToken();
		return {
			"Content-Type": "application/json",
			...token && token !== "mock-offline-token" ? { "Authorization": `Bearer ${token}` } : {},
			...extra
		};
	};
	useEffect(() => {
		const handleOnline = () => {
			setIsOnline(true);
			// Al recuperar conexión, intentar sincronizar pendientes y descargar cambios del servidor
			const state = useStore.getState();
			if (state.token && state.token !== "mock-offline-token") {
				state.pullInitialData?.();
			}
		};
		const handleOffline = () => setIsOnline(false);
		window.addEventListener("online", handleOnline);
		window.addEventListener("offline", handleOffline);
		return () => {
			window.removeEventListener("online", handleOnline);
			window.removeEventListener("offline", handleOffline);
		};
	}, []);
	// Disparar sincronización automática cuando cambie la red o la cola de elementos
	useEffect(() => {
		if (isOnline && syncQueue.length > 0 && !isSyncingRef.current) {
			procesarColaSincronizacion();
		}
	}, [isOnline, syncQueue]);
	const sincronizarLote = async (mutaciones) => {
		try {
			const response = await fetch(`${API_BASE_URL}/api/sync/batch`, {
				method: "POST",
				headers: getAuthHeaders(),
				body: JSON.stringify({ mutations: mutaciones })
			});
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				return {
					success: false,
					status: response.status
				};
			}
			if (!response.ok) {
				return {
					success: false,
					status: response.status
				};
			}
			const json = await response.json();
			return {
				success: true,
				data: json
			};
		} catch (err) {
			console.error("Error de red en sincronizarLote:", err);
			return {
				success: false,
				status: "NETWORK_ERROR"
			};
		}
	};
	const procesarColaSincronizacion = async () => {
		if (isSyncingRef.current) return;
		const token = getFreshToken();
		if (!token || token === "mock-offline-token") {
			// Modo offline local sin backend configurado
			return;
		}
		isSyncingRef.current = true;
		setIsSyncing(true);
		const currentQueue = [...useStore.getState().syncQueue];
		if (currentQueue.length === 0) {
			setIsSyncing(false);
			isSyncingRef.current = false;
			return;
		}
		// Separar elementos sin archivos para sincronización en lote (batch) y elementos con archivos
		const jsonMutations = [];
		const queueItemsMap = new Map();
		for (const item of currentQueue) {
			if (!item) continue;
			// Si el elemento tiene un archivo de imagen fotoBlob, debe enviarse via FormData
			if (item.payload && item.payload.fotoBlob) {
				continue;
			}
			let entityName = "ElementoUnifilar";
			if (item.tipo === "PROYECTO") entityName = "Proyecto";
			else if (item.tipo === "ELEMENTO_UNIFILAR" || item.tipo === "TABLERO") entityName = "ElementoUnifilar";
			else if (item.tipo === "SUBESTACION") entityName = "Subestacion";
			else if (item.tipo === "PUNTO_MEDICION") entityName = "PuntoMedicion";
			else if (item.tipo === "CCM") entityName = "Ccm";
			else if (item.tipo === "INSPECCION_TERMOGRAFICA") entityName = "InspeccionTermografica";
			else if (item.tipo === "INSPECCION_ATERRAMIENTO") entityName = "InspeccionAterramiento";
			else if (item.tipo === "INSPECCION_TANQUE_COMBUSTIBLE") entityName = "InspeccionTanqueCombustible";
			jsonMutations.push({
				entity: entityName,
				id: item.payload?.id || item.id,
				operation: item.operation || "UPSERT",
				baseVersion: item.payload?.version || 1,
				data: item.payload
			});
			queueItemsMap.set(item.payload?.id || item.id, item.id);
		}
		if (jsonMutations.length > 0) {
			const batchRes = await sincronizarLote(jsonMutations);
			if (batchRes.success) {
				// Remover del queue local los elementos procesados exitosamente
				(batchRes.data?.applied || []).forEach((appItem) => {
					const queueId = queueItemsMap.get(appItem.id);
					if (queueId) removeFromQueue(queueId);
				});
				// Notificar en consola si hubo conflictos OCC
				if (batchRes.data?.conflicts && batchRes.data.conflicts.length > 0) {
					console.warn("⚠️ Se detectaron conflictos OCC al sincronizar:", batchRes.data.conflicts);
				}
			} else if (batchRes.status === 401 || batchRes.status === 403) {
				console.warn(`[SYNC AUTH] Error HTTP ${batchRes.status}: Sesión expirada. Pausando sincronización.`);
				setIsSyncing(false);
				isSyncingRef.current = false;
				return;
			}
		}
		// Procesar secuencialmente elementos restantes (ej. aquellos con fotos)
		while (useStore.getState().syncQueue.length > 0) {
			if (!navigator.onLine) {
				setIsOnline(false);
				break;
			}
			const queueNow = useStore.getState().syncQueue;
			const item = queueNow[0];
			if (!item) break;
			let res = null;
			if (item.tipo === "PROYECTO") {
				res = await sincronizarProyecto(item.companyId, item.payload);
			} else if (item.tipo === "ELEMENTO_UNIFILAR" || item.tipo === "TABLERO") {
				res = await sincronizarElementoUnifilar(item.companyId, item.payload);
			} else if (item.tipo === "SUBESTACION") {
				res = await sincronizarSubestacion(item.companyId, item.payload);
			} else if (item.tipo === "PUNTO_MEDICION") {
				res = await sincronizarPuntoMedicion(item.companyId, item.payload);
			} else if (item.tipo === "CCM") {
				res = await sincronizarCcm(item.companyId, item.payload);
			}
			if (res) {
				if (res.success) {
					removeFromQueue(item.id);
				} else {
					if (res.status === "NETWORK_ERROR") break;
					if (res.status === 401 || res.status === 403) {
						useStore.getState().handleAuthError?.(res.status);
						break;
					}
					removeFromQueue(item.id);
				}
			} else {
				removeFromQueue(item.id);
			}
		}
		// Si la cola se vació por completo, actualizar datos desde el servidor
		if (useStore.getState().syncQueue.length === 0) {
			useStore.getState().pullInitialData?.();
		}
		setIsSyncing(false);
		isSyncingRef.current = false;
	};
	const sincronizarProyecto = async (empresaId, proyecto) => {
		try {
			const payload = {
				id: proyecto.id,
				nombre: proyecto.nombre,
				descripcion: proyecto.descripcion || "",
				empresaId
			};
			const response = await fetch(`${API_BASE_URL}/api/proyectos`, {
				method: "POST",
				headers: getAuthHeaders(),
				body: JSON.stringify(payload)
			});
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				return {
					success: false,
					status: response.status
				};
			}
			if (!response.ok) {
				return {
					success: false,
					status: response.status
				};
			}
			return { success: true };
		} catch (error) {
			console.error("Error de red en sincronizarProyecto:", error);
			return {
				success: false,
				status: "NETWORK_ERROR"
			};
		}
	};
	const sincronizarElementoUnifilar = async (empresaId, elemento) => {
		try {
			const formData = new FormData();
			formData.append("id", elemento.id);
			formData.append("nombre", elemento.nombre);
			formData.append("tipoElemento", elemento.tipoElemento || "TABLERO");
			formData.append("ubicacion", elemento.ubicacion || "");
			formData.append("alimentadoPor", elemento.alimentadoPor || "");
			formData.append("observacionesGenerales", elemento.observacionesGenerales || "");
			formData.append("proyectoId", elemento.proyectoId);
			if (empresaId) {
				formData.append("empresaId", empresaId);
			}
			formData.append("datosTecnicos", JSON.stringify(elemento.datosTecnicos || {}));
			if (elemento.fotoBlob) {
				const fileExt = elemento.fotoBlob.type ? elemento.fotoBlob.type.split("/")[1] : "jpg";
				formData.append("foto", elemento.fotoBlob, `foto_${elemento.id}.${fileExt}`);
			} else if (elemento.foto) {
				formData.append("fotoUrl", elemento.foto);
			}
			const token = getFreshToken();
			const response = await fetch(`${API_BASE_URL}/api/elementos-unifilares`, {
				method: "POST",
				headers: { ...token && token !== "mock-offline-token" ? { "Authorization": `Bearer ${token}` } : {} },
				body: formData
			});
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				return {
					success: false,
					status: response.status
				};
			}
			if (!response.ok) {
				return {
					success: false,
					status: response.status
				};
			}
			const resJson = await response.json();
			if (resJson.data && resJson.data.foto) {
				useStore.getState().updateElementoUnifilar(elemento.proyectoId, elemento.id, {
					foto: `${API_BASE_URL}${resJson.data.foto}`,
					fotoBlob: null
				});
			}
			return { success: true };
		} catch (error) {
			console.error("Error de red en sincronizarElementoUnifilar:", error);
			return {
				success: false,
				status: "NETWORK_ERROR"
			};
		}
	};
	const sincronizarSubestacion = async (empresaId, subestacion) => {
		try {
			const payload = {
				id: subestacion.id,
				nombre: subestacion.nombre,
				ubicacion: subestacion.ubicacion,
				fecha: subestacion.fecha,
				hora: subestacion.hora,
				inspector: subestacion.inspector,
				nivelTension: subestacion.nivelTension,
				estadoEntorno: subestacion.estadoEntorno,
				obrasCiviles: subestacion.obrasCiviles,
				equiposPrincipales: subestacion.equiposPrincipales,
				puestaTierra: subestacion.puestaTierra,
				edificioControl: subestacion.edificioControl,
				firmaInspector: subestacion.firmaInspector || null,
				firmaSupervisor: subestacion.firmaSupervisor || null,
				proyectoId: subestacion.proyectoId,
				empresaId
			};
			const response = await fetch(`${API_BASE_URL}/api/subestaciones`, {
				method: "POST",
				headers: getAuthHeaders(),
				body: JSON.stringify(payload)
			});
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				return {
					success: false,
					status: response.status
				};
			}
			if (!response.ok) {
				return {
					success: false,
					status: response.status
				};
			}
			return { success: true };
		} catch (error) {
			console.error("Error de red en sincronizarSubestacion:", error);
			return {
				success: false,
				status: "NETWORK_ERROR"
			};
		}
	};
	const sincronizarPuntoMedicion = async (empresaId, punto) => {
		try {
			const payload = {
				...punto,
				empresaId
			};
			const response = await fetch(`${API_BASE_URL}/api/puntos-medicion`, {
				method: "POST",
				headers: getAuthHeaders(),
				body: JSON.stringify(payload)
			});
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				return {
					success: false,
					status: response.status
				};
			}
			if (!response.ok) {
				return {
					success: false,
					status: response.status
				};
			}
			return { success: true };
		} catch (error) {
			console.error("Error de red en sincronizarPuntoMedicion:", error);
			return {
				success: false,
				status: "NETWORK_ERROR"
			};
		}
	};
	const sincronizarCcm = async (empresaId, ccmItem) => {
		try {
			const payload = {
				...ccmItem,
				empresaId
			};
			const response = await fetch(`${API_BASE_URL}/api/ccm`, {
				method: "POST",
				headers: getAuthHeaders(),
				body: JSON.stringify(payload)
			});
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				return {
					success: false,
					status: response.status
				};
			}
			if (!response.ok) {
				return {
					success: false,
					status: response.status
				};
			}
			return { success: true };
		} catch (error) {
			console.error("Error de red en sincronizarCcm:", error);
			return {
				success: false,
				status: "NETWORK_ERROR"
			};
		}
	};
	return {
		isOnline,
		isSyncing,
		pendingCount: syncQueue.length,
		triggerSync: procesarColaSincronizacion,
		syncPendingData: procesarColaSincronizacion,
		pullInitialData: () => useStore.getState().pullInitialData?.()
	};
}
export default useSync;

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFVBQVUsY0FBYztBQUM1QyxPQUFPLGNBQWM7QUFDckIsU0FBUyxvQkFBb0I7QUFFN0IsT0FBTyxTQUFTLFVBQVU7Q0FDeEIsTUFBTSxFQUFFLFdBQVcsb0JBQW9CLFNBQVM7Q0FDaEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLE9BQU8sY0FBYyxjQUFjLFVBQVUsU0FBUyxJQUFJO0NBQ25HLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7O0NBR2hELE1BQU0sZUFBZSxPQUFPLEtBQUs7Q0FFakMsTUFBTSxzQkFBc0I7RUFDMUIsT0FBTyxTQUFTLFNBQVMsQ0FBQyxDQUFDLFVBQVUsT0FBTyxpQkFBaUIsY0FBYyxhQUFhLFFBQVEsT0FBTyxJQUFJLE9BQU87Q0FDcEg7Q0FFQSxNQUFNLGtCQUFrQixRQUFRLENBQUMsTUFBTTtFQUNyQyxNQUFNLFFBQVEsY0FBYztFQUM1QixPQUFPO0dBQ0wsZ0JBQWdCO0dBQ2hCLEdBQUksU0FBUyxVQUFVLHVCQUF1QixFQUFFLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxDQUFDO0dBQ3hGLEdBQUc7RUFDTDtDQUNGO0NBRUEsZ0JBQWdCO0VBQ2QsTUFBTSxxQkFBcUI7R0FDekIsWUFBWSxJQUFJOztHQUVoQixNQUFNLFFBQVEsU0FBUyxTQUFTO0dBQ2hDLElBQUksTUFBTSxTQUFTLE1BQU0sVUFBVSxzQkFBc0I7SUFDdkQsTUFBTSxrQkFBa0I7R0FDMUI7RUFDRjtFQUNBLE1BQU0sc0JBQXNCLFlBQVksS0FBSztFQUU3QyxPQUFPLGlCQUFpQixVQUFVLFlBQVk7RUFDOUMsT0FBTyxpQkFBaUIsV0FBVyxhQUFhO0VBRWhELGFBQWE7R0FDWCxPQUFPLG9CQUFvQixVQUFVLFlBQVk7R0FDakQsT0FBTyxvQkFBb0IsV0FBVyxhQUFhO0VBQ3JEO0NBQ0YsR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ2QsSUFBSSxZQUFZLFVBQVUsU0FBUyxLQUFLLENBQUMsYUFBYSxTQUFTO0dBQzdELDJCQUEyQjtFQUM3QjtDQUNGLEdBQUcsQ0FBQyxVQUFVLFNBQVMsQ0FBQztDQUV4QixNQUFNLGtCQUFrQixPQUFPLGVBQWU7RUFDNUMsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0sR0FBRyxhQUFhLGtCQUFrQjtJQUM3RCxRQUFRO0lBQ1IsU0FBUyxlQUFlO0lBQ3hCLE1BQU0sS0FBSyxVQUFVLEVBQUUsV0FBVyxXQUFXLENBQUM7R0FDaEQsQ0FBQztHQUVELElBQUksU0FBUyxXQUFXLE9BQU8sU0FBUyxXQUFXLEtBQUs7SUFDdEQsU0FBUyxTQUFTLENBQUMsQ0FBQyxrQkFBa0IsU0FBUyxNQUFNO0lBQ3JELE9BQU87S0FBRSxTQUFTO0tBQU8sUUFBUSxTQUFTO0lBQU87R0FDbkQ7R0FFQSxJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLE9BQU87S0FBRSxTQUFTO0tBQU8sUUFBUSxTQUFTO0lBQU87R0FDbkQ7R0FFQSxNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUs7R0FDakMsT0FBTztJQUFFLFNBQVM7SUFBTSxNQUFNO0dBQUs7RUFDckMsU0FBUyxLQUFLO0dBQ1osUUFBUSxNQUFNLG9DQUFvQyxHQUFHO0dBQ3JELE9BQU87SUFBRSxTQUFTO0lBQU8sUUFBUTtHQUFnQjtFQUNuRDtDQUNGO0NBRUEsTUFBTSw2QkFBNkIsWUFBWTtFQUM3QyxJQUFJLGFBQWEsU0FBUztFQUUxQixNQUFNLFFBQVEsY0FBYztFQUM1QixJQUFJLENBQUMsU0FBUyxVQUFVLHNCQUFzQjs7R0FFNUM7RUFDRjtFQUVBLGFBQWEsVUFBVTtFQUN2QixhQUFhLElBQUk7RUFFakIsTUFBTSxlQUFlLENBQUMsR0FBRyxTQUFTLFNBQVMsQ0FBQyxDQUFDLFNBQVM7RUFDdEQsSUFBSSxhQUFhLFdBQVcsR0FBRztHQUM3QixhQUFhLEtBQUs7R0FDbEIsYUFBYSxVQUFVO0dBQ3ZCO0VBQ0Y7O0VBR0EsTUFBTSxnQkFBZ0IsQ0FBQztFQUN2QixNQUFNLGdCQUFnQixJQUFJLElBQUk7RUFFOUIsS0FBSyxNQUFNLFFBQVEsY0FBYztHQUMvQixJQUFJLENBQUMsTUFBTTs7R0FHWCxJQUFJLEtBQUssV0FBVyxLQUFLLFFBQVEsVUFBVTtJQUN6QztHQUNGO0dBRUEsSUFBSSxhQUFhO0dBQ2pCLElBQUksS0FBSyxTQUFTLFlBQVksYUFBYTtRQUN0QyxJQUFJLEtBQUssU0FBUyx1QkFBdUIsS0FBSyxTQUFTLFdBQVcsYUFBYTtRQUMvRSxJQUFJLEtBQUssU0FBUyxlQUFlLGFBQWE7UUFDOUMsSUFBSSxLQUFLLFNBQVMsa0JBQWtCLGFBQWE7UUFDakQsSUFBSSxLQUFLLFNBQVMsT0FBTyxhQUFhO1FBQ3RDLElBQUksS0FBSyxTQUFTLDJCQUEyQixhQUFhO1FBQzFELElBQUksS0FBSyxTQUFTLDJCQUEyQixhQUFhO1FBQzFELElBQUksS0FBSyxTQUFTLGlDQUFpQyxhQUFhO0dBRXJFLGNBQWMsS0FBSztJQUNqQixRQUFRO0lBQ1IsSUFBSSxLQUFLLFNBQVMsTUFBTSxLQUFLO0lBQzdCLFdBQVcsS0FBSyxhQUFhO0lBQzdCLGFBQWEsS0FBSyxTQUFTLFdBQVc7SUFDdEMsTUFBTSxLQUFLO0dBQ2IsQ0FBQztHQUNELGNBQWMsSUFBSSxLQUFLLFNBQVMsTUFBTSxLQUFLLElBQUksS0FBSyxFQUFFO0VBQ3hEO0VBRUEsSUFBSSxjQUFjLFNBQVMsR0FBRztHQUM1QixNQUFNLFdBQVcsTUFBTSxnQkFBZ0IsYUFBYTtHQUVwRCxJQUFJLFNBQVMsU0FBUzs7SUFFcEIsQ0FBQyxTQUFTLE1BQU0sV0FBVyxDQUFDLEVBQUMsQ0FBRSxTQUFRLFlBQVc7S0FDaEQsTUFBTSxVQUFVLGNBQWMsSUFBSSxRQUFRLEVBQUU7S0FDNUMsSUFBSSxTQUFTLGdCQUFnQixPQUFPO0lBQ3RDLENBQUM7O0lBR0QsSUFBSSxTQUFTLE1BQU0sYUFBYSxTQUFTLEtBQUssVUFBVSxTQUFTLEdBQUc7S0FDbEUsUUFBUSxLQUFLLG1EQUFtRCxTQUFTLEtBQUssU0FBUztJQUN6RjtHQUNGLE9BQU8sSUFBSSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztJQUM3RCxRQUFRLEtBQUssMEJBQTBCLFNBQVMsT0FBTyw0Q0FBNEM7SUFDbkcsYUFBYSxLQUFLO0lBQ2xCLGFBQWEsVUFBVTtJQUN2QjtHQUNGO0VBQ0Y7O0VBR0EsT0FBTyxTQUFTLFNBQVMsQ0FBQyxDQUFDLFVBQVUsU0FBUyxHQUFHO0dBQy9DLElBQUksQ0FBQyxVQUFVLFFBQVE7SUFDckIsWUFBWSxLQUFLO0lBQ2pCO0dBQ0Y7R0FFQSxNQUFNLFdBQVcsU0FBUyxTQUFTLENBQUMsQ0FBQztHQUNyQyxNQUFNLE9BQU8sU0FBUztHQUN0QixJQUFJLENBQUMsTUFBTTtHQUVYLElBQUksTUFBTTtHQUNWLElBQUksS0FBSyxTQUFTLFlBQVk7SUFDNUIsTUFBTSxNQUFNLG9CQUFvQixLQUFLLFdBQVcsS0FBSyxPQUFPO0dBQzlELE9BQU8sSUFBSSxLQUFLLFNBQVMsdUJBQXVCLEtBQUssU0FBUyxXQUFXO0lBQ3ZFLE1BQU0sTUFBTSw0QkFBNEIsS0FBSyxXQUFXLEtBQUssT0FBTztHQUN0RSxPQUFPLElBQUksS0FBSyxTQUFTLGVBQWU7SUFDdEMsTUFBTSxNQUFNLHVCQUF1QixLQUFLLFdBQVcsS0FBSyxPQUFPO0dBQ2pFLE9BQU8sSUFBSSxLQUFLLFNBQVMsa0JBQWtCO0lBQ3pDLE1BQU0sTUFBTSx5QkFBeUIsS0FBSyxXQUFXLEtBQUssT0FBTztHQUNuRSxPQUFPLElBQUksS0FBSyxTQUFTLE9BQU87SUFDOUIsTUFBTSxNQUFNLGVBQWUsS0FBSyxXQUFXLEtBQUssT0FBTztHQUN6RDtHQUVBLElBQUksS0FBSztJQUNQLElBQUksSUFBSSxTQUFTO0tBQ2YsZ0JBQWdCLEtBQUssRUFBRTtJQUN6QixPQUFPO0tBQ0wsSUFBSSxJQUFJLFdBQVcsaUJBQWlCO0tBQ3BDLElBQUksSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7TUFDNUMsU0FBUyxTQUFTLENBQUMsQ0FBQyxrQkFBa0IsSUFBSSxNQUFNO01BQ2hEO0tBQ0Y7S0FDQSxnQkFBZ0IsS0FBSyxFQUFFO0lBQ3pCO0dBQ0YsT0FBTztJQUNMLGdCQUFnQixLQUFLLEVBQUU7R0FDekI7RUFDRjs7RUFHQSxJQUFJLFNBQVMsU0FBUyxDQUFDLENBQUMsVUFBVSxXQUFXLEdBQUc7R0FDOUMsU0FBUyxTQUFTLENBQUMsQ0FBQyxrQkFBa0I7RUFDeEM7RUFFQSxhQUFhLEtBQUs7RUFDbEIsYUFBYSxVQUFVO0NBQ3pCO0NBRUEsTUFBTSxzQkFBc0IsT0FBTyxXQUFXLGFBQWE7RUFDekQsSUFBSTtHQUNGLE1BQU0sVUFBVTtJQUNkLElBQUksU0FBUztJQUNiLFFBQVEsU0FBUztJQUNqQixhQUFhLFNBQVMsZUFBZTtJQUNyQztHQUNGO0dBRUEsTUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLGFBQWEsaUJBQWlCO0lBQzVELFFBQVE7SUFDUixTQUFTLGVBQWU7SUFDeEIsTUFBTSxLQUFLLFVBQVUsT0FBTztHQUM5QixDQUFDO0dBRUQsSUFBSSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztJQUN0RCxTQUFTLFNBQVMsQ0FBQyxDQUFDLGtCQUFrQixTQUFTLE1BQU07SUFDckQsT0FBTztLQUFFLFNBQVM7S0FBTyxRQUFRLFNBQVM7SUFBTztHQUNuRDtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsT0FBTztLQUFFLFNBQVM7S0FBTyxRQUFRLFNBQVM7SUFBTztHQUNuRDtHQUVBLE9BQU8sRUFBRSxTQUFTLEtBQUs7RUFDekIsU0FBUyxPQUFPO0dBQ2QsUUFBUSxNQUFNLHdDQUF3QyxLQUFLO0dBQzNELE9BQU87SUFBRSxTQUFTO0lBQU8sUUFBUTtHQUFnQjtFQUNuRDtDQUNGO0NBRUEsTUFBTSw4QkFBOEIsT0FBTyxXQUFXLGFBQWE7RUFDakUsSUFBSTtHQUNGLE1BQU0sV0FBVyxJQUFJLFNBQVM7R0FDOUIsU0FBUyxPQUFPLE1BQU0sU0FBUyxFQUFFO0dBQ2pDLFNBQVMsT0FBTyxVQUFVLFNBQVMsTUFBTTtHQUN6QyxTQUFTLE9BQU8sZ0JBQWdCLFNBQVMsZ0JBQWdCLFNBQVM7R0FDbEUsU0FBUyxPQUFPLGFBQWEsU0FBUyxhQUFhLEVBQUU7R0FDckQsU0FBUyxPQUFPLGlCQUFpQixTQUFTLGlCQUFpQixFQUFFO0dBQzdELFNBQVMsT0FBTywwQkFBMEIsU0FBUywwQkFBMEIsRUFBRTtHQUMvRSxTQUFTLE9BQU8sY0FBYyxTQUFTLFVBQVU7R0FDakQsSUFBSSxXQUFXO0lBQ2IsU0FBUyxPQUFPLGFBQWEsU0FBUztHQUN4QztHQUVBLFNBQVMsT0FBTyxpQkFBaUIsS0FBSyxVQUFVLFNBQVMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO0dBRTdFLElBQUksU0FBUyxVQUFVO0lBQ3JCLE1BQU0sVUFBVSxTQUFTLFNBQVMsT0FBTyxTQUFTLFNBQVMsS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUs7SUFDaEYsU0FBUyxPQUFPLFFBQVEsU0FBUyxVQUFVLFFBQVEsU0FBUyxHQUFHLEdBQUcsU0FBUztHQUM3RSxPQUFPLElBQUksU0FBUyxNQUFNO0lBQ3hCLFNBQVMsT0FBTyxXQUFXLFNBQVMsSUFBSTtHQUMxQztHQUVBLE1BQU0sUUFBUSxjQUFjO0dBQzVCLE1BQU0sV0FBVyxNQUFNLE1BQU0sR0FBRyxhQUFhLDRCQUE0QjtJQUN2RSxRQUFRO0lBQ1IsU0FBUyxFQUNQLEdBQUksU0FBUyxVQUFVLHVCQUF1QixFQUFFLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxDQUFDLEVBQzFGO0lBQ0EsTUFBTTtHQUNSLENBQUM7R0FFRCxJQUFJLFNBQVMsV0FBVyxPQUFPLFNBQVMsV0FBVyxLQUFLO0lBQ3RELFNBQVMsU0FBUyxDQUFDLENBQUMsa0JBQWtCLFNBQVMsTUFBTTtJQUNyRCxPQUFPO0tBQUUsU0FBUztLQUFPLFFBQVEsU0FBUztJQUFPO0dBQ25EO0dBRUEsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixPQUFPO0tBQUUsU0FBUztLQUFPLFFBQVEsU0FBUztJQUFPO0dBQ25EO0dBRUEsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLO0dBQ3BDLElBQUksUUFBUSxRQUFRLFFBQVEsS0FBSyxNQUFNO0lBQ3JDLFNBQVMsU0FBUyxDQUFDLENBQUMsdUJBQXVCLFNBQVMsWUFBWSxTQUFTLElBQUk7S0FDM0UsTUFBTSxHQUFHLGVBQWUsUUFBUSxLQUFLO0tBQ3JDLFVBQVU7SUFDWixDQUFDO0dBQ0g7R0FFQSxPQUFPLEVBQUUsU0FBUyxLQUFLO0VBQ3pCLFNBQVMsT0FBTztHQUNkLFFBQVEsTUFBTSxnREFBZ0QsS0FBSztHQUNuRSxPQUFPO0lBQUUsU0FBUztJQUFPLFFBQVE7R0FBZ0I7RUFDbkQ7Q0FDRjtDQUVBLE1BQU0seUJBQXlCLE9BQU8sV0FBVyxnQkFBZ0I7RUFDL0QsSUFBSTtHQUNGLE1BQU0sVUFBVTtJQUNkLElBQUksWUFBWTtJQUNoQixRQUFRLFlBQVk7SUFDcEIsV0FBVyxZQUFZO0lBQ3ZCLE9BQU8sWUFBWTtJQUNuQixNQUFNLFlBQVk7SUFDbEIsV0FBVyxZQUFZO0lBQ3ZCLGNBQWMsWUFBWTtJQUMxQixlQUFlLFlBQVk7SUFDM0IsY0FBYyxZQUFZO0lBQzFCLG9CQUFvQixZQUFZO0lBQ2hDLGNBQWMsWUFBWTtJQUMxQixpQkFBaUIsWUFBWTtJQUM3QixnQkFBZ0IsWUFBWSxrQkFBa0I7SUFDOUMsaUJBQWlCLFlBQVksbUJBQW1CO0lBQ2hELFlBQVksWUFBWTtJQUN4QjtHQUNGO0dBRUEsTUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLGFBQWEscUJBQXFCO0lBQ2hFLFFBQVE7SUFDUixTQUFTLGVBQWU7SUFDeEIsTUFBTSxLQUFLLFVBQVUsT0FBTztHQUM5QixDQUFDO0dBRUQsSUFBSSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztJQUN0RCxTQUFTLFNBQVMsQ0FBQyxDQUFDLGtCQUFrQixTQUFTLE1BQU07SUFDckQsT0FBTztLQUFFLFNBQVM7S0FBTyxRQUFRLFNBQVM7SUFBTztHQUNuRDtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsT0FBTztLQUFFLFNBQVM7S0FBTyxRQUFRLFNBQVM7SUFBTztHQUNuRDtHQUVBLE9BQU8sRUFBRSxTQUFTLEtBQUs7RUFDekIsU0FBUyxPQUFPO0dBQ2QsUUFBUSxNQUFNLDJDQUEyQyxLQUFLO0dBQzlELE9BQU87SUFBRSxTQUFTO0lBQU8sUUFBUTtHQUFnQjtFQUNuRDtDQUNGO0NBRUEsTUFBTSwyQkFBMkIsT0FBTyxXQUFXLFVBQVU7RUFDM0QsSUFBSTtHQUNGLE1BQU0sVUFBVTtJQUNkLEdBQUc7SUFDSDtHQUNGO0dBRUEsTUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLGFBQWEsdUJBQXVCO0lBQ2xFLFFBQVE7SUFDUixTQUFTLGVBQWU7SUFDeEIsTUFBTSxLQUFLLFVBQVUsT0FBTztHQUM5QixDQUFDO0dBRUQsSUFBSSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztJQUN0RCxTQUFTLFNBQVMsQ0FBQyxDQUFDLGtCQUFrQixTQUFTLE1BQU07SUFDckQsT0FBTztLQUFFLFNBQVM7S0FBTyxRQUFRLFNBQVM7SUFBTztHQUNuRDtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsT0FBTztLQUFFLFNBQVM7S0FBTyxRQUFRLFNBQVM7SUFBTztHQUNuRDtHQUVBLE9BQU8sRUFBRSxTQUFTLEtBQUs7RUFDekIsU0FBUyxPQUFPO0dBQ2QsUUFBUSxNQUFNLDZDQUE2QyxLQUFLO0dBQ2hFLE9BQU87SUFBRSxTQUFTO0lBQU8sUUFBUTtHQUFnQjtFQUNuRDtDQUNGO0NBRUEsTUFBTSxpQkFBaUIsT0FBTyxXQUFXLFlBQVk7RUFDbkQsSUFBSTtHQUNGLE1BQU0sVUFBVTtJQUNkLEdBQUc7SUFDSDtHQUNGO0dBRUEsTUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLGFBQWEsV0FBVztJQUN0RCxRQUFRO0lBQ1IsU0FBUyxlQUFlO0lBQ3hCLE1BQU0sS0FBSyxVQUFVLE9BQU87R0FDOUIsQ0FBQztHQUVELElBQUksU0FBUyxXQUFXLE9BQU8sU0FBUyxXQUFXLEtBQUs7SUFDdEQsU0FBUyxTQUFTLENBQUMsQ0FBQyxrQkFBa0IsU0FBUyxNQUFNO0lBQ3JELE9BQU87S0FBRSxTQUFTO0tBQU8sUUFBUSxTQUFTO0lBQU87R0FDbkQ7R0FFQSxJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLE9BQU87S0FBRSxTQUFTO0tBQU8sUUFBUSxTQUFTO0lBQU87R0FDbkQ7R0FFQSxPQUFPLEVBQUUsU0FBUyxLQUFLO0VBQ3pCLFNBQVMsT0FBTztHQUNkLFFBQVEsTUFBTSxtQ0FBbUMsS0FBSztHQUN0RCxPQUFPO0lBQUUsU0FBUztJQUFPLFFBQVE7R0FBZ0I7RUFDbkQ7Q0FDRjtDQUVBLE9BQU87RUFDTDtFQUNBO0VBQ0EsY0FBYyxVQUFVO0VBQ3hCLGFBQWE7RUFDYixpQkFBaUI7RUFDakIsdUJBQXVCLFNBQVMsU0FBUyxDQUFDLENBQUMsa0JBQWtCO0NBQy9EO0FBQ0Y7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInVzZVN5bmMuanMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgdXNlU3RvcmUgZnJvbSAnLi4vc3RvcmUvdXNlU3RvcmUnO1xyXG5pbXBvcnQgeyBBUElfQkFTRV9VUkwgfSBmcm9tICcuL2FwaSc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXNlU3luYygpIHtcclxuICBjb25zdCB7IHN5bmNRdWV1ZSwgcmVtb3ZlRnJvbVF1ZXVlIH0gPSB1c2VTdG9yZSgpO1xyXG4gIGNvbnN0IFtpc09ubGluZSwgc2V0SXNPbmxpbmVdID0gdXNlU3RhdGUodHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgPyBuYXZpZ2F0b3Iub25MaW5lIDogdHJ1ZSk7XHJcbiAgY29uc3QgW2lzU3luY2luZywgc2V0SXNTeW5jaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICAvLyBTZW3DoWZvcm8gZGUgYmxvcXVlbyBwYXJhIGltcGVkaXIgbGEgZWplY3VjacOzbiBjb25jdXJyZW50ZSBkZSBsYSBjb2xhIGRlIHNpbmNyb25pemFjacOzblxyXG4gIGNvbnN0IGlzU3luY2luZ1JlZiA9IHVzZVJlZihmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGdldEZyZXNoVG9rZW4gPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gdXNlU3RvcmUuZ2V0U3RhdGUoKS50b2tlbiB8fCAodHlwZW9mIGxvY2FsU3RvcmFnZSAhPT0gJ3VuZGVmaW5lZCcgPyBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKSA6ICcnKSB8fCAnJztcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRBdXRoSGVhZGVycyA9IChleHRyYSA9IHt9KSA9PiB7XHJcbiAgICBjb25zdCB0b2tlbiA9IGdldEZyZXNoVG9rZW4oKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgIC4uLih0b2tlbiAmJiB0b2tlbiAhPT0gJ21vY2stb2ZmbGluZS10b2tlbicgPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KSxcclxuICAgICAgLi4uZXh0cmFcclxuICAgIH07XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGhhbmRsZU9ubGluZSA9ICgpID0+IHtcclxuICAgICAgc2V0SXNPbmxpbmUodHJ1ZSk7XHJcbiAgICAgIC8vIEFsIHJlY3VwZXJhciBjb25leGnDs24sIGludGVudGFyIHNpbmNyb25pemFyIHBlbmRpZW50ZXMgeSBkZXNjYXJnYXIgY2FtYmlvcyBkZWwgc2Vydmlkb3JcclxuICAgICAgY29uc3Qgc3RhdGUgPSB1c2VTdG9yZS5nZXRTdGF0ZSgpO1xyXG4gICAgICBpZiAoc3RhdGUudG9rZW4gJiYgc3RhdGUudG9rZW4gIT09ICdtb2NrLW9mZmxpbmUtdG9rZW4nKSB7XHJcbiAgICAgICAgc3RhdGUucHVsbEluaXRpYWxEYXRhPy4oKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGNvbnN0IGhhbmRsZU9mZmxpbmUgPSAoKSA9PiBzZXRJc09ubGluZShmYWxzZSk7XHJcblxyXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ29ubGluZScsIGhhbmRsZU9ubGluZSk7XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignb2ZmbGluZScsIGhhbmRsZU9mZmxpbmUpO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdvbmxpbmUnLCBoYW5kbGVPbmxpbmUpO1xyXG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignb2ZmbGluZScsIGhhbmRsZU9mZmxpbmUpO1xyXG4gICAgfTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIERpc3BhcmFyIHNpbmNyb25pemFjacOzbiBhdXRvbcOhdGljYSBjdWFuZG8gY2FtYmllIGxhIHJlZCBvIGxhIGNvbGEgZGUgZWxlbWVudG9zXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChpc09ubGluZSAmJiBzeW5jUXVldWUubGVuZ3RoID4gMCAmJiAhaXNTeW5jaW5nUmVmLmN1cnJlbnQpIHtcclxuICAgICAgcHJvY2VzYXJDb2xhU2luY3Jvbml6YWNpb24oKTtcclxuICAgIH1cclxuICB9LCBbaXNPbmxpbmUsIHN5bmNRdWV1ZV0pO1xyXG5cclxuICBjb25zdCBzaW5jcm9uaXphckxvdGUgPSBhc3luYyAobXV0YWNpb25lcykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9zeW5jL2JhdGNoYCwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IGdldEF1dGhIZWFkZXJzKCksXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBtdXRhdGlvbnM6IG11dGFjaW9uZXMgfSlcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDEgfHwgcmVzcG9uc2Uuc3RhdHVzID09PSA0MDMpIHtcclxuICAgICAgICB1c2VTdG9yZS5nZXRTdGF0ZSgpLmhhbmRsZUF1dGhFcnJvcj8uKHJlc3BvbnNlLnN0YXR1cyk7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzIH07XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QganNvbiA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZGF0YToganNvbiB9O1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGRlIHJlZCBlbiBzaW5jcm9uaXphckxvdGU6JywgZXJyKTtcclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIHN0YXR1czogJ05FVFdPUktfRVJST1InIH07XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcHJvY2VzYXJDb2xhU2luY3Jvbml6YWNpb24gPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoaXNTeW5jaW5nUmVmLmN1cnJlbnQpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCB0b2tlbiA9IGdldEZyZXNoVG9rZW4oKTtcclxuICAgIGlmICghdG9rZW4gfHwgdG9rZW4gPT09ICdtb2NrLW9mZmxpbmUtdG9rZW4nKSB7XHJcbiAgICAgIC8vIE1vZG8gb2ZmbGluZSBsb2NhbCBzaW4gYmFja2VuZCBjb25maWd1cmFkb1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaXNTeW5jaW5nUmVmLmN1cnJlbnQgPSB0cnVlO1xyXG4gICAgc2V0SXNTeW5jaW5nKHRydWUpO1xyXG5cclxuICAgIGNvbnN0IGN1cnJlbnRRdWV1ZSA9IFsuLi51c2VTdG9yZS5nZXRTdGF0ZSgpLnN5bmNRdWV1ZV07XHJcbiAgICBpZiAoY3VycmVudFF1ZXVlLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBzZXRJc1N5bmNpbmcoZmFsc2UpO1xyXG4gICAgICBpc1N5bmNpbmdSZWYuY3VycmVudCA9IGZhbHNlO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgLy8gU2VwYXJhciBlbGVtZW50b3Mgc2luIGFyY2hpdm9zIHBhcmEgc2luY3Jvbml6YWNpw7NuIGVuIGxvdGUgKGJhdGNoKSB5IGVsZW1lbnRvcyBjb24gYXJjaGl2b3NcclxuICAgIGNvbnN0IGpzb25NdXRhdGlvbnMgPSBbXTtcclxuICAgIGNvbnN0IHF1ZXVlSXRlbXNNYXAgPSBuZXcgTWFwKCk7XHJcblxyXG4gICAgZm9yIChjb25zdCBpdGVtIG9mIGN1cnJlbnRRdWV1ZSkge1xyXG4gICAgICBpZiAoIWl0ZW0pIGNvbnRpbnVlO1xyXG4gICAgICBcclxuICAgICAgLy8gU2kgZWwgZWxlbWVudG8gdGllbmUgdW4gYXJjaGl2byBkZSBpbWFnZW4gZm90b0Jsb2IsIGRlYmUgZW52aWFyc2UgdmlhIEZvcm1EYXRhXHJcbiAgICAgIGlmIChpdGVtLnBheWxvYWQgJiYgaXRlbS5wYXlsb2FkLmZvdG9CbG9iKSB7XHJcbiAgICAgICAgY29udGludWU7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGxldCBlbnRpdHlOYW1lID0gJ0VsZW1lbnRvVW5pZmlsYXInO1xyXG4gICAgICBpZiAoaXRlbS50aXBvID09PSAnUFJPWUVDVE8nKSBlbnRpdHlOYW1lID0gJ1Byb3llY3RvJztcclxuICAgICAgZWxzZSBpZiAoaXRlbS50aXBvID09PSAnRUxFTUVOVE9fVU5JRklMQVInIHx8IGl0ZW0udGlwbyA9PT0gJ1RBQkxFUk8nKSBlbnRpdHlOYW1lID0gJ0VsZW1lbnRvVW5pZmlsYXInO1xyXG4gICAgICBlbHNlIGlmIChpdGVtLnRpcG8gPT09ICdTVUJFU1RBQ0lPTicpIGVudGl0eU5hbWUgPSAnU3ViZXN0YWNpb24nO1xyXG4gICAgICBlbHNlIGlmIChpdGVtLnRpcG8gPT09ICdQVU5UT19NRURJQ0lPTicpIGVudGl0eU5hbWUgPSAnUHVudG9NZWRpY2lvbic7XHJcbiAgICAgIGVsc2UgaWYgKGl0ZW0udGlwbyA9PT0gJ0NDTScpIGVudGl0eU5hbWUgPSAnQ2NtJztcclxuICAgICAgZWxzZSBpZiAoaXRlbS50aXBvID09PSAnSU5TUEVDQ0lPTl9URVJNT0dSQUZJQ0EnKSBlbnRpdHlOYW1lID0gJ0luc3BlY2Npb25UZXJtb2dyYWZpY2EnO1xyXG4gICAgICBlbHNlIGlmIChpdGVtLnRpcG8gPT09ICdJTlNQRUNDSU9OX0FURVJSQU1JRU5UTycpIGVudGl0eU5hbWUgPSAnSW5zcGVjY2lvbkF0ZXJyYW1pZW50byc7XHJcbiAgICAgIGVsc2UgaWYgKGl0ZW0udGlwbyA9PT0gJ0lOU1BFQ0NJT05fVEFOUVVFX0NPTUJVU1RJQkxFJykgZW50aXR5TmFtZSA9ICdJbnNwZWNjaW9uVGFucXVlQ29tYnVzdGlibGUnO1xyXG5cclxuICAgICAganNvbk11dGF0aW9ucy5wdXNoKHtcclxuICAgICAgICBlbnRpdHk6IGVudGl0eU5hbWUsXHJcbiAgICAgICAgaWQ6IGl0ZW0ucGF5bG9hZD8uaWQgfHwgaXRlbS5pZCxcclxuICAgICAgICBvcGVyYXRpb246IGl0ZW0ub3BlcmF0aW9uIHx8ICdVUFNFUlQnLFxyXG4gICAgICAgIGJhc2VWZXJzaW9uOiBpdGVtLnBheWxvYWQ/LnZlcnNpb24gfHwgMSxcclxuICAgICAgICBkYXRhOiBpdGVtLnBheWxvYWRcclxuICAgICAgfSk7XHJcbiAgICAgIHF1ZXVlSXRlbXNNYXAuc2V0KGl0ZW0ucGF5bG9hZD8uaWQgfHwgaXRlbS5pZCwgaXRlbS5pZCk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGpzb25NdXRhdGlvbnMubGVuZ3RoID4gMCkge1xyXG4gICAgICBjb25zdCBiYXRjaFJlcyA9IGF3YWl0IHNpbmNyb25pemFyTG90ZShqc29uTXV0YXRpb25zKTtcclxuXHJcbiAgICAgIGlmIChiYXRjaFJlcy5zdWNjZXNzKSB7XHJcbiAgICAgICAgLy8gUmVtb3ZlciBkZWwgcXVldWUgbG9jYWwgbG9zIGVsZW1lbnRvcyBwcm9jZXNhZG9zIGV4aXRvc2FtZW50ZVxyXG4gICAgICAgIChiYXRjaFJlcy5kYXRhPy5hcHBsaWVkIHx8IFtdKS5mb3JFYWNoKGFwcEl0ZW0gPT4ge1xyXG4gICAgICAgICAgY29uc3QgcXVldWVJZCA9IHF1ZXVlSXRlbXNNYXAuZ2V0KGFwcEl0ZW0uaWQpO1xyXG4gICAgICAgICAgaWYgKHF1ZXVlSWQpIHJlbW92ZUZyb21RdWV1ZShxdWV1ZUlkKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLy8gTm90aWZpY2FyIGVuIGNvbnNvbGEgc2kgaHVibyBjb25mbGljdG9zIE9DQ1xyXG4gICAgICAgIGlmIChiYXRjaFJlcy5kYXRhPy5jb25mbGljdHMgJiYgYmF0Y2hSZXMuZGF0YS5jb25mbGljdHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgY29uc29sZS53YXJuKCfimqDvuI8gU2UgZGV0ZWN0YXJvbiBjb25mbGljdG9zIE9DQyBhbCBzaW5jcm9uaXphcjonLCBiYXRjaFJlcy5kYXRhLmNvbmZsaWN0cyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2UgaWYgKGJhdGNoUmVzLnN0YXR1cyA9PT0gNDAxIHx8IGJhdGNoUmVzLnN0YXR1cyA9PT0gNDAzKSB7XHJcbiAgICAgICAgY29uc29sZS53YXJuKGBbU1lOQyBBVVRIXSBFcnJvciBIVFRQICR7YmF0Y2hSZXMuc3RhdHVzfTogU2VzacOzbiBleHBpcmFkYS4gUGF1c2FuZG8gc2luY3Jvbml6YWNpw7NuLmApO1xyXG4gICAgICAgIHNldElzU3luY2luZyhmYWxzZSk7XHJcbiAgICAgICAgaXNTeW5jaW5nUmVmLmN1cnJlbnQgPSBmYWxzZTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBQcm9jZXNhciBzZWN1ZW5jaWFsbWVudGUgZWxlbWVudG9zIHJlc3RhbnRlcyAoZWouIGFxdWVsbG9zIGNvbiBmb3RvcylcclxuICAgIHdoaWxlICh1c2VTdG9yZS5nZXRTdGF0ZSgpLnN5bmNRdWV1ZS5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGlmICghbmF2aWdhdG9yLm9uTGluZSkge1xyXG4gICAgICAgIHNldElzT25saW5lKGZhbHNlKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcXVldWVOb3cgPSB1c2VTdG9yZS5nZXRTdGF0ZSgpLnN5bmNRdWV1ZTtcclxuICAgICAgY29uc3QgaXRlbSA9IHF1ZXVlTm93WzBdO1xyXG4gICAgICBpZiAoIWl0ZW0pIGJyZWFrO1xyXG5cclxuICAgICAgbGV0IHJlcyA9IG51bGw7XHJcbiAgICAgIGlmIChpdGVtLnRpcG8gPT09ICdQUk9ZRUNUTycpIHtcclxuICAgICAgICByZXMgPSBhd2FpdCBzaW5jcm9uaXphclByb3llY3RvKGl0ZW0uY29tcGFueUlkLCBpdGVtLnBheWxvYWQpO1xyXG4gICAgICB9IGVsc2UgaWYgKGl0ZW0udGlwbyA9PT0gJ0VMRU1FTlRPX1VOSUZJTEFSJyB8fCBpdGVtLnRpcG8gPT09ICdUQUJMRVJPJykge1xyXG4gICAgICAgIHJlcyA9IGF3YWl0IHNpbmNyb25pemFyRWxlbWVudG9VbmlmaWxhcihpdGVtLmNvbXBhbnlJZCwgaXRlbS5wYXlsb2FkKTtcclxuICAgICAgfSBlbHNlIGlmIChpdGVtLnRpcG8gPT09ICdTVUJFU1RBQ0lPTicpIHtcclxuICAgICAgICByZXMgPSBhd2FpdCBzaW5jcm9uaXphclN1YmVzdGFjaW9uKGl0ZW0uY29tcGFueUlkLCBpdGVtLnBheWxvYWQpO1xyXG4gICAgICB9IGVsc2UgaWYgKGl0ZW0udGlwbyA9PT0gJ1BVTlRPX01FRElDSU9OJykge1xyXG4gICAgICAgIHJlcyA9IGF3YWl0IHNpbmNyb25pemFyUHVudG9NZWRpY2lvbihpdGVtLmNvbXBhbnlJZCwgaXRlbS5wYXlsb2FkKTtcclxuICAgICAgfSBlbHNlIGlmIChpdGVtLnRpcG8gPT09ICdDQ00nKSB7XHJcbiAgICAgICAgcmVzID0gYXdhaXQgc2luY3Jvbml6YXJDY20oaXRlbS5jb21wYW55SWQsIGl0ZW0ucGF5bG9hZCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChyZXMpIHtcclxuICAgICAgICBpZiAocmVzLnN1Y2Nlc3MpIHtcclxuICAgICAgICAgIHJlbW92ZUZyb21RdWV1ZShpdGVtLmlkKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT09ICdORVRXT1JLX0VSUk9SJykgYnJlYWs7XHJcbiAgICAgICAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDAxIHx8IHJlcy5zdGF0dXMgPT09IDQwMykge1xyXG4gICAgICAgICAgICB1c2VTdG9yZS5nZXRTdGF0ZSgpLmhhbmRsZUF1dGhFcnJvcj8uKHJlcy5zdGF0dXMpO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHJlbW92ZUZyb21RdWV1ZShpdGVtLmlkKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVtb3ZlRnJvbVF1ZXVlKGl0ZW0uaWQpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gU2kgbGEgY29sYSBzZSB2YWNpw7MgcG9yIGNvbXBsZXRvLCBhY3R1YWxpemFyIGRhdG9zIGRlc2RlIGVsIHNlcnZpZG9yXHJcbiAgICBpZiAodXNlU3RvcmUuZ2V0U3RhdGUoKS5zeW5jUXVldWUubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHVzZVN0b3JlLmdldFN0YXRlKCkucHVsbEluaXRpYWxEYXRhPy4oKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRJc1N5bmNpbmcoZmFsc2UpO1xyXG4gICAgaXNTeW5jaW5nUmVmLmN1cnJlbnQgPSBmYWxzZTtcclxuICB9O1xyXG5cclxuICBjb25zdCBzaW5jcm9uaXphclByb3llY3RvID0gYXN5bmMgKGVtcHJlc2FJZCwgcHJveWVjdG8pID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgaWQ6IHByb3llY3RvLmlkLFxyXG4gICAgICAgIG5vbWJyZTogcHJveWVjdG8ubm9tYnJlLFxyXG4gICAgICAgIGRlc2NyaXBjaW9uOiBwcm95ZWN0by5kZXNjcmlwY2lvbiB8fCAnJyxcclxuICAgICAgICBlbXByZXNhSWRcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvcHJveWVjdG9zYCwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IGdldEF1dGhIZWFkZXJzKCksXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocGF5bG9hZClcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDEgfHwgcmVzcG9uc2Uuc3RhdHVzID09PSA0MDMpIHtcclxuICAgICAgICB1c2VTdG9yZS5nZXRTdGF0ZSgpLmhhbmRsZUF1dGhFcnJvcj8uKHJlc3BvbnNlLnN0YXR1cyk7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzIH07XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZGUgcmVkIGVuIHNpbmNyb25pemFyUHJveWVjdG86JywgZXJyb3IpO1xyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgc3RhdHVzOiAnTkVUV09SS19FUlJPUicgfTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBzaW5jcm9uaXphckVsZW1lbnRvVW5pZmlsYXIgPSBhc3luYyAoZW1wcmVzYUlkLCBlbGVtZW50bykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgICAgZm9ybURhdGEuYXBwZW5kKCdpZCcsIGVsZW1lbnRvLmlkKTtcclxuICAgICAgZm9ybURhdGEuYXBwZW5kKCdub21icmUnLCBlbGVtZW50by5ub21icmUpO1xyXG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ3RpcG9FbGVtZW50bycsIGVsZW1lbnRvLnRpcG9FbGVtZW50byB8fCAnVEFCTEVSTycpO1xyXG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ViaWNhY2lvbicsIGVsZW1lbnRvLnViaWNhY2lvbiB8fCAnJyk7XHJcbiAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYWxpbWVudGFkb1BvcicsIGVsZW1lbnRvLmFsaW1lbnRhZG9Qb3IgfHwgJycpO1xyXG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ29ic2VydmFjaW9uZXNHZW5lcmFsZXMnLCBlbGVtZW50by5vYnNlcnZhY2lvbmVzR2VuZXJhbGVzIHx8ICcnKTtcclxuICAgICAgZm9ybURhdGEuYXBwZW5kKCdwcm95ZWN0b0lkJywgZWxlbWVudG8ucHJveWVjdG9JZCk7XHJcbiAgICAgIGlmIChlbXByZXNhSWQpIHtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2VtcHJlc2FJZCcsIGVtcHJlc2FJZCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZGF0b3NUZWNuaWNvcycsIEpTT04uc3RyaW5naWZ5KGVsZW1lbnRvLmRhdG9zVGVjbmljb3MgfHwge30pKTtcclxuXHJcbiAgICAgIGlmIChlbGVtZW50by5mb3RvQmxvYikge1xyXG4gICAgICAgIGNvbnN0IGZpbGVFeHQgPSBlbGVtZW50by5mb3RvQmxvYi50eXBlID8gZWxlbWVudG8uZm90b0Jsb2IudHlwZS5zcGxpdCgnLycpWzFdIDogJ2pwZyc7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdmb3RvJywgZWxlbWVudG8uZm90b0Jsb2IsIGBmb3RvXyR7ZWxlbWVudG8uaWR9LiR7ZmlsZUV4dH1gKTtcclxuICAgICAgfSBlbHNlIGlmIChlbGVtZW50by5mb3RvKSB7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdmb3RvVXJsJywgZWxlbWVudG8uZm90byk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHRva2VuID0gZ2V0RnJlc2hUb2tlbigpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2VsZW1lbnRvcy11bmlmaWxhcmVzYCwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIC4uLih0b2tlbiAmJiB0b2tlbiAhPT0gJ21vY2stb2ZmbGluZS10b2tlbicgPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWAgfSA6IHt9KVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keTogZm9ybURhdGFcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDEgfHwgcmVzcG9uc2Uuc3RhdHVzID09PSA0MDMpIHtcclxuICAgICAgICB1c2VTdG9yZS5nZXRTdGF0ZSgpLmhhbmRsZUF1dGhFcnJvcj8uKHJlc3BvbnNlLnN0YXR1cyk7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzIH07XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcmVzSnNvbiA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgaWYgKHJlc0pzb24uZGF0YSAmJiByZXNKc29uLmRhdGEuZm90bykge1xyXG4gICAgICAgIHVzZVN0b3JlLmdldFN0YXRlKCkudXBkYXRlRWxlbWVudG9VbmlmaWxhcihlbGVtZW50by5wcm95ZWN0b0lkLCBlbGVtZW50by5pZCwge1xyXG4gICAgICAgICAgZm90bzogYCR7QVBJX0JBU0VfVVJMfSR7cmVzSnNvbi5kYXRhLmZvdG99YCxcclxuICAgICAgICAgIGZvdG9CbG9iOiBudWxsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGRlIHJlZCBlbiBzaW5jcm9uaXphckVsZW1lbnRvVW5pZmlsYXI6JywgZXJyb3IpO1xyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgc3RhdHVzOiAnTkVUV09SS19FUlJPUicgfTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBzaW5jcm9uaXphclN1YmVzdGFjaW9uID0gYXN5bmMgKGVtcHJlc2FJZCwgc3ViZXN0YWNpb24pID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgaWQ6IHN1YmVzdGFjaW9uLmlkLFxyXG4gICAgICAgIG5vbWJyZTogc3ViZXN0YWNpb24ubm9tYnJlLFxyXG4gICAgICAgIHViaWNhY2lvbjogc3ViZXN0YWNpb24udWJpY2FjaW9uLFxyXG4gICAgICAgIGZlY2hhOiBzdWJlc3RhY2lvbi5mZWNoYSxcclxuICAgICAgICBob3JhOiBzdWJlc3RhY2lvbi5ob3JhLFxyXG4gICAgICAgIGluc3BlY3Rvcjogc3ViZXN0YWNpb24uaW5zcGVjdG9yLFxyXG4gICAgICAgIG5pdmVsVGVuc2lvbjogc3ViZXN0YWNpb24ubml2ZWxUZW5zaW9uLFxyXG4gICAgICAgIGVzdGFkb0VudG9ybm86IHN1YmVzdGFjaW9uLmVzdGFkb0VudG9ybm8sXHJcbiAgICAgICAgb2JyYXNDaXZpbGVzOiBzdWJlc3RhY2lvbi5vYnJhc0NpdmlsZXMsXHJcbiAgICAgICAgZXF1aXBvc1ByaW5jaXBhbGVzOiBzdWJlc3RhY2lvbi5lcXVpcG9zUHJpbmNpcGFsZXMsXHJcbiAgICAgICAgcHVlc3RhVGllcnJhOiBzdWJlc3RhY2lvbi5wdWVzdGFUaWVycmEsXHJcbiAgICAgICAgZWRpZmljaW9Db250cm9sOiBzdWJlc3RhY2lvbi5lZGlmaWNpb0NvbnRyb2wsXHJcbiAgICAgICAgZmlybWFJbnNwZWN0b3I6IHN1YmVzdGFjaW9uLmZpcm1hSW5zcGVjdG9yIHx8IG51bGwsXHJcbiAgICAgICAgZmlybWFTdXBlcnZpc29yOiBzdWJlc3RhY2lvbi5maXJtYVN1cGVydmlzb3IgfHwgbnVsbCxcclxuICAgICAgICBwcm95ZWN0b0lkOiBzdWJlc3RhY2lvbi5wcm95ZWN0b0lkLFxyXG4gICAgICAgIGVtcHJlc2FJZFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9zdWJlc3RhY2lvbmVzYCwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IGdldEF1dGhIZWFkZXJzKCksXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocGF5bG9hZClcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDEgfHwgcmVzcG9uc2Uuc3RhdHVzID09PSA0MDMpIHtcclxuICAgICAgICB1c2VTdG9yZS5nZXRTdGF0ZSgpLmhhbmRsZUF1dGhFcnJvcj8uKHJlc3BvbnNlLnN0YXR1cyk7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzIH07XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZGUgcmVkIGVuIHNpbmNyb25pemFyU3ViZXN0YWNpb246JywgZXJyb3IpO1xyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgc3RhdHVzOiAnTkVUV09SS19FUlJPUicgfTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBzaW5jcm9uaXphclB1bnRvTWVkaWNpb24gPSBhc3luYyAoZW1wcmVzYUlkLCBwdW50bykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAuLi5wdW50byxcclxuICAgICAgICBlbXByZXNhSWRcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvcHVudG9zLW1lZGljaW9uYCwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IGdldEF1dGhIZWFkZXJzKCksXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocGF5bG9hZClcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDEgfHwgcmVzcG9uc2Uuc3RhdHVzID09PSA0MDMpIHtcclxuICAgICAgICB1c2VTdG9yZS5nZXRTdGF0ZSgpLmhhbmRsZUF1dGhFcnJvcj8uKHJlc3BvbnNlLnN0YXR1cyk7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzIH07XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZGUgcmVkIGVuIHNpbmNyb25pemFyUHVudG9NZWRpY2lvbjonLCBlcnJvcik7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBzdGF0dXM6ICdORVRXT1JLX0VSUk9SJyB9O1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNpbmNyb25pemFyQ2NtID0gYXN5bmMgKGVtcHJlc2FJZCwgY2NtSXRlbSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAuLi5jY21JdGVtLFxyXG4gICAgICAgIGVtcHJlc2FJZFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9L2FwaS9jY21gLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVyczogZ2V0QXV0aEhlYWRlcnMoKSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwYXlsb2FkKVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwMSB8fCByZXNwb25zZS5zdGF0dXMgPT09IDQwMykge1xyXG4gICAgICAgIHVzZVN0b3JlLmdldFN0YXRlKCkuaGFuZGxlQXV0aEVycm9yPy4ocmVzcG9uc2Uuc3RhdHVzKTtcclxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1cyB9O1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBkZSByZWQgZW4gc2luY3Jvbml6YXJDY206JywgZXJyb3IpO1xyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgc3RhdHVzOiAnTkVUV09SS19FUlJPUicgfTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4ge1xyXG4gICAgaXNPbmxpbmUsXHJcbiAgICBpc1N5bmNpbmcsXHJcbiAgICBwZW5kaW5nQ291bnQ6IHN5bmNRdWV1ZS5sZW5ndGgsXHJcbiAgICB0cmlnZ2VyU3luYzogcHJvY2VzYXJDb2xhU2luY3Jvbml6YWNpb24sXHJcbiAgICBzeW5jUGVuZGluZ0RhdGE6IHByb2Nlc2FyQ29sYVNpbmNyb25pemFjaW9uLFxyXG4gICAgcHVsbEluaXRpYWxEYXRhOiAoKSA9PiB1c2VTdG9yZS5nZXRTdGF0ZSgpLnB1bGxJbml0aWFsRGF0YT8uKClcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTeW5jO1xyXG5cclxuIl19