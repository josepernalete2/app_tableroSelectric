import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/InformeCompiladoView.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport10_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f49807c8";
import useStore, { formatElementTitleWithId } from "/src/store/useStore.js?t=1790792337841";
import TableroComponent from "/src/components/TableroComponent.jsx?t=1790793566895";
import FichaTecnicaComponent from "/src/components/FichaTecnicaComponent.jsx?t=1790793862643";
import SubestacionComponent from "/src/components/SubestacionComponent.jsx?t=1790793566895";
import PuntoMedicionComponent from "/src/components/PuntoMedicionComponent.jsx?t=1790793566895";
import CcmComponent from "/src/components/CcmComponent.jsx?t=1790793566895";
import DiagramaUnifilarBlueprint from "/src/components/DiagramaUnifilarBlueprint.jsx?t=1790792337841";
import { ArrowLeft, Printer, BookOpen, FileText, Zap, Building, Gauge, Award, User, Calendar, Layers, Cpu, ShieldAlert, RefreshCw, Edit, Check } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/InformeCompiladoView.jsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function InformeCompiladoView() {
	_s();
	const { companyId, proyectoId } = useParams();
	const navigate = useNavigate();
	const { companies, updateElementoUnifilar, updateSubestacion, updatePuntoMedicion, updateCcm } = useStore();
	const company = companies.find((c) => c.id === companyId);
	const proyecto = company?.proyectos?.find((p) => p.id === proyectoId);
	// Modo Edición del Informe
	const [isEditingReport, setIsEditingReport] = useState(false);
	const [coverTitle, setCoverTitle] = useState("INFORME TÉCNICO\nDIAGRAMA UNIFILAR");
	const [coverSubtitle, setCoverSubtitle] = useState("Evaluación y Resultados de Inspección de Campo");
	const [introText, setIntroText] = useState("");
	// Sync introText when company and proyecto load
	useEffect(() => {
		if (company && proyecto && !introText) {
			setIntroText(`En el presente informe técnico se documenta la inspección y levantamiento del diagrama unifilar del sistema eléctrico de ${company.nombre}, correspondiente al proyecto de ${proyecto.nombre}.\n\nLas actividades de evaluación en campo se enfocaron en auditar la distribución de cargas, calibres de acometidas, protecciones termomagnéticas y sistemas de seguridad como la puesta a tierra de equipos principales y condiciones de obras civiles en subestaciones.\n\nTodos los análisis se realizan siguiendo las directrices técnicas del Código Eléctrico Nacional vigente para garantizar la integridad humana y operativa.`);
		}
	}, [
		company,
		proyecto,
		introText
	]);
	useEffect(() => {
		// Scroll to top on load
		window.scrollTo(0, 0);
	}, []);
	if (!company || !proyecto) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center p-6 text-center space-y-4",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-lg font-bold",
				children: "Proyecto o Empresa no encontrado"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => navigate(`/empresa/${companyId || ""}`),
				className: "px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs rounded-xl font-bold transition-all",
				children: "Volver"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 7
		}, this);
	}
	const elementos = proyecto.elementosUnifilares || proyecto.tableros || [];
	const subestaciones = proyecto.inspeccionesSubestacion || proyecto.subestaciones || [];
	const puntosMedicion = proyecto.puntosMedicion || [];
	const ccmList = proyecto.ccmList || [];
	const transformadores = elementos.filter((e) => e.tipoElemento === "TRANSFORMADOR");
	const generadores = elementos.filter((e) => e.tipoElemento === "GENERADOR");
	const transferencias = elementos.filter((e) => e.tipoElemento === "TRANSFER");
	const tableros = elementos.filter((e) => e.tipoElemento === "TABLERO");
	const bancosCondensadores = elementos.filter((e) => e.tipoElemento === "BANCO_CONDENSADOR");
	const puestasTierra = elementos.filter((e) => e.tipoElemento === "PUESTA_TIERRA");
	const otros = elementos.filter((e) => e.tipoElemento === "OTRO");
	// Year for cover page
	const currentYear = new Date().getFullYear();
	// Handle printing
	const handlePrint = () => {
		setIsEditingReport(false);
		setTimeout(() => {
			window.print();
		}, 150);
	};
	const handleUpdateElemento = (elementoId, updatedData) => {
		const { id, nombre, ubicacion, alimentadoPor, foto, fotoBlob, observacionesGenerales, ...datosTecnicos } = updatedData;
		updateElementoUnifilar(proyectoId, elementoId, {
			nombre,
			ubicacion,
			alimentadoPor,
			foto,
			fotoBlob,
			observacionesGenerales,
			datosTecnicos
		});
	};
	const handleUpdateSubestacion = (subestacionId, updatedData) => {
		updateSubestacion(proyectoId, subestacionId, updatedData);
	};
	const handleUpdateElementoObservaciones = (elementoId, obs) => {
		const el = elementos.find((item) => item.id === elementoId);
		if (!el) return;
		handleUpdateElemento(elementoId, {
			...el,
			observacionesGenerales: obs
		});
	};
	const handleUpdateSubestacionObservaciones = (subestacionId, obs) => {
		const sub = subestaciones.find((item) => item.id === subestacionId);
		if (!sub) return;
		handleUpdateSubestacion(subestacionId, {
			...sub,
			observacionesGenerales: obs
		});
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border-b border-slate-800 px-6 py-4 flex items-center justify-between shadow-md no-print sticky top-0 z-50",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => navigate(`/empresa/${companyId}/proyecto/${proyectoId}`),
					className: "p-2 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-slate-200 transition-colors cursor-pointer border border-slate-850",
					title: "Volver al Proyecto",
					children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider block",
					children: "Generador de Reportes"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("h1", {
					className: "text-sm font-bold text-slate-100",
					children: ["Informe Técnico Compilado: ", proyecto.nombre]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 145,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 141,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 133,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setIsEditingReport(!isEditingReport),
					className: `px-4 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-2 text-xs font-bold shadow-md ${isEditingReport ? "bg-emerald-600 hover:bg-emerald-500 text-white" : "bg-slate-800 hover:bg-slate-750 text-slate-100 border border-slate-700"}`,
					children: isEditingReport ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 animate-bounce" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 162,
						columnNumber: 17
					}, this), "Guardar / Bloquear Informe"] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Edit, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 167,
						columnNumber: 17
					}, this), "Editar Informe"] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 152,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: handlePrint,
					className: "px-4 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 rounded-xl transition-all cursor-pointer flex items-center gap-2 text-xs font-black shadow-md",
					children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 13
					}, this), "Imprimir / Guardar PDF"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 151,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 132,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full max-w-5xl mx-auto p-4 md:p-8 space-y-12 bg-slate-900/40 md:rounded-3xl border border-slate-900/60 my-6 shadow-2xl print:my-0 print:p-0 print:border-none print:bg-white print:text-black print:shadow-none print:max-w-full",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "min-h-[90vh] flex flex-col justify-between items-center py-16 px-8 text-center bg-slate-950 print:bg-white print:text-black print:min-h-screen page-break-avoid",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-full text-left",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold text-amber-500 uppercase tracking-widest print:text-slate-500",
								children: "Reporte de Ingeniería Eléctrica"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-6 my-auto w-full max-w-2xl flex flex-col items-center",
							children: [
								isEditingReport ? /* @__PURE__ */ _jsxDEV("textarea", {
									value: coverTitle,
									onChange: (e) => setCoverTitle(e.target.value),
									rows: 2,
									className: "w-full bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-white font-black text-center text-3xl uppercase rounded-xl p-3 outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 15
								}, this) : /* @__PURE__ */ _jsxDEV("h1", {
									className: "text-4xl md:text-5xl font-black uppercase tracking-tight text-white print:text-slate-950 font-sans leading-none whitespace-pre-line",
									children: coverTitle
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 203,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { className: "w-24 h-1.5 bg-amber-500 mx-auto rounded-full" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 208,
									columnNumber: 13
								}, this),
								isEditingReport ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: coverSubtitle,
									onChange: (e) => setCoverSubtitle(e.target.value),
									className: "w-full bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-slate-300 text-center text-sm font-medium tracking-wide uppercase rounded-xl p-2 outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 211,
									columnNumber: 15
								}, this) : /* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-400 print:text-slate-600 text-sm font-medium tracking-wide uppercase",
									children: coverSubtitle
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 194,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 border-t border-slate-800 pt-8 w-full print:border-gray-200",
							children: [
								/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-md font-bold text-slate-100 print:text-slate-900",
									children: company.nombre.toUpperCase()
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 225,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-semibold text-slate-400 print:text-slate-600",
									children: ["PROYECTO: ", proyecto.nombre.toUpperCase()]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-mono text-slate-500 print:text-slate-500",
									children: currentYear
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "page-break min-h-[90vh] flex flex-col justify-between py-12 px-6 print:min-h-screen",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-8",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "border-b border-slate-800 pb-4 print:border-gray-300",
							children: /* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold uppercase tracking-wider text-amber-500 print:text-slate-900",
								children: "Tabla de Contenido"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 235,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4 font-sans text-sm text-slate-350 print:text-slate-800",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-200 print:text-slate-950",
											children: "1. INTRODUCCIÓN"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 240,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 241,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 242,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-200 print:text-slate-950",
											children: "2. SISTEMA DE ALIMENTACIÓN"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 245,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 246,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 247,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 244,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2 pl-4",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "Puntos de Suministro / Acometida" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 250,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 251,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 252,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 249,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2 pl-4",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "Transformadores" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 255,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 256,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 257,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 254,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2 pl-4",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "Generadores" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 260,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 261,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 262,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2 pl-4",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "Transferencias (ATS / MTS)" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 265,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 266,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 267,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2 pl-4",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "Tableros Eléctricos" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 270,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 271,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 272,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 269,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2 pl-4",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "Bancos de Condensadores" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 275,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 276,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 277,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 274,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2 pl-4",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "Centros de Control de Motores (CCM)" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 280,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 281,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 282,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2 pl-4",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "Sistemas de Puesta a Tierra (PAT / Telurometría)" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 285,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 286,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 287,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 284,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-200 print:text-slate-950",
											children: "3. JERARQUÍA DEL DIAGRAMA UNIFILAR"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 290,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 291,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 4"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 292,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 289,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-200 print:text-slate-950",
											children: "4. RESULTADOS DE LAS INSPECCIONES TÉCNICAS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 296,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 297,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. 5"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 298,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 295,
									columnNumber: 15
								}, this),
								elementos.map((item, idx) => /* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2 pl-4 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "truncate",
											children: [
												item.nombre,
												" (",
												item.tipoElemento,
												")"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 302,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-850 flex-1 h-1 min-w-[20px] print:border-gray-200" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 303,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: ["Reg. ", idx + 1]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 304,
											columnNumber: 19
										}, this)
									]
								}, item.id, true, {
									fileName: _jsxFileName,
									lineNumber: 301,
									columnNumber: 17
								}, this)),
								subestaciones.map((sub, idx) => /* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2 pl-4 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "truncate",
											children: ["Inspección Subestación: ", sub.nombre]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 309,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-850 flex-1 h-1 min-w-[20px] print:border-gray-200" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 310,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: ["Sub. ", idx + 1]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 311,
											columnNumber: 19
										}, this)
									]
								}, sub.id, true, {
									fileName: _jsxFileName,
									lineNumber: 308,
									columnNumber: 17
								}, this)),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-200 print:text-slate-950",
											children: "5. RECOMENDACIONES GENERALES"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 316,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 317,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. Final"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 318,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 315,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-end gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-200 print:text-slate-950",
											children: "6. RESUMEN EJECUTIVO DE HALLAZGOS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 321,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "border-b border-dashed border-slate-800 flex-1 h-1 min-w-[20px] print:border-gray-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 322,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono",
											children: "Pág. Final"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 323,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 320,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 232,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "page-break py-12 px-6 space-y-8 print:text-black",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-3 print:text-slate-950 print:border-gray-300",
							children: "1. Introducción"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 332,
							columnNumber: 13
						}, this), isEditingReport ? /* @__PURE__ */ _jsxDEV("textarea", {
							value: introText,
							onChange: (e) => setIntroText(e.target.value),
							rows: 8,
							className: "w-full bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-slate-100 rounded-xl p-4 text-xs font-sans leading-relaxed outline-none"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 336,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-slate-350 text-justify leading-relaxed print:text-slate-800 whitespace-pre-wrap",
							children: introText
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 343,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 331,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6 pt-4",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-3 print:text-slate-950 print:border-gray-300",
								children: "2. Sistema de Alimentación"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 350,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold uppercase tracking-wider text-amber-500/80 print:text-slate-700",
									children: "Puntos de Suministro / Acometida"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 356,
									columnNumber: 15
								}, this), puntosMedicion.length > 0 ? /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-xs text-left border border-slate-800 print:border-gray-300",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-slate-950 text-[10px] font-bold uppercase tracking-wider text-slate-400 print:bg-gray-100 print:text-slate-700",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Nombre / Tag"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 361,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Empresa Distribuidora"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 362,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Nivel Tensión"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 363,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Potencia Contratada"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 364,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Tipo Medición"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 365,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 360,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 359,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-slate-850 print:divide-gray-255 text-slate-300 print:text-slate-800",
										children: puntosMedicion.map((e) => /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5 font-bold",
												children: e.nombre
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 371,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.empresaDistribuidora || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 372,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.nivelTensionContrato || e.tensionNominal || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 373,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.potenciaContratada || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 374,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.tipoMedicion || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 375,
												columnNumber: 25
											}, this)
										] }, e.id, true, {
											fileName: _jsxFileName,
											lineNumber: 370,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 368,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 358,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-550 italic",
									children: "No se registraron puntos de medición específicos en este proyecto."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 381,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 355,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold uppercase tracking-wider text-amber-500/80 print:text-slate-700",
									children: "Transformadores"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 387,
									columnNumber: 15
								}, this), transformadores.length > 0 ? /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-xs text-left border border-slate-800 print:border-gray-300",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-slate-950 text-[10px] font-bold uppercase tracking-wider text-slate-400 print:bg-gray-100 print:text-slate-700",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Nombre"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 392,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Ubicación"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 393,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Capacidad"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 394,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Marca"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 395,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Conexión"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 396,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 391,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 390,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-slate-850 print:divide-gray-255 text-slate-300 print:text-slate-800",
										children: transformadores.map((e) => /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5 font-bold",
												children: e.nombre
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 402,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.ubicacion
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 403,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.kva || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 404,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.marca || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 405,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.conexion || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 406,
												columnNumber: 25
											}, this)
										] }, e.id, true, {
											fileName: _jsxFileName,
											lineNumber: 401,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 399,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 389,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-550 italic",
									children: "No se registraron transformadores específicos en este proyecto."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 412,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 386,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold uppercase tracking-wider text-amber-500/80 print:text-slate-700",
									children: "Generadores"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 418,
									columnNumber: 15
								}, this), generadores.length > 0 ? /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-xs text-left border border-slate-800 print:border-gray-300",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-slate-950 text-[10px] font-bold uppercase tracking-wider text-slate-400 print:bg-gray-100 print:text-slate-700",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Nombre"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 423,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Ubicación"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 424,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Potencia (KVA)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 425,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Combustible"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 426,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Amperaje"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 427,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 422,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 421,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-slate-850 print:divide-gray-255 text-slate-300 print:text-slate-800",
										children: generadores.map((e) => /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5 font-bold",
												children: e.nombre
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 433,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.ubicacion
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 434,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.kva || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 435,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.combustible || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 436,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.amperaje || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 437,
												columnNumber: 25
											}, this)
										] }, e.id, true, {
											fileName: _jsxFileName,
											lineNumber: 432,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 430,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 420,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-550 italic",
									children: "No se registraron generadores en este proyecto."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 443,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 417,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold uppercase tracking-wider text-amber-500/80 print:text-slate-700",
									children: "Transferencias (ATS / MTS)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 449,
									columnNumber: 15
								}, this), transferencias.length > 0 ? /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-xs text-left border border-slate-800 print:border-gray-300",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-slate-950 text-[10px] font-bold uppercase tracking-wider text-slate-400 print:bg-gray-100 print:text-slate-700",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Nombre"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 454,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Tipo"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 455,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Capacidad (A)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 456,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Marca / Controlador"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 457,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Ubicación"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 458,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 453,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 452,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-slate-850 print:divide-gray-255 text-slate-300 print:text-slate-800",
										children: transferencias.map((e) => /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5 font-bold",
												children: e.nombre
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 464,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.tipoTransferencia || e.datosTecnicos?.tipo || "Automática (ATS)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 465,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.amperajeNominal || e.datosTecnicos?.amperaje || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 466,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.marcaControlador || e.datosTecnicos?.marca || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 467,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.ubicacion || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 468,
												columnNumber: 25
											}, this)
										] }, e.id, true, {
											fileName: _jsxFileName,
											lineNumber: 463,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 461,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 451,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-550 italic",
									children: "No se registraron transferencias en este proyecto."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 474,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 448,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold uppercase tracking-wider text-amber-500/80 print:text-slate-700",
									children: "Tableros Eléctricos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 480,
									columnNumber: 15
								}, this), tableros.length > 0 ? /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-xs text-left border border-slate-800 print:border-gray-300",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-slate-950 text-[10px] font-bold uppercase tracking-wider text-slate-400 print:bg-gray-100 print:text-slate-700",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Nombre"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 485,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Ubicación"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 486,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Polos Máx"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 487,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Alimentador"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 488,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 484,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 483,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-slate-850 print:divide-gray-255 text-slate-300 print:text-slate-800",
										children: tableros.map((e) => /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5 font-bold",
												children: e.nombre
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 494,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.ubicacion
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 495,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.maxPoles || "30"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 496,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.alimentadoPor || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 497,
												columnNumber: 25
											}, this)
										] }, e.id, true, {
											fileName: _jsxFileName,
											lineNumber: 493,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 491,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 482,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-550 italic",
									children: "No se registraron tableros eléctricos en este proyecto."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 503,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 479,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold uppercase tracking-wider text-amber-500/80 print:text-slate-700",
									children: "Bancos de Condensadores (Compensación Reactiva)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 509,
									columnNumber: 15
								}, this), bancosCondensadores.length > 0 ? /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-xs text-left border border-slate-800 print:border-gray-300",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-slate-950 text-[10px] font-bold uppercase tracking-wider text-slate-400 print:bg-gray-100 print:text-slate-700",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Nombre / Tag"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 514,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Ubicación"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 515,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Capacidad Total"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 516,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Tipo / Pasos"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 517,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Tensión"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 518,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 513,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 512,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-slate-850 print:divide-gray-255 text-slate-300 print:text-slate-800",
										children: bancosCondensadores.map((e) => /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5 font-bold",
												children: e.nombre
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 524,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.ubicacion
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 525,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.potenciaReactivaTotal ? `${e.datosTecnicos.potenciaReactivaTotal} kVAR` : "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 526,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: [
													e.datosTecnicos?.tipoCompensacion || "Automática",
													" ",
													e.datosTecnicos?.numPasos ? `(${e.datosTecnicos.numPasos} pasos)` : ""
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 527,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.datosTecnicos?.tensionNominal || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 528,
												columnNumber: 25
											}, this)
										] }, e.id, true, {
											fileName: _jsxFileName,
											lineNumber: 523,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 521,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 511,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-550 italic",
									children: "No se registraron bancos de condensadores en este proyecto."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 534,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 508,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold uppercase tracking-wider text-amber-500/80 print:text-slate-700",
									children: "Centros de Control de Motores (CCM)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 540,
									columnNumber: 15
								}, this), ccmList.length > 0 ? /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-xs text-left border border-slate-800 print:border-gray-300",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-slate-950 text-[10px] font-bold uppercase tracking-wider text-slate-400 print:bg-gray-100 print:text-slate-700",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Tag CCM"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 545,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Planta / Área"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 546,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Marca / Modelo"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 547,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Nivel Tensión"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 548,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Gavetas / Buckets"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 549,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 544,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 543,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-slate-850 print:divide-gray-255 text-slate-300 print:text-slate-800",
										children: ccmList.map((e) => /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5 font-bold",
												children: e.nombre
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 555,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.plantaInstalacion || e.areaProceso || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 556,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.fabricanteMarca || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 557,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.parametrosElectricos?.tensionNominal || "480 V"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 558,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "p-2.5",
												children: e.gavetasBucketLog?.length ? `${e.gavetasBucketLog.length} gavetas` : "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 559,
												columnNumber: 25
											}, this)
										] }, e.id, true, {
											fileName: _jsxFileName,
											lineNumber: 554,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 552,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 542,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-550 italic",
									children: "No se registraron centros de control de motores en este proyecto."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 565,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 539,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold uppercase tracking-wider text-amber-500/80 print:text-slate-700",
									children: "Sistemas de Puesta a Tierra (PAT / Telurometría)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 571,
									columnNumber: 15
								}, this), puestasTierra.length > 0 ? /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-xs text-left border border-slate-800 print:border-gray-300",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-slate-950 text-[10px] font-bold uppercase tracking-wider text-slate-400 print:bg-gray-100 print:text-slate-700",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Nombre / Tag"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 576,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Ubicación / Equipo"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 577,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Resistencia Medida"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 578,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Conformidad Normativa"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 579,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-2.5 border-b border-slate-800 print:border-gray-300",
												children: "Tipo Sistema / Varillas"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 580,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 575,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 574,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-slate-850 print:divide-gray-255 text-slate-300 print:text-slate-800",
										children: puestasTierra.map((e) => {
											const res = parseFloat(e.datosTecnicos?.resistenciaOhms || e.datosTecnicos?.resistencia);
											const isNorm = !isNaN(res) ? res <= 5 ? "🟢 Conforme (≤5.0 Ω)" : res <= 10 ? "🟡 Aceptable (≤10.0 Ω)" : "🔴 No Conforme (>10.0 Ω)" : "—";
											return /* @__PURE__ */ _jsxDEV("tr", { children: [
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-2.5 font-bold",
													children: e.nombre
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 589,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-2.5",
													children: e.ubicacion || e.datosTecnicos?.equipoVinculado || "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 590,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-2.5 font-mono font-bold text-amber-400 print:text-black",
													children: !isNaN(res) ? `${res} Ω` : "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 591,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-2.5 font-bold",
													children: isNorm
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 594,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-2.5",
													children: [
														e.datosTecnicos?.tipoSistemaPat || "Malla PAT",
														" ",
														e.datosTecnicos?.numVarillas ? `(${e.datosTecnicos.numVarillas} picas)` : ""
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 597,
													columnNumber: 27
												}, this)
											] }, e.id, true, {
												fileName: _jsxFileName,
												lineNumber: 588,
												columnNumber: 25
											}, this);
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 583,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 573,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-550 italic",
									children: "No se registraron sistemas de puesta a tierra en este proyecto."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 604,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 570,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 349,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 330,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "page-break py-12 px-6 space-y-6 print:text-black",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border-b border-slate-800 pb-3 print:border-gray-300",
							children: /* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold uppercase tracking-wider text-amber-500 print:text-slate-950",
								children: "3. Jerarquía y Diagrama Unifilar Gráfico"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 613,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 612,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-slate-350 print:text-slate-800 mb-6",
							children: "A continuación se presenta de forma jerárquica las relaciones de alimentación entre los equipos registrados en el sistema, mostrando el flujo de potencia aguas abajo y el plano CAD unifilar correspondiente:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 618,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-full bg-white text-black rounded-2xl shadow-inner border border-slate-200 print:border-none p-4 overflow-x-auto",
							children: /* @__PURE__ */ _jsxDEV(DiagramaUnifilarBlueprint, {
								elementos,
								companyName: company.nombre,
								projectName: proyecto.nombre,
								interactive: false
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 623,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 622,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-950 p-6 rounded-2xl border border-slate-850 space-y-4 print:bg-slate-50 print:border-gray-300 no-print",
							children: elementos.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: elementos.map((e) => {
									const feeds = elementos.filter((child) => child.alimentadoPor === e.nombre);
									return /* @__PURE__ */ _jsxDEV("div", {
										className: "border-l-2 border-amber-500/30 pl-4 py-1.5 space-y-2",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-bold text-slate-100 print:text-slate-900 uppercase",
													children: e.nombre
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 640,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[9px] px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400 uppercase font-mono print:bg-white print:border-gray-300",
													children: e.tipoElemento
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 643,
													columnNumber: 25
												}, this),
												e.alimentadoPor && /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[9px] text-slate-500 font-medium",
													children: [
														"(Alimentado por: ",
														e.alimentadoPor,
														")"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 647,
													columnNumber: 27
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 639,
											columnNumber: 23
										}, this), feeds.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
											className: "pl-6 space-y-1",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[9px] font-bold text-slate-500 uppercase block",
												children: "Alimenta a:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 655,
												columnNumber: 27
											}, this), feeds.map((child) => /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 text-xs text-slate-400 print:text-slate-700",
												children: [
													/* @__PURE__ */ _jsxDEV("span", { children: "↳" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 658,
														columnNumber: 31
													}, this),
													/* @__PURE__ */ _jsxDEV("span", {
														className: "font-bold",
														children: child.nombre
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 659,
														columnNumber: 31
													}, this),
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-[8px] px-1 bg-slate-900 text-slate-500 rounded uppercase font-mono print:bg-white print:border-gray-200 border border-slate-850",
														children: child.tipoElemento
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 660,
														columnNumber: 31
													}, this)
												]
											}, child.id, true, {
												fileName: _jsxFileName,
												lineNumber: 657,
												columnNumber: 29
											}, this))]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 654,
											columnNumber: 25
										}, this)]
									}, e.id, true, {
										fileName: _jsxFileName,
										lineNumber: 638,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 633,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 italic text-center",
								children: "No hay suficientes elementos para trazar la jerarquía."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 672,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 631,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 611,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-12",
					children: [
						elementos.map((item, idx) => {
							const isTablero = item.tipoElemento === "TABLERO";
							const enrichedElement = isTablero ? {
								id: item.id,
								nombre: item.nombre,
								ubicacion: item.ubicacion,
								alimentadoPor: item.alimentadoPor,
								foto: item.foto,
								fotoBlob: item.fotoBlob,
								observacionesGenerales: item.observacionesGenerales,
								...item.datosTecnicos,
								nombreEmpresa: company.nombre
							} : item;
							return /* @__PURE__ */ _jsxDEV("div", {
								className: "page-break pt-8 space-y-6",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "border-b border-slate-800 pb-3 flex justify-between items-center print:border-gray-300 no-print",
									children: [/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-lg font-bold text-amber-500 uppercase tracking-wide",
										children: [
											"Inspección #",
											idx + 1,
											": ",
											formatElementTitleWithId(item.nombre, item.id),
											" (",
											item.tipoElemento,
											")"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 698,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-amber-400 font-mono font-bold bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded",
										children: ["ID: ", item.id]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 701,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 697,
									columnNumber: 17
								}, this), isTablero ? /* @__PURE__ */ _jsxDEV("div", {
									className: isEditingReport ? "" : "pointer-events-none select-none",
									children: /* @__PURE__ */ _jsxDEV(TableroComponent, {
										tableroData: enrichedElement,
										onUpdateTablero: (updatedData) => handleUpdateElemento(item.id, updatedData)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 707,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 706,
									columnNumber: 19
								}, this) : /* @__PURE__ */ _jsxDEV("div", {
									className: isEditingReport ? "" : "pointer-events-none select-none",
									children: /* @__PURE__ */ _jsxDEV(FichaTecnicaComponent, {
										elementoData: enrichedElement,
										onUpdate: (updatedData) => handleUpdateElemento(item.id, updatedData)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 714,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 713,
									columnNumber: 19
								}, this)]
							}, item.id, true, {
								fileName: _jsxFileName,
								lineNumber: 696,
								columnNumber: 15
							}, this);
						}),
						subestaciones.map((sub, idx) => /* @__PURE__ */ _jsxDEV("div", {
							className: "page-break pt-8 space-y-6",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "border-b border-slate-800 pb-3 flex justify-between items-center print:border-gray-300 no-print",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-bold text-amber-500 uppercase tracking-wide",
									children: [
										"Subestación #",
										idx + 1,
										": ",
										formatElementTitleWithId(sub.nombre, sub.id)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 728,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-amber-400 font-mono font-bold bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded",
									children: ["ID: ", sub.id]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 731,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 727,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: isEditingReport ? "" : "pointer-events-none select-none",
								children: /* @__PURE__ */ _jsxDEV(SubestacionComponent, {
									subestacionData: sub,
									onUpdate: (updatedData) => handleUpdateSubestacion(sub.id, updatedData)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 735,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 734,
								columnNumber: 15
							}, this)]
						}, sub.id, true, {
							fileName: _jsxFileName,
							lineNumber: 726,
							columnNumber: 13
						}, this)),
						puntosMedicion.map((pm, idx) => /* @__PURE__ */ _jsxDEV("div", {
							className: "page-break pt-8 space-y-6",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "border-b border-slate-800 pb-3 flex justify-between items-center print:border-gray-300 no-print",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-bold text-amber-500 uppercase tracking-wide",
									children: [
										"Punto de Medición #",
										idx + 1,
										": ",
										formatElementTitleWithId(pm.nombre, pm.id)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 747,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-amber-400 font-mono font-bold bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded",
									children: ["ID: ", pm.id]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 750,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 746,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: isEditingReport ? "" : "pointer-events-none select-none",
								children: /* @__PURE__ */ _jsxDEV(PuntoMedicionComponent, {
									puntoData: pm,
									onUpdate: (updatedData) => updatePuntoMedicion(proyectoId, pm.id, updatedData)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 754,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 753,
								columnNumber: 15
							}, this)]
						}, pm.id, true, {
							fileName: _jsxFileName,
							lineNumber: 745,
							columnNumber: 13
						}, this)),
						ccmList.map((ccm, idx) => /* @__PURE__ */ _jsxDEV("div", {
							className: "page-break pt-8 space-y-6",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "border-b border-slate-800 pb-3 flex justify-between items-center print:border-gray-300 no-print",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-bold text-amber-500 uppercase tracking-wide",
									children: [
										"CCM #",
										idx + 1,
										": ",
										formatElementTitleWithId(ccm.nombre, ccm.id)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 766,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-amber-400 font-mono font-bold bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded",
									children: ["ID: ", ccm.id]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 769,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 765,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: isEditingReport ? "" : "pointer-events-none select-none",
								children: /* @__PURE__ */ _jsxDEV(CcmComponent, {
									ccmData: ccm,
									onUpdate: (updatedData) => updateCcm(proyectoId, ccm.id, updatedData)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 773,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 772,
								columnNumber: 15
							}, this)]
						}, ccm.id, true, {
							fileName: _jsxFileName,
							lineNumber: 764,
							columnNumber: 13
						}, this))
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 678,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "page-break py-12 px-6 space-y-6 print:text-black",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "border-b border-slate-800 pb-3 print:border-gray-300",
						children: /* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-bold uppercase tracking-wider text-amber-500 print:text-slate-950",
							children: "5. Recomendaciones Generales"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 785,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 784,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4 text-sm text-slate-350 print:text-slate-800",
						children: elementos.some((e) => e.observacionesGenerales) ? elementos.filter((e) => e.observacionesGenerales).map((e) => /* @__PURE__ */ _jsxDEV("div", {
							className: "border-l-2 border-amber-500 pl-4 py-1 space-y-1",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-slate-100 print:text-slate-900 block text-xs uppercase",
								children: [e.nombre, ":"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 794,
								columnNumber: 19
							}, this), isEditingReport ? /* @__PURE__ */ _jsxDEV("textarea", {
								value: e.observacionesGenerales || "",
								onChange: (eVal) => handleUpdateElementoObservaciones(e.id, eVal.target.value),
								placeholder: "Modifique recomendaciones...",
								rows: 2,
								className: "w-full bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-slate-100 rounded px-2 py-1 text-xs outline-none"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 796,
								columnNumber: 21
							}, this) : /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 print:text-slate-700 italic",
								children: [
									"\"",
									e.observacionesGenerales,
									"\""
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 804,
								columnNumber: 21
							}, this)]
						}, e.id, true, {
							fileName: _jsxFileName,
							lineNumber: 793,
							columnNumber: 17
						}, this)) : /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-550 italic text-center",
							children: "No se ingresaron recomendaciones detalladas individuales."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 809,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 790,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 783,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "page-break py-12 px-6 space-y-6 print:text-black",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "border-b border-slate-800 pb-3 print:border-gray-300",
						children: /* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-bold uppercase tracking-wider text-amber-500 print:text-slate-950",
							children: "6. Resumen de Hallazgos y Recomendaciones"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 817,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 816,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-xs text-left border border-slate-800 print:border-gray-300",
						children: [/* @__PURE__ */ _jsxDEV("thead", {
							className: "bg-slate-950 text-[10px] font-bold uppercase tracking-wider text-slate-400 print:bg-gray-100 print:text-slate-700",
							children: /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("th", {
								className: "p-3 border-b border-slate-800 print:border-gray-300 w-1/4",
								children: "Área / Equipo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 825,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("th", {
								className: "p-3 border-b border-slate-800 print:border-gray-300",
								children: "Observaciones y Recomendaciones Técnicas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 826,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 824,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 823,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-850 print:divide-gray-255 text-slate-350 print:text-slate-800",
							children: [elementos.map((e) => /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 font-bold uppercase",
								children: [
									e.nombre,
									" (",
									e.tipoElemento,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 832,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 whitespace-pre-line leading-relaxed",
								children: isEditingReport ? /* @__PURE__ */ _jsxDEV("textarea", {
									value: e.observacionesGenerales || "",
									onChange: (eVal) => handleUpdateElementoObservaciones(e.id, eVal.target.value),
									placeholder: "Edite los hallazgos del equipo...",
									rows: 3,
									className: "w-full bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-slate-100 rounded px-2 py-1 text-xs outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 835,
									columnNumber: 23
								}, this) : e.observacionesGenerales || "El equipo presenta buen estado general de estructura y cableado. Cumple con normas operativas."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 833,
								columnNumber: 19
							}, this)] }, e.id, true, {
								fileName: _jsxFileName,
								lineNumber: 831,
								columnNumber: 17
							}, this)), subestaciones.map((s) => /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 font-bold uppercase",
								children: ["SUBESTACIÓN: ", s.nombre]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 850,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("td", {
								className: "p-3 whitespace-pre-line leading-relaxed",
								children: isEditingReport ? /* @__PURE__ */ _jsxDEV("textarea", {
									value: s.observacionesGenerales || "",
									onChange: (eVal) => handleUpdateSubestacionObservaciones(s.id, eVal.target.value),
									placeholder: "Edite los hallazgos de la subestación...",
									rows: 3,
									className: "w-full bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-slate-100 rounded px-2 py-1 text-xs outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 853,
									columnNumber: 23
								}, this) : s.observacionesGenerales || "Obras civiles e infraestructura física en buenas condiciones generales."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 851,
								columnNumber: 19
							}, this)] }, s.id, true, {
								fileName: _jsxFileName,
								lineNumber: 849,
								columnNumber: 17
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 829,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 822,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 815,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 184,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 129,
		columnNumber: 5
	}, this);
}
_s(InformeCompiladoView, "YGRhRpC9cznZbZ/Ly5Yr3Ps6j2w=", false, function() {
	return [
		useParams,
		useNavigate,
		useStore
	];
});
_c = InformeCompiladoView;
var _c;
$RefreshReg$(_c, "InformeCompiladoView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/views/InformeCompiladoView.jsx?t=1790793862643";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/InformeCompiladoView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/InformeCompiladoView.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/InformeCompiladoView.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsV0FBVyxtQkFBbUI7QUFDdkMsT0FBTyxZQUFZLGdDQUFnQztBQUNuRCxPQUFPLHNCQUFzQjtBQUM3QixPQUFPLDJCQUEyQjtBQUNsQyxPQUFPLDBCQUEwQjtBQUNqQyxPQUFPLDRCQUE0QjtBQUNuQyxPQUFPLGtCQUFrQjtBQUN6QixPQUFPLCtCQUErQjtBQUN0QyxTQUNFLFdBQ0EsU0FDQSxVQUNBLFVBQ0EsS0FDQSxVQUNBLE9BQ0EsT0FDQSxNQUNBLFVBQ0EsUUFDQSxLQUNBLGFBQ0EsV0FDQSxNQUNBLGFBQ0s7Ozs7QUFFUCxlQUFlLFNBQVMsdUJBQXVCOztDQUM3QyxNQUFNLEVBQUUsV0FBVyxlQUFlLFVBQVU7Q0FDNUMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxFQUFFLFdBQVcsd0JBQXdCLG1CQUFtQixxQkFBcUIsY0FBYyxTQUFTO0NBRTFHLE1BQU0sVUFBVSxVQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sU0FBUztDQUN4RCxNQUFNLFdBQVcsU0FBUyxXQUFXLE1BQU0sTUFBTSxFQUFFLE9BQU8sVUFBVTs7Q0FHcEUsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBQzVELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLG9DQUFvQztDQUNqRixNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxnREFBZ0Q7Q0FDbkcsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTs7Q0FHN0MsZ0JBQWdCO0VBQ2QsSUFBSSxXQUFXLFlBQVksQ0FBQyxXQUFXO0dBQ3JDLGFBQ0UsNEhBQTRILFFBQVEsT0FBTyxtQ0FBbUMsU0FBUyxPQUFPLHlhQUNoTTtFQUNGO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBVTtDQUFTLENBQUM7Q0FFakMsZ0JBQWdCOztFQUVkLE9BQU8sU0FBUyxHQUFHLENBQUM7Q0FDdEIsR0FBRyxDQUFDLENBQUM7Q0FFTCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVU7RUFDekIsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBb0I7R0FBb0M7Ozs7YUFDdEUsd0JBQUMsVUFBRDtJQUNFLGVBQWUsU0FBUyxZQUFZLGFBQWEsSUFBSTtJQUNyRCxXQUFVO2NBQ1g7R0FFTzs7OztXQUNMOzs7Ozs7Q0FFVDtDQUVBLE1BQU0sWUFBWSxTQUFTLHVCQUF1QixTQUFTLFlBQVksQ0FBQztDQUN4RSxNQUFNLGdCQUFnQixTQUFTLDJCQUEyQixTQUFTLGlCQUFpQixDQUFDO0NBQ3JGLE1BQU0saUJBQWlCLFNBQVMsa0JBQWtCLENBQUM7Q0FDbkQsTUFBTSxVQUFVLFNBQVMsV0FBVyxDQUFDO0NBRXJDLE1BQU0sa0JBQWtCLFVBQVUsUUFBTyxNQUFLLEVBQUUsaUJBQWlCLGVBQWU7Q0FDaEYsTUFBTSxjQUFjLFVBQVUsUUFBTyxNQUFLLEVBQUUsaUJBQWlCLFdBQVc7Q0FDeEUsTUFBTSxpQkFBaUIsVUFBVSxRQUFPLE1BQUssRUFBRSxpQkFBaUIsVUFBVTtDQUMxRSxNQUFNLFdBQVcsVUFBVSxRQUFPLE1BQUssRUFBRSxpQkFBaUIsU0FBUztDQUNuRSxNQUFNLHNCQUFzQixVQUFVLFFBQU8sTUFBSyxFQUFFLGlCQUFpQixtQkFBbUI7Q0FDeEYsTUFBTSxnQkFBZ0IsVUFBVSxRQUFPLE1BQUssRUFBRSxpQkFBaUIsZUFBZTtDQUM5RSxNQUFNLFFBQVEsVUFBVSxRQUFPLE1BQUssRUFBRSxpQkFBaUIsTUFBTTs7Q0FHN0QsTUFBTSxjQUFjLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTs7Q0FHM0MsTUFBTSxvQkFBb0I7RUFDeEIsbUJBQW1CLEtBQUs7RUFDeEIsaUJBQWlCO0dBQ2YsT0FBTyxNQUFNO0VBQ2YsR0FBRyxHQUFHO0NBQ1I7Q0FFQSxNQUFNLHdCQUF3QixZQUFZLGdCQUFnQjtFQUN4RCxNQUFNLEVBQ0osSUFBSSxRQUFRLFdBQVcsZUFBZSxNQUFNLFVBQVUsd0JBQ3RELEdBQUcsa0JBQ0Q7RUFFSix1QkFBdUIsWUFBWSxZQUFZO0dBQzdDO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0YsQ0FBQztDQUNIO0NBRUEsTUFBTSwyQkFBMkIsZUFBZSxnQkFBZ0I7RUFDOUQsa0JBQWtCLFlBQVksZUFBZSxXQUFXO0NBQzFEO0NBRUEsTUFBTSxxQ0FBcUMsWUFBWSxRQUFRO0VBQzdELE1BQU0sS0FBSyxVQUFVLE1BQUssU0FBUSxLQUFLLE9BQU8sVUFBVTtFQUN4RCxJQUFJLENBQUMsSUFBSTtFQUNULHFCQUFxQixZQUFZO0dBQUUsR0FBRztHQUFJLHdCQUF3QjtFQUFJLENBQUM7Q0FDekU7Q0FFQSxNQUFNLHdDQUF3QyxlQUFlLFFBQVE7RUFDbkUsTUFBTSxNQUFNLGNBQWMsTUFBSyxTQUFRLEtBQUssT0FBTyxhQUFhO0VBQ2hFLElBQUksQ0FBQyxLQUFLO0VBQ1Ysd0JBQXdCLGVBQWU7R0FBRSxHQUFHO0dBQUssd0JBQXdCO0VBQUksQ0FBQztDQUNoRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUdFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsVUFBRDtLQUNFLGVBQWUsU0FBUyxZQUFZLFVBQVUsWUFBWSxZQUFZO0tBQ3RFLFdBQVU7S0FDVixPQUFNO2VBRU4sd0JBQUMsV0FBRCxFQUFXLFdBQVUsVUFBVzs7Ozs7SUFDMUI7Ozs7Y0FDUix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBc0U7SUFFaEY7Ozs7Y0FDTix3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkLENBQWlELCtCQUNuQixTQUFTLE1BQ25DOzs7OztZQUNEOzs7O1lBQ0Y7Ozs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxlQUFlLG1CQUFtQixDQUFDLGVBQWU7S0FDbEQsV0FBVywwR0FDVCxrQkFDSSxtREFDQTtlQUdMLGtCQUNDLGdEQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7OztlQUFDLDRCQUU1Qzs7OztnQkFFRixnREFDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSx5QkFBMEI7Ozs7ZUFBQyxnQkFFM0M7Ozs7O0lBRUU7Ozs7Y0FFUix3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7ZUFGWixDQUlFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7ZUFBQyx3QkFFekI7Ozs7O1lBQ0w7Ozs7O1dBQ0Y7Ozs7O1lBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUdFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBa0Y7T0FFNUY7Ozs7O01BQ0g7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRyxrQkFDQyx3QkFBQyxZQUFEO1NBQ0UsT0FBTztTQUNQLFdBQVcsTUFBTSxjQUFjLEVBQUUsT0FBTyxLQUFLO1NBQzdDLE1BQU07U0FDTixXQUFVO1FBQ1g7Ozs7bUJBRUQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1g7UUFDQzs7Ozs7UUFHTix3QkFBQyxPQUFELEVBQUssV0FBVSwrQ0FBb0Q7Ozs7O1FBRWxFLGtCQUNDLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7U0FDaEQsV0FBVTtRQUNYOzs7O21CQUVELHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWO1FBQ0E7Ozs7O09BRUY7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXlELFFBQVEsT0FBTyxZQUFZO1FBQU07Ozs7O1FBQ3hHLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiLENBQXlFLGNBQVcsU0FBUyxPQUFPLFlBQVksQ0FBSzs7Ozs7O1FBQ3JILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5RDtRQUFlOzs7OztPQUNsRjs7Ozs7O0tBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBaUY7T0FBc0I7Ozs7O01BQ2xIOzs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZ0Q7VUFBcUI7Ozs7O1VBQ3JGLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHdGQUE4Rjs7Ozs7VUFDOUcsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQVk7VUFBWTs7Ozs7U0FDckM7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWdEO1VBQWdDOzs7OztVQUNoRyx3QkFBQyxRQUFELEVBQU0sV0FBVSx3RkFBOEY7Ozs7O1VBQzlHLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFZO1VBQVk7Ozs7O1NBQ3JDOzs7Ozs7UUFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFFBQUQsWUFBTSxtQ0FBc0M7Ozs7O1VBQzVDLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHdGQUE4Rjs7Ozs7VUFDOUcsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQVk7VUFBWTs7Ozs7U0FDckM7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7Ozs7VUFDM0Isd0JBQUMsUUFBRCxFQUFNLFdBQVUsd0ZBQThGOzs7OztVQUM5Ryx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBWTtVQUFZOzs7OztTQUNyQzs7Ozs7O1FBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7O1VBQ3ZCLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHdGQUE4Rjs7Ozs7VUFDOUcsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQVk7VUFBWTs7Ozs7U0FDckM7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRCxZQUFNLDZCQUFnQzs7Ozs7VUFDdEMsd0JBQUMsUUFBRCxFQUFNLFdBQVUsd0ZBQThGOzs7OztVQUM5Ryx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBWTtVQUFZOzs7OztTQUNyQzs7Ozs7O1FBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7OztVQUMvQix3QkFBQyxRQUFELEVBQU0sV0FBVSx3RkFBOEY7Ozs7O1VBQzlHLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFZO1VBQVk7Ozs7O1NBQ3JDOzs7Ozs7UUFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFFBQUQsWUFBTSwwQkFBNkI7Ozs7O1VBQ25DLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHdGQUE4Rjs7Ozs7VUFDOUcsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQVk7VUFBWTs7Ozs7U0FDckM7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRCxZQUFNLHNDQUF5Qzs7Ozs7VUFDL0Msd0JBQUMsUUFBRCxFQUFNLFdBQVUsd0ZBQThGOzs7OztVQUM5Ryx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBWTtVQUFZOzs7OztTQUNyQzs7Ozs7O1FBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxRQUFELFlBQU0sbURBQXNEOzs7OztVQUM1RCx3QkFBQyxRQUFELEVBQU0sV0FBVSx3RkFBOEY7Ozs7O1VBQzlHLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFZO1VBQVk7Ozs7O1NBQ3JDOzs7Ozs7UUFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFnRDtVQUF3Qzs7Ozs7VUFDeEcsd0JBQUMsUUFBRCxFQUFNLFdBQVUsd0ZBQThGOzs7OztVQUM5Ryx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBWTtVQUFZOzs7OztTQUNyQzs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZ0Q7VUFBZ0Q7Ozs7O1VBQ2hILHdCQUFDLFFBQUQsRUFBTSxXQUFVLHdGQUE4Rjs7Ozs7VUFDOUcsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQVk7VUFBWTs7Ozs7U0FDckM7Ozs7OztRQUNKLFVBQVUsS0FBSyxNQUFNLFFBQ3BCLHdCQUFDLE9BQUQ7U0FBbUIsV0FBVTttQkFBN0I7VUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFBNEIsS0FBSztZQUFPO1lBQUcsS0FBSztZQUFhO1dBQU87Ozs7OztVQUNwRSx3QkFBQyxRQUFELEVBQU0sV0FBVSx3RkFBOEY7Ozs7O1VBQzlHLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUE0QixTQUFNLE1BQU0sQ0FBUTs7Ozs7O1NBQzdDO1dBSkssS0FBSzs7OztlQUlWLENBQ047UUFDQSxjQUFjLEtBQUssS0FBSyxRQUN2Qix3QkFBQyxPQUFEO1NBQWtCLFdBQVU7bUJBQTVCO1VBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQTJCLDRCQUF5QixJQUFJLE1BQWE7Ozs7OztVQUNyRSx3QkFBQyxRQUFELEVBQU0sV0FBVSx3RkFBOEY7Ozs7O1VBQzlHLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUE0QixTQUFNLE1BQU0sQ0FBUTs7Ozs7O1NBQzdDO1dBSkssSUFBSTs7OztlQUlULENBQ047UUFFRCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFnRDtVQUFrQzs7Ozs7VUFDbEcsd0JBQUMsUUFBRCxFQUFNLFdBQVUsd0ZBQThGOzs7OztVQUM5Ryx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBWTtVQUFnQjs7Ozs7U0FDekM7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWdEO1VBQXVDOzs7OztVQUN2Ryx3QkFBQyxRQUFELEVBQU0sV0FBVSx3RkFBOEY7Ozs7O1VBQzlHLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFZO1VBQWdCOzs7OztTQUN6Qzs7Ozs7O09BQ0Y7Ozs7O2NBQ0Y7Ozs7OztJQUNGOzs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFzSTtNQUVoSjs7OztnQkFDSCxrQkFDQyx3QkFBQyxZQUFEO09BQ0UsT0FBTztPQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO09BQzVDLE1BQU07T0FDTixXQUFVO01BQ1g7Ozs7aUJBRUQsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1Y7TUFDQTs7OztjQUVGOzs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXNJO09BRWhKOzs7OztPQUdKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW9GO1FBQW9DOzs7O2tCQUNySSxlQUFlLFNBQVMsSUFDdkIsd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQ2Ysd0JBQUMsTUFBRDtXQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUFnQjs7Ozs7V0FDdEYsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQXlCOzs7OztXQUMvRix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBaUI7Ozs7O1dBQ3ZGLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUF1Qjs7Ozs7V0FDN0Ysd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQWlCOzs7OztVQUNyRjs7Ozs7U0FDQzs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFDZCxlQUFlLEtBQUksTUFDbEIsd0JBQUMsTUFBRDtXQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFtQixFQUFFO1dBQVc7Ozs7O1dBQzlDLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsd0JBQXdCO1dBQVE7Ozs7O1dBQ3pELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsd0JBQXdCLEVBQUUsa0JBQWtCO1dBQVE7Ozs7O1dBQzdFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsc0JBQXNCO1dBQVE7Ozs7O1dBQ3ZELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsZ0JBQWdCO1dBQVE7Ozs7O1VBQy9DLEtBTkssRUFBRTs7OztpQkFNUCxDQUNMO1NBQ0k7Ozs7aUJBQ0Y7Ozs7O21CQUVQLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFnQztRQUFxRTs7OztnQkFFakg7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW9GO1FBQW1COzs7O2tCQUNwSCxnQkFBZ0IsU0FBUyxJQUN4Qix3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFDZix3QkFBQyxNQUFEO1dBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQVU7Ozs7O1dBQ2hGLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUFhOzs7OztXQUNuRix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBYTs7Ozs7V0FDbkYsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQVM7Ozs7O1dBQy9FLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUFZOzs7OztVQUNoRjs7Ozs7U0FDQzs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFDZCxnQkFBZ0IsS0FBSSxNQUNuQix3QkFBQyxNQUFEO1dBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQW1CLEVBQUU7V0FBVzs7Ozs7V0FDOUMsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQVMsRUFBRTtXQUFjOzs7OztXQUN2Qyx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUyxFQUFFLGVBQWUsT0FBTztXQUFROzs7OztXQUN2RCx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUyxFQUFFLGVBQWUsU0FBUztXQUFROzs7OztXQUN6RCx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUyxFQUFFLGVBQWUsWUFBWTtXQUFROzs7OztVQUMxRCxLQU5LLEVBQUU7Ozs7aUJBTVAsQ0FDTDtTQUNJOzs7O2lCQUNGOzs7OzttQkFFUCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBZ0M7UUFBa0U7Ozs7Z0JBRTlHOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFvRjtRQUFlOzs7O2tCQUNoSCxZQUFZLFNBQVMsSUFDcEIsd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQ2Ysd0JBQUMsTUFBRDtXQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUFVOzs7OztXQUNoRix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBYTs7Ozs7V0FDbkYsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQWtCOzs7OztXQUN4Rix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBZTs7Ozs7V0FDckYsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQVk7Ozs7O1VBQ2hGOzs7OztTQUNDOzs7O21CQUNQLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUNkLFlBQVksS0FBSSxNQUNmLHdCQUFDLE1BQUQ7V0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBbUIsRUFBRTtXQUFXOzs7OztXQUM5Qyx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUyxFQUFFO1dBQWM7Ozs7O1dBQ3ZDLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsZUFBZSxPQUFPO1dBQVE7Ozs7O1dBQ3ZELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsZUFBZSxlQUFlO1dBQVE7Ozs7O1dBQy9ELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsZUFBZSxZQUFZO1dBQVE7Ozs7O1VBQzFELEtBTkssRUFBRTs7OztpQkFNUCxDQUNMO1NBQ0k7Ozs7aUJBQ0Y7Ozs7O21CQUVQLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFnQztRQUFrRDs7OztnQkFFOUY7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW9GO1FBQThCOzs7O2tCQUMvSCxlQUFlLFNBQVMsSUFDdkIsd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQ2Ysd0JBQUMsTUFBRDtXQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUFVOzs7OztXQUNoRix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBUTs7Ozs7V0FDOUUsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQWlCOzs7OztXQUN2Rix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBdUI7Ozs7O1dBQzdGLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUFhOzs7OztVQUNqRjs7Ozs7U0FDQzs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFDZCxlQUFlLEtBQUksTUFDbEIsd0JBQUMsTUFBRDtXQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFtQixFQUFFO1dBQVc7Ozs7O1dBQzlDLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsZUFBZSxxQkFBcUIsRUFBRSxlQUFlLFFBQVE7V0FBdUI7Ozs7O1dBQzdHLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsZUFBZSxtQkFBbUIsRUFBRSxlQUFlLFlBQVk7V0FBUTs7Ozs7V0FDaEcsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQVMsRUFBRSxlQUFlLG9CQUFvQixFQUFFLGVBQWUsU0FBUztXQUFROzs7OztXQUM5Rix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUyxFQUFFLGFBQWE7V0FBUTs7Ozs7VUFDNUMsS0FOSyxFQUFFOzs7O2lCQU1QLENBQ0w7U0FDSTs7OztpQkFDRjs7Ozs7bUJBRVAsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWdDO1FBQXFEOzs7O2dCQUVqRzs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBb0Y7UUFBdUI7Ozs7a0JBQ3hILFNBQVMsU0FBUyxJQUNqQix3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFDZix3QkFBQyxNQUFEO1dBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQVU7Ozs7O1dBQ2hGLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUFhOzs7OztXQUNuRix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBYTs7Ozs7V0FDbkYsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQWU7Ozs7O1VBQ25GOzs7OztTQUNDOzs7O21CQUNQLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUNkLFNBQVMsS0FBSSxNQUNaLHdCQUFDLE1BQUQ7V0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBbUIsRUFBRTtXQUFXOzs7OztXQUM5Qyx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUyxFQUFFO1dBQWM7Ozs7O1dBQ3ZDLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsZUFBZSxZQUFZO1dBQVM7Ozs7O1dBQzdELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsaUJBQWlCO1dBQVE7Ozs7O1VBQ2hELEtBTEssRUFBRTs7OztpQkFLUCxDQUNMO1NBQ0k7Ozs7aUJBQ0Y7Ozs7O21CQUVQLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFnQztRQUEwRDs7OztnQkFFdEc7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW9GO1FBQW1EOzs7O2tCQUNwSixvQkFBb0IsU0FBUyxJQUM1Qix3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFDZix3QkFBQyxNQUFEO1dBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQWdCOzs7OztXQUN0Rix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBYTs7Ozs7V0FDbkYsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQW1COzs7OztXQUN6Rix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBZ0I7Ozs7O1dBQ3RGLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUFXOzs7OztVQUMvRTs7Ozs7U0FDQzs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFDZCxvQkFBb0IsS0FBSSxNQUN2Qix3QkFBQyxNQUFEO1dBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQW1CLEVBQUU7V0FBVzs7Ozs7V0FDOUMsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQVMsRUFBRTtXQUFjOzs7OztXQUN2Qyx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUyxFQUFFLGVBQWUsd0JBQXdCLEdBQUcsRUFBRSxjQUFjLHNCQUFzQixTQUFTO1dBQVE7Ozs7O1dBQzFILHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFkO2FBQXVCLEVBQUUsZUFBZSxvQkFBb0I7YUFBYTthQUFFLEVBQUUsZUFBZSxXQUFXLElBQUksRUFBRSxjQUFjLFNBQVMsV0FBVztZQUFPOzs7Ozs7V0FDdEosd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQVMsRUFBRSxlQUFlLGtCQUFrQjtXQUFROzs7OztVQUNoRSxLQU5LLEVBQUU7Ozs7aUJBTVAsQ0FDTDtTQUNJOzs7O2lCQUNGOzs7OzttQkFFUCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBZ0M7UUFBOEQ7Ozs7Z0JBRTFHOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFvRjtRQUF1Qzs7OztrQkFDeEksUUFBUSxTQUFTLElBQ2hCLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUNmLHdCQUFDLE1BQUQ7V0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBVzs7Ozs7V0FDakYsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQWlCOzs7OztXQUN2Rix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBa0I7Ozs7O1dBQ3hGLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUFpQjs7Ozs7V0FDdkYsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQXFCOzs7OztVQUN6Rjs7Ozs7U0FDQzs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFDZCxRQUFRLEtBQUksTUFDWCx3QkFBQyxNQUFEO1dBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQW1CLEVBQUU7V0FBVzs7Ozs7V0FDOUMsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQVMsRUFBRSxxQkFBcUIsRUFBRSxlQUFlO1dBQVE7Ozs7O1dBQ3ZFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsbUJBQW1CO1dBQVE7Ozs7O1dBQ3BELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFTLEVBQUUsc0JBQXNCLGtCQUFrQjtXQUFZOzs7OztXQUM3RSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUyxFQUFFLGtCQUFrQixTQUFTLEdBQUcsRUFBRSxpQkFBaUIsT0FBTyxZQUFZO1dBQVE7Ozs7O1VBQ25HLEtBTkssRUFBRTs7OztpQkFNUCxDQUNMO1NBQ0k7Ozs7aUJBQ0Y7Ozs7O21CQUVQLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFnQztRQUFvRTs7OztnQkFFaEg7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW9GO1FBQW9EOzs7O2tCQUNySixjQUFjLFNBQVMsSUFDdEIsd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQ2Ysd0JBQUMsTUFBRDtXQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUFnQjs7Ozs7V0FDdEYsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQXNCOzs7OztXQUM1Rix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0Q7V0FBc0I7Ozs7O1dBQzVGLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3RDtXQUF5Qjs7Ozs7V0FDL0Ysd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdEO1dBQTJCOzs7OztVQUMvRjs7Ozs7U0FDQzs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFDZCxjQUFjLEtBQUksTUFBSztXQUN0QixNQUFNLE1BQU0sV0FBVyxFQUFFLGVBQWUsbUJBQW1CLEVBQUUsZUFBZSxXQUFXO1dBQ3ZGLE1BQU0sU0FBUyxDQUFDLE1BQU0sR0FBRyxJQUFLLE9BQU8sSUFBTSx5QkFBeUIsT0FBTyxLQUFPLDJCQUEyQiw2QkFBOEI7V0FDM0ksT0FDRSx3QkFBQyxNQUFEO1lBQ0Usd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQW1CLEVBQUU7WUFBVzs7Ozs7WUFDOUMsd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQVMsRUFBRSxhQUFhLEVBQUUsZUFBZSxtQkFBbUI7WUFBUTs7Ozs7WUFDbEYsd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1gsQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLElBQUksTUFBTTtZQUMxQjs7Ozs7WUFDSix3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWDtZQUNDOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFkO2NBQXVCLEVBQUUsZUFBZSxrQkFBa0I7Y0FBWTtjQUFFLEVBQUUsZUFBZSxjQUFjLElBQUksRUFBRSxjQUFjLFlBQVksV0FBVzthQUFPOzs7Ozs7V0FDdkosS0FWSyxFQUFFOzs7O2tCQVVQO1VBRVIsQ0FBQztTQUNJOzs7O2lCQUNGOzs7OzttQkFFUCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBZ0M7UUFBa0U7Ozs7Z0JBRTlHOzs7Ozs7TUFDRjs7Ozs7YUFDRjs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFpRjtPQUUzRjs7Ozs7TUFDRDs7Ozs7TUFFTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBbUQ7TUFFN0Q7Ozs7O01BRUgsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsMkJBQUQ7UUFDYTtRQUNYLGFBQWEsUUFBUTtRQUNyQixhQUFhLFNBQVM7UUFDdEIsYUFBYTtPQUNkOzs7OztNQUNFOzs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLFVBQVUsU0FBUyxJQUNsQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFFWixVQUFVLEtBQUksTUFBSztTQUNsQixNQUFNLFFBQVEsVUFBVSxRQUFPLFVBQVMsTUFBTSxrQkFBa0IsRUFBRSxNQUFNO1NBQ3hFLE9BQ0Usd0JBQUMsT0FBRDtVQUFnQixXQUFVO29CQUExQixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQ2IsRUFBRTtZQUNDOzs7OztZQUNOLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUNiLEVBQUU7WUFDQzs7Ozs7WUFDTCxFQUFFLGlCQUNELHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQjtjQUF3RDtjQUNwQyxFQUFFO2NBQWM7YUFDOUI7Ozs7OztXQUVMOzs7OztvQkFFSixNQUFNLFNBQVMsS0FDZCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFzRDtXQUFpQjs7OztxQkFDdEYsTUFBTSxLQUFJLFVBQ1Qsd0JBQUMsT0FBRDtZQUFvQixXQUFVO3NCQUE5QjthQUNFLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OzthQUNiLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFhLE1BQU07YUFBYTs7Ozs7YUFDaEQsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQ2IsTUFBTTthQUNIOzs7OztZQUNIO2NBTkssTUFBTTs7OztrQkFNWCxDQUNOLENBQ0U7Ozs7O2tCQUVKO1lBN0JLLEVBQUU7Ozs7Z0JBNkJQO1FBRVQsQ0FBQztPQUNFOzs7O2tCQUVMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE0QztPQUF5RDs7Ozs7TUFFakg7Ozs7O0tBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRyxVQUFVLEtBQUssTUFBTSxRQUFRO09BQzVCLE1BQU0sWUFBWSxLQUFLLGlCQUFpQjtPQUV4QyxNQUFNLGtCQUFrQixZQUFZO1FBQ2xDLElBQUksS0FBSztRQUNULFFBQVEsS0FBSztRQUNiLFdBQVcsS0FBSztRQUNoQixlQUFlLEtBQUs7UUFDcEIsTUFBTSxLQUFLO1FBQ1gsVUFBVSxLQUFLO1FBQ2Ysd0JBQXdCLEtBQUs7UUFDN0IsR0FBRyxLQUFLO1FBQ1IsZUFBZSxRQUFRO09BQ3pCLElBQUk7T0FFSixPQUNFLHdCQUFDLE9BQUQ7UUFBbUIsV0FBVTtrQkFBN0IsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkO1dBQXlFO1dBQzFELE1BQU07V0FBRTtXQUFHLHlCQUF5QixLQUFLLFFBQVEsS0FBSyxFQUFFO1dBQUU7V0FBRyxLQUFLO1dBQWE7VUFDMUY7Ozs7O21CQUNKLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUE0SCxRQUFLLEtBQUssRUFBUzs7Ozs7aUJBQzVJOzs7OztrQkFHSixZQUNDLHdCQUFDLE9BQUQ7U0FBSyxXQUFXLGtCQUFrQixLQUFLO21CQUNyQyx3QkFBQyxrQkFBRDtVQUNFLGFBQWE7VUFDYixrQkFBa0IsZ0JBQWdCLHFCQUFxQixLQUFLLElBQUksV0FBVztTQUM1RTs7Ozs7UUFDRTs7OzttQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVyxrQkFBa0IsS0FBSzttQkFDckMsd0JBQUMsdUJBQUQ7VUFDRSxjQUFjO1VBQ2QsV0FBVyxnQkFBZ0IscUJBQXFCLEtBQUssSUFBSSxXQUFXO1NBQ3JFOzs7OztRQUNFOzs7O2dCQUVKO1VBeEJLLEtBQUs7Ozs7Y0F3QlY7TUFFVCxDQUFDO01BR0EsY0FBYyxLQUFLLEtBQUssUUFDdkIsd0JBQUMsT0FBRDtPQUFrQixXQUFVO2lCQUE1QixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQ7VUFBeUU7VUFDekQsTUFBTTtVQUFFO1VBQUcseUJBQXlCLElBQUksUUFBUSxJQUFJLEVBQUU7U0FDbEU7Ozs7O2tCQUNKLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUE0SCxRQUFLLElBQUksRUFBUzs7Ozs7Z0JBQzNJOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVyxrQkFBa0IsS0FBSztrQkFDckMsd0JBQUMsc0JBQUQ7U0FDRSxpQkFBaUI7U0FDakIsV0FBVyxnQkFBZ0Isd0JBQXdCLElBQUksSUFBSSxXQUFXO1FBQ3ZFOzs7OztPQUNFOzs7O2VBQ0Y7U0FkSyxJQUFJOzs7O2FBY1QsQ0FDTjtNQUdBLGVBQWUsS0FBSyxJQUFJLFFBQ3ZCLHdCQUFDLE9BQUQ7T0FBaUIsV0FBVTtpQkFBM0IsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkO1VBQXlFO1VBQ25ELE1BQU07VUFBRTtVQUFHLHlCQUF5QixHQUFHLFFBQVEsR0FBRyxFQUFFO1NBQ3RFOzs7OztrQkFDSix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBNEgsUUFBSyxHQUFHLEVBQVM7Ozs7O2dCQUMxSTs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVcsa0JBQWtCLEtBQUs7a0JBQ3JDLHdCQUFDLHdCQUFEO1NBQ0UsV0FBVztTQUNYLFdBQVcsZ0JBQWdCLG9CQUFvQixZQUFZLEdBQUcsSUFBSSxXQUFXO1FBQzlFOzs7OztPQUNFOzs7O2VBQ0Y7U0FkSyxHQUFHOzs7O2FBY1IsQ0FDTjtNQUdBLFFBQVEsS0FBSyxLQUFLLFFBQ2pCLHdCQUFDLE9BQUQ7T0FBa0IsV0FBVTtpQkFBNUIsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkO1VBQXlFO1VBQ2pFLE1BQU07VUFBRTtVQUFHLHlCQUF5QixJQUFJLFFBQVEsSUFBSSxFQUFFO1NBQzFEOzs7OztrQkFDSix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBNEgsUUFBSyxJQUFJLEVBQVM7Ozs7O2dCQUMzSTs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVcsa0JBQWtCLEtBQUs7a0JBQ3JDLHdCQUFDLGNBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVyxnQkFBZ0IsVUFBVSxZQUFZLElBQUksSUFBSSxXQUFXO1FBQ3JFOzs7OztPQUNFOzs7O2VBQ0Y7U0FkSyxJQUFJOzs7O2FBY1QsQ0FDTjtLQUNFOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWlGO01BRTNGOzs7OztLQUNEOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osVUFBVSxNQUFLLE1BQUssRUFBRSxzQkFBc0IsSUFDM0MsVUFBVSxRQUFPLE1BQUssRUFBRSxzQkFBc0IsQ0FBQyxDQUFDLEtBQUksTUFDbEQsd0JBQUMsT0FBRDtPQUFnQixXQUFVO2lCQUExQixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUF5RixFQUFFLFFBQU8sR0FBTzs7Ozs7aUJBQ3hHLGtCQUNDLHdCQUFDLFlBQUQ7UUFDRSxPQUFPLEVBQUUsMEJBQTBCO1FBQ25DLFdBQVcsU0FBUyxrQ0FBa0MsRUFBRSxJQUFJLEtBQUssT0FBTyxLQUFLO1FBQzdFLGFBQVk7UUFDWixNQUFNO1FBQ04sV0FBVTtPQUNYOzs7O2tCQUVELHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQWtFO1NBQUUsRUFBRTtTQUF1QjtRQUFJOzs7OztlQUVoRztTQWJLLEVBQUU7Ozs7YUFhUCxDQUNOLElBRUQsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTRDO01BQTREOzs7OztLQUVwSDs7OzthQUNGOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWlGO01BRTNGOzs7OztLQUNEOzs7O2VBRUwsd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQ2Ysd0JBQUMsTUFBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUE0RDtPQUFpQjs7OztpQkFDM0Ysd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXNEO09BQTRDOzs7O2VBQzlHOzs7OztNQUNDOzs7O2dCQUNQLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUNHLFVBQVUsS0FBSSxNQUNiLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUF5QyxFQUFFO1NBQU87U0FBRyxFQUFFO1NBQWE7UUFBSzs7Ozs7aUJBQ3pFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLGtCQUNDLHdCQUFDLFlBQUQ7U0FDRSxPQUFPLEVBQUUsMEJBQTBCO1NBQ25DLFdBQVcsU0FBUyxrQ0FBa0MsRUFBRSxJQUFJLEtBQUssT0FBTyxLQUFLO1NBQzdFLGFBQVk7U0FDWixNQUFNO1NBQ04sV0FBVTtRQUNYOzs7O21CQUVELEVBQUUsMEJBQTBCO09BRTVCOzs7O2VBQ0YsS0FmSyxFQUFFOzs7O2NBZVAsQ0FDTCxHQUNBLGNBQWMsS0FBSSxNQUNqQix3QkFBQyxNQUFELGFBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FBd0MsaUJBQWMsRUFBRSxNQUFXOzs7OztpQkFDbkUsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsa0JBQ0Msd0JBQUMsWUFBRDtTQUNFLE9BQU8sRUFBRSwwQkFBMEI7U0FDbkMsV0FBVyxTQUFTLHFDQUFxQyxFQUFFLElBQUksS0FBSyxPQUFPLEtBQUs7U0FDaEYsYUFBWTtTQUNaLE1BQU07U0FDTixXQUFVO1FBQ1g7Ozs7bUJBRUQsRUFBRSwwQkFBMEI7T0FFNUI7Ozs7ZUFDRixLQWZLLEVBQUU7Ozs7Y0FlUCxDQUNMLENBQ0k7Ozs7O2NBQ0Y7Ozs7O2FBQ0o7Ozs7OztHQUVGOzs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJJbmZvcm1lQ29tcGlsYWRvVmlldy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgdXNlU3RvcmUsIHsgZm9ybWF0RWxlbWVudFRpdGxlV2l0aElkIH0gZnJvbSAnLi4vc3RvcmUvdXNlU3RvcmUnO1xuaW1wb3J0IFRhYmxlcm9Db21wb25lbnQgZnJvbSAnLi4vY29tcG9uZW50cy9UYWJsZXJvQ29tcG9uZW50JztcbmltcG9ydCBGaWNoYVRlY25pY2FDb21wb25lbnQgZnJvbSAnLi4vY29tcG9uZW50cy9GaWNoYVRlY25pY2FDb21wb25lbnQnO1xuaW1wb3J0IFN1YmVzdGFjaW9uQ29tcG9uZW50IGZyb20gJy4uL2NvbXBvbmVudHMvU3ViZXN0YWNpb25Db21wb25lbnQnO1xuaW1wb3J0IFB1bnRvTWVkaWNpb25Db21wb25lbnQgZnJvbSAnLi4vY29tcG9uZW50cy9QdW50b01lZGljaW9uQ29tcG9uZW50JztcbmltcG9ydCBDY21Db21wb25lbnQgZnJvbSAnLi4vY29tcG9uZW50cy9DY21Db21wb25lbnQnO1xuaW1wb3J0IERpYWdyYW1hVW5pZmlsYXJCbHVlcHJpbnQgZnJvbSAnLi4vY29tcG9uZW50cy9EaWFncmFtYVVuaWZpbGFyQmx1ZXByaW50JztcbmltcG9ydCB7IFxuICBBcnJvd0xlZnQsIFxuICBQcmludGVyLCBcbiAgQm9va09wZW4sIFxuICBGaWxlVGV4dCwgXG4gIFphcCwgXG4gIEJ1aWxkaW5nLCBcbiAgR2F1Z2UsXG4gIEF3YXJkLCBcbiAgVXNlciwgXG4gIENhbGVuZGFyLFxuICBMYXllcnMsXG4gIENwdSxcbiAgU2hpZWxkQWxlcnQsXG4gIFJlZnJlc2hDdyxcbiAgRWRpdCxcbiAgQ2hlY2tcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW5mb3JtZUNvbXBpbGFkb1ZpZXcoKSB7XG4gIGNvbnN0IHsgY29tcGFueUlkLCBwcm95ZWN0b0lkIH0gPSB1c2VQYXJhbXMoKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCB7IGNvbXBhbmllcywgdXBkYXRlRWxlbWVudG9VbmlmaWxhciwgdXBkYXRlU3ViZXN0YWNpb24sIHVwZGF0ZVB1bnRvTWVkaWNpb24sIHVwZGF0ZUNjbSB9ID0gdXNlU3RvcmUoKTtcblxuICBjb25zdCBjb21wYW55ID0gY29tcGFuaWVzLmZpbmQoKGMpID0+IGMuaWQgPT09IGNvbXBhbnlJZCk7XG4gIGNvbnN0IHByb3llY3RvID0gY29tcGFueT8ucHJveWVjdG9zPy5maW5kKChwKSA9PiBwLmlkID09PSBwcm95ZWN0b0lkKTtcblxuICAvLyBNb2RvIEVkaWNpw7NuIGRlbCBJbmZvcm1lXG4gIGNvbnN0IFtpc0VkaXRpbmdSZXBvcnQsIHNldElzRWRpdGluZ1JlcG9ydF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtjb3ZlclRpdGxlLCBzZXRDb3ZlclRpdGxlXSA9IHVzZVN0YXRlKCdJTkZPUk1FIFTDiUNOSUNPXFxuRElBR1JBTUEgVU5JRklMQVInKTtcbiAgY29uc3QgW2NvdmVyU3VidGl0bGUsIHNldENvdmVyU3VidGl0bGVdID0gdXNlU3RhdGUoJ0V2YWx1YWNpw7NuIHkgUmVzdWx0YWRvcyBkZSBJbnNwZWNjacOzbiBkZSBDYW1wbycpO1xuICBjb25zdCBbaW50cm9UZXh0LCBzZXRJbnRyb1RleHRdID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIFN5bmMgaW50cm9UZXh0IHdoZW4gY29tcGFueSBhbmQgcHJveWVjdG8gbG9hZFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChjb21wYW55ICYmIHByb3llY3RvICYmICFpbnRyb1RleHQpIHtcbiAgICAgIHNldEludHJvVGV4dChcbiAgICAgICAgYEVuIGVsIHByZXNlbnRlIGluZm9ybWUgdMOpY25pY28gc2UgZG9jdW1lbnRhIGxhIGluc3BlY2Npw7NuIHkgbGV2YW50YW1pZW50byBkZWwgZGlhZ3JhbWEgdW5pZmlsYXIgZGVsIHNpc3RlbWEgZWzDqWN0cmljbyBkZSAke2NvbXBhbnkubm9tYnJlfSwgY29ycmVzcG9uZGllbnRlIGFsIHByb3llY3RvIGRlICR7cHJveWVjdG8ubm9tYnJlfS5cXG5cXG5MYXMgYWN0aXZpZGFkZXMgZGUgZXZhbHVhY2nDs24gZW4gY2FtcG8gc2UgZW5mb2Nhcm9uIGVuIGF1ZGl0YXIgbGEgZGlzdHJpYnVjacOzbiBkZSBjYXJnYXMsIGNhbGlicmVzIGRlIGFjb21ldGlkYXMsIHByb3RlY2Npb25lcyB0ZXJtb21hZ27DqXRpY2FzIHkgc2lzdGVtYXMgZGUgc2VndXJpZGFkIGNvbW8gbGEgcHVlc3RhIGEgdGllcnJhIGRlIGVxdWlwb3MgcHJpbmNpcGFsZXMgeSBjb25kaWNpb25lcyBkZSBvYnJhcyBjaXZpbGVzIGVuIHN1YmVzdGFjaW9uZXMuXFxuXFxuVG9kb3MgbG9zIGFuw6FsaXNpcyBzZSByZWFsaXphbiBzaWd1aWVuZG8gbGFzIGRpcmVjdHJpY2VzIHTDqWNuaWNhcyBkZWwgQ8OzZGlnbyBFbMOpY3RyaWNvIE5hY2lvbmFsIHZpZ2VudGUgcGFyYSBnYXJhbnRpemFyIGxhIGludGVncmlkYWQgaHVtYW5hIHkgb3BlcmF0aXZhLmBcbiAgICAgICk7XG4gICAgfVxuICB9LCBbY29tcGFueSwgcHJveWVjdG8sIGludHJvVGV4dF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gU2Nyb2xsIHRvIHRvcCBvbiBsb2FkXG4gICAgd2luZG93LnNjcm9sbFRvKDAsIDApO1xuICB9LCBbXSk7XG5cbiAgaWYgKCFjb21wYW55IHx8ICFwcm95ZWN0bykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC02IHRleHQtY2VudGVyIHNwYWNlLXktNFwiPlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGRcIj5Qcm95ZWN0byBvIEVtcHJlc2Egbm8gZW5jb250cmFkbzwvaDI+XG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9lbXByZXNhLyR7Y29tcGFueUlkIHx8ICcnfWApfSBcbiAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXhzIHJvdW5kZWQteGwgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgPlxuICAgICAgICAgIFZvbHZlclxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBjb25zdCBlbGVtZW50b3MgPSBwcm95ZWN0by5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IHByb3llY3RvLnRhYmxlcm9zIHx8IFtdO1xuICBjb25zdCBzdWJlc3RhY2lvbmVzID0gcHJveWVjdG8uaW5zcGVjY2lvbmVzU3ViZXN0YWNpb24gfHwgcHJveWVjdG8uc3ViZXN0YWNpb25lcyB8fCBbXTtcbiAgY29uc3QgcHVudG9zTWVkaWNpb24gPSBwcm95ZWN0by5wdW50b3NNZWRpY2lvbiB8fCBbXTtcbiAgY29uc3QgY2NtTGlzdCA9IHByb3llY3RvLmNjbUxpc3QgfHwgW107XG5cbiAgY29uc3QgdHJhbnNmb3JtYWRvcmVzID0gZWxlbWVudG9zLmZpbHRlcihlID0+IGUudGlwb0VsZW1lbnRvID09PSAnVFJBTlNGT1JNQURPUicpO1xuICBjb25zdCBnZW5lcmFkb3JlcyA9IGVsZW1lbnRvcy5maWx0ZXIoZSA9PiBlLnRpcG9FbGVtZW50byA9PT0gJ0dFTkVSQURPUicpO1xuICBjb25zdCB0cmFuc2ZlcmVuY2lhcyA9IGVsZW1lbnRvcy5maWx0ZXIoZSA9PiBlLnRpcG9FbGVtZW50byA9PT0gJ1RSQU5TRkVSJyk7XG4gIGNvbnN0IHRhYmxlcm9zID0gZWxlbWVudG9zLmZpbHRlcihlID0+IGUudGlwb0VsZW1lbnRvID09PSAnVEFCTEVSTycpO1xuICBjb25zdCBiYW5jb3NDb25kZW5zYWRvcmVzID0gZWxlbWVudG9zLmZpbHRlcihlID0+IGUudGlwb0VsZW1lbnRvID09PSAnQkFOQ09fQ09OREVOU0FET1InKTtcbiAgY29uc3QgcHVlc3Rhc1RpZXJyYSA9IGVsZW1lbnRvcy5maWx0ZXIoZSA9PiBlLnRpcG9FbGVtZW50byA9PT0gJ1BVRVNUQV9USUVSUkEnKTtcbiAgY29uc3Qgb3Ryb3MgPSBlbGVtZW50b3MuZmlsdGVyKGUgPT4gZS50aXBvRWxlbWVudG8gPT09ICdPVFJPJyk7XG5cbiAgLy8gWWVhciBmb3IgY292ZXIgcGFnZVxuICBjb25zdCBjdXJyZW50WWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKTtcblxuICAvLyBIYW5kbGUgcHJpbnRpbmdcbiAgY29uc3QgaGFuZGxlUHJpbnQgPSAoKSA9PiB7XG4gICAgc2V0SXNFZGl0aW5nUmVwb3J0KGZhbHNlKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHdpbmRvdy5wcmludCgpO1xuICAgIH0sIDE1MCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlVXBkYXRlRWxlbWVudG8gPSAoZWxlbWVudG9JZCwgdXBkYXRlZERhdGEpID0+IHtcbiAgICBjb25zdCB7IFxuICAgICAgaWQsIG5vbWJyZSwgdWJpY2FjaW9uLCBhbGltZW50YWRvUG9yLCBmb3RvLCBmb3RvQmxvYiwgb2JzZXJ2YWNpb25lc0dlbmVyYWxlcywgXG4gICAgICAuLi5kYXRvc1RlY25pY29zIFxuICAgIH0gPSB1cGRhdGVkRGF0YTtcblxuICAgIHVwZGF0ZUVsZW1lbnRvVW5pZmlsYXIocHJveWVjdG9JZCwgZWxlbWVudG9JZCwge1xuICAgICAgbm9tYnJlLFxuICAgICAgdWJpY2FjaW9uLFxuICAgICAgYWxpbWVudGFkb1BvcixcbiAgICAgIGZvdG8sXG4gICAgICBmb3RvQmxvYixcbiAgICAgIG9ic2VydmFjaW9uZXNHZW5lcmFsZXMsXG4gICAgICBkYXRvc1RlY25pY29zXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlVXBkYXRlU3ViZXN0YWNpb24gPSAoc3ViZXN0YWNpb25JZCwgdXBkYXRlZERhdGEpID0+IHtcbiAgICB1cGRhdGVTdWJlc3RhY2lvbihwcm95ZWN0b0lkLCBzdWJlc3RhY2lvbklkLCB1cGRhdGVkRGF0YSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlVXBkYXRlRWxlbWVudG9PYnNlcnZhY2lvbmVzID0gKGVsZW1lbnRvSWQsIG9icykgPT4ge1xuICAgIGNvbnN0IGVsID0gZWxlbWVudG9zLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBlbGVtZW50b0lkKTtcbiAgICBpZiAoIWVsKSByZXR1cm47XG4gICAgaGFuZGxlVXBkYXRlRWxlbWVudG8oZWxlbWVudG9JZCwgeyAuLi5lbCwgb2JzZXJ2YWNpb25lc0dlbmVyYWxlczogb2JzIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZVN1YmVzdGFjaW9uT2JzZXJ2YWNpb25lcyA9IChzdWJlc3RhY2lvbklkLCBvYnMpID0+IHtcbiAgICBjb25zdCBzdWIgPSBzdWJlc3RhY2lvbmVzLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBzdWJlc3RhY2lvbklkKTtcbiAgICBpZiAoIXN1YikgcmV0dXJuO1xuICAgIGhhbmRsZVVwZGF0ZVN1YmVzdGFjaW9uKHN1YmVzdGFjaW9uSWQsIHsgLi4uc3ViLCBvYnNlcnZhY2lvbmVzR2VuZXJhbGVzOiBvYnMgfSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBhbnRpYWxpYXNlZFwiPlxuICAgICAgXG4gICAgICB7LyogQmFycmEgZGUgY29udHJvbCBzdXBlcmlvciAobm8tcHJpbnQpICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBweC02IHB5LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNoYWRvdy1tZCBuby1wcmludCBzdGlja3kgdG9wLTAgei01MFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9lbXByZXNhLyR7Y29tcGFueUlkfS9wcm95ZWN0by8ke3Byb3llY3RvSWR9YCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgaG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgYm9yZGVyIGJvcmRlci1zbGF0ZS04NTBcIlxuICAgICAgICAgICAgdGl0bGU9XCJWb2x2ZXIgYWwgUHJveWVjdG9cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNTAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2tcIj5cbiAgICAgICAgICAgICAgR2VuZXJhZG9yIGRlIFJlcG9ydGVzXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgSW5mb3JtZSBUw6ljbmljbyBDb21waWxhZG86IHtwcm95ZWN0by5ub21icmV9XG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFZGl0aW5nUmVwb3J0KCFpc0VkaXRpbmdSZXBvcnQpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LW1kICR7XG4gICAgICAgICAgICAgIGlzRWRpdGluZ1JlcG9ydCBcbiAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCB0ZXh0LXdoaXRlJyBcbiAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzUwIHRleHQtc2xhdGUtMTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2lzRWRpdGluZ1JlcG9ydCA/IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLWJvdW5jZVwiIC8+XG4gICAgICAgICAgICAgICAgR3VhcmRhciAvIEJsb3F1ZWFyIEluZm9ybWVcbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxFZGl0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgICAgICAgIEVkaXRhciBJbmZvcm1lXG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVByaW50fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgYWN0aXZlOnNjYWxlLTk1IHRleHQtc2xhdGUtOTUwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LWJsYWNrIHNoYWRvdy1tZFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICBJbXByaW1pciAvIEd1YXJkYXIgUERGXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBET0NVTUVOVE8gQ09NUElMQURPIChEaXNlw7FhZG8gcGFyYSBpbXByaW1pciBhIHDDoWdpbmFzIGluZGVwZW5kaWVudGVzKSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LTV4bCBteC1hdXRvIHAtNCBtZDpwLTggc3BhY2UteS0xMiBiZy1zbGF0ZS05MDAvNDAgbWQ6cm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS05MDAvNjAgbXktNiBzaGFkb3ctMnhsIHByaW50Om15LTAgcHJpbnQ6cC0wIHByaW50OmJvcmRlci1ub25lIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtYmxhY2sgcHJpbnQ6c2hhZG93LW5vbmUgcHJpbnQ6bWF4LXctZnVsbFwiPlxuICAgICAgICBcbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFBPUlRBREEgPT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtWzkwdmhdIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0xNiBweC04IHRleHQtY2VudGVyIGJnLXNsYXRlLTk1MCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LWJsYWNrIHByaW50Om1pbi1oLXNjcmVlbiBwYWdlLWJyZWFrLWF2b2lkXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHByaW50OnRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgIFJlcG9ydGUgZGUgSW5nZW5pZXLDrWEgRWzDqWN0cmljYVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IG15LWF1dG8gdy1mdWxsIG1heC13LTJ4bCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAge2lzRWRpdGluZ1JlcG9ydCA/IChcbiAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NvdmVyVGl0bGV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb3ZlclRpdGxlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICByb3dzPXsyfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgdGV4dC13aGl0ZSBmb250LWJsYWNrIHRleHQtY2VudGVyIHRleHQtM3hsIHVwcGVyY2FzZSByb3VuZGVkLXhsIHAtMyBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIG1kOnRleHQtNXhsIGZvbnQtYmxhY2sgdXBwZXJjYXNlIHRyYWNraW5nLXRpZ2h0IHRleHQtd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05NTAgZm9udC1zYW5zIGxlYWRpbmctbm9uZSB3aGl0ZXNwYWNlLXByZS1saW5lXCI+XG4gICAgICAgICAgICAgICAge2NvdmVyVGl0bGV9XG4gICAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjQgaC0xLjUgYmctYW1iZXItNTAwIG14LWF1dG8gcm91bmRlZC1mdWxsXCI+PC9kaXY+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHtpc0VkaXRpbmdSZXBvcnQgPyAoXG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Y292ZXJTdWJ0aXRsZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvdmVyU3VidGl0bGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgdGV4dC1zbGF0ZS0zMDAgdGV4dC1jZW50ZXIgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFja2luZy13aWRlIHVwcGVyY2FzZSByb3VuZGVkLXhsIHAtMiBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS02MDAgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFja2luZy13aWRlIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgIHtjb3ZlclN1YnRpdGxlfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBwdC04IHctZnVsbCBwcmludDpib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LW1kIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBwcmludDp0ZXh0LXNsYXRlLTkwMFwiPntjb21wYW55Lm5vbWJyZS50b1VwcGVyQ2FzZSgpfTwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5QUk9ZRUNUTzoge3Byb3llY3RvLm5vbWJyZS50b1VwcGVyQ2FzZSgpfTwvcD5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtc2xhdGUtNTAwIHByaW50OnRleHQtc2xhdGUtNTAwXCI+e2N1cnJlbnRZZWFyfTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFRBQkxBIERFIENPTlRFTklETyA9PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLWJyZWFrIG1pbi1oLVs5MHZoXSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBweS0xMiBweC02IHByaW50Om1pbi1oLXNjcmVlblwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS04XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItNCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWFtYmVyLTUwMCBwcmludDp0ZXh0LXNsYXRlLTkwMFwiPlRhYmxhIGRlIENvbnRlbmlkbzwvaDI+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgZm9udC1zYW5zIHRleHQtc20gdGV4dC1zbGF0ZS0zNTAgcHJpbnQ6dGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDAgcHJpbnQ6dGV4dC1zbGF0ZS05NTBcIj4xLiBJTlRST0RVQ0NJw5NOPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4LTEgaC0xIG1pbi13LVsyMHB4XSBwcmludDpib3JkZXItZ3JheS0zMDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+UMOhZy4gMzwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtZW5kIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwIHByaW50OnRleHQtc2xhdGUtOTUwXCI+Mi4gU0lTVEVNQSBERSBBTElNRU5UQUNJw5NOPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4LTEgaC0xIG1pbi13LVsyMHB4XSBwcmludDpib3JkZXItZ3JheS0zMDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+UMOhZy4gMzwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtZW5kIGdhcC0yIHBsLTRcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5QdW50b3MgZGUgU3VtaW5pc3RybyAvIEFjb21ldGlkYTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS04MDAgZmxleC0xIGgtMSBtaW4tdy1bMjBweF0gcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPlDDoWcuIDM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWVuZCBnYXAtMiBwbC00XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+VHJhbnNmb3JtYWRvcmVzPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4LTEgaC0xIG1pbi13LVsyMHB4XSBwcmludDpib3JkZXItZ3JheS0zMDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+UMOhZy4gMzwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtZW5kIGdhcC0yIHBsLTRcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5HZW5lcmFkb3Jlczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS04MDAgZmxleC0xIGgtMSBtaW4tdy1bMjBweF0gcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPlDDoWcuIDM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWVuZCBnYXAtMiBwbC00XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+VHJhbnNmZXJlbmNpYXMgKEFUUyAvIE1UUyk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtODAwIGZsZXgtMSBoLTEgbWluLXctWzIwcHhdIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj5Qw6FnLiAzPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1lbmQgZ2FwLTIgcGwtNFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPlRhYmxlcm9zIEVsw6ljdHJpY29zPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4LTEgaC0xIG1pbi13LVsyMHB4XSBwcmludDpib3JkZXItZ3JheS0zMDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+UMOhZy4gMzwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtZW5kIGdhcC0yIHBsLTRcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5CYW5jb3MgZGUgQ29uZGVuc2Fkb3Jlczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS04MDAgZmxleC0xIGgtMSBtaW4tdy1bMjBweF0gcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPlDDoWcuIDM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWVuZCBnYXAtMiBwbC00XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+Q2VudHJvcyBkZSBDb250cm9sIGRlIE1vdG9yZXMgKENDTSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtODAwIGZsZXgtMSBoLTEgbWluLXctWzIwcHhdIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj5Qw6FnLiAzPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1lbmQgZ2FwLTIgcGwtNFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPlNpc3RlbWFzIGRlIFB1ZXN0YSBhIFRpZXJyYSAoUEFUIC8gVGVsdXJvbWV0csOtYSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtODAwIGZsZXgtMSBoLTEgbWluLXctWzIwcHhdIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj5Qw6FnLiAzPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDAgcHJpbnQ6dGV4dC1zbGF0ZS05NTBcIj4zLiBKRVJBUlFVw41BIERFTCBESUFHUkFNQSBVTklGSUxBUjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS04MDAgZmxleC0xIGgtMSBtaW4tdy1bMjBweF0gcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPlDDoWcuIDQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDAgcHJpbnQ6dGV4dC1zbGF0ZS05NTBcIj40LiBSRVNVTFRBRE9TIERFIExBUyBJTlNQRUNDSU9ORVMgVMOJQ05JQ0FTPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4LTEgaC0xIG1pbi13LVsyMHB4XSBwcmludDpib3JkZXItZ3JheS0zMDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+UMOhZy4gNTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIHtlbGVtZW50b3MubWFwKChpdGVtLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17aXRlbS5pZH0gY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtZW5kIGdhcC0yIHBsLTQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57aXRlbS5ub21icmV9ICh7aXRlbS50aXBvRWxlbWVudG99KTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTg1MCBmbGV4LTEgaC0xIG1pbi13LVsyMHB4XSBwcmludDpib3JkZXItZ3JheS0yMDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj5SZWcuIHtpZHggKyAxfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIHtzdWJlc3RhY2lvbmVzLm1hcCgoc3ViLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17c3ViLmlkfSBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1lbmQgZ2FwLTIgcGwtNCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPkluc3BlY2Npw7NuIFN1YmVzdGFjacOzbjoge3N1Yi5ub21icmV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtODUwIGZsZXgtMSBoLTEgbWluLXctWzIwcHhdIHByaW50OmJvcmRlci1ncmF5LTIwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPlN1Yi4ge2lkeCArIDF9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWVuZCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTIwMCBwcmludDp0ZXh0LXNsYXRlLTk1MFwiPjUuIFJFQ09NRU5EQUNJT05FUyBHRU5FUkFMRVM8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtODAwIGZsZXgtMSBoLTEgbWluLXctWzIwcHhdIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj5Qw6FnLiBGaW5hbDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtZW5kIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwIHByaW50OnRleHQtc2xhdGUtOTUwXCI+Ni4gUkVTVU1FTiBFSkVDVVRJVk8gREUgSEFMTEFaR09TPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4LTEgaC0xIG1pbi13LVsyMHB4XSBwcmludDpib3JkZXItZ3JheS0zMDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+UMOhZy4gRmluYWw8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBJTlRST0RVQ0NJw5NOICYgU0lTVEVNQSBERSBBTElNRU5UQUNJw5NOID09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtYnJlYWsgcHktMTIgcHgtNiBzcGFjZS15LTggcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNTAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItMyBwcmludDp0ZXh0LXNsYXRlLTk1MCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgMS4gSW50cm9kdWNjacOzblxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIHtpc0VkaXRpbmdSZXBvcnQgPyAoXG4gICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgIHZhbHVlPXtpbnRyb1RleHR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRJbnRyb1RleHQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHJvd3M9ezh9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTEwMCByb3VuZGVkLXhsIHAtNCB0ZXh0LXhzIGZvbnQtc2FucyBsZWFkaW5nLXJlbGF4ZWQgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS0zNTAgdGV4dC1qdXN0aWZ5IGxlYWRpbmctcmVsYXhlZCBwcmludDp0ZXh0LXNsYXRlLTgwMCB3aGl0ZXNwYWNlLXByZS13cmFwXCI+XG4gICAgICAgICAgICAgICAge2ludHJvVGV4dH1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IHB0LTRcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci01MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0zIHByaW50OnRleHQtc2xhdGUtOTUwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAyLiBTaXN0ZW1hIGRlIEFsaW1lbnRhY2nDs25cbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHsvKiBQdW50b3MgZGUgTWVkaWNpw7NuIHkgU3VtaW5pc3RybyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci01MDAvODAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5QdW50b3MgZGUgU3VtaW5pc3RybyAvIEFjb21ldGlkYTwvaDM+XG4gICAgICAgICAgICAgIHtwdW50b3NNZWRpY2lvbi5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14cyB0ZXh0LWxlZnQgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6YmctZ3JheS0xMDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPk5vbWJyZSAvIFRhZzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+RW1wcmVzYSBEaXN0cmlidWlkb3JhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5OaXZlbCBUZW5zacOzbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+UG90ZW5jaWEgQ29udHJhdGFkYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+VGlwbyBNZWRpY2nDs248L3RoPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODUwIHByaW50OmRpdmlkZS1ncmF5LTI1NSB0ZXh0LXNsYXRlLTMwMCBwcmludDp0ZXh0LXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7cHVudG9zTWVkaWNpb24ubWFwKGUgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2UuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGZvbnQtYm9sZFwiPntlLm5vbWJyZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UuZW1wcmVzYURpc3RyaWJ1aWRvcmEgfHwgJ+KAlCd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNVwiPntlLm5pdmVsVGVuc2lvbkNvbnRyYXRvIHx8IGUudGVuc2lvbk5vbWluYWwgfHwgJ+KAlCd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNVwiPntlLnBvdGVuY2lhQ29udHJhdGFkYSB8fCAn4oCUJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UudGlwb01lZGljaW9uIHx8ICfigJQnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTU1MCBpdGFsaWNcIj5ObyBzZSByZWdpc3RyYXJvbiBwdW50b3MgZGUgbWVkaWNpw7NuIGVzcGVjw61maWNvcyBlbiBlc3RlIHByb3llY3RvLjwvcD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogVHJhbnNmb3JtYWRvcmVzICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWFtYmVyLTUwMC84MCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPlRyYW5zZm9ybWFkb3JlczwvaDM+XG4gICAgICAgICAgICAgIHt0cmFuc2Zvcm1hZG9yZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQteHMgdGV4dC1sZWZ0IGJvcmRlciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIHByaW50OmJnLWdyYXktMTAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5Ob21icmU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlViaWNhY2nDs248L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPkNhcGFjaWRhZDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+TWFyY2E8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPkNvbmV4acOzbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS04NTAgcHJpbnQ6ZGl2aWRlLWdyYXktMjU1IHRleHQtc2xhdGUtMzAwIHByaW50OnRleHQtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHt0cmFuc2Zvcm1hZG9yZXMubWFwKGUgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2UuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGZvbnQtYm9sZFwiPntlLm5vbWJyZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UudWJpY2FjaW9ufTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjVcIj57ZS5kYXRvc1RlY25pY29zPy5rdmEgfHwgJ+KAlCd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNVwiPntlLmRhdG9zVGVjbmljb3M/Lm1hcmNhIHx8ICfigJQnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjVcIj57ZS5kYXRvc1RlY25pY29zPy5jb25leGlvbiB8fCAn4oCUJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01NTAgaXRhbGljXCI+Tm8gc2UgcmVnaXN0cmFyb24gdHJhbnNmb3JtYWRvcmVzIGVzcGVjw61maWNvcyBlbiBlc3RlIHByb3llY3RvLjwvcD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogR2VuZXJhZG9yZXMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNTAwLzgwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+R2VuZXJhZG9yZXM8L2gzPlxuICAgICAgICAgICAgICB7Z2VuZXJhZG9yZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQteHMgdGV4dC1sZWZ0IGJvcmRlciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIHByaW50OmJnLWdyYXktMTAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5Ob21icmU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlViaWNhY2nDs248L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlBvdGVuY2lhIChLVkEpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5Db21idXN0aWJsZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+QW1wZXJhamU8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODUwIHByaW50OmRpdmlkZS1ncmF5LTI1NSB0ZXh0LXNsYXRlLTMwMCBwcmludDp0ZXh0LXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7Z2VuZXJhZG9yZXMubWFwKGUgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2UuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGZvbnQtYm9sZFwiPntlLm5vbWJyZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UudWJpY2FjaW9ufTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjVcIj57ZS5kYXRvc1RlY25pY29zPy5rdmEgfHwgJ+KAlCd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNVwiPntlLmRhdG9zVGVjbmljb3M/LmNvbWJ1c3RpYmxlIHx8ICfigJQnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjVcIj57ZS5kYXRvc1RlY25pY29zPy5hbXBlcmFqZSB8fCAn4oCUJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01NTAgaXRhbGljXCI+Tm8gc2UgcmVnaXN0cmFyb24gZ2VuZXJhZG9yZXMgZW4gZXN0ZSBwcm95ZWN0by48L3A+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFRyYW5zZmVyZW5jaWFzIChBVFMgLyBNVFMpICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWFtYmVyLTUwMC84MCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPlRyYW5zZmVyZW5jaWFzIChBVFMgLyBNVFMpPC9oMz5cbiAgICAgICAgICAgICAge3RyYW5zZmVyZW5jaWFzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXhzIHRleHQtbGVmdCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgdGV4dC1bMTBweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBwcmludDpiZy1ncmF5LTEwMCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+Tm9tYnJlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5UaXBvPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5DYXBhY2lkYWQgKEEpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5NYXJjYSAvIENvbnRyb2xhZG9yPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5VYmljYWNpw7NuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTg1MCBwcmludDpkaXZpZGUtZ3JheS0yNTUgdGV4dC1zbGF0ZS0zMDAgcHJpbnQ6dGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge3RyYW5zZmVyZW5jaWFzLm1hcChlID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtlLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBmb250LWJvbGRcIj57ZS5ub21icmV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNVwiPntlLmRhdG9zVGVjbmljb3M/LnRpcG9UcmFuc2ZlcmVuY2lhIHx8IGUuZGF0b3NUZWNuaWNvcz8udGlwbyB8fCAnQXV0b23DoXRpY2EgKEFUUyknfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjVcIj57ZS5kYXRvc1RlY25pY29zPy5hbXBlcmFqZU5vbWluYWwgfHwgZS5kYXRvc1RlY25pY29zPy5hbXBlcmFqZSB8fCAn4oCUJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UuZGF0b3NUZWNuaWNvcz8ubWFyY2FDb250cm9sYWRvciB8fCBlLmRhdG9zVGVjbmljb3M/Lm1hcmNhIHx8ICfigJQnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjVcIj57ZS51YmljYWNpb24gfHwgJ+KAlCd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTUwIGl0YWxpY1wiPk5vIHNlIHJlZ2lzdHJhcm9uIHRyYW5zZmVyZW5jaWFzIGVuIGVzdGUgcHJveWVjdG8uPC9wPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBUYWJsZXJvcyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci01MDAvODAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5UYWJsZXJvcyBFbMOpY3RyaWNvczwvaDM+XG4gICAgICAgICAgICAgIHt0YWJsZXJvcy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14cyB0ZXh0LWxlZnQgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6YmctZ3JheS0xMDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPk5vbWJyZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+VWJpY2FjacOzbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+UG9sb3MgTcOheDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+QWxpbWVudGFkb3I8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODUwIHByaW50OmRpdmlkZS1ncmF5LTI1NSB0ZXh0LXNsYXRlLTMwMCBwcmludDp0ZXh0LXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7dGFibGVyb3MubWFwKGUgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2UuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGZvbnQtYm9sZFwiPntlLm5vbWJyZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UudWJpY2FjaW9ufTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjVcIj57ZS5kYXRvc1RlY25pY29zPy5tYXhQb2xlcyB8fCAnMzAnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjVcIj57ZS5hbGltZW50YWRvUG9yIHx8ICfigJQnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTU1MCBpdGFsaWNcIj5ObyBzZSByZWdpc3RyYXJvbiB0YWJsZXJvcyBlbMOpY3RyaWNvcyBlbiBlc3RlIHByb3llY3RvLjwvcD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQmFuY29zIGRlIENvbmRlbnNhZG9yZXMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNTAwLzgwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+QmFuY29zIGRlIENvbmRlbnNhZG9yZXMgKENvbXBlbnNhY2nDs24gUmVhY3RpdmEpPC9oMz5cbiAgICAgICAgICAgICAge2JhbmNvc0NvbmRlbnNhZG9yZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQteHMgdGV4dC1sZWZ0IGJvcmRlciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIHByaW50OmJnLWdyYXktMTAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5Ob21icmUgLyBUYWc8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlViaWNhY2nDs248L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPkNhcGFjaWRhZCBUb3RhbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+VGlwbyAvIFBhc29zPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5UZW5zacOzbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS04NTAgcHJpbnQ6ZGl2aWRlLWdyYXktMjU1IHRleHQtc2xhdGUtMzAwIHByaW50OnRleHQtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtiYW5jb3NDb25kZW5zYWRvcmVzLm1hcChlID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtlLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBmb250LWJvbGRcIj57ZS5ub21icmV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNVwiPntlLnViaWNhY2lvbn08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UuZGF0b3NUZWNuaWNvcz8ucG90ZW5jaWFSZWFjdGl2YVRvdGFsID8gYCR7ZS5kYXRvc1RlY25pY29zLnBvdGVuY2lhUmVhY3RpdmFUb3RhbH0ga1ZBUmAgOiAn4oCUJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UuZGF0b3NUZWNuaWNvcz8udGlwb0NvbXBlbnNhY2lvbiB8fCAnQXV0b23DoXRpY2EnfSB7ZS5kYXRvc1RlY25pY29zPy5udW1QYXNvcyA/IGAoJHtlLmRhdG9zVGVjbmljb3MubnVtUGFzb3N9IHBhc29zKWAgOiAnJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UuZGF0b3NUZWNuaWNvcz8udGVuc2lvbk5vbWluYWwgfHwgJ+KAlCd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTUwIGl0YWxpY1wiPk5vIHNlIHJlZ2lzdHJhcm9uIGJhbmNvcyBkZSBjb25kZW5zYWRvcmVzIGVuIGVzdGUgcHJveWVjdG8uPC9wPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDZW50cm8gQ29udHJvbCBkZSBNb3RvcmVzIChDQ00pICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWFtYmVyLTUwMC84MCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPkNlbnRyb3MgZGUgQ29udHJvbCBkZSBNb3RvcmVzIChDQ00pPC9oMz5cbiAgICAgICAgICAgICAge2NjbUxpc3QubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQteHMgdGV4dC1sZWZ0IGJvcmRlciBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIHByaW50OmJnLWdyYXktMTAwIHByaW50OnRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5UYWcgQ0NNPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5QbGFudGEgLyDDgXJlYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+TWFyY2EgLyBNb2RlbG88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPk5pdmVsIFRlbnNpw7NuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5HYXZldGFzIC8gQnVja2V0czwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS04NTAgcHJpbnQ6ZGl2aWRlLWdyYXktMjU1IHRleHQtc2xhdGUtMzAwIHByaW50OnRleHQtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtjY21MaXN0Lm1hcChlID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtlLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBmb250LWJvbGRcIj57ZS5ub21icmV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNVwiPntlLnBsYW50YUluc3RhbGFjaW9uIHx8IGUuYXJlYVByb2Nlc28gfHwgJ+KAlCd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNVwiPntlLmZhYnJpY2FudGVNYXJjYSB8fCAn4oCUJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UucGFyYW1ldHJvc0VsZWN0cmljb3M/LnRlbnNpb25Ob21pbmFsIHx8ICc0ODAgVid9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNVwiPntlLmdhdmV0YXNCdWNrZXRMb2c/Lmxlbmd0aCA/IGAke2UuZ2F2ZXRhc0J1Y2tldExvZy5sZW5ndGh9IGdhdmV0YXNgIDogJ+KAlCd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTUwIGl0YWxpY1wiPk5vIHNlIHJlZ2lzdHJhcm9uIGNlbnRyb3MgZGUgY29udHJvbCBkZSBtb3RvcmVzIGVuIGVzdGUgcHJveWVjdG8uPC9wPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTaXN0ZW1hcyBkZSBQdWVzdGEgYSBUaWVycmEgKFBBVCAvIFRlbHVyb21ldHLDrWEpICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWFtYmVyLTUwMC84MCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPlNpc3RlbWFzIGRlIFB1ZXN0YSBhIFRpZXJyYSAoUEFUIC8gVGVsdXJvbWV0csOtYSk8L2gzPlxuICAgICAgICAgICAgICB7cHVlc3Rhc1RpZXJyYS5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14cyB0ZXh0LWxlZnQgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6YmctZ3JheS0xMDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPk5vbWJyZSAvIFRhZzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+VWJpY2FjacOzbiAvIEVxdWlwbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+UmVzaXN0ZW5jaWEgTWVkaWRhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5Db25mb3JtaWRhZCBOb3JtYXRpdmE8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlRpcG8gU2lzdGVtYSAvIFZhcmlsbGFzPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTg1MCBwcmludDpkaXZpZGUtZ3JheS0yNTUgdGV4dC1zbGF0ZS0zMDAgcHJpbnQ6dGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge3B1ZXN0YXNUaWVycmEubWFwKGUgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IHBhcnNlRmxvYXQoZS5kYXRvc1RlY25pY29zPy5yZXNpc3RlbmNpYU9obXMgfHwgZS5kYXRvc1RlY25pY29zPy5yZXNpc3RlbmNpYSk7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNOb3JtID0gIWlzTmFOKHJlcykgPyAocmVzIDw9IDUuMCA/ICfwn5+iIENvbmZvcm1lICjiiaQ1LjAgzqkpJyA6IHJlcyA8PSAxMC4wID8gJ/Cfn6EgQWNlcHRhYmxlICjiiaQxMC4wIM6pKScgOiAn8J+UtCBObyBDb25mb3JtZSAoPjEwLjAgzqkpJykgOiAn4oCUJztcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17ZS5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBmb250LWJvbGRcIj57ZS5ub21icmV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UudWJpY2FjaW9uIHx8IGUuZGF0b3NUZWNuaWNvcz8uZXF1aXBvVmluY3VsYWRvIHx8ICfigJQnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzTmFOKHJlcykgPyBgJHtyZXN9IM6pYCA6ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzTm9ybX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41XCI+e2UuZGF0b3NUZWNuaWNvcz8udGlwb1Npc3RlbWFQYXQgfHwgJ01hbGxhIFBBVCd9IHtlLmRhdG9zVGVjbmljb3M/Lm51bVZhcmlsbGFzID8gYCgke2UuZGF0b3NUZWNuaWNvcy5udW1WYXJpbGxhc30gcGljYXMpYCA6ICcnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01NTAgaXRhbGljXCI+Tm8gc2UgcmVnaXN0cmFyb24gc2lzdGVtYXMgZGUgcHVlc3RhIGEgdGllcnJhIGVuIGVzdGUgcHJveWVjdG8uPC9wPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBKRVJBUlFVw41BIERFTCBESUFHUkFNQSBVTklGSUxBUiA9PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLWJyZWFrIHB5LTEyIHB4LTYgc3BhY2UteS02IHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItMyBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci01MDAgcHJpbnQ6dGV4dC1zbGF0ZS05NTBcIj5cbiAgICAgICAgICAgICAgMy4gSmVyYXJxdcOtYSB5IERpYWdyYW1hIFVuaWZpbGFyIEdyw6FmaWNvXG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIFxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS0zNTAgcHJpbnQ6dGV4dC1zbGF0ZS04MDAgbWItNlwiPlxuICAgICAgICAgICAgQSBjb250aW51YWNpw7NuIHNlIHByZXNlbnRhIGRlIGZvcm1hIGplcsOhcnF1aWNhIGxhcyByZWxhY2lvbmVzIGRlIGFsaW1lbnRhY2nDs24gZW50cmUgbG9zIGVxdWlwb3MgcmVnaXN0cmFkb3MgZW4gZWwgc2lzdGVtYSwgbW9zdHJhbmRvIGVsIGZsdWpvIGRlIHBvdGVuY2lhIGFndWFzIGFiYWpvIHkgZWwgcGxhbm8gQ0FEIHVuaWZpbGFyIGNvcnJlc3BvbmRpZW50ZTpcbiAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy13aGl0ZSB0ZXh0LWJsYWNrIHJvdW5kZWQtMnhsIHNoYWRvdy1pbm5lciBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwcmludDpib3JkZXItbm9uZSBwLTQgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICA8RGlhZ3JhbWFVbmlmaWxhckJsdWVwcmludFxuICAgICAgICAgICAgICBlbGVtZW50b3M9e2VsZW1lbnRvc31cbiAgICAgICAgICAgICAgY29tcGFueU5hbWU9e2NvbXBhbnkubm9tYnJlfVxuICAgICAgICAgICAgICBwcm9qZWN0TmFtZT17cHJveWVjdG8ubm9tYnJlfVxuICAgICAgICAgICAgICBpbnRlcmFjdGl2ZT17ZmFsc2V9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC02IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODUwIHNwYWNlLXktNCBwcmludDpiZy1zbGF0ZS01MCBwcmludDpib3JkZXItZ3JheS0zMDAgbm8tcHJpbnRcIj5cbiAgICAgICAgICAgIHtlbGVtZW50b3MubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICB7LyogRmluZCBlbGVtZW50cyB0aGF0IGFyZSBmZWQgYnkgbm90aGluZyBvciBnZW5lcmFsIGZlZWQgKi99XG4gICAgICAgICAgICAgICAge2VsZW1lbnRvcy5tYXAoZSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBmZWVkcyA9IGVsZW1lbnRvcy5maWx0ZXIoY2hpbGQgPT4gY2hpbGQuYWxpbWVudGFkb1BvciA9PT0gZS5ub21icmUpO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2UuaWR9IGNsYXNzTmFtZT1cImJvcmRlci1sLTIgYm9yZGVyLWFtYmVyLTUwMC8zMCBwbC00IHB5LTEuNSBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBwcmludDp0ZXh0LXNsYXRlLTkwMCB1cHBlcmNhc2VcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Uubm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBweC0xLjUgcHktMC41IHJvdW5kZWQgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LW1vbm8gcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlLnRpcG9FbGVtZW50b31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtlLmFsaW1lbnRhZG9Qb3IgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKEFsaW1lbnRhZG8gcG9yOiB7ZS5hbGltZW50YWRvUG9yfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIHtmZWVkcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtNiBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIGJsb2NrXCI+QWxpbWVudGEgYTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtmZWVkcy5tYXAoY2hpbGQgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjaGlsZC5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4oazPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+e2NoaWxkLm5vbWJyZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs4cHhdIHB4LTEgYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNTAwIHJvdW5kZWQgdXBwZXJjYXNlIGZvbnQtbW9ubyBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0yMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04NTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NoaWxkLnRpcG9FbGVtZW50b31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBpdGFsaWMgdGV4dC1jZW50ZXJcIj5ObyBoYXkgc3VmaWNpZW50ZXMgZWxlbWVudG9zIHBhcmEgdHJhemFyIGxhIGplcmFycXXDrWEuPC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFJFU1VMVEFET1MgREUgSU5TUEVDQ0lPTkVTIChQw6FnaW5hcyBpbmRpdmlkdWFsZXMpID09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMTJcIj5cbiAgICAgICAgICB7LyogRWxlbWVudG9zICovfVxuICAgICAgICAgIHtlbGVtZW50b3MubWFwKChpdGVtLCBpZHgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGlzVGFibGVybyA9IGl0ZW0udGlwb0VsZW1lbnRvID09PSAnVEFCTEVSTyc7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGNvbnN0IGVucmljaGVkRWxlbWVudCA9IGlzVGFibGVybyA/IHtcbiAgICAgICAgICAgICAgaWQ6IGl0ZW0uaWQsXG4gICAgICAgICAgICAgIG5vbWJyZTogaXRlbS5ub21icmUsXG4gICAgICAgICAgICAgIHViaWNhY2lvbjogaXRlbS51YmljYWNpb24sXG4gICAgICAgICAgICAgIGFsaW1lbnRhZG9Qb3I6IGl0ZW0uYWxpbWVudGFkb1BvcixcbiAgICAgICAgICAgICAgZm90bzogaXRlbS5mb3RvLFxuICAgICAgICAgICAgICBmb3RvQmxvYjogaXRlbS5mb3RvQmxvYixcbiAgICAgICAgICAgICAgb2JzZXJ2YWNpb25lc0dlbmVyYWxlczogaXRlbS5vYnNlcnZhY2lvbmVzR2VuZXJhbGVzLFxuICAgICAgICAgICAgICAuLi5pdGVtLmRhdG9zVGVjbmljb3MsXG4gICAgICAgICAgICAgIG5vbWJyZUVtcHJlc2E6IGNvbXBhbnkubm9tYnJlXG4gICAgICAgICAgICB9IDogaXRlbTtcblxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2l0ZW0uaWR9IGNsYXNzTmFtZT1cInBhZ2UtYnJlYWsgcHQtOCBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItMyBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwIG5vLXByaW50XCI+XG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1hbWJlci01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cbiAgICAgICAgICAgICAgICAgICAgSW5zcGVjY2nDs24gI3tpZHggKyAxfToge2Zvcm1hdEVsZW1lbnRUaXRsZVdpdGhJZChpdGVtLm5vbWJyZSwgaXRlbS5pZCl9ICh7aXRlbS50aXBvRWxlbWVudG99KVxuICAgICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1hbWJlci00MDAgZm9udC1tb25vIGZvbnQtYm9sZCBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcHgtMiBweS0wLjUgcm91bmRlZFwiPklEOiB7aXRlbS5pZH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogUmVuZGVyaXphciBzZWfDum4gc2VhIFRhYmxlcm8gbyBGaWNoYSBUw6ljbmljYSAqL31cbiAgICAgICAgICAgICAgICB7aXNUYWJsZXJvID8gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2lzRWRpdGluZ1JlcG9ydCA/IFwiXCIgOiBcInBvaW50ZXItZXZlbnRzLW5vbmUgc2VsZWN0LW5vbmVcIn0+XG4gICAgICAgICAgICAgICAgICAgIDxUYWJsZXJvQ29tcG9uZW50IFxuICAgICAgICAgICAgICAgICAgICAgIHRhYmxlcm9EYXRhPXtlbnJpY2hlZEVsZW1lbnR9XG4gICAgICAgICAgICAgICAgICAgICAgb25VcGRhdGVUYWJsZXJvPXsodXBkYXRlZERhdGEpID0+IGhhbmRsZVVwZGF0ZUVsZW1lbnRvKGl0ZW0uaWQsIHVwZGF0ZWREYXRhKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17aXNFZGl0aW5nUmVwb3J0ID8gXCJcIiA6IFwicG9pbnRlci1ldmVudHMtbm9uZSBzZWxlY3Qtbm9uZVwifT5cbiAgICAgICAgICAgICAgICAgICAgPEZpY2hhVGVjbmljYUNvbXBvbmVudFxuICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnRvRGF0YT17ZW5yaWNoZWRFbGVtZW50fVxuICAgICAgICAgICAgICAgICAgICAgIG9uVXBkYXRlPXsodXBkYXRlZERhdGEpID0+IGhhbmRsZVVwZGF0ZUVsZW1lbnRvKGl0ZW0uaWQsIHVwZGF0ZWREYXRhKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cblxuICAgICAgICAgIHsvKiBTdWJlc3RhY2lvbmVzICovfVxuICAgICAgICAgIHtzdWJlc3RhY2lvbmVzLm1hcCgoc3ViLCBpZHgpID0+IChcbiAgICAgICAgICAgIDxkaXYga2V5PXtzdWIuaWR9IGNsYXNzTmFtZT1cInBhZ2UtYnJlYWsgcHQtOCBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTMgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHByaW50OmJvcmRlci1ncmF5LTMwMCBuby1wcmludFwiPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxuICAgICAgICAgICAgICAgICAgU3ViZXN0YWNpw7NuICN7aWR4ICsgMX06IHtmb3JtYXRFbGVtZW50VGl0bGVXaXRoSWQoc3ViLm5vbWJyZSwgc3ViLmlkKX1cbiAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1hbWJlci00MDAgZm9udC1tb25vIGZvbnQtYm9sZCBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcHgtMiBweS0wLjUgcm91bmRlZFwiPklEOiB7c3ViLmlkfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2lzRWRpdGluZ1JlcG9ydCA/IFwiXCIgOiBcInBvaW50ZXItZXZlbnRzLW5vbmUgc2VsZWN0LW5vbmVcIn0+XG4gICAgICAgICAgICAgICAgPFN1YmVzdGFjaW9uQ29tcG9uZW50XG4gICAgICAgICAgICAgICAgICBzdWJlc3RhY2lvbkRhdGE9e3N1Yn1cbiAgICAgICAgICAgICAgICAgIG9uVXBkYXRlPXsodXBkYXRlZERhdGEpID0+IGhhbmRsZVVwZGF0ZVN1YmVzdGFjaW9uKHN1Yi5pZCwgdXBkYXRlZERhdGEpfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG5cbiAgICAgICAgICB7LyogUHVudG9zIGRlIE1lZGljacOzbiB5IFN1bWluaXN0cm8gKi99XG4gICAgICAgICAge3B1bnRvc01lZGljaW9uLm1hcCgocG0sIGlkeCkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e3BtLmlkfSBjbGFzc05hbWU9XCJwYWdlLWJyZWFrIHB0LTggc3BhY2UteS02XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0zIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwcmludDpib3JkZXItZ3JheS0zMDAgbm8tcHJpbnRcIj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1hbWJlci01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cbiAgICAgICAgICAgICAgICAgIFB1bnRvIGRlIE1lZGljacOzbiAje2lkeCArIDF9OiB7Zm9ybWF0RWxlbWVudFRpdGxlV2l0aElkKHBtLm5vbWJyZSwgcG0uaWQpfVxuICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWFtYmVyLTQwMCBmb250LW1vbm8gZm9udC1ib2xkIGJnLWFtYmVyLTUwMC8xMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBweC0yIHB5LTAuNSByb3VuZGVkXCI+SUQ6IHtwbS5pZH08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtpc0VkaXRpbmdSZXBvcnQgPyBcIlwiIDogXCJwb2ludGVyLWV2ZW50cy1ub25lIHNlbGVjdC1ub25lXCJ9PlxuICAgICAgICAgICAgICAgIDxQdW50b01lZGljaW9uQ29tcG9uZW50XG4gICAgICAgICAgICAgICAgICBwdW50b0RhdGE9e3BtfVxuICAgICAgICAgICAgICAgICAgb25VcGRhdGU9eyh1cGRhdGVkRGF0YSkgPT4gdXBkYXRlUHVudG9NZWRpY2lvbihwcm95ZWN0b0lkLCBwbS5pZCwgdXBkYXRlZERhdGEpfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG5cbiAgICAgICAgICB7LyogQ2VudHJvcyBkZSBDb250cm9sIGRlIE1vdG9yZXMgKENDTSkgKi99XG4gICAgICAgICAge2NjbUxpc3QubWFwKChjY20sIGlkeCkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e2NjbS5pZH0gY2xhc3NOYW1lPVwicGFnZS1icmVhayBwdC04IHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItMyBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwIG5vLXByaW50XCI+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtYW1iZXItNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XG4gICAgICAgICAgICAgICAgICBDQ00gI3tpZHggKyAxfToge2Zvcm1hdEVsZW1lbnRUaXRsZVdpdGhJZChjY20ubm9tYnJlLCBjY20uaWQpfVxuICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWFtYmVyLTQwMCBmb250LW1vbm8gZm9udC1ib2xkIGJnLWFtYmVyLTUwMC8xMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBweC0yIHB5LTAuNSByb3VuZGVkXCI+SUQ6IHtjY20uaWR9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17aXNFZGl0aW5nUmVwb3J0ID8gXCJcIiA6IFwicG9pbnRlci1ldmVudHMtbm9uZSBzZWxlY3Qtbm9uZVwifT5cbiAgICAgICAgICAgICAgICA8Q2NtQ29tcG9uZW50XG4gICAgICAgICAgICAgICAgICBjY21EYXRhPXtjY219XG4gICAgICAgICAgICAgICAgICBvblVwZGF0ZT17KHVwZGF0ZWREYXRhKSA9PiB1cGRhdGVDY20ocHJveWVjdG9JZCwgY2NtLmlkLCB1cGRhdGVkRGF0YSl9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFJFQ09NRU5EQUNJT05FUyBHRU5FUkFMRVMgPT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFnZS1icmVhayBweS0xMiBweC02IHNwYWNlLXktNiBwcmludDp0ZXh0LWJsYWNrXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTMgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNTAwIHByaW50OnRleHQtc2xhdGUtOTUwXCI+XG4gICAgICAgICAgICAgIDUuIFJlY29tZW5kYWNpb25lcyBHZW5lcmFsZXNcbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCB0ZXh0LXNtIHRleHQtc2xhdGUtMzUwIHByaW50OnRleHQtc2xhdGUtODAwXCI+XG4gICAgICAgICAgICB7ZWxlbWVudG9zLnNvbWUoZSA9PiBlLm9ic2VydmFjaW9uZXNHZW5lcmFsZXMpID8gKFxuICAgICAgICAgICAgICBlbGVtZW50b3MuZmlsdGVyKGUgPT4gZS5vYnNlcnZhY2lvbmVzR2VuZXJhbGVzKS5tYXAoZSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2UuaWR9IGNsYXNzTmFtZT1cImJvcmRlci1sLTIgYm9yZGVyLWFtYmVyLTUwMCBwbC00IHB5LTEgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgYmxvY2sgdGV4dC14cyB1cHBlcmNhc2VcIj57ZS5ub21icmV9Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmdSZXBvcnQgPyAoXG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlLm9ic2VydmFjaW9uZXNHZW5lcmFsZXMgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlVmFsKSA9PiBoYW5kbGVVcGRhdGVFbGVtZW50b09ic2VydmFjaW9uZXMoZS5pZCwgZVZhbC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTW9kaWZpcXVlIHJlY29tZW5kYWNpb25lcy4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHRleHQtc2xhdGUtMTAwIHJvdW5kZWQgcHgtMiBweS0xIHRleHQteHMgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDAgaXRhbGljXCI+XCJ7ZS5vYnNlcnZhY2lvbmVzR2VuZXJhbGVzfVwiPC9wPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01NTAgaXRhbGljIHRleHQtY2VudGVyXCI+Tm8gc2UgaW5ncmVzYXJvbiByZWNvbWVuZGFjaW9uZXMgZGV0YWxsYWRhcyBpbmRpdmlkdWFsZXMuPC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFRBQkxBIFJFU1VNRU4gREUgUkVDT01FTkRBQ0lPTkVTID09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtYnJlYWsgcHktMTIgcHgtNiBzcGFjZS15LTYgcHJpbnQ6dGV4dC1ibGFja1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0zIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWFtYmVyLTUwMCBwcmludDp0ZXh0LXNsYXRlLTk1MFwiPlxuICAgICAgICAgICAgICA2LiBSZXN1bWVuIGRlIEhhbGxhemdvcyB5IFJlY29tZW5kYWNpb25lc1xuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14cyB0ZXh0LWxlZnQgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6YmctZ3JheS0xMDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0zMDAgdy0xLzRcIj7DgXJlYSAvIEVxdWlwbzwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPk9ic2VydmFjaW9uZXMgeSBSZWNvbWVuZGFjaW9uZXMgVMOpY25pY2FzPC90aD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTg1MCBwcmludDpkaXZpZGUtZ3JheS0yNTUgdGV4dC1zbGF0ZS0zNTAgcHJpbnQ6dGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAge2VsZW1lbnRvcy5tYXAoZSA9PiAoXG4gICAgICAgICAgICAgICAgPHRyIGtleT17ZS5pZH0+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIGZvbnQtYm9sZCB1cHBlcmNhc2VcIj57ZS5ub21icmV9ICh7ZS50aXBvRWxlbWVudG99KTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHdoaXRlc3BhY2UtcHJlLWxpbmUgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmdSZXBvcnQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZS5vYnNlcnZhY2lvbmVzR2VuZXJhbGVzIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlVmFsKSA9PiBoYW5kbGVVcGRhdGVFbGVtZW50b09ic2VydmFjaW9uZXMoZS5pZCwgZVZhbC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFZGl0ZSBsb3MgaGFsbGF6Z29zIGRlbCBlcXVpcG8uLi5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgdGV4dC1zbGF0ZS0xMDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC14cyBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgZS5vYnNlcnZhY2lvbmVzR2VuZXJhbGVzIHx8ICdFbCBlcXVpcG8gcHJlc2VudGEgYnVlbiBlc3RhZG8gZ2VuZXJhbCBkZSBlc3RydWN0dXJhIHkgY2FibGVhZG8uIEN1bXBsZSBjb24gbm9ybWFzIG9wZXJhdGl2YXMuJ1xuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAge3N1YmVzdGFjaW9uZXMubWFwKHMgPT4gKFxuICAgICAgICAgICAgICAgIDx0ciBrZXk9e3MuaWR9PlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyBmb250LWJvbGQgdXBwZXJjYXNlXCI+U1VCRVNUQUNJw5NOOiB7cy5ub21icmV9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgd2hpdGVzcGFjZS1wcmUtbGluZSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZ1JlcG9ydCA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzLm9ic2VydmFjaW9uZXNHZW5lcmFsZXMgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGVWYWwpID0+IGhhbmRsZVVwZGF0ZVN1YmVzdGFjaW9uT2JzZXJ2YWNpb25lcyhzLmlkLCBlVmFsLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVkaXRlIGxvcyBoYWxsYXpnb3MgZGUgbGEgc3ViZXN0YWNpw7NuLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHRleHQtc2xhdGUtMTAwIHJvdW5kZWQgcHgtMiBweS0xIHRleHQteHMgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIHMub2JzZXJ2YWNpb25lc0dlbmVyYWxlcyB8fCAnT2JyYXMgY2l2aWxlcyBlIGluZnJhZXN0cnVjdHVyYSBmw61zaWNhIGVuIGJ1ZW5hcyBjb25kaWNpb25lcyBnZW5lcmFsZXMuJ1xuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl19