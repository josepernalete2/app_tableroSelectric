import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/ProyectoView.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport11_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f49807c8";
import useStore, { getNextElementId, PREFIX_MAP, formatElementTitleWithId } from "/src/store/useStore.js?t=1790792337841";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
import ModalDiagramaUnifilar from "/src/components/ModalDiagramaUnifilar.jsx?t=1790792337841";
import SelectorAlimentadorJerarquico from "/src/components/SelectorAlimentadorJerarquico.jsx?t=1790792337841";
import AvanceProgressBar from "/src/components/AvanceProgressBar.jsx";
import ElementoCardActions from "/src/components/ElementoCardActions.jsx";
import { TENSIONES_COVENIN_159_BT, TENSIONES_COVENIN_159_MT, TENSIONES_COVENIN_TODAS } from "/src/utils/constants.js";
import { ArrowLeft, Layers, Trash2, Search, AlertTriangle, X, Camera, Calendar, User, Zap, Building, Gauge, Cpu, ShieldAlert, RefreshCw, FileText, CheckSquare, Settings, HelpCircle, Plus } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import HelpModal from "/src/components/HelpModal.jsx";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/ProyectoView.jsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
// Componente para renderizar Blobs de forma segura evitando fugas de memoria
const SafeImage = ({ blob, src, alt, className }) => {
	_s();
	const [objectUrl, setObjectUrl] = useState(null);
	useEffect(() => {
		if (blob) {
			const url = URL.createObjectURL(blob);
			setObjectUrl(url);
			return () => {
				URL.revokeObjectURL(url);
			};
		} else {
			setObjectUrl(null);
		}
	}, [blob]);
	const finalSrc = objectUrl || src;
	if (!finalSrc) return null;
	return /* @__PURE__ */ _jsxDEV("img", {
		src: finalSrc,
		alt,
		className
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 57,
		columnNumber: 10
	}, this);
};
_s(SafeImage, "Q4ugJUn5miWrvY9z1+S4+H7NbYg=");
_c = SafeImage;
export const ProyectoView = () => {
	_s2();
	const { companyId, proyectoId } = useParams();
	const navigate = useNavigate();
	const { user, companies, addElementoUnifilar, deleteElementoUnifilar, updateElementoUnifilar, addInspeccionSubestacion, deleteSubestacion, addPuntoMedicion, deletePuntoMedicion, updatePuntoMedicion, addCcm, deleteCcm, updateCcm, updateProyecto, showToast } = useStore();
	const company = companies.find((c) => c.id === companyId);
	const proyecto = company?.proyectos?.find((p) => p.id === proyectoId);
	const { confirm, alert: customAlert } = useConfirm();
	// Estados para Edición de Proyecto
	const [showEditProyectoModal, setShowEditProyectoModal] = useState(false);
	const [editProyectoNombre, setEditProyectoNombre] = useState("");
	const [editProyectoDescripcion, setEditProyectoDescripcion] = useState("");
	const [editProyectoDireccion, setEditProyectoDireccion] = useState("");
	const [editResponsableNombre, setEditResponsableNombre] = useState("");
	const [editResponsableTelefono, setEditResponsableTelefono] = useState("");
	const [editResponsableEmail, setEditResponsableEmail] = useState("");
	const handleUpdateProyectoSubmit = async (e) => {
		e.preventDefault();
		if (!editProyectoNombre.trim()) return;
		updateProyecto(companyId, proyectoId, {
			nombre: editProyectoNombre.trim(),
			descripcion: editProyectoDescripcion.trim(),
			direccion: editProyectoDireccion.trim(),
			responsable: {
				nombre: editResponsableNombre.trim(),
				telefono: editResponsableTelefono.trim(),
				email: editResponsableEmail.trim()
			}
		});
		setShowEditProyectoModal(false);
		showToast?.("Información del proyecto actualizada.", "success");
	};
	const handleOpenEditModal = () => {
		setEditProyectoNombre(proyecto?.nombre || "");
		setEditProyectoDescripcion(proyecto?.descripcion || "");
		setEditProyectoDireccion(proyecto?.direccion || "");
		setEditResponsableNombre(proyecto?.responsable?.nombre || "");
		setEditResponsableTelefono(proyecto?.responsable?.telefono || "");
		setEditResponsableEmail(proyecto?.responsable?.email || "");
		setShowEditProyectoModal(true);
	};
	// Estados de pestaña activa
	const [activeTab, setActiveTab] = useState("UNIFILAR");
	const [searchQuery, setSearchQuery] = useState("");
	// Estados de selección múltiple
	const [isMultiSelectMode, setIsMultiSelectMode] = useState(false);
	const [selectedIds, setSelectedIds] = useState(new Set());
	// Limpiar selección cuando cambia la pestaña o la búsqueda
	useEffect(() => {
		setSelectedIds(new Set());
	}, [activeTab, searchQuery]);
	const handleToggleSelect = (id) => {
		setSelectedIds((prev) => {
			const next = new Set(prev);
			if (next.has(id)) {
				next.delete(id);
			} else {
				next.add(id);
			}
			return next;
		});
	};
	const handleSelectAll = (items) => {
		setSelectedIds(new Set(items.map((i) => i.id)));
	};
	const handleDeselectAll = () => {
		setSelectedIds(new Set());
	};
	const handleDeleteSelected = async () => {
		const selectedCount = selectedIds.size;
		if (selectedCount === 0) return;
		const confirmMsg = activeTab === "UNIFILAR" ? `¿Estás seguro de que deseas eliminar los ${selectedCount} elementos seleccionados del Diagrama Unifilar?` : `¿Estás seguro de que deseas eliminar las ${selectedCount} fichas de inspección seleccionadas?`;
		const ok = await confirm({
			title: "Eliminar elementos seleccionados",
			message: confirmMsg,
			type: "danger",
			confirmText: "Eliminar seleccionados"
		});
		if (ok) {
			if (activeTab === "UNIFILAR") {
				selectedIds.forEach((id) => {
					deleteElementoUnifilar(proyectoId, id);
				});
				showToast?.(`Se eliminaron ${selectedCount} elementos correctamente`, "success");
			} else {
				selectedIds.forEach((id) => {
					deleteSubestacion(proyectoId, id);
				});
				showToast?.(`Se eliminaron ${selectedCount} fichas de inspección correctamente`, "success");
			}
			setSelectedIds(new Set());
			setIsMultiSelectMode(false);
		}
	};
	// Modales
	const [showElementoModal, setShowElementoModal] = useState(false);
	const [showInspeccionModal, setShowInspeccionModal] = useState(false);
	const [showPuntoMedicionModal, setShowPuntoMedicionModal] = useState(false);
	const [showCcmModal, setShowCcmModal] = useState(false);
	// Campos de Punto de Medición
	const [puntoMedicionNombre, setPuntoMedicionNombre] = useState("");
	const [puntoMedicionUsuario, setPuntoMedicionUsuario] = useState("");
	const [puntoMedicionNIC, setPuntoMedicionNIC] = useState("");
	const [puntoMedicionNivelTension, setPuntoMedicionNivelTension] = useState("Media Tensión");
	// Campos de CCM
	const [ccmNombre, setCcmNombre] = useState("");
	const [ccmPlanta, setCcmPlanta] = useState("");
	const [ccmArea, setCcmArea] = useState("");
	const handleCreateCcmSubmit = (e) => {
		e.preventDefault();
		if (!ccmNombre.trim()) {
			showToast?.("Por favor ingresa la identificación o tag del CCM.", "error");
			return;
		}
		const payload = {
			nombre: ccmNombre,
			plantaInstalacion: ccmPlanta,
			areaProceso: ccmArea,
			fecha: new Date().toISOString().split("T")[0],
			inspector: user?.nombre || user?.username || "Inspector",
			supervisor: "",
			parametrosElectricos: {},
			gavetasBucketLog: [],
			inspeccionFisica: {},
			seguridadTermografia: {},
			hallazgosCriticos: []
		};
		const result = addCcm(proyectoId, payload);
		if (result.success) {
			showToast?.("Centro de Control de Motores (CCM) creado exitosamente", "success");
			setShowCcmModal(false);
			setCcmNombre("");
			setCcmPlanta("");
			setCcmArea("");
		} else {
			showToast?.(result.error || "Error al crear el CCM", "error");
		}
	};
	// Estado para edición de elementos
	const [editingElemento, setEditingElemento] = useState(null);
	// Efecto para rellenar campos en caso de edición
	useEffect(() => {
		if (editingElemento) {
			setNombre(editingElemento.nombre || "");
			setUbicacion(editingElemento.ubicacion || "");
			setAlimentadoPor(editingElemento.alimentadoPor || "");
			setObservacionesGenerales(editingElemento.observacionesGenerales || "");
			setTipoElemento(editingElemento.tipoElemento || "TABLERO");
			const tech = editingElemento.datosTecnicos || {};
			if (editingElemento.tipoElemento === "TABLERO") {
				setMaxPoles(tech.maxPoles || 24);
			} else if (editingElemento.tipoElemento === "TRANSFORMADOR") {
				setKvaTrafo(tech.kva || tech.potenciaKva || "");
				setMarcaTrafo(tech.marca || "");
				setTipoTrafo(tech.tipoTransformador || "Pedestal");
				setConexionTrafo(tech.conexion || "");
				setVoltajePrimario(tech.voltajePrimario || tech.tensionPrimaria || "");
				setVoltajeSecundario(tech.voltajeSecundario || tech.tensionSecundaria || "");
			} else if (editingElemento.tipoElemento === "GENERADOR") {
				setKvaGen(tech.kva || "");
				setCombustibleGen(tech.combustible || tech.tipoCombustible || "DIESEL");
				setVoltajeGen(tech.voltajeGeneracion || "");
				setPotenciaKwGen(tech.potenciaKw || tech.kw || "");
				setAmperajeGen(tech.amperaje || "");
			} else if (editingElemento.tipoElemento === "PUESTA_TIERRA") {
				setResistenciaOhmios(tech.resistenciaOhmios || "");
				setCorrienteFuga(tech.corrienteFugaAmperios || "");
				setTipoMalla(tech.tipoMalla || "");
				setCableAcometidaTierra(tech.cableAcometida || "");
			} else if (editingElemento.tipoElemento === "TRANSFER") {
				setCapacidadAmperios(tech.capacidadAmperios || "");
				setTipoTransferencia(tech.tipoTransferencia || "AUTOMATICA");
				setTensionOperativa(tech.tensionOperativa || "");
			} else if (editingElemento.tipoElemento === "BANCO_CONDENSADOR") {
				setKvarTotal(tech.potenciaReactivaTotal || tech.kvarTotal || "");
				setPasosCondensador(tech.numPasos || tech.pasosCondensador || "");
				setTipoBanco(tech.tipoCompensacion === "Fija" ? "FIJO" : "AUTOMATICO");
				setTensionBanco(tech.tensionNominal || tech.tensionBanco || "");
			} else if (editingElemento.tipoElemento === "PUNTO_SUMINISTRO") {
				setSuministroTension(tech.nivelTension || tech.tensionNominal || "");
				setSuministroEmpresa(tech.empresaDistribuidora || "CORPOELEC");
				setSuministroTipoAcometida(tech.tipoAcometida || "Subterránea");
				setSuministroCapacidad(tech.capacidadContratadaKva || tech.cargaContratadaKva || tech.capacidadKva || "");
				setSuministroTipoMedicion(tech.tipoMedicion || "Medición Directa (Baja Tensión)");
				setSuministroEnlaceCorpoelec(tech.enlaceCorpoelec !== undefined ? tech.enlaceCorpoelec : true);
				setSuministroNumeroContrato(tech.numeroContrato || tech.contrato || "");
				setSuministroNic(tech.nic || tech.numeroMedidor || "");
				setSuministroPosteTrafo(tech.posteTransformador || tech.posteTrafo || "");
			} else if (editingElemento.tipoElemento === "CCM") {
				setCcmCapacidadBarra(tech.capacidadBarraAmperios || "");
				setCcmTension(tech.tensionOperativa || "");
				setCcmBreakerPrincipal(tech.breakerPrincipal || "");
				setCcmNumeroGavetas(tech.numeroGavetas || 8);
			} else {
				setDescripcionOtro(tech.descripcionEspecificaciones || "");
			}
		} else {
			setNombre("");
			setUbicacion("");
			setAlimentadoPor("");
			setObservacionesGenerales("");
			setTipoElemento("TABLERO");
			setMaxPoles(24);
			setKvaTrafo("");
			setMarcaTrafo("");
			setConexionTrafo("");
			setVoltajePrimario("");
			setVoltajeSecundario("");
			setKvaGen("");
			setVoltajeGen("");
			setPotenciaKwGen("");
			setAmperajeGen("");
			setResistenciaOhmios("");
			setCorrienteFuga("");
			setTipoMalla("");
			setCableAcometidaTierra("");
			setCapacidadAmperios("");
			setTensionOperativa("");
			setKvarTotal("");
			setPasosCondensador("");
			setTensionBanco("");
			setSuministroTension("");
			setSuministroEmpresa("CORPOELEC");
			setSuministroTipoAcometida("Subterránea");
			setSuministroCapacidad("");
			setSuministroTipoMedicion("Medición Directa (Baja Tensión)");
			setSuministroEnlaceCorpoelec(true);
			setSuministroNumeroContrato("");
			setSuministroNic("");
			setSuministroPosteTrafo("");
			setCcmCapacidadBarra("");
			setCcmTension("");
			setCcmBreakerPrincipal("");
			setDescripcionOtro("");
		}
	}, [editingElemento]);
	const [showDiagramModal, setShowDiagramModal] = useState(false);
	const [showHelpModal, setShowHelpModal] = useState(false);
	// Selector de plantilla / tipo de elemento
	const [tipoElemento, setTipoElemento] = useState("TABLERO");
	// Campos comunes
	const [nombre, setNombre] = useState("");
	const [ubicacion, setUbicacion] = useState("");
	const [alimentadoPor, setAlimentadoPor] = useState("");
	const [observacionesGenerales, setObservacionesGenerales] = useState("");
	const [fotoBlob, setFotoBlob] = useState(null);
	const [previewUrl, setPreviewUrl] = useState(null);
	// Campos de Tablero
	const [maxPoles, setMaxPoles] = useState(24);
	// Campos de Transformador
	const [kvaTrafo, setKvaTrafo] = useState("");
	const [marcaTrafo, setMarcaTrafo] = useState("");
	const [tipoTrafo, setTipoTrafo] = useState("Pedestal");
	const [conexionTrafo, setConexionTrafo] = useState("");
	const [voltajePrimario, setVoltajePrimario] = useState("");
	const [voltajeSecundario, setVoltajeSecundario] = useState("");
	// Campos de Generador
	const [kvaGen, setKvaGen] = useState("");
	const [combustibleGen, setCombustibleGen] = useState("DIESEL");
	const [voltajeGen, setVoltajeGen] = useState("");
	const [potenciaKwGen, setPotenciaKwGen] = useState("");
	const [amperajeGen, setAmperajeGen] = useState("");
	// Campos de Puesta a Tierra
	const [resistenciaOhmios, setResistenciaOhmios] = useState("");
	const [corrienteFuga, setCorrienteFuga] = useState("");
	const [tipoMalla, setTipoMalla] = useState("");
	const [cableAcometidaTierra, setCableAcometidaTierra] = useState("");
	// Campos de Transfer
	const [capacidadAmperios, setCapacidadAmperios] = useState("");
	const [tipoTransferencia, setTipoTransferencia] = useState("AUTOMATICA");
	const [tensionOperativa, setTensionOperativa] = useState("");
	// Campos de Banco de Condensadores
	const [kvarTotal, setKvarTotal] = useState("");
	const [pasosCondensador, setPasosCondensador] = useState("");
	const [tipoBanco, setTipoBanco] = useState("AUTOMATICO");
	const [tensionBanco, setTensionBanco] = useState("");
	// Campos de Punto de Suministro
	const [suministroTension, setSuministroTension] = useState("");
	const [suministroEmpresa, setSuministroEmpresa] = useState("CORPOELEC");
	const [suministroTipoAcometida, setSuministroTipoAcometida] = useState("Subterránea");
	const [suministroCapacidad, setSuministroCapacidad] = useState("");
	const [suministroTipoMedicion, setSuministroTipoMedicion] = useState("Medición Directa (Baja Tensión)");
	const [suministroEnlaceCorpoelec, setSuministroEnlaceCorpoelec] = useState(true);
	const [suministroNumeroContrato, setSuministroNumeroContrato] = useState("");
	const [suministroNic, setSuministroNic] = useState("");
	const [suministroPosteTrafo, setSuministroPosteTrafo] = useState("");
	// Campos de CCM Elemento
	const [ccmCapacidadBarra, setCcmCapacidadBarra] = useState("");
	const [ccmTension, setCcmTension] = useState("");
	const [ccmBreakerPrincipal, setCcmBreakerPrincipal] = useState("");
	const [ccmNumeroGavetas, setCcmNumeroGavetas] = useState(8);
	// Campos de Otro
	const [descripcionOtro, setDescripcionOtro] = useState("");
	// Campos de Inspecciones Separadas (Capa 2)
	const [tipoInspeccionModal, setTipoInspeccionModal] = useState("AMBIENTAL_FISICA");
	// 1. Ambiental / Física (Subestación)
	const [subestacionNombre, setSubestacionNombre] = useState("");
	const [subestacionUbicacion, setSubestacionUbicacion] = useState("");
	const [nivelTension, setNivelTension] = useState("13.8 kV");
	const [inspectorName, setInspectorName] = useState("");
	// 2. Termográfica
	const [termoNombre, setTermoNombre] = useState("");
	const [termoUbicacion, setTermoUbicacion] = useState("");
	const [termoTempAmbiente, setTermoTempAmbiente] = useState("25");
	const [termoTempPuntoCaliente, setTermoTempPuntoCaliente] = useState("");
	const [termoTempRef, setTermoTempRef] = useState("30");
	const [termoCamara, setTermoCamara] = useState("FLIR E8-XT");
	// 3. Sistema de Aterramiento (PAT)
	const [patNombre, setPatNombre] = useState("");
	const [patUbicacion, setPatUbicacion] = useState("");
	const [patResistencia, setPatResistencia] = useState("");
	const [patMetodo, setPatMetodo] = useState("Caída de Potencial (62%)");
	const [patTipo, setPatTipo] = useState("Malla con Varillas");
	const [patUnion, setPatUnion] = useState("Soldadura Exotérmica (Cadweld)");
	const [patTelurometro, setPatTelurometro] = useState("AEMC 4630");
	// 4. Tanque de Combustible
	const [tanqueNombre, setTanqueNombre] = useState("");
	const [tanqueUbicacion, setTanqueUbicacion] = useState("");
	const [tanqueTipoCombustible, setTanqueTipoCombustible] = useState("DIESEL");
	const [tanqueCapacidadLitros, setTanqueCapacidadLitros] = useState("2000");
	const [tanqueNivelPorcentaje, setTanqueNivelPorcentaje] = useState("75");
	const [tanqueConsumoLh, setTanqueConsumoLh] = useState("45");
	const [tanqueDique110, setTanqueDique110] = useState("CONFORME");
	if (!company || !proyecto) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center p-6 text-center space-y-4 font-sans",
			children: [
				/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-12 h-12 text-amber-500 animate-pulse" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 448,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-bold",
					children: "Proyecto o Empresa no encontrado"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 449,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => navigate(`/empresa/${companyId || ""}`),
					className: "px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs rounded-xl font-bold transition-all shadow-md",
					children: "Volver a la Empresa"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 450,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 447,
			columnNumber: 7
		}, this);
	}
	const elementos = proyecto.elementosUnifilares || proyecto.tableros || [];
	const inspecciones = proyecto.inspeccionesSubestacion || proyecto.subestaciones || [];
	const puntosMedicion = proyecto.puntosMedicion || [];
	const filteredElementos = elementos.filter((item) => item.nombre.toLowerCase().includes(searchQuery.toLowerCase()) || item.ubicacion && item.ubicacion.toLowerCase().includes(searchQuery.toLowerCase()) || item.tipoElemento.toLowerCase().includes(searchQuery.toLowerCase()));
	const filteredInspecciones = inspecciones.filter((item) => item.nombre.toLowerCase().includes(searchQuery.toLowerCase()) || item.ubicacion && item.ubicacion.toLowerCase().includes(searchQuery.toLowerCase()) || item.inspector && item.inspector.toLowerCase().includes(searchQuery.toLowerCase()));
	const filteredPuntosMedicion = puntosMedicion.filter((item) => item.nombre && item.nombre.toLowerCase().includes(searchQuery.toLowerCase()) || item.nombreUsuario && item.nombreUsuario.toLowerCase().includes(searchQuery.toLowerCase()) || item.numeroContrato && item.numeroContrato.toLowerCase().includes(searchQuery.toLowerCase()) || item.codigoElementoPrincipal && item.codigoElementoPrincipal.toLowerCase().includes(searchQuery.toLowerCase()));
	const nombreElementoDuplicado = elementos.some((e) => e.nombre.toLowerCase().trim() === nombre.toLowerCase().trim() && e.id !== editingElemento?.id);
	const nombreInspeccionDuplicado = inspecciones.some((s) => s.nombre.toLowerCase().trim() === subestacionNombre.toLowerCase().trim());
	const isElementoFormValid = nombre.trim() !== "" && !nombreElementoDuplicado;
	const isInspeccionFormValid = tipoInspeccionModal === "AMBIENTAL_FISICA" || tipoInspeccionModal === "SUBESTACION" ? subestacionNombre.trim() !== "" && !nombreInspeccionDuplicado : tipoInspeccionModal === "TERMOGRAFICA" ? termoNombre.trim() !== "" : tipoInspeccionModal === "SISTEMA_ATERRAMIENTO" || tipoInspeccionModal === "PUESTA_TIERRA" ? patNombre.trim() !== "" || subestacionNombre.trim() !== "" : tipoInspeccionModal === "TANQUE_COMBUSTIBLE" ? tanqueNombre.trim() !== "" : true;
	const handleImageChange = (e) => {
		const file = e.target.files[0];
		if (!file) return;
		if (file.size > 10 * 1024 * 1024) {
			customAlert("La imagen es demasiado grande. Por favor elija una de menos de 10MB.");
			return;
		}
		setFotoBlob(file);
		if (previewUrl) URL.revokeObjectURL(previewUrl);
		setPreviewUrl(URL.createObjectURL(file));
	};
	const handleCreateElemento = (e) => {
		e.preventDefault();
		if (!isElementoFormValid) return;
		let datosTecnicos = {};
		if (tipoElemento === "TABLERO") {
			datosTecnicos = {
				maxPoles: parseInt(maxPoles, 10),
				barrasPrincipales: editingElemento?.datosTecnicos?.barrasPrincipales || {
					ia: "0",
					ib: "0",
					ic: "0"
				},
				breakerPrincipal: editingElemento?.datosTecnicos?.breakerPrincipal || {
					marca: "",
					tipo: "",
					amp: ""
				},
				voltaje: editingElemento?.datosTecnicos?.voltaje || {
					va: "208",
					vb: "205",
					vc: "205"
				},
				acometida: editingElemento?.datosTecnicos?.acometida || "",
				circuits: editingElemento?.datosTecnicos?.circuits || [],
				neutroLlegada: editingElemento?.datosTecnicos?.neutroLlegada || {
					calibre: "",
					observaciones: ""
				},
				puestaTierra: editingElemento?.datosTecnicos?.puestaTierra || {
					calibre: "",
					observaciones: ""
				}
			};
		} else if (tipoElemento === "TRANSFORMADOR") {
			const kvaNum = parseFloat(String(kvaTrafo || editingElemento?.datosTecnicos?.kva || editingElemento?.datosTecnicos?.potenciaKva || 0).replace(/[^0-9.]/g, "")) || null;
			const fpTrafo = parseFloat(editingElemento?.datosTecnicos?.factorPotencia || .9) || .9;
			const kvarCalc = kvaNum ? Math.round(kvaNum * Math.sqrt(Math.max(0, 1 - Math.pow(fpTrafo, 2))) * 100) / 100 : null;
			const secVolts = parseFloat(String(voltajeSecundario || editingElemento?.datosTecnicos?.voltajeSecundario || "208").replace(/[^0-9.]/g, "")) || 208;
			const secAmps = kvaNum && secVolts > 0 ? Math.round(kvaNum * 1e3 / (Math.sqrt(3) * secVolts) * 100) / 100 : null;
			datosTecnicos = {
				marca: marcaTrafo || editingElemento?.datosTecnicos?.marca || "",
				fases: editingElemento?.datosTecnicos?.fases || "3",
				potenciaKva: kvaTrafo || editingElemento?.datosTecnicos?.potenciaKva || "",
				kva: kvaNum || kvaTrafo || "",
				capEx: editingElemento?.datosTecnicos?.capEx || kvaNum || null,
				capRe: editingElemento?.datosTecnicos?.capRe || kvarCalc || null,
				kvar: editingElemento?.datosTecnicos?.kvar || kvarCalc || null,
				factorPotencia: fpTrafo,
				corrienteNominalA: editingElemento?.datosTecnicos?.corrienteNominalA || secAmps,
				corrienteNominalB: editingElemento?.datosTecnicos?.corrienteNominalB || secAmps,
				corrienteNominalC: editingElemento?.datosTecnicos?.corrienteNominalC || secAmps,
				corrienteSecundaria: editingElemento?.datosTecnicos?.corrienteSecundaria || secAmps,
				tipoTransformador: tipoTrafo || editingElemento?.datosTecnicos?.tipoTransformador || "Pedestal",
				conexion: conexionTrafo || editingElemento?.datosTecnicos?.conexion || "",
				voltajePrimario: voltajePrimario || editingElemento?.datosTecnicos?.voltajePrimario || "",
				voltajeSecundario: voltajeSecundario || editingElemento?.datosTecnicos?.voltajeSecundario || "",
				impedanciaPct: editingElemento?.datosTecnicos?.impedanciaPct || "",
				impedanciaAmp: editingElemento?.datosTecnicos?.impedanciaAmp || "",
				impedanciaTemp: editingElemento?.datosTecnicos?.impedanciaTemp || "",
				tensionPrimaria: editingElemento?.datosTecnicos?.tensionPrimaria || voltajePrimario || "",
				amperiosPrimaria: editingElemento?.datosTecnicos?.amperiosPrimaria || "",
				tensionSecundaria: editingElemento?.datosTecnicos?.tensionSecundaria || voltajeSecundario || "",
				amperiosSecundaria: editingElemento?.datosTecnicos?.amperiosSecundaria || secAmps || "",
				aislamiento: editingElemento?.datosTecnicos?.aislamiento || "",
				aceite: editingElemento?.datosTecnicos?.aceite || "",
				seco: editingElemento?.datosTecnicos?.seco || "",
				acometidas: editingElemento?.datosTecnicos?.acometidas || {
					primaria: {
						aerea: false,
						subterranea: false,
						calibre: "",
						tipo: "",
						terminal: "",
						fusible: "",
						pararrayo: "",
						observaciones: ""
					},
					secundaria: {
						aerea: false,
						subterranea: false,
						calibre: "",
						tipo: "",
						terminal: "",
						fusible: "",
						pararrayo: "",
						observaciones: ""
					},
					neutro: {
						aerea: false,
						subterranea: false,
						calibre: "",
						tipo: "",
						terminal: "",
						fusible: "",
						pararrayo: "",
						observaciones: ""
					}
				},
				spt: editingElemento?.datosTecnicos?.spt || {
					barillaCalibre: "",
					barillaCantidad: "",
					barillaConfiguracion: "",
					conductorCalibre: "",
					conductorTipoSold: "",
					resistencia: "",
					fechaMedicion: ""
				}
			};
		} else if (tipoElemento === "GENERADOR") {
			const kvaGenNum = parseFloat(String(kvaGen || editingElemento?.datosTecnicos?.kva || 0).replace(/[^0-9.]/g, "")) || null;
			const kwGenNum = parseFloat(String(potenciaKwGen || editingElemento?.datosTecnicos?.kw || editingElemento?.datosTecnicos?.potenciaKw || 0).replace(/[^0-9.]/g, "")) || (kvaGenNum ? Math.round(kvaGenNum * .8 * 100) / 100 : null);
			const fpGen = parseFloat(editingElemento?.datosTecnicos?.factorPotencia || .8) || .8;
			const kvarGen = kvaGenNum ? Math.round(kvaGenNum * Math.sqrt(Math.max(0, 1 - Math.pow(fpGen, 2))) * 100) / 100 : null;
			const ampGenNum = parseFloat(String(amperajeGen || editingElemento?.datosTecnicos?.amperaje || 0).replace(/[^0-9.]/g, "")) || null;
			datosTecnicos = {
				kva: kvaGenNum || kvaGen,
				kw: kwGenNum || potenciaKwGen,
				potenciaKw: kwGenNum || potenciaKwGen,
				kvar: editingElemento?.datosTecnicos?.kvar || kvarGen,
				factorPotencia: fpGen,
				voltajeGeneracion: voltajeGen || editingElemento?.datosTecnicos?.voltajeGeneracion || "",
				amperaje: ampGenNum || amperajeGen,
				tipoCombustible: combustibleGen || editingElemento?.datosTecnicos?.tipoCombustible || editingElemento?.datosTecnicos?.combustible || "DIESEL",
				combustible: combustibleGen || editingElemento?.datosTecnicos?.combustible || "DIESEL",
				capacidadCombustible: editingElemento?.datosTecnicos?.capacidadCombustible || null,
				consumoEspecificado: editingElemento?.datosTecnicos?.consumoEspecificado || null,
				horasOperacion: editingElemento?.datosTecnicos?.horasOperacion || null,
				horasReserva: editingElemento?.datosTecnicos?.horasReserva || null
			};
		} else if (tipoElemento === "BANCO_CONDENSADOR") {
			datosTecnicos = editingElemento?.datosTecnicos || {
				marca: "",
				modelo: "",
				alimentador: "",
				calibreConductor: "",
				fabricante: "",
				anioFabricacion: "",
				tensionNominal: tensionBanco || "208 V",
				tensionRegistrada: tensionBanco || "208 V",
				frecuencia: "60 Hz",
				potenciaReactivaTotal: kvarTotal || "150 kVAR",
				corrienteNominalTotal: "",
				numFases: "Trifásico",
				conexion: "Estrella",
				nivelAislamientoBIL: "",
				tipoCompensacion: tipoBanco === "AUTOMATICO" ? "Automática (Pasos)" : "Fija",
				numPasos: pasosCondensador || "6",
				secuenciaPasosKvar: "",
				tipoConmutacion: "Contactores dedicados",
				potenciaIndividual: "",
				capacitanciaMuf: "",
				tensionCondensador: "",
				tecnologiaDielectrica: "Polipropileno metalizado",
				resistenciaDescarga: "Sí",
				seguridad: "Desconectador por sobrepresión",
				factorDesintonizacion: "N/A",
				tipoNucleo: "Núcleo de Hierro con Entrehierro",
				claseAislamientoTermico: "Clase H (180°C)",
				proteccionTermica: "Sensor Bimetálico / PT100 integrado",
				reguladorMarcaModelo: "",
				relacionTc: "",
				puertoComunicacion: "RS-485 (Modbus RTU)",
				interruptorPrincipalAmp: "",
				proteccionPasos: "Fusibles",
				gradoProteccionEnvolvente: "IP54",
				dimensionesAlto: "",
				dimensionesAncho: "",
				dimensionesProf: "",
				sistemaEnfriamiento: "Ventilación Forzada",
				temperaturaC: "",
				humedadPct: ""
			};
		} else if (tipoElemento === "PUNTO_SUMINISTRO") {
			datosTecnicos = {
				...editingElemento?.datosTecnicos || {},
				nivelTension: suministroTension || "13.8 kV",
				tensionNominal: suministroTension || "13.8 kV",
				empresaDistribuidora: suministroEmpresa || "CORPOELEC",
				tipoAcometida: suministroTipoAcometida || "Subterránea",
				capacidadContratadaKva: suministroCapacidad || "",
				cargaContratadaKva: suministroCapacidad || "",
				tipoMedicion: suministroTipoMedicion || "Medición Directa (Baja Tensión)",
				enlaceCorpoelec: Boolean(suministroEnlaceCorpoelec),
				numeroContrato: suministroNumeroContrato || "",
				nic: suministroNic || "",
				posteTransformador: suministroPosteTrafo || ""
			};
		} else if (tipoElemento === "CCM") {
			datosTecnicos = {
				capacidadBarraAmperios: ccmCapacidadBarra || "1200 A",
				tensionOperativa: ccmTension || "480 V",
				breakerPrincipal: ccmBreakerPrincipal || "1200A 3P",
				numeroGavetas: parseInt(ccmNumeroGavetas, 10) || 8
			};
		} else if (tipoElemento === "PUESTA_TIERRA") {
			datosTecnicos = {
				resistenciaOhmios,
				corrienteFugaAmperios: corrienteFuga,
				tipoMalla,
				cableAcometida: cableAcometidaTierra
			};
		} else if (tipoElemento === "TRANSFER") {
			datosTecnicos = {
				capacidadAmperios,
				tipoTransferencia,
				tensionOperativa
			};
		} else {
			datosTecnicos = { descripcionEspecificaciones: descripcionOtro };
		}
		if (editingElemento) {
			updateElementoUnifilar(proyectoId, editingElemento.id, {
				nombre: nombre.trim(),
				tipoElemento,
				ubicacion: ubicacion.trim() || "Sin ubicación",
				alimentadoPor: alimentadoPor.trim() || "No definido",
				observacionesGenerales: observacionesGenerales.trim(),
				datosTecnicos
			});
			showToast?.("Elemento actualizado correctamente.", "success");
			setEditingElemento(null);
			setShowElementoModal(false);
		} else {
			const result = addElementoUnifilar(proyectoId, {
				nombre: nombre.trim(),
				tipoElemento,
				ubicacion: ubicacion.trim() || "Sin ubicación",
				alimentadoPor: alimentadoPor.trim() || "No definido",
				fotoBlob,
				observacionesGenerales: observacionesGenerales.trim(),
				datosTecnicos
			});
			if (result.success) {
				setNombre("");
				setUbicacion("");
				setAlimentadoPor("");
				setObservacionesGenerales("");
				setFotoBlob(null);
				if (previewUrl) URL.revokeObjectURL(previewUrl);
				setPreviewUrl(null);
				setShowElementoModal(false);
				showToast?.("Elemento registrado correctamente.", "success");
			} else {
				customAlert(result.error);
			}
		}
	};
	const handleCreateInspeccion = (e) => {
		e.preventDefault();
		if (!isInspeccionFormValid) return;
		if (tipoInspeccionModal === "AMBIENTAL_FISICA" || tipoInspeccionModal === "SUBESTACION") {
			const result = addInspeccionSubestacion(proyectoId, {
				nombre: subestacionNombre.trim() || "Subestación Principal",
				ubicacion: subestacionUbicacion.trim() || "Sala Eléctrica",
				nivelTension: nivelTension.trim() || "13.8 kV",
				inspector: inspectorName.trim() || "No asignado",
				fecha: new Date().toISOString().split("T")[0],
				hora: new Date().toLocaleTimeString("es-ES", {
					hour: "2-digit",
					minute: "2-digit"
				}),
				estadoEntorno: {},
				obrasCiviles: {},
				equiposPrincipales: {},
				puestaTierra: {},
				edificioControl: {}
			});
			if (result.success) {
				setSubestacionNombre("");
				setSubestacionUbicacion("");
				setNivelTension("13.8 kV");
				setInspectorName("");
				setShowInspeccionModal(false);
				showToast?.("Inspección Ambiental o Física registrada exitosamente.", "success");
			} else {
				customAlert(result.error);
			}
			return;
		}
		if (tipoInspeccionModal === "TERMOGRAFICA") {
			const tPunto = parseFloat(termoTempPuntoCaliente) || 0;
			const tRef = parseFloat(termoTempRef) || 0;
			const deltaT = (tPunto - tRef).toFixed(1);
			let severidad = "NORMAL";
			if (deltaT > 40) severidad = "CRITICA";
			else if (deltaT > 20) severidad = "ALTA";
			else if (deltaT > 10) severidad = "MODERADA";
			const result = addInspeccionSubestacion(proyectoId, {
				nombre: termoNombre.trim() || `IT-1: Inspección Termográfica`,
				tipoElemento: "TERMOGRAFICA",
				ubicacion: termoUbicacion.trim() || "Sala Eléctrica",
				nivelTension: "Termografía",
				inspector: inspectorName.trim() || user?.username || "Inspector",
				fecha: new Date().toISOString().split("T")[0],
				hora: new Date().toLocaleTimeString("es-ES", {
					hour: "2-digit",
					minute: "2-digit"
				}),
				estadoEntorno: {},
				obrasCiviles: {},
				equiposPrincipales: {
					temperaturaAmbiente: termoTempAmbiente,
					temperaturaPuntoCaliente: termoTempPuntoCaliente,
					temperaturaReferencia: termoTempRef,
					deltaT,
					severidadNeta: severidad,
					camaraModelo: termoCamara
				},
				puestaTierra: {},
				edificioControl: {}
			});
			if (result.success) {
				setTermoNombre("");
				setTermoUbicacion("");
				setTermoTempPuntoCaliente("");
				setShowInspeccionModal(false);
				showToast?.("Inspección Termográfica registrada exitosamente.", "success");
			} else {
				customAlert(result.error);
			}
			return;
		}
		if (tipoInspeccionModal === "SISTEMA_ATERRAMIENTO" || tipoInspeccionModal === "PUESTA_TIERRA") {
			const rOhms = parseFloat(patResistencia) || 0;
			let cumplimientoIeee = "CUMPLE (Excelente <= 5Ω)";
			if (rOhms > 10) cumplimientoIeee = "NO CUMPLE (> 10Ω - Requiere Mantenimiento)";
			else if (rOhms > 5) cumplimientoIeee = "ACEPTABLE (<= 10Ω)";
			const result = addInspeccionSubestacion(proyectoId, {
				nombre: (patNombre || subestacionNombre).trim() || `PAT-1: Sistema de Aterramiento`,
				tipoElemento: "SISTEMA_ATERRAMIENTO",
				ubicacion: (patUbicacion || subestacionUbicacion).trim() || "Patio / Sala Eléctrica",
				nivelTension: "Aterramiento PAT",
				inspector: inspectorName.trim() || user?.username || "Inspector",
				fecha: new Date().toISOString().split("T")[0],
				hora: new Date().toLocaleTimeString("es-ES", {
					hour: "2-digit",
					minute: "2-digit"
				}),
				estadoEntorno: {},
				obrasCiviles: {},
				equiposPrincipales: {},
				puestaTierra: {
					resistenciaOhms: patResistencia.trim() || "",
					metodoMedicion: patMetodo || "Caída de Potencial (62%)",
					tipoSistemaPat: patTipo || "Malla con Varillas",
					tipoUnion: patUnion || "Soldadura Exotérmica (Cadweld)",
					telurometro: patTelurometro,
					cumplimientoIeee80: cumplimientoIeee
				},
				edificioControl: {}
			});
			if (result.success) {
				setPatNombre("");
				setPatUbicacion("");
				setPatResistencia("");
				setSubestacionNombre("");
				setSubestacionUbicacion("");
				setShowInspeccionModal(false);
				showToast?.("Inspección del Sistema de Aterramiento registrada exitosamente.", "success");
			} else {
				customAlert(result.error);
			}
			return;
		}
		if (tipoInspeccionModal === "TANQUE_COMBUSTIBLE") {
			const capLitros = parseFloat(tanqueCapacidadLitros) || 0;
			const nivelPct = parseFloat(tanqueNivelPorcentaje) || 0;
			const consumo = parseFloat(tanqueConsumoLh) || 1;
			const litrosActuales = (capLitros * nivelPct / 100).toFixed(0);
			const autonomiaHoras = (litrosActuales / (consumo || 1)).toFixed(1);
			const result = addInspeccionSubestacion(proyectoId, {
				nombre: tanqueNombre.trim() || `TK-1: Tanque de Combustible`,
				tipoElemento: "TANQUE_COMBUSTIBLE",
				ubicacion: tanqueUbicacion.trim() || "Área de Generación",
				nivelTension: "Combustible",
				inspector: inspectorName.trim() || user?.username || "Inspector",
				fecha: new Date().toISOString().split("T")[0],
				hora: new Date().toLocaleTimeString("es-ES", {
					hour: "2-digit",
					minute: "2-digit"
				}),
				estadoEntorno: {
					tipoCombustible: tanqueTipoCombustible,
					capacidadLitros: tanqueCapacidadLitros,
					nivelPorcentaje: tanqueNivelPorcentaje,
					litrosActuales,
					consumoLh: tanqueConsumoLh,
					autonomiaHorasCalculada: autonomiaHoras,
					diqueContencion110: tanqueDique110
				},
				obrasCiviles: {},
				equiposPrincipales: {},
				puestaTierra: {},
				edificioControl: {}
			});
			if (result.success) {
				setTanqueNombre("");
				setTanqueUbicacion("");
				setShowInspeccionModal(false);
				showToast?.("Inspección de Tanque de Combustible registrada exitosamente.", "success");
			} else {
				customAlert(result.error);
			}
			return;
		}
	};
	const handleCreatePuntoMedicion = (e) => {
		e.preventDefault();
		if (!puntoMedicionNombre.trim()) return;
		const result = addPuntoMedicion(proyectoId, {
			nombre: puntoMedicionNombre.trim(),
			nombreUsuario: puntoMedicionUsuario.trim() || "",
			numeroContrato: puntoMedicionNIC.trim() || "",
			nivelTensionContrato: puntoMedicionNivelTension || "Media Tensión",
			inspector: user?.username || "Inspector",
			fecha: new Date().toISOString().split("T")[0],
			hora: new Date().toLocaleTimeString("es-ES", {
				hour: "2-digit",
				minute: "2-digit"
			})
		});
		if (result.success) {
			setPuntoMedicionNombre("");
			setPuntoMedicionUsuario("");
			setPuntoMedicionNIC("");
			setShowPuntoMedicionModal(false);
			showToast?.("Punto de Medición registrado con éxito", "success");
		} else {
			customAlert(result.error);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased font-sans",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-slate-950 border-b border-slate-800/80 px-6 py-4 flex items-center justify-between shadow-lg",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigate(`/empresa/${companyId}`),
						className: "p-2.5 bg-slate-900 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-slate-200 transition-all border border-slate-800 active:scale-95 cursor-pointer",
						title: "Volver a la Empresa",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 898,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 893,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider block",
							children: ["Proyecto de: ", company.nombre]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 901,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-lg font-bold text-slate-100 tracking-tight",
							children: proyecto.nombre
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 904,
							columnNumber: 13
						}, this),
						proyecto.descripcion && /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-0.5 line-clamp-1",
							children: proyecto.descripcion
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 906,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 900,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 892,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 891,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-6 py-8 space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-start gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider block mb-1",
										children: "Proyecto Técnico"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 919,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-xl font-extrabold text-slate-100 tracking-tight flex items-center gap-2",
										children: [
											/* @__PURE__ */ _jsxDEV(Building, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 921,
												columnNumber: 17
											}, this),
											" ",
											proyecto.nombre
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 920,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 mt-1 max-w-2xl",
										children: proyecto.descripcion || "Sin descripción."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 923,
										columnNumber: 15
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 918,
									columnNumber: 13
								}, this), user?.role === "ADMIN" && activeTab !== "ESTRUCTURAL" && /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setEditProyectoNombre(proyecto.nombre);
										setEditProyectoDescripcion(proyecto.descripcion || "");
										setEditProyectoDireccion(proyecto.direccion || "");
										setEditResponsableNombre(proyecto.responsableNombre || "");
										setEditResponsableTelefono(proyecto.responsableTelefono || "");
										setEditResponsableEmail(proyecto.responsableEmail || "");
										setShowEditProyectoModal(true);
									},
									className: "px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold rounded-lg text-slate-200 hover:text-slate-100 flex items-center gap-1.5 transition-all cursor-pointer shadow-md",
									children: "Editar Proyecto"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 926,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 917,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6 pt-6 border-t border-slate-900",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "md:col-span-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 font-bold uppercase block",
											children: "Ubicación / Dirección"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 945,
											columnNumber: 15
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm font-semibold text-slate-200",
											children: proyecto.direccion || "No definida"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 946,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 944,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 font-bold uppercase block",
										children: "Empresa"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 949,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-sm font-semibold text-slate-200",
										children: company?.nombre
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 950,
										columnNumber: 15
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 948,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 font-bold uppercase block",
										children: "Registro"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 953,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-slate-400 font-mono mt-1 space-y-0.5",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: ["Creado: ", proyecto.createdAt ? new Date(proyecto.createdAt).toLocaleString("es-ES") : "N/D"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 955,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: ["Actualizado: ", proyecto.updatedAt ? new Date(proyecto.updatedAt).toLocaleString("es-ES") : "N/D"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 956,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 954,
										columnNumber: 15
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 952,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 943,
								columnNumber: 11
							}, this),
							user?.role === "ADMIN" && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 pt-6 border-t border-slate-900",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-sky-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 964,
										columnNumber: 17
									}, this), " Responsable del Proyecto (Solo Visible para Administradores)"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 963,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-900/50 p-4 rounded-xl border border-slate-900 max-w-md",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1.5 text-xs",
										children: [
											/* @__PURE__ */ _jsxDEV("div", { children: [
												/* @__PURE__ */ _jsxDEV("strong", {
													className: "text-slate-450",
													children: "Nombre:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 968,
													columnNumber: 24
												}, this),
												" ",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-slate-255 font-semibold",
													children: proyecto.responsableNombre || "N/D"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 968,
													columnNumber: 76
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 968,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: [
												/* @__PURE__ */ _jsxDEV("strong", {
													className: "text-slate-450",
													children: "Teléfono:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 969,
													columnNumber: 24
												}, this),
												" ",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-slate-255 font-semibold",
													children: proyecto.responsableTelefono || "N/D"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 969,
													columnNumber: 78
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 969,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: [
												/* @__PURE__ */ _jsxDEV("strong", {
													className: "text-slate-450",
													children: "Email:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 970,
													columnNumber: 24
												}, this),
												" ",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-slate-255 font-semibold",
													children: proyecto.responsableEmail || "N/D"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 970,
													columnNumber: 75
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 970,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 967,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 966,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 962,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 916,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4 pb-6 border-b border-slate-800/80",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex bg-slate-950 p-1.5 rounded-2xl border border-slate-800 self-start",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("UNIFILAR"),
								className: `px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${activeTab === "UNIFILAR" ? "bg-amber-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"}`,
								children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 992,
									columnNumber: 15
								}, this), " Diagrama Unifilar"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 984,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("ESTRUCTURAL"),
								className: `px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${activeTab === "ESTRUCTURAL" ? "bg-amber-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"}`,
								children: [/* @__PURE__ */ _jsxDEV(Building, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1002,
									columnNumber: 15
								}, this), " Inspecciones"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 994,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 983,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap md:flex-nowrap items-center gap-3 justify-end w-full md:w-auto",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "relative w-full md:w-60",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: searchQuery,
									onChange: (e) => setSearchQuery(e.target.value),
									placeholder: "Buscar en esta sección...",
									className: "w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 hover:border-slate-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none h-10 transition-all"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1011,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 absolute left-3.5 top-3 text-slate-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1018,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1010,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap md:flex-nowrap items-center gap-3 w-full md:w-auto justify-end",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center bg-slate-950 border border-slate-800 p-1.5 rounded-xl gap-1",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => navigate(`/empresa/${companyId}/proyecto/${proyectoId}/informe`),
										className: "bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-bold transition-all px-3 py-2 rounded-lg flex items-center gap-1.5 h-9 text-xs cursor-pointer shadow-md",
										title: "Generar Informe Técnico PDF completo",
										children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1031,
											columnNumber: 19
										}, this), " Informe PDF"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1026,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setShowHelpModal(true),
										className: "bg-slate-900 border border-slate-800 hover:border-amber-500/40 text-slate-300 hover:text-amber-400 font-semibold px-3 py-2 rounded-lg flex items-center gap-1.5 h-9 text-xs transition-all cursor-pointer shadow-sm",
										title: "Manual de Usuario, Matriz de Roles y Normativa Eléctrica",
										children: [/* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1038,
											columnNumber: 19
										}, this), " Ayuda / Manual"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1033,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1025,
									columnNumber: 15
								}, this), user?.role !== "CLIENT" && /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [activeTab === "UNIFILAR" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setIsMultiSelectMode(!isMultiSelectMode);
											setSelectedIds(new Set());
										},
										className: `border font-semibold transition-all px-3.5 py-2 rounded-xl flex items-center justify-center gap-2 h-9 cursor-pointer text-xs ${isMultiSelectMode ? "bg-amber-500/10 border-amber-500/40 text-amber-500" : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"}`,
										children: [
											/* @__PURE__ */ _jsxDEV(CheckSquare, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1059,
												columnNumber: 25
											}, this),
											" ",
											isMultiSelectMode ? "Cancelar Selección" : "Seleccionar Varios"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1048,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setTipoElemento("TABLERO");
											setShowElementoModal(true);
										},
										className: "bg-slate-900 border border-slate-800 text-slate-100 font-semibold hover:bg-slate-850 active:scale-95 transition-all px-3.5 py-2 rounded-xl flex items-center justify-center gap-2 h-9 cursor-pointer text-xs",
										children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1069,
											columnNumber: 25
										}, this), " + Crear Elemento"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1062,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1047,
										columnNumber: 21
									}, this), activeTab === "ESTRUCTURAL" && /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setShowInspeccionModal(true),
										className: "bg-slate-900 border border-slate-800 text-slate-100 font-bold hover:bg-slate-850 active:scale-95 transition-all px-3.5 py-2 rounded-xl flex items-center justify-center gap-2 h-9 cursor-pointer text-xs",
										children: [/* @__PURE__ */ _jsxDEV(Building, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1080,
											columnNumber: 23
										}, this), " + Crear Inspección"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1076,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1044,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1022,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1007,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 980,
						columnNumber: 9
					}, this),
					isMultiSelectMode && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 border border-amber-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 animate-fadeIn shadow-lg shadow-amber-500/5",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-2 h-2 rounded-full bg-amber-500 animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1092,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-300 font-medium",
								children: [
									"Modo Selección Múltiple: ",
									/* @__PURE__ */ _jsxDEV("strong", {
										className: "text-amber-500 font-bold",
										children: selectedIds.size
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1094,
										columnNumber: 42
									}, this),
									" ",
									selectedIds.size === 1 ? "elemento seleccionado" : "elementos seleccionados"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1093,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1091,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleSelectAll,
									className: "px-3.5 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-[11px] font-semibold text-slate-300 transition-all cursor-pointer hover:text-slate-100",
									children: "Seleccionar Todo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1098,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleDeselectAll,
									className: "px-3.5 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-[11px] font-semibold text-slate-300 transition-all cursor-pointer hover:text-slate-100",
									children: "Deseleccionar Todo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1104,
									columnNumber: 15
								}, this),
								selectedIds.size > 0 && user?.role !== "CLIENT" && /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleDeleteSelected,
									className: "px-3.5 py-2 bg-red-950/40 hover:bg-red-900/60 border border-red-800/40 rounded-xl text-[11px] font-bold text-red-400 hover:text-red-300 flex items-center gap-1.5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1115,
											columnNumber: 19
										}, this),
										" Eliminar (",
										selectedIds.size,
										")"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1111,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setIsMultiSelectMode(false);
										setSelectedIds(new Set());
									},
									className: "px-3.5 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-[11px] font-semibold text-slate-400 hover:text-slate-200 transition-all cursor-pointer",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1118,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1097,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1090,
						columnNumber: 11
					}, this),
					activeTab === "ESTRUCTURAL" && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-4",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-md font-bold text-slate-200",
							children: "Fichas de Inspecciones Técnicas"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1135,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500",
							children: "Inspecciones de obras civiles, termografía, sistema de aterramiento (SPAT) y tanques de combustible."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1136,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1134,
						columnNumber: 13
					}, this), filteredInspecciones.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
						children: filteredInspecciones.map((item) => {
							const isSelected = selectedIds.has(item.id);
							return /* @__PURE__ */ _jsxDEV("div", {
								onClick: () => {
									if (isMultiSelectMode) {
										handleToggleSelect(item.id);
									} else {
										navigate(`/empresa/${companyId}/tablero/${item.id}`);
									}
								},
								className: `bg-slate-950 border flex flex-col justify-between overflow-hidden cursor-pointer transition-all hover:-translate-y-0.5 group rounded-2xl shadow-md hover:shadow-xl ${isMultiSelectMode && isSelected ? "border-amber-500 shadow-amber-500/5 ring-1 ring-amber-500/20" : "border-slate-800/80 hover:border-slate-700/60"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "h-32 w-full bg-gradient-to-br from-slate-900 to-slate-900/40 relative flex flex-col items-center justify-center border-b border-slate-900/50 select-none",
									children: [
										/* @__PURE__ */ _jsxDEV(Building, { className: "w-9 h-9 text-amber-500/70 group-hover:scale-105 transition-transform duration-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1160,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] uppercase font-bold tracking-widest opacity-35 mt-2",
											children: item.tipoElemento === "TERMOGRAFICA" ? "Inspección Termográfica" : item.tipoElemento === "SISTEMA_ATERRAMIENTO" ? "Puesta a Tierra (SPAT)" : item.tipoElemento === "TANQUE_COMBUSTIBLE" ? "Tanque de Combustible" : "Inspección Visual / Civil"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1161,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-3 left-3",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: "px-3 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-[10px] font-bold font-mono",
												children: item.tipoElemento === "TERMOGRAFICA" ? "🔥 TERMOGRAFÍA" : item.tipoElemento === "SISTEMA_ATERRAMIENTO" ? "🛡️ SPAT ATERRAMIENTO" : item.tipoElemento === "TANQUE_COMBUSTIBLE" ? "⛽ TANQUE COMBUSTIBLE" : "🏢 SUBESTACIÓN"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1166,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1165,
											columnNumber: 25
										}, this),
										!isMultiSelectMode && /* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-3 right-3 flex items-center gap-2",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: "font-mono font-black text-amber-400 bg-slate-900 border border-amber-500/30 px-2.5 py-0.5 rounded-lg text-xs shadow-sm",
												children: ["ID: ", item.id]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1173,
												columnNumber: 29
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1172,
											columnNumber: 27
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1159,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-5 flex-1 flex flex-col justify-between",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-sm font-bold text-slate-100 group-hover:text-amber-500 transition-colors truncate",
												children: formatElementTitleWithId(item.nombre, item.id)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1182,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "space-y-1 mt-3 text-[11px] text-slate-400 border-t border-slate-900/60 pt-3",
												children: [
													/* @__PURE__ */ _jsxDEV("p", {
														className: "truncate",
														children: [
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-slate-500 font-bold",
																children: "Ubicación:"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1186,
																columnNumber: 51
															}, this),
															" ",
															item.ubicacion
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1186,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "truncate",
														children: [
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-slate-500 font-bold",
																children: "Tensión:"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1187,
																columnNumber: 51
															}, this),
															" ",
															item.nivelTension
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1187,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "truncate flex items-center gap-1.5",
														children: [
															/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5 text-slate-600 shrink-0" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1188,
																columnNumber: 77
															}, this),
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-slate-500 font-bold",
																children: "Fecha:"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1188,
																columnNumber: 137
															}, this),
															" ",
															item.fecha
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1188,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "truncate flex items-center gap-1.5",
														children: [
															/* @__PURE__ */ _jsxDEV(User, { className: "w-3.5 h-3.5 text-slate-600 shrink-0" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1189,
																columnNumber: 77
															}, this),
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-slate-500 font-bold",
																children: "Inspector:"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1189,
																columnNumber: 133
															}, this),
															" ",
															item.inspector
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1189,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1185,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1181,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-4 pt-3 border-t border-slate-900/80",
											children: /* @__PURE__ */ _jsxDEV(AvanceProgressBar, {
												elemento: item,
												tipoElemento: item.tipoElemento || "SUBESTACION"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1195,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1194,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-3",
											children: /* @__PURE__ */ _jsxDEV(ElementoCardActions, {
												onEdit: () => navigate(`/empresa/${companyId}/tablero/${item.id}`),
												onNewInspection: () => navigate(`/empresa/${companyId}/tablero/${item.id}`),
												onDelete: async () => {
													const ok = await confirm({
														title: "Eliminar Inspección",
														message: `¿Estás seguro de que deseas eliminar la inspección "${item.nombre}"?`,
														type: "danger",
														confirmText: "Eliminar"
													});
													if (ok) {
														deleteSubestacion(proyectoId, item.id);
													}
												},
												readOnly: user?.role === "CLIENT"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1200,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1199,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1180,
									columnNumber: 21
								}, this)]
							}, item.id, true, {
								fileName: _jsxFileName,
								lineNumber: 1144,
								columnNumber: 21
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1140,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "p-16 border-2 border-dashed border-slate-800 rounded-2xl text-center space-y-4 bg-slate-950/20",
						children: [/* @__PURE__ */ _jsxDEV(Building, { className: "w-12 h-12 text-slate-700 mx-auto" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1224,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1 font-sans",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-slate-400",
								children: "No hay inspecciones técnicas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1226,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 max-w-sm mx-auto",
								children: "Crea una ficha de Inspección Técnica (Subestación, Termografía, SPAT o Tanque de Combustible)."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1227,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1225,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1223,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1133,
						columnNumber: 11
					}, this),
					activeTab === "UNIFILAR" && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-md font-bold text-slate-200",
							children: "Equipos Registrados en el Diagrama Unifilar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1241,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500",
							children: "Tableros, Transformadores, Generadores, Puntos de Suministro, Mallas de Tierra y Transferencias."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1242,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1240,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setShowDiagramModal(true),
							className: "bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4.5 py-2.5 rounded-xl flex items-center justify-center gap-2 text-xs transition-all shadow-md active:scale-98 cursor-pointer self-start md:self-auto",
							children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 fill-slate-950" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1249,
								columnNumber: 17
							}, this), " Ver Diagrama Gráfico"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1244,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1239,
						columnNumber: 13
					}, this), filteredElementos.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
						children: filteredElementos.map((item) => {
							const isTablero = item.tipoElemento === "TABLERO";
							const isTrafo = item.tipoElemento === "TRANSFORMADOR";
							const isGen = item.tipoElemento === "GENERADOR";
							const isPuestaTierra = item.tipoElemento === "PUESTA_TIERRA";
							const isTransfer = item.tipoElemento === "TRANSFER";
							const isPuntoSuministro = item.tipoElemento === "PUNTO_SUMINISTRO";
							const isCcm = item.tipoElemento === "CCM";
							const isBanco = item.tipoElemento === "BANCO_CONDENSADOR";
							return /* @__PURE__ */ _jsxDEV("div", {
								onClick: () => {
									if (isMultiSelectMode) {
										handleToggleSelect(item.id);
									} else {
										navigate(`/empresa/${companyId}/tablero/${item.id}`);
									}
								},
								className: `bg-slate-950 border flex flex-col justify-between overflow-hidden cursor-pointer transition-all hover:-translate-y-0.5 group rounded-2xl shadow-md hover:shadow-xl ${isMultiSelectMode && selectedIds.has(item.id) ? "border-amber-500 shadow-amber-500/5 ring-1 ring-amber-500/20" : "border-slate-800/80 hover:border-slate-700/60"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "h-32 w-full bg-slate-900 relative overflow-hidden flex items-center justify-center border-b border-slate-900/50",
									children: [
										item.fotoBlob || item.foto ? /* @__PURE__ */ _jsxDEV(SafeImage, {
											blob: item.fotoBlob,
											src: item.foto,
											alt: item.nombre,
											className: "w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1284,
											columnNumber: 27
										}, this) : /* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-col items-center justify-center text-slate-700 gap-1.5 select-none",
											children: [
												isTablero && /* @__PURE__ */ _jsxDEV(Zap, { className: "w-8 h-8 opacity-25 text-sky-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1292,
													columnNumber: 43
												}, this),
												isTrafo && /* @__PURE__ */ _jsxDEV(Cpu, { className: "w-8 h-8 opacity-25 text-purple-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1293,
													columnNumber: 41
												}, this),
												isGen && /* @__PURE__ */ _jsxDEV(Zap, { className: "w-8 h-8 opacity-25 text-amber-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1294,
													columnNumber: 39
												}, this),
												isPuestaTierra && /* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-8 h-8 opacity-25 text-teal-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1295,
													columnNumber: 48
												}, this),
												isTransfer && /* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-8 h-8 opacity-25 text-emerald-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1296,
													columnNumber: 44
												}, this),
												isPuntoSuministro && /* @__PURE__ */ _jsxDEV(Gauge, { className: "w-8 h-8 opacity-25 text-blue-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1297,
													columnNumber: 51
												}, this),
												isCcm && /* @__PURE__ */ _jsxDEV(Cpu, { className: "w-8 h-8 opacity-25 text-amber-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1298,
													columnNumber: 39
												}, this),
												isBanco && /* @__PURE__ */ _jsxDEV(Layers, { className: "w-8 h-8 opacity-25 text-emerald-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1299,
													columnNumber: 41
												}, this),
												!isTablero && !isTrafo && !isGen && !isPuestaTierra && !isTransfer && !isPuntoSuministro && !isCcm && !isBanco && /* @__PURE__ */ _jsxDEV(Layers, { className: "w-8 h-8 opacity-25 text-slate-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1300,
													columnNumber: 144
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[9px] uppercase font-bold tracking-widest opacity-30",
													children: "Sin Imagen"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1301,
													columnNumber: 29
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1291,
											columnNumber: 27
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-3 left-3",
											children: [
												isTablero && /* @__PURE__ */ _jsxDEV("span", {
													className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-[10px] font-bold font-mono",
													children: "⚡ PANEL ELÉCTRICO"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1308,
													columnNumber: 29
												}, this),
												isTrafo && /* @__PURE__ */ _jsxDEV("span", {
													className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-[10px] font-bold font-mono",
													children: "🔄 TRANSFORMADOR"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1313,
													columnNumber: 29
												}, this),
												isGen && /* @__PURE__ */ _jsxDEV("span", {
													className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-[10px] font-bold font-mono",
													children: "🔋 GENERADOR"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1318,
													columnNumber: 29
												}, this),
												isPuestaTierra && /* @__PURE__ */ _jsxDEV("span", {
													className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-[10px] font-bold font-mono",
													children: "🛡️ PUESTA A TIERRA"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1323,
													columnNumber: 29
												}, this),
												isTransfer && /* @__PURE__ */ _jsxDEV("span", {
													className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-[10px] font-bold font-mono",
													children: "🔀 TRANSFERENCIA"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1328,
													columnNumber: 29
												}, this),
												isPuntoSuministro && /* @__PURE__ */ _jsxDEV("span", {
													className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-[10px] font-bold font-mono",
													children: "🔌 PTO. SUMINISTRO"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1333,
													columnNumber: 29
												}, this),
												isCcm && /* @__PURE__ */ _jsxDEV("span", {
													className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-[10px] font-bold font-mono",
													children: "⚙️ CCM MOTORES"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1338,
													columnNumber: 29
												}, this),
												isBanco && /* @__PURE__ */ _jsxDEV("span", {
													className: "px-3.5 py-1 bg-amber-950/90 text-amber-500 border border-amber-800/50 rounded-full text-[10px] font-bold font-mono",
													children: "⚡ BANCO CONDENSADOR"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1343,
													columnNumber: 29
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1306,
											columnNumber: 25
										}, this),
										!isMultiSelectMode && /* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-3 right-3 flex items-center gap-2",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: "font-mono font-black text-amber-400 bg-slate-900 border border-amber-500/30 px-2.5 py-0.5 rounded-lg text-xs shadow-sm",
												children: ["ID: ", item.id]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1351,
												columnNumber: 29
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1350,
											columnNumber: 27
										}, this),
										isMultiSelectMode && /* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-3 right-3 z-10",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: `p-1.5 rounded-lg flex items-center justify-center border transition-all ${selectedIds.has(item.id) ? "bg-amber-500 border-amber-400 text-slate-950 shadow-md shadow-amber-500/20" : "bg-slate-950/90 border-slate-700 text-slate-500"}`,
												children: selectedIds.has(item.id) ? /* @__PURE__ */ _jsxDEV(CheckSquare, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1366,
													columnNumber: 33
												}, this) : /* @__PURE__ */ _jsxDEV("div", { className: "w-3.5 h-3.5 border border-slate-600 rounded-sm" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1368,
													columnNumber: 33
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1360,
												columnNumber: 29
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1359,
											columnNumber: 27
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1282,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-5 flex-1 flex flex-col justify-between",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-sm font-bold text-slate-100 group-hover:text-amber-500 transition-colors truncate",
												children: formatElementTitleWithId(item.nombre, item.id)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1378,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "space-y-1.5 mt-3 text-[11px] text-slate-400 border-t border-slate-900/60 pt-3",
												children: [
													/* @__PURE__ */ _jsxDEV("p", {
														className: "truncate",
														children: [
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-slate-500 font-bold",
																children: "Ubicación:"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1383,
																columnNumber: 53
															}, this),
															" ",
															item.ubicacion
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1383,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "truncate",
														children: [
															/* @__PURE__ */ _jsxDEV("span", {
																className: "text-slate-500 font-bold",
																children: "Alimentado por:"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1384,
																columnNumber: 53
															}, this),
															" ",
															item.alimentadoPor || "No definido"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1384,
														columnNumber: 29
													}, this),
													isTablero && /* @__PURE__ */ _jsxDEV("p", {
														className: "text-sky-400 font-mono font-semibold text-[10px] bg-sky-950/40 p-1.5 rounded-lg border border-sky-900/40",
														children: [
															"⚡ Capacidad: ",
															item.datosTecnicos?.maxPoles || 24,
															" Polos (",
															item.datosTecnicos?.voltajeAcometida || "208/120 V",
															")"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1388,
														columnNumber: 31
													}, this),
													isTrafo && /* @__PURE__ */ _jsxDEV("p", {
														className: "text-purple-400 font-mono font-semibold text-[10px] bg-purple-950/40 p-1.5 rounded-lg border border-purple-900/40",
														children: [
															"⚡ ",
															item.datosTecnicos?.kva || "500 KVA",
															" | GE ",
															item.datosTecnicos?.conexion || "Estrella-Estrella",
															" (",
															item.datosTecnicos?.voltajePrimario || "13.8 kV",
															")"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1393,
														columnNumber: 31
													}, this),
													isGen && /* @__PURE__ */ _jsxDEV("p", {
														className: "text-amber-400 font-mono font-semibold text-[10px] bg-amber-950/40 p-1.5 rounded-lg border border-amber-900/40",
														children: [
															"⚡ ",
															item.datosTecnicos?.kva || "580 kVA",
															" | ",
															item.datosTecnicos?.voltajeGeneracion || "208 V",
															" | Breaker ",
															item.datosTecnicos?.amperaje || "1600 A"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1398,
														columnNumber: 31
													}, this),
													isPuestaTierra && /* @__PURE__ */ _jsxDEV("p", {
														className: "text-teal-400 font-mono font-semibold text-[10px] bg-teal-950/40 p-1.5 rounded-lg border border-teal-900/40",
														children: [
															"🛡️ Corriente Fuga: ",
															item.datosTecnicos?.corrienteFugaAmperios || "6.4 A",
															" | ",
															item.datosTecnicos?.tipoMalla || "Malla Concreto"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1403,
														columnNumber: 31
													}, this),
													isTransfer && /* @__PURE__ */ _jsxDEV("p", {
														className: "text-emerald-400 font-mono font-semibold text-[10px] bg-emerald-950/40 p-1.5 rounded-lg border border-emerald-900/40",
														children: [
															"🔄 ",
															item.datosTecnicos?.capacidadAmperios || "3200 A",
															" | ",
															item.datosTecnicos?.tipoTransferencia || "ATS YUYE-YES1"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1408,
														columnNumber: 31
													}, this),
													isPuntoSuministro && /* @__PURE__ */ _jsxDEV("p", {
														className: "text-blue-400 font-mono font-semibold text-[10px] bg-blue-950/40 p-1.5 rounded-lg border border-blue-900/40",
														children: [
															"🔌 ",
															item.datosTecnicos?.nivelTension || "13.8 kV",
															" | ",
															item.datosTecnicos?.cargaContratadaKva || item.datosTecnicos?.capacidadContratadaKva || "1000 kVA",
															" | ",
															item.datosTecnicos?.tipoMedicion || "Medición Directa BT"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1413,
														columnNumber: 31
													}, this),
													isCcm && /* @__PURE__ */ _jsxDEV("p", {
														className: "text-amber-400 font-mono font-semibold text-[10px] bg-amber-950/40 p-1.5 rounded-lg border border-amber-900/40",
														children: [
															"⚙️ Barra: ",
															item.datosTecnicos?.capacidadBarraAmperios || "1200 A",
															" | ",
															item.datosTecnicos?.numeroGavetas || 8,
															" Gavetas (",
															item.datosTecnicos?.tensionOperativa || "480 V",
															")"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1418,
														columnNumber: 31
													}, this),
													isBanco && /* @__PURE__ */ _jsxDEV("p", {
														className: "text-emerald-400 font-mono font-semibold text-[10px] bg-emerald-950/40 p-1.5 rounded-lg border border-emerald-900/40",
														children: [
															"⚡ ",
															item.datosTecnicos?.potenciaReactivaTotal || "150 kVAR",
															" | ",
															item.datosTecnicos?.numPasos || 6,
															" Pasos (",
															item.datosTecnicos?.tensionNominal || "208 V",
															")"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1423,
														columnNumber: 31
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1382,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1377,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-4 pt-3 border-t border-slate-900/80",
											children: /* @__PURE__ */ _jsxDEV(AvanceProgressBar, {
												elemento: item,
												tipoElemento: item.tipoElemento || "TABLERO"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1432,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1431,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-3",
											children: /* @__PURE__ */ _jsxDEV(ElementoCardActions, {
												onEdit: () => {
													setEditingElemento(item);
													setShowElementoModal(true);
												},
												onNewInspection: () => navigate(`/empresa/${companyId}/tablero/${item.id}`),
												onDelete: async () => {
													const ok = await confirm({
														title: "Eliminar Elemento",
														message: `¿Estás seguro de que deseas eliminar el elemento "${item.nombre}"?`,
														type: "danger",
														confirmText: "Eliminar"
													});
													if (ok) {
														deleteElementoUnifilar(proyectoId, item.id);
													}
												},
												readOnly: user?.role === "CLIENT"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1437,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1436,
											columnNumber: 25
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1376,
									columnNumber: 23
								}, this)]
							}, item.id, true, {
								fileName: _jsxFileName,
								lineNumber: 1266,
								columnNumber: 21
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1254,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "p-16 border-2 border-dashed border-slate-800 rounded-2xl text-center space-y-4 bg-slate-950/20",
						children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-12 h-12 text-slate-700 mx-auto" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1464,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1 font-sans",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-slate-400",
								children: "No hay equipos registrados"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1466,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 max-w-sm mx-auto",
								children: "Registra un Tablero, Transformador, Generador, Puesta a Tierra o Transfer en este proyecto."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1467,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1465,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1463,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1238,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 913,
				columnNumber: 7
			}, this),
			showElementoModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200",
					onClick: () => {
						setShowElementoModal(false);
						setEditingElemento(null);
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1481,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center pb-4 border-b border-slate-800 shrink-0",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1486,
									columnNumber: 17
								}, this),
								" ",
								editingElemento ? `Editar Plantilla: ${editingElemento.nombre}` : "Registrar Plantilla Técnica"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1485,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setShowElementoModal(false);
								setEditingElemento(null);
							},
							className: "p-1.5 hover:bg-slate-900 rounded-lg text-slate-500 transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1492,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1488,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1484,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCreateElemento,
						className: "mt-4 space-y-4 overflow-y-auto pr-1 flex-1",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Tipo de Elemento Eléctrico"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1500,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 sm:grid-cols-3 gap-1.5 bg-slate-900 p-1.5 rounded-xl border border-slate-800 text-[9px]",
								children: [
									{
										id: "TABLERO",
										label: "⚡ PANEL ELÉCTRICO"
									},
									{
										id: "PUNTO_SUMINISTRO",
										label: "🔌 PTO. SUMINISTRO"
									},
									{
										id: "GENERADOR",
										label: "🔋 GENERADOR"
									},
									{
										id: "TRANSFORMADOR",
										label: "🔄 TRANSFORMADOR"
									},
									{
										id: "TRANSFER",
										label: "🔀 TRANSFERENCIA"
									},
									{
										id: "CCM",
										label: "⚙️ CCM (MOTORES)"
									},
									{
										id: "BANCO_CONDENSADOR",
										label: "⚡ BANCO COND."
									}
								].map((t) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTipoElemento(t.id),
									className: `py-2 px-2 font-black rounded-lg transition-all text-center cursor-pointer ${tipoElemento === t.id ? "bg-amber-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"}`,
									children: t.label
								}, t.id, false, {
									fileName: _jsxFileName,
									lineNumber: 1513,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1503,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1499,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
									children: "Nombre descriptivo del equipo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1531,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									value: nombre,
									onChange: (e) => setNombre(e.target.value),
									placeholder: `Ej. ${PREFIX_MAP[tipoElemento] || "TAB"}-1: Nombre Descriptivo`,
									className: `w-full px-3.5 py-2 bg-slate-900 border focus:ring-1 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all ${nombreElementoDuplicado ? "border-red-500 focus:border-red-500 focus:ring-red-500" : "border-slate-800 focus:border-amber-500 focus:ring-amber-500"}`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1534,
									columnNumber: 17
								}, this),
								nombreElementoDuplicado && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-red-550 font-bold flex items-center gap-1.5 mt-1.5",
									children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1548,
										columnNumber: 21
									}, this), " Nombre duplicado: ya existe este equipo en el proyecto."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1547,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1530,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Ubicación Física"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1555,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: ubicacion,
								onChange: (e) => setUbicacion(e.target.value),
								placeholder: "Ej. Sótano Sala Técnica o Estacionamiento Exterior",
								className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none placeholder-slate-600 h-11 transition-all"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1558,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1554,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV(SelectorAlimentadorJerarquico, {
								proyectoId,
								tableroActualId: editingElemento?.id,
								elementosList: elementos,
								value: alimentadoPor,
								onChange: (val) => setAlimentadoPor(val),
								label: "Alimentado Por (Procedencia / Jerarquía)",
								placeholder: "Seleccionar Subestación, Trafo, CCM o Tablero..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1569,
								columnNumber: 17
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1568,
								columnNumber: 15
							}, this),
							tipoElemento === "TABLERO" && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Número Máximo de Polos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1585,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "number",
									value: maxPoles,
									onChange: (e) => setMaxPoles(parseInt(e.target.value, 10) || 0),
									placeholder: "Escribe el nro. de polos",
									className: "w-2/3 px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1589,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: maxPoles,
									onChange: (e) => {
										const val = parseInt(e.target.value, 10);
										if (val) setMaxPoles(val);
									},
									className: "w-1/3 px-3 py-2.5 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11",
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "",
											children: "-- Estándar --"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1604,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 12,
											children: "12 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1605,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 24,
											children: "24 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1606,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 30,
											children: "30 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1607,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 42,
											children: "42 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1608,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 48,
											children: "48 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1609,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 60,
											children: "60 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1610,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 72,
											children: "72 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1611,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 84,
											children: "84 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1612,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 96,
											children: "96 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1613,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1596,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1588,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1584,
								columnNumber: 17
							}, this),
							tipoElemento === "TRANSFORMADOR" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Potencia KVA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1624,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: kvaTrafo,
										onChange: (e) => setKvaTrafo(e.target.value),
										placeholder: "Ej. 500 KVA",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1625,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1623,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Marca"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1628,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: marcaTrafo,
										onChange: (e) => setMarcaTrafo(e.target.value),
										placeholder: "Ej. GE",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1629,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1627,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1622,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tipo Transformador"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1634,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: tipoTrafo,
										onChange: (e) => setTipoTrafo(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Aceite",
												children: "Aceite (Sumergido / Exterior)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1636,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Seco",
												children: "Seco (Encapsulado / Interior)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1637,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Pedestal",
												children: "Pedestal (Aceite)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1638,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Poste",
												children: "Montaje en Poste (Aceite)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1639,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1635,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1633,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Conexión"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1643,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: conexionTrafo,
										onChange: (e) => setConexionTrafo(e.target.value),
										placeholder: "Ej. Estrella - Estrella",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1644,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1642,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1632,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1621,
								columnNumber: 17
							}, this),
							tipoElemento === "GENERADOR" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Capacidad kVA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1655,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: kvaGen,
										onChange: (e) => setKvaGen(e.target.value),
										placeholder: "Ej. 580 kVA",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1656,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1654,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Combustible"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1659,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: combustibleGen,
										onChange: (e) => setCombustibleGen(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "DIESEL",
												children: "DIÉSEL / GASOIL"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1661,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "GAS",
												children: "GAS NATURAL"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1662,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "GASOLINA",
												children: "GASOLINA"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1663,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1660,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1658,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1653,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Voltaje Generación"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1669,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: voltajeGen,
										onChange: (e) => setVoltajeGen(e.target.value),
										placeholder: "Ej. 208 / 120 V",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1670,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1668,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Interruptor Amperaje"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1673,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: amperajeGen,
										onChange: (e) => setAmperajeGen(e.target.value),
										placeholder: "Ej. 1600 A",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1674,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1672,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1667,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1652,
								columnNumber: 17
							}, this),
							tipoElemento === "PUESTA_TIERRA" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Resistencia (Ω)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1685,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: resistenciaOhmios,
										onChange: (e) => setResistenciaOhmios(e.target.value),
										placeholder: "Ej. 0.5 Ω",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1686,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1684,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Corriente Fuga (A)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1689,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: corrienteFuga,
										onChange: (e) => setCorrienteFuga(e.target.value),
										placeholder: "Ej. 6.4 A",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono text-amber-400"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1690,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1688,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1683,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
									children: "Tipo de Malla / Ubicación"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1694,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: tipoMalla,
									onChange: (e) => setTipoMalla(e.target.value),
									placeholder: "Ej. Malla debajo de concreto",
									className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1695,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1693,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1682,
								columnNumber: 17
							}, this),
							tipoElemento === "TRANSFER" && /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
									children: "Capacidad Amperios"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1704,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: capacidadAmperios,
									onChange: (e) => setCapacidadAmperios(e.target.value),
									placeholder: "Ej. 3200 A",
									className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1705,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1703,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
									children: "Tipo Transferencia"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1708,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: tipoTransferencia,
									onChange: (e) => setTipoTransferencia(e.target.value),
									className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
									children: [/* @__PURE__ */ _jsxDEV("option", {
										value: "AUTOMATICA",
										children: "AUTOMÁTICA (ATS)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1710,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("option", {
										value: "MANUAL",
										children: "MANUAL (MTS)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1711,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1709,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1707,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1702,
								columnNumber: 17
							}, this),
							tipoElemento === "BANCO_CONDENSADOR" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Capacidad Total (kVAR)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1722,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: kvarTotal,
										onChange: (e) => setKvarTotal(e.target.value),
										placeholder: "Ej. 150 kVAR",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1723,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1721,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Pasos / Escalones"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1726,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: pasosCondensador,
										onChange: (e) => setPasosCondensador(e.target.value),
										placeholder: "Ej. 6 pasos",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1727,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1725,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1720,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tipo de Banco"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1732,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: tipoBanco,
										onChange: (e) => setTipoBanco(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "AUTOMATICO",
											children: "AUTOMÁTICO (CONTROLADOR)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1734,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("option", {
											value: "FIJO",
											children: "FIJO"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1735,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1733,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1731,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tensión Operativa"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1739,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: tensionBanco,
										onChange: (e) => setTensionBanco(e.target.value),
										placeholder: "Ej. 208 V o 480 V",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1740,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1738,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1730,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1719,
								columnNumber: 17
							}, this),
							tipoElemento === "PUNTO_SUMINISTRO" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 md:grid-cols-2 gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
											children: "Tensión de Suministro (COVENIN 159:1997)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1752,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex gap-2",
											children: [/* @__PURE__ */ _jsxDEV("select", {
												value: TENSIONES_COVENIN_TODAS.includes(suministroTension) ? suministroTension : suministroTension ? "CUSTOM" : "",
												onChange: (e) => {
													if (e.target.value !== "CUSTOM") {
														setSuministroTension(e.target.value);
													}
												},
												className: "w-1/2 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
												children: [
													/* @__PURE__ */ _jsxDEV("option", {
														value: "",
														children: "Seleccione tensión..."
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1765,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("optgroup", {
														label: "Baja Tensión (BT)",
														children: TENSIONES_COVENIN_159_BT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
															value: v,
															children: v
														}, v, false, {
															fileName: _jsxFileName,
															lineNumber: 1768,
															columnNumber: 31
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1766,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("optgroup", {
														label: "Media Tensión (MT)",
														children: TENSIONES_COVENIN_159_MT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
															value: v,
															children: v
														}, v, false, {
															fileName: _jsxFileName,
															lineNumber: 1773,
															columnNumber: 31
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1771,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "CUSTOM",
														children: "Otra tensión..."
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1776,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1756,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: suministroTension,
												onChange: (e) => setSuministroTension(e.target.value),
												placeholder: "Ej. 13.8 kV o 208/120 V",
												className: "w-1/2 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1778,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1755,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1751,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
											children: "Carga Contratada (kVA)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1789,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: suministroCapacidad,
											onChange: (e) => setSuministroCapacidad(e.target.value),
											placeholder: "Ej. 1000 kVA o 500",
											className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1792,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1788,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1750,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-slate-900/60 p-3.5 rounded-xl border border-slate-800/80 space-y-2",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[10px] font-bold text-amber-400 uppercase tracking-wide",
											children: "⚡ Tipo de Medición Eléctrica (Obligatorio)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1804,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: suministroTipoMedicion,
											onChange: (e) => setSuministroTipoMedicion(e.target.value),
											className: "w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 h-10 focus:border-amber-500 font-semibold",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Medición Directa (Baja Tensión)",
													children: "1. Medición Directa (Baja Tensión)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1812,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Medición Indirecta BT",
													children: "2. Medición Indirecta BT (con transformadores de corriente TCs)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1813,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Medición Indirecta AT/MT",
													children: "3. Medición Indirecta AT/MT (con TCs y TPs para media/alta tensión)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1814,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1807,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1803,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-slate-900/40 p-4 rounded-xl border border-slate-800 space-y-3",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between pb-2 border-b border-slate-800/60",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] font-bold text-slate-300 uppercase tracking-wide flex items-center gap-2",
													children: [/* @__PURE__ */ _jsxDEV(Gauge, { className: "w-4 h-4 text-blue-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1822,
														columnNumber: 25
													}, this), " Acometida de Servicio / Red Corpoelec"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1821,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("label", {
													className: "flex items-center gap-2 cursor-pointer text-xs text-slate-400",
													children: [/* @__PURE__ */ _jsxDEV("input", {
														type: "checkbox",
														checked: suministroEnlaceCorpoelec,
														onChange: (e) => setSuministroEnlaceCorpoelec(e.target.checked),
														className: "rounded border-slate-700 text-amber-500 focus:ring-amber-500 h-4 w-4 bg-slate-900"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1825,
														columnNumber: 25
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] font-semibold",
														children: "Enlace Activo"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1831,
														columnNumber: 25
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1824,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1820,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "grid grid-cols-1 md:grid-cols-2 gap-3",
												children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
													children: "Empresa Distribuidora"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1837,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "text",
													value: suministroEmpresa,
													onChange: (e) => setSuministroEmpresa(e.target.value),
													placeholder: "Ej. CORPOELEC",
													className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-9"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1838,
													columnNumber: 25
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1836,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
													children: "Tipo de Acometida"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1847,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("select", {
													value: suministroTipoAcometida,
													onChange: (e) => setSuministroTipoAcometida(e.target.value),
													className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-9",
													children: [
														/* @__PURE__ */ _jsxDEV("option", {
															value: "Subterránea",
															children: "Subterránea"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1853,
															columnNumber: 27
														}, this),
														/* @__PURE__ */ _jsxDEV("option", {
															value: "Aérea",
															children: "Aérea"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1854,
															columnNumber: 27
														}, this),
														/* @__PURE__ */ _jsxDEV("option", {
															value: "Mixta",
															children: "Mixta (Aéreo - Subterráneo)"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1855,
															columnNumber: 27
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1848,
													columnNumber: 25
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1846,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1835,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "grid grid-cols-1 md:grid-cols-3 gap-3",
												children: [
													/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
														className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
														children: "N° Contrato / NIC"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1862,
														columnNumber: 25
													}, this), /* @__PURE__ */ _jsxDEV("input", {
														type: "text",
														value: suministroNumeroContrato,
														onChange: (e) => setSuministroNumeroContrato(e.target.value),
														placeholder: "Ej. 1000284759",
														className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-9 font-mono"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1863,
														columnNumber: 25
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1861,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
														className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
														children: "N° Medidor"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1872,
														columnNumber: 25
													}, this), /* @__PURE__ */ _jsxDEV("input", {
														type: "text",
														value: suministroNic,
														onChange: (e) => setSuministroNic(e.target.value),
														placeholder: "Ej. MED-883921",
														className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-9 font-mono"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1873,
														columnNumber: 25
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1871,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
														className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
														children: "Poste / Trafo Servicio"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1882,
														columnNumber: 25
													}, this), /* @__PURE__ */ _jsxDEV("input", {
														type: "text",
														value: suministroPosteTrafo,
														onChange: (e) => setSuministroPosteTrafo(e.target.value),
														placeholder: "Ej. P-142 / Trafo 50kVA",
														className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-9 font-mono"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1883,
														columnNumber: 25
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1881,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1860,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1819,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1748,
								columnNumber: 17
							}, this),
							tipoElemento === "CCM" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Capacidad Barra (A)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1901,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: ccmCapacidadBarra,
										onChange: (e) => setCcmCapacidadBarra(e.target.value),
										placeholder: "Ej. 1200 A",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1902,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1900,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tensión Operativa"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1905,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: ccmTension,
										onChange: (e) => setCcmTension(e.target.value),
										placeholder: "Ej. 480 V",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1906,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1904,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1899,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Breaker Principal"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1911,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: ccmBreakerPrincipal,
										onChange: (e) => setCcmBreakerPrincipal(e.target.value),
										placeholder: "Ej. 1200A 3P",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1912,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1910,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Nro. de Gavetas / Buckets"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1915,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										min: "1",
										max: "48",
										value: ccmNumeroGavetas,
										onChange: (e) => setCcmNumeroGavetas(parseInt(e.target.value, 10) || 1),
										placeholder: "8",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1916,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1914,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1909,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1898,
								columnNumber: 17
							}, this),
							tipoElemento === "OTRO" && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Especificaciones Técnicas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1925,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("textarea", {
								value: descripcionOtro,
								onChange: (e) => setDescripcionOtro(e.target.value),
								rows: 3,
								placeholder: "Detalles técnicos adicionales...",
								className: "w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none resize-none"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1928,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1924,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Observaciones del Informe Técnico"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1934,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("textarea", {
								value: observacionesGenerales,
								onChange: (e) => setObservacionesGenerales(e.target.value),
								rows: 2,
								placeholder: "Detalles del estado de mantenimiento, polvo, humedad o recomendaciones...",
								className: "w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-xs text-slate-100 focus:outline-none placeholder-slate-650 transition-all resize-none"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1937,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1933,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1949,
									columnNumber: 19
								}, this), "Foto o Imagen de la Placa Técnico"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1948,
								columnNumber: 17
							}, this), previewUrl ? /* @__PURE__ */ _jsxDEV("div", {
								className: "relative rounded-xl overflow-hidden border border-slate-800 bg-slate-900 aspect-video flex items-center justify-center group shadow-md shrink-0",
								children: [/* @__PURE__ */ _jsxDEV("img", {
									src: previewUrl,
									alt: "Vista previa",
									className: "w-full h-full object-cover"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1955,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setFotoBlob(null);
										if (previewUrl) URL.revokeObjectURL(previewUrl);
										setPreviewUrl(null);
									},
									className: "absolute top-2 right-2 p-1.5 bg-slate-950/80 hover:bg-red-650 text-white rounded-lg cursor-pointer",
									children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1965,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1956,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1954,
								columnNumber: 19
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-center w-full",
								children: /* @__PURE__ */ _jsxDEV("label", {
									className: "flex flex-col items-center justify-center w-full h-24 border-2 border-slate-800 border-dashed rounded-xl cursor-pointer bg-slate-900/20 hover:bg-slate-900/40 hover:border-slate-700 transition-all select-none",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-col items-center justify-center pt-3 pb-3",
										children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-5 h-5 text-slate-500 mb-1" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1972,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-slate-450",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold",
												children: "Tomar Foto"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1974,
												columnNumber: 27
											}, this), " o subir"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1973,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1971,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										accept: "image/*",
										capture: "environment",
										onChange: handleImageChange,
										className: "hidden"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1977,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1970,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1969,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1947,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-end gap-3 pt-4 border-t border-slate-900 shrink-0",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setShowElementoModal(false);
										setEditingElemento(null);
									},
									className: "px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-xs font-bold rounded-lg text-slate-300 transition-colors cursor-pointer",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1991,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: !isElementoFormValid,
									className: "bg-amber-500 text-slate-950 font-semibold hover:bg-amber-400 active:scale-98 transition-all px-4 py-2.5 rounded-lg flex flex-row items-center justify-center gap-2 h-10 whitespace-nowrap text-xs cursor-pointer shadow-md disabled:opacity-40",
									children: editingElemento ? "Guardar Cambios" : "Guardar Plantilla"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1998,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1990,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1496,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1483,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1480,
				columnNumber: 9
			}, this),
			showInspeccionModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200",
					onClick: () => setShowInspeccionModal(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 2015,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full max-w-lg bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center pb-4 border-b border-slate-800 shrink-0",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Building, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2020,
								columnNumber: 17
							}, this), " Registrar Inspección Técnica (Capa 2)"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2019,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowInspeccionModal(false),
							className: "p-1.5 hover:bg-slate-900 rounded-lg text-slate-500 transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2026,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2022,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2018,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCreateInspeccion,
						className: "mt-4 space-y-4 overflow-y-auto pr-1 flex-1",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Tipo de Inspección Técnica"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2034,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-1.5 bg-slate-900 p-1.5 rounded-xl border border-slate-800 text-[10px]",
								children: [
									{
										id: "AMBIENTAL_FISICA",
										label: "🏢 AMBIENTAL O FÍSICA"
									},
									{
										id: "TERMOGRAFICA",
										label: "🌡️ TERMOGRÁFICA"
									},
									{
										id: "SISTEMA_ATERRAMIENTO",
										label: "🛡️ SISTEMA ATERRAMIENTO"
									},
									{
										id: "TANQUE_COMBUSTIBLE",
										label: "⛽ TANQUE COMBUSTIBLE"
									}
								].map((t) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTipoInspeccionModal(t.id),
									className: `py-2 px-2.5 font-bold rounded-lg transition-all text-center cursor-pointer ${tipoInspeccionModal === t.id ? "bg-amber-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"}`,
									children: t.label
								}, t.id, false, {
									fileName: _jsxFileName,
									lineNumber: 2044,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2037,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2033,
								columnNumber: 15
							}, this),
							(tipoInspeccionModal === "AMBIENTAL_FISICA" || tipoInspeccionModal === "SUBESTACION") && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
										children: "Nombre de la Subestación / Sala Eléctrica"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2066,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										required: true,
										value: subestacionNombre,
										onChange: (e) => setSubestacionNombre(e.target.value),
										placeholder: "Ej. Subestación Principal Sótano 2",
										className: `w-full px-3.5 py-2 bg-slate-900 border focus:ring-1 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all ${nombreInspeccionDuplicado ? "border-red-500 focus:border-red-500 focus:ring-red-500" : "border-slate-800 focus:border-amber-500 focus:ring-amber-500"}`
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2069,
										columnNumber: 21
									}, this),
									nombreInspeccionDuplicado && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] text-red-550 font-bold flex items-center gap-1.5 mt-1.5",
										children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2083,
											columnNumber: 25
										}, this), " Nombre duplicado: ya existe esta inspección."]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2082,
										columnNumber: 23
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2065,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
									children: "Ubicación Física"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2089,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: subestacionUbicacion,
									onChange: (e) => setSubestacionUbicacion(e.target.value),
									placeholder: "Ej. Patio de Transformadores Norte / Sala Eléctrica",
									className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none placeholder-slate-600 h-11 transition-all"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2092,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2088,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
									children: "Nivel de Tensión (kV)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2102,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: nivelTension,
									onChange: (e) => setNivelTension(e.target.value),
									placeholder: "Ej. 13.8 kV, 4.16 kV",
									className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11 font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2105,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2101,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2064,
								columnNumber: 17
							}, this),
							tipoInspeccionModal === "TERMOGRAFICA" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
									children: "Nombre / Tag de la Inspección Termográfica"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2120,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									value: termoNombre,
									onChange: (e) => setTermoNombre(e.target.value),
									placeholder: "Ej. IT-01: Termografía Tableros Principales",
									className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2123,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2119,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Ubicación / Equipo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2135,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: termoUbicacion,
										onChange: (e) => setTermoUbicacion(e.target.value),
										placeholder: "Ej. Interruptor Principal TAB-01",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2136,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2134,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Cámara Termográfica"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2139,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: termoCamara,
										onChange: (e) => setTermoCamara(e.target.value),
										placeholder: "Ej. FLIR E8-XT / Fluke Ti480",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2140,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2138,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2133,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-2.5 bg-slate-900/60 p-3 rounded-xl border border-slate-800",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
											children: "T. Ambiente (°C)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2146,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "number",
											step: "0.1",
											value: termoTempAmbiente,
											onChange: (e) => setTermoTempAmbiente(e.target.value),
											placeholder: "25",
											className: "w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-100 font-mono h-9"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2147,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2145,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
											children: "T. Punto (°C)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2150,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "number",
											step: "0.1",
											value: termoTempPuntoCaliente,
											onChange: (e) => setTermoTempPuntoCaliente(e.target.value),
											placeholder: "48.5",
											className: "w-full px-2.5 py-1.5 bg-slate-950 border border-amber-500/50 rounded-lg text-xs text-amber-400 font-mono h-9 font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2151,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2149,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
											children: "T. Ref (°C)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2154,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "number",
											step: "0.1",
											value: termoTempRef,
											onChange: (e) => setTermoTempRef(e.target.value),
											placeholder: "30",
											className: "w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-100 font-mono h-9"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2155,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2153,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2144,
									columnNumber: 19
								}, this),
								termoTempPuntoCaliente && /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 block uppercase font-bold",
										children: "Gradiente Térmico (ΔT)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2163,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono font-bold text-amber-400 text-sm",
										children: [(parseFloat(termoTempPuntoCaliente || 0) - parseFloat(termoTempRef || 0)).toFixed(1), " °C"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2164,
										columnNumber: 25
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2162,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-right",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 block uppercase font-bold",
											children: "Severidad NETA/NFPA"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2169,
											columnNumber: 25
										}, this), (() => {
											const dtVal = parseFloat(termoTempPuntoCaliente || 0) - parseFloat(termoTempRef || 0);
											if (dtVal > 40) return /* @__PURE__ */ _jsxDEV("span", {
												className: "px-2 py-0.5 bg-red-950 border border-red-800 text-red-400 font-black rounded-lg text-[10px]",
												children: "CRÍTICA (>40°C)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2172,
												columnNumber: 50
											}, this);
											if (dtVal > 20) return /* @__PURE__ */ _jsxDEV("span", {
												className: "px-2 py-0.5 bg-amber-950 border border-amber-800 text-amber-400 font-black rounded-lg text-[10px]",
												children: "ALTA (21-40°C)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2173,
												columnNumber: 50
											}, this);
											if (dtVal > 10) return /* @__PURE__ */ _jsxDEV("span", {
												className: "px-2 py-0.5 bg-yellow-950 border border-yellow-800 text-yellow-400 font-black rounded-lg text-[10px]",
												children: "MODERADA (11-20°C)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2174,
												columnNumber: 50
											}, this);
											return /* @__PURE__ */ _jsxDEV("span", {
												className: "px-2 py-0.5 bg-emerald-950 border border-emerald-800 text-emerald-400 font-black rounded-lg text-[10px]",
												children: "NORMAL (≤10°C)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2175,
												columnNumber: 34
											}, this);
										})()]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2168,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2161,
									columnNumber: 21
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2118,
								columnNumber: 17
							}, this),
							(tipoInspeccionModal === "SISTEMA_ATERRAMIENTO" || tipoInspeccionModal === "PUESTA_TIERRA") && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
									children: "Nombre / Tag del Sistema de Aterramiento (PAT)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2187,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									value: patNombre || subestacionNombre,
									onChange: (e) => {
										setPatNombre(e.target.value);
										setSubestacionNombre(e.target.value);
									},
									placeholder: "Ej. PAT-01: Malla Pozo Principal Transformador",
									className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2190,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2186,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Resistencia Ohmios (Ω)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2202,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										step: "0.01",
										value: patResistencia,
										onChange: (e) => setPatResistencia(e.target.value),
										placeholder: "Ej. 2.5 Ω",
										className: "w-full px-3 py-2 bg-slate-900 border border-amber-500/40 rounded-xl text-xs text-amber-400 h-10 font-mono font-bold"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2205,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2201,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Método Medición"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2215,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: patMetodo,
										onChange: (e) => setPatMetodo(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Caída de Potencial (62%)",
												children: "Caída de Potencial (62%)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2223,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Método de 3 Puntos",
												children: "Método de 3 Puntos"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2224,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Pinza de Tierra (Sin Picas)",
												children: "Pinza de Tierra (Sin Picas)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2225,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Método Wenner (4 Picas)",
												children: "Método Wenner (4 Picas)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2226,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2218,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2214,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2200,
									columnNumber: 19
								}, this),
								patResistencia && /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-900 p-2.5 rounded-xl border border-slate-800 text-xs flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 uppercase font-bold",
										children: "Criterio IEEE 80 / Código"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2233,
										columnNumber: 23
									}, this), parseFloat(patResistencia) > 10 ? /* @__PURE__ */ _jsxDEV("span", {
										className: "text-red-450 font-bold",
										children: "⚠️ > 10 Ω (Requiere Mantenimiento)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2235,
										columnNumber: 25
									}, this) : parseFloat(patResistencia) > 5 ? /* @__PURE__ */ _jsxDEV("span", {
										className: "text-amber-450 font-bold",
										children: "🟡 ≤ 10 Ω (Aceptable)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2237,
										columnNumber: 25
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-emerald-450 font-bold",
										children: "✅ ≤ 5 Ω (Excelente para Subestación)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2239,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2232,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tipo de Sistema PAT"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2246,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: patTipo,
										onChange: (e) => setPatTipo(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Malla con Varillas",
												children: "Malla con Varillas Copperweld"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2254,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Pozo Individual",
												children: "Pozo a Tierra Individual"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2255,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Anillo Perimetral",
												children: "Anillo Perimetral Edificio"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2256,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Malla Profunda",
												children: "Malla Profunda"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2257,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2249,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2245,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tipo de Unión"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2261,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: patUnion,
										onChange: (e) => setPatUnion(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Soldadura Exotérmica (Cadweld)",
												children: "Soldadura Exotérmica (Cadweld)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2269,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Conector Mecánico Bronce",
												children: "Conector Mecánico Bronce"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2270,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Terminal a Compresión",
												children: "Terminal a Compresión"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2271,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2264,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2260,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2244,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
									children: "Ubicación Física"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2277,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: patUbicacion || subestacionUbicacion,
									onChange: (e) => {
										setPatUbicacion(e.target.value);
										setSubestacionUbicacion(e.target.value);
									},
									placeholder: "Ej. Patio de Transformadores Norte / Sala Eléctrica",
									className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none placeholder-slate-600 h-11 transition-all"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2280,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2276,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2185,
								columnNumber: 17
							}, this),
							tipoInspeccionModal === "TANQUE_COMBUSTIBLE" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
									children: "Nombre / Tag del Tanque de Combustible"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2295,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									value: tanqueNombre,
									onChange: (e) => setTanqueNombre(e.target.value),
									placeholder: "Ej. TK-01: Tanque Principal Diésel Generador",
									className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2298,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2294,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tipo de Combustible"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2310,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: tanqueTipoCombustible,
										onChange: (e) => setTanqueTipoCombustible(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "DIESEL",
												children: "Diésel / Gasoil"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2312,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "GASOLINA",
												children: "Gasolina"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2313,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "GAS",
												children: "Gas Licuado / GLP"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2314,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2311,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2309,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Capacidad Total (L)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2318,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										value: tanqueCapacidadLitros,
										onChange: (e) => setTanqueCapacidadLitros(e.target.value),
										placeholder: "Ej. 2000",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2319,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2317,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2308,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Nivel Actual (%)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2325,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										min: "0",
										max: "100",
										value: tanqueNivelPorcentaje,
										onChange: (e) => setTanqueNivelPorcentaje(e.target.value),
										placeholder: "Ej. 75",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2326,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2324,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Consumo Generador (L/h)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2329,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										step: "0.1",
										value: tanqueConsumoLh,
										onChange: (e) => setTanqueConsumoLh(e.target.value),
										placeholder: "Ej. 45",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2330,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2328,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2323,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 block uppercase font-bold",
										children: "Litros Actuales"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2337,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono font-bold text-amber-400 text-sm",
										children: [(parseFloat(tanqueCapacidadLitros || 0) * parseFloat(tanqueNivelPorcentaje || 0) / 100).toFixed(0), " Litros"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2338,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2336,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-right",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 block uppercase font-bold",
											children: "Autonomía Estimada"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2343,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono font-black text-emerald-400 text-sm",
											children: [(parseFloat(tanqueCapacidadLitros || 0) * (parseFloat(tanqueNivelPorcentaje || 0) / 100) / (parseFloat(tanqueConsumoLh) || 1)).toFixed(1), " Horas"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2344,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2342,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2335,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Dique Contención 110%"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2352,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: tanqueDique110,
										onChange: (e) => setTanqueDique110(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "CONFORME",
												children: "Conforme (110% sin fugas)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2354,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "NO_CONFORME",
												children: "No Conforme / Sin Dique"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2355,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "CON_FILTRACION",
												children: "Con Filtración / Fisuras"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2356,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2353,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2351,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Ubicación Tanque"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2360,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: tanqueUbicacion,
										onChange: (e) => setTanqueUbicacion(e.target.value),
										placeholder: "Ej. Sala de Generación / Exterior",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2361,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2359,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2350,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2293,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Nombre del Inspector Encargado"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2369,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: inspectorName,
								onChange: (e) => setInspectorName(e.target.value),
								placeholder: "Ej. Ing. Juan Carlos",
								className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none placeholder-slate-600 h-11 transition-all"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2372,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2368,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-end gap-3 pt-4 border-t border-slate-900 shrink-0",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowInspeccionModal(false),
									className: "px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-xs font-bold rounded-lg text-slate-300 transition-colors cursor-pointer",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2382,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: !isInspeccionFormValid,
									className: "bg-amber-500 text-slate-950 font-black hover:bg-amber-400 active:scale-98 transition-all px-4 py-2.5 rounded-lg flex flex-row items-center justify-center gap-2 h-10 whitespace-nowrap text-xs cursor-pointer shadow-md disabled:opacity-40",
									children: "Crear Ficha de Inspección"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2389,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2381,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2030,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2017,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 2014,
				columnNumber: 9
			}, this),
			showPuntoMedicionModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200",
					onClick: () => setShowPuntoMedicionModal(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 2406,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden animate-in zoom-in-95 duration-200",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center pb-4 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Gauge, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2411,
								columnNumber: 17
							}, this), " Registrar Punto de Medición"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2410,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowPuntoMedicionModal(false),
							className: "p-1.5 hover:bg-slate-900 rounded-lg text-slate-500 transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2417,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2413,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2409,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCreatePuntoMedicion,
						className: "mt-4 space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Nombre / Identificador del Punto"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2424,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								required: true,
								value: puntoMedicionNombre,
								onChange: (e) => setPuntoMedicionNombre(e.target.value),
								placeholder: "Ej. Punto de Medición Principal Acometida 1",
								className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2427,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2423,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Nombre del Usuario / Razón Social"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2438,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: puntoMedicionUsuario,
								onChange: (e) => setPuntoMedicionUsuario(e.target.value),
								placeholder: "Ej. Comercial Selectric C.A.",
								className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none placeholder-slate-600 h-11 transition-all"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2441,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2437,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "N° de Contrato / NIC"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2451,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: puntoMedicionNIC,
								onChange: (e) => setPuntoMedicionNIC(e.target.value),
								placeholder: "Ej. NIC-8492019",
								className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11 font-mono"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2454,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2450,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Nivel de Tensión de Contrato"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2464,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: puntoMedicionNivelTension,
								onChange: (e) => setPuntoMedicionNivelTension(e.target.value),
								className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Baja Tensión",
										children: "Baja Tensión"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2472,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Media Tensión",
										children: "Media Tensión"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2473,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Alta Tensión",
										children: "Alta Tensión"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2474,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2467,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2463,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-end gap-3 pt-4 border-t border-slate-900",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowPuntoMedicionModal(false),
									className: "px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-xs font-bold rounded-lg text-slate-300 transition-colors cursor-pointer",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2479,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: !puntoMedicionNombre.trim(),
									className: "bg-amber-500 text-slate-950 font-semibold hover:bg-amber-400 active:scale-98 transition-all px-4 py-2.5 rounded-lg flex flex-row items-center justify-center gap-2 h-10 whitespace-nowrap text-xs cursor-pointer shadow-md disabled:opacity-40",
									children: "Registrar Punto"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2486,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2478,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2421,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2408,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 2405,
				columnNumber: 9
			}, this),
			showEditProyectoModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn font-sans text-xs",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center pb-4 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-lg font-bold text-slate-100 flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Building, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2506,
								columnNumber: 17
							}, this), " Editar Proyecto"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2505,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowEditProyectoModal(false),
							className: "p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2512,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2508,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2504,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleUpdateProyectoSubmit,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-slate-400 font-semibold mb-1",
								children: "Nombre del Proyecto"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2518,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: editProyectoNombre,
								onChange: (e) => setEditProyectoNombre(e.target.value),
								required: true,
								className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 text-sm"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2519,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2517,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-slate-400 font-semibold mb-1",
								children: "Descripción del Proyecto"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2529,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("textarea", {
								value: editProyectoDescripcion,
								onChange: (e) => setEditProyectoDescripcion(e.target.value),
								className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 text-sm h-20"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2530,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2528,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-slate-400 font-semibold mb-1",
								children: "Dirección / Ubicación Física"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2538,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: editProyectoDireccion,
								onChange: (e) => setEditProyectoDireccion(e.target.value),
								className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 text-sm"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2539,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2537,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "border-t border-slate-800 pt-4 mt-4 space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-sky-400 uppercase tracking-wider text-[10px]",
									children: "Responsable del Proyecto"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2548,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-500 font-medium mb-1",
											children: "Nombre"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2551,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: editResponsableNombre,
											onChange: (e) => setEditResponsableNombre(e.target.value),
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500 text-xs"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2552,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2550,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-500 font-medium mb-1",
											children: "Teléfono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2560,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: editResponsableTelefono,
											onChange: (e) => setEditResponsableTelefono(e.target.value),
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500 text-xs"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2561,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2559,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-500 font-medium mb-1",
											children: "Email"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2569,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "email",
											value: editResponsableEmail,
											onChange: (e) => setEditResponsableEmail(e.target.value),
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500 text-xs"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2570,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2568,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2549,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2547,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-end gap-3 pt-6 border-t border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowEditProyectoModal(false),
									className: "px-4 py-2 border border-slate-700 text-slate-350 hover:bg-slate-800 hover:text-slate-200 rounded-lg font-bold transition-colors cursor-pointer",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2581,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									className: "px-4 py-2 bg-amber-500 text-slate-950 hover:bg-amber-400 active:scale-98 rounded-lg font-bold transition-all shadow-md cursor-pointer",
									children: "Guardar Cambios"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2588,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2580,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2516,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2503,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2502,
				columnNumber: 9
			}, this),
			showCcmModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-md shadow-2xl space-y-4 font-sans",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center border-b border-slate-800 pb-3",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-bold text-slate-100 uppercase tracking-wider flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Cpu, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2606,
								columnNumber: 17
							}, this), " Registrar Nuevo CCM"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 2605,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowCcmModal(false),
							className: "p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition-colors",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2612,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 2608,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2604,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCreateCcmSubmit,
						className: "space-y-4 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-slate-400 font-bold mb-1 uppercase text-[10px]",
								children: ["Tag / Identificación del CCM ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-amber-500",
									children: "*"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2619,
									columnNumber: 48
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2618,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: ccmNombre,
								onChange: (e) => setCcmNombre(e.target.value),
								placeholder: "Ej. CCM-IND-01",
								required: true,
								className: "w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-slate-100 outline-none h-10 transition-all font-bold"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2621,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2617,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-slate-400 font-bold mb-1 uppercase text-[10px]",
								children: "Planta / Instalación"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2632,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: ccmPlanta,
								onChange: (e) => setCcmPlanta(e.target.value),
								placeholder: "Ej. Planta Procesadora Central",
								className: "w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-slate-100 outline-none h-10 transition-all"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2635,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2631,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-slate-400 font-bold mb-1 uppercase text-[10px]",
								children: "Área / Proceso"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2645,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: ccmArea,
								onChange: (e) => setCcmArea(e.target.value),
								placeholder: "Ej. Cuarto Eléctrico 02 - Bombeo",
								className: "w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-slate-100 outline-none h-10 transition-all"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2648,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2644,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-end gap-3 pt-4 border-t border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowCcmModal(false),
									className: "px-4 py-2 border border-slate-700 text-slate-400 hover:bg-slate-800 rounded-xl font-bold transition-all",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2658,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									className: "px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition-all shadow-md",
									children: "Crear CCM"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2665,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2657,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2616,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 2603,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2602,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(ModalDiagramaUnifilar, {
				isOpen: showDiagramModal,
				onClose: () => setShowDiagramModal(false),
				elementos,
				companyName: company?.nombre,
				proyectoId,
				companyId
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2680,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(HelpModal, {
				isOpen: showHelpModal,
				onClose: () => setShowHelpModal(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 2690,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 888,
		columnNumber: 5
	}, this);
};
_s2(ProyectoView, "SfJnVgE+OqURBrGe+U9DNaM0Bnc=", false, function() {
	return [
		useParams,
		useNavigate,
		useStore,
		useConfirm
	];
});
_c2 = ProyectoView;
export default ProyectoView;
var _c, _c2;
$RefreshReg$(_c, "SafeImage");
$RefreshReg$(_c2, "ProyectoView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/views/ProyectoView.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/ProyectoView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/ProyectoView.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/ProyectoView.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsV0FBVyxtQkFBbUI7QUFDdkMsT0FBTyxZQUFZLGtCQUFrQixZQUFZLGdDQUFnQztBQUNqRixTQUFTLGtCQUFrQjtBQUMzQixPQUFPLDJCQUEyQjtBQUNsQyxPQUFPLG1DQUFtQztBQUMxQyxPQUFPLHVCQUF1QjtBQUM5QixPQUFPLHlCQUF5QjtBQUNoQyxTQUNFLDBCQUNBLDBCQUNBLCtCQUNLO0FBQ1AsU0FDRSxXQUNBLFFBQ0EsUUFDQSxRQUNBLGVBQ0EsR0FDQSxRQUNBLFVBQ0EsTUFDQSxLQUNBLFVBQ0EsT0FDQSxLQUNBLGFBQ0EsV0FDQSxVQUNBLGFBQ0EsVUFDQSxZQUNBLFlBQ0s7QUFDUCxPQUFPLGVBQWU7Ozs7O0FBR3RCLE1BQU0sYUFBYSxFQUFFLE1BQU0sS0FBSyxLQUFLLGdCQUFnQjs7Q0FDbkQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsSUFBSTtDQUUvQyxnQkFBZ0I7RUFDZCxJQUFJLE1BQU07R0FDUixNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtHQUNwQyxhQUFhLEdBQUc7R0FDaEIsYUFBYTtJQUNYLElBQUksZ0JBQWdCLEdBQUc7R0FDekI7RUFDRixPQUFPO0dBQ0wsYUFBYSxJQUFJO0VBQ25CO0NBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQztDQUVULE1BQU0sV0FBVyxhQUFhO0NBQzlCLElBQUksQ0FBQyxVQUFVLE9BQU87Q0FFdEIsT0FBTyx3QkFBQyxPQUFEO0VBQUssS0FBSztFQUFlO0VBQWdCO0NBQVk7Ozs7O0FBQzlEOzs7QUFFQSxPQUFPLE1BQU0scUJBQXFCOztDQUNoQyxNQUFNLEVBQUUsV0FBVyxlQUFlLFVBQVU7Q0FDNUMsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsTUFBTSxFQUNKLE1BQ0EsV0FDQSxxQkFDQSx3QkFDQSx3QkFDQSwwQkFDQSxtQkFDQSxrQkFDQSxxQkFDQSxxQkFDQSxRQUNBLFdBQ0EsV0FDQSxnQkFDQSxjQUNFLFNBQVM7Q0FFYixNQUFNLFVBQVUsVUFBVSxNQUFNLE1BQU0sRUFBRSxPQUFPLFNBQVM7Q0FDeEQsTUFBTSxXQUFXLFNBQVMsV0FBVyxNQUFNLE1BQU0sRUFBRSxPQUFPLFVBQVU7Q0FFcEUsTUFBTSxFQUFFLFNBQVMsT0FBTyxnQkFBZ0IsV0FBVzs7Q0FHbkQsTUFBTSxDQUFDLHVCQUF1Qiw0QkFBNEIsU0FBUyxLQUFLO0NBQ3hFLE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsRUFBRTtDQUMvRCxNQUFNLENBQUMseUJBQXlCLDhCQUE4QixTQUFTLEVBQUU7Q0FDekUsTUFBTSxDQUFDLHVCQUF1Qiw0QkFBNEIsU0FBUyxFQUFFO0NBQ3JFLE1BQU0sQ0FBQyx1QkFBdUIsNEJBQTRCLFNBQVMsRUFBRTtDQUNyRSxNQUFNLENBQUMseUJBQXlCLDhCQUE4QixTQUFTLEVBQUU7Q0FDekUsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxFQUFFO0NBRW5FLE1BQU0sNkJBQTZCLE9BQU8sTUFBTTtFQUM5QyxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLG1CQUFtQixLQUFLLEdBQUc7RUFFaEMsZUFBZSxXQUFXLFlBQVk7R0FDcEMsUUFBUSxtQkFBbUIsS0FBSztHQUNoQyxhQUFhLHdCQUF3QixLQUFLO0dBQzFDLFdBQVcsc0JBQXNCLEtBQUs7R0FDdEMsYUFBYTtJQUNYLFFBQVEsc0JBQXNCLEtBQUs7SUFDbkMsVUFBVSx3QkFBd0IsS0FBSztJQUN2QyxPQUFPLHFCQUFxQixLQUFLO0dBQ25DO0VBQ0YsQ0FBQztFQUVELHlCQUF5QixLQUFLO0VBQzlCLFlBQVkseUNBQXlDLFNBQVM7Q0FDaEU7Q0FFQSxNQUFNLDRCQUE0QjtFQUNoQyxzQkFBc0IsVUFBVSxVQUFVLEVBQUU7RUFDNUMsMkJBQTJCLFVBQVUsZUFBZSxFQUFFO0VBQ3RELHlCQUF5QixVQUFVLGFBQWEsRUFBRTtFQUNsRCx5QkFBeUIsVUFBVSxhQUFhLFVBQVUsRUFBRTtFQUM1RCwyQkFBMkIsVUFBVSxhQUFhLFlBQVksRUFBRTtFQUNoRSx3QkFBd0IsVUFBVSxhQUFhLFNBQVMsRUFBRTtFQUMxRCx5QkFBeUIsSUFBSTtDQUMvQjs7Q0FHQSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxVQUFVO0NBQ3JELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7O0NBR2pELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsS0FBSztDQUNoRSxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxJQUFJLElBQUksQ0FBQzs7Q0FHeEQsZ0JBQWdCO0VBQ2QsZUFBZSxJQUFJLElBQUksQ0FBQztDQUMxQixHQUFHLENBQUMsV0FBVyxXQUFXLENBQUM7Q0FFM0IsTUFBTSxzQkFBc0IsT0FBTztFQUNqQyxnQkFBZ0IsU0FBUztHQUN2QixNQUFNLE9BQU8sSUFBSSxJQUFJLElBQUk7R0FDekIsSUFBSSxLQUFLLElBQUksRUFBRSxHQUFHO0lBQ2hCLEtBQUssT0FBTyxFQUFFO0dBQ2hCLE9BQU87SUFDTCxLQUFLLElBQUksRUFBRTtHQUNiO0dBQ0EsT0FBTztFQUNULENBQUM7Q0FDSDtDQUVBLE1BQU0sbUJBQW1CLFVBQVU7RUFDakMsZUFBZSxJQUFJLElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztDQUNoRDtDQUVBLE1BQU0sMEJBQTBCO0VBQzlCLGVBQWUsSUFBSSxJQUFJLENBQUM7Q0FDMUI7Q0FFQSxNQUFNLHVCQUF1QixZQUFZO0VBQ3ZDLE1BQU0sZ0JBQWdCLFlBQVk7RUFDbEMsSUFBSSxrQkFBa0IsR0FBRztFQUV6QixNQUFNLGFBQWEsY0FBYyxhQUM3Qiw0Q0FBNEMsY0FBYyxtREFDMUQsNENBQTRDLGNBQWM7RUFFOUQsTUFBTSxLQUFLLE1BQU0sUUFBUTtHQUN2QixPQUFPO0dBQ1AsU0FBUztHQUNULE1BQU07R0FDTixhQUFhO0VBQ2YsQ0FBQztFQUVELElBQUksSUFBSTtHQUNOLElBQUksY0FBYyxZQUFZO0lBQzVCLFlBQVksU0FBUyxPQUFPO0tBQzFCLHVCQUF1QixZQUFZLEVBQUU7SUFDdkMsQ0FBQztJQUNELFlBQVksaUJBQWlCLGNBQWMsMkJBQTJCLFNBQVM7R0FDakYsT0FBTztJQUNMLFlBQVksU0FBUyxPQUFPO0tBQzFCLGtCQUFrQixZQUFZLEVBQUU7SUFDbEMsQ0FBQztJQUNELFlBQVksaUJBQWlCLGNBQWMsc0NBQXNDLFNBQVM7R0FDNUY7R0FDQSxlQUFlLElBQUksSUFBSSxDQUFDO0dBQ3hCLHFCQUFxQixLQUFLO0VBQzVCO0NBQ0Y7O0NBR0EsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxLQUFLO0NBQ2hFLE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQVMsS0FBSztDQUNwRSxNQUFNLENBQUMsd0JBQXdCLDZCQUE2QixTQUFTLEtBQUs7Q0FDMUUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSzs7Q0FHdEQsTUFBTSxDQUFDLHFCQUFxQiwwQkFBMEIsU0FBUyxFQUFFO0NBQ2pFLE1BQU0sQ0FBQyxzQkFBc0IsMkJBQTJCLFNBQVMsRUFBRTtDQUNuRSxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEVBQUU7Q0FDM0QsTUFBTSxDQUFDLDJCQUEyQixnQ0FBZ0MsU0FBUyxlQUFlOztDQUcxRixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxFQUFFO0NBQzdDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FDN0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FFekMsTUFBTSx5QkFBeUIsTUFBTTtFQUNuQyxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLFVBQVUsS0FBSyxHQUFHO0dBQ3JCLFlBQVksc0RBQXNELE9BQU87R0FDekU7RUFDRjtFQUVBLE1BQU0sVUFBVTtHQUNkLFFBQVE7R0FDUixtQkFBbUI7R0FDbkIsYUFBYTtHQUNiLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0dBQzNDLFdBQVcsTUFBTSxVQUFVLE1BQU0sWUFBWTtHQUM3QyxZQUFZO0dBQ1osc0JBQXNCLENBQUM7R0FDdkIsa0JBQWtCLENBQUM7R0FDbkIsa0JBQWtCLENBQUM7R0FDbkIsc0JBQXNCLENBQUM7R0FDdkIsbUJBQW1CLENBQUM7RUFDdEI7RUFFQSxNQUFNLFNBQVMsT0FBTyxZQUFZLE9BQU87RUFDekMsSUFBSSxPQUFPLFNBQVM7R0FDbEIsWUFBWSwwREFBMEQsU0FBUztHQUMvRSxnQkFBZ0IsS0FBSztHQUNyQixhQUFhLEVBQUU7R0FDZixhQUFhLEVBQUU7R0FDZixXQUFXLEVBQUU7RUFDZixPQUFPO0dBQ0wsWUFBWSxPQUFPLFNBQVMseUJBQXlCLE9BQU87RUFDOUQ7Q0FDRjs7Q0FHQSxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLElBQUk7O0NBRzNELGdCQUFnQjtFQUNkLElBQUksaUJBQWlCO0dBQ25CLFVBQVUsZ0JBQWdCLFVBQVUsRUFBRTtHQUN0QyxhQUFhLGdCQUFnQixhQUFhLEVBQUU7R0FDNUMsaUJBQWlCLGdCQUFnQixpQkFBaUIsRUFBRTtHQUNwRCwwQkFBMEIsZ0JBQWdCLDBCQUEwQixFQUFFO0dBQ3RFLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLFNBQVM7R0FFekQsTUFBTSxPQUFPLGdCQUFnQixpQkFBaUIsQ0FBQztHQUMvQyxJQUFJLGdCQUFnQixpQkFBaUIsV0FBVztJQUM5QyxZQUFZLEtBQUssWUFBWSxFQUFFO0dBQ2pDLE9BQU8sSUFBSSxnQkFBZ0IsaUJBQWlCLGlCQUFpQjtJQUMzRCxZQUFZLEtBQUssT0FBTyxLQUFLLGVBQWUsRUFBRTtJQUM5QyxjQUFjLEtBQUssU0FBUyxFQUFFO0lBQzlCLGFBQWEsS0FBSyxxQkFBcUIsVUFBVTtJQUNqRCxpQkFBaUIsS0FBSyxZQUFZLEVBQUU7SUFDcEMsbUJBQW1CLEtBQUssbUJBQW1CLEtBQUssbUJBQW1CLEVBQUU7SUFDckUscUJBQXFCLEtBQUsscUJBQXFCLEtBQUsscUJBQXFCLEVBQUU7R0FDN0UsT0FBTyxJQUFJLGdCQUFnQixpQkFBaUIsYUFBYTtJQUN2RCxVQUFVLEtBQUssT0FBTyxFQUFFO0lBQ3hCLGtCQUFrQixLQUFLLGVBQWUsS0FBSyxtQkFBbUIsUUFBUTtJQUN0RSxjQUFjLEtBQUsscUJBQXFCLEVBQUU7SUFDMUMsaUJBQWlCLEtBQUssY0FBYyxLQUFLLE1BQU0sRUFBRTtJQUNqRCxlQUFlLEtBQUssWUFBWSxFQUFFO0dBQ3BDLE9BQU8sSUFBSSxnQkFBZ0IsaUJBQWlCLGlCQUFpQjtJQUMzRCxxQkFBcUIsS0FBSyxxQkFBcUIsRUFBRTtJQUNqRCxpQkFBaUIsS0FBSyx5QkFBeUIsRUFBRTtJQUNqRCxhQUFhLEtBQUssYUFBYSxFQUFFO0lBQ2pDLHdCQUF3QixLQUFLLGtCQUFrQixFQUFFO0dBQ25ELE9BQU8sSUFBSSxnQkFBZ0IsaUJBQWlCLFlBQVk7SUFDdEQscUJBQXFCLEtBQUsscUJBQXFCLEVBQUU7SUFDakQscUJBQXFCLEtBQUsscUJBQXFCLFlBQVk7SUFDM0Qsb0JBQW9CLEtBQUssb0JBQW9CLEVBQUU7R0FDakQsT0FBTyxJQUFJLGdCQUFnQixpQkFBaUIscUJBQXFCO0lBQy9ELGFBQWEsS0FBSyx5QkFBeUIsS0FBSyxhQUFhLEVBQUU7SUFDL0Qsb0JBQW9CLEtBQUssWUFBWSxLQUFLLG9CQUFvQixFQUFFO0lBQ2hFLGFBQWEsS0FBSyxxQkFBcUIsU0FBUyxTQUFTLFlBQVk7SUFDckUsZ0JBQWdCLEtBQUssa0JBQWtCLEtBQUssZ0JBQWdCLEVBQUU7R0FDaEUsT0FBTyxJQUFJLGdCQUFnQixpQkFBaUIsb0JBQW9CO0lBQzlELHFCQUFxQixLQUFLLGdCQUFnQixLQUFLLGtCQUFrQixFQUFFO0lBQ25FLHFCQUFxQixLQUFLLHdCQUF3QixXQUFXO0lBQzdELDJCQUEyQixLQUFLLGlCQUFpQixhQUFhO0lBQzlELHVCQUF1QixLQUFLLDBCQUEwQixLQUFLLHNCQUFzQixLQUFLLGdCQUFnQixFQUFFO0lBQ3hHLDBCQUEwQixLQUFLLGdCQUFnQixpQ0FBaUM7SUFDaEYsNkJBQTZCLEtBQUssb0JBQW9CLFlBQVksS0FBSyxrQkFBa0IsSUFBSTtJQUM3Riw0QkFBNEIsS0FBSyxrQkFBa0IsS0FBSyxZQUFZLEVBQUU7SUFDdEUsaUJBQWlCLEtBQUssT0FBTyxLQUFLLGlCQUFpQixFQUFFO0lBQ3JELHdCQUF3QixLQUFLLHNCQUFzQixLQUFLLGNBQWMsRUFBRTtHQUMxRSxPQUFPLElBQUksZ0JBQWdCLGlCQUFpQixPQUFPO0lBQ2pELHFCQUFxQixLQUFLLDBCQUEwQixFQUFFO0lBQ3RELGNBQWMsS0FBSyxvQkFBb0IsRUFBRTtJQUN6Qyx1QkFBdUIsS0FBSyxvQkFBb0IsRUFBRTtJQUNsRCxvQkFBb0IsS0FBSyxpQkFBaUIsQ0FBQztHQUM3QyxPQUFPO0lBQ0wsbUJBQW1CLEtBQUssK0JBQStCLEVBQUU7R0FDM0Q7RUFDRixPQUFPO0dBQ0wsVUFBVSxFQUFFO0dBQ1osYUFBYSxFQUFFO0dBQ2YsaUJBQWlCLEVBQUU7R0FDbkIsMEJBQTBCLEVBQUU7R0FDNUIsZ0JBQWdCLFNBQVM7R0FDekIsWUFBWSxFQUFFO0dBQ2QsWUFBWSxFQUFFO0dBQ2QsY0FBYyxFQUFFO0dBQ2hCLGlCQUFpQixFQUFFO0dBQ25CLG1CQUFtQixFQUFFO0dBQ3JCLHFCQUFxQixFQUFFO0dBQ3ZCLFVBQVUsRUFBRTtHQUNaLGNBQWMsRUFBRTtHQUNoQixpQkFBaUIsRUFBRTtHQUNuQixlQUFlLEVBQUU7R0FDakIscUJBQXFCLEVBQUU7R0FDdkIsaUJBQWlCLEVBQUU7R0FDbkIsYUFBYSxFQUFFO0dBQ2Ysd0JBQXdCLEVBQUU7R0FDMUIscUJBQXFCLEVBQUU7R0FDdkIsb0JBQW9CLEVBQUU7R0FDdEIsYUFBYSxFQUFFO0dBQ2Ysb0JBQW9CLEVBQUU7R0FDdEIsZ0JBQWdCLEVBQUU7R0FDbEIscUJBQXFCLEVBQUU7R0FDdkIscUJBQXFCLFdBQVc7R0FDaEMsMkJBQTJCLGFBQWE7R0FDeEMsdUJBQXVCLEVBQUU7R0FDekIsMEJBQTBCLGlDQUFpQztHQUMzRCw2QkFBNkIsSUFBSTtHQUNqQyw0QkFBNEIsRUFBRTtHQUM5QixpQkFBaUIsRUFBRTtHQUNuQix3QkFBd0IsRUFBRTtHQUMxQixxQkFBcUIsRUFBRTtHQUN2QixjQUFjLEVBQUU7R0FDaEIsdUJBQXVCLEVBQUU7R0FDekIsbUJBQW1CLEVBQUU7RUFDdkI7Q0FDRixHQUFHLENBQUMsZUFBZSxDQUFDO0NBRXBCLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUM5RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLOztDQUd4RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxTQUFTOztDQUcxRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRTtDQUN2QyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxFQUFFO0NBQzdDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEVBQUU7Q0FDckQsTUFBTSxDQUFDLHdCQUF3Qiw2QkFBNkIsU0FBUyxFQUFFO0NBQ3ZFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxJQUFJO0NBQzdDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLElBQUk7O0NBR2pELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFOztDQUczQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLFVBQVU7Q0FDckQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsRUFBRTtDQUNyRCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEVBQUU7Q0FDekQsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxFQUFFOztDQUc3RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRTtDQUN2QyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLFFBQVE7Q0FDN0QsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7O0NBR2pELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsRUFBRTtDQUM3RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FDN0MsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxFQUFFOztDQUduRSxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEVBQUU7Q0FDN0QsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxZQUFZO0NBQ3ZFLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsRUFBRTs7Q0FHM0QsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUM3QyxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEVBQUU7Q0FDM0QsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsWUFBWTtDQUN2RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFOztDQUduRCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEVBQUU7Q0FDN0QsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxXQUFXO0NBQ3RFLE1BQU0sQ0FBQyx5QkFBeUIsOEJBQThCLFNBQVMsYUFBYTtDQUNwRixNQUFNLENBQUMscUJBQXFCLDBCQUEwQixTQUFTLEVBQUU7Q0FDakUsTUFBTSxDQUFDLHdCQUF3Qiw2QkFBNkIsU0FBUyxpQ0FBaUM7Q0FDdEcsTUFBTSxDQUFDLDJCQUEyQixnQ0FBZ0MsU0FBUyxJQUFJO0NBQy9FLE1BQU0sQ0FBQywwQkFBMEIsK0JBQStCLFNBQVMsRUFBRTtDQUMzRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxzQkFBc0IsMkJBQTJCLFNBQVMsRUFBRTs7Q0FHbkUsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxFQUFFO0NBQzdELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEVBQUU7Q0FDL0MsTUFBTSxDQUFDLHFCQUFxQiwwQkFBMEIsU0FBUyxFQUFFO0NBQ2pFLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsQ0FBQzs7Q0FHMUQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFOztDQUd6RCxNQUFNLENBQUMscUJBQXFCLDBCQUEwQixTQUFTLGtCQUFrQjs7Q0FHakYsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxFQUFFO0NBQzdELE1BQU0sQ0FBQyxzQkFBc0IsMkJBQTJCLFNBQVMsRUFBRTtDQUNuRSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxTQUFTO0NBQzFELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEVBQUU7O0NBR3JELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsSUFBSTtDQUMvRCxNQUFNLENBQUMsd0JBQXdCLDZCQUE2QixTQUFTLEVBQUU7Q0FDdkUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsSUFBSTtDQUNyRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxZQUFZOztDQUczRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxFQUFFO0NBQzdDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEVBQUU7Q0FDbkQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLDBCQUEwQjtDQUNyRSxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsb0JBQW9CO0NBQzNELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxnQ0FBZ0M7Q0FDekUsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxXQUFXOztDQUdoRSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFO0NBQ25ELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsRUFBRTtDQUN6RCxNQUFNLENBQUMsdUJBQXVCLDRCQUE0QixTQUFTLFFBQVE7Q0FDM0UsTUFBTSxDQUFDLHVCQUF1Qiw0QkFBNEIsU0FBUyxNQUFNO0NBQ3pFLE1BQU0sQ0FBQyx1QkFBdUIsNEJBQTRCLFNBQVMsSUFBSTtDQUN2RSxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLElBQUk7Q0FDM0QsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxVQUFVO0NBRS9ELElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVTtFQUN6QixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSx5Q0FBMEM7Ozs7O0lBQ25FLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQW9CO0lBQW9DOzs7OztJQUN0RSx3QkFBQyxVQUFEO0tBQ0UsZUFBZSxTQUFTLFlBQVksYUFBYSxJQUFJO0tBQ3JELFdBQVU7ZUFDWDtJQUVPOzs7OztHQUNMOzs7Ozs7Q0FFVDtDQUVBLE1BQU0sWUFBWSxTQUFTLHVCQUF1QixTQUFTLFlBQVksQ0FBQztDQUN4RSxNQUFNLGVBQWUsU0FBUywyQkFBMkIsU0FBUyxpQkFBaUIsQ0FBQztDQUNwRixNQUFNLGlCQUFpQixTQUFTLGtCQUFrQixDQUFDO0NBRW5ELE1BQU0sb0JBQW9CLFVBQVUsUUFBUSxTQUMxQyxLQUFLLE9BQU8sWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFlBQVksQ0FBQyxLQUMzRCxLQUFLLGFBQWEsS0FBSyxVQUFVLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsS0FDbEYsS0FBSyxhQUFhLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsQ0FDcEU7Q0FFQSxNQUFNLHVCQUF1QixhQUFhLFFBQVEsU0FDaEQsS0FBSyxPQUFPLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsS0FDM0QsS0FBSyxhQUFhLEtBQUssVUFBVSxZQUFZLENBQUMsQ0FBQyxTQUFTLFlBQVksWUFBWSxDQUFDLEtBQ2pGLEtBQUssYUFBYSxLQUFLLFVBQVUsWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFlBQVksQ0FBQyxDQUNwRjtDQUVBLE1BQU0seUJBQXlCLGVBQWUsUUFBUSxTQUNuRCxLQUFLLFVBQVUsS0FBSyxPQUFPLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsS0FDM0UsS0FBSyxpQkFBaUIsS0FBSyxjQUFjLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsS0FDekYsS0FBSyxrQkFBa0IsS0FBSyxlQUFlLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsS0FDM0YsS0FBSywyQkFBMkIsS0FBSyx3QkFBd0IsWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFlBQVksQ0FBQyxDQUNoSDtDQUVBLE1BQU0sMEJBQTBCLFVBQVUsTUFDdkMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDLENBQUMsS0FBSyxNQUFNLE9BQU8sWUFBWSxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUUsT0FBTyxpQkFBaUIsRUFDcEc7Q0FFQSxNQUFNLDRCQUE0QixhQUFhLE1BQzVDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDLEtBQUssTUFBTSxrQkFBa0IsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUNoRjtDQUVBLE1BQU0sc0JBQXNCLE9BQU8sS0FBSyxNQUFNLE1BQU0sQ0FBQztDQUVyRCxNQUFNLHdCQUNKLHdCQUF3QixzQkFBc0Isd0JBQXdCLGdCQUNqRSxrQkFBa0IsS0FBSyxNQUFNLE1BQU0sQ0FBQyw0QkFDckMsd0JBQXdCLGlCQUN0QixZQUFZLEtBQUssTUFBTSxLQUN2Qix3QkFBd0IsMEJBQTBCLHdCQUF3QixrQkFDdkUsVUFBVSxLQUFLLE1BQU0sTUFBTSxrQkFBa0IsS0FBSyxNQUFNLEtBQ3pELHdCQUF3Qix1QkFDdEIsYUFBYSxLQUFLLE1BQU0sS0FDeEI7Q0FFWixNQUFNLHFCQUFxQixNQUFNO0VBQy9CLE1BQU0sT0FBTyxFQUFFLE9BQU8sTUFBTTtFQUM1QixJQUFJLENBQUMsTUFBTTtFQUVYLElBQUksS0FBSyxPQUFPLEtBQUssT0FBTyxNQUFNO0dBQ2hDLFlBQVksc0VBQXNFO0dBQ2xGO0VBQ0Y7RUFFQSxZQUFZLElBQUk7RUFDaEIsSUFBSSxZQUFZLElBQUksZ0JBQWdCLFVBQVU7RUFDOUMsY0FBYyxJQUFJLGdCQUFnQixJQUFJLENBQUM7Q0FDekM7Q0FFQSxNQUFNLHdCQUF3QixNQUFNO0VBQ2xDLEVBQUUsZUFBZTtFQUNqQixJQUFJLENBQUMscUJBQXFCO0VBRTFCLElBQUksZ0JBQWdCLENBQUM7RUFFckIsSUFBSSxpQkFBaUIsV0FBVztHQUM5QixnQkFBZ0I7SUFDZCxVQUFVLFNBQVMsVUFBVSxFQUFFO0lBQy9CLG1CQUFtQixpQkFBaUIsZUFBZSxxQkFBcUI7S0FBRSxJQUFJO0tBQUssSUFBSTtLQUFLLElBQUk7SUFBSTtJQUNwRyxrQkFBa0IsaUJBQWlCLGVBQWUsb0JBQW9CO0tBQUUsT0FBTztLQUFJLE1BQU07S0FBSSxLQUFLO0lBQUc7SUFDckcsU0FBUyxpQkFBaUIsZUFBZSxXQUFXO0tBQUUsSUFBSTtLQUFPLElBQUk7S0FBTyxJQUFJO0lBQU07SUFDdEYsV0FBVyxpQkFBaUIsZUFBZSxhQUFhO0lBQ3hELFVBQVUsaUJBQWlCLGVBQWUsWUFBWSxDQUFDO0lBQ3ZELGVBQWUsaUJBQWlCLGVBQWUsaUJBQWlCO0tBQUUsU0FBUztLQUFJLGVBQWU7SUFBRztJQUNqRyxjQUFjLGlCQUFpQixlQUFlLGdCQUFnQjtLQUFFLFNBQVM7S0FBSSxlQUFlO0lBQUc7R0FDakc7RUFDRixPQUFPLElBQUksaUJBQWlCLGlCQUFpQjtHQUMzQyxNQUFNLFNBQVMsV0FBVyxPQUFPLFlBQVksaUJBQWlCLGVBQWUsT0FBTyxpQkFBaUIsZUFBZSxlQUFlLENBQUMsQ0FBQyxDQUFDLFFBQVEsWUFBWSxFQUFFLENBQUMsS0FBSztHQUNsSyxNQUFNLFVBQVUsV0FBVyxpQkFBaUIsZUFBZSxrQkFBa0IsRUFBRyxLQUFLO0dBQ3JGLE1BQU0sV0FBVyxTQUFTLEtBQUssTUFBTSxTQUFTLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRyxJQUFJLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLE1BQU07R0FDOUcsTUFBTSxXQUFXLFdBQVcsT0FBTyxxQkFBcUIsaUJBQWlCLGVBQWUscUJBQXFCLEtBQUssQ0FBQyxDQUFDLFFBQVEsWUFBWSxFQUFFLENBQUMsS0FBSztHQUNoSixNQUFNLFVBQVUsVUFBVSxXQUFXLElBQUksS0FBSyxNQUFRLFNBQVMsT0FBUyxLQUFLLEtBQUssQ0FBQyxJQUFJLFlBQWEsR0FBRyxJQUFJLE1BQU07R0FFakgsZ0JBQWdCO0lBQ2QsT0FBTyxjQUFjLGlCQUFpQixlQUFlLFNBQVM7SUFDOUQsT0FBTyxpQkFBaUIsZUFBZSxTQUFTO0lBQ2hELGFBQWEsWUFBWSxpQkFBaUIsZUFBZSxlQUFlO0lBQ3hFLEtBQUssVUFBVSxZQUFZO0lBQzNCLE9BQU8saUJBQWlCLGVBQWUsU0FBUyxVQUFVO0lBQzFELE9BQU8saUJBQWlCLGVBQWUsU0FBUyxZQUFZO0lBQzVELE1BQU0saUJBQWlCLGVBQWUsUUFBUSxZQUFZO0lBQzFELGdCQUFnQjtJQUNoQixtQkFBbUIsaUJBQWlCLGVBQWUscUJBQXFCO0lBQ3hFLG1CQUFtQixpQkFBaUIsZUFBZSxxQkFBcUI7SUFDeEUsbUJBQW1CLGlCQUFpQixlQUFlLHFCQUFxQjtJQUN4RSxxQkFBcUIsaUJBQWlCLGVBQWUsdUJBQXVCO0lBQzVFLG1CQUFtQixhQUFhLGlCQUFpQixlQUFlLHFCQUFxQjtJQUNyRixVQUFVLGlCQUFpQixpQkFBaUIsZUFBZSxZQUFZO0lBQ3ZFLGlCQUFpQixtQkFBbUIsaUJBQWlCLGVBQWUsbUJBQW1CO0lBQ3ZGLG1CQUFtQixxQkFBcUIsaUJBQWlCLGVBQWUscUJBQXFCO0lBQzdGLGVBQWUsaUJBQWlCLGVBQWUsaUJBQWlCO0lBQ2hFLGVBQWUsaUJBQWlCLGVBQWUsaUJBQWlCO0lBQ2hFLGdCQUFnQixpQkFBaUIsZUFBZSxrQkFBa0I7SUFDbEUsaUJBQWlCLGlCQUFpQixlQUFlLG1CQUFtQixtQkFBbUI7SUFDdkYsa0JBQWtCLGlCQUFpQixlQUFlLG9CQUFvQjtJQUN0RSxtQkFBbUIsaUJBQWlCLGVBQWUscUJBQXFCLHFCQUFxQjtJQUM3RixvQkFBb0IsaUJBQWlCLGVBQWUsc0JBQXNCLFdBQVc7SUFDckYsYUFBYSxpQkFBaUIsZUFBZSxlQUFlO0lBQzVELFFBQVEsaUJBQWlCLGVBQWUsVUFBVTtJQUNsRCxNQUFNLGlCQUFpQixlQUFlLFFBQVE7SUFDOUMsWUFBWSxpQkFBaUIsZUFBZSxjQUFjO0tBQ3hELFVBQVU7TUFBRSxPQUFPO01BQU8sYUFBYTtNQUFPLFNBQVM7TUFBSSxNQUFNO01BQUksVUFBVTtNQUFJLFNBQVM7TUFBSSxXQUFXO01BQUksZUFBZTtLQUFHO0tBQ2pJLFlBQVk7TUFBRSxPQUFPO01BQU8sYUFBYTtNQUFPLFNBQVM7TUFBSSxNQUFNO01BQUksVUFBVTtNQUFJLFNBQVM7TUFBSSxXQUFXO01BQUksZUFBZTtLQUFHO0tBQ25JLFFBQVE7TUFBRSxPQUFPO01BQU8sYUFBYTtNQUFPLFNBQVM7TUFBSSxNQUFNO01BQUksVUFBVTtNQUFJLFNBQVM7TUFBSSxXQUFXO01BQUksZUFBZTtLQUFHO0lBQ2pJO0lBQ0EsS0FBSyxpQkFBaUIsZUFBZSxPQUFPO0tBQzFDLGdCQUFnQjtLQUNoQixpQkFBaUI7S0FDakIsc0JBQXNCO0tBQ3RCLGtCQUFrQjtLQUNsQixtQkFBbUI7S0FDbkIsYUFBYTtLQUNiLGVBQWU7SUFDakI7R0FDRjtFQUNGLE9BQU8sSUFBSSxpQkFBaUIsYUFBYTtHQUN2QyxNQUFNLFlBQVksV0FBVyxPQUFPLFVBQVUsaUJBQWlCLGVBQWUsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLFlBQVksRUFBRSxDQUFDLEtBQUs7R0FDcEgsTUFBTSxXQUFXLFdBQVcsT0FBTyxpQkFBaUIsaUJBQWlCLGVBQWUsTUFBTSxpQkFBaUIsZUFBZSxjQUFjLENBQUMsQ0FBQyxDQUFDLFFBQVEsWUFBWSxFQUFFLENBQUMsTUFBTSxZQUFZLEtBQUssTUFBTSxZQUFZLEtBQU0sR0FBRyxJQUFJLE1BQU07R0FDOU4sTUFBTSxRQUFRLFdBQVcsaUJBQWlCLGVBQWUsa0JBQWtCLEVBQUcsS0FBSztHQUNuRixNQUFNLFVBQVUsWUFBWSxLQUFLLE1BQU0sWUFBWSxLQUFLLEtBQUssS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsSUFBSSxNQUFNO0dBQ2pILE1BQU0sWUFBWSxXQUFXLE9BQU8sZUFBZSxpQkFBaUIsZUFBZSxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsWUFBWSxFQUFFLENBQUMsS0FBSztHQUU5SCxnQkFBZ0I7SUFDZCxLQUFLLGFBQWE7SUFDbEIsSUFBSSxZQUFZO0lBQ2hCLFlBQVksWUFBWTtJQUN4QixNQUFNLGlCQUFpQixlQUFlLFFBQVE7SUFDOUMsZ0JBQWdCO0lBQ2hCLG1CQUFtQixjQUFjLGlCQUFpQixlQUFlLHFCQUFxQjtJQUN0RixVQUFVLGFBQWE7SUFDdkIsaUJBQWlCLGtCQUFrQixpQkFBaUIsZUFBZSxtQkFBbUIsaUJBQWlCLGVBQWUsZUFBZTtJQUNySSxhQUFhLGtCQUFrQixpQkFBaUIsZUFBZSxlQUFlO0lBQzlFLHNCQUFzQixpQkFBaUIsZUFBZSx3QkFBd0I7SUFDOUUscUJBQXFCLGlCQUFpQixlQUFlLHVCQUF1QjtJQUM1RSxnQkFBZ0IsaUJBQWlCLGVBQWUsa0JBQWtCO0lBQ2xFLGNBQWMsaUJBQWlCLGVBQWUsZ0JBQWdCO0dBQ2hFO0VBQ0YsT0FBTyxJQUFJLGlCQUFpQixxQkFBcUI7R0FDL0MsZ0JBQWdCLGlCQUFpQixpQkFBaUI7SUFDaEQsT0FBTztJQUFJLFFBQVE7SUFBSSxhQUFhO0lBQUksa0JBQWtCO0lBQUksWUFBWTtJQUFJLGlCQUFpQjtJQUMvRixnQkFBZ0IsZ0JBQWdCO0lBQVMsbUJBQW1CLGdCQUFnQjtJQUFTLFlBQVk7SUFDakcsdUJBQXVCLGFBQWE7SUFDcEMsdUJBQXVCO0lBQUksVUFBVTtJQUFhLFVBQVU7SUFBWSxxQkFBcUI7SUFDN0Ysa0JBQWtCLGNBQWMsZUFBZSx1QkFBdUI7SUFBUSxVQUFVLG9CQUFvQjtJQUFLLG9CQUFvQjtJQUNySSxpQkFBaUI7SUFBeUIsb0JBQW9CO0lBQUksaUJBQWlCO0lBQ25GLG9CQUFvQjtJQUFJLHVCQUF1QjtJQUMvQyxxQkFBcUI7SUFBTSxXQUFXO0lBQ3RDLHVCQUF1QjtJQUFPLFlBQVk7SUFDMUMseUJBQXlCO0lBQW1CLG1CQUFtQjtJQUMvRCxzQkFBc0I7SUFBSSxZQUFZO0lBQUksb0JBQW9CO0lBQzlELHlCQUF5QjtJQUFJLGlCQUFpQjtJQUFZLDJCQUEyQjtJQUNyRixpQkFBaUI7SUFBSSxrQkFBa0I7SUFBSSxpQkFBaUI7SUFDNUQscUJBQXFCO0lBQXVCLGNBQWM7SUFBSSxZQUFZO0dBQzVFO0VBQ0YsT0FBTyxJQUFJLGlCQUFpQixvQkFBb0I7R0FDOUMsZ0JBQWdCO0lBQ2QsR0FBSSxpQkFBaUIsaUJBQWlCLENBQUM7SUFDdkMsY0FBYyxxQkFBcUI7SUFDbkMsZ0JBQWdCLHFCQUFxQjtJQUNyQyxzQkFBc0IscUJBQXFCO0lBQzNDLGVBQWUsMkJBQTJCO0lBQzFDLHdCQUF3Qix1QkFBdUI7SUFDL0Msb0JBQW9CLHVCQUF1QjtJQUMzQyxjQUFjLDBCQUEwQjtJQUN4QyxpQkFBaUIsUUFBUSx5QkFBeUI7SUFDbEQsZ0JBQWdCLDRCQUE0QjtJQUM1QyxLQUFLLGlCQUFpQjtJQUN0QixvQkFBb0Isd0JBQXdCO0dBQzlDO0VBQ0YsT0FBTyxJQUFJLGlCQUFpQixPQUFPO0dBQ2pDLGdCQUFnQjtJQUNkLHdCQUF3QixxQkFBcUI7SUFDN0Msa0JBQWtCLGNBQWM7SUFDaEMsa0JBQWtCLHVCQUF1QjtJQUN6QyxlQUFlLFNBQVMsa0JBQWtCLEVBQUUsS0FBSztHQUNuRDtFQUNGLE9BQU8sSUFBSSxpQkFBaUIsaUJBQWlCO0dBQzNDLGdCQUFnQjtJQUNkO0lBQ0EsdUJBQXVCO0lBQ3ZCO0lBQ0EsZ0JBQWdCO0dBQ2xCO0VBQ0YsT0FBTyxJQUFJLGlCQUFpQixZQUFZO0dBQ3RDLGdCQUFnQjtJQUNkO0lBQ0E7SUFDQTtHQUNGO0VBQ0YsT0FBTztHQUNMLGdCQUFnQixFQUNkLDZCQUE2QixnQkFDL0I7RUFDRjtFQUVBLElBQUksaUJBQWlCO0dBQ25CLHVCQUF1QixZQUFZLGdCQUFnQixJQUFJO0lBQ3JELFFBQVEsT0FBTyxLQUFLO0lBQ3BCO0lBQ0EsV0FBVyxVQUFVLEtBQUssS0FBSztJQUMvQixlQUFlLGNBQWMsS0FBSyxLQUFLO0lBQ3ZDLHdCQUF3Qix1QkFBdUIsS0FBSztJQUNwRDtHQUNGLENBQUM7R0FDRCxZQUFZLHVDQUF1QyxTQUFTO0dBQzVELG1CQUFtQixJQUFJO0dBQ3ZCLHFCQUFxQixLQUFLO0VBQzVCLE9BQU87R0FDTCxNQUFNLFNBQVMsb0JBQW9CLFlBQVk7SUFDN0MsUUFBUSxPQUFPLEtBQUs7SUFDcEI7SUFDQSxXQUFXLFVBQVUsS0FBSyxLQUFLO0lBQy9CLGVBQWUsY0FBYyxLQUFLLEtBQUs7SUFDdkM7SUFDQSx3QkFBd0IsdUJBQXVCLEtBQUs7SUFDcEQ7R0FDRixDQUFDO0dBRUQsSUFBSSxPQUFPLFNBQVM7SUFDbEIsVUFBVSxFQUFFO0lBQ1osYUFBYSxFQUFFO0lBQ2YsaUJBQWlCLEVBQUU7SUFDbkIsMEJBQTBCLEVBQUU7SUFDNUIsWUFBWSxJQUFJO0lBQ2hCLElBQUksWUFBWSxJQUFJLGdCQUFnQixVQUFVO0lBQzlDLGNBQWMsSUFBSTtJQUNsQixxQkFBcUIsS0FBSztJQUMxQixZQUFZLHNDQUFzQyxTQUFTO0dBQzdELE9BQU87SUFDTCxZQUFZLE9BQU8sS0FBSztHQUMxQjtFQUNGO0NBQ0Y7Q0FFQSxNQUFNLDBCQUEwQixNQUFNO0VBQ3BDLEVBQUUsZUFBZTtFQUNqQixJQUFJLENBQUMsdUJBQXVCO0VBRTVCLElBQUksd0JBQXdCLHNCQUFzQix3QkFBd0IsZUFBZTtHQUN2RixNQUFNLFNBQVMseUJBQXlCLFlBQVk7SUFDbEQsUUFBUSxrQkFBa0IsS0FBSyxLQUFLO0lBQ3BDLFdBQVcscUJBQXFCLEtBQUssS0FBSztJQUMxQyxjQUFjLGFBQWEsS0FBSyxLQUFLO0lBQ3JDLFdBQVcsY0FBYyxLQUFLLEtBQUs7SUFDbkMsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDM0MsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixTQUFTO0tBQUUsTUFBTTtLQUFXLFFBQVE7SUFBVSxDQUFDO0lBQ25GLGVBQWUsQ0FBQztJQUNoQixjQUFjLENBQUM7SUFDZixvQkFBb0IsQ0FBQztJQUNyQixjQUFjLENBQUM7SUFDZixpQkFBaUIsQ0FBQztHQUNwQixDQUFDO0dBRUQsSUFBSSxPQUFPLFNBQVM7SUFDbEIscUJBQXFCLEVBQUU7SUFDdkIsd0JBQXdCLEVBQUU7SUFDMUIsZ0JBQWdCLFNBQVM7SUFDekIsaUJBQWlCLEVBQUU7SUFDbkIsdUJBQXVCLEtBQUs7SUFDNUIsWUFBWSwwREFBMEQsU0FBUztHQUNqRixPQUFPO0lBQ0wsWUFBWSxPQUFPLEtBQUs7R0FDMUI7R0FDQTtFQUNGO0VBRUEsSUFBSSx3QkFBd0IsZ0JBQWdCO0dBQzFDLE1BQU0sU0FBUyxXQUFXLHNCQUFzQixLQUFLO0dBQ3JELE1BQU0sT0FBTyxXQUFXLFlBQVksS0FBSztHQUN6QyxNQUFNLFVBQVUsU0FBUyxLQUFJLENBQUUsUUFBUSxDQUFDO0dBQ3hDLElBQUksWUFBWTtHQUNoQixJQUFJLFNBQVMsSUFBSSxZQUFZO1FBQ3hCLElBQUksU0FBUyxJQUFJLFlBQVk7UUFDN0IsSUFBSSxTQUFTLElBQUksWUFBWTtHQUVsQyxNQUFNLFNBQVMseUJBQXlCLFlBQVk7SUFDbEQsUUFBUSxZQUFZLEtBQUssS0FBSztJQUM5QixjQUFjO0lBQ2QsV0FBVyxlQUFlLEtBQUssS0FBSztJQUNwQyxjQUFjO0lBQ2QsV0FBVyxjQUFjLEtBQUssS0FBSyxNQUFNLFlBQVk7SUFDckQsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDM0MsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixTQUFTO0tBQUUsTUFBTTtLQUFXLFFBQVE7SUFBVSxDQUFDO0lBQ25GLGVBQWUsQ0FBQztJQUNoQixjQUFjLENBQUM7SUFDZixvQkFBb0I7S0FDbEIscUJBQXFCO0tBQ3JCLDBCQUEwQjtLQUMxQix1QkFBdUI7S0FDdkI7S0FDQSxlQUFlO0tBQ2YsY0FBYztJQUNoQjtJQUNBLGNBQWMsQ0FBQztJQUNmLGlCQUFpQixDQUFDO0dBQ3BCLENBQUM7R0FFRCxJQUFJLE9BQU8sU0FBUztJQUNsQixlQUFlLEVBQUU7SUFDakIsa0JBQWtCLEVBQUU7SUFDcEIsMEJBQTBCLEVBQUU7SUFDNUIsdUJBQXVCLEtBQUs7SUFDNUIsWUFBWSxvREFBb0QsU0FBUztHQUMzRSxPQUFPO0lBQ0wsWUFBWSxPQUFPLEtBQUs7R0FDMUI7R0FDQTtFQUNGO0VBRUEsSUFBSSx3QkFBd0IsMEJBQTBCLHdCQUF3QixpQkFBaUI7R0FDN0YsTUFBTSxRQUFRLFdBQVcsY0FBYyxLQUFLO0dBQzVDLElBQUksbUJBQW1CO0dBQ3ZCLElBQUksUUFBUSxJQUFJLG1CQUFtQjtRQUM5QixJQUFJLFFBQVEsR0FBRyxtQkFBbUI7R0FFdkMsTUFBTSxTQUFTLHlCQUF5QixZQUFZO0lBQ2xELFNBQVMsYUFBYSxrQkFBaUIsQ0FBRSxLQUFLLEtBQUs7SUFDbkQsY0FBYztJQUNkLFlBQVksZ0JBQWdCLHFCQUFvQixDQUFFLEtBQUssS0FBSztJQUM1RCxjQUFjO0lBQ2QsV0FBVyxjQUFjLEtBQUssS0FBSyxNQUFNLFlBQVk7SUFDckQsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDM0MsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixTQUFTO0tBQUUsTUFBTTtLQUFXLFFBQVE7SUFBVSxDQUFDO0lBQ25GLGVBQWUsQ0FBQztJQUNoQixjQUFjLENBQUM7SUFDZixvQkFBb0IsQ0FBQztJQUNyQixjQUFjO0tBQ1osaUJBQWlCLGVBQWUsS0FBSyxLQUFLO0tBQzFDLGdCQUFnQixhQUFhO0tBQzdCLGdCQUFnQixXQUFXO0tBQzNCLFdBQVcsWUFBWTtLQUN2QixhQUFhO0tBQ2Isb0JBQW9CO0lBQ3RCO0lBQ0EsaUJBQWlCLENBQUM7R0FDcEIsQ0FBQztHQUVELElBQUksT0FBTyxTQUFTO0lBQ2xCLGFBQWEsRUFBRTtJQUNmLGdCQUFnQixFQUFFO0lBQ2xCLGtCQUFrQixFQUFFO0lBQ3BCLHFCQUFxQixFQUFFO0lBQ3ZCLHdCQUF3QixFQUFFO0lBQzFCLHVCQUF1QixLQUFLO0lBQzVCLFlBQVksbUVBQW1FLFNBQVM7R0FDMUYsT0FBTztJQUNMLFlBQVksT0FBTyxLQUFLO0dBQzFCO0dBQ0E7RUFDRjtFQUVBLElBQUksd0JBQXdCLHNCQUFzQjtHQUNoRCxNQUFNLFlBQVksV0FBVyxxQkFBcUIsS0FBSztHQUN2RCxNQUFNLFdBQVcsV0FBVyxxQkFBcUIsS0FBSztHQUN0RCxNQUFNLFVBQVUsV0FBVyxlQUFlLEtBQUs7R0FDL0MsTUFBTSxrQkFBbUIsWUFBWSxXQUFZLElBQUcsQ0FBRSxRQUFRLENBQUM7R0FDL0QsTUFBTSxrQkFBa0Isa0JBQWtCLFdBQVcsR0FBRSxDQUFFLFFBQVEsQ0FBQztHQUVsRSxNQUFNLFNBQVMseUJBQXlCLFlBQVk7SUFDbEQsUUFBUSxhQUFhLEtBQUssS0FBSztJQUMvQixjQUFjO0lBQ2QsV0FBVyxnQkFBZ0IsS0FBSyxLQUFLO0lBQ3JDLGNBQWM7SUFDZCxXQUFXLGNBQWMsS0FBSyxLQUFLLE1BQU0sWUFBWTtJQUNyRCxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUMzQyxNQUFNLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLFNBQVM7S0FBRSxNQUFNO0tBQVcsUUFBUTtJQUFVLENBQUM7SUFDbkYsZUFBZTtLQUNiLGlCQUFpQjtLQUNqQixpQkFBaUI7S0FDakIsaUJBQWlCO0tBQ2pCO0tBQ0EsV0FBVztLQUNYLHlCQUF5QjtLQUN6QixvQkFBb0I7SUFDdEI7SUFDQSxjQUFjLENBQUM7SUFDZixvQkFBb0IsQ0FBQztJQUNyQixjQUFjLENBQUM7SUFDZixpQkFBaUIsQ0FBQztHQUNwQixDQUFDO0dBRUQsSUFBSSxPQUFPLFNBQVM7SUFDbEIsZ0JBQWdCLEVBQUU7SUFDbEIsbUJBQW1CLEVBQUU7SUFDckIsdUJBQXVCLEtBQUs7SUFDNUIsWUFBWSxnRUFBZ0UsU0FBUztHQUN2RixPQUFPO0lBQ0wsWUFBWSxPQUFPLEtBQUs7R0FDMUI7R0FDQTtFQUNGO0NBQ0Y7Q0FFQSxNQUFNLDZCQUE2QixNQUFNO0VBQ3ZDLEVBQUUsZUFBZTtFQUNqQixJQUFJLENBQUMsb0JBQW9CLEtBQUssR0FBRztFQUVqQyxNQUFNLFNBQVMsaUJBQWlCLFlBQVk7R0FDMUMsUUFBUSxvQkFBb0IsS0FBSztHQUNqQyxlQUFlLHFCQUFxQixLQUFLLEtBQUs7R0FDOUMsZ0JBQWdCLGlCQUFpQixLQUFLLEtBQUs7R0FDM0Msc0JBQXNCLDZCQUE2QjtHQUNuRCxXQUFXLE1BQU0sWUFBWTtHQUM3QixPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztHQUMzQyxNQUFNLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLFNBQVM7SUFBRSxNQUFNO0lBQVcsUUFBUTtHQUFVLENBQUM7RUFDckYsQ0FBQztFQUVELElBQUksT0FBTyxTQUFTO0dBQ2xCLHVCQUF1QixFQUFFO0dBQ3pCLHdCQUF3QixFQUFFO0dBQzFCLG9CQUFvQixFQUFFO0dBQ3RCLDBCQUEwQixLQUFLO0dBQy9CLFlBQVksMENBQTBDLFNBQVM7RUFDakUsT0FBTztHQUNMLFlBQVksT0FBTyxLQUFLO0VBQzFCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FHRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUNoQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsU0FBUyxZQUFZLFdBQVc7TUFDL0MsV0FBVTtNQUNWLE9BQU07Z0JBRU4sd0JBQUMsV0FBRCxFQUFXLFdBQVUsVUFBVzs7Ozs7S0FDMUI7Ozs7ZUFDUix3QkFBQyxPQUFEO01BQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQXNGLGlCQUN0RSxRQUFRLE1BQ2xCOzs7Ozs7TUFDTix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBbUQsU0FBUztNQUFXOzs7OztNQUNwRixTQUFTLGVBQ1Isd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQThDLFNBQVM7TUFBZTs7Ozs7S0FFbEY7Ozs7YUFDRjs7Ozs7O0dBQ0M7Ozs7O0dBR1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEI7S0FHRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyRTtTQUFzQjs7Ozs7U0FDakgsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQ7V0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSx5QkFBMEI7Ozs7O1dBQUM7V0FBRSxTQUFTO1VBQ3hEOzs7Ozs7U0FDSix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBeUMsU0FBUyxlQUFlO1NBQXNCOzs7OztRQUNqRzs7OztrQkFDSixNQUFNLFNBQVMsV0FBVyxjQUFjLGlCQUN2Qyx3QkFBQyxVQUFEO1NBQ0UsZUFBZTtVQUNiLHNCQUFzQixTQUFTLE1BQU07VUFDckMsMkJBQTJCLFNBQVMsZUFBZSxFQUFFO1VBQ3JELHlCQUF5QixTQUFTLGFBQWEsRUFBRTtVQUNqRCx5QkFBeUIsU0FBUyxxQkFBcUIsRUFBRTtVQUN6RCwyQkFBMkIsU0FBUyx1QkFBdUIsRUFBRTtVQUM3RCx3QkFBd0IsU0FBUyxvQkFBb0IsRUFBRTtVQUN2RCx5QkFBeUIsSUFBSTtTQUMvQjtTQUNBLFdBQVU7bUJBQ1g7UUFFTzs7OztnQkFFUDs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF1RDtVQUEyQjs7OztvQkFDbEcsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXdDLFNBQVMsYUFBYTtVQUFvQjs7OztrQkFDL0Y7Ozs7OztTQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUQ7U0FBYTs7OzttQkFDcEYsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXdDLFNBQVM7U0FBYTs7OztpQkFDM0U7Ozs7O1NBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF1RDtTQUFjOzs7O21CQUNyRix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFBSyxZQUFTLFNBQVMsWUFBWSxJQUFJLEtBQUssU0FBUyxTQUFTLENBQUMsQ0FBQyxlQUFlLE9BQU8sSUFBSSxLQUFXOzs7O29CQUNyRyx3QkFBQyxPQUFELGFBQUssaUJBQWMsU0FBUyxZQUFZLElBQUksS0FBSyxTQUFTLFNBQVMsQ0FBQyxDQUFDLGVBQWUsT0FBTyxJQUFJLEtBQVc7Ozs7a0JBQ3ZHOzs7OztpQkFDRjs7Ozs7UUFDRjs7Ozs7O09BRUosTUFBTSxTQUFTLFdBQ2Qsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHVCQUF3Qjs7OzttQkFBQywrREFDdkM7Ozs7O2tCQUNKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLHdCQUFDLFVBQUQ7YUFBUSxXQUFVO3VCQUFpQjtZQUFlOzs7OztZQUFDO1lBQUMsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWdDLFNBQVMscUJBQXFCO1lBQVk7Ozs7O1dBQU07Ozs7O1dBQ3pKLHdCQUFDLE9BQUQ7WUFBSyx3QkFBQyxVQUFEO2FBQVEsV0FBVTt1QkFBaUI7WUFBaUI7Ozs7O1lBQUM7WUFBQyx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBZ0MsU0FBUyx1QkFBdUI7WUFBWTs7Ozs7V0FBTTs7Ozs7V0FDN0osd0JBQUMsT0FBRDtZQUFLLHdCQUFDLFVBQUQ7YUFBUSxXQUFVO3VCQUFpQjtZQUFjOzs7OztZQUFDO1lBQUMsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWdDLFNBQVMsb0JBQW9CO1lBQVk7Ozs7O1dBQU07Ozs7O1VBQ3BKOzs7Ozs7UUFDRjs7OztnQkFDRjs7Ozs7O01BSUo7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBR0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxhQUFhLFVBQVU7UUFDdEMsV0FBVyxrR0FDVCxjQUFjLGFBQ1YsMENBQ0E7a0JBTFIsQ0FRRSx3QkFBQyxLQUFELEVBQUssV0FBVSxVQUFXOzs7O2tCQUFDLG9CQUNyQjs7Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUNFLGVBQWUsYUFBYSxhQUFhO1FBQ3pDLFdBQVcsa0dBQ1QsY0FBYyxnQkFDViwwQ0FDQTtrQkFMUixDQVFFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7a0JBQUMsZUFDMUI7Ozs7O2VBQ0w7Ozs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBR0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU87U0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztTQUM5QyxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2tCQUNELHdCQUFDLFFBQUQsRUFBUSxXQUFVLGlEQUFrRDs7OztnQkFDakU7Ozs7O2lCQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBR0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1VBQ0UsZUFBZSxTQUFTLFlBQVksVUFBVSxZQUFZLFdBQVcsU0FBUztVQUM5RSxXQUFVO1VBQ1YsT0FBTTtvQkFIUixDQUtFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7b0JBQUMsY0FDOUI7Ozs7O21CQUNSLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLGlCQUFpQixJQUFJO1VBQ3BDLFdBQVU7VUFDVixPQUFNO29CQUhSLENBS0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsNkJBQThCOzs7O29CQUFDLGlCQUMvQzs7Ozs7aUJBQ0w7Ozs7O2tCQUdKLE1BQU0sU0FBUyxZQUNkLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBRUcsY0FBYyxjQUNiLGdEQUNFLHdCQUFDLFVBQUQ7VUFDRSxlQUFlO1dBQ2IscUJBQXFCLENBQUMsaUJBQWlCO1dBQ3ZDLGVBQWUsSUFBSSxJQUFJLENBQUM7VUFDMUI7VUFDQSxXQUFXLGdJQUNULG9CQUNJLHVEQUNBO29CQVJSO1dBV0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsVUFBVzs7Ozs7V0FBQztXQUFFLG9CQUFvQix1QkFBdUI7VUFDMUU7Ozs7O21CQUVSLHdCQUFDLFVBQUQ7VUFDRSxlQUFlO1dBQ2IsZ0JBQWdCLFNBQVM7V0FDekIscUJBQXFCLElBQUk7VUFDM0I7VUFDQSxXQUFVO29CQUxaLENBT0Usd0JBQUMsS0FBRCxFQUFLLFdBQVUseUJBQTBCOzs7O29CQUFDLG1CQUNwQzs7Ozs7aUJBQ1I7Ozs7bUJBSUgsY0FBYyxpQkFDYix3QkFBQyxVQUFEO1VBQ0UsZUFBZSx1QkFBdUIsSUFBSTtVQUMxQyxXQUFVO29CQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUseUJBQTBCOzs7O29CQUFDLHFCQUN6Qzs7Ozs7aUJBRVA7Ozs7O2dCQUVKOzs7OztlQUNGOzs7OztjQUNGOzs7Ozs7S0FFSixxQkFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsa0RBQW1EOzs7O2lCQUNsRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEI7U0FBcUQ7U0FDMUIsd0JBQUMsVUFBRDtVQUFRLFdBQVU7b0JBQTRCLFlBQVk7U0FBYTs7Ozs7U0FBQztTQUFFLFlBQVksU0FBUyxJQUFJLDBCQUEwQjtRQUNsSjs7Ozs7ZUFDSDs7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7bUJBQ1g7UUFFTzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7bUJBQ1g7UUFFTzs7Ozs7UUFDUCxZQUFZLE9BQU8sS0FBSyxNQUFNLFNBQVMsWUFDdEMsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFVO21CQUZaO1VBSUUsd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7Ozs7VUFBQztVQUFZLFlBQVk7VUFBSztTQUN6RDs7Ozs7O1FBRVYsd0JBQUMsVUFBRDtTQUNFLGVBQWU7VUFDYixxQkFBcUIsS0FBSztVQUMxQixlQUFlLElBQUksSUFBSSxDQUFDO1NBQzFCO1NBQ0EsV0FBVTttQkFDWDtRQUVPOzs7OztPQUNMOzs7OztjQUNGOzs7Ozs7S0FJTixjQUFjLGlCQUNiLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFtQztNQUFtQzs7OztnQkFDcEYsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BQXVHOzs7O2NBQzFJOzs7OztlQUVKLHFCQUFxQixTQUFTLElBQzdCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLHFCQUFxQixLQUFLLFNBQVM7T0FDbEMsTUFBTSxhQUFhLFlBQVksSUFBSSxLQUFLLEVBQUU7T0FDMUMsT0FDRSx3QkFBQyxPQUFEO1FBRUUsZUFBZTtTQUNiLElBQUksbUJBQW1CO1VBQ3JCLG1CQUFtQixLQUFLLEVBQUU7U0FDNUIsT0FBTztVQUNMLFNBQVMsWUFBWSxVQUFVLFdBQVcsS0FBSyxJQUFJO1NBQ3JEO1FBQ0Y7UUFDQSxXQUFXLHNLQUNULHFCQUFxQixhQUNqQixpRUFDQTtrQkFaUixDQWVFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsb0ZBQXFGOzs7OztVQUN6Ryx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixLQUFLLGlCQUFpQixpQkFBaUIsNEJBQTRCLEtBQUssaUJBQWlCLHlCQUF5QiwyQkFBMkIsS0FBSyxpQkFBaUIsdUJBQXVCLDBCQUEwQjtVQUNqTjs7Ozs7VUFFTix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFDYixLQUFLLGlCQUFpQixpQkFBaUIsbUJBQW1CLEtBQUssaUJBQWlCLHlCQUF5QiwwQkFBMEIsS0FBSyxpQkFBaUIsdUJBQXVCLHlCQUF5QjtXQUN0TTs7Ozs7VUFDSDs7Ozs7VUFFSixDQUFDLHFCQUNBLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUF5SSxRQUNsSSxLQUFLLEVBQ047Ozs7OztVQUNIOzs7OztTQUVKOzs7OztrQkFFUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1gseUJBQXlCLEtBQUssUUFBUSxLQUFLLEVBQUU7V0FDNUM7Ozs7cUJBQ0osd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFDRSx3QkFBQyxLQUFEO2NBQUcsV0FBVTt3QkFBYjtlQUF3Qix3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQTJCO2VBQWdCOzs7OztlQUFDO2VBQUUsS0FBSztjQUFhOzs7Ozs7YUFDeEcsd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQWI7ZUFBd0Isd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUEyQjtlQUFjOzs7OztlQUFDO2VBQUUsS0FBSztjQUFnQjs7Ozs7O2FBQ3pHLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUFiO2VBQWtELHdCQUFDLFVBQUQsRUFBVSxXQUFVLHNDQUF1Qzs7Ozs7ZUFBQyx3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQTJCO2VBQVk7Ozs7O2VBQUM7ZUFBRSxLQUFLO2NBQVM7Ozs7OzthQUN0TCx3QkFBQyxLQUFEO2NBQUcsV0FBVTt3QkFBYjtlQUFrRCx3QkFBQyxNQUFELEVBQU0sV0FBVSxzQ0FBdUM7Ozs7O2VBQUMsd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUEyQjtlQUFnQjs7Ozs7ZUFBQztlQUFFLEtBQUs7Y0FBYTs7Ozs7O1lBQ3ZMOzs7OzttQkFDRjs7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ2Isd0JBQUMsbUJBQUQ7WUFBbUIsVUFBVTtZQUFNLGNBQWMsS0FBSyxnQkFBZ0I7V0FBZ0I7Ozs7O1VBQ25GOzs7OztVQUdMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLHFCQUFEO1lBQ0UsY0FBYyxTQUFTLFlBQVksVUFBVSxXQUFXLEtBQUssSUFBSTtZQUNqRSx1QkFBdUIsU0FBUyxZQUFZLFVBQVUsV0FBVyxLQUFLLElBQUk7WUFDMUUsVUFBVSxZQUFZO2FBQ3BCLE1BQU0sS0FBSyxNQUFNLFFBQVE7Y0FDdkIsT0FBTztjQUNQLFNBQVMsdURBQXVELEtBQUssT0FBTztjQUM1RSxNQUFNO2NBQ04sYUFBYTthQUNmLENBQUM7YUFDRCxJQUFJLElBQUk7Y0FDTixrQkFBa0IsWUFBWSxLQUFLLEVBQUU7YUFDdkM7WUFDRjtZQUNBLFVBQVUsTUFBTSxTQUFTO1dBQzFCOzs7OztVQUNFOzs7OztTQUNGOzs7OztnQkFDRjtVQXpFSSxLQUFLOzs7O2NBeUVUO01BRVQsQ0FBQztLQUNFOzs7O2dCQUVILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsbUNBQW9DOzs7O2dCQUN4RCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFtQztPQUFnQzs7OztpQkFDakYsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQTBDO09BRXBEOzs7O2VBQ0E7Ozs7O2NBQ0Y7Ozs7O2FBRUo7Ozs7O0tBSU4sY0FBYyxjQUNiLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBbUM7TUFBK0M7Ozs7Z0JBQ2hHLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF5QjtNQUFtRzs7OztjQUN0STs7OztnQkFDTCx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGVBQWUsb0JBQW9CLElBQUk7T0FDdkMsV0FBVTtpQkFIWixDQUtFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLHlCQUEwQjs7OztpQkFBQyx1QkFDcEM7Ozs7O2NBQ0w7Ozs7O2VBRUosa0JBQWtCLFNBQVMsSUFDMUIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osa0JBQWtCLEtBQUssU0FBUztPQUMvQixNQUFNLFlBQVksS0FBSyxpQkFBaUI7T0FDeEMsTUFBTSxVQUFVLEtBQUssaUJBQWlCO09BQ3RDLE1BQU0sUUFBUSxLQUFLLGlCQUFpQjtPQUNwQyxNQUFNLGlCQUFpQixLQUFLLGlCQUFpQjtPQUM3QyxNQUFNLGFBQWEsS0FBSyxpQkFBaUI7T0FDekMsTUFBTSxvQkFBb0IsS0FBSyxpQkFBaUI7T0FDaEQsTUFBTSxRQUFRLEtBQUssaUJBQWlCO09BQ3BDLE1BQU0sVUFBVSxLQUFLLGlCQUFpQjtPQUV0QyxPQUNFLHdCQUFDLE9BQUQ7UUFFRSxlQUFlO1NBQ2IsSUFBSSxtQkFBbUI7VUFDckIsbUJBQW1CLEtBQUssRUFBRTtTQUM1QixPQUFPO1VBQ0wsU0FBUyxZQUFZLFVBQVUsV0FBVyxLQUFLLElBQUk7U0FDckQ7UUFDRjtRQUNBLFdBQVcsc0tBQ1QscUJBQXFCLFlBQVksSUFBSSxLQUFLLEVBQUUsSUFDeEMsaUVBQ0E7a0JBWlIsQ0FnQkUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRyxLQUFLLFlBQVksS0FBSyxPQUNyQix3QkFBQyxXQUFEO1dBQ0UsTUFBTSxLQUFLO1dBQ1gsS0FBSyxLQUFLO1dBQ1YsS0FBSyxLQUFLO1dBQ1YsV0FBVTtVQUNYOzs7O3FCQUVELHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0csYUFBYSx3QkFBQyxLQUFELEVBQUssV0FBVSxrQ0FBbUM7Ozs7O1lBQy9ELFdBQVcsd0JBQUMsS0FBRCxFQUFLLFdBQVUscUNBQXNDOzs7OztZQUNoRSxTQUFTLHdCQUFDLEtBQUQsRUFBSyxXQUFVLG9DQUFxQzs7Ozs7WUFDN0Qsa0JBQWtCLHdCQUFDLGFBQUQsRUFBYSxXQUFVLG1DQUFvQzs7Ozs7WUFDN0UsY0FBYyx3QkFBQyxXQUFELEVBQVcsV0FBVSxzQ0FBdUM7Ozs7O1lBQzFFLHFCQUFxQix3QkFBQyxPQUFELEVBQU8sV0FBVSxtQ0FBb0M7Ozs7O1lBQzFFLFNBQVMsd0JBQUMsS0FBRCxFQUFLLFdBQVUsb0NBQXFDOzs7OztZQUM3RCxXQUFXLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHNDQUF1Qzs7Ozs7WUFDcEUsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxjQUFjLENBQUMscUJBQXFCLENBQUMsU0FBUyxDQUFDLFdBQVcsd0JBQUMsUUFBRCxFQUFRLFdBQVUsb0NBQXFDOzs7OztZQUMxSyx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBNEQ7WUFBZ0I7Ozs7O1dBQ3pGOzs7Ozs7VUFJUCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNHLGFBQ0Msd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXFIO1lBRS9IOzs7OztZQUVQLFdBQ0Msd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXFIO1lBRS9IOzs7OztZQUVQLFNBQ0Msd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXFIO1lBRS9IOzs7OztZQUVQLGtCQUNDLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFxSDtZQUUvSDs7Ozs7WUFFUCxjQUNDLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFxSDtZQUUvSDs7Ozs7WUFFUCxxQkFDQyx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBcUg7WUFFL0g7Ozs7O1lBRVAsU0FDQyx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBcUg7WUFFL0g7Ozs7O1lBRVAsV0FDQyx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBcUg7WUFFL0g7Ozs7O1dBRUw7Ozs7OztVQUVKLENBQUMscUJBQ0Esd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ2Isd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCLENBQXlJLFFBQ2xJLEtBQUssRUFDTjs7Ozs7O1VBQ0g7Ozs7O1VBSU4scUJBQ0Msd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ2Isd0JBQUMsUUFBRDtZQUFNLFdBQVcsMkVBQ2YsWUFBWSxJQUFJLEtBQUssRUFBRSxJQUNuQiwrRUFDQTtzQkFFSCxZQUFZLElBQUksS0FBSyxFQUFFLElBQ3RCLHdCQUFDLGFBQUQsRUFBYSxXQUFVLGNBQWU7Ozs7dUJBRXRDLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGlEQUFrRDs7Ozs7V0FFL0Q7Ozs7O1VBQ0g7Ozs7O1NBRUo7Ozs7O2tCQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWCx5QkFBeUIsS0FBSyxRQUFRLEtBQUssRUFBRTtXQUM1Qzs7OztxQkFFSix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUNFLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUFiO2VBQXdCLHdCQUFDLFFBQUQ7Z0JBQU0sV0FBVTswQkFBMkI7ZUFBZ0I7Ozs7O2VBQUM7ZUFBRSxLQUFLO2NBQWE7Ozs7OzthQUN4Ryx3QkFBQyxLQUFEO2NBQUcsV0FBVTt3QkFBYjtlQUF3Qix3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQTJCO2VBQXFCOzs7OztlQUFDO2VBQUUsS0FBSyxpQkFBaUI7Y0FBaUI7Ozs7OzthQUdqSSxhQUNDLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUFiO2VBQXdIO2VBQ3hHLEtBQUssZUFBZSxZQUFZO2VBQUc7ZUFBUyxLQUFLLGVBQWUsb0JBQW9CO2VBQVk7Y0FDN0c7Ozs7OzthQUVKLFdBQ0Msd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQWI7ZUFBaUk7ZUFDNUgsS0FBSyxlQUFlLE9BQU87ZUFBVTtlQUFPLEtBQUssZUFBZSxZQUFZO2VBQW9CO2VBQUcsS0FBSyxlQUFlLG1CQUFtQjtlQUFVO2NBQ3RKOzs7Ozs7YUFFSixTQUNDLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUFiO2VBQThIO2VBQ3pILEtBQUssZUFBZSxPQUFPO2VBQVU7ZUFBSSxLQUFLLGVBQWUscUJBQXFCO2VBQVE7ZUFBWSxLQUFLLGVBQWUsWUFBWTtjQUN4STs7Ozs7O2FBRUosa0JBQ0Msd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQWI7ZUFBMkg7ZUFDcEcsS0FBSyxlQUFlLHlCQUF5QjtlQUFRO2VBQUksS0FBSyxlQUFlLGFBQWE7Y0FDOUc7Ozs7OzthQUVKLGNBQ0Msd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQWI7ZUFBb0k7ZUFDOUgsS0FBSyxlQUFlLHFCQUFxQjtlQUFTO2VBQUksS0FBSyxlQUFlLHFCQUFxQjtjQUNsRzs7Ozs7O2FBRUoscUJBQ0Msd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQWI7ZUFBMkg7ZUFDckgsS0FBSyxlQUFlLGdCQUFnQjtlQUFVO2VBQUksS0FBSyxlQUFlLHNCQUFzQixLQUFLLGVBQWUsMEJBQTBCO2VBQVc7ZUFBSSxLQUFLLGVBQWUsZ0JBQWdCO2NBQ2hNOzs7Ozs7YUFFSixTQUNDLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUFiO2VBQThIO2VBQ2pILEtBQUssZUFBZSwwQkFBMEI7ZUFBUztlQUFJLEtBQUssZUFBZSxpQkFBaUI7ZUFBRTtlQUFXLEtBQUssZUFBZSxvQkFBb0I7ZUFBUTtjQUN2Szs7Ozs7O2FBRUosV0FDQyx3QkFBQyxLQUFEO2NBQUcsV0FBVTt3QkFBYjtlQUFvSTtlQUMvSCxLQUFLLGVBQWUseUJBQXlCO2VBQVc7ZUFBSSxLQUFLLGVBQWUsWUFBWTtlQUFFO2VBQVMsS0FBSyxlQUFlLGtCQUFrQjtlQUFRO2NBQ3ZKOzs7Ozs7WUFFRjs7Ozs7bUJBQ0Y7Ozs7OztVQUdMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLG1CQUFEO1lBQW1CLFVBQVU7WUFBTSxjQUFjLEtBQUssZ0JBQWdCO1dBQVk7Ozs7O1VBQy9FOzs7OztVQUdMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLHFCQUFEO1lBQ0UsY0FBYzthQUNaLG1CQUFtQixJQUFJO2FBQ3ZCLHFCQUFxQixJQUFJO1lBQzNCO1lBQ0EsdUJBQXVCLFNBQVMsWUFBWSxVQUFVLFdBQVcsS0FBSyxJQUFJO1lBQzFFLFVBQVUsWUFBWTthQUNwQixNQUFNLEtBQUssTUFBTSxRQUFRO2NBQ3ZCLE9BQU87Y0FDUCxTQUFTLHFEQUFxRCxLQUFLLE9BQU87Y0FDMUUsTUFBTTtjQUNOLGFBQWE7YUFDZixDQUFDO2FBQ0QsSUFBSSxJQUFJO2NBQ04sdUJBQXVCLFlBQVksS0FBSyxFQUFFO2FBQzVDO1lBQ0Y7WUFDQSxVQUFVLE1BQU0sU0FBUztXQUMxQjs7Ozs7VUFDRTs7Ozs7U0FDRjs7Ozs7Z0JBQ0Y7VUEvTEUsS0FBSzs7OztjQStMUDtNQUVULENBQUM7S0FDRTs7OztnQkFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLG1DQUFvQzs7OztnQkFDbkQsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBbUM7T0FBOEI7Ozs7aUJBQy9FLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUEwQztPQUVwRDs7OztlQUNBOzs7OztjQUNGOzs7OzthQUVKOzs7OztJQUdIOzs7Ozs7R0FHTCxxQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBb0YsZUFBZTtNQUFFLHFCQUFxQixLQUFLO01BQUcsbUJBQW1CLElBQUk7S0FBRztJQUFJOzs7O2NBRS9LLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsS0FBRCxFQUFLLFdBQVUseUJBQTBCOzs7OztRQUFDO1FBQUUsa0JBQWtCLHFCQUFxQixnQkFBZ0IsV0FBVztPQUM1Rzs7Ozs7Z0JBQ0osd0JBQUMsVUFBRDtPQUNFLGVBQWU7UUFBRSxxQkFBcUIsS0FBSztRQUFHLG1CQUFtQixJQUFJO09BQUc7T0FDeEUsV0FBVTtpQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztNQUNsQjs7OztjQUNMOzs7OztlQUVMLHdCQUFDLFFBQUQ7TUFBTSxVQUFVO01BQXNCLFdBQVU7Z0JBQWhEO09BR0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0RTtPQUV0Rjs7OztpQkFDUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWjtTQUNDO1VBQUUsSUFBSTtVQUFXLE9BQU87U0FBb0I7U0FDNUM7VUFBRSxJQUFJO1VBQW9CLE9BQU87U0FBcUI7U0FDdEQ7VUFBRSxJQUFJO1VBQWEsT0FBTztTQUFlO1NBQ3pDO1VBQUUsSUFBSTtVQUFpQixPQUFPO1NBQW1CO1NBQ2pEO1VBQUUsSUFBSTtVQUFZLE9BQU87U0FBbUI7U0FDNUM7VUFBRSxJQUFJO1VBQU8sT0FBTztTQUFtQjtTQUN2QztVQUFFLElBQUk7VUFBcUIsT0FBTztTQUFnQjtRQUNwRCxDQUFDLENBQUMsS0FBSyxNQUNMLHdCQUFDLFVBQUQ7U0FFRSxNQUFLO1NBQ0wsZUFBZSxnQkFBZ0IsRUFBRSxFQUFFO1NBQ25DLFdBQVcsNkVBQ1QsaUJBQWlCLEVBQUUsS0FDZiwwQ0FDQTttQkFHTCxFQUFFO1FBQ0csR0FWRCxFQUFFOzs7O2VBVUQsQ0FDVDtPQUNFOzs7O2VBQ0Y7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0RTtRQUV0Rjs7Ozs7UUFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMO1NBQ0EsT0FBTztTQUNQLFdBQVcsTUFBTSxVQUFVLEVBQUUsT0FBTyxLQUFLO1NBQ3pDLGFBQWEsT0FBTyxXQUFXLGlCQUFpQixNQUFNO1NBQ3RELFdBQVcsZ0lBQ1QsMEJBQ0ksMkRBQ0E7UUFFUDs7Ozs7UUFDQSwyQkFDQyx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLGNBQWU7Ozs7bUJBQUMsMERBQ3hDOzs7Ozs7T0FFRjs7Ozs7T0FHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRFO09BRXRGOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1FBQzVDLGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FHTCx3QkFBQyxPQUFELFlBQ0Usd0JBQUMsK0JBQUQ7UUFDYztRQUNaLGlCQUFpQixpQkFBaUI7UUFDbEMsZUFBZTtRQUNmLE9BQU87UUFDUCxXQUFXLFFBQVEsaUJBQWlCLEdBQUc7UUFDdkMsT0FBTTtRQUNOLGFBQVk7T0FDYjs7OztnQkFDRTs7Ozs7T0FLSixpQkFBaUIsYUFDaEIsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0RTtPQUV0Rjs7OztpQkFDUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLFNBQVMsRUFBRSxPQUFPLE9BQU8sRUFBRSxLQUFLLENBQUM7U0FDOUQsYUFBWTtTQUNaLFdBQVU7UUFDWDs7OztrQkFDRCx3QkFBQyxVQUFEO1NBQ0UsT0FBTztTQUNQLFdBQVcsTUFBTTtVQUNmLE1BQU0sTUFBTSxTQUFTLEVBQUUsT0FBTyxPQUFPLEVBQUU7VUFDdkMsSUFBSSxLQUFLLFlBQVksR0FBRztTQUMxQjtTQUNBLFdBQVU7bUJBTlo7VUFRRSx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBRztVQUFzQjs7Ozs7VUFDdkMsd0JBQUMsVUFBRDtXQUFRLE9BQU87cUJBQUk7VUFBZ0I7Ozs7O1VBQ25DLHdCQUFDLFVBQUQ7V0FBUSxPQUFPO3FCQUFJO1VBQWdCOzs7OztVQUNuQyx3QkFBQyxVQUFEO1dBQVEsT0FBTztxQkFBSTtVQUFnQjs7Ozs7VUFDbkMsd0JBQUMsVUFBRDtXQUFRLE9BQU87cUJBQUk7VUFBZ0I7Ozs7O1VBQ25DLHdCQUFDLFVBQUQ7V0FBUSxPQUFPO3FCQUFJO1VBQWdCOzs7OztVQUNuQyx3QkFBQyxVQUFEO1dBQVEsT0FBTztxQkFBSTtVQUFnQjs7Ozs7VUFDbkMsd0JBQUMsVUFBRDtXQUFRLE9BQU87cUJBQUk7VUFBZ0I7Ozs7O1VBQ25DLHdCQUFDLFVBQUQ7V0FBUSxPQUFPO3FCQUFJO1VBQWdCOzs7OztVQUNuQyx3QkFBQyxVQUFEO1dBQVEsT0FBTztxQkFBSTtVQUFnQjs7Ozs7U0FDN0I7Ozs7O2dCQUNMOzs7OztlQUNGOzs7OztPQUlOLGlCQUFpQixtQkFDaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FBbUI7Ozs7bUJBQzlHLHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU8sT0FBTztVQUFVLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO1VBQUcsYUFBWTtVQUFjLFdBQVU7U0FBMEc7Ozs7aUJBQzdOOzs7O21CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FBWTs7OzttQkFDdkcsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQVksV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQVMsV0FBVTtTQUFnRzs7OztpQkFDbE47Ozs7aUJBQ0Y7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUF5Qjs7OzttQkFDcEgsd0JBQUMsVUFBRDtVQUFRLE9BQU87VUFBVyxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztVQUFHLFdBQVU7b0JBQW5GO1dBQ0Usd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVM7V0FBcUM7Ozs7O1dBQzVELHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFPO1dBQXFDOzs7OztXQUMxRCx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBVztXQUF5Qjs7Ozs7V0FDbEQsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVE7V0FBaUM7Ozs7O1VBQ2pEOzs7OztpQkFDTDs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQWU7Ozs7bUJBQzFHLHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU8sT0FBTztVQUFlLFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQTBCLFdBQVU7U0FBZ0c7Ozs7aUJBQ3pPOzs7O2lCQUNGOzs7OztnQkFDRjs7Ozs7O09BSU4saUJBQWlCLGVBQ2hCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQW9COzs7O21CQUMvRyx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLE9BQU87VUFBUSxXQUFXLE1BQU0sVUFBVSxFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBYyxXQUFVO1NBQTBHOzs7O2lCQUN6Tjs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQWtCOzs7O21CQUM3Ryx3QkFBQyxVQUFEO1VBQVEsT0FBTztVQUFnQixXQUFXLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1VBQUcsV0FBVTtvQkFBN0Y7V0FDRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBUztXQUF1Qjs7Ozs7V0FDOUMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQU07V0FBbUI7Ozs7O1dBQ3ZDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFXO1dBQWdCOzs7OztVQUNuQzs7Ozs7aUJBQ0w7Ozs7aUJBQ0Y7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUF5Qjs7OzttQkFDcEgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQVksV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQWtCLFdBQVU7U0FBMEc7Ozs7aUJBQ3JPOzs7O21CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FBMkI7Ozs7bUJBQ3RILHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU8sT0FBTztVQUFhLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxLQUFLO1VBQUcsYUFBWTtVQUFhLFdBQVU7U0FBMEc7Ozs7aUJBQ2xPOzs7O2lCQUNGOzs7OztnQkFDRjs7Ozs7O09BSU4saUJBQWlCLG1CQUNoQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUFzQjs7OzttQkFDakgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQW1CLFdBQVcsTUFBTSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQVksV0FBVTtTQUEwRzs7OztpQkFDN087Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUF5Qjs7OzttQkFDcEgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQWUsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBWSxXQUFVO1NBQXlIOzs7O2lCQUNwUDs7OztpQkFDRjs7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUEwRTtRQUFnQzs7OztrQkFDM0gsd0JBQUMsU0FBRDtTQUFPLE1BQUs7U0FBTyxPQUFPO1NBQVcsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7U0FBRyxhQUFZO1NBQStCLFdBQVU7UUFBZ0c7Ozs7Z0JBQ3RPOzs7O2dCQUNGOzs7Ozs7T0FJTixpQkFBaUIsY0FDaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTBFO1FBQXlCOzs7O2tCQUNwSCx3QkFBQyxTQUFEO1NBQU8sTUFBSztTQUFPLE9BQU87U0FBbUIsV0FBVyxNQUFNLHFCQUFxQixFQUFFLE9BQU8sS0FBSztTQUFHLGFBQVk7U0FBYSxXQUFVO1FBQTBHOzs7O2dCQUM5Tzs7OztrQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTBFO1FBQXlCOzs7O2tCQUNwSCx3QkFBQyxVQUFEO1NBQVEsT0FBTztTQUFtQixXQUFXLE1BQU0scUJBQXFCLEVBQUUsT0FBTyxLQUFLO1NBQUcsV0FBVTttQkFBbkcsQ0FDRSx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBYTtTQUF3Qjs7OzttQkFDbkQsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVM7U0FBb0I7Ozs7aUJBQ3JDOzs7OztnQkFDTDs7OztnQkFDRjs7Ozs7O09BSU4saUJBQWlCLHVCQUNoQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUE2Qjs7OzttQkFDeEgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQVcsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQWUsV0FBVTtTQUEwRzs7OztpQkFDaE87Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUF3Qjs7OzttQkFDbkgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQWtCLFdBQVcsTUFBTSxvQkFBb0IsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQWMsV0FBVTtTQUEwRzs7OztpQkFDN087Ozs7aUJBQ0Y7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUFvQjs7OzttQkFDL0csd0JBQUMsVUFBRDtVQUFRLE9BQU87VUFBVyxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztVQUFHLFdBQVU7b0JBQW5GLENBQ0Usd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQWE7VUFBZ0M7Ozs7b0JBQzNELHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFPO1VBQVk7Ozs7a0JBQzNCOzs7OztpQkFDTDs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQXdCOzs7O21CQUNuSCx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLE9BQU87VUFBYyxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1VBQUcsYUFBWTtVQUFvQixXQUFVO1NBQTBHOzs7O2lCQUMzTzs7OztpQkFDRjs7Ozs7Z0JBQ0Y7Ozs7OztPQUlOLGlCQUFpQixzQkFDaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FFRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBMEU7VUFFcEY7Ozs7b0JBQ1Asd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1lBQ0UsT0FBTyx3QkFBd0IsU0FBUyxpQkFBaUIsSUFBSSxvQkFBcUIsb0JBQW9CLFdBQVc7WUFDakgsV0FBVyxNQUFNO2FBQ2YsSUFBSSxFQUFFLE9BQU8sVUFBVSxVQUFVO2NBQy9CLHFCQUFxQixFQUFFLE9BQU8sS0FBSzthQUNyQztZQUNGO1lBQ0EsV0FBVTtzQkFQWjthQVNFLHdCQUFDLFVBQUQ7Y0FBUSxPQUFNO3dCQUFHO2FBQTZCOzs7OzthQUM5Qyx3QkFBQyxZQUFEO2NBQVUsT0FBTTt3QkFDYix5QkFBeUIsS0FBSSxNQUM1Qix3QkFBQyxVQUFEO2VBQWdCLE9BQU87eUJBQUk7Y0FBVSxHQUF4Qjs7OztxQkFBd0IsQ0FDdEM7YUFDTzs7Ozs7YUFDVix3QkFBQyxZQUFEO2NBQVUsT0FBTTt3QkFDYix5QkFBeUIsS0FBSSxNQUM1Qix3QkFBQyxVQUFEO2VBQWdCLE9BQU87eUJBQUk7Y0FBVSxHQUF4Qjs7OztxQkFBd0IsQ0FDdEM7YUFDTzs7Ozs7YUFDVix3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBUzthQUF1Qjs7Ozs7WUFDeEM7Ozs7O3FCQUNSLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVcsTUFBTSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7WUFDcEQsYUFBWTtZQUNaLFdBQVU7V0FDWDs7OzttQkFDRTs7Ozs7a0JBQ0Y7Ozs7b0JBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUEwRTtVQUVwRjs7OztvQkFDUCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU87V0FDUCxXQUFXLE1BQU0sdUJBQXVCLEVBQUUsT0FBTyxLQUFLO1dBQ3RELGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7a0JBQ0Y7Ozs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQXFFO1VBRS9FOzs7O29CQUNQLHdCQUFDLFVBQUQ7V0FDRSxPQUFPO1dBQ1AsV0FBVyxNQUFNLDBCQUEwQixFQUFFLE9BQU8sS0FBSztXQUN6RCxXQUFVO3FCQUhaO1lBS0Usd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQWtDO1lBQTBDOzs7OztZQUMxRix3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBd0I7WUFBdUU7Ozs7O1lBQzdHLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUEyQjtZQUEyRTs7Ozs7V0FDOUc7Ozs7O2tCQUNMOzs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsd0JBQXlCOzs7O3VCQUFDLHdDQUN2Qzs7Ozs7c0JBQ04sd0JBQUMsU0FBRDthQUFPLFdBQVU7dUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtjQUNFLE1BQUs7Y0FDTCxTQUFTO2NBQ1QsV0FBVyxNQUFNLDZCQUE2QixFQUFFLE9BQU8sT0FBTztjQUM5RCxXQUFVO2FBQ1g7Ozs7dUJBQ0Qsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQTRCO2FBQW1COzs7O3FCQUMxRDs7Ozs7b0JBQ0o7Ozs7OztXQUVMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUEyRDtZQUE0Qjs7OztzQkFDeEcsd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxPQUFPO2FBQ1AsV0FBVyxNQUFNLHFCQUFxQixFQUFFLE9BQU8sS0FBSzthQUNwRCxhQUFZO2FBQ1osV0FBVTtZQUNYOzs7O29CQUNFOzs7O3NCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBMkQ7WUFBd0I7Ozs7c0JBQ3BHLHdCQUFDLFVBQUQ7YUFDRSxPQUFPO2FBQ1AsV0FBVyxNQUFNLDJCQUEyQixFQUFFLE9BQU8sS0FBSzthQUMxRCxXQUFVO3VCQUhaO2NBS0Usd0JBQUMsVUFBRDtlQUFRLE9BQU07eUJBQWM7Y0FBbUI7Ozs7O2NBQy9DLHdCQUFDLFVBQUQ7ZUFBUSxPQUFNO3lCQUFRO2NBQWE7Ozs7O2NBQ25DLHdCQUFDLFVBQUQ7ZUFBUSxPQUFNO3lCQUFRO2NBQW1DOzs7OzthQUNuRDs7Ozs7b0JBQ0w7Ozs7b0JBQ0Y7Ozs7OztXQUVMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7Y0FBTyxXQUFVO3dCQUEyRDthQUF3Qjs7Ozt1QkFDcEcsd0JBQUMsU0FBRDtjQUNFLE1BQUs7Y0FDTCxPQUFPO2NBQ1AsV0FBVyxNQUFNLDRCQUE0QixFQUFFLE9BQU8sS0FBSztjQUMzRCxhQUFZO2NBQ1osV0FBVTthQUNYOzs7O3FCQUNFOzs7OzthQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO2NBQU8sV0FBVTt3QkFBMkQ7YUFBaUI7Ozs7dUJBQzdGLHdCQUFDLFNBQUQ7Y0FDRSxNQUFLO2NBQ0wsT0FBTztjQUNQLFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7Y0FDaEQsYUFBWTtjQUNaLFdBQVU7YUFDWDs7OztxQkFDRTs7Ozs7YUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtjQUFPLFdBQVU7d0JBQTJEO2FBQTZCOzs7O3VCQUN6Ryx3QkFBQyxTQUFEO2NBQ0UsTUFBSztjQUNMLE9BQU87Y0FDUCxXQUFXLE1BQU0sd0JBQXdCLEVBQUUsT0FBTyxLQUFLO2NBQ3ZELGFBQVk7Y0FDWixXQUFVO2FBQ1g7Ozs7cUJBQ0U7Ozs7O1lBQ0Y7Ozs7OztVQUNGOzs7Ozs7UUFDRjs7Ozs7O09BSU4saUJBQWlCLFNBQ2hCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQTBCOzs7O21CQUNySCx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLE9BQU87VUFBbUIsV0FBVyxNQUFNLHFCQUFxQixFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBYSxXQUFVO1NBQTBHOzs7O2lCQUM5Tzs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQXdCOzs7O21CQUNuSCx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLE9BQU87VUFBWSxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBWSxXQUFVO1NBQTBHOzs7O2lCQUMvTjs7OztpQkFDRjs7Ozs7a0JBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQXdCOzs7O21CQUNuSCx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLE9BQU87VUFBcUIsV0FBVyxNQUFNLHVCQUF1QixFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBZSxXQUFVO1NBQTBHOzs7O2lCQUNwUDs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQWdDOzs7O21CQUMzSCx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFTLEtBQUk7VUFBSSxLQUFJO1VBQUssT0FBTztVQUFrQixXQUFXLE1BQU0sb0JBQW9CLFNBQVMsRUFBRSxPQUFPLE9BQU8sRUFBRSxLQUFLLENBQUM7VUFBRyxhQUFZO1VBQUksV0FBVTtTQUEwRzs7OztpQkFDelE7Ozs7aUJBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FJTixpQkFBaUIsVUFDaEIsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0RTtPQUV0Rjs7OztpQkFDUCx3QkFBQyxZQUFEO1FBQVUsT0FBTztRQUFpQixXQUFXLE1BQU0sbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1FBQUcsTUFBTTtRQUFHLGFBQVk7UUFBbUMsV0FBVTtPQUE4SDs7OztlQUNwUjs7Ozs7T0FJUCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRFO09BRXRGOzs7O2lCQUNQLHdCQUFDLFlBQUQ7UUFDRSxPQUFPO1FBQ1AsV0FBVyxNQUFNLDBCQUEwQixFQUFFLE9BQU8sS0FBSztRQUN6RCxNQUFNO1FBQ04sYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakIsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx5QkFBMEI7Ozs7a0JBQUMsbUNBRXhDOzs7OztpQkFFTixhQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLEtBQUs7U0FBWSxLQUFJO1NBQWUsV0FBVTtRQUE4Qjs7OztrQkFDakYsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlO1VBQ2IsWUFBWSxJQUFJO1VBQ2hCLElBQUksWUFBWSxJQUFJLGdCQUFnQixVQUFVO1VBQzlDLGNBQWMsSUFBSTtTQUNwQjtTQUNBLFdBQVU7bUJBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7UUFDbEI7Ozs7Z0JBQ0w7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsOEJBQStCOzs7O29CQUNqRCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFZO1dBQWdCOzs7O3FCQUFDLFVBQzVDOzs7OztrQkFDQTs7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxRQUFPO1VBQ1AsU0FBUTtVQUNSLFVBQVU7VUFDVixXQUFVO1NBQ1g7Ozs7aUJBQ0k7Ozs7OztPQUNKOzs7O2VBRUo7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWU7VUFBRSxxQkFBcUIsS0FBSztVQUFHLG1CQUFtQixJQUFJO1NBQUc7U0FDeEUsV0FBVTttQkFDWDtRQUVPOzs7O2tCQUNSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsVUFBVSxDQUFDO1NBQ1gsV0FBVTttQkFFVCxrQkFBa0Isb0JBQW9CO1FBQ2pDOzs7O2dCQUNMOzs7Ozs7TUFFRDs7Ozs7YUFDSDs7Ozs7WUFDRjs7Ozs7O0dBSU4sdUJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQW9GLGVBQWUsdUJBQXVCLEtBQUs7SUFBSTs7OztjQUVsSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OztpQkFBQyx3Q0FDN0M7Ozs7O2dCQUNKLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLHVCQUF1QixLQUFLO09BQzNDLFdBQVU7aUJBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7TUFDbEI7Ozs7Y0FDTDs7Ozs7ZUFFTCx3QkFBQyxRQUFEO01BQU0sVUFBVTtNQUF3QixXQUFVO2dCQUFsRDtPQUdFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEU7T0FFdEY7Ozs7aUJBQ1Asd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1o7U0FDQztVQUFFLElBQUk7VUFBb0IsT0FBTztTQUF3QjtTQUN6RDtVQUFFLElBQUk7VUFBZ0IsT0FBTztTQUFtQjtTQUNoRDtVQUFFLElBQUk7VUFBd0IsT0FBTztTQUEyQjtTQUNoRTtVQUFFLElBQUk7VUFBc0IsT0FBTztTQUF1QjtRQUM1RCxDQUFDLENBQUMsS0FBSyxNQUNMLHdCQUFDLFVBQUQ7U0FFRSxNQUFLO1NBQ0wsZUFBZSx1QkFBdUIsRUFBRSxFQUFFO1NBQzFDLFdBQVcsOEVBQ1Qsd0JBQXdCLEVBQUUsS0FDdEIscURBQ0E7bUJBR0wsRUFBRTtRQUNHLEdBVkQsRUFBRTs7OztlQVVELENBQ1Q7T0FDRTs7OztlQUNGOzs7OztRQUtILHdCQUF3QixzQkFBc0Isd0JBQXdCLGtCQUN0RTtRQUNFLHdCQUFDLE9BQUQ7U0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBNEU7U0FFdEY7Ozs7O1NBQ1Asd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTDtVQUNBLE9BQU87VUFDUCxXQUFXLE1BQU0scUJBQXFCLEVBQUUsT0FBTyxLQUFLO1VBQ3BELGFBQVk7VUFDWixXQUFXLGdJQUNULDRCQUNJLDJEQUNBO1NBRVA7Ozs7O1NBQ0EsNkJBQ0Msd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWIsQ0FDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSxjQUFlOzs7O29CQUFDLCtDQUN4Qzs7Ozs7O1FBRUY7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0RTtRQUV0Rjs7OztrQkFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU87U0FDUCxXQUFXLE1BQU0sd0JBQXdCLEVBQUUsT0FBTyxLQUFLO1NBQ3ZELGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0RTtRQUV0Rjs7OztrQkFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU87U0FDUCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1NBQy9DLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O09BQ0w7Ozs7O09BSUgsd0JBQXdCLGtCQUN2QjtRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEU7UUFFdEY7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTDtTQUNBLE9BQU87U0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztTQUM5QyxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUF5Qjs7OzttQkFDcEgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQWdCLFdBQVcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQW1DLFdBQVU7U0FBZ0c7Ozs7aUJBQ3BQOzs7O21CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FBMEI7Ozs7bUJBQ3JILHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU8sT0FBTztVQUFhLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxLQUFLO1VBQUcsYUFBWTtVQUErQixXQUFVO1NBQWdHOzs7O2lCQUMxTzs7OztpQkFDRjs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTJEO1VBQXVCOzs7O29CQUNuRyx3QkFBQyxTQUFEO1dBQU8sTUFBSztXQUFTLE1BQUs7V0FBTSxPQUFPO1dBQW1CLFdBQVcsTUFBTSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7V0FBRyxhQUFZO1dBQUssV0FBVTtVQUE2Rzs7OztrQkFDdFA7Ozs7O1VBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUEyRDtVQUFvQjs7OztvQkFDaEcsd0JBQUMsU0FBRDtXQUFPLE1BQUs7V0FBUyxNQUFLO1dBQU0sT0FBTztXQUF3QixXQUFXLE1BQU0sMEJBQTBCLEVBQUUsT0FBTyxLQUFLO1dBQUcsYUFBWTtXQUFPLFdBQVU7VUFBMEg7Ozs7a0JBQy9ROzs7OztVQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBMkQ7VUFBa0I7Ozs7b0JBQzlGLHdCQUFDLFNBQUQ7V0FBTyxNQUFLO1dBQVMsTUFBSztXQUFNLE9BQU87V0FBYyxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1dBQUcsYUFBWTtXQUFLLFdBQVU7VUFBNkc7Ozs7a0JBQzVPOzs7OztTQUNGOzs7Ozs7UUFHSiwwQkFDQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUQ7U0FBNEI7Ozs7bUJBQ25HLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixFQUNJLFdBQVcsMEJBQTBCLENBQUMsSUFBSSxXQUFXLGdCQUFnQixDQUFDLEVBQUMsQ0FBRSxRQUFRLENBQUMsR0FBRSxLQUNsRjs7Ozs7aUJBQ0g7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBdUQ7VUFBeUI7Ozs7MkJBQ3hGO1dBQ04sTUFBTSxRQUFRLFdBQVcsMEJBQTBCLENBQUMsSUFBSSxXQUFXLGdCQUFnQixDQUFDO1dBQ3BGLElBQUksUUFBUSxJQUFJLE9BQU8sd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQThGO1dBQXdCOzs7OztXQUM3SixJQUFJLFFBQVEsSUFBSSxPQUFPLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFvRztXQUFvQjs7Ozs7V0FDL0osSUFBSSxRQUFRLElBQUksT0FBTyx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBdUc7V0FBd0I7Ozs7O1dBQ3RLLE9BQU8sd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTBHO1dBQW9COzs7OztVQUN2SixFQUFDLENBQUUsQ0FDQTs7Ozs7aUJBQ0Y7Ozs7OztPQUVQOzs7OztRQUlGLHdCQUF3QiwwQkFBMEIsd0JBQXdCLG9CQUMxRTtRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEU7UUFFdEY7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTDtTQUNBLE9BQU8sYUFBYTtTQUNwQixXQUFXLE1BQU07VUFBRSxhQUFhLEVBQUUsT0FBTyxLQUFLO1VBQUcscUJBQXFCLEVBQUUsT0FBTyxLQUFLO1NBQUc7U0FDdkYsYUFBWTtTQUNaLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FFcEY7Ozs7bUJBQ1Asd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7VUFDakQsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBRXBGOzs7O21CQUNQLHdCQUFDLFVBQUQ7VUFDRSxPQUFPO1VBQ1AsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7VUFDNUMsV0FBVTtvQkFIWjtXQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUEyQjtXQUFnQzs7Ozs7V0FDekUsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQXFCO1dBQTBCOzs7OztXQUM3RCx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBOEI7V0FBbUM7Ozs7O1dBQy9FLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUEwQjtXQUErQjs7Ozs7VUFDakU7Ozs7O2lCQUNMOzs7O2lCQUNGOzs7Ozs7UUFFSixrQkFDQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpRDtTQUErQjs7OzttQkFDL0YsV0FBVyxjQUFjLElBQUksS0FDNUIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXlCO1NBQTJDOzs7O29CQUNsRixXQUFXLGNBQWMsSUFBSSxJQUMvQix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBMkI7U0FBMkI7Ozs7b0JBRXRFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QjtTQUEwQzs7OztpQkFFdEY7Ozs7OztRQUdQLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUVwRjs7OzttQkFDUCx3QkFBQyxVQUFEO1VBQ0UsT0FBTztVQUNQLFdBQVcsTUFBTSxXQUFXLEVBQUUsT0FBTyxLQUFLO1VBQzFDLFdBQVU7b0JBSFo7V0FLRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBcUI7V0FBcUM7Ozs7O1dBQ3hFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFrQjtXQUFnQzs7Ozs7V0FDaEUsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQW9CO1dBQWtDOzs7OztXQUNwRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBaUI7V0FBc0I7Ozs7O1VBQy9DOzs7OztpQkFDTDs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBRXBGOzs7O21CQUNQLHdCQUFDLFVBQUQ7VUFDRSxPQUFPO1VBQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7VUFDM0MsV0FBVTtvQkFIWjtXQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFpQztXQUFzQzs7Ozs7V0FDckYsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQTJCO1dBQWdDOzs7OztXQUN6RSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBd0I7V0FBNkI7Ozs7O1VBQzdEOzs7OztpQkFDTDs7OztpQkFDRjs7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0RTtRQUV0Rjs7OztrQkFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU8sZ0JBQWdCO1NBQ3ZCLFdBQVcsTUFBTTtVQUFFLGdCQUFnQixFQUFFLE9BQU8sS0FBSztVQUFHLHdCQUF3QixFQUFFLE9BQU8sS0FBSztTQUFHO1NBQzdGLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O09BQ0w7Ozs7O09BSUgsd0JBQXdCLHdCQUN2QjtRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEU7UUFFdEY7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTDtTQUNBLE9BQU87U0FDUCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1NBQy9DLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQTBCOzs7O21CQUNySCx3QkFBQyxVQUFEO1VBQVEsT0FBTztVQUF1QixXQUFXLE1BQU0seUJBQXlCLEVBQUUsT0FBTyxLQUFLO1VBQUcsV0FBVTtvQkFBM0c7V0FDRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBUztXQUF1Qjs7Ozs7V0FDOUMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVc7V0FBZ0I7Ozs7O1dBQ3pDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFNO1dBQXlCOzs7OztVQUN2Qzs7Ozs7aUJBQ0w7Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUEwQjs7OzttQkFDckgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBUyxPQUFPO1VBQXVCLFdBQVcsTUFBTSx5QkFBeUIsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQVcsV0FBVTtTQUEwRzs7OztpQkFDdFA7Ozs7aUJBQ0Y7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUF1Qjs7OzttQkFDbEgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBUyxLQUFJO1VBQUksS0FBSTtVQUFNLE9BQU87VUFBdUIsV0FBVyxNQUFNLHlCQUF5QixFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBUyxXQUFVO1NBQTBHOzs7O2lCQUN0UTs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQThCOzs7O21CQUN6SCx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFTLE1BQUs7VUFBTSxPQUFPO1VBQWlCLFdBQVcsTUFBTSxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQVMsV0FBVTtTQUEwRzs7OztpQkFDblA7Ozs7aUJBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF1RDtTQUFxQjs7OzttQkFDNUYsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLEVBQ0ssV0FBVyx5QkFBeUIsQ0FBQyxJQUFJLFdBQVcseUJBQXlCLENBQUMsSUFBSyxJQUFHLENBQUUsUUFBUSxDQUFDLEdBQUUsU0FDbEc7Ozs7O2lCQUNIOzs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXVEO1VBQXdCOzs7O29CQUMvRix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsRUFDSyxXQUFXLHlCQUF5QixDQUFDLEtBQUssV0FBVyx5QkFBeUIsQ0FBQyxJQUFJLFFBQVMsV0FBVyxlQUFlLEtBQUssR0FBRSxDQUFFLFFBQVEsQ0FBQyxHQUFFLFFBQ3pJOzs7OztrQkFDSDs7Ozs7aUJBQ0Y7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUE0Qjs7OzttQkFDdkgsd0JBQUMsVUFBRDtVQUFRLE9BQU87VUFBZ0IsV0FBVyxNQUFNLGtCQUFrQixFQUFFLE9BQU8sS0FBSztVQUFHLFdBQVU7b0JBQTdGO1dBQ0Usd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVc7V0FBaUM7Ozs7O1dBQzFELHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFjO1dBQStCOzs7OztXQUMzRCx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBaUI7V0FBZ0M7Ozs7O1VBQ3pEOzs7OztpQkFDTDs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQXVCOzs7O21CQUNsSCx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLE9BQU87VUFBaUIsV0FBVyxNQUFNLG1CQUFtQixFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBb0MsV0FBVTtTQUFnRzs7OztpQkFDdlA7Ozs7aUJBQ0Y7Ozs7OztPQUNMOzs7OztPQUlKLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEU7T0FFdEY7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztRQUNoRCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsdUJBQXVCLEtBQUs7U0FDM0MsV0FBVTttQkFDWDtRQUVPOzs7O2tCQUNSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsVUFBVSxDQUFDO1NBQ1gsV0FBVTttQkFDWDtRQUVPOzs7O2dCQUNMOzs7Ozs7TUFFRDs7Ozs7YUFDSDs7Ozs7WUFDRjs7Ozs7O0dBSU4sMEJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQW9GLGVBQWUsMEJBQTBCLEtBQUs7SUFBSTs7OztjQUVySix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7OztpQkFBQyw4QkFDMUM7Ozs7O2dCQUNKLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLDBCQUEwQixLQUFLO09BQzlDLFdBQVU7aUJBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7TUFDbEI7Ozs7Y0FDTDs7Ozs7ZUFFTCx3QkFBQyxRQUFEO01BQU0sVUFBVTtNQUEyQixXQUFVO2dCQUFyRDtPQUVFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEU7T0FFdEY7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTDtRQUNBLE9BQU87UUFDUCxXQUFXLE1BQU0sdUJBQXVCLEVBQUUsT0FBTyxLQUFLO1FBQ3RELGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRFO09BRXRGOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSx3QkFBd0IsRUFBRSxPQUFPLEtBQUs7UUFDdkQsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEU7T0FFdEY7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLG9CQUFvQixFQUFFLE9BQU8sS0FBSztRQUNuRCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0RTtPQUV0Rjs7OztpQkFDUCx3QkFBQyxVQUFEO1FBQ0UsT0FBTztRQUNQLFdBQVcsTUFBTSw2QkFBNkIsRUFBRSxPQUFPLEtBQUs7UUFDNUQsV0FBVTtrQkFIWjtTQUtFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFlO1NBQW9COzs7OztTQUNqRCx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBZ0I7U0FBcUI7Ozs7O1NBQ25ELHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFlO1NBQW9COzs7OztRQUMzQzs7Ozs7ZUFDTDs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSwwQkFBMEIsS0FBSztTQUM5QyxXQUFVO21CQUNYO1FBRU87Ozs7a0JBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxVQUFVLENBQUMsb0JBQW9CLEtBQUs7U0FDcEMsV0FBVTttQkFDWDtRQUVPOzs7O2dCQUNMOzs7Ozs7TUFFRDs7Ozs7YUFDSDs7Ozs7WUFDRjs7Ozs7O0dBSU4seUJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OztpQkFBQyxrQkFDN0M7Ozs7O2dCQUNKLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLHlCQUF5QixLQUFLO09BQzdDLFdBQVU7aUJBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7TUFDbEI7Ozs7Y0FDTDs7Ozs7ZUFFTCx3QkFBQyxRQUFEO01BQU0sVUFBVTtNQUE0QixXQUFVO2dCQUF0RDtPQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBMEM7T0FBMEI7Ozs7aUJBQ3JGLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxzQkFBc0IsRUFBRSxPQUFPLEtBQUs7UUFDckQ7UUFDQSxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTBDO09BQStCOzs7O2lCQUMxRix3QkFBQyxZQUFEO1FBQ0UsT0FBTztRQUNQLFdBQVcsTUFBTSwyQkFBMkIsRUFBRSxPQUFPLEtBQUs7UUFDMUQsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUEwQztPQUFtQzs7OztpQkFDOUYsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLHlCQUF5QixFQUFFLE9BQU8sS0FBSztRQUN4RCxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUE4RDtRQUE0Qjs7OztrQkFDeEcsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQXdDO1VBQWE7Ozs7b0JBQ3RFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTztXQUNQLFdBQVcsTUFBTSx5QkFBeUIsRUFBRSxPQUFPLEtBQUs7V0FDeEQsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztVQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBd0M7VUFBZTs7OztvQkFDeEUsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPO1dBQ1AsV0FBVyxNQUFNLDJCQUEyQixFQUFFLE9BQU8sS0FBSztXQUMxRCxXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7O1VBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUF3QztVQUFZOzs7O29CQUNyRSx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU87V0FDUCxXQUFXLE1BQU0sd0JBQXdCLEVBQUUsT0FBTyxLQUFLO1dBQ3ZELFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7U0FDRjs7Ozs7Z0JBQ0Y7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLHlCQUF5QixLQUFLO1NBQzdDLFdBQVU7bUJBQ1g7UUFFTzs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7bUJBQ1g7UUFFTzs7OztnQkFDTDs7Ozs7O01BQ0Q7Ozs7O2FBQ0g7Ozs7OztHQUNGOzs7OztHQUlOLGdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7aUJBQUMsc0JBQ3hDOzs7OztnQkFDSix3QkFBQyxVQUFEO09BQ0UsZUFBZSxnQkFBZ0IsS0FBSztPQUNwQyxXQUFVO2lCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O01BQ2xCOzs7O2NBQ0w7Ozs7O2VBRUwsd0JBQUMsUUFBRDtNQUFNLFVBQVU7TUFBdUIsV0FBVTtnQkFBakQ7T0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQTZFLGlDQUM5Qyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUI7UUFBTzs7OztnQkFDaEU7Ozs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1FBQzVDLGFBQVk7UUFDWjtRQUNBLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FFdEU7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7UUFDNUMsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FFdEU7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFdBQVcsRUFBRSxPQUFPLEtBQUs7UUFDMUMsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLGdCQUFnQixLQUFLO1NBQ3BDLFdBQVU7bUJBQ1g7UUFFTzs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7bUJBQ1g7UUFFTzs7OztnQkFDTDs7Ozs7O01BQ0Q7Ozs7O2FBQ0g7Ozs7OztHQUNGOzs7OztHQU1QLHdCQUFDLHVCQUFEO0lBQ0UsUUFBUTtJQUNSLGVBQWUsb0JBQW9CLEtBQUs7SUFDN0I7SUFDWCxhQUFhLFNBQVM7SUFDVjtJQUNEO0dBQ1o7Ozs7O0dBR0Qsd0JBQUMsV0FBRDtJQUNFLFFBQVE7SUFDUixlQUFlLGlCQUFpQixLQUFLO0dBQ3RDOzs7OztFQUVFOzs7Ozs7QUFFVDs7Ozs7Ozs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJveWVjdG9WaWV3LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB1c2VTdG9yZSwgeyBnZXROZXh0RWxlbWVudElkLCBQUkVGSVhfTUFQLCBmb3JtYXRFbGVtZW50VGl0bGVXaXRoSWQgfSBmcm9tICcuLi9zdG9yZS91c2VTdG9yZSc7XG5pbXBvcnQgeyB1c2VDb25maXJtIH0gZnJvbSAnLi4vY29udGV4dC9Db25maXJtQ29udGV4dCc7XG5pbXBvcnQgTW9kYWxEaWFncmFtYVVuaWZpbGFyIGZyb20gJy4uL2NvbXBvbmVudHMvTW9kYWxEaWFncmFtYVVuaWZpbGFyJztcbmltcG9ydCBTZWxlY3RvckFsaW1lbnRhZG9ySmVyYXJxdWljbyBmcm9tICcuLi9jb21wb25lbnRzL1NlbGVjdG9yQWxpbWVudGFkb3JKZXJhcnF1aWNvJztcbmltcG9ydCBBdmFuY2VQcm9ncmVzc0JhciBmcm9tICcuLi9jb21wb25lbnRzL0F2YW5jZVByb2dyZXNzQmFyJztcbmltcG9ydCBFbGVtZW50b0NhcmRBY3Rpb25zIGZyb20gJy4uL2NvbXBvbmVudHMvRWxlbWVudG9DYXJkQWN0aW9ucyc7XG5pbXBvcnQgeyBcbiAgVEVOU0lPTkVTX0NPVkVOSU5fMTU5X0JULCBcbiAgVEVOU0lPTkVTX0NPVkVOSU5fMTU5X01ULCBcbiAgVEVOU0lPTkVTX0NPVkVOSU5fVE9EQVMgXG59IGZyb20gJy4uL3V0aWxzL2NvbnN0YW50cyc7XG5pbXBvcnQgeyBcbiAgQXJyb3dMZWZ0LCBcbiAgTGF5ZXJzLCBcbiAgVHJhc2gyLCBcbiAgU2VhcmNoLCBcbiAgQWxlcnRUcmlhbmdsZSxcbiAgWCxcbiAgQ2FtZXJhLFxuICBDYWxlbmRhcixcbiAgVXNlcixcbiAgWmFwLFxuICBCdWlsZGluZyxcbiAgR2F1Z2UsXG4gIENwdSxcbiAgU2hpZWxkQWxlcnQsXG4gIFJlZnJlc2hDdyxcbiAgRmlsZVRleHQsXG4gIENoZWNrU3F1YXJlLFxuICBTZXR0aW5ncyxcbiAgSGVscENpcmNsZSxcbiAgUGx1c1xufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IEhlbHBNb2RhbCBmcm9tICcuLi9jb21wb25lbnRzL0hlbHBNb2RhbCc7XG5cbi8vIENvbXBvbmVudGUgcGFyYSByZW5kZXJpemFyIEJsb2JzIGRlIGZvcm1hIHNlZ3VyYSBldml0YW5kbyBmdWdhcyBkZSBtZW1vcmlhXG5jb25zdCBTYWZlSW1hZ2UgPSAoeyBibG9iLCBzcmMsIGFsdCwgY2xhc3NOYW1lIH0pID0+IHtcbiAgY29uc3QgW29iamVjdFVybCwgc2V0T2JqZWN0VXJsXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGJsb2IpIHtcbiAgICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgICBzZXRPYmplY3RVcmwodXJsKTtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbiAgICAgIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldE9iamVjdFVybChudWxsKTtcbiAgICB9XG4gIH0sIFtibG9iXSk7XG5cbiAgY29uc3QgZmluYWxTcmMgPSBvYmplY3RVcmwgfHwgc3JjO1xuICBpZiAoIWZpbmFsU3JjKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gPGltZyBzcmM9e2ZpbmFsU3JjfSBhbHQ9e2FsdH0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IC8+O1xufTtcblxuZXhwb3J0IGNvbnN0IFByb3llY3RvVmlldyA9ICgpID0+IHtcbiAgY29uc3QgeyBjb21wYW55SWQsIHByb3llY3RvSWQgfSA9IHVzZVBhcmFtcygpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIFxuICBjb25zdCB7IFxuICAgIHVzZXIsXG4gICAgY29tcGFuaWVzLCBcbiAgICBhZGRFbGVtZW50b1VuaWZpbGFyLCBcbiAgICBkZWxldGVFbGVtZW50b1VuaWZpbGFyLFxuICAgIHVwZGF0ZUVsZW1lbnRvVW5pZmlsYXIsXG4gICAgYWRkSW5zcGVjY2lvblN1YmVzdGFjaW9uLFxuICAgIGRlbGV0ZVN1YmVzdGFjaW9uLFxuICAgIGFkZFB1bnRvTWVkaWNpb24sXG4gICAgZGVsZXRlUHVudG9NZWRpY2lvbixcbiAgICB1cGRhdGVQdW50b01lZGljaW9uLFxuICAgIGFkZENjbSxcbiAgICBkZWxldGVDY20sXG4gICAgdXBkYXRlQ2NtLFxuICAgIHVwZGF0ZVByb3llY3RvLFxuICAgIHNob3dUb2FzdFxuICB9ID0gdXNlU3RvcmUoKTtcblxuICBjb25zdCBjb21wYW55ID0gY29tcGFuaWVzLmZpbmQoKGMpID0+IGMuaWQgPT09IGNvbXBhbnlJZCk7XG4gIGNvbnN0IHByb3llY3RvID0gY29tcGFueT8ucHJveWVjdG9zPy5maW5kKChwKSA9PiBwLmlkID09PSBwcm95ZWN0b0lkKTtcblxuICBjb25zdCB7IGNvbmZpcm0sIGFsZXJ0OiBjdXN0b21BbGVydCB9ID0gdXNlQ29uZmlybSgpO1xuXG4gIC8vIEVzdGFkb3MgcGFyYSBFZGljacOzbiBkZSBQcm95ZWN0b1xuICBjb25zdCBbc2hvd0VkaXRQcm95ZWN0b01vZGFsLCBzZXRTaG93RWRpdFByb3llY3RvTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZWRpdFByb3llY3RvTm9tYnJlLCBzZXRFZGl0UHJveWVjdG9Ob21icmVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZWRpdFByb3llY3RvRGVzY3JpcGNpb24sIHNldEVkaXRQcm95ZWN0b0Rlc2NyaXBjaW9uXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2VkaXRQcm95ZWN0b0RpcmVjY2lvbiwgc2V0RWRpdFByb3llY3RvRGlyZWNjaW9uXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2VkaXRSZXNwb25zYWJsZU5vbWJyZSwgc2V0RWRpdFJlc3BvbnNhYmxlTm9tYnJlXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2VkaXRSZXNwb25zYWJsZVRlbGVmb25vLCBzZXRFZGl0UmVzcG9uc2FibGVUZWxlZm9ub10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtlZGl0UmVzcG9uc2FibGVFbWFpbCwgc2V0RWRpdFJlc3BvbnNhYmxlRW1haWxdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZVByb3llY3RvU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFlZGl0UHJveWVjdG9Ob21icmUudHJpbSgpKSByZXR1cm47XG5cbiAgICB1cGRhdGVQcm95ZWN0byhjb21wYW55SWQsIHByb3llY3RvSWQsIHtcbiAgICAgIG5vbWJyZTogZWRpdFByb3llY3RvTm9tYnJlLnRyaW0oKSxcbiAgICAgIGRlc2NyaXBjaW9uOiBlZGl0UHJveWVjdG9EZXNjcmlwY2lvbi50cmltKCksXG4gICAgICBkaXJlY2Npb246IGVkaXRQcm95ZWN0b0RpcmVjY2lvbi50cmltKCksXG4gICAgICByZXNwb25zYWJsZToge1xuICAgICAgICBub21icmU6IGVkaXRSZXNwb25zYWJsZU5vbWJyZS50cmltKCksXG4gICAgICAgIHRlbGVmb25vOiBlZGl0UmVzcG9uc2FibGVUZWxlZm9uby50cmltKCksXG4gICAgICAgIGVtYWlsOiBlZGl0UmVzcG9uc2FibGVFbWFpbC50cmltKClcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHNldFNob3dFZGl0UHJveWVjdG9Nb2RhbChmYWxzZSk7XG4gICAgc2hvd1RvYXN0Py4oXCJJbmZvcm1hY2nDs24gZGVsIHByb3llY3RvIGFjdHVhbGl6YWRhLlwiLCBcInN1Y2Nlc3NcIik7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlT3BlbkVkaXRNb2RhbCA9ICgpID0+IHtcbiAgICBzZXRFZGl0UHJveWVjdG9Ob21icmUocHJveWVjdG8/Lm5vbWJyZSB8fCAnJyk7XG4gICAgc2V0RWRpdFByb3llY3RvRGVzY3JpcGNpb24ocHJveWVjdG8/LmRlc2NyaXBjaW9uIHx8ICcnKTtcbiAgICBzZXRFZGl0UHJveWVjdG9EaXJlY2Npb24ocHJveWVjdG8/LmRpcmVjY2lvbiB8fCAnJyk7XG4gICAgc2V0RWRpdFJlc3BvbnNhYmxlTm9tYnJlKHByb3llY3RvPy5yZXNwb25zYWJsZT8ubm9tYnJlIHx8ICcnKTtcbiAgICBzZXRFZGl0UmVzcG9uc2FibGVUZWxlZm9ubyhwcm95ZWN0bz8ucmVzcG9uc2FibGU/LnRlbGVmb25vIHx8ICcnKTtcbiAgICBzZXRFZGl0UmVzcG9uc2FibGVFbWFpbChwcm95ZWN0bz8ucmVzcG9uc2FibGU/LmVtYWlsIHx8ICcnKTtcbiAgICBzZXRTaG93RWRpdFByb3llY3RvTW9kYWwodHJ1ZSk7XG4gIH07XG5cbiAgLy8gRXN0YWRvcyBkZSBwZXN0YcOxYSBhY3RpdmFcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKCdVTklGSUxBUicpOyAvLyAnVU5JRklMQVInIHwgJ0VTVFJVQ1RVUkFMJ1xuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBFc3RhZG9zIGRlIHNlbGVjY2nDs24gbcO6bHRpcGxlXG4gIGNvbnN0IFtpc011bHRpU2VsZWN0TW9kZSwgc2V0SXNNdWx0aVNlbGVjdE1vZGVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2VsZWN0ZWRJZHMsIHNldFNlbGVjdGVkSWRzXSA9IHVzZVN0YXRlKG5ldyBTZXQoKSk7XG5cbiAgLy8gTGltcGlhciBzZWxlY2Npw7NuIGN1YW5kbyBjYW1iaWEgbGEgcGVzdGHDsWEgbyBsYSBiw7pzcXVlZGFcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRTZWxlY3RlZElkcyhuZXcgU2V0KCkpO1xuICB9LCBbYWN0aXZlVGFiLCBzZWFyY2hRdWVyeV0pO1xuXG4gIGNvbnN0IGhhbmRsZVRvZ2dsZVNlbGVjdCA9IChpZCkgPT4ge1xuICAgIHNldFNlbGVjdGVkSWRzKChwcmV2KSA9PiB7XG4gICAgICBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2KTtcbiAgICAgIGlmIChuZXh0LmhhcyhpZCkpIHtcbiAgICAgICAgbmV4dC5kZWxldGUoaWQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmV4dC5hZGQoaWQpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG5leHQ7XG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2VsZWN0QWxsID0gKGl0ZW1zKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRJZHMobmV3IFNldChpdGVtcy5tYXAoKGkpID0+IGkuaWQpKSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGVzZWxlY3RBbGwgPSAoKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRJZHMobmV3IFNldCgpKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEZWxldGVTZWxlY3RlZCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBzZWxlY3RlZENvdW50ID0gc2VsZWN0ZWRJZHMuc2l6ZTtcbiAgICBpZiAoc2VsZWN0ZWRDb3VudCA9PT0gMCkgcmV0dXJuO1xuXG4gICAgY29uc3QgY29uZmlybU1zZyA9IGFjdGl2ZVRhYiA9PT0gJ1VOSUZJTEFSJ1xuICAgICAgPyBgwr9Fc3TDoXMgc2VndXJvIGRlIHF1ZSBkZXNlYXMgZWxpbWluYXIgbG9zICR7c2VsZWN0ZWRDb3VudH0gZWxlbWVudG9zIHNlbGVjY2lvbmFkb3MgZGVsIERpYWdyYW1hIFVuaWZpbGFyP2BcbiAgICAgIDogYMK/RXN0w6FzIHNlZ3VybyBkZSBxdWUgZGVzZWFzIGVsaW1pbmFyIGxhcyAke3NlbGVjdGVkQ291bnR9IGZpY2hhcyBkZSBpbnNwZWNjacOzbiBzZWxlY2Npb25hZGFzP2A7XG5cbiAgICBjb25zdCBvayA9IGF3YWl0IGNvbmZpcm0oe1xuICAgICAgdGl0bGU6ICdFbGltaW5hciBlbGVtZW50b3Mgc2VsZWNjaW9uYWRvcycsXG4gICAgICBtZXNzYWdlOiBjb25maXJtTXNnLFxuICAgICAgdHlwZTogJ2RhbmdlcicsXG4gICAgICBjb25maXJtVGV4dDogJ0VsaW1pbmFyIHNlbGVjY2lvbmFkb3MnXG4gICAgfSk7XG5cbiAgICBpZiAob2spIHtcbiAgICAgIGlmIChhY3RpdmVUYWIgPT09ICdVTklGSUxBUicpIHtcbiAgICAgICAgc2VsZWN0ZWRJZHMuZm9yRWFjaCgoaWQpID0+IHtcbiAgICAgICAgICBkZWxldGVFbGVtZW50b1VuaWZpbGFyKHByb3llY3RvSWQsIGlkKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHNob3dUb2FzdD8uKGBTZSBlbGltaW5hcm9uICR7c2VsZWN0ZWRDb3VudH0gZWxlbWVudG9zIGNvcnJlY3RhbWVudGVgLCAnc3VjY2VzcycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2VsZWN0ZWRJZHMuZm9yRWFjaCgoaWQpID0+IHtcbiAgICAgICAgICBkZWxldGVTdWJlc3RhY2lvbihwcm95ZWN0b0lkLCBpZCk7XG4gICAgICAgIH0pO1xuICAgICAgICBzaG93VG9hc3Q/LihgU2UgZWxpbWluYXJvbiAke3NlbGVjdGVkQ291bnR9IGZpY2hhcyBkZSBpbnNwZWNjacOzbiBjb3JyZWN0YW1lbnRlYCwgJ3N1Y2Nlc3MnKTtcbiAgICAgIH1cbiAgICAgIHNldFNlbGVjdGVkSWRzKG5ldyBTZXQoKSk7XG4gICAgICBzZXRJc011bHRpU2VsZWN0TW9kZShmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIE1vZGFsZXNcbiAgY29uc3QgW3Nob3dFbGVtZW50b01vZGFsLCBzZXRTaG93RWxlbWVudG9Nb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzaG93SW5zcGVjY2lvbk1vZGFsLCBzZXRTaG93SW5zcGVjY2lvbk1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dQdW50b01lZGljaW9uTW9kYWwsIHNldFNob3dQdW50b01lZGljaW9uTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2hvd0NjbU1vZGFsLCBzZXRTaG93Q2NtTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIENhbXBvcyBkZSBQdW50byBkZSBNZWRpY2nDs25cbiAgY29uc3QgW3B1bnRvTWVkaWNpb25Ob21icmUsIHNldFB1bnRvTWVkaWNpb25Ob21icmVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcHVudG9NZWRpY2lvblVzdWFyaW8sIHNldFB1bnRvTWVkaWNpb25Vc3VhcmlvXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3B1bnRvTWVkaWNpb25OSUMsIHNldFB1bnRvTWVkaWNpb25OSUNdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcHVudG9NZWRpY2lvbk5pdmVsVGVuc2lvbiwgc2V0UHVudG9NZWRpY2lvbk5pdmVsVGVuc2lvbl0gPSB1c2VTdGF0ZSgnTWVkaWEgVGVuc2nDs24nKTtcblxuICAvLyBDYW1wb3MgZGUgQ0NNXG4gIGNvbnN0IFtjY21Ob21icmUsIHNldENjbU5vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjY21QbGFudGEsIHNldENjbVBsYW50YV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjY21BcmVhLCBzZXRDY21BcmVhXSA9IHVzZVN0YXRlKCcnKTtcblxuICBjb25zdCBoYW5kbGVDcmVhdGVDY21TdWJtaXQgPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIWNjbU5vbWJyZS50cmltKCkpIHtcbiAgICAgIHNob3dUb2FzdD8uKCdQb3IgZmF2b3IgaW5ncmVzYSBsYSBpZGVudGlmaWNhY2nDs24gbyB0YWcgZGVsIENDTS4nLCAnZXJyb3InKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgbm9tYnJlOiBjY21Ob21icmUsXG4gICAgICBwbGFudGFJbnN0YWxhY2lvbjogY2NtUGxhbnRhLFxuICAgICAgYXJlYVByb2Nlc286IGNjbUFyZWEsXG4gICAgICBmZWNoYTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gICAgICBpbnNwZWN0b3I6IHVzZXI/Lm5vbWJyZSB8fCB1c2VyPy51c2VybmFtZSB8fCAnSW5zcGVjdG9yJyxcbiAgICAgIHN1cGVydmlzb3I6ICcnLFxuICAgICAgcGFyYW1ldHJvc0VsZWN0cmljb3M6IHt9LFxuICAgICAgZ2F2ZXRhc0J1Y2tldExvZzogW10sXG4gICAgICBpbnNwZWNjaW9uRmlzaWNhOiB7fSxcbiAgICAgIHNlZ3VyaWRhZFRlcm1vZ3JhZmlhOiB7fSxcbiAgICAgIGhhbGxhemdvc0NyaXRpY29zOiBbXVxuICAgIH07XG5cbiAgICBjb25zdCByZXN1bHQgPSBhZGRDY20ocHJveWVjdG9JZCwgcGF5bG9hZCk7XG4gICAgaWYgKHJlc3VsdC5zdWNjZXNzKSB7XG4gICAgICBzaG93VG9hc3Q/LignQ2VudHJvIGRlIENvbnRyb2wgZGUgTW90b3JlcyAoQ0NNKSBjcmVhZG8gZXhpdG9zYW1lbnRlJywgJ3N1Y2Nlc3MnKTtcbiAgICAgIHNldFNob3dDY21Nb2RhbChmYWxzZSk7XG4gICAgICBzZXRDY21Ob21icmUoJycpO1xuICAgICAgc2V0Q2NtUGxhbnRhKCcnKTtcbiAgICAgIHNldENjbUFyZWEoJycpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzaG93VG9hc3Q/LihyZXN1bHQuZXJyb3IgfHwgJ0Vycm9yIGFsIGNyZWFyIGVsIENDTScsICdlcnJvcicpO1xuICAgIH1cbiAgfTtcblxuICAvLyBFc3RhZG8gcGFyYSBlZGljacOzbiBkZSBlbGVtZW50b3NcbiAgY29uc3QgW2VkaXRpbmdFbGVtZW50bywgc2V0RWRpdGluZ0VsZW1lbnRvXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIC8vIEVmZWN0byBwYXJhIHJlbGxlbmFyIGNhbXBvcyBlbiBjYXNvIGRlIGVkaWNpw7NuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGVkaXRpbmdFbGVtZW50bykge1xuICAgICAgc2V0Tm9tYnJlKGVkaXRpbmdFbGVtZW50by5ub21icmUgfHwgJycpO1xuICAgICAgc2V0VWJpY2FjaW9uKGVkaXRpbmdFbGVtZW50by51YmljYWNpb24gfHwgJycpO1xuICAgICAgc2V0QWxpbWVudGFkb1BvcihlZGl0aW5nRWxlbWVudG8uYWxpbWVudGFkb1BvciB8fCAnJyk7XG4gICAgICBzZXRPYnNlcnZhY2lvbmVzR2VuZXJhbGVzKGVkaXRpbmdFbGVtZW50by5vYnNlcnZhY2lvbmVzR2VuZXJhbGVzIHx8ICcnKTtcbiAgICAgIHNldFRpcG9FbGVtZW50byhlZGl0aW5nRWxlbWVudG8udGlwb0VsZW1lbnRvIHx8ICdUQUJMRVJPJyk7XG4gICAgICBcbiAgICAgIGNvbnN0IHRlY2ggPSBlZGl0aW5nRWxlbWVudG8uZGF0b3NUZWNuaWNvcyB8fCB7fTtcbiAgICAgIGlmIChlZGl0aW5nRWxlbWVudG8udGlwb0VsZW1lbnRvID09PSAnVEFCTEVSTycpIHtcbiAgICAgICAgc2V0TWF4UG9sZXModGVjaC5tYXhQb2xlcyB8fCAyNCk7XG4gICAgICB9IGVsc2UgaWYgKGVkaXRpbmdFbGVtZW50by50aXBvRWxlbWVudG8gPT09ICdUUkFOU0ZPUk1BRE9SJykge1xuICAgICAgICBzZXRLdmFUcmFmbyh0ZWNoLmt2YSB8fCB0ZWNoLnBvdGVuY2lhS3ZhIHx8ICcnKTtcbiAgICAgICAgc2V0TWFyY2FUcmFmbyh0ZWNoLm1hcmNhIHx8ICcnKTtcbiAgICAgICAgc2V0VGlwb1RyYWZvKHRlY2gudGlwb1RyYW5zZm9ybWFkb3IgfHwgJ1BlZGVzdGFsJyk7XG4gICAgICAgIHNldENvbmV4aW9uVHJhZm8odGVjaC5jb25leGlvbiB8fCAnJyk7XG4gICAgICAgIHNldFZvbHRhamVQcmltYXJpbyh0ZWNoLnZvbHRhamVQcmltYXJpbyB8fCB0ZWNoLnRlbnNpb25QcmltYXJpYSB8fCAnJyk7XG4gICAgICAgIHNldFZvbHRhamVTZWN1bmRhcmlvKHRlY2gudm9sdGFqZVNlY3VuZGFyaW8gfHwgdGVjaC50ZW5zaW9uU2VjdW5kYXJpYSB8fCAnJyk7XG4gICAgICB9IGVsc2UgaWYgKGVkaXRpbmdFbGVtZW50by50aXBvRWxlbWVudG8gPT09ICdHRU5FUkFET1InKSB7XG4gICAgICAgIHNldEt2YUdlbih0ZWNoLmt2YSB8fCAnJyk7XG4gICAgICAgIHNldENvbWJ1c3RpYmxlR2VuKHRlY2guY29tYnVzdGlibGUgfHwgdGVjaC50aXBvQ29tYnVzdGlibGUgfHwgJ0RJRVNFTCcpO1xuICAgICAgICBzZXRWb2x0YWplR2VuKHRlY2gudm9sdGFqZUdlbmVyYWNpb24gfHwgJycpO1xuICAgICAgICBzZXRQb3RlbmNpYUt3R2VuKHRlY2gucG90ZW5jaWFLdyB8fCB0ZWNoLmt3IHx8ICcnKTtcbiAgICAgICAgc2V0QW1wZXJhamVHZW4odGVjaC5hbXBlcmFqZSB8fCAnJyk7XG4gICAgICB9IGVsc2UgaWYgKGVkaXRpbmdFbGVtZW50by50aXBvRWxlbWVudG8gPT09ICdQVUVTVEFfVElFUlJBJykge1xuICAgICAgICBzZXRSZXNpc3RlbmNpYU9obWlvcyh0ZWNoLnJlc2lzdGVuY2lhT2htaW9zIHx8ICcnKTtcbiAgICAgICAgc2V0Q29ycmllbnRlRnVnYSh0ZWNoLmNvcnJpZW50ZUZ1Z2FBbXBlcmlvcyB8fCAnJyk7XG4gICAgICAgIHNldFRpcG9NYWxsYSh0ZWNoLnRpcG9NYWxsYSB8fCAnJyk7XG4gICAgICAgIHNldENhYmxlQWNvbWV0aWRhVGllcnJhKHRlY2guY2FibGVBY29tZXRpZGEgfHwgJycpO1xuICAgICAgfSBlbHNlIGlmIChlZGl0aW5nRWxlbWVudG8udGlwb0VsZW1lbnRvID09PSAnVFJBTlNGRVInKSB7XG4gICAgICAgIHNldENhcGFjaWRhZEFtcGVyaW9zKHRlY2guY2FwYWNpZGFkQW1wZXJpb3MgfHwgJycpO1xuICAgICAgICBzZXRUaXBvVHJhbnNmZXJlbmNpYSh0ZWNoLnRpcG9UcmFuc2ZlcmVuY2lhIHx8ICdBVVRPTUFUSUNBJyk7XG4gICAgICAgIHNldFRlbnNpb25PcGVyYXRpdmEodGVjaC50ZW5zaW9uT3BlcmF0aXZhIHx8ICcnKTtcbiAgICAgIH0gZWxzZSBpZiAoZWRpdGluZ0VsZW1lbnRvLnRpcG9FbGVtZW50byA9PT0gJ0JBTkNPX0NPTkRFTlNBRE9SJykge1xuICAgICAgICBzZXRLdmFyVG90YWwodGVjaC5wb3RlbmNpYVJlYWN0aXZhVG90YWwgfHwgdGVjaC5rdmFyVG90YWwgfHwgJycpO1xuICAgICAgICBzZXRQYXNvc0NvbmRlbnNhZG9yKHRlY2gubnVtUGFzb3MgfHwgdGVjaC5wYXNvc0NvbmRlbnNhZG9yIHx8ICcnKTtcbiAgICAgICAgc2V0VGlwb0JhbmNvKHRlY2gudGlwb0NvbXBlbnNhY2lvbiA9PT0gJ0ZpamEnID8gJ0ZJSk8nIDogJ0FVVE9NQVRJQ08nKTtcbiAgICAgICAgc2V0VGVuc2lvbkJhbmNvKHRlY2gudGVuc2lvbk5vbWluYWwgfHwgdGVjaC50ZW5zaW9uQmFuY28gfHwgJycpO1xuICAgICAgfSBlbHNlIGlmIChlZGl0aW5nRWxlbWVudG8udGlwb0VsZW1lbnRvID09PSAnUFVOVE9fU1VNSU5JU1RSTycpIHtcbiAgICAgICAgc2V0U3VtaW5pc3Ryb1RlbnNpb24odGVjaC5uaXZlbFRlbnNpb24gfHwgdGVjaC50ZW5zaW9uTm9taW5hbCB8fCAnJyk7XG4gICAgICAgIHNldFN1bWluaXN0cm9FbXByZXNhKHRlY2guZW1wcmVzYURpc3RyaWJ1aWRvcmEgfHwgJ0NPUlBPRUxFQycpO1xuICAgICAgICBzZXRTdW1pbmlzdHJvVGlwb0Fjb21ldGlkYSh0ZWNoLnRpcG9BY29tZXRpZGEgfHwgJ1N1YnRlcnLDoW5lYScpO1xuICAgICAgICBzZXRTdW1pbmlzdHJvQ2FwYWNpZGFkKHRlY2guY2FwYWNpZGFkQ29udHJhdGFkYUt2YSB8fCB0ZWNoLmNhcmdhQ29udHJhdGFkYUt2YSB8fCB0ZWNoLmNhcGFjaWRhZEt2YSB8fCAnJyk7XG4gICAgICAgIHNldFN1bWluaXN0cm9UaXBvTWVkaWNpb24odGVjaC50aXBvTWVkaWNpb24gfHwgJ01lZGljacOzbiBEaXJlY3RhIChCYWphIFRlbnNpw7NuKScpO1xuICAgICAgICBzZXRTdW1pbmlzdHJvRW5sYWNlQ29ycG9lbGVjKHRlY2guZW5sYWNlQ29ycG9lbGVjICE9PSB1bmRlZmluZWQgPyB0ZWNoLmVubGFjZUNvcnBvZWxlYyA6IHRydWUpO1xuICAgICAgICBzZXRTdW1pbmlzdHJvTnVtZXJvQ29udHJhdG8odGVjaC5udW1lcm9Db250cmF0byB8fCB0ZWNoLmNvbnRyYXRvIHx8ICcnKTtcbiAgICAgICAgc2V0U3VtaW5pc3Ryb05pYyh0ZWNoLm5pYyB8fCB0ZWNoLm51bWVyb01lZGlkb3IgfHwgJycpO1xuICAgICAgICBzZXRTdW1pbmlzdHJvUG9zdGVUcmFmbyh0ZWNoLnBvc3RlVHJhbnNmb3JtYWRvciB8fCB0ZWNoLnBvc3RlVHJhZm8gfHwgJycpO1xuICAgICAgfSBlbHNlIGlmIChlZGl0aW5nRWxlbWVudG8udGlwb0VsZW1lbnRvID09PSAnQ0NNJykge1xuICAgICAgICBzZXRDY21DYXBhY2lkYWRCYXJyYSh0ZWNoLmNhcGFjaWRhZEJhcnJhQW1wZXJpb3MgfHwgJycpO1xuICAgICAgICBzZXRDY21UZW5zaW9uKHRlY2gudGVuc2lvbk9wZXJhdGl2YSB8fCAnJyk7XG4gICAgICAgIHNldENjbUJyZWFrZXJQcmluY2lwYWwodGVjaC5icmVha2VyUHJpbmNpcGFsIHx8ICcnKTtcbiAgICAgICAgc2V0Q2NtTnVtZXJvR2F2ZXRhcyh0ZWNoLm51bWVyb0dhdmV0YXMgfHwgOCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXREZXNjcmlwY2lvbk90cm8odGVjaC5kZXNjcmlwY2lvbkVzcGVjaWZpY2FjaW9uZXMgfHwgJycpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzZXROb21icmUoJycpO1xuICAgICAgc2V0VWJpY2FjaW9uKCcnKTtcbiAgICAgIHNldEFsaW1lbnRhZG9Qb3IoJycpO1xuICAgICAgc2V0T2JzZXJ2YWNpb25lc0dlbmVyYWxlcygnJyk7XG4gICAgICBzZXRUaXBvRWxlbWVudG8oJ1RBQkxFUk8nKTtcbiAgICAgIHNldE1heFBvbGVzKDI0KTtcbiAgICAgIHNldEt2YVRyYWZvKCcnKTtcbiAgICAgIHNldE1hcmNhVHJhZm8oJycpO1xuICAgICAgc2V0Q29uZXhpb25UcmFmbygnJyk7XG4gICAgICBzZXRWb2x0YWplUHJpbWFyaW8oJycpO1xuICAgICAgc2V0Vm9sdGFqZVNlY3VuZGFyaW8oJycpO1xuICAgICAgc2V0S3ZhR2VuKCcnKTtcbiAgICAgIHNldFZvbHRhamVHZW4oJycpO1xuICAgICAgc2V0UG90ZW5jaWFLd0dlbignJyk7XG4gICAgICBzZXRBbXBlcmFqZUdlbignJyk7XG4gICAgICBzZXRSZXNpc3RlbmNpYU9obWlvcygnJyk7XG4gICAgICBzZXRDb3JyaWVudGVGdWdhKCcnKTtcbiAgICAgIHNldFRpcG9NYWxsYSgnJyk7XG4gICAgICBzZXRDYWJsZUFjb21ldGlkYVRpZXJyYSgnJyk7XG4gICAgICBzZXRDYXBhY2lkYWRBbXBlcmlvcygnJyk7XG4gICAgICBzZXRUZW5zaW9uT3BlcmF0aXZhKCcnKTtcbiAgICAgIHNldEt2YXJUb3RhbCgnJyk7XG4gICAgICBzZXRQYXNvc0NvbmRlbnNhZG9yKCcnKTtcbiAgICAgIHNldFRlbnNpb25CYW5jbygnJyk7XG4gICAgICBzZXRTdW1pbmlzdHJvVGVuc2lvbignJyk7XG4gICAgICBzZXRTdW1pbmlzdHJvRW1wcmVzYSgnQ09SUE9FTEVDJyk7XG4gICAgICBzZXRTdW1pbmlzdHJvVGlwb0Fjb21ldGlkYSgnU3VidGVycsOhbmVhJyk7XG4gICAgICBzZXRTdW1pbmlzdHJvQ2FwYWNpZGFkKCcnKTtcbiAgICAgIHNldFN1bWluaXN0cm9UaXBvTWVkaWNpb24oJ01lZGljacOzbiBEaXJlY3RhIChCYWphIFRlbnNpw7NuKScpO1xuICAgICAgc2V0U3VtaW5pc3Ryb0VubGFjZUNvcnBvZWxlYyh0cnVlKTtcbiAgICAgIHNldFN1bWluaXN0cm9OdW1lcm9Db250cmF0bygnJyk7XG4gICAgICBzZXRTdW1pbmlzdHJvTmljKCcnKTtcbiAgICAgIHNldFN1bWluaXN0cm9Qb3N0ZVRyYWZvKCcnKTtcbiAgICAgIHNldENjbUNhcGFjaWRhZEJhcnJhKCcnKTtcbiAgICAgIHNldENjbVRlbnNpb24oJycpO1xuICAgICAgc2V0Q2NtQnJlYWtlclByaW5jaXBhbCgnJyk7XG4gICAgICBzZXREZXNjcmlwY2lvbk90cm8oJycpO1xuICAgIH1cbiAgfSwgW2VkaXRpbmdFbGVtZW50b10pO1xuXG4gIGNvbnN0IFtzaG93RGlhZ3JhbU1vZGFsLCBzZXRTaG93RGlhZ3JhbU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dIZWxwTW9kYWwsIHNldFNob3dIZWxwTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIFNlbGVjdG9yIGRlIHBsYW50aWxsYSAvIHRpcG8gZGUgZWxlbWVudG9cbiAgY29uc3QgW3RpcG9FbGVtZW50bywgc2V0VGlwb0VsZW1lbnRvXSA9IHVzZVN0YXRlKCdUQUJMRVJPJyk7IC8vICdUQUJMRVJPJyB8ICdUUkFOU0ZPUk1BRE9SJyB8ICdHRU5FUkFET1InIHwgJ1BVRVNUQV9USUVSUkEnIHwgJ1RSQU5TRkVSJyB8ICdQVU5UT19TVU1JTklTVFJPJyB8ICdDQ00nIHwgJ0JBTkNPX0NPTkRFTlNBRE9SJyB8ICdPVFJPJ1xuXG4gIC8vIENhbXBvcyBjb211bmVzXG4gIGNvbnN0IFtub21icmUsIHNldE5vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFt1YmljYWNpb24sIHNldFViaWNhY2lvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFthbGltZW50YWRvUG9yLCBzZXRBbGltZW50YWRvUG9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW29ic2VydmFjaW9uZXNHZW5lcmFsZXMsIHNldE9ic2VydmFjaW9uZXNHZW5lcmFsZXNdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZm90b0Jsb2IsIHNldEZvdG9CbG9iXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbcHJldmlld1VybCwgc2V0UHJldmlld1VybF0gPSB1c2VTdGF0ZShudWxsKTtcblxuICAvLyBDYW1wb3MgZGUgVGFibGVyb1xuICBjb25zdCBbbWF4UG9sZXMsIHNldE1heFBvbGVzXSA9IHVzZVN0YXRlKDI0KTtcblxuICAvLyBDYW1wb3MgZGUgVHJhbnNmb3JtYWRvclxuICBjb25zdCBba3ZhVHJhZm8sIHNldEt2YVRyYWZvXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW21hcmNhVHJhZm8sIHNldE1hcmNhVHJhZm9dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbdGlwb1RyYWZvLCBzZXRUaXBvVHJhZm9dID0gdXNlU3RhdGUoJ1BlZGVzdGFsJyk7IC8vICdQZWRlc3RhbCcgfCAnU2VjbycgfCAnUG9zdGUnXG4gIGNvbnN0IFtjb25leGlvblRyYWZvLCBzZXRDb25leGlvblRyYWZvXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3ZvbHRhamVQcmltYXJpbywgc2V0Vm9sdGFqZVByaW1hcmlvXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3ZvbHRhamVTZWN1bmRhcmlvLCBzZXRWb2x0YWplU2VjdW5kYXJpb10gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gQ2FtcG9zIGRlIEdlbmVyYWRvclxuICBjb25zdCBba3ZhR2VuLCBzZXRLdmFHZW5dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbY29tYnVzdGlibGVHZW4sIHNldENvbWJ1c3RpYmxlR2VuXSA9IHVzZVN0YXRlKCdESUVTRUwnKTtcbiAgY29uc3QgW3ZvbHRhamVHZW4sIHNldFZvbHRhamVHZW5dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcG90ZW5jaWFLd0dlbiwgc2V0UG90ZW5jaWFLd0dlbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFthbXBlcmFqZUdlbiwgc2V0QW1wZXJhamVHZW5dID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIENhbXBvcyBkZSBQdWVzdGEgYSBUaWVycmFcbiAgY29uc3QgW3Jlc2lzdGVuY2lhT2htaW9zLCBzZXRSZXNpc3RlbmNpYU9obWlvc10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjb3JyaWVudGVGdWdhLCBzZXRDb3JyaWVudGVGdWdhXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3RpcG9NYWxsYSwgc2V0VGlwb01hbGxhXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2NhYmxlQWNvbWV0aWRhVGllcnJhLCBzZXRDYWJsZUFjb21ldGlkYVRpZXJyYV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gQ2FtcG9zIGRlIFRyYW5zZmVyXG4gIGNvbnN0IFtjYXBhY2lkYWRBbXBlcmlvcywgc2V0Q2FwYWNpZGFkQW1wZXJpb3NdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbdGlwb1RyYW5zZmVyZW5jaWEsIHNldFRpcG9UcmFuc2ZlcmVuY2lhXSA9IHVzZVN0YXRlKCdBVVRPTUFUSUNBJyk7XG4gIGNvbnN0IFt0ZW5zaW9uT3BlcmF0aXZhLCBzZXRUZW5zaW9uT3BlcmF0aXZhXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBDYW1wb3MgZGUgQmFuY28gZGUgQ29uZGVuc2Fkb3Jlc1xuICBjb25zdCBba3ZhclRvdGFsLCBzZXRLdmFyVG90YWxdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGFzb3NDb25kZW5zYWRvciwgc2V0UGFzb3NDb25kZW5zYWRvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFt0aXBvQmFuY28sIHNldFRpcG9CYW5jb10gPSB1c2VTdGF0ZSgnQVVUT01BVElDTycpO1xuICBjb25zdCBbdGVuc2lvbkJhbmNvLCBzZXRUZW5zaW9uQmFuY29dID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIENhbXBvcyBkZSBQdW50byBkZSBTdW1pbmlzdHJvXG4gIGNvbnN0IFtzdW1pbmlzdHJvVGVuc2lvbiwgc2V0U3VtaW5pc3Ryb1RlbnNpb25dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc3VtaW5pc3Ryb0VtcHJlc2EsIHNldFN1bWluaXN0cm9FbXByZXNhXSA9IHVzZVN0YXRlKCdDT1JQT0VMRUMnKTtcbiAgY29uc3QgW3N1bWluaXN0cm9UaXBvQWNvbWV0aWRhLCBzZXRTdW1pbmlzdHJvVGlwb0Fjb21ldGlkYV0gPSB1c2VTdGF0ZSgnU3VidGVycsOhbmVhJyk7XG4gIGNvbnN0IFtzdW1pbmlzdHJvQ2FwYWNpZGFkLCBzZXRTdW1pbmlzdHJvQ2FwYWNpZGFkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3N1bWluaXN0cm9UaXBvTWVkaWNpb24sIHNldFN1bWluaXN0cm9UaXBvTWVkaWNpb25dID0gdXNlU3RhdGUoJ01lZGljacOzbiBEaXJlY3RhIChCYWphIFRlbnNpw7NuKScpO1xuICBjb25zdCBbc3VtaW5pc3Ryb0VubGFjZUNvcnBvZWxlYywgc2V0U3VtaW5pc3Ryb0VubGFjZUNvcnBvZWxlY10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW3N1bWluaXN0cm9OdW1lcm9Db250cmF0bywgc2V0U3VtaW5pc3Ryb051bWVyb0NvbnRyYXRvXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3N1bWluaXN0cm9OaWMsIHNldFN1bWluaXN0cm9OaWNdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc3VtaW5pc3Ryb1Bvc3RlVHJhZm8sIHNldFN1bWluaXN0cm9Qb3N0ZVRyYWZvXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBDYW1wb3MgZGUgQ0NNIEVsZW1lbnRvXG4gIGNvbnN0IFtjY21DYXBhY2lkYWRCYXJyYSwgc2V0Q2NtQ2FwYWNpZGFkQmFycmFdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbY2NtVGVuc2lvbiwgc2V0Q2NtVGVuc2lvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjY21CcmVha2VyUHJpbmNpcGFsLCBzZXRDY21CcmVha2VyUHJpbmNpcGFsXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2NjbU51bWVyb0dhdmV0YXMsIHNldENjbU51bWVyb0dhdmV0YXNdID0gdXNlU3RhdGUoOCk7XG5cbiAgLy8gQ2FtcG9zIGRlIE90cm9cbiAgY29uc3QgW2Rlc2NyaXBjaW9uT3Rybywgc2V0RGVzY3JpcGNpb25PdHJvXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBDYW1wb3MgZGUgSW5zcGVjY2lvbmVzIFNlcGFyYWRhcyAoQ2FwYSAyKVxuICBjb25zdCBbdGlwb0luc3BlY2Npb25Nb2RhbCwgc2V0VGlwb0luc3BlY2Npb25Nb2RhbF0gPSB1c2VTdGF0ZSgnQU1CSUVOVEFMX0ZJU0lDQScpOyAvLyAnQU1CSUVOVEFMX0ZJU0lDQScgfCAnVEVSTU9HUkFGSUNBJyB8ICdTSVNURU1BX0FURVJSQU1JRU5UTycgfCAnVEFOUVVFX0NPTUJVU1RJQkxFJ1xuXG4gIC8vIDEuIEFtYmllbnRhbCAvIEbDrXNpY2EgKFN1YmVzdGFjacOzbilcbiAgY29uc3QgW3N1YmVzdGFjaW9uTm9tYnJlLCBzZXRTdWJlc3RhY2lvbk5vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzdWJlc3RhY2lvblViaWNhY2lvbiwgc2V0U3ViZXN0YWNpb25VYmljYWNpb25dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbml2ZWxUZW5zaW9uLCBzZXROaXZlbFRlbnNpb25dID0gdXNlU3RhdGUoJzEzLjgga1YnKTtcbiAgY29uc3QgW2luc3BlY3Rvck5hbWUsIHNldEluc3BlY3Rvck5hbWVdID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIDIuIFRlcm1vZ3LDoWZpY2FcbiAgY29uc3QgW3Rlcm1vTm9tYnJlLCBzZXRUZXJtb05vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFt0ZXJtb1ViaWNhY2lvbiwgc2V0VGVybW9VYmljYWNpb25dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbdGVybW9UZW1wQW1iaWVudGUsIHNldFRlcm1vVGVtcEFtYmllbnRlXSA9IHVzZVN0YXRlKCcyNScpO1xuICBjb25zdCBbdGVybW9UZW1wUHVudG9DYWxpZW50ZSwgc2V0VGVybW9UZW1wUHVudG9DYWxpZW50ZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFt0ZXJtb1RlbXBSZWYsIHNldFRlcm1vVGVtcFJlZl0gPSB1c2VTdGF0ZSgnMzAnKTtcbiAgY29uc3QgW3Rlcm1vQ2FtYXJhLCBzZXRUZXJtb0NhbWFyYV0gPSB1c2VTdGF0ZSgnRkxJUiBFOC1YVCcpO1xuXG4gIC8vIDMuIFNpc3RlbWEgZGUgQXRlcnJhbWllbnRvIChQQVQpXG4gIGNvbnN0IFtwYXROb21icmUsIHNldFBhdE5vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwYXRVYmljYWNpb24sIHNldFBhdFViaWNhY2lvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwYXRSZXNpc3RlbmNpYSwgc2V0UGF0UmVzaXN0ZW5jaWFdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGF0TWV0b2RvLCBzZXRQYXRNZXRvZG9dID0gdXNlU3RhdGUoJ0Nhw61kYSBkZSBQb3RlbmNpYWwgKDYyJSknKTtcbiAgY29uc3QgW3BhdFRpcG8sIHNldFBhdFRpcG9dID0gdXNlU3RhdGUoJ01hbGxhIGNvbiBWYXJpbGxhcycpO1xuICBjb25zdCBbcGF0VW5pb24sIHNldFBhdFVuaW9uXSA9IHVzZVN0YXRlKCdTb2xkYWR1cmEgRXhvdMOpcm1pY2EgKENhZHdlbGQpJyk7XG4gIGNvbnN0IFtwYXRUZWx1cm9tZXRybywgc2V0UGF0VGVsdXJvbWV0cm9dID0gdXNlU3RhdGUoJ0FFTUMgNDYzMCcpO1xuXG4gIC8vIDQuIFRhbnF1ZSBkZSBDb21idXN0aWJsZVxuICBjb25zdCBbdGFucXVlTm9tYnJlLCBzZXRUYW5xdWVOb21icmVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbdGFucXVlVWJpY2FjaW9uLCBzZXRUYW5xdWVVYmljYWNpb25dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbdGFucXVlVGlwb0NvbWJ1c3RpYmxlLCBzZXRUYW5xdWVUaXBvQ29tYnVzdGlibGVdID0gdXNlU3RhdGUoJ0RJRVNFTCcpO1xuICBjb25zdCBbdGFucXVlQ2FwYWNpZGFkTGl0cm9zLCBzZXRUYW5xdWVDYXBhY2lkYWRMaXRyb3NdID0gdXNlU3RhdGUoJzIwMDAnKTtcbiAgY29uc3QgW3RhbnF1ZU5pdmVsUG9yY2VudGFqZSwgc2V0VGFucXVlTml2ZWxQb3JjZW50YWplXSA9IHVzZVN0YXRlKCc3NScpO1xuICBjb25zdCBbdGFucXVlQ29uc3Vtb0xoLCBzZXRUYW5xdWVDb25zdW1vTGhdID0gdXNlU3RhdGUoJzQ1Jyk7XG4gIGNvbnN0IFt0YW5xdWVEaXF1ZTExMCwgc2V0VGFucXVlRGlxdWUxMTBdID0gdXNlU3RhdGUoJ0NPTkZPUk1FJyk7XG5cbiAgaWYgKCFjb21wYW55IHx8ICFwcm95ZWN0bykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC02IHRleHQtY2VudGVyIHNwYWNlLXktNCBmb250LXNhbnNcIj5cbiAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtYW1iZXItNTAwIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGRcIj5Qcm95ZWN0byBvIEVtcHJlc2Egbm8gZW5jb250cmFkbzwvaDI+XG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9lbXByZXNhLyR7Y29tcGFueUlkIHx8ICcnfWApfSBcbiAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXhzIHJvdW5kZWQteGwgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZFwiXG4gICAgICAgID5cbiAgICAgICAgICBWb2x2ZXIgYSBsYSBFbXByZXNhXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0IGVsZW1lbnRvcyA9IHByb3llY3RvLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgcHJveWVjdG8udGFibGVyb3MgfHwgW107XG4gIGNvbnN0IGluc3BlY2Npb25lcyA9IHByb3llY3RvLmluc3BlY2Npb25lc1N1YmVzdGFjaW9uIHx8IHByb3llY3RvLnN1YmVzdGFjaW9uZXMgfHwgW107XG4gIGNvbnN0IHB1bnRvc01lZGljaW9uID0gcHJveWVjdG8ucHVudG9zTWVkaWNpb24gfHwgW107XG5cbiAgY29uc3QgZmlsdGVyZWRFbGVtZW50b3MgPSBlbGVtZW50b3MuZmlsdGVyKChpdGVtKSA9PlxuICAgIGl0ZW0ubm9tYnJlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkgfHxcbiAgICAoaXRlbS51YmljYWNpb24gJiYgaXRlbS51YmljYWNpb24udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSkgfHxcbiAgICBpdGVtLnRpcG9FbGVtZW50by50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpXG4gICk7XG5cbiAgY29uc3QgZmlsdGVyZWRJbnNwZWNjaW9uZXMgPSBpbnNwZWNjaW9uZXMuZmlsdGVyKChpdGVtKSA9PlxuICAgIGl0ZW0ubm9tYnJlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkgfHxcbiAgICAoaXRlbS51YmljYWNpb24gJiYgaXRlbS51YmljYWNpb24udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSkgfHxcbiAgICAoaXRlbS5pbnNwZWN0b3IgJiYgaXRlbS5pbnNwZWN0b3IudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSlcbiAgKTtcblxuICBjb25zdCBmaWx0ZXJlZFB1bnRvc01lZGljaW9uID0gcHVudG9zTWVkaWNpb24uZmlsdGVyKChpdGVtKSA9PlxuICAgIChpdGVtLm5vbWJyZSAmJiBpdGVtLm5vbWJyZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpKSB8fFxuICAgIChpdGVtLm5vbWJyZVVzdWFyaW8gJiYgaXRlbS5ub21icmVVc3VhcmlvLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkpIHx8XG4gICAgKGl0ZW0ubnVtZXJvQ29udHJhdG8gJiYgaXRlbS5udW1lcm9Db250cmF0by50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpKSB8fFxuICAgIChpdGVtLmNvZGlnb0VsZW1lbnRvUHJpbmNpcGFsICYmIGl0ZW0uY29kaWdvRWxlbWVudG9QcmluY2lwYWwudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSlcbiAgKTtcblxuICBjb25zdCBub21icmVFbGVtZW50b0R1cGxpY2FkbyA9IGVsZW1lbnRvcy5zb21lKFxuICAgIChlKSA9PiBlLm5vbWJyZS50b0xvd2VyQ2FzZSgpLnRyaW0oKSA9PT0gbm9tYnJlLnRvTG93ZXJDYXNlKCkudHJpbSgpICYmIGUuaWQgIT09IGVkaXRpbmdFbGVtZW50bz8uaWRcbiAgKTtcblxuICBjb25zdCBub21icmVJbnNwZWNjaW9uRHVwbGljYWRvID0gaW5zcGVjY2lvbmVzLnNvbWUoXG4gICAgKHMpID0+IHMubm9tYnJlLnRvTG93ZXJDYXNlKCkudHJpbSgpID09PSBzdWJlc3RhY2lvbk5vbWJyZS50b0xvd2VyQ2FzZSgpLnRyaW0oKVxuICApO1xuXG4gIGNvbnN0IGlzRWxlbWVudG9Gb3JtVmFsaWQgPSBub21icmUudHJpbSgpICE9PSAnJyAmJiAhbm9tYnJlRWxlbWVudG9EdXBsaWNhZG87XG5cbiAgY29uc3QgaXNJbnNwZWNjaW9uRm9ybVZhbGlkID0gXG4gICAgdGlwb0luc3BlY2Npb25Nb2RhbCA9PT0gJ0FNQklFTlRBTF9GSVNJQ0EnIHx8IHRpcG9JbnNwZWNjaW9uTW9kYWwgPT09ICdTVUJFU1RBQ0lPTidcbiAgICAgID8gKHN1YmVzdGFjaW9uTm9tYnJlLnRyaW0oKSAhPT0gJycgJiYgIW5vbWJyZUluc3BlY2Npb25EdXBsaWNhZG8pXG4gICAgICA6IHRpcG9JbnNwZWNjaW9uTW9kYWwgPT09ICdURVJNT0dSQUZJQ0EnXG4gICAgICAgID8gdGVybW9Ob21icmUudHJpbSgpICE9PSAnJ1xuICAgICAgICA6IHRpcG9JbnNwZWNjaW9uTW9kYWwgPT09ICdTSVNURU1BX0FURVJSQU1JRU5UTycgfHwgdGlwb0luc3BlY2Npb25Nb2RhbCA9PT0gJ1BVRVNUQV9USUVSUkEnXG4gICAgICAgICAgPyAocGF0Tm9tYnJlLnRyaW0oKSAhPT0gJycgfHwgc3ViZXN0YWNpb25Ob21icmUudHJpbSgpICE9PSAnJylcbiAgICAgICAgICA6IHRpcG9JbnNwZWNjaW9uTW9kYWwgPT09ICdUQU5RVUVfQ09NQlVTVElCTEUnXG4gICAgICAgICAgICA/IHRhbnF1ZU5vbWJyZS50cmltKCkgIT09ICcnXG4gICAgICAgICAgICA6IHRydWU7XG5cbiAgY29uc3QgaGFuZGxlSW1hZ2VDaGFuZ2UgPSAoZSkgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlc1swXTtcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcblxuICAgIGlmIChmaWxlLnNpemUgPiAxMCAqIDEwMjQgKiAxMDI0KSB7XG4gICAgICBjdXN0b21BbGVydChcIkxhIGltYWdlbiBlcyBkZW1hc2lhZG8gZ3JhbmRlLiBQb3IgZmF2b3IgZWxpamEgdW5hIGRlIG1lbm9zIGRlIDEwTUIuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldEZvdG9CbG9iKGZpbGUpO1xuICAgIGlmIChwcmV2aWV3VXJsKSBVUkwucmV2b2tlT2JqZWN0VVJMKHByZXZpZXdVcmwpO1xuICAgIHNldFByZXZpZXdVcmwoVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ3JlYXRlRWxlbWVudG8gPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIWlzRWxlbWVudG9Gb3JtVmFsaWQpIHJldHVybjtcblxuICAgIGxldCBkYXRvc1RlY25pY29zID0ge307XG5cbiAgICBpZiAodGlwb0VsZW1lbnRvID09PSAnVEFCTEVSTycpIHtcbiAgICAgIGRhdG9zVGVjbmljb3MgPSB7XG4gICAgICAgIG1heFBvbGVzOiBwYXJzZUludChtYXhQb2xlcywgMTApLFxuICAgICAgICBiYXJyYXNQcmluY2lwYWxlczogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5iYXJyYXNQcmluY2lwYWxlcyB8fCB7IGlhOiAnMCcsIGliOiAnMCcsIGljOiAnMCcgfSxcbiAgICAgICAgYnJlYWtlclByaW5jaXBhbDogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5icmVha2VyUHJpbmNpcGFsIHx8IHsgbWFyY2E6ICcnLCB0aXBvOiAnJywgYW1wOiAnJyB9LFxuICAgICAgICB2b2x0YWplOiBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LnZvbHRhamUgfHwgeyB2YTogJzIwOCcsIHZiOiAnMjA1JywgdmM6ICcyMDUnIH0sXG4gICAgICAgIGFjb21ldGlkYTogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5hY29tZXRpZGEgfHwgJycsXG4gICAgICAgIGNpcmN1aXRzOiBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LmNpcmN1aXRzIHx8IFtdLFxuICAgICAgICBuZXV0cm9MbGVnYWRhOiBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/Lm5ldXRyb0xsZWdhZGEgfHwgeyBjYWxpYnJlOiAnJywgb2JzZXJ2YWNpb25lczogJycgfSxcbiAgICAgICAgcHVlc3RhVGllcnJhOiBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LnB1ZXN0YVRpZXJyYSB8fCB7IGNhbGlicmU6ICcnLCBvYnNlcnZhY2lvbmVzOiAnJyB9XG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAodGlwb0VsZW1lbnRvID09PSAnVFJBTlNGT1JNQURPUicpIHtcbiAgICAgIGNvbnN0IGt2YU51bSA9IHBhcnNlRmxvYXQoU3RyaW5nKGt2YVRyYWZvIHx8IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8ua3ZhIHx8IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8ucG90ZW5jaWFLdmEgfHwgMCkucmVwbGFjZSgvW14wLTkuXS9nLCAnJykpIHx8IG51bGw7XG4gICAgICBjb25zdCBmcFRyYWZvID0gcGFyc2VGbG9hdChlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LmZhY3RvclBvdGVuY2lhIHx8IDAuOSkgfHwgMC45O1xuICAgICAgY29uc3Qga3ZhckNhbGMgPSBrdmFOdW0gPyBNYXRoLnJvdW5kKGt2YU51bSAqIE1hdGguc3FydChNYXRoLm1heCgwLCAxIC0gTWF0aC5wb3coZnBUcmFmbywgMikpKSAqIDEwMCkgLyAxMDAgOiBudWxsO1xuICAgICAgY29uc3Qgc2VjVm9sdHMgPSBwYXJzZUZsb2F0KFN0cmluZyh2b2x0YWplU2VjdW5kYXJpbyB8fCBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LnZvbHRhamVTZWN1bmRhcmlvIHx8ICcyMDgnKS5yZXBsYWNlKC9bXjAtOS5dL2csICcnKSkgfHwgMjA4O1xuICAgICAgY29uc3Qgc2VjQW1wcyA9IGt2YU51bSAmJiBzZWNWb2x0cyA+IDAgPyBNYXRoLnJvdW5kKCgoa3ZhTnVtICogMTAwMCkgLyAoTWF0aC5zcXJ0KDMpICogc2VjVm9sdHMpKSAqIDEwMCkgLyAxMDAgOiBudWxsO1xuXG4gICAgICBkYXRvc1RlY25pY29zID0ge1xuICAgICAgICBtYXJjYTogbWFyY2FUcmFmbyB8fCBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/Lm1hcmNhIHx8ICcnLFxuICAgICAgICBmYXNlczogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5mYXNlcyB8fCAnMycsXG4gICAgICAgIHBvdGVuY2lhS3ZhOiBrdmFUcmFmbyB8fCBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LnBvdGVuY2lhS3ZhIHx8ICcnLFxuICAgICAgICBrdmE6IGt2YU51bSB8fCBrdmFUcmFmbyB8fCAnJyxcbiAgICAgICAgY2FwRXg6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uY2FwRXggfHwga3ZhTnVtIHx8IG51bGwsXG4gICAgICAgIGNhcFJlOiBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LmNhcFJlIHx8IGt2YXJDYWxjIHx8IG51bGwsXG4gICAgICAgIGt2YXI6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8ua3ZhciB8fCBrdmFyQ2FsYyB8fCBudWxsLFxuICAgICAgICBmYWN0b3JQb3RlbmNpYTogZnBUcmFmbyxcbiAgICAgICAgY29ycmllbnRlTm9taW5hbEE6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uY29ycmllbnRlTm9taW5hbEEgfHwgc2VjQW1wcyxcbiAgICAgICAgY29ycmllbnRlTm9taW5hbEI6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uY29ycmllbnRlTm9taW5hbEIgfHwgc2VjQW1wcyxcbiAgICAgICAgY29ycmllbnRlTm9taW5hbEM6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uY29ycmllbnRlTm9taW5hbEMgfHwgc2VjQW1wcyxcbiAgICAgICAgY29ycmllbnRlU2VjdW5kYXJpYTogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5jb3JyaWVudGVTZWN1bmRhcmlhIHx8IHNlY0FtcHMsXG4gICAgICAgIHRpcG9UcmFuc2Zvcm1hZG9yOiB0aXBvVHJhZm8gfHwgZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy50aXBvVHJhbnNmb3JtYWRvciB8fCAnUGVkZXN0YWwnLFxuICAgICAgICBjb25leGlvbjogY29uZXhpb25UcmFmbyB8fCBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LmNvbmV4aW9uIHx8ICcnLFxuICAgICAgICB2b2x0YWplUHJpbWFyaW86IHZvbHRhamVQcmltYXJpbyB8fCBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LnZvbHRhamVQcmltYXJpbyB8fCAnJyxcbiAgICAgICAgdm9sdGFqZVNlY3VuZGFyaW86IHZvbHRhamVTZWN1bmRhcmlvIHx8IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8udm9sdGFqZVNlY3VuZGFyaW8gfHwgJycsXG4gICAgICAgIGltcGVkYW5jaWFQY3Q6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uaW1wZWRhbmNpYVBjdCB8fCAnJyxcbiAgICAgICAgaW1wZWRhbmNpYUFtcDogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5pbXBlZGFuY2lhQW1wIHx8ICcnLFxuICAgICAgICBpbXBlZGFuY2lhVGVtcDogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5pbXBlZGFuY2lhVGVtcCB8fCAnJyxcbiAgICAgICAgdGVuc2lvblByaW1hcmlhOiBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LnRlbnNpb25QcmltYXJpYSB8fCB2b2x0YWplUHJpbWFyaW8gfHwgJycsXG4gICAgICAgIGFtcGVyaW9zUHJpbWFyaWE6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uYW1wZXJpb3NQcmltYXJpYSB8fCAnJyxcbiAgICAgICAgdGVuc2lvblNlY3VuZGFyaWE6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8udGVuc2lvblNlY3VuZGFyaWEgfHwgdm9sdGFqZVNlY3VuZGFyaW8gfHwgJycsXG4gICAgICAgIGFtcGVyaW9zU2VjdW5kYXJpYTogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5hbXBlcmlvc1NlY3VuZGFyaWEgfHwgc2VjQW1wcyB8fCAnJyxcbiAgICAgICAgYWlzbGFtaWVudG86IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uYWlzbGFtaWVudG8gfHwgJycsXG4gICAgICAgIGFjZWl0ZTogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5hY2VpdGUgfHwgJycsXG4gICAgICAgIHNlY286IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uc2VjbyB8fCAnJyxcbiAgICAgICAgYWNvbWV0aWRhczogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5hY29tZXRpZGFzIHx8IHtcbiAgICAgICAgICBwcmltYXJpYTogeyBhZXJlYTogZmFsc2UsIHN1YnRlcnJhbmVhOiBmYWxzZSwgY2FsaWJyZTogJycsIHRpcG86ICcnLCB0ZXJtaW5hbDogJycsIGZ1c2libGU6ICcnLCBwYXJhcnJheW86ICcnLCBvYnNlcnZhY2lvbmVzOiAnJyB9LFxuICAgICAgICAgIHNlY3VuZGFyaWE6IHsgYWVyZWE6IGZhbHNlLCBzdWJ0ZXJyYW5lYTogZmFsc2UsIGNhbGlicmU6ICcnLCB0aXBvOiAnJywgdGVybWluYWw6ICcnLCBmdXNpYmxlOiAnJywgcGFyYXJyYXlvOiAnJywgb2JzZXJ2YWNpb25lczogJycgfSxcbiAgICAgICAgICBuZXV0cm86IHsgYWVyZWE6IGZhbHNlLCBzdWJ0ZXJyYW5lYTogZmFsc2UsIGNhbGlicmU6ICcnLCB0aXBvOiAnJywgdGVybWluYWw6ICcnLCBmdXNpYmxlOiAnJywgcGFyYXJyYXlvOiAnJywgb2JzZXJ2YWNpb25lczogJycgfVxuICAgICAgICB9LFxuICAgICAgICBzcHQ6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uc3B0IHx8IHtcbiAgICAgICAgICBiYXJpbGxhQ2FsaWJyZTogJycsXG4gICAgICAgICAgYmFyaWxsYUNhbnRpZGFkOiAnJyxcbiAgICAgICAgICBiYXJpbGxhQ29uZmlndXJhY2lvbjogJycsXG4gICAgICAgICAgY29uZHVjdG9yQ2FsaWJyZTogJycsXG4gICAgICAgICAgY29uZHVjdG9yVGlwb1NvbGQ6ICcnLFxuICAgICAgICAgIHJlc2lzdGVuY2lhOiAnJyxcbiAgICAgICAgICBmZWNoYU1lZGljaW9uOiAnJ1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAodGlwb0VsZW1lbnRvID09PSAnR0VORVJBRE9SJykge1xuICAgICAgY29uc3Qga3ZhR2VuTnVtID0gcGFyc2VGbG9hdChTdHJpbmcoa3ZhR2VuIHx8IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8ua3ZhIHx8IDApLnJlcGxhY2UoL1teMC05Ll0vZywgJycpKSB8fCBudWxsO1xuICAgICAgY29uc3Qga3dHZW5OdW0gPSBwYXJzZUZsb2F0KFN0cmluZyhwb3RlbmNpYUt3R2VuIHx8IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8ua3cgfHwgZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5wb3RlbmNpYUt3IHx8IDApLnJlcGxhY2UoL1teMC05Ll0vZywgJycpKSB8fCAoa3ZhR2VuTnVtID8gTWF0aC5yb3VuZChrdmFHZW5OdW0gKiAwLjggKiAxMDApIC8gMTAwIDogbnVsbCk7XG4gICAgICBjb25zdCBmcEdlbiA9IHBhcnNlRmxvYXQoZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5mYWN0b3JQb3RlbmNpYSB8fCAwLjgpIHx8IDAuODtcbiAgICAgIGNvbnN0IGt2YXJHZW4gPSBrdmFHZW5OdW0gPyBNYXRoLnJvdW5kKGt2YUdlbk51bSAqIE1hdGguc3FydChNYXRoLm1heCgwLCAxIC0gTWF0aC5wb3coZnBHZW4sIDIpKSkgKiAxMDApIC8gMTAwIDogbnVsbDtcbiAgICAgIGNvbnN0IGFtcEdlbk51bSA9IHBhcnNlRmxvYXQoU3RyaW5nKGFtcGVyYWplR2VuIHx8IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uYW1wZXJhamUgfHwgMCkucmVwbGFjZSgvW14wLTkuXS9nLCAnJykpIHx8IG51bGw7XG5cbiAgICAgIGRhdG9zVGVjbmljb3MgPSB7XG4gICAgICAgIGt2YToga3ZhR2VuTnVtIHx8IGt2YUdlbixcbiAgICAgICAga3c6IGt3R2VuTnVtIHx8IHBvdGVuY2lhS3dHZW4sXG4gICAgICAgIHBvdGVuY2lhS3c6IGt3R2VuTnVtIHx8IHBvdGVuY2lhS3dHZW4sXG4gICAgICAgIGt2YXI6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8ua3ZhciB8fCBrdmFyR2VuLFxuICAgICAgICBmYWN0b3JQb3RlbmNpYTogZnBHZW4sXG4gICAgICAgIHZvbHRhamVHZW5lcmFjaW9uOiB2b2x0YWplR2VuIHx8IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8udm9sdGFqZUdlbmVyYWNpb24gfHwgJycsXG4gICAgICAgIGFtcGVyYWplOiBhbXBHZW5OdW0gfHwgYW1wZXJhamVHZW4sXG4gICAgICAgIHRpcG9Db21idXN0aWJsZTogY29tYnVzdGlibGVHZW4gfHwgZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy50aXBvQ29tYnVzdGlibGUgfHwgZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5jb21idXN0aWJsZSB8fCAnRElFU0VMJyxcbiAgICAgICAgY29tYnVzdGlibGU6IGNvbWJ1c3RpYmxlR2VuIHx8IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uY29tYnVzdGlibGUgfHwgJ0RJRVNFTCcsXG4gICAgICAgIGNhcGFjaWRhZENvbWJ1c3RpYmxlOiBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3M/LmNhcGFjaWRhZENvbWJ1c3RpYmxlIHx8IG51bGwsXG4gICAgICAgIGNvbnN1bW9Fc3BlY2lmaWNhZG86IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uY29uc3Vtb0VzcGVjaWZpY2FkbyB8fCBudWxsLFxuICAgICAgICBob3Jhc09wZXJhY2lvbjogZWRpdGluZ0VsZW1lbnRvPy5kYXRvc1RlY25pY29zPy5ob3Jhc09wZXJhY2lvbiB8fCBudWxsLFxuICAgICAgICBob3Jhc1Jlc2VydmE6IGVkaXRpbmdFbGVtZW50bz8uZGF0b3NUZWNuaWNvcz8uaG9yYXNSZXNlcnZhIHx8IG51bGxcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0aXBvRWxlbWVudG8gPT09ICdCQU5DT19DT05ERU5TQURPUicpIHtcbiAgICAgIGRhdG9zVGVjbmljb3MgPSBlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3MgfHwge1xuICAgICAgICBtYXJjYTogJycsIG1vZGVsbzogJycsIGFsaW1lbnRhZG9yOiAnJywgY2FsaWJyZUNvbmR1Y3RvcjogJycsIGZhYnJpY2FudGU6ICcnLCBhbmlvRmFicmljYWNpb246ICcnLFxuICAgICAgICB0ZW5zaW9uTm9taW5hbDogdGVuc2lvbkJhbmNvIHx8ICcyMDggVicsIHRlbnNpb25SZWdpc3RyYWRhOiB0ZW5zaW9uQmFuY28gfHwgJzIwOCBWJywgZnJlY3VlbmNpYTogJzYwIEh6JywgXG4gICAgICAgIHBvdGVuY2lhUmVhY3RpdmFUb3RhbDoga3ZhclRvdGFsIHx8ICcxNTAga1ZBUicsXG4gICAgICAgIGNvcnJpZW50ZU5vbWluYWxUb3RhbDogJycsIG51bUZhc2VzOiAnVHJpZsOhc2ljbycsIGNvbmV4aW9uOiAnRXN0cmVsbGEnLCBuaXZlbEFpc2xhbWllbnRvQklMOiAnJyxcbiAgICAgICAgdGlwb0NvbXBlbnNhY2lvbjogdGlwb0JhbmNvID09PSAnQVVUT01BVElDTycgPyAnQXV0b23DoXRpY2EgKFBhc29zKScgOiAnRmlqYScsIG51bVBhc29zOiBwYXNvc0NvbmRlbnNhZG9yIHx8ICc2Jywgc2VjdWVuY2lhUGFzb3NLdmFyOiAnJyxcbiAgICAgICAgdGlwb0Nvbm11dGFjaW9uOiAnQ29udGFjdG9yZXMgZGVkaWNhZG9zJywgcG90ZW5jaWFJbmRpdmlkdWFsOiAnJywgY2FwYWNpdGFuY2lhTXVmOiAnJyxcbiAgICAgICAgdGVuc2lvbkNvbmRlbnNhZG9yOiAnJywgdGVjbm9sb2dpYURpZWxlY3RyaWNhOiAnUG9saXByb3BpbGVubyBtZXRhbGl6YWRvJyxcbiAgICAgICAgcmVzaXN0ZW5jaWFEZXNjYXJnYTogJ1PDrScsIHNlZ3VyaWRhZDogJ0Rlc2NvbmVjdGFkb3IgcG9yIHNvYnJlcHJlc2nDs24nLFxuICAgICAgICBmYWN0b3JEZXNpbnRvbml6YWNpb246ICdOL0EnLCB0aXBvTnVjbGVvOiAnTsO6Y2xlbyBkZSBIaWVycm8gY29uIEVudHJlaGllcnJvJyxcbiAgICAgICAgY2xhc2VBaXNsYW1pZW50b1Rlcm1pY286ICdDbGFzZSBIICgxODDCsEMpJywgcHJvdGVjY2lvblRlcm1pY2E6ICdTZW5zb3IgQmltZXTDoWxpY28gLyBQVDEwMCBpbnRlZ3JhZG8nLFxuICAgICAgICByZWd1bGFkb3JNYXJjYU1vZGVsbzogJycsIHJlbGFjaW9uVGM6ICcnLCBwdWVydG9Db211bmljYWNpb246ICdSUy00ODUgKE1vZGJ1cyBSVFUpJyxcbiAgICAgICAgaW50ZXJydXB0b3JQcmluY2lwYWxBbXA6ICcnLCBwcm90ZWNjaW9uUGFzb3M6ICdGdXNpYmxlcycsIGdyYWRvUHJvdGVjY2lvbkVudm9sdmVudGU6ICdJUDU0JyxcbiAgICAgICAgZGltZW5zaW9uZXNBbHRvOiAnJywgZGltZW5zaW9uZXNBbmNobzogJycsIGRpbWVuc2lvbmVzUHJvZjogJycsXG4gICAgICAgIHNpc3RlbWFFbmZyaWFtaWVudG86ICdWZW50aWxhY2nDs24gRm9yemFkYScsIHRlbXBlcmF0dXJhQzogJycsIGh1bWVkYWRQY3Q6ICcnXG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAodGlwb0VsZW1lbnRvID09PSAnUFVOVE9fU1VNSU5JU1RSTycpIHtcbiAgICAgIGRhdG9zVGVjbmljb3MgPSB7XG4gICAgICAgIC4uLihlZGl0aW5nRWxlbWVudG8/LmRhdG9zVGVjbmljb3MgfHwge30pLFxuICAgICAgICBuaXZlbFRlbnNpb246IHN1bWluaXN0cm9UZW5zaW9uIHx8ICcxMy44IGtWJyxcbiAgICAgICAgdGVuc2lvbk5vbWluYWw6IHN1bWluaXN0cm9UZW5zaW9uIHx8ICcxMy44IGtWJyxcbiAgICAgICAgZW1wcmVzYURpc3RyaWJ1aWRvcmE6IHN1bWluaXN0cm9FbXByZXNhIHx8ICdDT1JQT0VMRUMnLFxuICAgICAgICB0aXBvQWNvbWV0aWRhOiBzdW1pbmlzdHJvVGlwb0Fjb21ldGlkYSB8fCAnU3VidGVycsOhbmVhJyxcbiAgICAgICAgY2FwYWNpZGFkQ29udHJhdGFkYUt2YTogc3VtaW5pc3Ryb0NhcGFjaWRhZCB8fCAnJyxcbiAgICAgICAgY2FyZ2FDb250cmF0YWRhS3ZhOiBzdW1pbmlzdHJvQ2FwYWNpZGFkIHx8ICcnLFxuICAgICAgICB0aXBvTWVkaWNpb246IHN1bWluaXN0cm9UaXBvTWVkaWNpb24gfHwgJ01lZGljacOzbiBEaXJlY3RhIChCYWphIFRlbnNpw7NuKScsXG4gICAgICAgIGVubGFjZUNvcnBvZWxlYzogQm9vbGVhbihzdW1pbmlzdHJvRW5sYWNlQ29ycG9lbGVjKSxcbiAgICAgICAgbnVtZXJvQ29udHJhdG86IHN1bWluaXN0cm9OdW1lcm9Db250cmF0byB8fCAnJyxcbiAgICAgICAgbmljOiBzdW1pbmlzdHJvTmljIHx8ICcnLFxuICAgICAgICBwb3N0ZVRyYW5zZm9ybWFkb3I6IHN1bWluaXN0cm9Qb3N0ZVRyYWZvIHx8ICcnXG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAodGlwb0VsZW1lbnRvID09PSAnQ0NNJykge1xuICAgICAgZGF0b3NUZWNuaWNvcyA9IHtcbiAgICAgICAgY2FwYWNpZGFkQmFycmFBbXBlcmlvczogY2NtQ2FwYWNpZGFkQmFycmEgfHwgJzEyMDAgQScsXG4gICAgICAgIHRlbnNpb25PcGVyYXRpdmE6IGNjbVRlbnNpb24gfHwgJzQ4MCBWJyxcbiAgICAgICAgYnJlYWtlclByaW5jaXBhbDogY2NtQnJlYWtlclByaW5jaXBhbCB8fCAnMTIwMEEgM1AnLFxuICAgICAgICBudW1lcm9HYXZldGFzOiBwYXJzZUludChjY21OdW1lcm9HYXZldGFzLCAxMCkgfHwgOFxuICAgICAgfTtcbiAgICB9IGVsc2UgaWYgKHRpcG9FbGVtZW50byA9PT0gJ1BVRVNUQV9USUVSUkEnKSB7XG4gICAgICBkYXRvc1RlY25pY29zID0ge1xuICAgICAgICByZXNpc3RlbmNpYU9obWlvcyxcbiAgICAgICAgY29ycmllbnRlRnVnYUFtcGVyaW9zOiBjb3JyaWVudGVGdWdhLFxuICAgICAgICB0aXBvTWFsbGEsXG4gICAgICAgIGNhYmxlQWNvbWV0aWRhOiBjYWJsZUFjb21ldGlkYVRpZXJyYVxuICAgICAgfTtcbiAgICB9IGVsc2UgaWYgKHRpcG9FbGVtZW50byA9PT0gJ1RSQU5TRkVSJykge1xuICAgICAgZGF0b3NUZWNuaWNvcyA9IHtcbiAgICAgICAgY2FwYWNpZGFkQW1wZXJpb3MsXG4gICAgICAgIHRpcG9UcmFuc2ZlcmVuY2lhLFxuICAgICAgICB0ZW5zaW9uT3BlcmF0aXZhXG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICBkYXRvc1RlY25pY29zID0ge1xuICAgICAgICBkZXNjcmlwY2lvbkVzcGVjaWZpY2FjaW9uZXM6IGRlc2NyaXBjaW9uT3Ryb1xuICAgICAgfTtcbiAgICB9XG5cbiAgICBpZiAoZWRpdGluZ0VsZW1lbnRvKSB7XG4gICAgICB1cGRhdGVFbGVtZW50b1VuaWZpbGFyKHByb3llY3RvSWQsIGVkaXRpbmdFbGVtZW50by5pZCwge1xuICAgICAgICBub21icmU6IG5vbWJyZS50cmltKCksXG4gICAgICAgIHRpcG9FbGVtZW50byxcbiAgICAgICAgdWJpY2FjaW9uOiB1YmljYWNpb24udHJpbSgpIHx8ICdTaW4gdWJpY2FjacOzbicsXG4gICAgICAgIGFsaW1lbnRhZG9Qb3I6IGFsaW1lbnRhZG9Qb3IudHJpbSgpIHx8ICdObyBkZWZpbmlkbycsXG4gICAgICAgIG9ic2VydmFjaW9uZXNHZW5lcmFsZXM6IG9ic2VydmFjaW9uZXNHZW5lcmFsZXMudHJpbSgpLFxuICAgICAgICBkYXRvc1RlY25pY29zXG4gICAgICB9KTtcbiAgICAgIHNob3dUb2FzdD8uKFwiRWxlbWVudG8gYWN0dWFsaXphZG8gY29ycmVjdGFtZW50ZS5cIiwgXCJzdWNjZXNzXCIpO1xuICAgICAgc2V0RWRpdGluZ0VsZW1lbnRvKG51bGwpO1xuICAgICAgc2V0U2hvd0VsZW1lbnRvTW9kYWwoZmFsc2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhZGRFbGVtZW50b1VuaWZpbGFyKHByb3llY3RvSWQsIHtcbiAgICAgICAgbm9tYnJlOiBub21icmUudHJpbSgpLFxuICAgICAgICB0aXBvRWxlbWVudG8sXG4gICAgICAgIHViaWNhY2lvbjogdWJpY2FjaW9uLnRyaW0oKSB8fCAnU2luIHViaWNhY2nDs24nLFxuICAgICAgICBhbGltZW50YWRvUG9yOiBhbGltZW50YWRvUG9yLnRyaW0oKSB8fCAnTm8gZGVmaW5pZG8nLFxuICAgICAgICBmb3RvQmxvYixcbiAgICAgICAgb2JzZXJ2YWNpb25lc0dlbmVyYWxlczogb2JzZXJ2YWNpb25lc0dlbmVyYWxlcy50cmltKCksXG4gICAgICAgIGRhdG9zVGVjbmljb3NcbiAgICAgIH0pO1xuXG4gICAgICBpZiAocmVzdWx0LnN1Y2Nlc3MpIHtcbiAgICAgICAgc2V0Tm9tYnJlKCcnKTtcbiAgICAgICAgc2V0VWJpY2FjaW9uKCcnKTtcbiAgICAgICAgc2V0QWxpbWVudGFkb1BvcignJyk7XG4gICAgICAgIHNldE9ic2VydmFjaW9uZXNHZW5lcmFsZXMoJycpO1xuICAgICAgICBzZXRGb3RvQmxvYihudWxsKTtcbiAgICAgICAgaWYgKHByZXZpZXdVcmwpIFVSTC5yZXZva2VPYmplY3RVUkwocHJldmlld1VybCk7XG4gICAgICAgIHNldFByZXZpZXdVcmwobnVsbCk7XG4gICAgICAgIHNldFNob3dFbGVtZW50b01vZGFsKGZhbHNlKTtcbiAgICAgICAgc2hvd1RvYXN0Py4oXCJFbGVtZW50byByZWdpc3RyYWRvIGNvcnJlY3RhbWVudGUuXCIsIFwic3VjY2Vzc1wiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGN1c3RvbUFsZXJ0KHJlc3VsdC5lcnJvcik7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUluc3BlY2Npb24gPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIWlzSW5zcGVjY2lvbkZvcm1WYWxpZCkgcmV0dXJuO1xuXG4gICAgaWYgKHRpcG9JbnNwZWNjaW9uTW9kYWwgPT09ICdBTUJJRU5UQUxfRklTSUNBJyB8fCB0aXBvSW5zcGVjY2lvbk1vZGFsID09PSAnU1VCRVNUQUNJT04nKSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhZGRJbnNwZWNjaW9uU3ViZXN0YWNpb24ocHJveWVjdG9JZCwge1xuICAgICAgICBub21icmU6IHN1YmVzdGFjaW9uTm9tYnJlLnRyaW0oKSB8fCAnU3ViZXN0YWNpw7NuIFByaW5jaXBhbCcsXG4gICAgICAgIHViaWNhY2lvbjogc3ViZXN0YWNpb25VYmljYWNpb24udHJpbSgpIHx8ICdTYWxhIEVsw6ljdHJpY2EnLFxuICAgICAgICBuaXZlbFRlbnNpb246IG5pdmVsVGVuc2lvbi50cmltKCkgfHwgJzEzLjgga1YnLFxuICAgICAgICBpbnNwZWN0b3I6IGluc3BlY3Rvck5hbWUudHJpbSgpIHx8ICdObyBhc2lnbmFkbycsXG4gICAgICAgIGZlY2hhOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgICAgICAgaG9yYTogbmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VzLUVTJywgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pLFxuICAgICAgICBlc3RhZG9FbnRvcm5vOiB7fSxcbiAgICAgICAgb2JyYXNDaXZpbGVzOiB7fSxcbiAgICAgICAgZXF1aXBvc1ByaW5jaXBhbGVzOiB7fSxcbiAgICAgICAgcHVlc3RhVGllcnJhOiB7fSxcbiAgICAgICAgZWRpZmljaW9Db250cm9sOiB7fVxuICAgICAgfSk7XG5cbiAgICAgIGlmIChyZXN1bHQuc3VjY2Vzcykge1xuICAgICAgICBzZXRTdWJlc3RhY2lvbk5vbWJyZSgnJyk7XG4gICAgICAgIHNldFN1YmVzdGFjaW9uVWJpY2FjaW9uKCcnKTtcbiAgICAgICAgc2V0Tml2ZWxUZW5zaW9uKCcxMy44IGtWJyk7XG4gICAgICAgIHNldEluc3BlY3Rvck5hbWUoJycpO1xuICAgICAgICBzZXRTaG93SW5zcGVjY2lvbk1vZGFsKGZhbHNlKTtcbiAgICAgICAgc2hvd1RvYXN0Py4oXCJJbnNwZWNjacOzbiBBbWJpZW50YWwgbyBGw61zaWNhIHJlZ2lzdHJhZGEgZXhpdG9zYW1lbnRlLlwiLCBcInN1Y2Nlc3NcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjdXN0b21BbGVydChyZXN1bHQuZXJyb3IpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICh0aXBvSW5zcGVjY2lvbk1vZGFsID09PSAnVEVSTU9HUkFGSUNBJykge1xuICAgICAgY29uc3QgdFB1bnRvID0gcGFyc2VGbG9hdCh0ZXJtb1RlbXBQdW50b0NhbGllbnRlKSB8fCAwO1xuICAgICAgY29uc3QgdFJlZiA9IHBhcnNlRmxvYXQodGVybW9UZW1wUmVmKSB8fCAwO1xuICAgICAgY29uc3QgZGVsdGFUID0gKHRQdW50byAtIHRSZWYpLnRvRml4ZWQoMSk7XG4gICAgICBsZXQgc2V2ZXJpZGFkID0gJ05PUk1BTCc7XG4gICAgICBpZiAoZGVsdGFUID4gNDApIHNldmVyaWRhZCA9ICdDUklUSUNBJztcbiAgICAgIGVsc2UgaWYgKGRlbHRhVCA+IDIwKSBzZXZlcmlkYWQgPSAnQUxUQSc7XG4gICAgICBlbHNlIGlmIChkZWx0YVQgPiAxMCkgc2V2ZXJpZGFkID0gJ01PREVSQURBJztcblxuICAgICAgY29uc3QgcmVzdWx0ID0gYWRkSW5zcGVjY2lvblN1YmVzdGFjaW9uKHByb3llY3RvSWQsIHtcbiAgICAgICAgbm9tYnJlOiB0ZXJtb05vbWJyZS50cmltKCkgfHwgYElULTE6IEluc3BlY2Npw7NuIFRlcm1vZ3LDoWZpY2FgLFxuICAgICAgICB0aXBvRWxlbWVudG86ICdURVJNT0dSQUZJQ0EnLFxuICAgICAgICB1YmljYWNpb246IHRlcm1vVWJpY2FjaW9uLnRyaW0oKSB8fCAnU2FsYSBFbMOpY3RyaWNhJyxcbiAgICAgICAgbml2ZWxUZW5zaW9uOiAnVGVybW9ncmFmw61hJyxcbiAgICAgICAgaW5zcGVjdG9yOiBpbnNwZWN0b3JOYW1lLnRyaW0oKSB8fCB1c2VyPy51c2VybmFtZSB8fCAnSW5zcGVjdG9yJyxcbiAgICAgICAgZmVjaGE6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICAgICAgICBob3JhOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygnZXMtRVMnLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSksXG4gICAgICAgIGVzdGFkb0VudG9ybm86IHt9LFxuICAgICAgICBvYnJhc0NpdmlsZXM6IHt9LFxuICAgICAgICBlcXVpcG9zUHJpbmNpcGFsZXM6IHtcbiAgICAgICAgICB0ZW1wZXJhdHVyYUFtYmllbnRlOiB0ZXJtb1RlbXBBbWJpZW50ZSxcbiAgICAgICAgICB0ZW1wZXJhdHVyYVB1bnRvQ2FsaWVudGU6IHRlcm1vVGVtcFB1bnRvQ2FsaWVudGUsXG4gICAgICAgICAgdGVtcGVyYXR1cmFSZWZlcmVuY2lhOiB0ZXJtb1RlbXBSZWYsXG4gICAgICAgICAgZGVsdGFULFxuICAgICAgICAgIHNldmVyaWRhZE5ldGE6IHNldmVyaWRhZCxcbiAgICAgICAgICBjYW1hcmFNb2RlbG86IHRlcm1vQ2FtYXJhXG4gICAgICAgIH0sXG4gICAgICAgIHB1ZXN0YVRpZXJyYToge30sXG4gICAgICAgIGVkaWZpY2lvQ29udHJvbDoge31cbiAgICAgIH0pO1xuXG4gICAgICBpZiAocmVzdWx0LnN1Y2Nlc3MpIHtcbiAgICAgICAgc2V0VGVybW9Ob21icmUoJycpO1xuICAgICAgICBzZXRUZXJtb1ViaWNhY2lvbignJyk7XG4gICAgICAgIHNldFRlcm1vVGVtcFB1bnRvQ2FsaWVudGUoJycpO1xuICAgICAgICBzZXRTaG93SW5zcGVjY2lvbk1vZGFsKGZhbHNlKTtcbiAgICAgICAgc2hvd1RvYXN0Py4oXCJJbnNwZWNjacOzbiBUZXJtb2dyw6FmaWNhIHJlZ2lzdHJhZGEgZXhpdG9zYW1lbnRlLlwiLCBcInN1Y2Nlc3NcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjdXN0b21BbGVydChyZXN1bHQuZXJyb3IpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICh0aXBvSW5zcGVjY2lvbk1vZGFsID09PSAnU0lTVEVNQV9BVEVSUkFNSUVOVE8nIHx8IHRpcG9JbnNwZWNjaW9uTW9kYWwgPT09ICdQVUVTVEFfVElFUlJBJykge1xuICAgICAgY29uc3Qgck9obXMgPSBwYXJzZUZsb2F0KHBhdFJlc2lzdGVuY2lhKSB8fCAwO1xuICAgICAgbGV0IGN1bXBsaW1pZW50b0llZWUgPSAnQ1VNUExFIChFeGNlbGVudGUgPD0gNc6pKSc7XG4gICAgICBpZiAock9obXMgPiAxMCkgY3VtcGxpbWllbnRvSWVlZSA9ICdOTyBDVU1QTEUgKD4gMTDOqSAtIFJlcXVpZXJlIE1hbnRlbmltaWVudG8pJztcbiAgICAgIGVsc2UgaWYgKHJPaG1zID4gNSkgY3VtcGxpbWllbnRvSWVlZSA9ICdBQ0VQVEFCTEUgKDw9IDEwzqkpJztcblxuICAgICAgY29uc3QgcmVzdWx0ID0gYWRkSW5zcGVjY2lvblN1YmVzdGFjaW9uKHByb3llY3RvSWQsIHtcbiAgICAgICAgbm9tYnJlOiAocGF0Tm9tYnJlIHx8IHN1YmVzdGFjaW9uTm9tYnJlKS50cmltKCkgfHwgYFBBVC0xOiBTaXN0ZW1hIGRlIEF0ZXJyYW1pZW50b2AsXG4gICAgICAgIHRpcG9FbGVtZW50bzogJ1NJU1RFTUFfQVRFUlJBTUlFTlRPJyxcbiAgICAgICAgdWJpY2FjaW9uOiAocGF0VWJpY2FjaW9uIHx8IHN1YmVzdGFjaW9uVWJpY2FjaW9uKS50cmltKCkgfHwgJ1BhdGlvIC8gU2FsYSBFbMOpY3RyaWNhJyxcbiAgICAgICAgbml2ZWxUZW5zaW9uOiAnQXRlcnJhbWllbnRvIFBBVCcsXG4gICAgICAgIGluc3BlY3RvcjogaW5zcGVjdG9yTmFtZS50cmltKCkgfHwgdXNlcj8udXNlcm5hbWUgfHwgJ0luc3BlY3RvcicsXG4gICAgICAgIGZlY2hhOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgICAgICAgaG9yYTogbmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VzLUVTJywgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pLFxuICAgICAgICBlc3RhZG9FbnRvcm5vOiB7fSxcbiAgICAgICAgb2JyYXNDaXZpbGVzOiB7fSxcbiAgICAgICAgZXF1aXBvc1ByaW5jaXBhbGVzOiB7fSxcbiAgICAgICAgcHVlc3RhVGllcnJhOiB7XG4gICAgICAgICAgcmVzaXN0ZW5jaWFPaG1zOiBwYXRSZXNpc3RlbmNpYS50cmltKCkgfHwgJycsXG4gICAgICAgICAgbWV0b2RvTWVkaWNpb246IHBhdE1ldG9kbyB8fCAnQ2HDrWRhIGRlIFBvdGVuY2lhbCAoNjIlKScsXG4gICAgICAgICAgdGlwb1Npc3RlbWFQYXQ6IHBhdFRpcG8gfHwgJ01hbGxhIGNvbiBWYXJpbGxhcycsXG4gICAgICAgICAgdGlwb1VuaW9uOiBwYXRVbmlvbiB8fCAnU29sZGFkdXJhIEV4b3TDqXJtaWNhIChDYWR3ZWxkKScsXG4gICAgICAgICAgdGVsdXJvbWV0cm86IHBhdFRlbHVyb21ldHJvLFxuICAgICAgICAgIGN1bXBsaW1pZW50b0llZWU4MDogY3VtcGxpbWllbnRvSWVlZVxuICAgICAgICB9LFxuICAgICAgICBlZGlmaWNpb0NvbnRyb2w6IHt9XG4gICAgICB9KTtcblxuICAgICAgaWYgKHJlc3VsdC5zdWNjZXNzKSB7XG4gICAgICAgIHNldFBhdE5vbWJyZSgnJyk7XG4gICAgICAgIHNldFBhdFViaWNhY2lvbignJyk7XG4gICAgICAgIHNldFBhdFJlc2lzdGVuY2lhKCcnKTtcbiAgICAgICAgc2V0U3ViZXN0YWNpb25Ob21icmUoJycpO1xuICAgICAgICBzZXRTdWJlc3RhY2lvblViaWNhY2lvbignJyk7XG4gICAgICAgIHNldFNob3dJbnNwZWNjaW9uTW9kYWwoZmFsc2UpO1xuICAgICAgICBzaG93VG9hc3Q/LihcIkluc3BlY2Npw7NuIGRlbCBTaXN0ZW1hIGRlIEF0ZXJyYW1pZW50byByZWdpc3RyYWRhIGV4aXRvc2FtZW50ZS5cIiwgXCJzdWNjZXNzXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY3VzdG9tQWxlcnQocmVzdWx0LmVycm9yKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAodGlwb0luc3BlY2Npb25Nb2RhbCA9PT0gJ1RBTlFVRV9DT01CVVNUSUJMRScpIHtcbiAgICAgIGNvbnN0IGNhcExpdHJvcyA9IHBhcnNlRmxvYXQodGFucXVlQ2FwYWNpZGFkTGl0cm9zKSB8fCAwO1xuICAgICAgY29uc3Qgbml2ZWxQY3QgPSBwYXJzZUZsb2F0KHRhbnF1ZU5pdmVsUG9yY2VudGFqZSkgfHwgMDtcbiAgICAgIGNvbnN0IGNvbnN1bW8gPSBwYXJzZUZsb2F0KHRhbnF1ZUNvbnN1bW9MaCkgfHwgMTtcbiAgICAgIGNvbnN0IGxpdHJvc0FjdHVhbGVzID0gKChjYXBMaXRyb3MgKiBuaXZlbFBjdCkgLyAxMDApLnRvRml4ZWQoMCk7XG4gICAgICBjb25zdCBhdXRvbm9taWFIb3JhcyA9IChsaXRyb3NBY3R1YWxlcyAvIChjb25zdW1vIHx8IDEpKS50b0ZpeGVkKDEpO1xuXG4gICAgICBjb25zdCByZXN1bHQgPSBhZGRJbnNwZWNjaW9uU3ViZXN0YWNpb24ocHJveWVjdG9JZCwge1xuICAgICAgICBub21icmU6IHRhbnF1ZU5vbWJyZS50cmltKCkgfHwgYFRLLTE6IFRhbnF1ZSBkZSBDb21idXN0aWJsZWAsXG4gICAgICAgIHRpcG9FbGVtZW50bzogJ1RBTlFVRV9DT01CVVNUSUJMRScsXG4gICAgICAgIHViaWNhY2lvbjogdGFucXVlVWJpY2FjaW9uLnRyaW0oKSB8fCAnw4FyZWEgZGUgR2VuZXJhY2nDs24nLFxuICAgICAgICBuaXZlbFRlbnNpb246ICdDb21idXN0aWJsZScsXG4gICAgICAgIGluc3BlY3RvcjogaW5zcGVjdG9yTmFtZS50cmltKCkgfHwgdXNlcj8udXNlcm5hbWUgfHwgJ0luc3BlY3RvcicsXG4gICAgICAgIGZlY2hhOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgICAgICAgaG9yYTogbmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VzLUVTJywgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pLFxuICAgICAgICBlc3RhZG9FbnRvcm5vOiB7XG4gICAgICAgICAgdGlwb0NvbWJ1c3RpYmxlOiB0YW5xdWVUaXBvQ29tYnVzdGlibGUsXG4gICAgICAgICAgY2FwYWNpZGFkTGl0cm9zOiB0YW5xdWVDYXBhY2lkYWRMaXRyb3MsXG4gICAgICAgICAgbml2ZWxQb3JjZW50YWplOiB0YW5xdWVOaXZlbFBvcmNlbnRhamUsXG4gICAgICAgICAgbGl0cm9zQWN0dWFsZXMsXG4gICAgICAgICAgY29uc3Vtb0xoOiB0YW5xdWVDb25zdW1vTGgsXG4gICAgICAgICAgYXV0b25vbWlhSG9yYXNDYWxjdWxhZGE6IGF1dG9ub21pYUhvcmFzLFxuICAgICAgICAgIGRpcXVlQ29udGVuY2lvbjExMDogdGFucXVlRGlxdWUxMTBcbiAgICAgICAgfSxcbiAgICAgICAgb2JyYXNDaXZpbGVzOiB7fSxcbiAgICAgICAgZXF1aXBvc1ByaW5jaXBhbGVzOiB7fSxcbiAgICAgICAgcHVlc3RhVGllcnJhOiB7fSxcbiAgICAgICAgZWRpZmljaW9Db250cm9sOiB7fVxuICAgICAgfSk7XG5cbiAgICAgIGlmIChyZXN1bHQuc3VjY2Vzcykge1xuICAgICAgICBzZXRUYW5xdWVOb21icmUoJycpO1xuICAgICAgICBzZXRUYW5xdWVVYmljYWNpb24oJycpO1xuICAgICAgICBzZXRTaG93SW5zcGVjY2lvbk1vZGFsKGZhbHNlKTtcbiAgICAgICAgc2hvd1RvYXN0Py4oXCJJbnNwZWNjacOzbiBkZSBUYW5xdWUgZGUgQ29tYnVzdGlibGUgcmVnaXN0cmFkYSBleGl0b3NhbWVudGUuXCIsIFwic3VjY2Vzc1wiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGN1c3RvbUFsZXJ0KHJlc3VsdC5lcnJvcik7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZVB1bnRvTWVkaWNpb24gPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIXB1bnRvTWVkaWNpb25Ob21icmUudHJpbSgpKSByZXR1cm47XG5cbiAgICBjb25zdCByZXN1bHQgPSBhZGRQdW50b01lZGljaW9uKHByb3llY3RvSWQsIHtcbiAgICAgIG5vbWJyZTogcHVudG9NZWRpY2lvbk5vbWJyZS50cmltKCksXG4gICAgICBub21icmVVc3VhcmlvOiBwdW50b01lZGljaW9uVXN1YXJpby50cmltKCkgfHwgJycsXG4gICAgICBudW1lcm9Db250cmF0bzogcHVudG9NZWRpY2lvbk5JQy50cmltKCkgfHwgJycsXG4gICAgICBuaXZlbFRlbnNpb25Db250cmF0bzogcHVudG9NZWRpY2lvbk5pdmVsVGVuc2lvbiB8fCAnTWVkaWEgVGVuc2nDs24nLFxuICAgICAgaW5zcGVjdG9yOiB1c2VyPy51c2VybmFtZSB8fCAnSW5zcGVjdG9yJyxcbiAgICAgIGZlY2hhOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgICAgIGhvcmE6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlcy1FUycsIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0JyB9KVxuICAgIH0pO1xuXG4gICAgaWYgKHJlc3VsdC5zdWNjZXNzKSB7XG4gICAgICBzZXRQdW50b01lZGljaW9uTm9tYnJlKCcnKTtcbiAgICAgIHNldFB1bnRvTWVkaWNpb25Vc3VhcmlvKCcnKTtcbiAgICAgIHNldFB1bnRvTWVkaWNpb25OSUMoJycpO1xuICAgICAgc2V0U2hvd1B1bnRvTWVkaWNpb25Nb2RhbChmYWxzZSk7XG4gICAgICBzaG93VG9hc3Q/LignUHVudG8gZGUgTWVkaWNpw7NuIHJlZ2lzdHJhZG8gY29uIMOpeGl0bycsICdzdWNjZXNzJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGN1c3RvbUFsZXJ0KHJlc3VsdC5lcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wgYW50aWFsaWFzZWQgZm9udC1zYW5zXCI+XG4gICAgICBcbiAgICAgIHsvKiBUb3AgSGVhZGVyICovfVxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMC84MCBweC02IHB5LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNoYWRvdy1sZ1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvZW1wcmVzYS8ke2NvbXBhbnlJZH1gKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCB0cmFuc2l0aW9uLWFsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBhY3RpdmU6c2NhbGUtOTUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgdGl0bGU9XCJWb2x2ZXIgYSBsYSBFbXByZXNhXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTUwMCBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJsb2NrXCI+XG4gICAgICAgICAgICAgIFByb3llY3RvIGRlOiB7Y29tcGFueS5ub21icmV9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgdHJhY2tpbmctdGlnaHRcIj57cHJveWVjdG8ubm9tYnJlfTwvaDE+XG4gICAgICAgICAgICB7cHJveWVjdG8uZGVzY3JpcGNpb24gJiYgKFxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNSBsaW5lLWNsYW1wLTFcIj57cHJveWVjdG8uZGVzY3JpcGNpb259PC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgey8qIE1haW4gQ29udGVudCBBcmVhICovfVxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG1heC13LTd4bCB3LWZ1bGwgbXgtYXV0byBweC02IHB5LTggc3BhY2UteS02XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogQ0FSRCBJTkZPUk1BQ0lPTiBERUwgUFJPWUVDVE8gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3cteGwgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci01MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9jayBtYi0xXCI+UHJveWVjdG8gVMOpY25pY288L3NwYW4+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtMTAwIHRyYWNraW5nLXRpZ2h0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPEJ1aWxkaW5nIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci01MDBcIiAvPiB7cHJveWVjdG8ubm9tYnJlfVxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTEgbWF4LXctMnhsXCI+e3Byb3llY3RvLmRlc2NyaXBjaW9uIHx8ICdTaW4gZGVzY3JpcGNpw7NuLid9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7dXNlcj8ucm9sZSA9PT0gJ0FETUlOJyAmJiBhY3RpdmVUYWIgIT09ICdFU1RSVUNUVVJBTCcgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0RWRpdFByb3llY3RvTm9tYnJlKHByb3llY3RvLm5vbWJyZSk7XG4gICAgICAgICAgICAgICAgICBzZXRFZGl0UHJveWVjdG9EZXNjcmlwY2lvbihwcm95ZWN0by5kZXNjcmlwY2lvbiB8fCAnJyk7XG4gICAgICAgICAgICAgICAgICBzZXRFZGl0UHJveWVjdG9EaXJlY2Npb24ocHJveWVjdG8uZGlyZWNjaW9uIHx8ICcnKTtcbiAgICAgICAgICAgICAgICAgIHNldEVkaXRSZXNwb25zYWJsZU5vbWJyZShwcm95ZWN0by5yZXNwb25zYWJsZU5vbWJyZSB8fCAnJyk7XG4gICAgICAgICAgICAgICAgICBzZXRFZGl0UmVzcG9uc2FibGVUZWxlZm9ubyhwcm95ZWN0by5yZXNwb25zYWJsZVRlbGVmb25vIHx8ICcnKTtcbiAgICAgICAgICAgICAgICAgIHNldEVkaXRSZXNwb25zYWJsZUVtYWlsKHByb3llY3RvLnJlc3BvbnNhYmxlRW1haWwgfHwgJycpO1xuICAgICAgICAgICAgICAgICAgc2V0U2hvd0VkaXRQcm95ZWN0b01vZGFsKHRydWUpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTEuNSBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS0yMDAgaG92ZXI6dGV4dC1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBzaGFkb3ctbWRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgRWRpdGFyIFByb3llY3RvXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNiBtdC02IHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgYmxvY2tcIj5VYmljYWNpw7NuIC8gRGlyZWNjacOzbjwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMjAwXCI+e3Byb3llY3RvLmRpcmVjY2lvbiB8fCAnTm8gZGVmaW5pZGEnfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkIHVwcGVyY2FzZSBibG9ja1wiPkVtcHJlc2E8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTIwMFwiPntjb21wYW55Py5ub21icmV9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGQgdXBwZXJjYXNlIGJsb2NrXCI+UmVnaXN0cm88L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIG10LTEgc3BhY2UteS0wLjVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PkNyZWFkbzoge3Byb3llY3RvLmNyZWF0ZWRBdCA/IG5ldyBEYXRlKHByb3llY3RvLmNyZWF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoJ2VzLUVTJykgOiAnTi9EJ308L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PkFjdHVhbGl6YWRvOiB7cHJveWVjdG8udXBkYXRlZEF0ID8gbmV3IERhdGUocHJveWVjdG8udXBkYXRlZEF0KS50b0xvY2FsZVN0cmluZygnZXMtRVMnKSA6ICdOL0QnfTwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge3VzZXI/LnJvbGUgPT09ICdBRE1JTicgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxVc2VyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1za3ktNDAwXCIgLz4gUmVzcG9uc2FibGUgZGVsIFByb3llY3RvIChTb2xvIFZpc2libGUgcGFyYSBBZG1pbmlzdHJhZG9yZXMpXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzUwIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtOTAwIG1heC13LW1kXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PjxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00NTBcIj5Ob21icmU6PC9zdHJvbmc+IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjU1IGZvbnQtc2VtaWJvbGRcIj57cHJveWVjdG8ucmVzcG9uc2FibGVOb21icmUgfHwgJ04vRCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj48c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDUwXCI+VGVsw6lmb25vOjwvc3Ryb25nPiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTI1NSBmb250LXNlbWlib2xkXCI+e3Byb3llY3RvLnJlc3BvbnNhYmxlVGVsZWZvbm8gfHwgJ04vRCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj48c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDUwXCI+RW1haWw6PC9zdHJvbmc+IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjU1IGZvbnQtc2VtaWJvbGRcIj57cHJveWVjdG8ucmVzcG9uc2FibGVFbWFpbCB8fCAnTi9EJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuXG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBOYXZpZ2F0aW9uICYgQ29udHJvbCBQYW5lbCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdHJldGNoIG1kOml0ZW1zLWNlbnRlciBnYXAtNCBwYi02IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAvODBcIj5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogUGVzdGHDsWFzIGRlIFNlbGVjY2nDs24gZGUgUmFtYSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYmctc2xhdGUtOTUwIHAtMS41IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNlbGYtc3RhcnRcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdVTklGSUxBUicpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC01IHB5LTIuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnVU5JRklMQVInIFxuICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIHNoYWRvdy1tZCcgXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS05MDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBEaWFncmFtYSBVbmlmaWxhclxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignRVNUUlVDVFVSQUwnKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNSBweS0yLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ0VTVFJVQ1RVUkFMJyBcbiAgICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctbWQnIFxuICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtOTAwJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEJ1aWxkaW5nIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBJbnNwZWNjaW9uZXNcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEJ1c2NhZG9yICYgQm90b25lcyBlbiBQYXJhbGVsbyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIG1kOmZsZXgtbm93cmFwIGl0ZW1zLWNlbnRlciBnYXAtMyBqdXN0aWZ5LWVuZCB3LWZ1bGwgbWQ6dy1hdXRvXCI+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHsvKiBCdXNjYWRvciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1kOnctNjBcIj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJ1c2NhciBlbiBlc3RhIHNlY2Npw7NuLi4uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTAgcHItNCBweS0yIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItc2xhdGUtNzAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBwbGFjZWhvbGRlci1zbGF0ZS01MDAgZm9jdXM6b3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctNCBoLTQgYWJzb2x1dGUgbGVmdC0zLjUgdG9wLTMgdGV4dC1zbGF0ZS01MDBcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBCT1RPTkVTIERFIEFDQ0nDk04gQUdSVVBBRE9TIFBPUiBKRVJBUlFVw41BICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBtZDpmbGV4LW5vd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTMgdy1mdWxsIG1kOnctYXV0byBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgey8qIEdydXBvIDE6IEdlbmVyYXIgSW5mb3JtZXMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtMS41IHJvdW5kZWQteGwgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2VtcHJlc2EvJHtjb21wYW55SWR9L3Byb3llY3RvLyR7cHJveWVjdG9JZH0vaW5mb3JtZWApfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCBhY3RpdmU6c2NhbGUtOTUgdGV4dC1zbGF0ZS05NTAgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIHB4LTMgcHktMiByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgaC05IHRleHQteHMgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiR2VuZXJhciBJbmZvcm1lIFTDqWNuaWNvIFBERiBjb21wbGV0b1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gSW5mb3JtZSBQREZcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93SGVscE1vZGFsKHRydWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAvNDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC1hbWJlci00MDAgZm9udC1zZW1pYm9sZCBweC0zIHB5LTIgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGgtOSB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIk1hbnVhbCBkZSBVc3VhcmlvLCBNYXRyaXogZGUgUm9sZXMgeSBOb3JtYXRpdmEgRWzDqWN0cmljYVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEhlbHBDaXJjbGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci01MDBcIiAvPiBBeXVkYSAvIE1hbnVhbFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogR3J1cG8gMjogQ29udHJvbGVzIGVzcGVjw61maWNvcyBzZWfDum4gUGVzdGHDsWEgQWN0aXZhICovfVxuICAgICAgICAgICAgICB7dXNlcj8ucm9sZSAhPT0gJ0NMSUVOVCcgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIHsvKiBDb250cm9sZXMgcGFyYSBEaWFncmFtYSBVbmlmaWxhciAqL31cbiAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdVTklGSUxBUicgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXNNdWx0aVNlbGVjdE1vZGUoIWlzTXVsdGlTZWxlY3RNb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJZHMobmV3IFNldCgpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bib3JkZXIgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBweC0zLjUgcHktMiByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGgtOSBjdXJzb3ItcG9pbnRlciB0ZXh0LXhzICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzTXVsdGlTZWxlY3RNb2RlIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMC8xMCBib3JkZXItYW1iZXItNTAwLzQwIHRleHQtYW1iZXItNTAwJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS04NTAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tTcXVhcmUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IHtpc011bHRpU2VsZWN0TW9kZSA/ICdDYW5jZWxhciBTZWxlY2Npw7NuJyA6ICdTZWxlY2Npb25hciBWYXJpb3MnfVxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUaXBvRWxlbWVudG8oJ1RBQkxFUk8nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd0VsZW1lbnRvTW9kYWwodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMTAwIGZvbnQtc2VtaWJvbGQgaG92ZXI6Ymctc2xhdGUtODUwIGFjdGl2ZTpzY2FsZS05NSB0cmFuc2l0aW9uLWFsbCBweC0zLjUgcHktMiByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGgtOSBjdXJzb3ItcG9pbnRlciB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPiArIENyZWFyIEVsZW1lbnRvXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgey8qIENvbnRyb2xlcyBwYXJhIEluc3BlY2Npb25lcyAqL31cbiAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdFU1RSVUNUVVJBTCcgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0luc3BlY2Npb25Nb2RhbCh0cnVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIGhvdmVyOmJnLXNsYXRlLTg1MCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGwgcHgtMy41IHB5LTIgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBoLTkgY3Vyc29yLXBvaW50ZXIgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8QnVpbGRpbmcgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+ICsgQ3JlYXIgSW5zcGVjY2nDs25cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtpc011bHRpU2VsZWN0TW9kZSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcm91bmRlZC0yeGwgcC00IGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBhbmltYXRlLWZhZGVJbiBzaGFkb3ctbGcgc2hhZG93LWFtYmVyLTUwMC81XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctYW1iZXItNTAwIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgTW9kbyBTZWxlY2Npw7NuIE3Dumx0aXBsZTogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTUwMCBmb250LWJvbGRcIj57c2VsZWN0ZWRJZHMuc2l6ZX08L3N0cm9uZz4ge3NlbGVjdGVkSWRzLnNpemUgPT09IDEgPyAnZWxlbWVudG8gc2VsZWNjaW9uYWRvJyA6ICdlbGVtZW50b3Mgc2VsZWNjaW9uYWRvcyd9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIHNtOnctYXV0byBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2VsZWN0QWxsfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0yIGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGhvdmVyOnRleHQtc2xhdGUtMTAwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFNlbGVjY2lvbmFyIFRvZG9cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEZXNlbGVjdEFsbH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTMwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBob3Zlcjp0ZXh0LXNsYXRlLTEwMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBEZXNlbGVjY2lvbmFyIFRvZG9cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIHtzZWxlY3RlZElkcy5zaXplID4gMCAmJiB1c2VyPy5yb2xlICE9PSAnQ0xJRU5UJyAmJiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGVsZXRlU2VsZWN0ZWR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiBiZy1yZWQtOTUwLzQwIGhvdmVyOmJnLXJlZC05MDAvNjAgYm9yZGVyIGJvcmRlci1yZWQtODAwLzQwIHJvdW5kZWQteGwgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtcmVkLTQwMCBob3Zlcjp0ZXh0LXJlZC0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IEVsaW1pbmFyICh7c2VsZWN0ZWRJZHMuc2l6ZX0pXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRJc011bHRpU2VsZWN0TW9kZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZElkcyhuZXcgU2V0KCkpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogQ09OVEVOSURPIERFIFBFU1RBw5FBIEE6IElOU1BFQ0NJT05FUyAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ0VTVFJVQ1RVUkFMJyAmJiAoXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1tZCBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDBcIj5GaWNoYXMgZGUgSW5zcGVjY2lvbmVzIFTDqWNuaWNhczwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5JbnNwZWNjaW9uZXMgZGUgb2JyYXMgY2l2aWxlcywgdGVybW9ncmFmw61hLCBzaXN0ZW1hIGRlIGF0ZXJyYW1pZW50byAoU1BBVCkgeSB0YW5xdWVzIGRlIGNvbWJ1c3RpYmxlLjwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7ZmlsdGVyZWRJbnNwZWNjaW9uZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkSW5zcGVjY2lvbmVzLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHNlbGVjdGVkSWRzLmhhcyhpdGVtLmlkKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzTXVsdGlTZWxlY3RNb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVRvZ2dsZVNlbGVjdChpdGVtLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKGAvZW1wcmVzYS8ke2NvbXBhbnlJZH0vdGFibGVyby8ke2l0ZW0uaWR9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1zbGF0ZS05NTAgYm9yZGVyIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIG92ZXJmbG93LWhpZGRlbiBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCBob3ZlcjotdHJhbnNsYXRlLXktMC41IGdyb3VwIHJvdW5kZWQtMnhsIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3cteGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTXVsdGlTZWxlY3RNb2RlICYmIGlzU2VsZWN0ZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1hbWJlci01MDAgc2hhZG93LWFtYmVyLTUwMC81IHJpbmctMSByaW5nLWFtYmVyLTUwMC8yMCcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS04MDAvODAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMC82MCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0zMiB3LWZ1bGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS05MDAgdG8tc2xhdGUtOTAwLzQwIHJlbGF0aXZlIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlci1iIGJvcmRlci1zbGF0ZS05MDAvNTAgc2VsZWN0LW5vbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdWlsZGluZyBjbGFzc05hbWU9XCJ3LTkgaC05IHRleHQtYW1iZXItNTAwLzcwIGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB1cHBlcmNhc2UgZm9udC1ib2xkIHRyYWNraW5nLXdpZGVzdCBvcGFjaXR5LTM1IG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGlwb0VsZW1lbnRvID09PSAnVEVSTU9HUkFGSUNBJyA/ICdJbnNwZWNjacOzbiBUZXJtb2dyw6FmaWNhJyA6IGl0ZW0udGlwb0VsZW1lbnRvID09PSAnU0lTVEVNQV9BVEVSUkFNSUVOVE8nID8gJ1B1ZXN0YSBhIFRpZXJyYSAoU1BBVCknIDogaXRlbS50aXBvRWxlbWVudG8gPT09ICdUQU5RVUVfQ09NQlVTVElCTEUnID8gJ1RhbnF1ZSBkZSBDb21idXN0aWJsZScgOiAnSW5zcGVjY2nDs24gVmlzdWFsIC8gQ2l2aWwnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIGxlZnQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgYmctYW1iZXItOTUwLzkwIHRleHQtYW1iZXItNTAwIGJvcmRlciBib3JkZXItYW1iZXItODAwLzUwIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGlwb0VsZW1lbnRvID09PSAnVEVSTU9HUkFGSUNBJyA/ICfwn5SlIFRFUk1PR1JBRsONQScgOiBpdGVtLnRpcG9FbGVtZW50byA9PT0gJ1NJU1RFTUFfQVRFUlJBTUlFTlRPJyA/ICfwn5uh77iPIFNQQVQgQVRFUlJBTUlFTlRPJyA6IGl0ZW0udGlwb0VsZW1lbnRvID09PSAnVEFOUVVFX0NPTUJVU1RJQkxFJyA/ICfim70gVEFOUVVFIENPTUJVU1RJQkxFJyA6ICfwn4+iIFNVQkVTVEFDScOTTid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7IWlzTXVsdGlTZWxlY3RNb2RlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMyByaWdodC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYmxhY2sgdGV4dC1hbWJlci00MDAgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIHB4LTIuNSBweS0wLjUgcm91bmRlZC1sZyB0ZXh0LXhzIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSUQ6IHtpdGVtLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IGZsZXgtMSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgZ3JvdXAtaG92ZXI6dGV4dC1hbWJlci01MDAgdHJhbnNpdGlvbi1jb2xvcnMgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEVsZW1lbnRUaXRsZVdpdGhJZChpdGVtLm5vbWJyZSwgaXRlbS5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEgbXQtMyB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwLzYwIHB0LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGRcIj5VYmljYWNpw7NuOjwvc3Bhbj4ge2l0ZW0udWJpY2FjaW9ufTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGRcIj5UZW5zacOzbjo8L3NwYW4+IHtpdGVtLm5pdmVsVGVuc2lvbn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj48Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS02MDAgc2hyaW5rLTBcIiAvPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGZvbnQtYm9sZFwiPkZlY2hhOjwvc3Bhbj4ge2l0ZW0uZmVjaGF9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+PFVzZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS02MDAgc2hyaW5rLTBcIiAvPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGZvbnQtYm9sZFwiPkluc3BlY3Rvcjo8L3NwYW4+IHtpdGVtLmluc3BlY3Rvcn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBCYXJyYSBkZSBBdmFuY2UgeSBQb3JjZW50YWplIGRlIENvbXBsZXRpdHVkIChPYnMgNCkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMC84MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEF2YW5jZVByb2dyZXNzQmFyIGVsZW1lbnRvPXtpdGVtfSB0aXBvRWxlbWVudG89e2l0ZW0udGlwb0VsZW1lbnRvIHx8ICdTVUJFU1RBQ0lPTid9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQWNjaW9uZXMgQ1JVRCBEaXJlY3RhcyBlbiBUYXJqZXRhIChPYnMgMiB5IDI0KSAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxFbGVtZW50b0NhcmRBY3Rpb25zXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uRWRpdD17KCkgPT4gbmF2aWdhdGUoYC9lbXByZXNhLyR7Y29tcGFueUlkfS90YWJsZXJvLyR7aXRlbS5pZH1gKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25OZXdJbnNwZWN0aW9uPXsoKSA9PiBuYXZpZ2F0ZShgL2VtcHJlc2EvJHtjb21wYW55SWR9L3RhYmxlcm8vJHtpdGVtLmlkfWApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG9rID0gYXdhaXQgY29uZmlybSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0VsaW1pbmFyIEluc3BlY2Npw7NuJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGDCv0VzdMOhcyBzZWd1cm8gZGUgcXVlIGRlc2VhcyBlbGltaW5hciBsYSBpbnNwZWNjacOzbiBcIiR7aXRlbS5ub21icmV9XCI/YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdkYW5nZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uZmlybVRleHQ6ICdFbGltaW5hcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAob2spIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZVN1YmVzdGFjaW9uKHByb3llY3RvSWQsIGl0ZW0uaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHk9e3VzZXI/LnJvbGUgPT09ICdDTElFTlQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTE2IGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCB0ZXh0LWNlbnRlciBzcGFjZS15LTQgYmctc2xhdGUtOTUwLzIwXCI+XG4gICAgICAgICAgICAgICAgPEJ1aWxkaW5nIGNsYXNzTmFtZT1cInctMTIgaC0xMiB0ZXh0LXNsYXRlLTcwMCBteC1hdXRvXCIgLz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMSBmb250LXNhbnNcIj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMFwiPk5vIGhheSBpbnNwZWNjaW9uZXMgdMOpY25pY2FzPC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbWF4LXctc20gbXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICBDcmVhIHVuYSBmaWNoYSBkZSBJbnNwZWNjacOzbiBUw6ljbmljYSAoU3ViZXN0YWNpw7NuLCBUZXJtb2dyYWbDrWEsIFNQQVQgbyBUYW5xdWUgZGUgQ29tYnVzdGlibGUpLlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIENPTlRFTklETyBERSBQRVNUQcORQSBCOiBESUFHUkFNQSBVTklGSUxBUiAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ1VOSUZJTEFSJyAmJiAoXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1tZCBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDBcIj5FcXVpcG9zIFJlZ2lzdHJhZG9zIGVuIGVsIERpYWdyYW1hIFVuaWZpbGFyPC9oMj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+VGFibGVyb3MsIFRyYW5zZm9ybWFkb3JlcywgR2VuZXJhZG9yZXMsIFB1bnRvcyBkZSBTdW1pbmlzdHJvLCBNYWxsYXMgZGUgVGllcnJhIHkgVHJhbnNmZXJlbmNpYXMuPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dEaWFncmFtTW9kYWwodHJ1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIHB4LTQuNSBweS0yLjUgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCBhY3RpdmU6c2NhbGUtOTggY3Vyc29yLXBvaW50ZXIgc2VsZi1zdGFydCBtZDpzZWxmLWF1dG9cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTQgaC00IGZpbGwtc2xhdGUtOTUwXCIgLz4gVmVyIERpYWdyYW1hIEdyw6FmaWNvXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtmaWx0ZXJlZEVsZW1lbnRvcy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cbiAgICAgICAgICAgICAgICB7ZmlsdGVyZWRFbGVtZW50b3MubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBpc1RhYmxlcm8gPSBpdGVtLnRpcG9FbGVtZW50byA9PT0gJ1RBQkxFUk8nO1xuICAgICAgICAgICAgICAgICAgY29uc3QgaXNUcmFmbyA9IGl0ZW0udGlwb0VsZW1lbnRvID09PSAnVFJBTlNGT1JNQURPUic7XG4gICAgICAgICAgICAgICAgICBjb25zdCBpc0dlbiA9IGl0ZW0udGlwb0VsZW1lbnRvID09PSAnR0VORVJBRE9SJztcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzUHVlc3RhVGllcnJhID0gaXRlbS50aXBvRWxlbWVudG8gPT09ICdQVUVTVEFfVElFUlJBJztcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzVHJhbnNmZXIgPSBpdGVtLnRpcG9FbGVtZW50byA9PT0gJ1RSQU5TRkVSJztcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzUHVudG9TdW1pbmlzdHJvID0gaXRlbS50aXBvRWxlbWVudG8gPT09ICdQVU5UT19TVU1JTklTVFJPJztcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzQ2NtID0gaXRlbS50aXBvRWxlbWVudG8gPT09ICdDQ00nO1xuICAgICAgICAgICAgICAgICAgY29uc3QgaXNCYW5jbyA9IGl0ZW0udGlwb0VsZW1lbnRvID09PSAnQkFOQ09fQ09OREVOU0FET1InO1xuXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc011bHRpU2VsZWN0TW9kZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVUb2dnbGVTZWxlY3QoaXRlbS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZShgL2VtcHJlc2EvJHtjb21wYW55SWR9L3RhYmxlcm8vJHtpdGVtLmlkfWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctc2xhdGUtOTUwIGJvcmRlciBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBvdmVyZmxvdy1oaWRkZW4gY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSBncm91cCByb3VuZGVkLTJ4bCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LXhsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc011bHRpU2VsZWN0TW9kZSAmJiBzZWxlY3RlZElkcy5oYXMoaXRlbS5pZCkgXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1hbWJlci01MDAgc2hhZG93LWFtYmVyLTUwMC81IHJpbmctMSByaW5nLWFtYmVyLTUwMC8yMCcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS04MDAvODAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMC82MCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBDYWJlY2VyYSBkZSBUYXJqZXRhICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0zMiB3LWZ1bGwgYmctc2xhdGUtOTAwIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXItYiBib3JkZXItc2xhdGUtOTAwLzUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5mb3RvQmxvYiB8fCBpdGVtLmZvdG8gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTYWZlSW1hZ2UgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvYj17aXRlbS5mb3RvQmxvYn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2l0ZW0uZm90b30gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtpdGVtLm5vbWJyZX0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXIgZ3JvdXAtaG92ZXI6c2NhbGUtMTAyIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTUwMFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXNsYXRlLTcwMCBnYXAtMS41IHNlbGVjdC1ub25lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzVGFibGVybyAmJiA8WmFwIGNsYXNzTmFtZT1cInctOCBoLTggb3BhY2l0eS0yNSB0ZXh0LXNreS00MDBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNUcmFmbyAmJiA8Q3B1IGNsYXNzTmFtZT1cInctOCBoLTggb3BhY2l0eS0yNSB0ZXh0LXB1cnBsZS00MDBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNHZW4gJiYgPFphcCBjbGFzc05hbWU9XCJ3LTggaC04IG9wYWNpdHktMjUgdGV4dC1hbWJlci00MDBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNQdWVzdGFUaWVycmEgJiYgPFNoaWVsZEFsZXJ0IGNsYXNzTmFtZT1cInctOCBoLTggb3BhY2l0eS0yNSB0ZXh0LXRlYWwtNDAwXCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzVHJhbnNmZXIgJiYgPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJ3LTggaC04IG9wYWNpdHktMjUgdGV4dC1lbWVyYWxkLTQwMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1B1bnRvU3VtaW5pc3RybyAmJiA8R2F1Z2UgY2xhc3NOYW1lPVwidy04IGgtOCBvcGFjaXR5LTI1IHRleHQtYmx1ZS00MDBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNDY20gJiYgPENwdSBjbGFzc05hbWU9XCJ3LTggaC04IG9wYWNpdHktMjUgdGV4dC1hbWJlci00MDBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNCYW5jbyAmJiA8TGF5ZXJzIGNsYXNzTmFtZT1cInctOCBoLTggb3BhY2l0eS0yNSB0ZXh0LWVtZXJhbGQtNDAwXCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc1RhYmxlcm8gJiYgIWlzVHJhZm8gJiYgIWlzR2VuICYmICFpc1B1ZXN0YVRpZXJyYSAmJiAhaXNUcmFuc2ZlciAmJiAhaXNQdW50b1N1bWluaXN0cm8gJiYgIWlzQ2NtICYmICFpc0JhbmNvICYmIDxMYXllcnMgY2xhc3NOYW1lPVwidy04IGgtOCBvcGFjaXR5LTI1IHRleHQtc2xhdGUtNDAwXCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB1cHBlcmNhc2UgZm9udC1ib2xkIHRyYWNraW5nLXdpZGVzdCBvcGFjaXR5LTMwXCI+U2luIEltYWdlbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQmFkZ2VzIGRlIHRpcG8gZSBJRCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgbGVmdC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1RhYmxlcm8gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xIGJnLWFtYmVyLTk1MC85MCB0ZXh0LWFtYmVyLTUwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTgwMC81MCByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pqhIFBBTkVMIEVMw4lDVFJJQ09cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1RyYWZvICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zLjUgcHktMSBiZy1hbWJlci05NTAvOTAgdGV4dC1hbWJlci01MDAgYm9yZGVyIGJvcmRlci1hbWJlci04MDAvNTAgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCflIQgVFJBTlNGT1JNQURPUlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2lzR2VuICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zLjUgcHktMSBiZy1hbWJlci05NTAvOTAgdGV4dC1hbWJlci01MDAgYm9yZGVyIGJvcmRlci1hbWJlci04MDAvNTAgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCflIsgR0VORVJBRE9SXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNQdWVzdGFUaWVycmEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xIGJnLWFtYmVyLTk1MC85MCB0ZXh0LWFtYmVyLTUwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTgwMC81MCByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+boe+4jyBQVUVTVEEgQSBUSUVSUkFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1RyYW5zZmVyICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zLjUgcHktMSBiZy1hbWJlci05NTAvOTAgdGV4dC1hbWJlci01MDAgYm9yZGVyIGJvcmRlci1hbWJlci04MDAvNTAgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCflIAgVFJBTlNGRVJFTkNJQVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2lzUHVudG9TdW1pbmlzdHJvICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zLjUgcHktMSBiZy1hbWJlci05NTAvOTAgdGV4dC1hbWJlci01MDAgYm9yZGVyIGJvcmRlci1hbWJlci04MDAvNTAgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCflIwgUFRPLiBTVU1JTklTVFJPXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNDY20gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xIGJnLWFtYmVyLTk1MC85MCB0ZXh0LWFtYmVyLTUwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTgwMC81MCByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pqZ77iPIENDTSBNT1RPUkVTXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNCYW5jbyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMy41IHB5LTEgYmctYW1iZXItOTUwLzkwIHRleHQtYW1iZXItNTAwIGJvcmRlciBib3JkZXItYW1iZXItODAwLzUwIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICDimqEgQkFOQ08gQ09OREVOU0FET1JcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgeyFpc011bHRpU2VsZWN0TW9kZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJsYWNrIHRleHQtYW1iZXItNDAwIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBweC0yLjUgcHktMC41IHJvdW5kZWQtbGcgdGV4dC14cyBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIElEOiB7aXRlbS5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEluZGljYWRvciBkZSBjYXNpbGxhIGRlIHZlcmlmaWNhY2nDs24gcGFyYSBTZWxlY2Npw7NuIE3Dumx0aXBsZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc011bHRpU2VsZWN0TW9kZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyB6LTEwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkSWRzLmhhcyhpdGVtLmlkKSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwIGJvcmRlci1hbWJlci00MDAgdGV4dC1zbGF0ZS05NTAgc2hhZG93LW1kIHNoYWRvdy1hbWJlci01MDAvMjAnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAvOTAgYm9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTUwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRJZHMuaGFzKGl0ZW0uaWQpID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tTcXVhcmUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBib3JkZXIgYm9yZGVyLXNsYXRlLTYwMCByb3VuZGVkLXNtXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQ29udGVuaWRvIGRlIFRhcmpldGEgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgZmxleC0xIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgZ3JvdXAtaG92ZXI6dGV4dC1hbWJlci01MDAgdHJhbnNpdGlvbi1jb2xvcnMgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RWxlbWVudFRpdGxlV2l0aElkKGl0ZW0ubm9tYnJlLCBpdGVtLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgbXQtMyB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwLzYwIHB0LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGZvbnQtYm9sZFwiPlViaWNhY2nDs246PC9zcGFuPiB7aXRlbS51YmljYWNpb259PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkXCI+QWxpbWVudGFkbyBwb3I6PC9zcGFuPiB7aXRlbS5hbGltZW50YWRvUG9yIHx8ICdObyBkZWZpbmlkbyd9PC9wPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1vc3RyYXIgcmVzw7ptZW5lcyBlbnJpcXVlY2lkb3MgZGUgbGFzIGZpY2hhcyB0w6ljbmljYXMgcmVhbGVzICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1RhYmxlcm8gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1za3ktNDAwIGZvbnQtbW9ubyBmb250LXNlbWlib2xkIHRleHQtWzEwcHhdIGJnLXNreS05NTAvNDAgcC0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNreS05MDAvNDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pqhIENhcGFjaWRhZDoge2l0ZW0uZGF0b3NUZWNuaWNvcz8ubWF4UG9sZXMgfHwgMjR9IFBvbG9zICh7aXRlbS5kYXRvc1RlY25pY29zPy52b2x0YWplQWNvbWV0aWRhIHx8ICcyMDgvMTIwIFYnfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1RyYWZvICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTQwMCBmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LVsxMHB4XSBiZy1wdXJwbGUtOTUwLzQwIHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1wdXJwbGUtOTAwLzQwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKaoSB7aXRlbS5kYXRvc1RlY25pY29zPy5rdmEgfHwgJzUwMCBLVkEnfSB8IEdFIHtpdGVtLmRhdG9zVGVjbmljb3M/LmNvbmV4aW9uIHx8ICdFc3RyZWxsYS1Fc3RyZWxsYSd9ICh7aXRlbS5kYXRvc1RlY25pY29zPy52b2x0YWplUHJpbWFyaW8gfHwgJzEzLjgga1YnfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0dlbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTQwMCBmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LVsxMHB4XSBiZy1hbWJlci05NTAvNDAgcC0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWFtYmVyLTkwMC80MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDimqEge2l0ZW0uZGF0b3NUZWNuaWNvcz8ua3ZhIHx8ICc1ODAga1ZBJ30gfCB7aXRlbS5kYXRvc1RlY25pY29zPy52b2x0YWplR2VuZXJhY2lvbiB8fCAnMjA4IFYnfSB8IEJyZWFrZXIge2l0ZW0uZGF0b3NUZWNuaWNvcz8uYW1wZXJhamUgfHwgJzE2MDAgQSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNQdWVzdGFUaWVycmEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZWFsLTQwMCBmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LVsxMHB4XSBiZy10ZWFsLTk1MC80MCBwLTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItdGVhbC05MDAvNDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+boe+4jyBDb3JyaWVudGUgRnVnYToge2l0ZW0uZGF0b3NUZWNuaWNvcz8uY29ycmllbnRlRnVnYUFtcGVyaW9zIHx8ICc2LjQgQSd9IHwge2l0ZW0uZGF0b3NUZWNuaWNvcz8udGlwb01hbGxhIHx8ICdNYWxsYSBDb25jcmV0byd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNUcmFuc2ZlciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtbW9ubyBmb250LXNlbWlib2xkIHRleHQtWzEwcHhdIGJnLWVtZXJhbGQtOTUwLzQwIHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTkwMC80MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5SEIHtpdGVtLmRhdG9zVGVjbmljb3M/LmNhcGFjaWRhZEFtcGVyaW9zIHx8ICczMjAwIEEnfSB8IHtpdGVtLmRhdG9zVGVjbmljb3M/LnRpcG9UcmFuc2ZlcmVuY2lhIHx8ICdBVFMgWVVZRS1ZRVMxJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1B1bnRvU3VtaW5pc3RybyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNDAwIGZvbnQtbW9ubyBmb250LXNlbWlib2xkIHRleHQtWzEwcHhdIGJnLWJsdWUtOTUwLzQwIHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ibHVlLTkwMC80MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5SMIHtpdGVtLmRhdG9zVGVjbmljb3M/Lm5pdmVsVGVuc2lvbiB8fCAnMTMuOCBrVid9IHwge2l0ZW0uZGF0b3NUZWNuaWNvcz8uY2FyZ2FDb250cmF0YWRhS3ZhIHx8IGl0ZW0uZGF0b3NUZWNuaWNvcz8uY2FwYWNpZGFkQ29udHJhdGFkYUt2YSB8fCAnMTAwMCBrVkEnfSB8IHtpdGVtLmRhdG9zVGVjbmljb3M/LnRpcG9NZWRpY2lvbiB8fCAnTWVkaWNpw7NuIERpcmVjdGEgQlQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzQ2NtICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYW1iZXItNDAwIGZvbnQtbW9ubyBmb250LXNlbWlib2xkIHRleHQtWzEwcHhdIGJnLWFtYmVyLTk1MC80MCBwLTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYW1iZXItOTAwLzQwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKame+4jyBCYXJyYToge2l0ZW0uZGF0b3NUZWNuaWNvcz8uY2FwYWNpZGFkQmFycmFBbXBlcmlvcyB8fCAnMTIwMCBBJ30gfCB7aXRlbS5kYXRvc1RlY25pY29zPy5udW1lcm9HYXZldGFzIHx8IDh9IEdhdmV0YXMgKHtpdGVtLmRhdG9zVGVjbmljb3M/LnRlbnNpb25PcGVyYXRpdmEgfHwgJzQ4MCBWJ30pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNCYW5jbyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtbW9ubyBmb250LXNlbWlib2xkIHRleHQtWzEwcHhdIGJnLWVtZXJhbGQtOTUwLzQwIHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTkwMC80MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDimqEge2l0ZW0uZGF0b3NUZWNuaWNvcz8ucG90ZW5jaWFSZWFjdGl2YVRvdGFsIHx8ICcxNTAga1ZBUid9IHwge2l0ZW0uZGF0b3NUZWNuaWNvcz8ubnVtUGFzb3MgfHwgNn0gUGFzb3MgKHtpdGVtLmRhdG9zVGVjbmljb3M/LnRlbnNpb25Ob21pbmFsIHx8ICcyMDggVid9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCYXJyYSBkZSBBdmFuY2UgeSBQb3JjZW50YWplIGRlIENvbXBsZXRpdHVkIChPYnMgNCkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwLzgwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxBdmFuY2VQcm9ncmVzc0JhciBlbGVtZW50bz17aXRlbX0gdGlwb0VsZW1lbnRvPXtpdGVtLnRpcG9FbGVtZW50byB8fCAnVEFCTEVSTyd9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFjY2lvbmVzIENSVUQgRGlyZWN0YXMgZW4gVGFyamV0YSAoT2JzIDIgeSAyNCkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEVsZW1lbnRvQ2FyZEFjdGlvbnNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkVkaXQ9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRpbmdFbGVtZW50byhpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dFbGVtZW50b01vZGFsKHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25OZXdJbnNwZWN0aW9uPXsoKSA9PiBuYXZpZ2F0ZShgL2VtcHJlc2EvJHtjb21wYW55SWR9L3RhYmxlcm8vJHtpdGVtLmlkfWApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRGVsZXRlPXthc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBvayA9IGF3YWl0IGNvbmZpcm0oe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0VsaW1pbmFyIEVsZW1lbnRvJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYMK/RXN0w6FzIHNlZ3VybyBkZSBxdWUgZGVzZWFzIGVsaW1pbmFyIGVsIGVsZW1lbnRvIFwiJHtpdGVtLm5vbWJyZX1cIj9gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnZGFuZ2VyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uZmlybVRleHQ6ICdFbGltaW5hcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9rKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZUVsZW1lbnRvVW5pZmlsYXIocHJveWVjdG9JZCwgaXRlbS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seT17dXNlcj8ucm9sZSA9PT0gJ0NMSUVOVCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xNiBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgdGV4dC1jZW50ZXIgc3BhY2UteS00IGJnLXNsYXRlLTk1MC8yMFwiPlxuICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtc2xhdGUtNzAwIG14LWF1dG9cIiAvPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIGZvbnQtc2Fuc1wiPlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwXCI+Tm8gaGF5IGVxdWlwb3MgcmVnaXN0cmFkb3M8L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtYXgtdy1zbSBteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIFJlZ2lzdHJhIHVuIFRhYmxlcm8sIFRyYW5zZm9ybWFkb3IsIEdlbmVyYWRvciwgUHVlc3RhIGEgVGllcnJhIG8gVHJhbnNmZXIgZW4gZXN0ZSBwcm95ZWN0by5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICA8L21haW4+XG5cbiAgICAgIHsvKiBNT0RBTCBNVUxUSS1QTEFOVElMTEEgREUgRUxFTUVOVE9TIFVOSUZJTEFSRVMgKi99XG4gICAgICB7c2hvd0VsZW1lbnRvTW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctc2xhdGUtOTAwLzcwIGJhY2tkcm9wLWJsdXItc20gYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiIG9uQ2xpY2s9eygpID0+IHsgc2V0U2hvd0VsZW1lbnRvTW9kYWwoZmFsc2UpOyBzZXRFZGl0aW5nRWxlbWVudG8obnVsbCk7IH19IC8+XG4gICAgICAgICAgXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctbWQgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgcC02IG92ZXJmbG93LWhpZGRlbiBhbmltYXRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMjAwIG1heC1oLVs5MHZoXSBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+IHtlZGl0aW5nRWxlbWVudG8gPyBgRWRpdGFyIFBsYW50aWxsYTogJHtlZGl0aW5nRWxlbWVudG8ubm9tYnJlfWAgOiAnUmVnaXN0cmFyIFBsYW50aWxsYSBUw6ljbmljYSd9XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRTaG93RWxlbWVudG9Nb2RhbChmYWxzZSk7IHNldEVkaXRpbmdFbGVtZW50byhudWxsKTsgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBob3ZlcjpiZy1zbGF0ZS05MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNyZWF0ZUVsZW1lbnRvfSBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktNCBvdmVyZmxvdy15LWF1dG8gcHItMSBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBTZWxlY3RvciBkZSBUaXBvIGRlIEVsZW1lbnRvICg3IE9wY2lvbmVzIGRlIENhcGEgMSkgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIFRpcG8gZGUgRWxlbWVudG8gRWzDqWN0cmljb1xuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy0zIGdhcC0xLjUgYmctc2xhdGUtOTAwIHAtMS41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1bOXB4XVwiPlxuICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ1RBQkxFUk8nLCBsYWJlbDogJ+KaoSBQQU5FTCBFTMOJQ1RSSUNPJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnUFVOVE9fU1VNSU5JU1RSTycsIGxhYmVsOiAn8J+UjCBQVE8uIFNVTUlOSVNUUk8nIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdHRU5FUkFET1InLCBsYWJlbDogJ/CflIsgR0VORVJBRE9SJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnVFJBTlNGT1JNQURPUicsIGxhYmVsOiAn8J+UhCBUUkFOU0ZPUk1BRE9SJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnVFJBTlNGRVInLCBsYWJlbDogJ/CflIAgVFJBTlNGRVJFTkNJQScgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ0NDTScsIGxhYmVsOiAn4pqZ77iPIENDTSAoTU9UT1JFUyknIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdCQU5DT19DT05ERU5TQURPUicsIGxhYmVsOiAn4pqhIEJBTkNPIENPTkQuJyB9XG4gICAgICAgICAgICAgICAgICBdLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXt0LmlkfVxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRpcG9FbGVtZW50byh0LmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTIgZm9udC1ibGFjayByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aXBvRWxlbWVudG8gPT09IHQuaWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctbWQnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7dC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIE5vbWJyZSBkZXNjcmlwdGl2byAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgTm9tYnJlIGRlc2NyaXB0aXZvIGRlbCBlcXVpcG9cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtub21icmV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5vbWJyZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17YEVqLiAke1BSRUZJWF9NQVBbdGlwb0VsZW1lbnRvXSB8fCAnVEFCJ30tMTogTm9tYnJlIERlc2NyaXB0aXZvYH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGZvY3VzOnJpbmctMSByb3VuZGVkLXhsIHRleHQtc20gdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGgtMTEgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgbm9tYnJlRWxlbWVudG9EdXBsaWNhZG8gXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDAgZm9jdXM6cmluZy1yZWQtNTAwJyBcbiAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy1hbWJlci01MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIHtub21icmVFbGVtZW50b0R1cGxpY2FkbyAmJiAoXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXJlZC01NTAgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgbXQtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gTm9tYnJlIGR1cGxpY2FkbzogeWEgZXhpc3RlIGVzdGUgZXF1aXBvIGVuIGVsIHByb3llY3RvLlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBVYmljYWNpw7NuICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICBVYmljYWNpw7NuIEbDrXNpY2FcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3ViaWNhY2lvbn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VWJpY2FjaW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIFPDs3Rhbm8gU2FsYSBUw6ljbmljYSBvIEVzdGFjaW9uYW1pZW50byBFeHRlcmlvclwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC1zbSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXItc2xhdGUtNjAwIGgtMTEgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBBbGltZW50YWNpw7NuIEplcsOhcnF1aWNhIERpbsOhbWljYSAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8U2VsZWN0b3JBbGltZW50YWRvckplcmFycXVpY29cbiAgICAgICAgICAgICAgICAgIHByb3llY3RvSWQ9e3Byb3llY3RvSWR9XG4gICAgICAgICAgICAgICAgICB0YWJsZXJvQWN0dWFsSWQ9e2VkaXRpbmdFbGVtZW50bz8uaWR9XG4gICAgICAgICAgICAgICAgICBlbGVtZW50b3NMaXN0PXtlbGVtZW50b3N9XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YWxpbWVudGFkb1Bvcn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBzZXRBbGltZW50YWRvUG9yKHZhbCl9XG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIkFsaW1lbnRhZG8gUG9yIChQcm9jZWRlbmNpYSAvIEplcmFycXXDrWEpXCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWNjaW9uYXIgU3ViZXN0YWNpw7NuLCBUcmFmbywgQ0NNIG8gVGFibGVyby4uLlwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIENBTVBPUyBFU1BFQ8ONRklDT1MgU0VHw5pOIEVMIEVOVU0gKi99XG5cbiAgICAgICAgICAgICAgey8qIFRBQkxFUk8gKi99XG4gICAgICAgICAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdUQUJMRVJPJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIE7Dum1lcm8gTcOheGltbyBkZSBQb2xvc1xuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bWF4UG9sZXN9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNYXhQb2xlcyhwYXJzZUludChlLnRhcmdldC52YWx1ZSwgMTApIHx8IDApfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXNjcmliZSBlbCBucm8uIGRlIHBvbG9zXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTIvMyBweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBoLTExIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttYXhQb2xlc31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlLCAxMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsKSBzZXRNYXhQb2xlcyh2YWwpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzMgcHgtMyBweS0yLjUgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC1zbSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgaC0xMVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+LS0gRXN0w6FuZGFyIC0tPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17MTJ9PjEyIFBvbG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17MjR9PjI0IFBvbG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17MzB9PjMwIFBvbG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17NDJ9PjQyIFBvbG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17NDh9PjQ4IFBvbG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17NjB9PjYwIFBvbG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17NzJ9PjcyIFBvbG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17ODR9Pjg0IFBvbG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17OTZ9Pjk2IFBvbG9zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIFRSQU5TRk9STUFET1IgKi99XG4gICAgICAgICAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdUUkFOU0ZPUk1BRE9SJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlBvdGVuY2lhIEtWQTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2t2YVRyYWZvfSBvbkNoYW5nZT17KGUpID0+IHNldEt2YVRyYWZvKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFai4gNTAwIEtWQVwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPk1hcmNhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17bWFyY2FUcmFmb30gb25DaGFuZ2U9eyhlKSA9PiBzZXRNYXJjYVRyYWZvKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFai4gR0VcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5UaXBvIFRyYW5zZm9ybWFkb3I8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e3RpcG9UcmFmb30gb25DaGFuZ2U9eyhlKSA9PiBzZXRUaXBvVHJhZm8oZS50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFjZWl0ZVwiPkFjZWl0ZSAoU3VtZXJnaWRvIC8gRXh0ZXJpb3IpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU2Vjb1wiPlNlY28gKEVuY2Fwc3VsYWRvIC8gSW50ZXJpb3IpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUGVkZXN0YWxcIj5QZWRlc3RhbCAoQWNlaXRlKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlBvc3RlXCI+TW9udGFqZSBlbiBQb3N0ZSAoQWNlaXRlKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5Db25leGnDs248L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtjb25leGlvblRyYWZvfSBvbkNoYW5nZT17KGUpID0+IHNldENvbmV4aW9uVHJhZm8oZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiBFc3RyZWxsYSAtIEVzdHJlbGxhXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBHRU5FUkFET1IgKi99XG4gICAgICAgICAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdHRU5FUkFET1InICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+Q2FwYWNpZGFkIGtWQTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2t2YUdlbn0gb25DaGFuZ2U9eyhlKSA9PiBzZXRLdmFHZW4oZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiA1ODAga1ZBXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+Q29tYnVzdGlibGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e2NvbWJ1c3RpYmxlR2VufSBvbkNoYW5nZT17KGUpID0+IHNldENvbWJ1c3RpYmxlR2VuKGUudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJESUVTRUxcIj5EScOJU0VMIC8gR0FTT0lMPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiR0FTXCI+R0FTIE5BVFVSQUw8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJHQVNPTElOQVwiPkdBU09MSU5BPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5Wb2x0YWplIEdlbmVyYWNpw7NuPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17dm9sdGFqZUdlbn0gb25DaGFuZ2U9eyhlKSA9PiBzZXRWb2x0YWplR2VuKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFai4gMjA4IC8gMTIwIFZcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb250LW1vbm9cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5JbnRlcnJ1cHRvciBBbXBlcmFqZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2FtcGVyYWplR2VufSBvbkNoYW5nZT17KGUpID0+IHNldEFtcGVyYWplR2VuKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFai4gMTYwMCBBXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogUFVFU1RBIEEgVElFUlJBICovfVxuICAgICAgICAgICAgICB7dGlwb0VsZW1lbnRvID09PSAnUFVFU1RBX1RJRVJSQScgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5SZXNpc3RlbmNpYSAozqkpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17cmVzaXN0ZW5jaWFPaG1pb3N9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVzaXN0ZW5jaWFPaG1pb3MoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiAwLjUgzqlcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb250LW1vbm9cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5Db3JyaWVudGUgRnVnYSAoQSk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtjb3JyaWVudGVGdWdhfSBvbkNoYW5nZT17KGUpID0+IHNldENvcnJpZW50ZUZ1Z2EoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiA2LjQgQVwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ubyB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5UaXBvIGRlIE1hbGxhIC8gVWJpY2FjacOzbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXt0aXBvTWFsbGF9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGlwb01hbGxhKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFai4gTWFsbGEgZGViYWpvIGRlIGNvbmNyZXRvXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTBcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIFRSQU5TRkVSICovfVxuICAgICAgICAgICAgICB7dGlwb0VsZW1lbnRvID09PSAnVFJBTlNGRVInICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPkNhcGFjaWRhZCBBbXBlcmlvczwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtjYXBhY2lkYWRBbXBlcmlvc30gb25DaGFuZ2U9eyhlKSA9PiBzZXRDYXBhY2lkYWRBbXBlcmlvcyhlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIDMyMDAgQVwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlRpcG8gVHJhbnNmZXJlbmNpYTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e3RpcG9UcmFuc2ZlcmVuY2lhfSBvbkNoYW5nZT17KGUpID0+IHNldFRpcG9UcmFuc2ZlcmVuY2lhKGUudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQVVUT01BVElDQVwiPkFVVE9Nw4FUSUNBIChBVFMpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk1BTlVBTFwiPk1BTlVBTCAoTVRTKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBCQU5DTyBDT05ERU5TQURPUiAqL31cbiAgICAgICAgICAgICAge3RpcG9FbGVtZW50byA9PT0gJ0JBTkNPX0NPTkRFTlNBRE9SJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPkNhcGFjaWRhZCBUb3RhbCAoa1ZBUik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtrdmFyVG90YWx9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0S3ZhclRvdGFsKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFai4gMTUwIGtWQVJcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb250LW1vbm9cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5QYXNvcyAvIEVzY2Fsb25lczwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e3Bhc29zQ29uZGVuc2Fkb3J9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzb3NDb25kZW5zYWRvcihlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIDYgcGFzb3NcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb250LW1vbm9cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+VGlwbyBkZSBCYW5jbzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17dGlwb0JhbmNvfSBvbkNoYW5nZT17KGUpID0+IHNldFRpcG9CYW5jbyhlLnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQVVUT01BVElDT1wiPkFVVE9Nw4FUSUNPIChDT05UUk9MQURPUik8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJGSUpPXCI+RklKTzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5UZW5zacOzbiBPcGVyYXRpdmE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXt0ZW5zaW9uQmFuY299IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVuc2lvbkJhbmNvKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFai4gMjA4IFYgbyA0ODAgVlwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIFBVTlRPIERFIFNVTUlOSVNUUk8gKi99XG4gICAgICAgICAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdQVU5UT19TVU1JTklTVFJPJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgIHsvKiBUZW5zaW9uIHkgQ2FyZ2EgQ29udHJhdGFkYSAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgVGVuc2nDs24gZGUgU3VtaW5pc3RybyAoQ09WRU5JTiAxNTk6MTk5NylcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17VEVOU0lPTkVTX0NPVkVOSU5fVE9EQVMuaW5jbHVkZXMoc3VtaW5pc3Ryb1RlbnNpb24pID8gc3VtaW5pc3Ryb1RlbnNpb24gOiAoc3VtaW5pc3Ryb1RlbnNpb24gPyAnQ1VTVE9NJyA6ICcnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGUudGFyZ2V0LnZhbHVlICE9PSAnQ1VTVE9NJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U3VtaW5pc3Ryb1RlbnNpb24oZS50YXJnZXQudmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzIgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2Npb25lIHRlbnNpw7NuLi4uPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRncm91cCBsYWJlbD1cIkJhamEgVGVuc2nDs24gKEJUKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtURU5TSU9ORVNfQ09WRU5JTl8xNTlfQlQubWFwKHYgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3Z9IHZhbHVlPXt2fT57dn08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRncm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGdyb3VwIGxhYmVsPVwiTWVkaWEgVGVuc2nDs24gKE1UKVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtURU5TSU9ORVNfQ09WRU5JTl8xNTlfTVQubWFwKHYgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3Z9IHZhbHVlPXt2fT57dn08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRncm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNVU1RPTVwiPk90cmEgdGVuc2nDs24uLi48L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3N1bWluaXN0cm9UZW5zaW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN1bWluaXN0cm9UZW5zaW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMTMuOCBrViBvIDIwOC8xMjAgVlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS8yIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBDYXJnYSBDb250cmF0YWRhIChrVkEpXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1pbmlzdHJvQ2FwYWNpZGFkfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdW1pbmlzdHJvQ2FwYWNpZGFkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDEwMDAga1ZBIG8gNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFRpcG8gZGUgTWVkaWNpw7NuIEVsw6ljdHJpY2EgKE9icyAyMykgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC82MCBwLTMuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAg4pqhIFRpcG8gZGUgTWVkaWNpw7NuIEVsw6ljdHJpY2EgKE9ibGlnYXRvcmlvKVxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3N1bWluaXN0cm9UaXBvTWVkaWNpb259XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdW1pbmlzdHJvVGlwb01lZGljaW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk1lZGljacOzbiBEaXJlY3RhIChCYWphIFRlbnNpw7NuKVwiPjEuIE1lZGljacOzbiBEaXJlY3RhIChCYWphIFRlbnNpw7NuKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNZWRpY2nDs24gSW5kaXJlY3RhIEJUXCI+Mi4gTWVkaWNpw7NuIEluZGlyZWN0YSBCVCAoY29uIHRyYW5zZm9ybWFkb3JlcyBkZSBjb3JyaWVudGUgVENzKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNZWRpY2nDs24gSW5kaXJlY3RhIEFUL01UXCI+My4gTWVkaWNpw7NuIEluZGlyZWN0YSBBVC9NVCAoY29uIFRDcyB5IFRQcyBwYXJhIG1lZGlhL2FsdGEgdGVuc2nDs24pPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBCbG9xdWUgRW5sYWNlIENvcnBvZWxlYyAvIFJlZCBQw7pibGljYSAoT2JzIDIwKSAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzQwIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAvNjBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxHYXVnZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS00MDBcIiAvPiBBY29tZXRpZGEgZGUgU2VydmljaW8gLyBSZWQgQ29ycG9lbGVjXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlciB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c3VtaW5pc3Ryb0VubGFjZUNvcnBvZWxlY31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdW1pbmlzdHJvRW5sYWNlQ29ycG9lbGVjKGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIGJvcmRlci1zbGF0ZS03MDAgdGV4dC1hbWJlci01MDAgZm9jdXM6cmluZy1hbWJlci01MDAgaC00IHctNCBiZy1zbGF0ZS05MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGRcIj5FbmxhY2UgQWN0aXZvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIG1iLTFcIj5FbXByZXNhIERpc3RyaWJ1aWRvcmE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3N1bWluaXN0cm9FbXByZXNhfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN1bWluaXN0cm9FbXByZXNhKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gQ09SUE9FTEVDXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtOVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIG1iLTFcIj5UaXBvIGRlIEFjb21ldGlkYTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1pbmlzdHJvVGlwb0Fjb21ldGlkYX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdW1pbmlzdHJvVGlwb0Fjb21ldGlkYShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU3VidGVycsOhbmVhXCI+U3VidGVycsOhbmVhPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBw6lyZWFcIj5Bw6lyZWE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk1peHRhXCI+TWl4dGEgKEHDqXJlbyAtIFN1YnRlcnLDoW5lbyk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBtYi0xXCI+TsKwIENvbnRyYXRvIC8gTklDPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1pbmlzdHJvTnVtZXJvQ29udHJhdG99XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3VtaW5pc3Ryb051bWVyb0NvbnRyYXRvKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMTAwMDI4NDc1OVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTkgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVs5cHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgbWItMVwiPk7CsCBNZWRpZG9yPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1pbmlzdHJvTmljfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN1bWluaXN0cm9OaWMoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBNRUQtODgzOTIxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtOSBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBtYi0xXCI+UG9zdGUgLyBUcmFmbyBTZXJ2aWNpbzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VtaW5pc3Ryb1Bvc3RlVHJhZm99XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3VtaW5pc3Ryb1Bvc3RlVHJhZm8oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBQLTE0MiAvIFRyYWZvIDUwa1ZBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtOSBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogQ0NNIChDRU5UUk8gREUgQ09OVFJPTCBERSBNT1RPUkVTKSAqL31cbiAgICAgICAgICAgICAge3RpcG9FbGVtZW50byA9PT0gJ0NDTScgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5DYXBhY2lkYWQgQmFycmEgKEEpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17Y2NtQ2FwYWNpZGFkQmFycmF9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2NtQ2FwYWNpZGFkQmFycmEoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiAxMjAwIEFcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb250LW1vbm9cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5UZW5zacOzbiBPcGVyYXRpdmE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtjY21UZW5zaW9ufSBvbkNoYW5nZT17KGUpID0+IHNldENjbVRlbnNpb24oZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiA0ODAgVlwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5CcmVha2VyIFByaW5jaXBhbDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2NjbUJyZWFrZXJQcmluY2lwYWx9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2NtQnJlYWtlclByaW5jaXBhbChlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIDEyMDBBIDNQXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+TnJvLiBkZSBHYXZldGFzIC8gQnVja2V0czwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIxXCIgbWF4PVwiNDhcIiB2YWx1ZT17Y2NtTnVtZXJvR2F2ZXRhc30gb25DaGFuZ2U9eyhlKSA9PiBzZXRDY21OdW1lcm9HYXZldGFzKHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlLCAxMCkgfHwgMSl9IHBsYWNlaG9sZGVyPVwiOFwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIE9UUk8gKi99XG4gICAgICAgICAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdPVFJPJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIEVzcGVjaWZpY2FjaW9uZXMgVMOpY25pY2FzXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHRleHRhcmVhIHZhbHVlPXtkZXNjcmlwY2lvbk90cm99IG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGVzY3JpcGNpb25PdHJvKGUudGFyZ2V0LnZhbHVlKX0gcm93cz17M30gcGxhY2Vob2xkZXI9XCJEZXRhbGxlcyB0w6ljbmljb3MgYWRpY2lvbmFsZXMuLi5cIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTIuNSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSByZXNpemUtbm9uZVwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIE9ic2VydmFjaW9uZXMgZ2VuZXJhbGVzICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICBPYnNlcnZhY2lvbmVzIGRlbCBJbmZvcm1lIFTDqWNuaWNvXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtvYnNlcnZhY2lvbmVzR2VuZXJhbGVzfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRPYnNlcnZhY2lvbmVzR2VuZXJhbGVzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRldGFsbGVzIGRlbCBlc3RhZG8gZGUgbWFudGVuaW1pZW50bywgcG9sdm8sIGh1bWVkYWQgbyByZWNvbWVuZGFjaW9uZXMuLi5cIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0yLjUgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXItc2xhdGUtNjUwIHRyYW5zaXRpb24tYWxsIHJlc2l6ZS1ub25lXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRm90byBPZmZsaW5lIEJsb2IgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPENhbWVyYSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIEZvdG8gbyBJbWFnZW4gZGUgbGEgUGxhY2EgVMOpY25pY29cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHtwcmV2aWV3VXJsID8gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS05MDAgYXNwZWN0LXZpZGVvIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdyb3VwIHNoYWRvdy1tZCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17cHJldmlld1VybH0gYWx0PVwiVmlzdGEgcHJldmlhXCIgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm90b0Jsb2IobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldmlld1VybCkgVVJMLnJldm9rZU9iamVjdFVSTChwcmV2aWV3VXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFByZXZpZXdVcmwobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMiByaWdodC0yIHAtMS41IGJnLXNsYXRlLTk1MC84MCBob3ZlcjpiZy1yZWQtNjUwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LWZ1bGxcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctZnVsbCBoLTI0IGJvcmRlci0yIGJvcmRlci1zbGF0ZS04MDAgYm9yZGVyLWRhc2hlZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIGJnLXNsYXRlLTkwMC8yMCBob3ZlcjpiZy1zbGF0ZS05MDAvNDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbCBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHQtMyBwYi0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FtZXJhIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1zbGF0ZS01MDAgbWItMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQ1MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5Ub21hciBGb3RvPC9zcGFuPiBvIHN1YmlyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhcHR1cmU9XCJlbnZpcm9ubWVudFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW1hZ2VDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQm90b25lcyBkZSBhY2Npw7NuIGNvbiBlc3RpbG8gYW1hcmlsbG8gdW5pZmljYWRvICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFNob3dFbGVtZW50b01vZGFsKGZhbHNlKTsgc2V0RWRpdGluZ0VsZW1lbnRvKG51bGwpOyB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWxnIHRleHQtc2xhdGUtMzAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFpc0VsZW1lbnRvRm9ybVZhbGlkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGZvbnQtc2VtaWJvbGQgaG92ZXI6YmctYW1iZXItNDAwIGFjdGl2ZTpzY2FsZS05OCB0cmFuc2l0aW9uLWFsbCBweC00IHB5LTIuNSByb3VuZGVkLWxnIGZsZXggZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGgtMTAgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC14cyBjdXJzb3ItcG9pbnRlciBzaGFkb3ctbWQgZGlzYWJsZWQ6b3BhY2l0eS00MFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2VkaXRpbmdFbGVtZW50byA/ICdHdWFyZGFyIENhbWJpb3MnIDogJ0d1YXJkYXIgUGxhbnRpbGxhJ31cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogTU9EQUwgQ1JFQVIgSU5TUEVDQ0nDk04gVMOJQ05JQ0EgKENBUEEgMiAtIDQgSU5TUEVDQ0lPTkVTIFNFUEFSQURBUykgKi99XG4gICAgICB7c2hvd0luc3BlY2Npb25Nb2RhbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1zbGF0ZS05MDAvNzAgYmFja2Ryb3AtYmx1ci1zbSBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0luc3BlY2Npb25Nb2RhbChmYWxzZSl9IC8+XG4gICAgICAgICAgXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctbGcgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgcC02IG92ZXJmbG93LWhpZGRlbiBhbmltYXRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMjAwIG1heC1oLVs5MHZoXSBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxCdWlsZGluZyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz4gUmVnaXN0cmFyIEluc3BlY2Npw7NuIFTDqWNuaWNhIChDYXBhIDIpXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0luc3BlY2Npb25Nb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgaG92ZXI6Ymctc2xhdGUtOTAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS01MDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVDcmVhdGVJbnNwZWNjaW9ufSBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktNCBvdmVyZmxvdy15LWF1dG8gcHItMSBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBTZWxlY3RvciBkZSA0IEluc3BlY2Npb25lcyBTZXBhcmFkYXMgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIFRpcG8gZGUgSW5zcGVjY2nDs24gVMOpY25pY2FcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMS41IGJnLXNsYXRlLTkwMCBwLTEuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtWzEwcHhdXCI+XG4gICAgICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnQU1CSUVOVEFMX0ZJU0lDQScsIGxhYmVsOiAn8J+PoiBBTUJJRU5UQUwgTyBGw41TSUNBJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnVEVSTU9HUkFGSUNBJywgbGFiZWw6ICfwn4yh77iPIFRFUk1PR1LDgUZJQ0EnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdTSVNURU1BX0FURVJSQU1JRU5UTycsIGxhYmVsOiAn8J+boe+4jyBTSVNURU1BIEFURVJSQU1JRU5UTycgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ1RBTlFVRV9DT01CVVNUSUJMRScsIGxhYmVsOiAn4pu9IFRBTlFVRSBDT01CVVNUSUJMRScgfVxuICAgICAgICAgICAgICAgICAgXS5tYXAoKHQpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGtleT17dC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUaXBvSW5zcGVjY2lvbk1vZGFsKHQuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTIgcHgtMi41IGZvbnQtYm9sZCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aXBvSW5zcGVjY2lvbk1vZGFsID09PSB0LmlkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgc2hhZG93LW1kIGZvbnQtYmxhY2snIFxuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7dC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIENBTVBPUyBTRUfDmk4gQ0FEQSBJTlNQRUNDScOTTiBQT1IgU0VQQVJBRE8gKi99XG5cbiAgICAgICAgICAgICAgey8qIDEuIEFNQklFTlRBTCBPIEbDjVNJQ0EgKi99XG4gICAgICAgICAgICAgIHsodGlwb0luc3BlY2Npb25Nb2RhbCA9PT0gJ0FNQklFTlRBTF9GSVNJQ0EnIHx8IHRpcG9JbnNwZWNjaW9uTW9kYWwgPT09ICdTVUJFU1RBQ0lPTicpICYmIChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICBOb21icmUgZGUgbGEgU3ViZXN0YWNpw7NuIC8gU2FsYSBFbMOpY3RyaWNhXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdWJlc3RhY2lvbk5vbWJyZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN1YmVzdGFjaW9uTm9tYnJlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBTdWJlc3RhY2nDs24gUHJpbmNpcGFsIFPDs3Rhbm8gMlwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTMuNSBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgZm9jdXM6cmluZy0xIHJvdW5kZWQteGwgdGV4dC1zbSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgaC0xMSB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgbm9tYnJlSW5zcGVjY2lvbkR1cGxpY2FkbyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDAgZm9jdXM6cmluZy1yZWQtNTAwJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctYW1iZXItNTAwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICB7bm9tYnJlSW5zcGVjY2lvbkR1cGxpY2FkbyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1yZWQtNTUwIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG10LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBOb21icmUgZHVwbGljYWRvOiB5YSBleGlzdGUgZXN0YSBpbnNwZWNjacOzbi5cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICBVYmljYWNpw7NuIEbDrXNpY2FcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdWJlc3RhY2lvblViaWNhY2lvbn1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN1YmVzdGFjaW9uVWJpY2FjaW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBQYXRpbyBkZSBUcmFuc2Zvcm1hZG9yZXMgTm9ydGUgLyBTYWxhIEVsw6ljdHJpY2FcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBwbGFjZWhvbGRlci1zbGF0ZS02MDAgaC0xMSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICBOaXZlbCBkZSBUZW5zacOzbiAoa1YpXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bml2ZWxUZW5zaW9ufVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tml2ZWxUZW5zaW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAxMy44IGtWLCA0LjE2IGtWXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC1zbSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgaC0xMSBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIDIuIFRFUk1PR1LDgUZJQ0EgKi99XG4gICAgICAgICAgICAgIHt0aXBvSW5zcGVjY2lvbk1vZGFsID09PSAnVEVSTU9HUkFGSUNBJyAmJiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgTm9tYnJlIC8gVGFnIGRlIGxhIEluc3BlY2Npw7NuIFRlcm1vZ3LDoWZpY2FcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Rlcm1vTm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVybW9Ob21icmUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIElULTAxOiBUZXJtb2dyYWbDrWEgVGFibGVyb3MgUHJpbmNpcGFsZXNcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBoLTExIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5VYmljYWNpw7NuIC8gRXF1aXBvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17dGVybW9VYmljYWNpb259IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVybW9VYmljYWNpb24oZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiBJbnRlcnJ1cHRvciBQcmluY2lwYWwgVEFCLTAxXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5Dw6FtYXJhIFRlcm1vZ3LDoWZpY2E8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXt0ZXJtb0NhbWFyYX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRUZXJtb0NhbWFyYShlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIEZMSVIgRTgtWFQgLyBGbHVrZSBUaTQ4MFwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yLjUgYmctc2xhdGUtOTAwLzYwIHAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBtYi0xXCI+VC4gQW1iaWVudGUgKMKwQyk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgc3RlcD1cIjAuMVwiIHZhbHVlPXt0ZXJtb1RlbXBBbWJpZW50ZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRUZXJtb1RlbXBBbWJpZW50ZShlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiMjVcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMi41IHB5LTEuNSBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGZvbnQtbW9ubyBoLTlcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIG1iLTFcIj5ULiBQdW50byAowrBDKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiBzdGVwPVwiMC4xXCIgdmFsdWU9e3Rlcm1vVGVtcFB1bnRvQ2FsaWVudGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVybW9UZW1wUHVudG9DYWxpZW50ZShlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiNDguNVwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0yLjUgcHktMS41IGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC81MCByb3VuZGVkLWxnIHRleHQteHMgdGV4dC1hbWJlci00MDAgZm9udC1tb25vIGgtOSBmb250LWJvbGRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIG1iLTFcIj5ULiBSZWYgKMKwQyk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgc3RlcD1cIjAuMVwiIHZhbHVlPXt0ZXJtb1RlbXBSZWZ9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVybW9UZW1wUmVmKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCIzMFwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0yLjUgcHktMS41IGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgZm9udC1tb25vIGgtOVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBDw6FsY3VsbyBlbiB2aXZvIGRlIERlbHRhIFQgeSBTZXZlcmlkYWQgKi99XG4gICAgICAgICAgICAgICAgICB7dGVybW9UZW1wUHVudG9DYWxpZW50ZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIHAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGJsb2NrIHVwcGVyY2FzZSBmb250LWJvbGRcIj5HcmFkaWVudGUgVMOpcm1pY28gKM6UVCk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhwYXJzZUZsb2F0KHRlcm1vVGVtcFB1bnRvQ2FsaWVudGUgfHwgMCkgLSBwYXJzZUZsb2F0KHRlcm1vVGVtcFJlZiB8fCAwKSkudG9GaXhlZCgxKX0gwrBDXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBibG9jayB1cHBlcmNhc2UgZm9udC1ib2xkXCI+U2V2ZXJpZGFkIE5FVEEvTkZQQTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkdFZhbCA9IHBhcnNlRmxvYXQodGVybW9UZW1wUHVudG9DYWxpZW50ZSB8fCAwKSAtIHBhcnNlRmxvYXQodGVybW9UZW1wUmVmIHx8IDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZHRWYWwgPiA0MCkgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IGJnLXJlZC05NTAgYm9yZGVyIGJvcmRlci1yZWQtODAwIHRleHQtcmVkLTQwMCBmb250LWJsYWNrIHJvdW5kZWQtbGcgdGV4dC1bMTBweF1cIj5DUsONVElDQSAoJmd0OzQwwrBDKTwvc3Bhbj47XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkdFZhbCA+IDIwKSByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgYmctYW1iZXItOTUwIGJvcmRlciBib3JkZXItYW1iZXItODAwIHRleHQtYW1iZXItNDAwIGZvbnQtYmxhY2sgcm91bmRlZC1sZyB0ZXh0LVsxMHB4XVwiPkFMVEEgKDIxLTQwwrBDKTwvc3Bhbj47XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkdFZhbCA+IDEwKSByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgYmcteWVsbG93LTk1MCBib3JkZXIgYm9yZGVyLXllbGxvdy04MDAgdGV4dC15ZWxsb3ctNDAwIGZvbnQtYmxhY2sgcm91bmRlZC1sZyB0ZXh0LVsxMHB4XVwiPk1PREVSQURBICgxMS0yMMKwQyk8L3NwYW4+O1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgYmctZW1lcmFsZC05NTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTgwMCB0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYmxhY2sgcm91bmRlZC1sZyB0ZXh0LVsxMHB4XVwiPk5PUk1BTCAo4omkMTDCsEMpPC9zcGFuPjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKCl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogMy4gU0lTVEVNQSBERSBBVEVSUkFNSUVOVE8gKi99XG4gICAgICAgICAgICAgIHsodGlwb0luc3BlY2Npb25Nb2RhbCA9PT0gJ1NJU1RFTUFfQVRFUlJBTUlFTlRPJyB8fCB0aXBvSW5zcGVjY2lvbk1vZGFsID09PSAnUFVFU1RBX1RJRVJSQScpICYmIChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICBOb21icmUgLyBUYWcgZGVsIFNpc3RlbWEgZGUgQXRlcnJhbWllbnRvIChQQVQpXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXROb21icmUgfHwgc3ViZXN0YWNpb25Ob21icmV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7IHNldFBhdE5vbWJyZShlLnRhcmdldC52YWx1ZSk7IHNldFN1YmVzdGFjaW9uTm9tYnJlKGUudGFyZ2V0LnZhbHVlKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBQQVQtMDE6IE1hbGxhIFBvem8gUHJpbmNpcGFsIFRyYW5zZm9ybWFkb3JcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBoLTExIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFJlc2lzdGVuY2lhIE9obWlvcyAozqkpXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BhdFJlc2lzdGVuY2lhfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXRSZXNpc3RlbmNpYShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAyLjUgzqlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvNDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtYW1iZXItNDAwIGgtMTAgZm9udC1tb25vIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBNw6l0b2RvIE1lZGljacOzblxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BhdE1ldG9kb31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGF0TWV0b2RvKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ2HDrWRhIGRlIFBvdGVuY2lhbCAoNjIlKVwiPkNhw61kYSBkZSBQb3RlbmNpYWwgKDYyJSk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNw6l0b2RvIGRlIDMgUHVudG9zXCI+TcOpdG9kbyBkZSAzIFB1bnRvczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlBpbnphIGRlIFRpZXJyYSAoU2luIFBpY2FzKVwiPlBpbnphIGRlIFRpZXJyYSAoU2luIFBpY2FzKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk3DqXRvZG8gV2VubmVyICg0IFBpY2FzKVwiPk3DqXRvZG8gV2VubmVyICg0IFBpY2FzKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7cGF0UmVzaXN0ZW5jaWEgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIGZvbnQtYm9sZFwiPkNyaXRlcmlvIElFRUUgODAgLyBDw7NkaWdvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIHtwYXJzZUZsb2F0KHBhdFJlc2lzdGVuY2lhKSA+IDEwID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNDUwIGZvbnQtYm9sZFwiPuKaoO+4jyAmZ3Q7IDEwIM6pIChSZXF1aWVyZSBNYW50ZW5pbWllbnRvKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogcGFyc2VGbG9hdChwYXRSZXNpc3RlbmNpYSkgPiA1ID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hbWJlci00NTAgZm9udC1ib2xkXCI+8J+foSDiiaQgMTAgzqkgKEFjZXB0YWJsZSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00NTAgZm9udC1ib2xkXCI+4pyFIOKJpCA1IM6pIChFeGNlbGVudGUgcGFyYSBTdWJlc3RhY2nDs24pPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBUaXBvIGRlIFNpc3RlbWEgUEFUXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGF0VGlwb31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGF0VGlwbyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMFwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk1hbGxhIGNvbiBWYXJpbGxhc1wiPk1hbGxhIGNvbiBWYXJpbGxhcyBDb3BwZXJ3ZWxkPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUG96byBJbmRpdmlkdWFsXCI+UG96byBhIFRpZXJyYSBJbmRpdmlkdWFsPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQW5pbGxvIFBlcmltZXRyYWxcIj5BbmlsbG8gUGVyaW1ldHJhbCBFZGlmaWNpbzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk1hbGxhIFByb2Z1bmRhXCI+TWFsbGEgUHJvZnVuZGE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBUaXBvIGRlIFVuacOzblxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BhdFVuaW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXRVbmlvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMFwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNvbGRhZHVyYSBFeG90w6lybWljYSAoQ2Fkd2VsZClcIj5Tb2xkYWR1cmEgRXhvdMOpcm1pY2EgKENhZHdlbGQpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ29uZWN0b3IgTWVjw6FuaWNvIEJyb25jZVwiPkNvbmVjdG9yIE1lY8OhbmljbyBCcm9uY2U8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUZXJtaW5hbCBhIENvbXByZXNpw7NuXCI+VGVybWluYWwgYSBDb21wcmVzacOzbjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIFViaWNhY2nDs24gRsOtc2ljYVxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BhdFViaWNhY2lvbiB8fCBzdWJlc3RhY2lvblViaWNhY2lvbn1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHsgc2V0UGF0VWJpY2FjaW9uKGUudGFyZ2V0LnZhbHVlKTsgc2V0U3ViZXN0YWNpb25VYmljYWNpb24oZS50YXJnZXQudmFsdWUpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIFBhdGlvIGRlIFRyYW5zZm9ybWFkb3JlcyBOb3J0ZSAvIFNhbGEgRWzDqWN0cmljYVwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHRleHQtc20gdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIHBsYWNlaG9sZGVyLXNsYXRlLTYwMCBoLTExIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiA0LiBUQU5RVUUgREUgQ09NQlVTVElCTEUgKi99XG4gICAgICAgICAgICAgIHt0aXBvSW5zcGVjY2lvbk1vZGFsID09PSAnVEFOUVVFX0NPTUJVU1RJQkxFJyAmJiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgTm9tYnJlIC8gVGFnIGRlbCBUYW5xdWUgZGUgQ29tYnVzdGlibGVcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhbnF1ZU5vbWJyZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRhbnF1ZU5vbWJyZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gVEstMDE6IFRhbnF1ZSBQcmluY2lwYWwgRGnDqXNlbCBHZW5lcmFkb3JcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBoLTExIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5UaXBvIGRlIENvbWJ1c3RpYmxlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXt0YW5xdWVUaXBvQ29tYnVzdGlibGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGFucXVlVGlwb0NvbWJ1c3RpYmxlKGUudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJESUVTRUxcIj5EacOpc2VsIC8gR2Fzb2lsPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiR0FTT0xJTkFcIj5HYXNvbGluYTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkdBU1wiPkdhcyBMaWN1YWRvIC8gR0xQPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPkNhcGFjaWRhZCBUb3RhbCAoTCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgdmFsdWU9e3RhbnF1ZUNhcGFjaWRhZExpdHJvc30gb25DaGFuZ2U9eyhlKSA9PiBzZXRUYW5xdWVDYXBhY2lkYWRMaXRyb3MoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiAyMDAwXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+Tml2ZWwgQWN0dWFsICglKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwXCIgbWF4PVwiMTAwXCIgdmFsdWU9e3RhbnF1ZU5pdmVsUG9yY2VudGFqZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRUYW5xdWVOaXZlbFBvcmNlbnRhamUoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiA3NVwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPkNvbnN1bW8gR2VuZXJhZG9yIChML2gpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIHN0ZXA9XCIwLjFcIiB2YWx1ZT17dGFucXVlQ29uc3Vtb0xofSBvbkNoYW5nZT17KGUpID0+IHNldFRhbnF1ZUNvbnN1bW9MaChlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIDQ1XCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIEF1dG9ub23DrWEgQ2FsY3VsYWRhIGVuIFRpZW1wbyBSZWFsICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBibG9jayB1cHBlcmNhc2UgZm9udC1ib2xkXCI+TGl0cm9zIEFjdHVhbGVzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1hbWJlci00MDAgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgeygocGFyc2VGbG9hdCh0YW5xdWVDYXBhY2lkYWRMaXRyb3MgfHwgMCkgKiBwYXJzZUZsb2F0KHRhbnF1ZU5pdmVsUG9yY2VudGFqZSB8fCAwKSkgLyAxMDApLnRvRml4ZWQoMCl9IExpdHJvc1xuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGJsb2NrIHVwcGVyY2FzZSBmb250LWJvbGRcIj5BdXRvbm9tw61hIEVzdGltYWRhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJsYWNrIHRleHQtZW1lcmFsZC00MDAgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgeygocGFyc2VGbG9hdCh0YW5xdWVDYXBhY2lkYWRMaXRyb3MgfHwgMCkgKiAocGFyc2VGbG9hdCh0YW5xdWVOaXZlbFBvcmNlbnRhamUgfHwgMCkgLyAxMDApKSAvIChwYXJzZUZsb2F0KHRhbnF1ZUNvbnN1bW9MaCkgfHwgMSkpLnRvRml4ZWQoMSl9IEhvcmFzXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5EaXF1ZSBDb250ZW5jacOzbiAxMTAlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXt0YW5xdWVEaXF1ZTExMH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRUYW5xdWVEaXF1ZTExMChlLnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ09ORk9STUVcIj5Db25mb3JtZSAoMTEwJSBzaW4gZnVnYXMpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTk9fQ09ORk9STUVcIj5ObyBDb25mb3JtZSAvIFNpbiBEaXF1ZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNPTl9GSUxUUkFDSU9OXCI+Q29uIEZpbHRyYWNpw7NuIC8gRmlzdXJhczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5VYmljYWNpw7NuIFRhbnF1ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e3RhbnF1ZVViaWNhY2lvbn0gb25DaGFuZ2U9eyhlKSA9PiBzZXRUYW5xdWVVYmljYWNpb24oZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiBTYWxhIGRlIEdlbmVyYWNpw7NuIC8gRXh0ZXJpb3JcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIEluc3BlY3RvciBFbmNhcmdhZG8gKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIE5vbWJyZSBkZWwgSW5zcGVjdG9yIEVuY2FyZ2Fkb1xuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17aW5zcGVjdG9yTmFtZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW5zcGVjdG9yTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBJbmcuIEp1YW4gQ2FybG9zXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBwbGFjZWhvbGRlci1zbGF0ZS02MDAgaC0xMSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0luc3BlY2Npb25Nb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS0zMDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWlzSW5zcGVjY2lvbkZvcm1WYWxpZH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIGhvdmVyOmJnLWFtYmVyLTQwMCBhY3RpdmU6c2NhbGUtOTggdHJhbnNpdGlvbi1hbGwgcHgtNCBweS0yLjUgcm91bmRlZC1sZyBmbGV4IGZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBoLTEwIHdoaXRlc3BhY2Utbm93cmFwIHRleHQteHMgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kIGRpc2FibGVkOm9wYWNpdHktNDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENyZWFyIEZpY2hhIGRlIEluc3BlY2Npw7NuXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE1PREFMIENSRUFSIFBVTlRPIERFIE1FRElDScOTTiAqL31cbiAgICAgIHtzaG93UHVudG9NZWRpY2lvbk1vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLXNsYXRlLTkwMC83MCBiYWNrZHJvcC1ibHVyLXNtIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UHVudG9NZWRpY2lvbk1vZGFsKGZhbHNlKX0gLz5cbiAgICAgICAgICBcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1tZCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBwLTYgb3ZlcmZsb3ctaGlkZGVuIGFuaW1hdGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPEdhdWdlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPiBSZWdpc3RyYXIgUHVudG8gZGUgTWVkaWNpw7NuXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1B1bnRvTWVkaWNpb25Nb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgaG92ZXI6Ymctc2xhdGUtOTAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS01MDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVDcmVhdGVQdW50b01lZGljaW9ufSBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgTm9tYnJlIC8gSWRlbnRpZmljYWRvciBkZWwgUHVudG9cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwdW50b01lZGljaW9uTm9tYnJlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQdW50b01lZGljaW9uTm9tYnJlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIFB1bnRvIGRlIE1lZGljacOzbiBQcmluY2lwYWwgQWNvbWV0aWRhIDFcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC1zbSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgaC0xMSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgTm9tYnJlIGRlbCBVc3VhcmlvIC8gUmF6w7NuIFNvY2lhbFxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cHVudG9NZWRpY2lvblVzdWFyaW99XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFB1bnRvTWVkaWNpb25Vc3VhcmlvKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIENvbWVyY2lhbCBTZWxlY3RyaWMgQy5BLlwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBwbGFjZWhvbGRlci1zbGF0ZS02MDAgaC0xMSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgTsKwIGRlIENvbnRyYXRvIC8gTklDXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwdW50b01lZGljaW9uTklDfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQdW50b01lZGljaW9uTklDKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIE5JQy04NDkyMDE5XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHRleHQtc20gdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGgtMTEgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICBOaXZlbCBkZSBUZW5zacOzbiBkZSBDb250cmF0b1xuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3B1bnRvTWVkaWNpb25OaXZlbFRlbnNpb259XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFB1bnRvTWVkaWNpb25OaXZlbFRlbnNpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC1zbSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgaC0xMSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkJhamEgVGVuc2nDs25cIj5CYWphIFRlbnNpw7NuPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTWVkaWEgVGVuc2nDs25cIj5NZWRpYSBUZW5zacOzbjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFsdGEgVGVuc2nDs25cIj5BbHRhIFRlbnNpw7NuPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dQdW50b01lZGljaW9uTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWxnIHRleHQtc2xhdGUtMzAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFwdW50b01lZGljaW9uTm9tYnJlLnRyaW0oKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBmb250LXNlbWlib2xkIGhvdmVyOmJnLWFtYmVyLTQwMCBhY3RpdmU6c2NhbGUtOTggdHJhbnNpdGlvbi1hbGwgcHgtNCBweS0yLjUgcm91bmRlZC1sZyBmbGV4IGZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBoLTEwIHdoaXRlc3BhY2Utbm93cmFwIHRleHQteHMgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kIGRpc2FibGVkOm9wYWNpdHktNDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFJlZ2lzdHJhciBQdW50b1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNb2RhbCBkZSBFZGljacOzbiBkZSBQcm95ZWN0byAqL31cbiAgICAgIHtzaG93RWRpdFByb3llY3RvTW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctc2xhdGUtOTUwLzgwIGJhY2tkcm9wLWJsdXItc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IHotNTAgYW5pbWF0ZS1mYWRlSW4gZm9udC1zYW5zIHRleHQteHNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBtYXgtdy1sZyB3LWZ1bGwgbWF4LWgtWzkwdmhdIG92ZXJmbG93LXktYXV0byBzaGFkb3ctMnhsIHAtNiBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8QnVpbGRpbmcgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTUwMFwiIC8+IEVkaXRhciBQcm95ZWN0b1xuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dFZGl0UHJveWVjdG9Nb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgaG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVVcGRhdGVQcm95ZWN0b1N1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtc2VtaWJvbGQgbWItMVwiPk5vbWJyZSBkZWwgUHJveWVjdG88L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdFByb3llY3RvTm9tYnJlfSBcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdFByb3llY3RvTm9tYnJlKGUudGFyZ2V0LnZhbHVlKX0gXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0zIHB5LTIgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1zZW1pYm9sZCBtYi0xXCI+RGVzY3JpcGNpw7NuIGRlbCBQcm95ZWN0bzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhIFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRQcm95ZWN0b0Rlc2NyaXBjaW9ufSBcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdFByb3llY3RvRGVzY3JpcGNpb24oZS50YXJnZXQudmFsdWUpfSBcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0zIHB5LTIgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgdGV4dC1zbSBoLTIwXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LXNlbWlib2xkIG1iLTFcIj5EaXJlY2Npw7NuIC8gVWJpY2FjacOzbiBGw61zaWNhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRQcm95ZWN0b0RpcmVjY2lvbn0gXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRQcm95ZWN0b0RpcmVjY2lvbihlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCB0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgcHQtNCBtdC00IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1za3ktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVsxMHB4XVwiPlJlc3BvbnNhYmxlIGRlbCBQcm95ZWN0bzwvaDQ+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW0gbWItMVwiPk5vbWJyZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0UmVzcG9uc2FibGVOb21icmV9IFxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdFJlc3BvbnNhYmxlTm9tYnJlKGUudGFyZ2V0LnZhbHVlKX0gXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bSBtYi0xXCI+VGVsw6lmb25vPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRSZXNwb25zYWJsZVRlbGVmb25vfSBcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRSZXNwb25zYWJsZVRlbGVmb25vKGUudGFyZ2V0LnZhbHVlKX0gXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bSBtYi0xXCI+RW1haWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCIgXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRSZXNwb25zYWJsZUVtYWlsfSBcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRSZXNwb25zYWJsZUVtYWlsKGUudGFyZ2V0LnZhbHVlKX0gXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCIgXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93RWRpdFByb3llY3RvTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtMzUwIGhvdmVyOmJnLXNsYXRlLTgwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLWxnIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGhvdmVyOmJnLWFtYmVyLTQwMCBhY3RpdmU6c2NhbGUtOTggcm91bmRlZC1sZyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgc2hhZG93LW1kIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBHdWFyZGFyIENhbWJpb3NcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE1vZGFsIHBhcmEgQ3JlYXIgTnVldm8gQ0NNICovfVxuICAgICAge3Nob3dDY21Nb2RhbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1zbGF0ZS05NTAvODAgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNiB3LWZ1bGwgbWF4LXctbWQgc2hhZG93LTJ4bCBzcGFjZS15LTQgZm9udC1zYW5zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxDcHUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+IFJlZ2lzdHJhciBOdWV2byBDQ01cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q2NtTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSBob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNyZWF0ZUNjbVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS00IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIG1iLTEgdXBwZXJjYXNlIHRleHQtWzEwcHhdXCI+XG4gICAgICAgICAgICAgICAgICBUYWcgLyBJZGVudGlmaWNhY2nDs24gZGVsIENDTSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTUwMFwiPio8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjY21Ob21icmV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENjbU5vbWJyZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBDQ00tSU5ELTAxXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgbWItMSB1cHBlcmNhc2UgdGV4dC1bMTBweF1cIj5cbiAgICAgICAgICAgICAgICAgIFBsYW50YSAvIEluc3RhbGFjacOzblxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y2NtUGxhbnRhfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDY21QbGFudGEoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gUGxhbnRhIFByb2Nlc2Fkb3JhIENlbnRyYWxcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgbWItMSB1cHBlcmNhc2UgdGV4dC1bMTBweF1cIj5cbiAgICAgICAgICAgICAgICAgIMOBcmVhIC8gUHJvY2Vzb1xuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y2NtQXJlYX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2NtQXJlYShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBDdWFydG8gRWzDqWN0cmljbyAwMiAtIEJvbWJlb1wiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dDY21Nb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQteGwgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgc2hhZG93LW1kXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDcmVhciBDQ01cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuXG5cbiAgICAgIHsvKiBNb2RhbCBkZWwgRGlhZ3JhbWEgVW5pZmlsYXIgR3LDoWZpY28gKi99XG4gICAgICA8TW9kYWxEaWFncmFtYVVuaWZpbGFyXG4gICAgICAgIGlzT3Blbj17c2hvd0RpYWdyYW1Nb2RhbH1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd0RpYWdyYW1Nb2RhbChmYWxzZSl9XG4gICAgICAgIGVsZW1lbnRvcz17ZWxlbWVudG9zfVxuICAgICAgICBjb21wYW55TmFtZT17Y29tcGFueT8ubm9tYnJlfVxuICAgICAgICBwcm95ZWN0b0lkPXtwcm95ZWN0b0lkfVxuICAgICAgICBjb21wYW55SWQ9e2NvbXBhbnlJZH1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBNb2RhbCBkZSBDZW50cm8gZGUgQXl1ZGEsIFJvbGVzIHkgTm9ybWF0aXZhIEVsw6ljdHJpY2EgKENhcGEgNykgKi99XG4gICAgICA8SGVscE1vZGFsXG4gICAgICAgIGlzT3Blbj17c2hvd0hlbHBNb2RhbH1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd0hlbHBNb2RhbChmYWxzZSl9XG4gICAgICAvPlxuXG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBQcm95ZWN0b1ZpZXc7XG4iXX0=