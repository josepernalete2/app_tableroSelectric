import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MetrologiaElectricaSection.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { Activity, Zap, Shield, Gauge } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/MetrologiaElectricaSection.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
export default function MetrologiaElectricaSection({ mediciones = {}, datosTecnicos, onChange, onNestedChange, readOnly = false, isEditing, titulo = "Metrología Eléctrica y Medición de Red (COVENIN 159)", subtitulo = "Lectura de tensiones desglosadas L-L, L-N y 5 canales de corriente de servicio" }) {
	const isReadOnly = isEditing !== undefined ? !isEditing : Boolean(readOnly);
	// Extraer mediciones desde prop directa o desde datosTecnicos
	const currentMediciones = mediciones && typeof mediciones === "object" ? mediciones : datosTecnicos?.mediciones && typeof datosTecnicos.mediciones === "object" ? datosTecnicos.mediciones : datosTecnicos || {};
	const handleChange = (field, val) => {
		if (isReadOnly) return;
		const updated = {
			...currentMediciones,
			[field]: val
		};
		if (typeof onNestedChange === "function") {
			onNestedChange("mediciones", field, val);
		}
		if (typeof onChange === "function") {
			onChange(updated, field, val);
		}
	};
	// Voltajes Línea-Línea (L-L)
	const v_l1_l2 = currentMediciones.v_l1_l2 ?? currentMediciones.v_ab ?? currentMediciones.vab ?? "";
	const v_l1_l3 = currentMediciones.v_l1_l3 ?? currentMediciones.v_ca ?? currentMediciones.vac ?? currentMediciones.v_l3_l1 ?? "";
	const v_l2_l3 = currentMediciones.v_l2_l3 ?? currentMediciones.v_bc ?? currentMediciones.vbc ?? "";
	// Voltajes Línea-Neutro (L-N)
	const v_l1_n = currentMediciones.v_l1_n ?? currentMediciones.v_an ?? currentMediciones.van ?? "";
	const v_l2_n = currentMediciones.v_l2_n ?? currentMediciones.v_bn ?? currentMediciones.vbn ?? "";
	const v_l3_n = currentMediciones.v_l3_n ?? currentMediciones.v_cn ?? currentMediciones.vcn ?? "";
	// 5 Canales de Corriente (A)
	const i_l1 = currentMediciones.i_l1 ?? currentMediciones.ia ?? currentMediciones.il1 ?? "";
	const i_l2 = currentMediciones.i_l2 ?? currentMediciones.ib ?? currentMediciones.il2 ?? "";
	const i_l3 = currentMediciones.i_l3 ?? currentMediciones.ic ?? currentMediciones.il3 ?? "";
	const i_n = currentMediciones.i_n ?? currentMediciones.in ?? currentMediciones.ineutro ?? "";
	const i_pe = currentMediciones.i_pe ?? currentMediciones.ipe ?? currentMediciones.itierra ?? "";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-slate-950/60 border border-slate-800 rounded-2xl p-4 md:p-5 space-y-4 print:bg-white print:border-gray-300 print:text-black font-sans",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-850 pb-3",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs md:text-sm font-extrabold uppercase tracking-wider text-amber-400 flex items-center gap-2 print:text-slate-900",
					children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 13
					}, this), titulo]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 11
				}, this), subtitulo && /* @__PURE__ */ _jsxDEV("p", {
					className: "text-[10px] text-slate-400 font-mono mt-0.5 print:text-slate-600",
					children: subtitulo
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] font-mono font-bold px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded self-start sm:self-auto",
					children: "Norma COVENIN 159:1997"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900/50 border border-slate-800/80 rounded-xl p-3.5 space-y-2.5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between border-b border-slate-800 pb-1.5",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[11px] font-bold text-slate-300 uppercase tracking-wide flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 15
							}, this), " Voltajes de Línea (L-L)"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[9px] font-mono text-slate-500 font-bold",
							children: "Unidad: Voltios (V)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-3 gap-2 text-xs font-mono",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 mb-1",
								children: "V L1-L2"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: isReadOnly,
								value: v_l1_l2,
								onChange: (e) => handleChange("v_l1_l2", e.target.value),
								placeholder: "Ej. 208",
								className: "w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-lg px-2.5 py-1.5 text-slate-100 text-center text-xs outline-none transition-all disabled:opacity-60 disabled:cursor-not-allowed"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 mb-1",
								children: "V L1-L3"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: isReadOnly,
								value: v_l1_l3,
								onChange: (e) => handleChange("v_l1_l3", e.target.value),
								placeholder: "Ej. 208",
								className: "w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-lg px-2.5 py-1.5 text-slate-100 text-center text-xs outline-none transition-all disabled:opacity-60 disabled:cursor-not-allowed"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 mb-1",
								children: "V L2-L3"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: isReadOnly,
								value: v_l2_l3,
								onChange: (e) => handleChange("v_l2_l3", e.target.value),
								placeholder: "Ej. 208",
								className: "w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-lg px-2.5 py-1.5 text-slate-100 text-center text-xs outline-none transition-all disabled:opacity-60 disabled:cursor-not-allowed"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900/50 border border-slate-800/80 rounded-xl p-3.5 space-y-2.5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between border-b border-slate-800 pb-1.5",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[11px] font-bold text-slate-300 uppercase tracking-wide flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(Gauge, { className: "w-3.5 h-3.5 text-cyan-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 15
							}, this), " Voltajes de Fase (L-N)"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[9px] font-mono text-slate-500 font-bold",
							children: "Unidad: Voltios (V)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-3 gap-2 text-xs font-mono",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 mb-1",
								children: "V L1-N"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: isReadOnly,
								value: v_l1_n,
								onChange: (e) => handleChange("v_l1_n", e.target.value),
								placeholder: "Ej. 120",
								className: "w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-lg px-2.5 py-1.5 text-slate-100 text-center text-xs outline-none transition-all disabled:opacity-60 disabled:cursor-not-allowed"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 mb-1",
								children: "V L2-N"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: isReadOnly,
								value: v_l2_n,
								onChange: (e) => handleChange("v_l2_n", e.target.value),
								placeholder: "Ej. 120",
								className: "w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-lg px-2.5 py-1.5 text-slate-100 text-center text-xs outline-none transition-all disabled:opacity-60 disabled:cursor-not-allowed"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 mb-1",
								children: "V L3-N"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: isReadOnly,
								value: v_l3_n,
								onChange: (e) => handleChange("v_l3_n", e.target.value),
								placeholder: "Ej. 120",
								className: "w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-lg px-2.5 py-1.5 text-slate-100 text-center text-xs outline-none transition-all disabled:opacity-60 disabled:cursor-not-allowed"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900/50 border border-slate-800/80 rounded-xl p-3.5 space-y-2.5",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between border-b border-slate-800 pb-1.5",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[11px] font-bold text-slate-300 uppercase tracking-wide flex items-center gap-1.5",
						children: [/* @__PURE__ */ _jsxDEV(Shield, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 13
						}, this), " Cinco Canales de Corriente (Fases, Neutro y Tierra)"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 170,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[9px] font-mono text-slate-500 font-bold",
						children: "Unidad: Amperios (A)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 169,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs font-mono",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-[10px] font-bold text-amber-400 mb-1 flex items-center gap-1",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 15
							}, this), " I Línea 1 (I_L1)"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							disabled: isReadOnly,
							value: i_l1,
							onChange: (e) => handleChange("i_l1", e.target.value),
							placeholder: "Ej. 650",
							className: "w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-lg px-2 py-1.5 text-slate-100 text-center text-xs outline-none font-bold disabled:opacity-60 disabled:cursor-not-allowed"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-[10px] font-bold text-amber-400 mb-1 flex items-center gap-1",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 191,
								columnNumber: 15
							}, this), " I Línea 2 (I_L2)"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							disabled: isReadOnly,
							value: i_l2,
							onChange: (e) => handleChange("i_l2", e.target.value),
							placeholder: "Ej. 630",
							className: "w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-lg px-2 py-1.5 text-slate-100 text-center text-xs outline-none font-bold disabled:opacity-60 disabled:cursor-not-allowed"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-[10px] font-bold text-amber-400 mb-1 flex items-center gap-1",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 15
							}, this), " I Línea 3 (I_L3)"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 203,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							disabled: isReadOnly,
							value: i_l3,
							onChange: (e) => handleChange("i_l3", e.target.value),
							placeholder: "Ej. 640",
							className: "w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-lg px-2 py-1.5 text-slate-100 text-center text-xs outline-none font-bold disabled:opacity-60 disabled:cursor-not-allowed"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-[10px] font-bold text-cyan-400 mb-1 flex items-center gap-1",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-cyan-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 15
							}, this), " I Neutro (I_N)"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 216,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							disabled: isReadOnly,
							value: i_n,
							onChange: (e) => handleChange("i_n", e.target.value),
							placeholder: "Ej. 35",
							className: "w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-lg px-2 py-1.5 text-cyan-300 text-center text-xs outline-none font-bold disabled:opacity-60 disabled:cursor-not-allowed"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 219,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "col-span-2 sm:col-span-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-emerald-400 mb-1 flex items-center gap-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 230,
									columnNumber: 15
								}, this), " I Tierra (I_PE)"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 229,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								disabled: isReadOnly,
								value: i_pe,
								onChange: (e) => handleChange("i_pe", e.target.value),
								placeholder: "Ej. 0.5",
								className: "w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-lg px-2 py-1.5 text-emerald-300 text-center text-xs outline-none font-bold disabled:opacity-60 disabled:cursor-not-allowed"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 228,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 175,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 168,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 57,
		columnNumber: 5
	}, this);
}
_c = MetrologiaElectricaSection;
var _c;
$RefreshReg$(_c, "MetrologiaElectricaSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/MetrologiaElectricaSection.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/MetrologiaElectricaSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/MetrologiaElectricaSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/MetrologiaElectricaSection.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsVUFBVSxLQUFLLFFBQVEsYUFBYTs7O0FBRTdDLGVBQWUsU0FBUywyQkFBMkIsRUFDakQsYUFBYSxDQUFDLEdBQ2QsZUFDQSxVQUNBLGdCQUNBLFdBQVcsT0FDWCxXQUNBLFNBQVMsd0RBQ1QsWUFBWSxvRkFDWDtDQUNELE1BQU0sYUFBYSxjQUFjLFlBQVksQ0FBQyxZQUFZLFFBQVEsUUFBUTs7Q0FHMUUsTUFBTSxvQkFBcUIsY0FBYyxPQUFPLGVBQWUsV0FDM0QsYUFDQyxlQUFlLGNBQWMsT0FBTyxjQUFjLGVBQWUsV0FDaEUsY0FBYyxhQUNiLGlCQUFpQixDQUFDO0NBRXpCLE1BQU0sZ0JBQWdCLE9BQU8sUUFBUTtFQUNuQyxJQUFJLFlBQVk7RUFDaEIsTUFBTSxVQUFVO0dBQ2QsR0FBRztJQUNGLFFBQVE7RUFDWDtFQUVBLElBQUksT0FBTyxtQkFBbUIsWUFBWTtHQUN4QyxlQUFlLGNBQWMsT0FBTyxHQUFHO0VBQ3pDO0VBRUEsSUFBSSxPQUFPLGFBQWEsWUFBWTtHQUNsQyxTQUFTLFNBQVMsT0FBTyxHQUFHO0VBQzlCO0NBQ0Y7O0NBR0EsTUFBTSxVQUFVLGtCQUFrQixXQUFXLGtCQUFrQixRQUFRLGtCQUFrQixPQUFPO0NBQ2hHLE1BQU0sVUFBVSxrQkFBa0IsV0FBVyxrQkFBa0IsUUFBUSxrQkFBa0IsT0FBTyxrQkFBa0IsV0FBVztDQUM3SCxNQUFNLFVBQVUsa0JBQWtCLFdBQVcsa0JBQWtCLFFBQVEsa0JBQWtCLE9BQU87O0NBR2hHLE1BQU0sU0FBUyxrQkFBa0IsVUFBVSxrQkFBa0IsUUFBUSxrQkFBa0IsT0FBTztDQUM5RixNQUFNLFNBQVMsa0JBQWtCLFVBQVUsa0JBQWtCLFFBQVEsa0JBQWtCLE9BQU87Q0FDOUYsTUFBTSxTQUFTLGtCQUFrQixVQUFVLGtCQUFrQixRQUFRLGtCQUFrQixPQUFPOztDQUc5RixNQUFNLE9BQU8sa0JBQWtCLFFBQVEsa0JBQWtCLE1BQU0sa0JBQWtCLE9BQU87Q0FDeEYsTUFBTSxPQUFPLGtCQUFrQixRQUFRLGtCQUFrQixNQUFNLGtCQUFrQixPQUFPO0NBQ3hGLE1BQU0sT0FBTyxrQkFBa0IsUUFBUSxrQkFBa0IsTUFBTSxrQkFBa0IsT0FBTztDQUN4RixNQUFNLE1BQU0sa0JBQWtCLE9BQU8sa0JBQWtCLE1BQU0sa0JBQWtCLFdBQVc7Q0FDMUYsTUFBTSxPQUFPLGtCQUFrQixRQUFRLGtCQUFrQixPQUFPLGtCQUFrQixXQUFXO0NBRTdGLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUNFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLHlCQUEwQjs7OztlQUN4QyxNQUNDOzs7OztjQUNILGFBQ0Msd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVjtJQUNBOzs7O1lBRUY7Ozs7Y0FDTCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUF3STtJQUVsSjs7OztZQUNIOzs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsNkJBQThCOzs7O2lCQUFDLDBCQUMvQzs7Ozs7Z0JBQ04sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWdEO01BQXlCOzs7O2NBQ3RGOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFrRDtPQUFjOzs7O2lCQUNqRix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPO1FBQ1AsV0FBVyxNQUFNLGFBQWEsV0FBVyxFQUFFLE9BQU8sS0FBSztRQUN2RCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFrRDtPQUFjOzs7O2lCQUNqRix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPO1FBQ1AsV0FBVyxNQUFNLGFBQWEsV0FBVyxFQUFFLE9BQU8sS0FBSztRQUN2RCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFrRDtPQUFjOzs7O2lCQUNqRix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPO1FBQ1AsV0FBVyxNQUFNLGFBQWEsV0FBVyxFQUFFLE9BQU8sS0FBSztRQUN2RCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O01BQ0Y7Ozs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsNEJBQTZCOzs7O2lCQUFDLHlCQUMzQzs7Ozs7Z0JBQ04sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWdEO01BQXlCOzs7O2NBQ3RGOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFrRDtPQUFhOzs7O2lCQUNoRix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPO1FBQ1AsV0FBVyxNQUFNLGFBQWEsVUFBVSxFQUFFLE9BQU8sS0FBSztRQUN0RCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFrRDtPQUFhOzs7O2lCQUNoRix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPO1FBQ1AsV0FBVyxNQUFNLGFBQWEsVUFBVSxFQUFFLE9BQU8sS0FBSztRQUN0RCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFrRDtPQUFhOzs7O2lCQUNoRix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPO1FBQ1AsV0FBVyxNQUFNLGFBQWEsVUFBVSxFQUFFLE9BQU8sS0FBSztRQUN0RCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O01BQ0Y7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsK0JBQWdDOzs7O2dCQUFDLHNEQUMvQzs7Ozs7ZUFDTix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBZ0Q7S0FBMEI7Ozs7YUFDdkY7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxvQ0FBMEM7Ozs7aUJBQUMsbUJBQ3REOzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLFVBQVU7T0FDVixPQUFPO09BQ1AsV0FBVyxNQUFNLGFBQWEsUUFBUSxFQUFFLE9BQU8sS0FBSztPQUNwRCxhQUFZO09BQ1osV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O01BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLG9DQUEwQzs7OztpQkFBQyxtQkFDdEQ7Ozs7O2dCQUNQLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsVUFBVTtPQUNWLE9BQU87T0FDUCxXQUFXLE1BQU0sYUFBYSxRQUFRLEVBQUUsT0FBTyxLQUFLO09BQ3BELGFBQVk7T0FDWixXQUFVO01BQ1g7Ozs7Y0FDRTs7Ozs7TUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsb0NBQTBDOzs7O2lCQUFDLG1CQUN0RDs7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxVQUFVO09BQ1YsT0FBTztPQUNQLFdBQVcsTUFBTSxhQUFhLFFBQVEsRUFBRSxPQUFPLEtBQUs7T0FDcEQsYUFBWTtPQUNaLFdBQVU7TUFDWDs7OztjQUNFOzs7OztNQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxtQ0FBeUM7Ozs7aUJBQUMsaUJBQ3JEOzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLFVBQVU7T0FDVixPQUFPO09BQ1AsV0FBVyxNQUFNLGFBQWEsT0FBTyxFQUFFLE9BQU8sS0FBSztPQUNuRCxhQUFZO09BQ1osV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxzQ0FBNEM7Ozs7a0JBQUMsa0JBQ3hEOzs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVU7UUFDVixPQUFPO1FBQ1AsV0FBVyxNQUFNLGFBQWEsUUFBUSxFQUFFLE9BQU8sS0FBSztRQUNwRCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7OztLQUNGOzs7OztZQUNGOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWV0cm9sb2dpYUVsZWN0cmljYVNlY3Rpb24uanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBBY3Rpdml0eSwgWmFwLCBTaGllbGQsIEdhdWdlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWV0cm9sb2dpYUVsZWN0cmljYVNlY3Rpb24oe1xuICBtZWRpY2lvbmVzID0ge30sXG4gIGRhdG9zVGVjbmljb3MsXG4gIG9uQ2hhbmdlLFxuICBvbk5lc3RlZENoYW5nZSxcbiAgcmVhZE9ubHkgPSBmYWxzZSxcbiAgaXNFZGl0aW5nLFxuICB0aXR1bG8gPSBcIk1ldHJvbG9nw61hIEVsw6ljdHJpY2EgeSBNZWRpY2nDs24gZGUgUmVkIChDT1ZFTklOIDE1OSlcIixcbiAgc3VidGl0dWxvID0gXCJMZWN0dXJhIGRlIHRlbnNpb25lcyBkZXNnbG9zYWRhcyBMLUwsIEwtTiB5IDUgY2FuYWxlcyBkZSBjb3JyaWVudGUgZGUgc2VydmljaW9cIlxufSkge1xuICBjb25zdCBpc1JlYWRPbmx5ID0gaXNFZGl0aW5nICE9PSB1bmRlZmluZWQgPyAhaXNFZGl0aW5nIDogQm9vbGVhbihyZWFkT25seSk7XG5cbiAgLy8gRXh0cmFlciBtZWRpY2lvbmVzIGRlc2RlIHByb3AgZGlyZWN0YSBvIGRlc2RlIGRhdG9zVGVjbmljb3NcbiAgY29uc3QgY3VycmVudE1lZGljaW9uZXMgPSAobWVkaWNpb25lcyAmJiB0eXBlb2YgbWVkaWNpb25lcyA9PT0gJ29iamVjdCcpXG4gICAgPyBtZWRpY2lvbmVzXG4gICAgOiAoZGF0b3NUZWNuaWNvcz8ubWVkaWNpb25lcyAmJiB0eXBlb2YgZGF0b3NUZWNuaWNvcy5tZWRpY2lvbmVzID09PSAnb2JqZWN0JylcbiAgICAgID8gZGF0b3NUZWNuaWNvcy5tZWRpY2lvbmVzXG4gICAgICA6IChkYXRvc1RlY25pY29zIHx8IHt9KTtcblxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZmllbGQsIHZhbCkgPT4ge1xuICAgIGlmIChpc1JlYWRPbmx5KSByZXR1cm47XG4gICAgY29uc3QgdXBkYXRlZCA9IHtcbiAgICAgIC4uLmN1cnJlbnRNZWRpY2lvbmVzLFxuICAgICAgW2ZpZWxkXTogdmFsXG4gICAgfTtcblxuICAgIGlmICh0eXBlb2Ygb25OZXN0ZWRDaGFuZ2UgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIG9uTmVzdGVkQ2hhbmdlKCdtZWRpY2lvbmVzJywgZmllbGQsIHZhbCk7XG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiBvbkNoYW5nZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgb25DaGFuZ2UodXBkYXRlZCwgZmllbGQsIHZhbCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIFZvbHRhamVzIEzDrW5lYS1Mw61uZWEgKEwtTClcbiAgY29uc3Qgdl9sMV9sMiA9IGN1cnJlbnRNZWRpY2lvbmVzLnZfbDFfbDIgPz8gY3VycmVudE1lZGljaW9uZXMudl9hYiA/PyBjdXJyZW50TWVkaWNpb25lcy52YWIgPz8gJyc7XG4gIGNvbnN0IHZfbDFfbDMgPSBjdXJyZW50TWVkaWNpb25lcy52X2wxX2wzID8/IGN1cnJlbnRNZWRpY2lvbmVzLnZfY2EgPz8gY3VycmVudE1lZGljaW9uZXMudmFjID8/IGN1cnJlbnRNZWRpY2lvbmVzLnZfbDNfbDEgPz8gJyc7XG4gIGNvbnN0IHZfbDJfbDMgPSBjdXJyZW50TWVkaWNpb25lcy52X2wyX2wzID8/IGN1cnJlbnRNZWRpY2lvbmVzLnZfYmMgPz8gY3VycmVudE1lZGljaW9uZXMudmJjID8/ICcnO1xuXG4gIC8vIFZvbHRhamVzIEzDrW5lYS1OZXV0cm8gKEwtTilcbiAgY29uc3Qgdl9sMV9uID0gY3VycmVudE1lZGljaW9uZXMudl9sMV9uID8/IGN1cnJlbnRNZWRpY2lvbmVzLnZfYW4gPz8gY3VycmVudE1lZGljaW9uZXMudmFuID8/ICcnO1xuICBjb25zdCB2X2wyX24gPSBjdXJyZW50TWVkaWNpb25lcy52X2wyX24gPz8gY3VycmVudE1lZGljaW9uZXMudl9ibiA/PyBjdXJyZW50TWVkaWNpb25lcy52Ym4gPz8gJyc7XG4gIGNvbnN0IHZfbDNfbiA9IGN1cnJlbnRNZWRpY2lvbmVzLnZfbDNfbiA/PyBjdXJyZW50TWVkaWNpb25lcy52X2NuID8/IGN1cnJlbnRNZWRpY2lvbmVzLnZjbiA/PyAnJztcblxuICAvLyA1IENhbmFsZXMgZGUgQ29ycmllbnRlIChBKVxuICBjb25zdCBpX2wxID0gY3VycmVudE1lZGljaW9uZXMuaV9sMSA/PyBjdXJyZW50TWVkaWNpb25lcy5pYSA/PyBjdXJyZW50TWVkaWNpb25lcy5pbDEgPz8gJyc7XG4gIGNvbnN0IGlfbDIgPSBjdXJyZW50TWVkaWNpb25lcy5pX2wyID8/IGN1cnJlbnRNZWRpY2lvbmVzLmliID8/IGN1cnJlbnRNZWRpY2lvbmVzLmlsMiA/PyAnJztcbiAgY29uc3QgaV9sMyA9IGN1cnJlbnRNZWRpY2lvbmVzLmlfbDMgPz8gY3VycmVudE1lZGljaW9uZXMuaWMgPz8gY3VycmVudE1lZGljaW9uZXMuaWwzID8/ICcnO1xuICBjb25zdCBpX24gPSBjdXJyZW50TWVkaWNpb25lcy5pX24gPz8gY3VycmVudE1lZGljaW9uZXMuaW4gPz8gY3VycmVudE1lZGljaW9uZXMuaW5ldXRybyA/PyAnJztcbiAgY29uc3QgaV9wZSA9IGN1cnJlbnRNZWRpY2lvbmVzLmlfcGUgPz8gY3VycmVudE1lZGljaW9uZXMuaXBlID8/IGN1cnJlbnRNZWRpY2lvbmVzLml0aWVycmEgPz8gJyc7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTQgbWQ6cC01IHNwYWNlLXktNCBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0zMDAgcHJpbnQ6dGV4dC1ibGFjayBmb250LXNhbnNcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04NTAgcGItM1wiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIG1kOnRleHQtc20gZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHByaW50OnRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgICAge3RpdHVsb31cbiAgICAgICAgICA8L2gzPlxuICAgICAgICAgIHtzdWJ0aXR1bG8gJiYgKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIG10LTAuNSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPlxuICAgICAgICAgICAgICB7c3VidGl0dWxvfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1ib2xkIHB4LTIgcHktMC41IGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8yMCByb3VuZGVkIHNlbGYtc3RhcnQgc206c2VsZi1hdXRvXCI+XG4gICAgICAgICAgTm9ybWEgQ09WRU5JTiAxNTk6MTk5N1xuICAgICAgICA8L3NwYW4+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgIHsvKiBCTE9RVUUgMTogVEVOU0lPTkVTIERFIEzDjU5FQSAoTC1MKSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgcm91bmRlZC14bCBwLTMuNSBzcGFjZS15LTIuNVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItMS41XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICA8QWN0aXZpdHkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci00MDBcIiAvPiBWb2x0YWplcyBkZSBMw61uZWEgKEwtTClcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNTAwIGZvbnQtYm9sZFwiPlVuaWRhZDogVm9sdGlvcyAoVik8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yIHRleHQteHMgZm9udC1tb25vXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIG1iLTFcIj5WIEwxLUwyPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1JlYWRPbmx5fVxuICAgICAgICAgICAgICAgIHZhbHVlPXt2X2wxX2wyfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKCd2X2wxX2wyJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDIwOFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCB0ZXh0LWNlbnRlciB0ZXh0LXhzIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWFsbCBkaXNhYmxlZDpvcGFjaXR5LTYwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgbWItMVwiPlYgTDEtTDM8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUmVhZE9ubHl9XG4gICAgICAgICAgICAgICAgdmFsdWU9e3ZfbDFfbDN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoJ3ZfbDFfbDMnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMjA4XCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIHRleHQtY2VudGVyIHRleHQteHMgb3V0bGluZS1ub25lIHRyYW5zaXRpb24tYWxsIGRpc2FibGVkOm9wYWNpdHktNjAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+ViBMMi1MMzwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNSZWFkT25seX1cbiAgICAgICAgICAgICAgICB2YWx1ZT17dl9sMl9sM31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoYW5nZSgndl9sMl9sMycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAyMDhcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgdGV4dC1jZW50ZXIgdGV4dC14cyBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS02MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBCTE9RVUUgMjogVEVOU0lPTkVTIERFIEZBU0UgKEwtTikgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHJvdW5kZWQteGwgcC0zLjUgc3BhY2UteS0yLjVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTEuNVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgPEdhdWdlIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtY3lhbi00MDBcIiAvPiBWb2x0YWplcyBkZSBGYXNlIChMLU4pXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGRcIj5VbmlkYWQ6IFZvbHRpb3MgKFYpPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMiB0ZXh0LXhzIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+ViBMMS1OPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1JlYWRPbmx5fVxuICAgICAgICAgICAgICAgIHZhbHVlPXt2X2wxX259XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoJ3ZfbDFfbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAxMjBcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9jdXM6Ym9yZGVyLWN5YW4tNTAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCB0ZXh0LWNlbnRlciB0ZXh0LXhzIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWFsbCBkaXNhYmxlZDpvcGFjaXR5LTYwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgbWItMVwiPlYgTDItTjwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNSZWFkT25seX1cbiAgICAgICAgICAgICAgICB2YWx1ZT17dl9sMl9ufVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKCd2X2wyX24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMTIwXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZvY3VzOmJvcmRlci1jeWFuLTUwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgdGV4dC1jZW50ZXIgdGV4dC14cyBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS02MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIG1iLTFcIj5WIEwzLU48L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUmVhZE9ubHl9XG4gICAgICAgICAgICAgICAgdmFsdWU9e3ZfbDNfbn1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoYW5nZSgndl9sM19uJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDEyMFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBmb2N1czpib3JkZXItY3lhbi01MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIHRleHQtY2VudGVyIHRleHQteHMgb3V0bGluZS1ub25lIHRyYW5zaXRpb24tYWxsIGRpc2FibGVkOm9wYWNpdHktNjAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQkxPUVVFIDM6IENJTkNPIENBTkFMRVMgREUgQ09SUklFTlRFICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgcm91bmRlZC14bCBwLTMuNSBzcGFjZS15LTIuNVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTEuNVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC00MDBcIiAvPiBDaW5jbyBDYW5hbGVzIGRlIENvcnJpZW50ZSAoRmFzZXMsIE5ldXRybyB5IFRpZXJyYSlcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkXCI+VW5pZGFkOiBBbXBlcmlvcyAoQSk8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTUgZ2FwLTIuNSB0ZXh0LXhzIGZvbnQtbW9ub1wiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctYW1iZXItNTAwXCI+PC9zcGFuPiBJIEzDrW5lYSAxIChJX0wxKVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc1JlYWRPbmx5fVxuICAgICAgICAgICAgICB2YWx1ZT17aV9sMX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoJ2lfbDEnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDY1MFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLWxnIHB4LTIgcHktMS41IHRleHQtc2xhdGUtMTAwIHRleHQtY2VudGVyIHRleHQteHMgb3V0bGluZS1ub25lIGZvbnQtYm9sZCBkaXNhYmxlZDpvcGFjaXR5LTYwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctYW1iZXItNTAwXCI+PC9zcGFuPiBJIEzDrW5lYSAyIChJX0wyKVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc1JlYWRPbmx5fVxuICAgICAgICAgICAgICB2YWx1ZT17aV9sMn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoJ2lfbDInLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDYzMFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLWxnIHB4LTIgcHktMS41IHRleHQtc2xhdGUtMTAwIHRleHQtY2VudGVyIHRleHQteHMgb3V0bGluZS1ub25lIGZvbnQtYm9sZCBkaXNhYmxlZDpvcGFjaXR5LTYwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctYW1iZXItNTAwXCI+PC9zcGFuPiBJIEzDrW5lYSAzIChJX0wzKVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc1JlYWRPbmx5fVxuICAgICAgICAgICAgICB2YWx1ZT17aV9sM31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoJ2lfbDMnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDY0MFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLWxnIHB4LTIgcHktMS41IHRleHQtc2xhdGUtMTAwIHRleHQtY2VudGVyIHRleHQteHMgb3V0bGluZS1ub25lIGZvbnQtYm9sZCBkaXNhYmxlZDpvcGFjaXR5LTYwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtY3lhbi00MDAgbWItMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1jeWFuLTQwMFwiPjwvc3Bhbj4gSSBOZXV0cm8gKElfTilcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNSZWFkT25seX1cbiAgICAgICAgICAgICAgdmFsdWU9e2lfbn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoJ2lfbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMzVcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZvY3VzOmJvcmRlci1jeWFuLTUwMCByb3VuZGVkLWxnIHB4LTIgcHktMS41IHRleHQtY3lhbi0zMDAgdGV4dC1jZW50ZXIgdGV4dC14cyBvdXRsaW5lLW5vbmUgZm9udC1ib2xkIGRpc2FibGVkOm9wYWNpdHktNjAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0yIHNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTQwMCBtYi0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNDAwXCI+PC9zcGFuPiBJIFRpZXJyYSAoSV9QRSlcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNSZWFkT25seX1cbiAgICAgICAgICAgICAgdmFsdWU9e2lfcGV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKCdpX3BlJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAwLjVcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCByb3VuZGVkLWxnIHB4LTIgcHktMS41IHRleHQtZW1lcmFsZC0zMDAgdGV4dC1jZW50ZXIgdGV4dC14cyBvdXRsaW5lLW5vbmUgZm9udC1ib2xkIGRpc2FibGVkOm9wYWNpdHktNjAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=