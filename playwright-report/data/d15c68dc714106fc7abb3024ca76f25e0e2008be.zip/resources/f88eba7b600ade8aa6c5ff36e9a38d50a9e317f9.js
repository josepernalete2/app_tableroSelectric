import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DualPhotoUploader.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { Camera, Image as ImageIcon, X, AlertCircle } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/DualPhotoUploader.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
// Renderizado seguro de imágenes con soporte para File / Blob / Data URL / URL remota
export const SafePreviewImage = ({ blob, src, alt, className }) => {
	_s();
	const [objectUrl, setObjectUrl] = useState(null);
	useEffect(() => {
		if (blob instanceof Blob || blob instanceof File) {
			const url = URL.createObjectURL(blob);
			setObjectUrl(url);
			return () => {
				URL.revokeObjectURL(url);
			};
		} else if (blob && (blob instanceof ArrayBuffer || ArrayBuffer.isView(blob))) {
			try {
				const b = new Blob([blob]);
				const url = URL.createObjectURL(b);
				setObjectUrl(url);
				return () => {
					URL.revokeObjectURL(url);
				};
			} catch (err) {
				setObjectUrl(null);
			}
		} else {
			setObjectUrl(null);
		}
	}, [blob]);
	const finalSrc = objectUrl || (typeof src === "string" ? src : null);
	if (!finalSrc) return null;
	return /* @__PURE__ */ _jsxDEV("img", {
		src: finalSrc,
		alt: alt || "Evidencia fotográfica",
		className
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 10
	}, this);
};
_s(SafePreviewImage, "Q4ugJUn5miWrvY9z1+S4+H7NbYg=");
_c = SafePreviewImage;
export default function DualPhotoUploader({ fotoBlob, fotoSrc, previewUrl, onImageSelected, onRemove, readOnly = false, label = "Evidencia Fotográfica", sublabel = "Captura con cámara en vivo o selecciona un archivo desde tu galería/dispositivo", maxSizeMB = 10, className = "" }) {
	_s2();
	const { alert: customAlert } = useConfirm();
	const handleFileChange = (e) => {
		if (readOnly) return;
		const file = e.target.files && e.target.files[0];
		if (!file) return;
		if (file.size > maxSizeMB * 1024 * 1024) {
			customAlert(`La imagen seleccionada supera los ${maxSizeMB}MB. Por favor elija un archivo más liviano.`);
			return;
		}
		if (onImageSelected) {
			onImageSelected(file);
		}
		// Reset file input value so selecting the same file triggers onChange
		e.target.value = "";
	};
	const hasPhoto = !!(fotoBlob || fotoSrc || previewUrl);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `space-y-3 font-sans ${className}`,
		children: [label && /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5",
				children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 13
				}, this), label]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 11
			}, this), sublabel && /* @__PURE__ */ _jsxDEV("span", {
				className: "text-[10px] text-slate-500 hidden sm:inline",
				children: sublabel
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 9
		}, this), hasPhoto ? /* @__PURE__ */ _jsxDEV("div", {
			className: "relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-950/80 shadow-xl group max-w-md mx-auto",
			children: [/* @__PURE__ */ _jsxDEV(SafePreviewImage, {
				blob: fotoBlob,
				src: previewUrl || fotoSrc,
				alt: label,
				className: "w-full h-auto max-h-80 object-cover rounded-2xl"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 11
			}, this), !readOnly && /* @__PURE__ */ _jsxDEV("div", {
				className: "absolute top-2 right-2 flex items-center gap-1.5 no-print",
				children: /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: onRemove,
					className: "p-1.5 bg-red-600/90 hover:bg-red-500 text-white rounded-xl shadow-lg transition-all cursor-pointer backdrop-blur-xs active:scale-95",
					title: "Eliminar Fotografía",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 97,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 88,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "p-4 sm:p-5 border-2 border-dashed border-slate-800 hover:border-slate-700 bg-slate-950/40 rounded-2xl text-center space-y-3 transition-colors no-print",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-center gap-2 text-slate-500",
					children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-6 h-6 text-amber-500/70" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(ImageIcon, { className: "w-6 h-6 text-sky-500/70" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 font-semibold",
					children: "Selecciona el método de captura de evidencia:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 11
				}, this),
				!readOnly && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center justify-center gap-3 pt-1",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "inline-flex items-center gap-2 px-3.5 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs rounded-xl cursor-pointer transition-all shadow-md",
						children: [
							/* @__PURE__ */ _jsxDEV(Camera, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Tomar Foto (Cámara)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "file",
								accept: "image/*",
								capture: "environment",
								onChange: handleFileChange,
								className: "hidden"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("label", {
						className: "inline-flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-slate-700 font-bold text-xs rounded-xl cursor-pointer transition-all shadow-sm",
						children: [
							/* @__PURE__ */ _jsxDEV(ImageIcon, { className: "w-4 h-4 text-sky-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Subir Archivo / Galería" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "file",
								accept: "image/*",
								onChange: handleFileChange,
								className: "hidden"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 110,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 72,
		columnNumber: 5
	}, this);
}
_s2(DualPhotoUploader, "n+JWvuw/FNculEBWKvh9/8laR5A=", false, function() {
	return [useConfirm];
});
_c2 = DualPhotoUploader;
var _c, _c2;
$RefreshReg$(_c, "SafePreviewImage");
$RefreshReg$(_c2, "DualPhotoUploader");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/DualPhotoUploader.jsx?t=1790793566895";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/DualPhotoUploader.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/DualPhotoUploader.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/DualPhotoUploader.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsUUFBUSxTQUFTLFdBQVcsR0FBRyxtQkFBbUI7QUFDM0QsU0FBUyxrQkFBa0I7Ozs7O0FBRzNCLE9BQU8sTUFBTSxvQkFBb0IsRUFBRSxNQUFNLEtBQUssS0FBSyxnQkFBZ0I7O0NBQ2pFLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLElBQUk7Q0FFL0MsZ0JBQWdCO0VBQ2QsSUFBSSxnQkFBZ0IsUUFBUSxnQkFBZ0IsTUFBTTtHQUNoRCxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtHQUNwQyxhQUFhLEdBQUc7R0FDaEIsYUFBYTtJQUNYLElBQUksZ0JBQWdCLEdBQUc7R0FDekI7RUFDRixPQUFPLElBQUksU0FBUyxnQkFBZ0IsZUFBZSxZQUFZLE9BQU8sSUFBSSxJQUFJO0dBQzVFLElBQUk7SUFDRixNQUFNLElBQUksSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDO0lBQ3pCLE1BQU0sTUFBTSxJQUFJLGdCQUFnQixDQUFDO0lBQ2pDLGFBQWEsR0FBRztJQUNoQixhQUFhO0tBQ1gsSUFBSSxnQkFBZ0IsR0FBRztJQUN6QjtHQUNGLFNBQVMsS0FBSztJQUNaLGFBQWEsSUFBSTtHQUNuQjtFQUNGLE9BQU87R0FDTCxhQUFhLElBQUk7RUFDbkI7Q0FDRixHQUFHLENBQUMsSUFBSSxDQUFDO0NBRVQsTUFBTSxXQUFXLGNBQWMsT0FBTyxRQUFRLFdBQVcsTUFBTTtDQUMvRCxJQUFJLENBQUMsVUFBVSxPQUFPO0NBRXRCLE9BQU8sd0JBQUMsT0FBRDtFQUFLLEtBQUs7RUFBVSxLQUFLLE9BQU87RUFBb0M7Q0FBWTs7Ozs7QUFDekY7OztBQUVBLGVBQWUsU0FBUyxrQkFBa0IsRUFDeEMsVUFDQSxTQUNBLFlBQ0EsaUJBQ0EsVUFDQSxXQUFXLE9BQ1gsUUFBUSx5QkFDUixXQUFXLG1GQUNYLFlBQVksSUFDWixZQUFZLE1BQ1g7O0NBQ0QsTUFBTSxFQUFFLE9BQU8sZ0JBQWdCLFdBQVc7Q0FFMUMsTUFBTSxvQkFBb0IsTUFBTTtFQUM5QixJQUFJLFVBQVU7RUFDZCxNQUFNLE9BQU8sRUFBRSxPQUFPLFNBQVMsRUFBRSxPQUFPLE1BQU07RUFDOUMsSUFBSSxDQUFDLE1BQU07RUFFWCxJQUFJLEtBQUssT0FBTyxZQUFZLE9BQU8sTUFBTTtHQUN2QyxZQUFZLHFDQUFxQyxVQUFVLDRDQUE0QztHQUN2RztFQUNGO0VBRUEsSUFBSSxpQkFBaUI7R0FDbkIsZ0JBQWdCLElBQUk7RUFDdEI7O0VBRUEsRUFBRSxPQUFPLFFBQVE7Q0FDbkI7Q0FFQSxNQUFNLFdBQVcsQ0FBQyxFQUFFLFlBQVksV0FBVztDQUUzQyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFXLHVCQUF1QjtZQUF2QyxDQUNHLFNBQ0Msd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUseUJBQTBCOzs7O2NBQzNDLEtBQ0c7Ozs7O2FBQ0wsWUFDQyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUNiO0dBQ0c7Ozs7V0FFTDs7Ozs7WUFHTixXQUNDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxrQkFBRDtJQUNFLE1BQU07SUFDTixLQUFLLGNBQWM7SUFDbkIsS0FBSztJQUNMLFdBQVU7R0FDWDs7OzthQUVBLENBQUMsWUFDQSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsU0FBUztLQUNULFdBQVU7S0FDVixPQUFNO2VBRU4sd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7SUFDbEI7Ozs7O0dBQ0w7Ozs7V0FFSjs7Ozs7YUFFTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDRCQUE2Qjs7OztlQUMvQyx3QkFBQyxXQUFELEVBQVcsV0FBVSwwQkFBMkI7Ozs7YUFDN0M7Ozs7OztJQUVMLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXVDO0lBRWpEOzs7OztJQUVGLENBQUMsWUFDQSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBRUUsd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCO09BQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7T0FDN0Isd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7Ozs7T0FDL0Isd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxRQUFPO1FBQ1AsU0FBUTtRQUNSLFVBQVU7UUFDVixXQUFVO09BQ1g7Ozs7O01BQ0k7Ozs7O2VBR1Asd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCO09BQ0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsdUJBQXdCOzs7OztPQUM3Qyx3QkFBQyxRQUFELFlBQU0sMEJBQTZCOzs7OztPQUNuQyx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFFBQU87UUFDUCxVQUFVO1FBQ1YsV0FBVTtPQUNYOzs7OztNQUNJOzs7OzthQUNKOzs7Ozs7R0FFSjs7Ozs7VUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRHVhbFBob3RvVXBsb2FkZXIuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQ2FtZXJhLCBJbWFnZSBhcyBJbWFnZUljb24sIFgsIEFsZXJ0Q2lyY2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IHVzZUNvbmZpcm0gfSBmcm9tICcuLi9jb250ZXh0L0NvbmZpcm1Db250ZXh0JztcblxuLy8gUmVuZGVyaXphZG8gc2VndXJvIGRlIGltw6FnZW5lcyBjb24gc29wb3J0ZSBwYXJhIEZpbGUgLyBCbG9iIC8gRGF0YSBVUkwgLyBVUkwgcmVtb3RhXG5leHBvcnQgY29uc3QgU2FmZVByZXZpZXdJbWFnZSA9ICh7IGJsb2IsIHNyYywgYWx0LCBjbGFzc05hbWUgfSkgPT4ge1xuICBjb25zdCBbb2JqZWN0VXJsLCBzZXRPYmplY3RVcmxdID0gdXNlU3RhdGUobnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoYmxvYiBpbnN0YW5jZW9mIEJsb2IgfHwgYmxvYiBpbnN0YW5jZW9mIEZpbGUpIHtcbiAgICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgICBzZXRPYmplY3RVcmwodXJsKTtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmIChibG9iICYmIChibG9iIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIgfHwgQXJyYXlCdWZmZXIuaXNWaWV3KGJsb2IpKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgYiA9IG5ldyBCbG9iKFtibG9iXSk7XG4gICAgICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYik7XG4gICAgICAgIHNldE9iamVjdFVybCh1cmwpO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbiAgICAgICAgfTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBzZXRPYmplY3RVcmwobnVsbCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldE9iamVjdFVybChudWxsKTtcbiAgICB9XG4gIH0sIFtibG9iXSk7XG5cbiAgY29uc3QgZmluYWxTcmMgPSBvYmplY3RVcmwgfHwgKHR5cGVvZiBzcmMgPT09ICdzdHJpbmcnID8gc3JjIDogbnVsbCk7XG4gIGlmICghZmluYWxTcmMpIHJldHVybiBudWxsO1xuXG4gIHJldHVybiA8aW1nIHNyYz17ZmluYWxTcmN9IGFsdD17YWx0IHx8IFwiRXZpZGVuY2lhIGZvdG9ncsOhZmljYVwifSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gLz47XG59O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEdWFsUGhvdG9VcGxvYWRlcih7XG4gIGZvdG9CbG9iLFxuICBmb3RvU3JjLFxuICBwcmV2aWV3VXJsLFxuICBvbkltYWdlU2VsZWN0ZWQsXG4gIG9uUmVtb3ZlLFxuICByZWFkT25seSA9IGZhbHNlLFxuICBsYWJlbCA9IFwiRXZpZGVuY2lhIEZvdG9ncsOhZmljYVwiLFxuICBzdWJsYWJlbCA9IFwiQ2FwdHVyYSBjb24gY8OhbWFyYSBlbiB2aXZvIG8gc2VsZWNjaW9uYSB1biBhcmNoaXZvIGRlc2RlIHR1IGdhbGVyw61hL2Rpc3Bvc2l0aXZvXCIsXG4gIG1heFNpemVNQiA9IDEwLFxuICBjbGFzc05hbWUgPSBcIlwiXG59KSB7XG4gIGNvbnN0IHsgYWxlcnQ6IGN1c3RvbUFsZXJ0IH0gPSB1c2VDb25maXJtKCk7XG5cbiAgY29uc3QgaGFuZGxlRmlsZUNoYW5nZSA9IChlKSA9PiB7XG4gICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzICYmIGUudGFyZ2V0LmZpbGVzWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgaWYgKGZpbGUuc2l6ZSA+IG1heFNpemVNQiAqIDEwMjQgKiAxMDI0KSB7XG4gICAgICBjdXN0b21BbGVydChgTGEgaW1hZ2VuIHNlbGVjY2lvbmFkYSBzdXBlcmEgbG9zICR7bWF4U2l6ZU1CfU1CLiBQb3IgZmF2b3IgZWxpamEgdW4gYXJjaGl2byBtw6FzIGxpdmlhbm8uYCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKG9uSW1hZ2VTZWxlY3RlZCkge1xuICAgICAgb25JbWFnZVNlbGVjdGVkKGZpbGUpO1xuICAgIH1cbiAgICAvLyBSZXNldCBmaWxlIGlucHV0IHZhbHVlIHNvIHNlbGVjdGluZyB0aGUgc2FtZSBmaWxlIHRyaWdnZXJzIG9uQ2hhbmdlXG4gICAgZS50YXJnZXQudmFsdWUgPSAnJztcbiAgfTtcblxuICBjb25zdCBoYXNQaG90byA9ICEhKGZvdG9CbG9iIHx8IGZvdG9TcmMgfHwgcHJldmlld1VybCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YHNwYWNlLXktMyBmb250LXNhbnMgJHtjbGFzc05hbWV9YH0+XG4gICAgICB7bGFiZWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICA8Q2FtZXJhIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICB7c3VibGFiZWwgJiYgKFxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgaGlkZGVuIHNtOmlubGluZVwiPlxuICAgICAgICAgICAgICB7c3VibGFiZWx9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7aGFzUGhvdG8gPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTk1MC84MCBzaGFkb3cteGwgZ3JvdXAgbWF4LXctbWQgbXgtYXV0b1wiPlxuICAgICAgICAgIDxTYWZlUHJldmlld0ltYWdlXG4gICAgICAgICAgICBibG9iPXtmb3RvQmxvYn1cbiAgICAgICAgICAgIHNyYz17cHJldmlld1VybCB8fCBmb3RvU3JjfVxuICAgICAgICAgICAgYWx0PXtsYWJlbH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLWF1dG8gbWF4LWgtODAgb2JqZWN0LWNvdmVyIHJvdW5kZWQtMnhsXCJcbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgeyFyZWFkT25seSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0yIHJpZ2h0LTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBuby1wcmludFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25SZW1vdmV9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgYmctcmVkLTYwMC85MCBob3ZlcjpiZy1yZWQtNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgYmFja2Ryb3AtYmx1ci14cyBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgIHRpdGxlPVwiRWxpbWluYXIgRm90b2dyYWbDrWFcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBzbTpwLTUgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtOTUwLzQwIHJvdW5kZWQtMnhsIHRleHQtY2VudGVyIHNwYWNlLXktMyB0cmFuc2l0aW9uLWNvbG9ycyBuby1wcmludFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWFtYmVyLTUwMC83MFwiIC8+XG4gICAgICAgICAgICA8SW1hZ2VJY29uIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1za3ktNTAwLzcwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgU2VsZWNjaW9uYSBlbCBtw6l0b2RvIGRlIGNhcHR1cmEgZGUgZXZpZGVuY2lhOlxuICAgICAgICAgIDwvcD5cblxuICAgICAgICAgIHshcmVhZE9ubHkgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgcHQtMVwiPlxuICAgICAgICAgICAgICB7LyogQm90w7NuIDE6IEPDoW1hcmEgZW4gdml2byAoRGlyZWN0IENhcHR1cmUpICovfVxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMuNSBweS0yIGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgYWN0aXZlOnNjYWxlLTk1IHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgdGV4dC14cyByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZFwiPlxuICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+VG9tYXIgRm90byAoQ8OhbWFyYSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcbiAgICAgICAgICAgICAgICAgIGNhcHR1cmU9XCJlbnZpcm9ubWVudFwiXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICB7LyogQm90w7NuIDI6IFNlbGVjdG9yIGRlIEFyY2hpdm8gLyBHYWxlcsOtYSAqL31cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zLjUgcHktMiBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIGFjdGl2ZTpzY2FsZS05NSB0ZXh0LXNsYXRlLTIwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBmb250LWJvbGQgdGV4dC14cyByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgIDxJbWFnZUljb24gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNreS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlN1YmlyIEFyY2hpdm8gLyBHYWxlcsOtYTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=