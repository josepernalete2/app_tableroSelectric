import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NotificationButton.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { Bell, BellOff, Send, CheckCircle2, AlertTriangle, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import { usePushNotifications } from "/src/hooks/usePushNotifications.js";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/NotificationButton.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function NotificationButton() {
	_s();
	const { isSupported, permission, isSubscribed, loading, statusMessage, subscribeUser, unsubscribeUser, sendTestNotification } = usePushNotifications();
	if (!isSupported) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2 text-xs text-amber-500 bg-amber-950/40 p-2.5 rounded-lg border border-amber-900/50 font-mono",
			children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Push Notifications no disponibles en este navegador." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-2 p-3 bg-slate-900/80 border border-slate-800 rounded-xl shadow-lg font-sans",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [isSubscribed ? /* @__PURE__ */ _jsxDEV("div", {
					className: "p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20",
					children: /* @__PURE__ */ _jsxDEV(Bell, { className: "w-5 h-5 animate-pulse" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "p-2 rounded-lg bg-slate-800 text-slate-400",
					children: /* @__PURE__ */ _jsxDEV(BellOff, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
					className: "text-xs font-bold text-slate-200 uppercase tracking-wider",
					children: "Notificaciones Push"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-[11px] text-slate-400",
					children: isSubscribed ? "Activas en este dispositivo" : permission === "denied" ? "Bloqueadas por el usuario" : "Recibe alertas nativas en tu móvil"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: isSubscribed ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => sendTestNotification(),
					disabled: loading,
					className: "px-3 py-1.5 text-xs font-semibold text-sky-400 bg-sky-950/60 hover:bg-sky-900 border border-sky-800/80 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50",
					title: "Probar envío de notificación",
					children: [loading ? /* @__PURE__ */ _jsxDEV(Loader2, { className: "w-3.5 h-3.5 animate-spin" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 28
					}, this) : /* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 79
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Probar" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: unsubscribeUser,
					disabled: loading,
					className: "px-3 py-1.5 text-xs font-semibold text-rose-400 bg-rose-950/60 hover:bg-rose-900 border border-rose-800/80 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50",
					children: [loading ? /* @__PURE__ */ _jsxDEV(Loader2, { className: "w-3.5 h-3.5 animate-spin" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 28
					}, this) : /* @__PURE__ */ _jsxDEV(BellOff, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 79
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Desactivar" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("button", {
					onClick: subscribeUser,
					disabled: loading || permission === "denied",
					className: "px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-md shadow-indigo-600/30",
					children: [loading ? /* @__PURE__ */ _jsxDEV(Loader2, { className: "w-3.5 h-3.5 animate-spin" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 26
					}, this) : /* @__PURE__ */ _jsxDEV(Bell, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 77
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Activar Alertas" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 7
		}, this), statusMessage && /* @__PURE__ */ _jsxDEV("div", {
			className: "mt-1 flex items-center gap-1.5 text-[11px] text-slate-300 bg-slate-950/60 p-2 rounded border border-slate-800 font-mono",
			children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-400 shrink-0" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "truncate",
				children: statusMessage
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 91,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
}
_s(NotificationButton, "7hYwb5fhZpDLbhmBSA0T8rdPL8Y=", false, function() {
	return [usePushNotifications];
});
_c = NotificationButton;
var _c;
$RefreshReg$(_c, "NotificationButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/NotificationButton.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/NotificationButton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/NotificationButton.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/NotificationButton.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsTUFBTSxTQUFTLE1BQU0sY0FBYyxlQUFlLGVBQWU7QUFDMUUsU0FBUyw0QkFBNEI7Ozs7QUFFckMsZUFBZSxTQUFTLHFCQUFxQjs7Q0FDM0MsTUFBTSxFQUNKLGFBQ0EsWUFDQSxjQUNBLFNBQ0EsZUFDQSxlQUNBLGlCQUNBLHlCQUNFLHFCQUFxQjtDQUV6QixJQUFJLENBQUMsYUFBYTtFQUNoQixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSxtQkFBb0I7Ozs7YUFDN0Msd0JBQUMsUUFBRCxZQUFNLHVEQUEwRDs7OztXQUM3RDs7Ozs7O0NBRVQ7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNHLGVBQ0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSx3QkFBeUI7Ozs7O0lBQ3RDOzs7O2VBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7OztJQUMzQjs7OztjQUVQLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUE0RDtJQUV0RTs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1YsZUFDRyxnQ0FDQSxlQUFlLFdBQ2IsOEJBQ0E7SUFDTDs7OztZQUNBOzs7O1lBQ0Y7Ozs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWixlQUNDLGdEQUNFLHdCQUFDLFVBQUQ7S0FDRSxlQUFlLHFCQUFxQjtLQUNwQyxVQUFVO0tBQ1YsV0FBVTtLQUNWLE9BQU07ZUFKUixDQU1HLFVBQVUsd0JBQUMsU0FBRCxFQUFTLFdBQVUsMkJBQTRCOzs7O2dCQUFJLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7ZUFDN0Ysd0JBQUMsUUFBRCxZQUFNLFNBQVk7Ozs7YUFDWjs7Ozs7Y0FFUix3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFVBQVU7S0FDVixXQUFVO2VBSFosQ0FLRyxVQUFVLHdCQUFDLFNBQUQsRUFBUyxXQUFVLDJCQUE0Qjs7OztnQkFBSSx3QkFBQyxTQUFELEVBQVMsV0FBVSxjQUFlOzs7O2VBQ2hHLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OzthQUNoQjs7Ozs7WUFDUjs7OztlQUVGLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsVUFBVSxXQUFXLGVBQWU7S0FDcEMsV0FBVTtlQUhaLENBS0csVUFBVSx3QkFBQyxTQUFELEVBQVMsV0FBVSwyQkFBNEI7Ozs7Z0JBQUksd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OztlQUM3Rix3QkFBQyxRQUFELFlBQU0sa0JBQXFCOzs7O2FBQ3JCOzs7Ozs7R0FFUDs7OztXQUNGOzs7OztZQUVKLGlCQUNDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSx3Q0FBeUM7Ozs7YUFDakUsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBWTtHQUFvQjs7OztXQUM3Qzs7Ozs7VUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uQnV0dG9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQmVsbCwgQmVsbE9mZiwgU2VuZCwgQ2hlY2tDaXJjbGUyLCBBbGVydFRyaWFuZ2xlLCBMb2FkZXIyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IHVzZVB1c2hOb3RpZmljYXRpb25zIH0gZnJvbSAnLi4vaG9va3MvdXNlUHVzaE5vdGlmaWNhdGlvbnMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBOb3RpZmljYXRpb25CdXR0b24oKSB7XG4gIGNvbnN0IHtcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBwZXJtaXNzaW9uLFxuICAgIGlzU3Vic2NyaWJlZCxcbiAgICBsb2FkaW5nLFxuICAgIHN0YXR1c01lc3NhZ2UsXG4gICAgc3Vic2NyaWJlVXNlcixcbiAgICB1bnN1YnNjcmliZVVzZXIsXG4gICAgc2VuZFRlc3ROb3RpZmljYXRpb25cbiAgfSA9IHVzZVB1c2hOb3RpZmljYXRpb25zKCk7XG5cbiAgaWYgKCFpc1N1cHBvcnRlZCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1hbWJlci01MDAgYmctYW1iZXItOTUwLzQwIHAtMi41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1hbWJlci05MDAvNTAgZm9udC1tb25vXCI+XG4gICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTQgc2hyaW5rLTBcIiAvPlxuICAgICAgICA8c3Bhbj5QdXNoIE5vdGlmaWNhdGlvbnMgbm8gZGlzcG9uaWJsZXMgZW4gZXN0ZSBuYXZlZ2Fkb3IuPC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yIHAtMyBiZy1zbGF0ZS05MDAvODAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBzaGFkb3ctbGcgZm9udC1zYW5zXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAge2lzU3Vic2NyaWJlZCA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtbGcgYmctZW1lcmFsZC01MDAvMTAgdGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzIwXCI+XG4gICAgICAgICAgICAgIDxCZWxsIGNsYXNzTmFtZT1cInctNSBoLTUgYW5pbWF0ZS1wdWxzZVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgPEJlbGxPZmYgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgIE5vdGlmaWNhY2lvbmVzIFB1c2hcbiAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICB7aXNTdWJzY3JpYmVkIFxuICAgICAgICAgICAgICAgID8gJ0FjdGl2YXMgZW4gZXN0ZSBkaXNwb3NpdGl2bycgXG4gICAgICAgICAgICAgICAgOiBwZXJtaXNzaW9uID09PSAnZGVuaWVkJ1xuICAgICAgICAgICAgICAgICAgPyAnQmxvcXVlYWRhcyBwb3IgZWwgdXN1YXJpbydcbiAgICAgICAgICAgICAgICAgIDogJ1JlY2liZSBhbGVydGFzIG5hdGl2YXMgZW4gdHUgbcOzdmlsJ31cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIHtpc1N1YnNjcmliZWQgPyAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2VuZFRlc3ROb3RpZmljYXRpb24oKX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1za3ktNDAwIGJnLXNreS05NTAvNjAgaG92ZXI6Ymctc2t5LTkwMCBib3JkZXIgYm9yZGVyLXNreS04MDAvODAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgIHRpdGxlPVwiUHJvYmFyIGVudsOtbyBkZSBub3RpZmljYWNpw7NuXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgYW5pbWF0ZS1zcGluXCIgLz4gOiA8U2VuZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+fVxuICAgICAgICAgICAgICAgIDxzcGFuPlByb2Jhcjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3Vuc3Vic2NyaWJlVXNlcn1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1yb3NlLTQwMCBiZy1yb3NlLTk1MC82MCBob3ZlcjpiZy1yb3NlLTkwMCBib3JkZXIgYm9yZGVyLXJvc2UtODAwLzgwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgYW5pbWF0ZS1zcGluXCIgLz4gOiA8QmVsbE9mZiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+fVxuICAgICAgICAgICAgICAgIDxzcGFuPkRlc2FjdGl2YXI8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17c3Vic2NyaWJlVXNlcn1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmcgfHwgcGVybWlzc2lvbiA9PT0gJ2RlbmllZCd9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTUwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MCBzaGFkb3ctbWQgc2hhZG93LWluZGlnby02MDAvMzBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7bG9hZGluZyA/IDxMb2FkZXIyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IGFuaW1hdGUtc3BpblwiIC8+IDogPEJlbGwgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgPHNwYW4+QWN0aXZhciBBbGVydGFzPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAge3N0YXR1c01lc3NhZ2UgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTMwMCBiZy1zbGF0ZS05NTAvNjAgcC0yIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPntzdGF0dXNNZXNzYWdlfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl19