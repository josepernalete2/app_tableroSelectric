import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/BackupView.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { API_BASE_URL } from "/src/utils/api.js";
import { ShieldCheck, ShieldAlert, Download, UploadCloud, Database, CheckCircle2, AlertCircle, Loader2, Layers, Zap, Clock, FileCode, Sparkles, RefreshCw, HardDrive, Building2, Send, Key, Copy, Check, Search, Filter, ExternalLink, ChevronRight, FileCheck, Info, X, Lock, Cpu } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/BackupView.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export const BackupView = () => {
	_s();
	const { user, token, companies, importCompanies, showToast } = useStore();
	const fileInputRef = useRef(null);
	// Obtener el token más reciente disponible para evitar fallos de 403
	const getFreshToken = () => {
		return useStore.getState().token || (typeof localStorage !== "undefined" ? localStorage.getItem("token") : "") || (typeof sessionStorage !== "undefined" ? sessionStorage.getItem("token") : "") || "";
	};
	const getAuthHeaders = (extra = {}) => {
		const t = getFreshToken();
		return {
			"Content-Type": "application/json",
			...t ? { "Authorization": `Bearer ${t}` } : {},
			...extra
		};
	};
	// Estados de Navegación y Pestañas
	const [activeTab, setActiveTab] = useState("empresas");
	const [searchQuery, setSearchQuery] = useState("");
	const [statusFilter, setStatusFilter] = useState("ALL");
	// Estados de Datos de Empresas (Resumen)
	const [empresasResumen, setEmpresasResumen] = useState([]);
	const [isLoadingEmpresas, setIsLoadingEmpresas] = useState(false);
	// Estados de Modales
	const [selectedPinModal, setSelectedPinModal] = useState(null);
	const [selectedCertModal, setSelectedCertModal] = useState(null);
	const [copiedPin, setCopiedPin] = useState(false);
	const [copiedCert, setCopiedCert] = useState(false);
	// Estados de Acciones Globales
	const [isExportingGlobal, setIsExportingGlobal] = useState(false);
	const [isExecutingGlobalPipeline, setIsExecutingGlobalPipeline] = useState(false);
	const [isImporting, setIsImporting] = useState(false);
	const [importStats, setImportStats] = useState(null);
	const [exportStats, setExportStats] = useState(null);
	// Estado de descarga aislada por empresa
	const [downloadingEmpresaId, setDownloadingEmpresaId] = useState(null);
	// Candado de tiempo contra clicks dobles / rápidos (<1500ms)
	const lastActionTimestampRef = useRef(0);
	const isAnyProcessing = isExecutingGlobalPipeline || isExportingGlobal || isImporting || Boolean(downloadingEmpresaId);
	/**
	* Rescate Inmediato Offline / Local Directo (.json)
	* Extrae el 100% de los datos residentes en el almacenamiento local y Zustand
	* sin peticiones HTTP, sin backend ni validación de token.
	*/
	const descargarCopiaLocalDirecta = () => {
		try {
			const estado = useStore.getState();
			const listadoEmpresas = estado.companies || estado.empresas || [];
			const listadoProyectos = estado.proyectos || estado.projects || [];
			const backupData = {
				appName: "App Tableros Eléctricos (Selectric)",
				tipoExportacion: "OFFLINE_LOCAL_DIRECT_SNAP",
				version: "2.2.0",
				fechaGeneracion: new Date().toISOString(),
				dispositivo: typeof navigator !== "undefined" ? navigator.userAgent : "Desconocido",
				metadata: {
					generadoEnCliente: true,
					totalEmpresas: listadoEmpresas.length,
					totalProyectos: listadoProyectos.length,
					totalTableros: (estado.tableros || []).length,
					totalCircuitos: (estado.circuitos || []).length,
					fechaLocal: new Date().toLocaleString("es-VE")
				},
				data: listadoEmpresas,
				datos: {
					empresas: listadoEmpresas,
					proyectos: listadoProyectos,
					subestaciones: estado.subestaciones || [],
					tableros: estado.tableros || [],
					circuitos: estado.circuitos || [],
					mediciones: estado.mediciones || estado.puntosMedicion || [],
					ccm: estado.ccmList || estado.ccm || [],
					inspeccionesTermograficas: estado.inspeccionesTermograficas || [],
					inspeccionesAterramiento: estado.inspeccionesAterramiento || [],
					inspeccionesTanquesCombustible: estado.inspeccionesTanquesCombustible || [],
					alarmas: estado.alarmas || [],
					alimentadores: estado.alimentadores || []
				}
			};
			const jsonString = JSON.stringify(backupData, null, 2);
			const blob = new Blob([jsonString], { type: "application/json;charset=utf-8" });
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = url;
			link.download = `respaldo_local_inmediato_${new Date().toISOString().slice(0, 10)}.json`;
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
			URL.revokeObjectURL(url);
			if (showToast) {
				showToast("¡Copia de seguridad local descargada exitosamente en este dispositivo!", "success");
			}
		} catch (err) {
			console.error("Error al exportar respaldo local directo:", err);
			if (showToast) {
				showToast("Error al exportar respaldo local: " + err.message, "error");
			}
		}
	};
	/**
	* Cargar listado de empresas con métricas de resguardo desde la API
	*/
	const fetchEmpresasResumen = async () => {
		setIsLoadingEmpresas(true);
		try {
			const response = await fetch(`${API_BASE_URL}/api/backup/resumen-empresas`, { headers: getAuthHeaders() });
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				return;
			}
			const data = await response.json();
			if (response.ok && data.ok) {
				setEmpresasResumen(data.data || []);
			}
		} catch (err) {
			console.error("Error al cargar resumen de empresas:", err);
		} finally {
			setIsLoadingEmpresas(false);
		}
	};
	useEffect(() => {
		fetchEmpresasResumen();
	}, [token]);
	// Cálculos consolidados para KPIs
	const totalEmpresas = empresasResumen.length || companies?.length || 0;
	const totalTableros = empresasResumen.reduce((acc, e) => acc + (e.totales?.tableros || 0), 0);
	const totalCircuitos = empresasResumen.reduce((acc, e) => acc + (e.totales?.circuitos || 0), 0);
	const totalActivosProtegidos = empresasResumen.reduce((acc, e) => acc + (e.totales?.totalActivos || 0), 0);
	const totalVinculadosTelegram = empresasResumen.filter((e) => e.telegramChatId).length;
	// Filtrado de empresas
	const filteredEmpresas = useMemo(() => {
		return empresasResumen.filter((emp) => {
			const matchesSearch = emp.nombre.toLowerCase().includes(searchQuery.toLowerCase()) || emp.rif.toLowerCase().includes(searchQuery.toLowerCase());
			if (!matchesSearch) return false;
			if (statusFilter === "VINCULADOS") return !!emp.telegramChatId;
			if (statusFilter === "PENDIENTES") return !emp.telegramChatId;
			return true;
		});
	}, [
		empresasResumen,
		searchQuery,
		statusFilter
	]);
	/**
	* Dispara el respaldo maestro en servidor / nube
	* Petición HTTP POST estándar y silenciosa (sin solicitar permisos de sistema, credenciales ni sync nativo)
	*/
	const handleRespaldoServidor = async () => {
		const now = Date.now();
		if (isExecutingGlobalPipeline || now - lastActionTimestampRef.current < 2e3) return;
		lastActionTimestampRef.current = now;
		setIsExecutingGlobalPipeline(true);
		try {
			const token = getFreshToken();
			const state = useStore.getState();
			const payload = {
				fecha: new Date().toISOString(),
				nombre: `Respaldo Servidor ${new Date().toLocaleDateString("es-VE")}`,
				descripcion: "Respaldo maestro disparado desde el Centro de Control Web",
				empresas: state.companies || state.empresas || [],
				proyectos: state.proyectos || state.projects || [],
				subestaciones: state.subestaciones || [],
				tableros: state.tableros || [],
				circuitos: state.circuitos || [],
				mediciones: state.mediciones || state.puntosMedicion || []
			};
			const response = await fetch(`${API_BASE_URL}/api/backup/cloud`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					...token && token !== "mock-offline-token" ? { "Authorization": `Bearer ${token}` } : {}
				},
				body: JSON.stringify(payload)
			});
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				if (showToast) showToast("Tu sesión ha expirado o no tienes permisos de Administrador.", "error");
				return;
			}
			if (!response.ok) {
				const errorData = await response.json().catch(() => ({}));
				throw new Error(errorData.error || `Error en el servidor: ${response.status}`);
			}
			const resData = await response.json().catch(() => ({ ok: true }));
			if (showToast) {
				showToast("Respaldo en la nube generado exitosamente.", "success");
			}
			fetchEmpresasResumen();
		} catch (error) {
			console.error("Error en respaldo servidor:", error);
			const isNetworkError = error.message?.includes("Failed to fetch") || error.message?.includes("NetworkError");
			const mensajeError = isNetworkError ? "No se pudo conectar con el servidor central. Puedes usar \"Descarga Inmediata Local (.json)\" mientras tanto." : error.message || "Fallo en la ejecución del respaldo";
			if (showToast) showToast(mensajeError, "error");
		} finally {
			setIsExecutingGlobalPipeline(false);
		}
	};
	const handleTriggerGlobalPipeline = handleRespaldoServidor;
	/**
	* Exportar y descargar el volcado JSON maestro en memoria
	*/
	const handleExportGlobalJson = async () => {
		const now = Date.now();
		if (isExportingGlobal || now - lastActionTimestampRef.current < 2e3) return;
		lastActionTimestampRef.current = now;
		setIsExportingGlobal(true);
		setExportStats(null);
		try {
			const response = await fetch(`${API_BASE_URL}/api/backups/export`, { headers: getAuthHeaders() });
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				if (showToast) showToast("Tu sesión ha expirado o no tienes permisos de Administrador.", "error");
				return;
			}
			if (!response.ok) throw new Error("Error al generar archivo JSON maestro");
			let filename = `backup_maestro_selectric_${new Date().toISOString().slice(0, 10)}.json`;
			const disposition = response.headers.get("content-disposition");
			if (disposition && disposition.includes("filename=")) {
				const match = disposition.match(/filename="?([^"]+)"?/);
				if (match?.[1]) filename = match[1];
			}
			const blob = await response.blob();
			const downloadUrl = window.URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = downloadUrl;
			link.setAttribute("download", filename);
			document.body.appendChild(link);
			link.click();
			link.remove();
			window.URL.revokeObjectURL(downloadUrl);
			setExportStats({
				filename,
				size: `${(blob.size / 1024).toFixed(1)} KB`,
				timestamp: new Date().toLocaleTimeString("es-VE")
			});
			if (showToast) showToast("Archivo de respaldo maestro descargado.", "success");
		} catch (err) {
			const isNetworkError = err.message?.includes("Failed to fetch") || err.message?.includes("NetworkError");
			const mensajeError = isNetworkError ? "Error de conexión con el servidor. Utiliza \"Descarga Inmediata Local (.json)\"." : err.message || "Error al descargar respaldo";
			if (showToast) showToast(mensajeError, "error");
		} finally {
			setIsExportingGlobal(false);
		}
	};
	/**
	* Generar o mostrar PIN de enlace para Telegram de una empresa
	*/
	const handleOpenPinModal = async (empresa) => {
		setSelectedPinModal({
			empresa,
			pin: empresa.telegramBackupPin,
			isGenerating: false
		});
		if (!empresa.telegramBackupPin) {
			try {
				setSelectedPinModal((prev) => ({
					...prev,
					isGenerating: true
				}));
				const response = await fetch(`${API_BASE_URL}/api/backup/generar-pin/${empresa.id}`, {
					method: "POST",
					headers: getAuthHeaders()
				});
				if (response.status === 401 || response.status === 403) {
					useStore.getState().handleAuthError?.(response.status);
					return;
				}
				const resData = await response.json();
				if (response.ok && resData.ok) {
					setSelectedPinModal({
						empresa,
						pin: resData.data.telegramBackupPin,
						isGenerating: false
					});
					fetchEmpresasResumen();
				}
			} catch (err) {
				console.error("Error al generar PIN:", err);
			}
		}
	};
	/**
	* Abrir modal de Certificado Ejecutivo de Resguardo
	*/
	const handleOpenCertModal = async (empresa) => {
		setSelectedCertModal({
			ficha: null,
			isLoading: true
		});
		try {
			const response = await fetch(`${API_BASE_URL}/api/backup/empresa/${empresa.id}/estado`, { headers: getAuthHeaders() });
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				return;
			}
			const data = await response.json();
			if (response.ok && data.ok) {
				setSelectedCertModal({
					ficha: data.data,
					isLoading: false
				});
			} else {
				throw new Error(data.error || "No se pudo obtener el certificado");
			}
		} catch (err) {
			if (showToast) showToast(err.message, "error");
			setSelectedCertModal(null);
		}
	};
	/**
	* Descargar snapshot aislado de una sola empresa
	*/
	const handleDownloadEmpresaSnapshot = async (empresaId, empresaNombre) => {
		const now = Date.now();
		if (downloadingEmpresaId || now - lastActionTimestampRef.current < 2e3) return;
		lastActionTimestampRef.current = now;
		setDownloadingEmpresaId(empresaId);
		try {
			const response = await fetch(`${API_BASE_URL}/api/backup/empresa/${empresaId}/export`, { headers: getAuthHeaders() });
			if (response.status === 401 || response.status === 403) {
				useStore.getState().handleAuthError?.(response.status);
				return;
			}
			if (!response.ok) throw new Error("Error al exportar datos de la empresa");
			const blob = await response.blob();
			const slug = empresaNombre.toLowerCase().replace(/[^a-z0-9]/g, "_");
			const filename = `backup_${slug}_${new Date().toISOString().slice(0, 10)}.json`;
			const downloadUrl = window.URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = downloadUrl;
			link.setAttribute("download", filename);
			document.body.appendChild(link);
			link.click();
			link.remove();
			window.URL.revokeObjectURL(downloadUrl);
			if (showToast) showToast(`Snapshot de ${empresaNombre} descargado con éxito.`, "success");
			fetchEmpresasResumen();
		} catch (err) {
			if (showToast) showToast(err.message, "error");
		} finally {
			setDownloadingEmpresaId(null);
		}
	};
	/**
	* Manejador de importación y restauración de base de datos
	*/
	const handleFileChange = async (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (!file.name.endsWith(".json")) {
			if (showToast) showToast("Por favor selecciona un archivo con extensión .json", "error");
			if (fileInputRef.current) fileInputRef.current.value = "";
			return;
		}
		const confirmRestore = window.confirm(`⚠️ ¿Estás seguro de que deseas restaurar la base de datos con "${file.name}"?\n\nEsta acción reemplazará la información existente en la base de datos.`);
		if (!confirmRestore) {
			if (fileInputRef.current) fileInputRef.current.value = "";
			return;
		}
		setIsImporting(true);
		setImportStats(null);
		try {
			const text = await file.text();
			const parsedData = JSON.parse(text);
			const payloadData = Array.isArray(parsedData) ? parsedData : parsedData.data || parsedData.empresas || [];
			if (!Array.isArray(payloadData) || payloadData.length === 0) {
				throw new Error("El archivo no contiene registros válidos de empresas o proyectos.");
			}
			const response = await fetch(`${API_BASE_URL}/api/backups/import`, {
				method: "POST",
				headers: getAuthHeaders(),
				body: JSON.stringify({ data: payloadData })
			});
			const result = await response.json();
			if (!response.ok || !result.ok && !result.success) {
				throw new Error(result.error || "Error al restaurar datos en el servidor.");
			}
			if (importCompanies) importCompanies(payloadData);
			setImportStats({
				filename: file.name,
				empresasRestauradas: payloadData.length,
				timestamp: new Date().toLocaleTimeString("es-VE")
			});
			if (showToast) showToast("Base de datos restaurada correctamente.", "success");
			fetchEmpresasResumen();
		} catch (err) {
			if (showToast) showToast(err.message || "Error al restaurar", "error");
		} finally {
			setIsImporting(false);
			if (fileInputRef.current) fileInputRef.current.value = "";
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "max-w-7xl mx-auto space-y-8 pb-16 px-2 sm:px-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 relative overflow-hidden shadow-2xl",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { className: "absolute -right-12 -bottom-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 488,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { className: "absolute -left-12 -top-12 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 489,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-start gap-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-xl shadow-amber-500/20 shrink-0",
								children: /* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-8 h-8" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 494,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 493,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5 flex-wrap",
								children: [/* @__PURE__ */ _jsxDEV("h1", {
									className: "text-2xl md:text-3xl font-black text-white tracking-tight",
									children: "Centro de Control & Resiliencia"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 498,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "px-3 py-0.5 rounded-full text-xs font-bold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 502,
										columnNumber: 19
									}, this), "Sistema Protegido"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 501,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 497,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-400 text-sm mt-1 max-w-2xl leading-relaxed",
								children: "Gestión integral de continuidad operativa, respaldos maestros en memoria, resguardo individual por empresa y certificación criptográfica de activos eléctricos."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 506,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 496,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 492,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-start gap-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-col items-center",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: descargarCopiaLocalDirecta,
										className: "flex items-center gap-2.5 py-3 px-5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 active:scale-[0.98] text-slate-950 font-bold rounded-2xl shadow-lg shadow-emerald-500/20 transition-all cursor-pointer text-sm",
										title: "Descarga directa instantánea desde el navegador (sin requerir red ni backend)",
										children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4 stroke-[2.5]" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 520,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Descarga Inmediata Local (.json)" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 521,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 515,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-emerald-400/90 mt-1.5 font-medium text-center max-w-[260px]",
										children: "Ruta destino: Almacenamiento local (Carpeta de Descargas / Downloads)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 523,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 514,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-col items-center",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleTriggerGlobalPipeline,
										disabled: isAnyProcessing,
										className: "flex items-center gap-2.5 py-3 px-5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none text-slate-950 font-bold rounded-2xl shadow-lg shadow-amber-500/20 transition-all cursor-pointer text-sm",
										children: isExecutingGlobalPipeline ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 536,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Ejecutando Respaldo Nube..." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 537,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 535,
											columnNumber: 19
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 fill-slate-950" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 541,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Respaldo Servidor / Nube" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 542,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 540,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 529,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-amber-400/90 mt-1.5 font-medium text-center max-w-[260px]",
										children: "Ruta destino: Base de Datos Central PostgreSQL (/api/backup/cloud)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 546,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 528,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: fetchEmpresasResumen,
									disabled: isLoadingEmpresas || isAnyProcessing,
									className: "p-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-2xl border border-slate-700 transition-all cursor-pointer disabled:opacity-50 mt-0.5",
									title: "Refrescar métricas",
									children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: `w-4 h-4 ${isLoadingEmpresas ? "animate-spin" : ""}` }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 557,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 551,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 512,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 491,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 lg:grid-cols-4 gap-3.5 mt-8 pt-6 border-t border-slate-800/80",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950/60 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-slate-400 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Empresas Auditadas" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 568,
											columnNumber: 15
										}, this), /* @__PURE__ */ _jsxDEV(Building2, { className: "w-4 h-4 text-cyan-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 569,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 567,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-2xl font-black text-white mt-2",
										children: totalEmpresas
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 571,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-emerald-400 mt-1 flex items-center gap-1 font-medium",
										children: [
											/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3 h-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 573,
												columnNumber: 15
											}, this),
											" ",
											totalEmpresas,
											" con resguardo activo"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 572,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 566,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950/60 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-slate-400 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Activos Eléctricos" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 579,
											columnNumber: 15
										}, this), /* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 580,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 578,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-2xl font-black text-amber-400 mt-2",
										children: totalActivosProtegidos
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 582,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-slate-400 mt-1",
										children: [
											totalTableros,
											" tableros • ",
											totalCircuitos,
											" polos"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 583,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 577,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950/60 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-slate-400 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Canales de Resguardo" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 590,
											columnNumber: 15
										}, this), /* @__PURE__ */ _jsxDEV(Send, { className: "w-4 h-4 text-indigo-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 591,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 589,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 mt-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-2xl font-black text-indigo-400",
											children: totalVinculadosTelegram
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 594,
											columnNumber: 15
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs text-slate-400",
											children: [
												"/ ",
												totalEmpresas,
												" chats"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 595,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 593,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-indigo-300 mt-1 flex items-center gap-1",
										children: "Bot @SelectricBackup_bot"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 597,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 588,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950/60 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-slate-400 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Frecuencia Automática" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 604,
											columnNumber: 15
										}, this), /* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 605,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 603,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm font-bold text-white mt-2",
										children: "02:00 AM (UTC-4)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 607,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-slate-400 mt-1",
										children: "Nightly Cron + On-Demand"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 608,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 602,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 565,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 mt-8 bg-slate-950/80 p-1.5 rounded-2xl border border-slate-800 w-fit",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("empresas"),
							className: `flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${activeTab === "empresas" ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20" : "text-slate-400 hover:text-white"}`,
							children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 626,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
								"Control por Empresas (",
								empresasResumen.length,
								")"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 627,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 618,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("global"),
							className: `flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${activeTab === "global" ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20" : "text-slate-400 hover:text-white"}`,
							children: [/* @__PURE__ */ _jsxDEV(Database, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 638,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Snapshots Maestros & Disaster Recovery" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 639,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 630,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 617,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 487,
				columnNumber: 7
			}, this),
			activeTab === "empresas" && /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl p-4 md:p-5 flex flex-col md:flex-row items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "relative w-full md:w-96",
						children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 652,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value),
							placeholder: "Buscar empresa por nombre o RIF...",
							className: "w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-2xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 653,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 651,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0",
						children: [
							/* @__PURE__ */ _jsxDEV(Filter, { className: "w-4 h-4 text-slate-500 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 663,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStatusFilter("ALL"),
								className: `px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${statusFilter === "ALL" ? "bg-slate-800 text-white border border-slate-700" : "text-slate-400 hover:text-slate-200"}`,
								children: [
									"Todas (",
									empresasResumen.length,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 664,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStatusFilter("VINCULADOS"),
								className: `px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${statusFilter === "VINCULADOS" ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30" : "text-slate-400 hover:text-slate-200"}`,
								children: [
									"Con Telegram (",
									totalVinculadosTelegram,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 674,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStatusFilter("PENDIENTES"),
								className: `px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${statusFilter === "PENDIENTES" ? "bg-amber-500/20 text-amber-300 border border-amber-500/30" : "text-slate-400 hover:text-slate-200"}`,
								children: [
									"Sin Telegram (",
									totalEmpresas - totalVinculadosTelegram,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 684,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 662,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 650,
					columnNumber: 11
				}, this), isLoadingEmpresas ? /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center",
					children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-8 h-8 text-amber-400 animate-spin mx-auto mb-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 700,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-slate-400 text-sm",
						children: "Auditando fichas de resguardo por empresa..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 701,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 699,
					columnNumber: 13
				}, this) : filteredEmpresas.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center text-slate-400",
					children: [
						/* @__PURE__ */ _jsxDEV(Building2, { className: "w-12 h-12 text-slate-600 mx-auto mb-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 705,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "font-bold text-white",
							children: "No se encontraron empresas"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 706,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs mt-1",
							children: "Prueba con otro término de búsqueda o filtro."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 707,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 704,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-5",
					children: filteredEmpresas.map((emp) => /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-3xl p-6 flex flex-col justify-between shadow-xl transition-all relative overflow-hidden group",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-11 h-11 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-950 border border-slate-700 flex items-center justify-center text-amber-400 font-bold shrink-0",
											children: /* @__PURE__ */ _jsxDEV(Building2, { className: "w-5 h-5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 721,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 720,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "font-bold text-base text-white group-hover:text-amber-400 transition-colors",
											children: emp.nombre
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 724,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-400 font-mono",
											children: ["RIF: ", emp.rif]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 727,
											columnNumber: 27
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 723,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 719,
										columnNumber: 23
									}, this), emp.telegramChatId ? /* @__PURE__ */ _jsxDEV("span", {
										className: "px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 flex items-center gap-1.5 shrink-0",
										children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-3 h-3" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 733,
											columnNumber: 27
										}, this), "Telegram Activo"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 732,
										columnNumber: 25
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center gap-1.5 shrink-0",
										children: [/* @__PURE__ */ _jsxDEV(Key, { className: "w-3 h-3" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 738,
											columnNumber: 27
										}, this), "PIN Pendiente"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 737,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 718,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-2 bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-center p-1.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 text-[11px] block",
												children: "Proyectos"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 747,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-white text-sm",
												children: emp.totales?.proyectos || 0
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 748,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 746,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-center p-1.5 border-x border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 text-[11px] block",
												children: "Tableros"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 751,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-amber-400 text-sm",
												children: emp.totales?.tableros || 0
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 752,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 750,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-center p-1.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 text-[11px] block",
												children: "Total Equipos"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 755,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-emerald-400 text-sm",
												children: emp.totales?.totalActivos || 0
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 756,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 754,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 745,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between text-xs text-slate-400 px-1",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5 text-slate-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 763,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: emp.ultimoBackupAt ? `Último: ${new Date(emp.ultimoBackupAt).toLocaleDateString("es-VE")}` : "Resguardo pendiente" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 764,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 762,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-[10px] text-slate-500",
										children: emp.certificadoHash
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 770,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 761,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 716,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-6 pt-5 border-t border-slate-800/80 flex items-center justify-between gap-2 flex-wrap",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleOpenCertModal(emp),
									className: "flex items-center gap-1.5 py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-semibold transition-all cursor-pointer",
									title: "Ver Certificado Ejecutivo de Resguardo",
									children: [/* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 784,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Certificado" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 785,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 779,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleDownloadEmpresaSnapshot(emp.id, emp.nombre),
									disabled: isAnyProcessing,
									className: "flex items-center gap-1.5 py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-semibold transition-all cursor-pointer disabled:opacity-50 disabled:pointer-events-none",
									title: "Descargar snapshot JSON aislado",
									children: [downloadingEmpresaId === emp.id ? /* @__PURE__ */ _jsxDEV(Loader2, { className: "w-3.5 h-3.5 animate-spin text-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 795,
										columnNumber: 27
									}, this) : /* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 797,
										columnNumber: 27
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "JSON Aislado" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 799,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 788,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 778,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleOpenPinModal(emp),
								className: `flex items-center gap-1.5 py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${emp.telegramChatId ? "bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30" : "bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30"}`,
								children: [/* @__PURE__ */ _jsxDEV(Key, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 811,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: emp.telegramChatId ? "Re-vincular PIN" : "Vincular Telegram" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 812,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 803,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 777,
							columnNumber: 19
						}, this)]
					}, emp.id, true, {
						fileName: _jsxFileName,
						lineNumber: 712,
						columnNumber: 17
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 710,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 648,
				columnNumber: 9
			}, this),
			activeTab === "global" && /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-3 gap-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 md:p-8 flex flex-col justify-between shadow-xl relative overflow-hidden group hover:border-emerald-500/50 transition-all",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold shadow-lg shadow-emerald-500/10",
										children: /* @__PURE__ */ _jsxDEV(Download, { className: "w-6 h-6 stroke-[2.5]" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 833,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 832,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "font-bold text-lg text-white",
										children: "Descarga Local Inmediata"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 836,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-emerald-400 font-medium",
										children: "100% Offline • Sin backend • Rescate directo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 837,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 835,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 831,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-300 text-sm leading-relaxed",
									children: "Exporta instantáneamente al navegador todos los datos cargados en memoria y almacenamiento local (empresas, tableros, circuitos, mediciones) en formato JSON. Funciona aún con token vencido o sin conexión."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 841,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 830,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-8 pt-6 border-t border-slate-800 flex flex-col items-center",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: descargarCopiaLocalDirecta,
									className: "w-full flex items-center justify-center gap-2.5 py-3.5 px-5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 active:scale-[0.98] text-slate-950 font-black rounded-2xl shadow-lg shadow-emerald-500/20 transition-all cursor-pointer text-sm",
									children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-5 h-5 stroke-[2.5]" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 851,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Descarga Inmediata Local (.json)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 852,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 847,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-emerald-400/90 mt-2 text-center font-medium",
									children: "Ruta destino: Almacenamiento local (Carpeta de Descargas / Downloads)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 854,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 846,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 829,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 flex flex-col justify-between shadow-xl relative overflow-hidden",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-bold",
											children: /* @__PURE__ */ _jsxDEV(Download, { className: "w-6 h-6" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 865,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 864,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "font-bold text-lg text-white",
											children: "Snapshot Maestro en Memoria"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 868,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-400",
											children: "Descarga directa sin bloqueos de disco (Serverless & Docker)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 869,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 867,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 863,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-300 text-sm leading-relaxed",
										children: "Genera el volcado total estructurado de la base de datos (empresas, proyectos, tableros, circuitos, alimentadores, mediciones, CCM y termografías) en un único archivo JSON compatible con Disaster Recovery."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 873,
										columnNumber: 17
									}, this),
									exportStats && /* @__PURE__ */ _jsxDEV("div", {
										className: "p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-1 text-xs text-slate-300",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1.5 text-emerald-400 font-bold",
												children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 880,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Último snapshot maestro descargado" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 881,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 879,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-400 font-mono truncate",
												children: exportStats.filename
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 883,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-400",
												children: [
													"Tamaño: ",
													exportStats.size,
													" • ",
													exportStats.timestamp
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 884,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 878,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 862,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-8 pt-6 border-t border-slate-800 flex flex-col items-center",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleExportGlobalJson,
									disabled: isAnyProcessing,
									className: "w-full flex items-center justify-center gap-2.5 py-3.5 px-5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none text-slate-950 font-bold rounded-2xl shadow-lg shadow-amber-500/20 transition-all cursor-pointer text-sm",
									children: isExportingGlobal ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-5 h-5 animate-spin" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 897,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Generando archivo JSON..." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 898,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 896,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 902,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Descargar Snapshot Nube (.json)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 903,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 901,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 890,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-amber-400/90 mt-2 text-center font-medium",
									children: "Ruta destino: Base de Datos Central PostgreSQL (/api/backup/cloud)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 907,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 889,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 861,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 flex flex-col justify-between shadow-xl relative overflow-hidden",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 font-bold",
											children: /* @__PURE__ */ _jsxDEV(UploadCloud, { className: "w-6 h-6" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 918,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 917,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "font-bold text-lg text-white",
											children: "Restauración y Reconstrucción"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 921,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-400",
											children: "Recuperación completa atómica con integridad referencial"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 922,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 920,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 916,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-300 text-sm leading-relaxed",
										children: "Restaura la estructura completa de proyectos eléctricos a partir de un respaldo maestro previo. Regenera claves foráneas, circuitos y jerarquías sin inconsistencias."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 926,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										ref: fileInputRef,
										accept: ".json,application/json",
										onChange: handleFileChange,
										className: "hidden"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 930,
										columnNumber: 17
									}, this),
									importStats && /* @__PURE__ */ _jsxDEV("div", {
										className: "p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-1 text-xs text-slate-300",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1.5 text-cyan-400 font-bold",
												children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 941,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Restauración completada con éxito" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 942,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 940,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-400 font-mono truncate",
												children: importStats.filename
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 944,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-400",
												children: [
													importStats.empresasRestauradas,
													" empresas restauradas • ",
													importStats.timestamp
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 945,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 939,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 915,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-8 pt-6 border-t border-slate-800",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => fileInputRef.current?.click(),
									disabled: isAnyProcessing,
									className: "w-full flex items-center justify-center gap-2.5 py-3.5 px-5 bg-slate-800 hover:bg-slate-700 hover:text-cyan-300 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none text-slate-200 font-bold rounded-2xl border border-slate-700 transition-all cursor-pointer text-sm",
									children: isImporting ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-5 h-5 animate-spin text-cyan-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 958,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Procesando restauración atómica..." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 959,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 957,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(UploadCloud, { className: "w-5 h-5 text-cyan-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 963,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Seleccionar Archivo de Respaldo (.json)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 964,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 962,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 951,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 950,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 914,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 827,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900/60 border border-slate-800 rounded-3xl p-6 text-xs text-slate-400 flex items-start gap-4",
					children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-6 h-6 text-amber-400 shrink-0 mt-0.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 974,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-slate-200 font-bold text-sm",
							children: "Arquitectura de Alta Disponibilidad"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 976,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "leading-relaxed",
							children: [
								"El sistema ejecuta la recolección de datos de Prisma 100% en memoria para evadir las restricciones de solo lectura (",
								/* @__PURE__ */ _jsxDEV("code", {
									className: "text-amber-300",
									children: "EROFS"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 978,
									columnNumber: 133
								}, this),
								") en funciones serverless de Vercel. Al mismo tiempo, distribuye de forma asíncrona hacia ",
								/* @__PURE__ */ _jsxDEV("strong", {
									className: "text-slate-300",
									children: "Cloudflare R2"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 978,
									columnNumber: 268
								}, this),
								", despacha alertas al canal de ",
								/* @__PURE__ */ _jsxDEV("strong", {
									className: "text-slate-300",
									children: "Telegram Bot"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 978,
									columnNumber: 356
								}, this),
								" y preserva metadatos livianos en PostgreSQL."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 977,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 975,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 973,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 826,
				columnNumber: 9
			}, this),
			selectedPinModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl relative",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setSelectedPinModal(null);
								setCopiedPin(false);
							},
							className: "absolute right-5 top-5 text-slate-500 hover:text-white p-1 rounded-xl bg-slate-800/50 transition-colors",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 998,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 991,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3 mb-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400",
								children: /* @__PURE__ */ _jsxDEV(Key, { className: "w-6 h-6" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1003,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1002,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-bold text-white",
								children: "Vincular Bot de Telegram"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1006,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400",
								children: selectedPinModal.empresa.nombre
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1007,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1005,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1001,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-slate-300 text-xs leading-relaxed mb-6",
							children: "Este PIN temporal de 6 dígitos permite al cliente vincular su chat o canal de Telegram para recibir certificados de resguardo automáticos."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1011,
							columnNumber: 13
						}, this),
						selectedPinModal.isGenerating ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-8 text-center",
							children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-8 h-8 text-indigo-400 animate-spin mx-auto mb-2" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1017,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400",
								children: "Generando PIN criptográfico..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1018,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1016,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 border border-indigo-500/30 rounded-2xl p-5 text-center relative group",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-indigo-400 uppercase font-bold tracking-wider block mb-1",
										children: "PIN de Activación"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1023,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-3xl font-black text-white tracking-widest font-mono",
										children: selectedPinModal.pin || "------"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1026,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											if (selectedPinModal.pin) {
												navigator.clipboard.writeText(selectedPinModal.pin);
												setCopiedPin(true);
												setTimeout(() => setCopiedPin(false), 2500);
											}
										},
										className: "mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 rounded-xl text-xs font-semibold transition-all cursor-pointer",
										children: copiedPin ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1042,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "¡Copiado!" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1043,
											columnNumber: 25
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1041,
											columnNumber: 23
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1047,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Copiar PIN" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1048,
											columnNumber: 25
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1046,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1030,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1022,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950/60 p-4 rounded-2xl border border-slate-800 text-xs text-slate-300 space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "font-bold text-white flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5 text-indigo-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1056,
										columnNumber: 21
									}, this), " Instrucciones para el usuario:"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1055,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("ol", {
									className: "list-decimal list-inside space-y-1 text-slate-400 pl-1",
									children: [
										/* @__PURE__ */ _jsxDEV("li", { children: ["Abre Telegram y busca el bot ", /* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-200",
											children: "@SelectricBackup_bot"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1059,
											columnNumber: 54
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1059,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: ["Envía el comando: ", /* @__PURE__ */ _jsxDEV("code", {
											className: "text-amber-300 bg-slate-900 px-1.5 py-0.5 rounded",
											children: ["/vincular ", selectedPinModal.pin]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1060,
											columnNumber: 43
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1060,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: "¡Listo! El canal recibirá la certificación de resguardo." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1061,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1058,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1054,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1021,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-6 flex justify-end",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setSelectedPinModal(null);
									setCopiedPin(false);
								},
								className: "py-2.5 px-5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs transition-all cursor-pointer",
								children: "Cerrar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1068,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1067,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 990,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 989,
				columnNumber: 9
			}, this),
			selectedCertModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 max-w-lg w-full shadow-2xl relative overflow-hidden",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => {
							setSelectedCertModal(null);
							setCopiedCert(false);
						},
						className: "absolute right-5 top-5 text-slate-500 hover:text-white p-1 rounded-xl bg-slate-800/50 transition-colors",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1095,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1088,
						columnNumber: 13
					}, this), selectedCertModal.isLoading ? /* @__PURE__ */ _jsxDEV("div", {
						className: "py-12 text-center",
						children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-8 h-8 text-amber-400 animate-spin mx-auto mb-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1100,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Generando certificado oficial de resguardo..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1101,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1099,
						columnNumber: 15
					}, this) : selectedCertModal.ficha ? /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "border-b border-slate-800 pb-5 text-center",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto mb-3 shadow-lg shadow-emerald-500/10",
										children: /* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-7 h-7" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1108,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1107,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-lg font-black text-white uppercase tracking-wide",
										children: "Certificado de Resguardo Eléctrico"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1110,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 mt-0.5 font-mono",
										children: selectedCertModal.ficha.certificado.codigo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1113,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1106,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950/70 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between items-center py-1 border-b border-slate-800/60",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400",
											children: "Empresa:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1121,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("strong", {
											className: "text-white font-semibold",
											children: selectedCertModal.ficha.empresa.nombre
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1122,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1120,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between items-center py-1 border-b border-slate-800/60",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400",
											children: "RIF:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1125,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-200 font-mono",
											children: selectedCertModal.ficha.empresa.rif
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1126,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1124,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between items-center py-1 border-b border-slate-800/60",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400",
											children: "Última Sincronización:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1129,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-amber-400 font-semibold",
											children: selectedCertModal.ficha.empresa.ultimoBackupAt ? new Date(selectedCertModal.ficha.empresa.ultimoBackupAt).toLocaleString("es-VE") : "En proceso"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1130,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1128,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between items-center py-1",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400",
											children: "Estado de Protección:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1137,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400",
											children: "✓ Snapshot Criptográfico Verificado"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1138,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1136,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1119,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-bold text-slate-300",
									children: "Activos Eléctricos Resguardados:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1146,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-2 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 flex justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-400",
												children: "Proyectos:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1149,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-white",
												children: selectedCertModal.ficha.totales.proyectos
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1150,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1148,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 flex justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-400",
												children: "Tableros:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1153,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-amber-400",
												children: selectedCertModal.ficha.totales.tableros
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1154,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1152,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 flex justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-400",
												children: "Circuitos:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1157,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-cyan-400",
												children: selectedCertModal.ficha.totales.circuitos
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1158,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1156,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 flex justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-400",
												children: "Total Activos:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1161,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-emerald-400",
												children: selectedCertModal.ficha.totales.totalActivos
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1162,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1160,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1147,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1145,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between pt-4 border-t border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										const textCert = `🛡️ CERTIFICADO DE RESGUARDO SELECTRIC\nEmpresa: ${selectedCertModal.ficha.empresa.nombre}\nCódigo: ${selectedCertModal.ficha.certificado.codigo}\nTotal Activos: ${selectedCertModal.ficha.totales.totalActivos}\nFecha: ${new Date().toLocaleDateString("es-VE")}`;
										navigator.clipboard.writeText(textCert);
										setCopiedCert(true);
										setTimeout(() => setCopiedCert(false), 2500);
									},
									className: "flex items-center gap-1.5 py-2 px-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-all cursor-pointer",
									children: copiedCert ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1180,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "¡Copiado!" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1181,
										columnNumber: 25
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1179,
										columnNumber: 23
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1185,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Copiar Certificado" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1186,
										columnNumber: 25
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1184,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1169,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setSelectedCertModal(null);
										setCopiedCert(false);
									},
									className: "py-2 px-5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl text-xs transition-all cursor-pointer shadow-md shadow-amber-500/20",
									children: "Aceptar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1191,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1168,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1104,
						columnNumber: 15
					}, this) : null]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1087,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1086,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 483,
		columnNumber: 5
	}, this);
};
_s(BackupView, "bn7wDCb8w/Kf/qOD6kEuto71HXI=", false, function() {
	return [useStore];
});
_c = BackupView;
export default BackupView;
var _c;
$RefreshReg$(_c, "BackupView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/views/BackupView.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/BackupView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/BackupView.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/BackupView.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxRQUFRLGVBQWU7QUFDNUQsT0FBTyxjQUFjO0FBQ3JCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQ0UsYUFDQSxhQUNBLFVBQ0EsYUFDQSxVQUNBLGNBQ0EsYUFDQSxTQUNBLFFBQ0EsS0FDQSxPQUNBLFVBQ0EsVUFDQSxXQUNBLFdBQ0EsV0FDQSxNQUNBLEtBQ0EsTUFDQSxPQUNBLFFBQ0EsUUFDQSxjQUNBLGNBQ0EsV0FDQSxNQUNBLEdBQ0EsTUFDQSxXQUNLOzs7O0FBRVAsT0FBTyxNQUFNLG1CQUFtQjs7Q0FDOUIsTUFBTSxFQUFFLE1BQU0sT0FBTyxXQUFXLGlCQUFpQixjQUFjLFNBQVM7Q0FDeEUsTUFBTSxlQUFlLE9BQU8sSUFBSTs7Q0FHaEMsTUFBTSxzQkFBc0I7RUFDMUIsT0FBTyxTQUFTLFNBQVMsQ0FBQyxDQUFDLFVBQVUsT0FBTyxpQkFBaUIsY0FBYyxhQUFhLFFBQVEsT0FBTyxJQUFJLFFBQVEsT0FBTyxtQkFBbUIsY0FBYyxlQUFlLFFBQVEsT0FBTyxJQUFJLE9BQU87Q0FDdE07Q0FFQSxNQUFNLGtCQUFrQixRQUFRLENBQUMsTUFBTTtFQUNyQyxNQUFNLElBQUksY0FBYztFQUN4QixPQUFPO0dBQ0wsZ0JBQWdCO0dBQ2hCLEdBQUksSUFBSSxFQUFFLGlCQUFpQixVQUFVLElBQUksSUFBSSxDQUFDO0dBQzlDLEdBQUc7RUFDTDtDQUNGOztDQUdBLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLFVBQVU7Q0FDckQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTtDQUNqRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLOztDQUd0RCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLENBQUMsQ0FBQztDQUN6RCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7O0NBR2hFLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsSUFBSTtDQUM3RCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLElBQUk7Q0FDL0QsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLOztDQUdsRCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7Q0FDaEUsTUFBTSxDQUFDLDJCQUEyQixnQ0FBZ0MsU0FBUyxLQUFLO0NBQ2hGLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsSUFBSTtDQUNuRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxJQUFJOztDQUduRCxNQUFNLENBQUMsc0JBQXNCLDJCQUEyQixTQUFTLElBQUk7O0NBR3JFLE1BQU0seUJBQXlCLE9BQU8sQ0FBQztDQUV2QyxNQUFNLGtCQUFrQiw2QkFBNkIscUJBQXFCLGVBQWUsUUFBUSxvQkFBb0I7Ozs7OztDQU9ySCxNQUFNLG1DQUFtQztFQUN2QyxJQUFJO0dBQ0YsTUFBTSxTQUFTLFNBQVMsU0FBUztHQUNqQyxNQUFNLGtCQUFrQixPQUFPLGFBQWEsT0FBTyxZQUFZLENBQUM7R0FDaEUsTUFBTSxtQkFBbUIsT0FBTyxhQUFhLE9BQU8sWUFBWSxDQUFDO0dBRWpFLE1BQU0sYUFBYTtJQUNqQixTQUFTO0lBQ1QsaUJBQWlCO0lBQ2pCLFNBQVM7SUFDVCxpQkFBaUIsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0lBQ3hDLGFBQWEsT0FBTyxjQUFjLGNBQWMsVUFBVSxZQUFZO0lBQ3RFLFVBQVU7S0FDUixtQkFBbUI7S0FDbkIsZUFBZSxnQkFBZ0I7S0FDL0IsZ0JBQWdCLGlCQUFpQjtLQUNqQyxnQkFBZ0IsT0FBTyxZQUFZLENBQUMsRUFBQyxDQUFFO0tBQ3ZDLGlCQUFpQixPQUFPLGFBQWEsQ0FBQyxFQUFDLENBQUU7S0FDekMsWUFBWSxJQUFJLEtBQUssQ0FBQyxDQUFDLGVBQWUsT0FBTztJQUMvQztJQUNBLE1BQU07SUFDTixPQUFPO0tBQ0wsVUFBVTtLQUNWLFdBQVc7S0FDWCxlQUFlLE9BQU8saUJBQWlCLENBQUM7S0FDeEMsVUFBVSxPQUFPLFlBQVksQ0FBQztLQUM5QixXQUFXLE9BQU8sYUFBYSxDQUFDO0tBQ2hDLFlBQVksT0FBTyxjQUFjLE9BQU8sa0JBQWtCLENBQUM7S0FDM0QsS0FBSyxPQUFPLFdBQVcsT0FBTyxPQUFPLENBQUM7S0FDdEMsMkJBQTJCLE9BQU8sNkJBQTZCLENBQUM7S0FDaEUsMEJBQTBCLE9BQU8sNEJBQTRCLENBQUM7S0FDOUQsZ0NBQWdDLE9BQU8sa0NBQWtDLENBQUM7S0FDMUUsU0FBUyxPQUFPLFdBQVcsQ0FBQztLQUM1QixlQUFlLE9BQU8saUJBQWlCLENBQUM7SUFDMUM7R0FDRjtHQUVBLE1BQU0sYUFBYSxLQUFLLFVBQVUsWUFBWSxNQUFNLENBQUM7R0FDckQsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLFVBQVUsR0FBRyxFQUFFLE1BQU0saUNBQWlDLENBQUM7R0FDOUUsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7R0FDcEMsTUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0dBQ3ZDLEtBQUssT0FBTztHQUNaLEtBQUssV0FBVyw0QkFBNEIsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxFQUFFO0dBQ2xGLFNBQVMsS0FBSyxZQUFZLElBQUk7R0FDOUIsS0FBSyxNQUFNO0dBQ1gsU0FBUyxLQUFLLFlBQVksSUFBSTtHQUM5QixJQUFJLGdCQUFnQixHQUFHO0dBRXZCLElBQUksV0FBVztJQUNiLFVBQVUsMEVBQTBFLFNBQVM7R0FDL0Y7RUFDRixTQUFTLEtBQUs7R0FDWixRQUFRLE1BQU0sNkNBQTZDLEdBQUc7R0FDOUQsSUFBSSxXQUFXO0lBQ2IsVUFBVSx1Q0FBdUMsSUFBSSxTQUFTLE9BQU87R0FDdkU7RUFDRjtDQUNGOzs7O0NBS0EsTUFBTSx1QkFBdUIsWUFBWTtFQUN2QyxxQkFBcUIsSUFBSTtFQUN6QixJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLGFBQWEsK0JBQStCLEVBQzFFLFNBQVMsZUFBZSxFQUMxQixDQUFDO0dBRUQsSUFBSSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztJQUN0RCxTQUFTLFNBQVMsQ0FBQyxDQUFDLGtCQUFrQixTQUFTLE1BQU07SUFDckQ7R0FDRjtHQUVBLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztHQUNqQyxJQUFJLFNBQVMsTUFBTSxLQUFLLElBQUk7SUFDMUIsbUJBQW1CLEtBQUssUUFBUSxDQUFDLENBQUM7R0FDcEM7RUFDRixTQUFTLEtBQUs7R0FDWixRQUFRLE1BQU0sd0NBQXdDLEdBQUc7RUFDM0QsVUFBVTtHQUNSLHFCQUFxQixLQUFLO0VBQzVCO0NBQ0Y7Q0FFQSxnQkFBZ0I7RUFDZCxxQkFBcUI7Q0FDdkIsR0FBRyxDQUFDLEtBQUssQ0FBQzs7Q0FHVixNQUFNLGdCQUFnQixnQkFBZ0IsVUFBVSxXQUFXLFVBQVU7Q0FDckUsTUFBTSxnQkFBZ0IsZ0JBQWdCLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRSxTQUFTLFlBQVksSUFBSSxDQUFDO0NBQzVGLE1BQU0saUJBQWlCLGdCQUFnQixRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUUsU0FBUyxhQUFhLElBQUksQ0FBQztDQUM5RixNQUFNLHlCQUF5QixnQkFBZ0IsUUFBUSxLQUFLLE1BQU0sT0FBTyxFQUFFLFNBQVMsZ0JBQWdCLElBQUksQ0FBQztDQUN6RyxNQUFNLDBCQUEwQixnQkFBZ0IsUUFBTyxNQUFLLEVBQUUsY0FBYyxDQUFDLENBQUM7O0NBRzlFLE1BQU0sbUJBQW1CLGNBQWM7RUFDckMsT0FBTyxnQkFBZ0IsUUFBTyxRQUFPO0dBQ25DLE1BQU0sZ0JBQWdCLElBQUksT0FBTyxZQUFZLENBQUMsQ0FBQyxTQUFTLFlBQVksWUFBWSxDQUFDLEtBQzNELElBQUksSUFBSSxZQUFZLENBQUMsQ0FBQyxTQUFTLFlBQVksWUFBWSxDQUFDO0dBQzlFLElBQUksQ0FBQyxlQUFlLE9BQU87R0FDM0IsSUFBSSxpQkFBaUIsY0FBYyxPQUFPLENBQUMsQ0FBQyxJQUFJO0dBQ2hELElBQUksaUJBQWlCLGNBQWMsT0FBTyxDQUFDLElBQUk7R0FDL0MsT0FBTztFQUNULENBQUM7Q0FDSCxHQUFHO0VBQUM7RUFBaUI7RUFBYTtDQUFZLENBQUM7Ozs7O0NBTS9DLE1BQU0seUJBQXlCLFlBQVk7RUFDekMsTUFBTSxNQUFNLEtBQUssSUFBSTtFQUNyQixJQUFJLDZCQUE4QixNQUFNLHVCQUF1QixVQUFVLEtBQU87RUFDaEYsdUJBQXVCLFVBQVU7RUFDakMsNkJBQTZCLElBQUk7RUFFakMsSUFBSTtHQUNGLE1BQU0sUUFBUSxjQUFjO0dBQzVCLE1BQU0sUUFBUSxTQUFTLFNBQVM7R0FFaEMsTUFBTSxVQUFVO0lBQ2QsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7SUFDOUIsUUFBUSxxQkFBcUIsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztJQUNsRSxhQUFhO0lBQ2IsVUFBVSxNQUFNLGFBQWEsTUFBTSxZQUFZLENBQUM7SUFDaEQsV0FBVyxNQUFNLGFBQWEsTUFBTSxZQUFZLENBQUM7SUFDakQsZUFBZSxNQUFNLGlCQUFpQixDQUFDO0lBQ3ZDLFVBQVUsTUFBTSxZQUFZLENBQUM7SUFDN0IsV0FBVyxNQUFNLGFBQWEsQ0FBQztJQUMvQixZQUFZLE1BQU0sY0FBYyxNQUFNLGtCQUFrQixDQUFDO0dBQzNEO0dBRUEsTUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLGFBQWEsb0JBQW9CO0lBQy9ELFFBQVE7SUFDUixTQUFTO0tBQ1AsZ0JBQWdCO0tBQ2hCLEdBQUksU0FBUyxVQUFVLHVCQUF1QixFQUFFLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxDQUFDO0lBQzFGO0lBQ0EsTUFBTSxLQUFLLFVBQVUsT0FBTztHQUM5QixDQUFDO0dBRUQsSUFBSSxTQUFTLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztJQUN0RCxTQUFTLFNBQVMsQ0FBQyxDQUFDLGtCQUFrQixTQUFTLE1BQU07SUFDckQsSUFBSSxXQUFXLFVBQVUsZ0VBQWdFLE9BQU87SUFDaEc7R0FDRjtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxZQUFZLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRTtJQUN4RCxNQUFNLElBQUksTUFBTSxVQUFVLFNBQVMseUJBQXlCLFNBQVMsUUFBUTtHQUMvRTtHQUVBLE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxDQUFDLENBQUMsYUFBYSxFQUFFLElBQUksS0FBSyxFQUFFO0dBQ2hFLElBQUksV0FBVztJQUNiLFVBQVUsOENBQThDLFNBQVM7R0FDbkU7R0FDQSxxQkFBcUI7RUFDdkIsU0FBUyxPQUFPO0dBQ2QsUUFBUSxNQUFNLCtCQUErQixLQUFLO0dBQ2xELE1BQU0saUJBQWlCLE1BQU0sU0FBUyxTQUFTLGlCQUFpQixLQUFLLE1BQU0sU0FBUyxTQUFTLGNBQWM7R0FDM0csTUFBTSxlQUFlLGlCQUNqQixrSEFDQyxNQUFNLFdBQVc7R0FDdEIsSUFBSSxXQUFXLFVBQVUsY0FBYyxPQUFPO0VBQ2hELFVBQVU7R0FDUiw2QkFBNkIsS0FBSztFQUNwQztDQUNGO0NBRUEsTUFBTSw4QkFBOEI7Ozs7Q0FLcEMsTUFBTSx5QkFBeUIsWUFBWTtFQUN6QyxNQUFNLE1BQU0sS0FBSyxJQUFJO0VBQ3JCLElBQUkscUJBQXNCLE1BQU0sdUJBQXVCLFVBQVUsS0FBTztFQUN4RSx1QkFBdUIsVUFBVTtFQUNqQyxxQkFBcUIsSUFBSTtFQUN6QixlQUFlLElBQUk7RUFFbkIsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0sR0FBRyxhQUFhLHNCQUFzQixFQUNqRSxTQUFTLGVBQWUsRUFDMUIsQ0FBQztHQUVELElBQUksU0FBUyxXQUFXLE9BQU8sU0FBUyxXQUFXLEtBQUs7SUFDdEQsU0FBUyxTQUFTLENBQUMsQ0FBQyxrQkFBa0IsU0FBUyxNQUFNO0lBQ3JELElBQUksV0FBVyxVQUFVLGdFQUFnRSxPQUFPO0lBQ2hHO0dBQ0Y7R0FFQSxJQUFJLENBQUMsU0FBUyxJQUFJLE1BQU0sSUFBSSxNQUFNLHVDQUF1QztHQUV6RSxJQUFJLFdBQVcsNEJBQTRCLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtHQUNqRixNQUFNLGNBQWMsU0FBUyxRQUFRLElBQUkscUJBQXFCO0dBQzlELElBQUksZUFBZSxZQUFZLFNBQVMsV0FBVyxHQUFHO0lBQ3BELE1BQU0sUUFBUSxZQUFZLE1BQU0sc0JBQXNCO0lBQ3RELElBQUksUUFBUSxJQUFJLFdBQVcsTUFBTTtHQUNuQztHQUVBLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztHQUNqQyxNQUFNLGNBQWMsT0FBTyxJQUFJLGdCQUFnQixJQUFJO0dBQ25ELE1BQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztHQUN2QyxLQUFLLE9BQU87R0FDWixLQUFLLGFBQWEsWUFBWSxRQUFRO0dBQ3RDLFNBQVMsS0FBSyxZQUFZLElBQUk7R0FDOUIsS0FBSyxNQUFNO0dBQ1gsS0FBSyxPQUFPO0dBQ1osT0FBTyxJQUFJLGdCQUFnQixXQUFXO0dBRXRDLGVBQWU7SUFDYjtJQUNBLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSSxDQUFFLFFBQVEsQ0FBQyxFQUFFO0lBQ3ZDLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztHQUNsRCxDQUFDO0dBRUQsSUFBSSxXQUFXLFVBQVUsMkNBQTJDLFNBQVM7RUFDL0UsU0FBUyxLQUFLO0dBQ1osTUFBTSxpQkFBaUIsSUFBSSxTQUFTLFNBQVMsaUJBQWlCLEtBQUssSUFBSSxTQUFTLFNBQVMsY0FBYztHQUN2RyxNQUFNLGVBQWUsaUJBQ2pCLHFGQUNDLElBQUksV0FBVztHQUNwQixJQUFJLFdBQVcsVUFBVSxjQUFjLE9BQU87RUFDaEQsVUFBVTtHQUNSLHFCQUFxQixLQUFLO0VBQzVCO0NBQ0Y7Ozs7Q0FLQSxNQUFNLHFCQUFxQixPQUFPLFlBQVk7RUFDNUMsb0JBQW9CO0dBQUU7R0FBUyxLQUFLLFFBQVE7R0FBbUIsY0FBYztFQUFNLENBQUM7RUFDcEYsSUFBSSxDQUFDLFFBQVEsbUJBQW1CO0dBQzlCLElBQUk7SUFDRixxQkFBb0IsVUFBUztLQUFFLEdBQUc7S0FBTSxjQUFjO0lBQUssRUFBRTtJQUM3RCxNQUFNLFdBQVcsTUFBTSxNQUFNLEdBQUcsYUFBYSwwQkFBMEIsUUFBUSxNQUFNO0tBQ25GLFFBQVE7S0FDUixTQUFTLGVBQWU7SUFDMUIsQ0FBQztJQUVELElBQUksU0FBUyxXQUFXLE9BQU8sU0FBUyxXQUFXLEtBQUs7S0FDdEQsU0FBUyxTQUFTLENBQUMsQ0FBQyxrQkFBa0IsU0FBUyxNQUFNO0tBQ3JEO0lBQ0Y7SUFFQSxNQUFNLFVBQVUsTUFBTSxTQUFTLEtBQUs7SUFDcEMsSUFBSSxTQUFTLE1BQU0sUUFBUSxJQUFJO0tBQzdCLG9CQUFvQjtNQUFFO01BQVMsS0FBSyxRQUFRLEtBQUs7TUFBbUIsY0FBYztLQUFNLENBQUM7S0FDekYscUJBQXFCO0lBQ3ZCO0dBQ0YsU0FBUyxLQUFLO0lBQ1osUUFBUSxNQUFNLHlCQUF5QixHQUFHO0dBQzVDO0VBQ0Y7Q0FDRjs7OztDQUtBLE1BQU0sc0JBQXNCLE9BQU8sWUFBWTtFQUM3QyxxQkFBcUI7R0FBRSxPQUFPO0dBQU0sV0FBVztFQUFLLENBQUM7RUFDckQsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0sR0FBRyxhQUFhLHNCQUFzQixRQUFRLEdBQUcsVUFBVSxFQUN0RixTQUFTLGVBQWUsRUFDMUIsQ0FBQztHQUVELElBQUksU0FBUyxXQUFXLE9BQU8sU0FBUyxXQUFXLEtBQUs7SUFDdEQsU0FBUyxTQUFTLENBQUMsQ0FBQyxrQkFBa0IsU0FBUyxNQUFNO0lBQ3JEO0dBQ0Y7R0FFQSxNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUs7R0FDakMsSUFBSSxTQUFTLE1BQU0sS0FBSyxJQUFJO0lBQzFCLHFCQUFxQjtLQUFFLE9BQU8sS0FBSztLQUFNLFdBQVc7SUFBTSxDQUFDO0dBQzdELE9BQU87SUFDTCxNQUFNLElBQUksTUFBTSxLQUFLLFNBQVMsbUNBQW1DO0dBQ25FO0VBQ0YsU0FBUyxLQUFLO0dBQ1osSUFBSSxXQUFXLFVBQVUsSUFBSSxTQUFTLE9BQU87R0FDN0MscUJBQXFCLElBQUk7RUFDM0I7Q0FDRjs7OztDQUtBLE1BQU0sZ0NBQWdDLE9BQU8sV0FBVyxrQkFBa0I7RUFDeEUsTUFBTSxNQUFNLEtBQUssSUFBSTtFQUNyQixJQUFJLHdCQUF5QixNQUFNLHVCQUF1QixVQUFVLEtBQU87RUFDM0UsdUJBQXVCLFVBQVU7RUFDakMsd0JBQXdCLFNBQVM7RUFDakMsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0sR0FBRyxhQUFhLHNCQUFzQixVQUFVLFVBQVUsRUFDckYsU0FBUyxlQUFlLEVBQzFCLENBQUM7R0FFRCxJQUFJLFNBQVMsV0FBVyxPQUFPLFNBQVMsV0FBVyxLQUFLO0lBQ3RELFNBQVMsU0FBUyxDQUFDLENBQUMsa0JBQWtCLFNBQVMsTUFBTTtJQUNyRDtHQUNGO0dBRUEsSUFBSSxDQUFDLFNBQVMsSUFBSSxNQUFNLElBQUksTUFBTSx1Q0FBdUM7R0FFekUsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0dBQ2pDLE1BQU0sT0FBTyxjQUFjLFlBQVksQ0FBQyxDQUFDLFFBQVEsY0FBYyxHQUFHO0dBQ2xFLE1BQU0sV0FBVyxVQUFVLEtBQUssR0FBRyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUU7R0FFekUsTUFBTSxjQUFjLE9BQU8sSUFBSSxnQkFBZ0IsSUFBSTtHQUNuRCxNQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7R0FDdkMsS0FBSyxPQUFPO0dBQ1osS0FBSyxhQUFhLFlBQVksUUFBUTtHQUN0QyxTQUFTLEtBQUssWUFBWSxJQUFJO0dBQzlCLEtBQUssTUFBTTtHQUNYLEtBQUssT0FBTztHQUNaLE9BQU8sSUFBSSxnQkFBZ0IsV0FBVztHQUV0QyxJQUFJLFdBQVcsVUFBVSxlQUFlLGNBQWMseUJBQXlCLFNBQVM7R0FDeEYscUJBQXFCO0VBQ3ZCLFNBQVMsS0FBSztHQUNaLElBQUksV0FBVyxVQUFVLElBQUksU0FBUyxPQUFPO0VBQy9DLFVBQVU7R0FDUix3QkFBd0IsSUFBSTtFQUM5QjtDQUNGOzs7O0NBS0EsTUFBTSxtQkFBbUIsT0FBTyxNQUFNO0VBQ3BDLE1BQU0sT0FBTyxFQUFFLE9BQU8sUUFBUTtFQUM5QixJQUFJLENBQUMsTUFBTTtFQUVYLElBQUksQ0FBQyxLQUFLLEtBQUssU0FBUyxPQUFPLEdBQUc7R0FDaEMsSUFBSSxXQUFXLFVBQVUsdURBQXVELE9BQU87R0FDdkYsSUFBSSxhQUFhLFNBQVMsYUFBYSxRQUFRLFFBQVE7R0FDdkQ7RUFDRjtFQUVBLE1BQU0saUJBQWlCLE9BQU8sUUFDNUIsa0VBQWtFLEtBQUssS0FBSyw0RUFDOUU7RUFDQSxJQUFJLENBQUMsZ0JBQWdCO0dBQ25CLElBQUksYUFBYSxTQUFTLGFBQWEsUUFBUSxRQUFRO0dBQ3ZEO0VBQ0Y7RUFFQSxlQUFlLElBQUk7RUFDbkIsZUFBZSxJQUFJO0VBRW5CLElBQUk7R0FDRixNQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUs7R0FDN0IsTUFBTSxhQUFhLEtBQUssTUFBTSxJQUFJO0dBQ2xDLE1BQU0sY0FBYyxNQUFNLFFBQVEsVUFBVSxJQUN4QyxhQUNDLFdBQVcsUUFBUSxXQUFXLFlBQVksQ0FBQztHQUVoRCxJQUFJLENBQUMsTUFBTSxRQUFRLFdBQVcsS0FBSyxZQUFZLFdBQVcsR0FBRztJQUMzRCxNQUFNLElBQUksTUFBTSxtRUFBbUU7R0FDckY7R0FFQSxNQUFNLFdBQVcsTUFBTSxNQUFNLEdBQUcsYUFBYSxzQkFBc0I7SUFDakUsUUFBUTtJQUNSLFNBQVMsZUFBZTtJQUN4QixNQUFNLEtBQUssVUFBVSxFQUFFLE1BQU0sWUFBWSxDQUFDO0dBQzVDLENBQUM7R0FFRCxNQUFNLFNBQVMsTUFBTSxTQUFTLEtBQUs7R0FDbkMsSUFBSSxDQUFDLFNBQVMsTUFBTyxDQUFDLE9BQU8sTUFBTSxDQUFDLE9BQU8sU0FBVTtJQUNuRCxNQUFNLElBQUksTUFBTSxPQUFPLFNBQVMsMENBQTBDO0dBQzVFO0dBRUEsSUFBSSxpQkFBaUIsZ0JBQWdCLFdBQVc7R0FFaEQsZUFBZTtJQUNiLFVBQVUsS0FBSztJQUNmLHFCQUFxQixZQUFZO0lBQ2pDLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztHQUNsRCxDQUFDO0dBRUQsSUFBSSxXQUFXLFVBQVUsMkNBQTJDLFNBQVM7R0FDN0UscUJBQXFCO0VBQ3ZCLFNBQVMsS0FBSztHQUNaLElBQUksV0FBVyxVQUFVLElBQUksV0FBVyxzQkFBc0IsT0FBTztFQUN2RSxVQUFVO0dBQ1IsZUFBZSxLQUFLO0dBQ3BCLElBQUksYUFBYSxTQUFTLGFBQWEsUUFBUSxRQUFRO0VBQ3pEO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FJRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsb0dBQXFHOzs7OztLQUNwSCx3QkFBQyxPQUFELEVBQUssV0FBVSwrRkFBZ0c7Ozs7O0tBRS9HLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxhQUFELEVBQWEsV0FBVSxVQUFXOzs7OztPQUMvQjs7OztpQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBNEQ7UUFFdEU7Ozs7a0JBQ0osd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsb0RBQXFEOzs7O21CQUFDLG1CQUVsRTs7Ozs7Z0JBQ0g7Ozs7O2lCQUNMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUF3RDtPQUVsRTs7OztlQUNBOzs7O2VBQ0Y7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBRUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7VUFDVixPQUFNO29CQUhSLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsdUJBQXdCOzs7O29CQUM1Qyx3QkFBQyxRQUFELFlBQU0sbUNBQXNDOzs7O2tCQUN0Qzs7Ozs7bUJBQ1Isd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStFO1NBRXpGOzs7O2lCQUNIOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsVUFBVTtVQUNWLFdBQVU7b0JBRVQsNEJBQ0MsZ0RBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsdUJBQXdCOzs7O29CQUMzQyx3QkFBQyxRQUFELFlBQU0sOEJBQWlDOzs7O2tCQUN2Qzs7OztxQkFFRixnREFDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7b0JBQ3pDLHdCQUFDLFFBQUQsWUFBTSwyQkFBOEI7Ozs7a0JBQ3BDOzs7OztTQUVFOzs7O21CQUNSLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2RTtTQUV2Rjs7OztpQkFDSDs7Ozs7O1FBRUwsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxVQUFVLHFCQUFxQjtTQUMvQixXQUFVO1NBQ1YsT0FBTTttQkFFTix3QkFBQyxXQUFELEVBQVcsV0FBVyxXQUFXLG9CQUFvQixpQkFBaUIsS0FBTzs7Ozs7UUFDdkU7Ozs7O09BQ0w7Ozs7O2NBQ0Y7Ozs7OztLQUtMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7b0JBQzlCLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHdCQUF5Qjs7OztrQkFDM0M7Ozs7OztTQUNMLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF1QztTQUFpQjs7Ozs7U0FDckUsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7Ozs7V0FBQztXQUFFO1dBQWM7VUFDaEQ7Ozs7OztRQUNIOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OztvQkFDOUIsd0JBQUMsS0FBRCxFQUFLLFdBQVUseUJBQTBCOzs7O2tCQUN0Qzs7Ozs7O1NBQ0wsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQTJDO1NBQTBCOzs7OztTQUNsRix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEI7V0FDRztXQUFjO1dBQWE7V0FBZTtVQUN2Qzs7Ozs7O1FBQ0g7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sdUJBQTBCOzs7O29CQUNoQyx3QkFBQyxNQUFELEVBQU0sV0FBVSwwQkFBMkI7Ozs7a0JBQ3hDOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF1QztVQUE4Qjs7OztvQkFDckYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCO1lBQXlDO1lBQUc7WUFBYztXQUFZOzs7OztrQkFDbkU7Ozs7OztTQUNMLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyRDtTQUVyRTs7Ozs7UUFDSDs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7b0JBQ2pDLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDJCQUE0Qjs7OztrQkFDMUM7Ozs7OztTQUNMLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFvQztTQUFtQjs7Ozs7U0FDcEUsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWtDO1NBRTVDOzs7OztRQUNIOzs7Ozs7TUFDRjs7Ozs7O0tBS0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLFVBQVU7T0FDdEMsV0FBVyxrR0FDVCxjQUFjLGFBQ1YsOERBQ0E7aUJBTFIsQ0FRRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7O2lCQUNoQyx3QkFBQyxRQUFEO1FBQU07UUFBdUIsZ0JBQWdCO1FBQU87T0FBTzs7OztlQUNyRDs7Ozs7Z0JBRVIsd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxRQUFRO09BQ3BDLFdBQVcsa0dBQ1QsY0FBYyxXQUNWLDhEQUNBO2lCQUxSLENBUUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztpQkFDL0Isd0JBQUMsUUFBRCxZQUFNLHlDQUE0Qzs7OztlQUM1Qzs7Ozs7Y0FDTDs7Ozs7O0lBQ0Y7Ozs7OztHQUtKLGNBQWMsY0FDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsb0VBQXFFOzs7O2dCQUN2Rix3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLE9BQU87T0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztPQUM5QyxhQUFZO09BQ1osV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxrQ0FBbUM7Ozs7O09BQ3JELHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGdCQUFnQixLQUFLO1FBQ3BDLFdBQVcsa0dBQ1QsaUJBQWlCLFFBQ2Isb0RBQ0E7a0JBTFI7U0FPQztTQUNTLGdCQUFnQjtTQUFPO1FBQ3pCOzs7Ozs7T0FDUix3QkFBQyxVQUFEO1FBQ0UsZUFBZSxnQkFBZ0IsWUFBWTtRQUMzQyxXQUFXLGtHQUNULGlCQUFpQixlQUNiLGlFQUNBO2tCQUxSO1NBT0M7U0FDZ0I7U0FBd0I7UUFDakM7Ozs7OztPQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGdCQUFnQixZQUFZO1FBQzNDLFdBQVcsa0dBQ1QsaUJBQWlCLGVBQ2IsOERBQ0E7a0JBTFI7U0FPQztTQUNnQixnQkFBZ0I7U0FBd0I7UUFDakQ7Ozs7OztNQUNMOzs7OzthQUNGOzs7OztjQUdKLG9CQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxtREFBb0Q7Ozs7ZUFDdkUsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQXlCO0tBQStDOzs7O2FBQ2xGOzs7OztlQUNILGlCQUFpQixXQUFXLElBQzlCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSx3Q0FBeUM7Ozs7O01BQzlELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF1QjtNQUE2Qjs7Ozs7TUFDakUsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWU7TUFBZ0Q7Ozs7O0tBQ3pFOzs7OztlQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osaUJBQWlCLEtBQUssUUFDckIsd0JBQUMsT0FBRDtNQUVFLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUVFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7OztVQUM3Qjs7OztvQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsSUFBSTtVQUNIOzs7O29CQUNKLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFiLENBQWdELFNBQU0sSUFBSSxHQUFPOzs7OztrQkFDOUQ7Ozs7a0JBQ0Y7Ozs7O21CQUVKLElBQUksaUJBQ0gsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7OztvQkFBQyxpQkFFeEI7Ozs7O29CQUVOLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLFVBQVc7Ozs7b0JBQUMsZUFFdkI7Ozs7O2lCQUVMOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQW1DO1dBQWU7Ozs7cUJBQ2xFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFnQyxJQUFJLFNBQVMsYUFBYTtXQUFROzs7O21CQUMvRTs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBbUM7V0FBYzs7OztxQkFDakUsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQW9DLElBQUksU0FBUyxZQUFZO1dBQVE7Ozs7bUJBQ2xGOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFtQztXQUFtQjs7OztxQkFDdEUsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXNDLElBQUksU0FBUyxnQkFBZ0I7V0FBUTs7OzttQkFDeEY7Ozs7OztTQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsNkJBQThCOzs7O29CQUMvQyx3QkFBQyxRQUFELFlBQ0csSUFBSSxpQkFDRCxXQUFXLElBQUksS0FBSyxJQUFJLGNBQWMsQ0FBQyxDQUFDLG1CQUFtQixPQUFPLE1BQ2xFLHNCQUNBOzs7O2tCQUNIOzs7OzttQkFDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixJQUFJO1NBQ0Q7Ozs7aUJBQ0g7Ozs7OztPQUNGOzs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLGVBQWUsb0JBQW9CLEdBQUc7U0FDdEMsV0FBVTtTQUNWLE9BQU07bUJBSFIsQ0FLRSx3QkFBQyxXQUFELEVBQVcsV0FBVSwrQkFBZ0M7Ozs7bUJBQ3JELHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7OztpQkFDakI7Ozs7O2tCQUVSLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLDhCQUE4QixJQUFJLElBQUksSUFBSSxNQUFNO1NBQy9ELFVBQVU7U0FDVixXQUFVO1NBQ1YsT0FBTTttQkFKUixDQU1HLHlCQUF5QixJQUFJLEtBQzVCLHdCQUFDLFNBQUQsRUFBUyxXQUFVLDBDQUEyQzs7OztvQkFFOUQsd0JBQUMsVUFBRCxFQUFVLFdBQVUsNkJBQThCOzs7O21CQUVwRCx3QkFBQyxRQUFELFlBQU0sZUFBa0I7Ozs7aUJBQ2xCOzs7OztnQkFDTDs7Ozs7aUJBRUwsd0JBQUMsVUFBRDtRQUNFLGVBQWUsbUJBQW1CLEdBQUc7UUFDckMsV0FBVyxvR0FDVCxJQUFJLGlCQUNBLHdGQUNBO2tCQUxSLENBUUUsd0JBQUMsS0FBRCxFQUFLLFdBQVUsY0FBZTs7OztrQkFDOUIsd0JBQUMsUUFBRCxZQUFPLElBQUksaUJBQWlCLG9CQUFvQixvQkFBMEI7Ozs7Z0JBQ3BFOzs7OztlQUNMOzs7OztjQUNGO1FBdEdFLElBQUk7Ozs7WUFzR04sQ0FDTjtJQUNFOzs7O1lBRUo7Ozs7OztHQU1OLGNBQWMsWUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHVCQUF3Qjs7Ozs7U0FDekM7Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUErQjtTQUE0Qjs7OzttQkFDekUsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXVDO1NBQStDOzs7O2lCQUNoRzs7OztpQkFDRjs7Ozs7a0JBRUwsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlDO1FBRW5EOzs7O2dCQUNBOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTttQkFGWixDQUlFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHVCQUF3Qjs7OzttQkFDNUMsd0JBQUMsUUFBRCxZQUFNLG1DQUFzQzs7OztpQkFDdEM7Ozs7O2tCQUNSLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUEyRDtRQUVyRTs7OztnQkFDSDs7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ2Isd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7Ozs7VUFDNUI7Ozs7b0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUErQjtVQUErQjs7OztvQkFDNUUsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXlCO1VBQStEOzs7O2tCQUNsRzs7OztrQkFDRjs7Ozs7O1NBRUwsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXlDO1NBRW5EOzs7OztTQUVGLGVBQ0Msd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7c0JBQ25DLHdCQUFDLFFBQUQsWUFBTSxxQ0FBd0M7Ozs7b0JBQzNDOzs7Ozs7V0FDTCx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBcUMsWUFBWTtXQUFZOzs7OztXQUMxRSx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBYjthQUE4QjthQUFTLFlBQVk7YUFBSzthQUFJLFlBQVk7WUFBYTs7Ozs7O1VBQ2xGOzs7Ozs7UUFFSjs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFVBQVU7U0FDVixXQUFVO21CQUVULG9CQUNDLGdEQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLHVCQUF3Qjs7OzttQkFDM0Msd0JBQUMsUUFBRCxZQUFNLDRCQUErQjs7OztpQkFDckM7Ozs7b0JBRUYsZ0RBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OzttQkFDL0Isd0JBQUMsUUFBRCxZQUFNLGtDQUFxQzs7OztpQkFDM0M7Ozs7O1FBRUU7Ozs7a0JBQ1Isd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXlEO1FBRW5FOzs7O2dCQUNIOzs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxhQUFELEVBQWEsV0FBVSxVQUFXOzs7OztVQUMvQjs7OztvQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQStCO1VBQWlDOzs7O29CQUM5RSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBeUI7VUFBMkQ7Ozs7a0JBQzlGOzs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBeUM7U0FFbkQ7Ozs7O1NBRUgsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFLO1VBQ0wsUUFBTztVQUNQLFVBQVU7VUFDVixXQUFVO1NBQ1g7Ozs7O1NBRUEsZUFDQyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7OztzQkFDbkMsd0JBQUMsUUFBRCxZQUFNLG9DQUF1Qzs7OztvQkFDMUM7Ozs7OztXQUNMLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUFxQyxZQUFZO1dBQVk7Ozs7O1dBQzFFLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUFiO2FBQStCLFlBQVk7YUFBb0I7YUFBeUIsWUFBWTtZQUFhOzs7Ozs7VUFDOUc7Ozs7OztRQUVKOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxVQUFEO1NBQ0UsZUFBZSxhQUFhLFNBQVMsTUFBTTtTQUMzQyxVQUFVO1NBQ1YsV0FBVTttQkFFVCxjQUNDLGdEQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLHFDQUFzQzs7OzttQkFDekQsd0JBQUMsUUFBRCxZQUFNLHFDQUF3Qzs7OztpQkFDOUM7Ozs7b0JBRUYsZ0RBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsd0JBQXlCOzs7O21CQUNoRCx3QkFBQyxRQUFELFlBQU0sMENBQTZDOzs7O2lCQUNuRDs7Ozs7UUFFRTs7Ozs7T0FDTDs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUseUNBQTBDOzs7O2VBQzlELHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQW1DO01BQXNDOzs7O2dCQUN0Rix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUErQjtRQUN1Rix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUI7UUFBVzs7Ozs7UUFBQztRQUEwRix3QkFBQyxVQUFEO1NBQVEsV0FBVTttQkFBaUI7UUFBcUI7Ozs7O1FBQUM7UUFBK0Isd0JBQUMsVUFBRDtTQUFRLFdBQVU7bUJBQWlCO1FBQW9COzs7OztRQUFDO09BQzFZOzs7OztjQUNBOzs7OzthQUNGOzs7OztZQUNGOzs7Ozs7R0FNTixvQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZTtRQUNiLG9CQUFvQixJQUFJO1FBQ3hCLGFBQWEsS0FBSztPQUNwQjtPQUNBLFdBQVU7aUJBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7TUFDbEI7Ozs7O01BRVIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxLQUFELEVBQUssV0FBVSxVQUFXOzs7OztPQUN2Qjs7OztpQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQStCO09BQTRCOzs7O2lCQUN6RSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBMEIsaUJBQWlCLFFBQVE7T0FBVTs7OztlQUN2RTs7OztlQUNGOzs7Ozs7TUFFTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBOEM7TUFFeEQ7Ozs7O01BRUYsaUJBQWlCLGVBQ2hCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsb0RBQXFEOzs7O2lCQUN4RSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBeUI7T0FBaUM7Ozs7ZUFDcEU7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNEU7U0FFdEY7Ozs7O1NBQ04sd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQ1YsaUJBQWlCLE9BQU87U0FDeEI7Ozs7O1NBRUgsd0JBQUMsVUFBRDtVQUNFLGVBQWU7V0FDYixJQUFJLGlCQUFpQixLQUFLO1lBQ3hCLFVBQVUsVUFBVSxVQUFVLGlCQUFpQixHQUFHO1lBQ2xELGFBQWEsSUFBSTtZQUNqQixpQkFBaUIsYUFBYSxLQUFLLEdBQUcsSUFBSTtXQUM1QztVQUNGO1VBQ0EsV0FBVTtvQkFFVCxZQUNDLGdEQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLCtCQUFnQzs7OztvQkFDakQsd0JBQUMsUUFBRCxZQUFNLFlBQWU7Ozs7a0JBQ3JCOzs7O3FCQUVGLGdEQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7b0JBQy9CLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztrQkFDdEI7Ozs7O1NBRUU7Ozs7O1FBQ0w7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWIsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSw4QkFBK0I7Ozs7bUJBQUMsaUNBQy9DOzs7OztrQkFDSCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZDtVQUNFLHdCQUFDLE1BQUQsYUFBSSxpQ0FBNkIsd0JBQUMsVUFBRDtXQUFRLFdBQVU7cUJBQWlCO1VBQTRCOzs7O2tCQUFLOzs7OztVQUNyRyx3QkFBQyxNQUFELGFBQUksc0JBQWtCLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUFvRSxjQUFXLGlCQUFpQixHQUFVOzs7OztrQkFBSzs7Ozs7VUFDckksd0JBQUMsTUFBRCxZQUFJLDJEQUE0RDs7Ozs7U0FDOUQ7Ozs7O2dCQUNEOzs7OztlQUNGOzs7Ozs7TUFHUCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFEO1FBQ0UsZUFBZTtTQUNiLG9CQUFvQixJQUFJO1NBQ3hCLGFBQWEsS0FBSztRQUNwQjtRQUNBLFdBQVU7a0JBQ1g7T0FFTzs7Ozs7TUFDTDs7Ozs7S0FDRjs7Ozs7O0dBQ0Y7Ozs7O0dBTU4scUJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWU7T0FDYixxQkFBcUIsSUFBSTtPQUN6QixjQUFjLEtBQUs7TUFDckI7TUFDQSxXQUFVO2dCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0tBQ2xCOzs7O2VBRVAsa0JBQWtCLFlBQ2pCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsbURBQW9EOzs7O2dCQUN2RSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUI7TUFBZ0Q7Ozs7Y0FDbkY7Ozs7O2dCQUNILGtCQUFrQixRQUNwQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsV0FBRCxFQUFXLFdBQVUsVUFBVzs7Ozs7U0FDN0I7Ozs7O1NBQ0wsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXdEO1NBRWxFOzs7OztTQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNWLGtCQUFrQixNQUFNLFlBQVk7U0FDcEM7Ozs7O1FBQ0E7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaUI7VUFBYzs7OztvQkFDL0Msd0JBQUMsVUFBRDtXQUFRLFdBQVU7cUJBQTRCLGtCQUFrQixNQUFNLFFBQVE7VUFBZTs7OztrQkFDMUY7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWlCO1VBQVU7Ozs7b0JBQzNDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE0QixrQkFBa0IsTUFBTSxRQUFRO1VBQVU7Ozs7a0JBQ25GOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFpQjtVQUE0Qjs7OztvQkFDN0Qsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2Isa0JBQWtCLE1BQU0sUUFBUSxpQkFDN0IsSUFBSSxLQUFLLGtCQUFrQixNQUFNLFFBQVEsY0FBYyxDQUFDLENBQUMsZUFBZSxPQUFPLElBQy9FO1VBQ0E7Ozs7a0JBQ0g7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWlCO1VBQTJCOzs7O29CQUM1RCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaUg7VUFFM0g7Ozs7a0JBQ0g7Ozs7OztRQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFtQztRQUFtQzs7OztrQkFDbkYsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFpQjtXQUFnQjs7OztxQkFDakQsd0JBQUMsVUFBRDtZQUFRLFdBQVU7c0JBQWMsa0JBQWtCLE1BQU0sUUFBUTtXQUFrQjs7OzttQkFDL0U7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWlCO1dBQWU7Ozs7cUJBQ2hELHdCQUFDLFVBQUQ7WUFBUSxXQUFVO3NCQUFrQixrQkFBa0IsTUFBTSxRQUFRO1dBQWlCOzs7O21CQUNsRjs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUI7V0FBZ0I7Ozs7cUJBQ2pELHdCQUFDLFVBQUQ7WUFBUSxXQUFVO3NCQUFpQixrQkFBa0IsTUFBTSxRQUFRO1dBQWtCOzs7O21CQUNsRjs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUI7V0FBb0I7Ozs7cUJBQ3JELHdCQUFDLFVBQUQ7WUFBUSxXQUFVO3NCQUFvQixrQkFBa0IsTUFBTSxRQUFRO1dBQXFCOzs7O21CQUN4Rjs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQ7U0FDRSxlQUFlO1VBQ2IsTUFBTSxXQUFXLG9EQUFvRCxrQkFBa0IsTUFBTSxRQUFRLE9BQU8sWUFBWSxrQkFBa0IsTUFBTSxZQUFZLE9BQU8sbUJBQW1CLGtCQUFrQixNQUFNLFFBQVEsYUFBYSxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLE9BQU87VUFDblIsVUFBVSxVQUFVLFVBQVUsUUFBUTtVQUN0QyxjQUFjLElBQUk7VUFDbEIsaUJBQWlCLGNBQWMsS0FBSyxHQUFHLElBQUk7U0FDN0M7U0FDQSxXQUFVO21CQUVULGFBQ0MsZ0RBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsK0JBQWdDOzs7O21CQUNqRCx3QkFBQyxRQUFELFlBQU0sWUFBZTs7OztpQkFDckI7Ozs7b0JBRUYsZ0RBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OzttQkFDL0Isd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OztpQkFDOUI7Ozs7O1FBRUU7Ozs7a0JBRVIsd0JBQUMsVUFBRDtTQUNFLGVBQWU7VUFDYixxQkFBcUIsSUFBSTtVQUN6QixjQUFjLEtBQUs7U0FDckI7U0FDQSxXQUFVO21CQUNYO1FBRU87Ozs7Z0JBQ0w7Ozs7OztNQUNGOzs7OztnQkFDSCxJQUNEOzs7Ozs7R0FDRjs7Ozs7RUFFSjs7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCYWNrdXBWaWV3LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHVzZVN0b3JlIGZyb20gJy4uL3N0b3JlL3VzZVN0b3JlJztcbmltcG9ydCB7IEFQSV9CQVNFX1VSTCB9IGZyb20gJy4uL3V0aWxzL2FwaSc7XG5pbXBvcnQgeyBcbiAgU2hpZWxkQ2hlY2ssIFxuICBTaGllbGRBbGVydCxcbiAgRG93bmxvYWQsIFxuICBVcGxvYWRDbG91ZCwgXG4gIERhdGFiYXNlLCBcbiAgQ2hlY2tDaXJjbGUyLCBcbiAgQWxlcnRDaXJjbGUsIFxuICBMb2FkZXIyLCBcbiAgTGF5ZXJzLCBcbiAgWmFwLCBcbiAgQ2xvY2ssIFxuICBGaWxlQ29kZSxcbiAgU3BhcmtsZXMsXG4gIFJlZnJlc2hDdyxcbiAgSGFyZERyaXZlLFxuICBCdWlsZGluZzIsXG4gIFNlbmQsXG4gIEtleSxcbiAgQ29weSxcbiAgQ2hlY2ssXG4gIFNlYXJjaCxcbiAgRmlsdGVyLFxuICBFeHRlcm5hbExpbmssXG4gIENoZXZyb25SaWdodCxcbiAgRmlsZUNoZWNrLFxuICBJbmZvLFxuICBYLFxuICBMb2NrLFxuICBDcHVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IGNvbnN0IEJhY2t1cFZpZXcgPSAoKSA9PiB7XG4gIGNvbnN0IHsgdXNlciwgdG9rZW4sIGNvbXBhbmllcywgaW1wb3J0Q29tcGFuaWVzLCBzaG93VG9hc3QgfSA9IHVzZVN0b3JlKCk7XG4gIGNvbnN0IGZpbGVJbnB1dFJlZiA9IHVzZVJlZihudWxsKTtcblxuICAvLyBPYnRlbmVyIGVsIHRva2VuIG3DoXMgcmVjaWVudGUgZGlzcG9uaWJsZSBwYXJhIGV2aXRhciBmYWxsb3MgZGUgNDAzXG4gIGNvbnN0IGdldEZyZXNoVG9rZW4gPSAoKSA9PiB7XG4gICAgcmV0dXJuIHVzZVN0b3JlLmdldFN0YXRlKCkudG9rZW4gfHwgKHR5cGVvZiBsb2NhbFN0b3JhZ2UgIT09ICd1bmRlZmluZWQnID8gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Rva2VuJykgOiAnJykgfHwgKHR5cGVvZiBzZXNzaW9uU3RvcmFnZSAhPT0gJ3VuZGVmaW5lZCcgPyBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCd0b2tlbicpIDogJycpIHx8ICcnO1xuICB9O1xuXG4gIGNvbnN0IGdldEF1dGhIZWFkZXJzID0gKGV4dHJhID0ge30pID0+IHtcbiAgICBjb25zdCB0ID0gZ2V0RnJlc2hUb2tlbigpO1xuICAgIHJldHVybiB7XG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgLi4uKHQgPyB7ICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3R9YCB9IDoge30pLFxuICAgICAgLi4uZXh0cmFcbiAgICB9O1xuICB9O1xuXG4gIC8vIEVzdGFkb3MgZGUgTmF2ZWdhY2nDs24geSBQZXN0YcOxYXNcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKCdlbXByZXNhcycpOyAvLyAnZW1wcmVzYXMnIHwgJ2dsb2JhbCdcbiAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzdGF0dXNGaWx0ZXIsIHNldFN0YXR1c0ZpbHRlcl0gPSB1c2VTdGF0ZSgnQUxMJyk7IC8vICdBTEwnIHwgJ1ZJTkNVTEFET1MnIHwgJ1BFTkRJRU5URVMnXG5cbiAgLy8gRXN0YWRvcyBkZSBEYXRvcyBkZSBFbXByZXNhcyAoUmVzdW1lbilcbiAgY29uc3QgW2VtcHJlc2FzUmVzdW1lbiwgc2V0RW1wcmVzYXNSZXN1bWVuXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgW2lzTG9hZGluZ0VtcHJlc2FzLCBzZXRJc0xvYWRpbmdFbXByZXNhc10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gRXN0YWRvcyBkZSBNb2RhbGVzXG4gIGNvbnN0IFtzZWxlY3RlZFBpbk1vZGFsLCBzZXRTZWxlY3RlZFBpbk1vZGFsXSA9IHVzZVN0YXRlKG51bGwpOyAvLyB7IGVtcHJlc2EsIHBpbiwgaXNHZW5lcmF0aW5nIH1cbiAgY29uc3QgW3NlbGVjdGVkQ2VydE1vZGFsLCBzZXRTZWxlY3RlZENlcnRNb2RhbF0gPSB1c2VTdGF0ZShudWxsKTsgLy8geyBmaWNoYSwgaXNMb2FkaW5nIH1cbiAgY29uc3QgW2NvcGllZFBpbiwgc2V0Q29waWVkUGluXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2NvcGllZENlcnQsIHNldENvcGllZENlcnRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIEVzdGFkb3MgZGUgQWNjaW9uZXMgR2xvYmFsZXNcbiAgY29uc3QgW2lzRXhwb3J0aW5nR2xvYmFsLCBzZXRJc0V4cG9ydGluZ0dsb2JhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc0V4ZWN1dGluZ0dsb2JhbFBpcGVsaW5lLCBzZXRJc0V4ZWN1dGluZ0dsb2JhbFBpcGVsaW5lXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzSW1wb3J0aW5nLCBzZXRJc0ltcG9ydGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpbXBvcnRTdGF0cywgc2V0SW1wb3J0U3RhdHNdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtleHBvcnRTdGF0cywgc2V0RXhwb3J0U3RhdHNdID0gdXNlU3RhdGUobnVsbCk7XG5cbiAgLy8gRXN0YWRvIGRlIGRlc2NhcmdhIGFpc2xhZGEgcG9yIGVtcHJlc2FcbiAgY29uc3QgW2Rvd25sb2FkaW5nRW1wcmVzYUlkLCBzZXREb3dubG9hZGluZ0VtcHJlc2FJZF0gPSB1c2VTdGF0ZShudWxsKTtcblxuICAvLyBDYW5kYWRvIGRlIHRpZW1wbyBjb250cmEgY2xpY2tzIGRvYmxlcyAvIHLDoXBpZG9zICg8MTUwMG1zKVxuICBjb25zdCBsYXN0QWN0aW9uVGltZXN0YW1wUmVmID0gdXNlUmVmKDApO1xuXG4gIGNvbnN0IGlzQW55UHJvY2Vzc2luZyA9IGlzRXhlY3V0aW5nR2xvYmFsUGlwZWxpbmUgfHwgaXNFeHBvcnRpbmdHbG9iYWwgfHwgaXNJbXBvcnRpbmcgfHwgQm9vbGVhbihkb3dubG9hZGluZ0VtcHJlc2FJZCk7XG5cbiAgLyoqXG4gICAqIFJlc2NhdGUgSW5tZWRpYXRvIE9mZmxpbmUgLyBMb2NhbCBEaXJlY3RvICguanNvbilcbiAgICogRXh0cmFlIGVsIDEwMCUgZGUgbG9zIGRhdG9zIHJlc2lkZW50ZXMgZW4gZWwgYWxtYWNlbmFtaWVudG8gbG9jYWwgeSBadXN0YW5kXG4gICAqIHNpbiBwZXRpY2lvbmVzIEhUVFAsIHNpbiBiYWNrZW5kIG5pIHZhbGlkYWNpw7NuIGRlIHRva2VuLlxuICAgKi9cbiAgY29uc3QgZGVzY2FyZ2FyQ29waWFMb2NhbERpcmVjdGEgPSAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGVzdGFkbyA9IHVzZVN0b3JlLmdldFN0YXRlKCk7XG4gICAgICBjb25zdCBsaXN0YWRvRW1wcmVzYXMgPSBlc3RhZG8uY29tcGFuaWVzIHx8IGVzdGFkby5lbXByZXNhcyB8fCBbXTtcbiAgICAgIGNvbnN0IGxpc3RhZG9Qcm95ZWN0b3MgPSBlc3RhZG8ucHJveWVjdG9zIHx8IGVzdGFkby5wcm9qZWN0cyB8fCBbXTtcbiAgICAgIFxuICAgICAgY29uc3QgYmFja3VwRGF0YSA9IHtcbiAgICAgICAgYXBwTmFtZTogJ0FwcCBUYWJsZXJvcyBFbMOpY3RyaWNvcyAoU2VsZWN0cmljKScsXG4gICAgICAgIHRpcG9FeHBvcnRhY2lvbjogJ09GRkxJTkVfTE9DQUxfRElSRUNUX1NOQVAnLFxuICAgICAgICB2ZXJzaW9uOiAnMi4yLjAnLFxuICAgICAgICBmZWNoYUdlbmVyYWNpb246IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZGlzcG9zaXRpdm86IHR5cGVvZiBuYXZpZ2F0b3IgIT09ICd1bmRlZmluZWQnID8gbmF2aWdhdG9yLnVzZXJBZ2VudCA6ICdEZXNjb25vY2lkbycsXG4gICAgICAgIG1ldGFkYXRhOiB7XG4gICAgICAgICAgZ2VuZXJhZG9FbkNsaWVudGU6IHRydWUsXG4gICAgICAgICAgdG90YWxFbXByZXNhczogbGlzdGFkb0VtcHJlc2FzLmxlbmd0aCxcbiAgICAgICAgICB0b3RhbFByb3llY3RvczogbGlzdGFkb1Byb3llY3Rvcy5sZW5ndGgsXG4gICAgICAgICAgdG90YWxUYWJsZXJvczogKGVzdGFkby50YWJsZXJvcyB8fCBbXSkubGVuZ3RoLFxuICAgICAgICAgIHRvdGFsQ2lyY3VpdG9zOiAoZXN0YWRvLmNpcmN1aXRvcyB8fCBbXSkubGVuZ3RoLFxuICAgICAgICAgIGZlY2hhTG9jYWw6IG5ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoJ2VzLVZFJylcbiAgICAgICAgfSxcbiAgICAgICAgZGF0YTogbGlzdGFkb0VtcHJlc2FzLFxuICAgICAgICBkYXRvczoge1xuICAgICAgICAgIGVtcHJlc2FzOiBsaXN0YWRvRW1wcmVzYXMsXG4gICAgICAgICAgcHJveWVjdG9zOiBsaXN0YWRvUHJveWVjdG9zLFxuICAgICAgICAgIHN1YmVzdGFjaW9uZXM6IGVzdGFkby5zdWJlc3RhY2lvbmVzIHx8IFtdLFxuICAgICAgICAgIHRhYmxlcm9zOiBlc3RhZG8udGFibGVyb3MgfHwgW10sXG4gICAgICAgICAgY2lyY3VpdG9zOiBlc3RhZG8uY2lyY3VpdG9zIHx8IFtdLFxuICAgICAgICAgIG1lZGljaW9uZXM6IGVzdGFkby5tZWRpY2lvbmVzIHx8IGVzdGFkby5wdW50b3NNZWRpY2lvbiB8fCBbXSxcbiAgICAgICAgICBjY206IGVzdGFkby5jY21MaXN0IHx8IGVzdGFkby5jY20gfHwgW10sXG4gICAgICAgICAgaW5zcGVjY2lvbmVzVGVybW9ncmFmaWNhczogZXN0YWRvLmluc3BlY2Npb25lc1Rlcm1vZ3JhZmljYXMgfHwgW10sXG4gICAgICAgICAgaW5zcGVjY2lvbmVzQXRlcnJhbWllbnRvOiBlc3RhZG8uaW5zcGVjY2lvbmVzQXRlcnJhbWllbnRvIHx8IFtdLFxuICAgICAgICAgIGluc3BlY2Npb25lc1RhbnF1ZXNDb21idXN0aWJsZTogZXN0YWRvLmluc3BlY2Npb25lc1RhbnF1ZXNDb21idXN0aWJsZSB8fCBbXSxcbiAgICAgICAgICBhbGFybWFzOiBlc3RhZG8uYWxhcm1hcyB8fCBbXSxcbiAgICAgICAgICBhbGltZW50YWRvcmVzOiBlc3RhZG8uYWxpbWVudGFkb3JlcyB8fCBbXVxuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICBjb25zdCBqc29uU3RyaW5nID0gSlNPTi5zdHJpbmdpZnkoYmFja3VwRGF0YSwgbnVsbCwgMik7XG4gICAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW2pzb25TdHJpbmddLCB7IHR5cGU6ICdhcHBsaWNhdGlvbi9qc29uO2NoYXJzZXQ9dXRmLTgnIH0pO1xuICAgICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBsaW5rLmhyZWYgPSB1cmw7XG4gICAgICBsaW5rLmRvd25sb2FkID0gYHJlc3BhbGRvX2xvY2FsX2lubWVkaWF0b18ke25ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCl9Lmpzb25gO1xuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChsaW5rKTtcbiAgICAgIGxpbmsuY2xpY2soKTtcbiAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQobGluayk7XG4gICAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG5cbiAgICAgIGlmIChzaG93VG9hc3QpIHtcbiAgICAgICAgc2hvd1RvYXN0KCfCoUNvcGlhIGRlIHNlZ3VyaWRhZCBsb2NhbCBkZXNjYXJnYWRhIGV4aXRvc2FtZW50ZSBlbiBlc3RlIGRpc3Bvc2l0aXZvIScsICdzdWNjZXNzJyk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBleHBvcnRhciByZXNwYWxkbyBsb2NhbCBkaXJlY3RvOicsIGVycik7XG4gICAgICBpZiAoc2hvd1RvYXN0KSB7XG4gICAgICAgIHNob3dUb2FzdCgnRXJyb3IgYWwgZXhwb3J0YXIgcmVzcGFsZG8gbG9jYWw6ICcgKyBlcnIubWVzc2FnZSwgJ2Vycm9yJyk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIC8qKlxuICAgKiBDYXJnYXIgbGlzdGFkbyBkZSBlbXByZXNhcyBjb24gbcOpdHJpY2FzIGRlIHJlc2d1YXJkbyBkZXNkZSBsYSBBUElcbiAgICovXG4gIGNvbnN0IGZldGNoRW1wcmVzYXNSZXN1bWVuID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldElzTG9hZGluZ0VtcHJlc2FzKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2JhY2t1cC9yZXN1bWVuLWVtcHJlc2FzYCwge1xuICAgICAgICBoZWFkZXJzOiBnZXRBdXRoSGVhZGVycygpXG4gICAgICB9KTtcblxuICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAxIHx8IHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAgIHVzZVN0b3JlLmdldFN0YXRlKCkuaGFuZGxlQXV0aEVycm9yPy4ocmVzcG9uc2Uuc3RhdHVzKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgaWYgKHJlc3BvbnNlLm9rICYmIGRhdGEub2spIHtcbiAgICAgICAgc2V0RW1wcmVzYXNSZXN1bWVuKGRhdGEuZGF0YSB8fCBbXSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBjYXJnYXIgcmVzdW1lbiBkZSBlbXByZXNhczonLCBlcnIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0xvYWRpbmdFbXByZXNhcyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2hFbXByZXNhc1Jlc3VtZW4oKTtcbiAgfSwgW3Rva2VuXSk7XG5cbiAgLy8gQ8OhbGN1bG9zIGNvbnNvbGlkYWRvcyBwYXJhIEtQSXNcbiAgY29uc3QgdG90YWxFbXByZXNhcyA9IGVtcHJlc2FzUmVzdW1lbi5sZW5ndGggfHwgY29tcGFuaWVzPy5sZW5ndGggfHwgMDtcbiAgY29uc3QgdG90YWxUYWJsZXJvcyA9IGVtcHJlc2FzUmVzdW1lbi5yZWR1Y2UoKGFjYywgZSkgPT4gYWNjICsgKGUudG90YWxlcz8udGFibGVyb3MgfHwgMCksIDApO1xuICBjb25zdCB0b3RhbENpcmN1aXRvcyA9IGVtcHJlc2FzUmVzdW1lbi5yZWR1Y2UoKGFjYywgZSkgPT4gYWNjICsgKGUudG90YWxlcz8uY2lyY3VpdG9zIHx8IDApLCAwKTtcbiAgY29uc3QgdG90YWxBY3Rpdm9zUHJvdGVnaWRvcyA9IGVtcHJlc2FzUmVzdW1lbi5yZWR1Y2UoKGFjYywgZSkgPT4gYWNjICsgKGUudG90YWxlcz8udG90YWxBY3Rpdm9zIHx8IDApLCAwKTtcbiAgY29uc3QgdG90YWxWaW5jdWxhZG9zVGVsZWdyYW0gPSBlbXByZXNhc1Jlc3VtZW4uZmlsdGVyKGUgPT4gZS50ZWxlZ3JhbUNoYXRJZCkubGVuZ3RoO1xuXG4gIC8vIEZpbHRyYWRvIGRlIGVtcHJlc2FzXG4gIGNvbnN0IGZpbHRlcmVkRW1wcmVzYXMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gZW1wcmVzYXNSZXN1bWVuLmZpbHRlcihlbXAgPT4ge1xuICAgICAgY29uc3QgbWF0Y2hlc1NlYXJjaCA9IGVtcC5ub21icmUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVtcC5yaWYudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKTtcbiAgICAgIGlmICghbWF0Y2hlc1NlYXJjaCkgcmV0dXJuIGZhbHNlO1xuICAgICAgaWYgKHN0YXR1c0ZpbHRlciA9PT0gJ1ZJTkNVTEFET1MnKSByZXR1cm4gISFlbXAudGVsZWdyYW1DaGF0SWQ7XG4gICAgICBpZiAoc3RhdHVzRmlsdGVyID09PSAnUEVORElFTlRFUycpIHJldHVybiAhZW1wLnRlbGVncmFtQ2hhdElkO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSk7XG4gIH0sIFtlbXByZXNhc1Jlc3VtZW4sIHNlYXJjaFF1ZXJ5LCBzdGF0dXNGaWx0ZXJdKTtcblxuICAvKipcbiAgICogRGlzcGFyYSBlbCByZXNwYWxkbyBtYWVzdHJvIGVuIHNlcnZpZG9yIC8gbnViZVxuICAgKiBQZXRpY2nDs24gSFRUUCBQT1NUIGVzdMOhbmRhciB5IHNpbGVuY2lvc2EgKHNpbiBzb2xpY2l0YXIgcGVybWlzb3MgZGUgc2lzdGVtYSwgY3JlZGVuY2lhbGVzIG5pIHN5bmMgbmF0aXZvKVxuICAgKi9cbiAgY29uc3QgaGFuZGxlUmVzcGFsZG9TZXJ2aWRvciA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgIGlmIChpc0V4ZWN1dGluZ0dsb2JhbFBpcGVsaW5lIHx8IChub3cgLSBsYXN0QWN0aW9uVGltZXN0YW1wUmVmLmN1cnJlbnQgPCAyMDAwKSkgcmV0dXJuO1xuICAgIGxhc3RBY3Rpb25UaW1lc3RhbXBSZWYuY3VycmVudCA9IG5vdztcbiAgICBzZXRJc0V4ZWN1dGluZ0dsb2JhbFBpcGVsaW5lKHRydWUpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRva2VuID0gZ2V0RnJlc2hUb2tlbigpO1xuICAgICAgY29uc3Qgc3RhdGUgPSB1c2VTdG9yZS5nZXRTdGF0ZSgpO1xuICAgICAgXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgICBmZWNoYTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBub21icmU6IGBSZXNwYWxkbyBTZXJ2aWRvciAke25ldyBEYXRlKCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlcy1WRScpfWAsXG4gICAgICAgIGRlc2NyaXBjaW9uOiAnUmVzcGFsZG8gbWFlc3RybyBkaXNwYXJhZG8gZGVzZGUgZWwgQ2VudHJvIGRlIENvbnRyb2wgV2ViJyxcbiAgICAgICAgZW1wcmVzYXM6IHN0YXRlLmNvbXBhbmllcyB8fCBzdGF0ZS5lbXByZXNhcyB8fCBbXSxcbiAgICAgICAgcHJveWVjdG9zOiBzdGF0ZS5wcm95ZWN0b3MgfHwgc3RhdGUucHJvamVjdHMgfHwgW10sXG4gICAgICAgIHN1YmVzdGFjaW9uZXM6IHN0YXRlLnN1YmVzdGFjaW9uZXMgfHwgW10sXG4gICAgICAgIHRhYmxlcm9zOiBzdGF0ZS50YWJsZXJvcyB8fCBbXSxcbiAgICAgICAgY2lyY3VpdG9zOiBzdGF0ZS5jaXJjdWl0b3MgfHwgW10sXG4gICAgICAgIG1lZGljaW9uZXM6IHN0YXRlLm1lZGljaW9uZXMgfHwgc3RhdGUucHVudG9zTWVkaWNpb24gfHwgW11cbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYmFja3VwL2Nsb3VkYCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgLi4uKHRva2VuICYmIHRva2VuICE9PSAnbW9jay1vZmZsaW5lLXRva2VuJyA/IHsgJ0F1dGhvcml6YXRpb24nOiBgQmVhcmVyICR7dG9rZW59YCB9IDoge30pXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHBheWxvYWQpXG4gICAgICB9KTtcblxuICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAxIHx8IHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAgIHVzZVN0b3JlLmdldFN0YXRlKCkuaGFuZGxlQXV0aEVycm9yPy4ocmVzcG9uc2Uuc3RhdHVzKTtcbiAgICAgICAgaWYgKHNob3dUb2FzdCkgc2hvd1RvYXN0KCdUdSBzZXNpw7NuIGhhIGV4cGlyYWRvIG8gbm8gdGllbmVzIHBlcm1pc29zIGRlIEFkbWluaXN0cmFkb3IuJywgJ2Vycm9yJyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCBlcnJvckRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gKHt9KSk7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihlcnJvckRhdGEuZXJyb3IgfHwgYEVycm9yIGVuIGVsIHNlcnZpZG9yOiAke3Jlc3BvbnNlLnN0YXR1c31gKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgcmVzRGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKS5jYXRjaCgoKSA9PiAoeyBvazogdHJ1ZSB9KSk7XG4gICAgICBpZiAoc2hvd1RvYXN0KSB7XG4gICAgICAgIHNob3dUb2FzdCgnUmVzcGFsZG8gZW4gbGEgbnViZSBnZW5lcmFkbyBleGl0b3NhbWVudGUuJywgJ3N1Y2Nlc3MnKTtcbiAgICAgIH1cbiAgICAgIGZldGNoRW1wcmVzYXNSZXN1bWVuKCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGVuIHJlc3BhbGRvIHNlcnZpZG9yOicsIGVycm9yKTtcbiAgICAgIGNvbnN0IGlzTmV0d29ya0Vycm9yID0gZXJyb3IubWVzc2FnZT8uaW5jbHVkZXMoJ0ZhaWxlZCB0byBmZXRjaCcpIHx8IGVycm9yLm1lc3NhZ2U/LmluY2x1ZGVzKCdOZXR3b3JrRXJyb3InKTtcbiAgICAgIGNvbnN0IG1lbnNhamVFcnJvciA9IGlzTmV0d29ya0Vycm9yIFxuICAgICAgICA/ICdObyBzZSBwdWRvIGNvbmVjdGFyIGNvbiBlbCBzZXJ2aWRvciBjZW50cmFsLiBQdWVkZXMgdXNhciBcIkRlc2NhcmdhIElubWVkaWF0YSBMb2NhbCAoLmpzb24pXCIgbWllbnRyYXMgdGFudG8uJ1xuICAgICAgICA6IChlcnJvci5tZXNzYWdlIHx8ICdGYWxsbyBlbiBsYSBlamVjdWNpw7NuIGRlbCByZXNwYWxkbycpO1xuICAgICAgaWYgKHNob3dUb2FzdCkgc2hvd1RvYXN0KG1lbnNhamVFcnJvciwgJ2Vycm9yJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzRXhlY3V0aW5nR2xvYmFsUGlwZWxpbmUoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVUcmlnZ2VyR2xvYmFsUGlwZWxpbmUgPSBoYW5kbGVSZXNwYWxkb1NlcnZpZG9yO1xuXG4gIC8qKlxuICAgKiBFeHBvcnRhciB5IGRlc2NhcmdhciBlbCB2b2xjYWRvIEpTT04gbWFlc3RybyBlbiBtZW1vcmlhXG4gICAqL1xuICBjb25zdCBoYW5kbGVFeHBvcnRHbG9iYWxKc29uID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgaWYgKGlzRXhwb3J0aW5nR2xvYmFsIHx8IChub3cgLSBsYXN0QWN0aW9uVGltZXN0YW1wUmVmLmN1cnJlbnQgPCAyMDAwKSkgcmV0dXJuO1xuICAgIGxhc3RBY3Rpb25UaW1lc3RhbXBSZWYuY3VycmVudCA9IG5vdztcbiAgICBzZXRJc0V4cG9ydGluZ0dsb2JhbCh0cnVlKTtcbiAgICBzZXRFeHBvcnRTdGF0cyhudWxsKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2JhY2t1cHMvZXhwb3J0YCwge1xuICAgICAgICBoZWFkZXJzOiBnZXRBdXRoSGVhZGVycygpXG4gICAgICB9KTtcblxuICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAxIHx8IHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAgIHVzZVN0b3JlLmdldFN0YXRlKCkuaGFuZGxlQXV0aEVycm9yPy4ocmVzcG9uc2Uuc3RhdHVzKTtcbiAgICAgICAgaWYgKHNob3dUb2FzdCkgc2hvd1RvYXN0KCdUdSBzZXNpw7NuIGhhIGV4cGlyYWRvIG8gbm8gdGllbmVzIHBlcm1pc29zIGRlIEFkbWluaXN0cmFkb3IuJywgJ2Vycm9yJyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBhbCBnZW5lcmFyIGFyY2hpdm8gSlNPTiBtYWVzdHJvJyk7XG5cbiAgICAgIGxldCBmaWxlbmFtZSA9IGBiYWNrdXBfbWFlc3Ryb19zZWxlY3RyaWNfJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApfS5qc29uYDtcbiAgICAgIGNvbnN0IGRpc3Bvc2l0aW9uID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ2NvbnRlbnQtZGlzcG9zaXRpb24nKTtcbiAgICAgIGlmIChkaXNwb3NpdGlvbiAmJiBkaXNwb3NpdGlvbi5pbmNsdWRlcygnZmlsZW5hbWU9JykpIHtcbiAgICAgICAgY29uc3QgbWF0Y2ggPSBkaXNwb3NpdGlvbi5tYXRjaCgvZmlsZW5hbWU9XCI/KFteXCJdKylcIj8vKTtcbiAgICAgICAgaWYgKG1hdGNoPy5bMV0pIGZpbGVuYW1lID0gbWF0Y2hbMV07XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwb25zZS5ibG9iKCk7XG4gICAgICBjb25zdCBkb3dubG9hZFVybCA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgIGxpbmsuaHJlZiA9IGRvd25sb2FkVXJsO1xuICAgICAgbGluay5zZXRBdHRyaWJ1dGUoJ2Rvd25sb2FkJywgZmlsZW5hbWUpO1xuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChsaW5rKTtcbiAgICAgIGxpbmsuY2xpY2soKTtcbiAgICAgIGxpbmsucmVtb3ZlKCk7XG4gICAgICB3aW5kb3cuVVJMLnJldm9rZU9iamVjdFVSTChkb3dubG9hZFVybCk7XG5cbiAgICAgIHNldEV4cG9ydFN0YXRzKHtcbiAgICAgICAgZmlsZW5hbWUsXG4gICAgICAgIHNpemU6IGAkeyhibG9iLnNpemUgLyAxMDI0KS50b0ZpeGVkKDEpfSBLQmAsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VzLVZFJylcbiAgICAgIH0pO1xuXG4gICAgICBpZiAoc2hvd1RvYXN0KSBzaG93VG9hc3QoJ0FyY2hpdm8gZGUgcmVzcGFsZG8gbWFlc3RybyBkZXNjYXJnYWRvLicsICdzdWNjZXNzJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBpc05ldHdvcmtFcnJvciA9IGVyci5tZXNzYWdlPy5pbmNsdWRlcygnRmFpbGVkIHRvIGZldGNoJykgfHwgZXJyLm1lc3NhZ2U/LmluY2x1ZGVzKCdOZXR3b3JrRXJyb3InKTtcbiAgICAgIGNvbnN0IG1lbnNhamVFcnJvciA9IGlzTmV0d29ya0Vycm9yIFxuICAgICAgICA/ICdFcnJvciBkZSBjb25leGnDs24gY29uIGVsIHNlcnZpZG9yLiBVdGlsaXphIFwiRGVzY2FyZ2EgSW5tZWRpYXRhIExvY2FsICguanNvbilcIi4nXG4gICAgICAgIDogKGVyci5tZXNzYWdlIHx8ICdFcnJvciBhbCBkZXNjYXJnYXIgcmVzcGFsZG8nKTtcbiAgICAgIGlmIChzaG93VG9hc3QpIHNob3dUb2FzdChtZW5zYWplRXJyb3IsICdlcnJvcicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0V4cG9ydGluZ0dsb2JhbChmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8qKlxuICAgKiBHZW5lcmFyIG8gbW9zdHJhciBQSU4gZGUgZW5sYWNlIHBhcmEgVGVsZWdyYW0gZGUgdW5hIGVtcHJlc2FcbiAgICovXG4gIGNvbnN0IGhhbmRsZU9wZW5QaW5Nb2RhbCA9IGFzeW5jIChlbXByZXNhKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRQaW5Nb2RhbCh7IGVtcHJlc2EsIHBpbjogZW1wcmVzYS50ZWxlZ3JhbUJhY2t1cFBpbiwgaXNHZW5lcmF0aW5nOiBmYWxzZSB9KTtcbiAgICBpZiAoIWVtcHJlc2EudGVsZWdyYW1CYWNrdXBQaW4pIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHNldFNlbGVjdGVkUGluTW9kYWwocHJldiA9PiAoeyAuLi5wcmV2LCBpc0dlbmVyYXRpbmc6IHRydWUgfSkpO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2JhY2t1cC9nZW5lcmFyLXBpbi8ke2VtcHJlc2EuaWR9YCwge1xuICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgIGhlYWRlcnM6IGdldEF1dGhIZWFkZXJzKClcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAxIHx8IHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAgICAgdXNlU3RvcmUuZ2V0U3RhdGUoKS5oYW5kbGVBdXRoRXJyb3I/LihyZXNwb25zZS5zdGF0dXMpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJlc0RhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGlmIChyZXNwb25zZS5vayAmJiByZXNEYXRhLm9rKSB7XG4gICAgICAgICAgc2V0U2VsZWN0ZWRQaW5Nb2RhbCh7IGVtcHJlc2EsIHBpbjogcmVzRGF0YS5kYXRhLnRlbGVncmFtQmFja3VwUGluLCBpc0dlbmVyYXRpbmc6IGZhbHNlIH0pO1xuICAgICAgICAgIGZldGNoRW1wcmVzYXNSZXN1bWVuKCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBnZW5lcmFyIFBJTjonLCBlcnIpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICAvKipcbiAgICogQWJyaXIgbW9kYWwgZGUgQ2VydGlmaWNhZG8gRWplY3V0aXZvIGRlIFJlc2d1YXJkb1xuICAgKi9cbiAgY29uc3QgaGFuZGxlT3BlbkNlcnRNb2RhbCA9IGFzeW5jIChlbXByZXNhKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRDZXJ0TW9kYWwoeyBmaWNoYTogbnVsbCwgaXNMb2FkaW5nOiB0cnVlIH0pO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2JhY2t1cC9lbXByZXNhLyR7ZW1wcmVzYS5pZH0vZXN0YWRvYCwge1xuICAgICAgICBoZWFkZXJzOiBnZXRBdXRoSGVhZGVycygpXG4gICAgICB9KTtcblxuICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAxIHx8IHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAgIHVzZVN0b3JlLmdldFN0YXRlKCkuaGFuZGxlQXV0aEVycm9yPy4ocmVzcG9uc2Uuc3RhdHVzKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgaWYgKHJlc3BvbnNlLm9rICYmIGRhdGEub2spIHtcbiAgICAgICAgc2V0U2VsZWN0ZWRDZXJ0TW9kYWwoeyBmaWNoYTogZGF0YS5kYXRhLCBpc0xvYWRpbmc6IGZhbHNlIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGRhdGEuZXJyb3IgfHwgJ05vIHNlIHB1ZG8gb2J0ZW5lciBlbCBjZXJ0aWZpY2FkbycpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKHNob3dUb2FzdCkgc2hvd1RvYXN0KGVyci5tZXNzYWdlLCAnZXJyb3InKTtcbiAgICAgIHNldFNlbGVjdGVkQ2VydE1vZGFsKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICAvKipcbiAgICogRGVzY2FyZ2FyIHNuYXBzaG90IGFpc2xhZG8gZGUgdW5hIHNvbGEgZW1wcmVzYVxuICAgKi9cbiAgY29uc3QgaGFuZGxlRG93bmxvYWRFbXByZXNhU25hcHNob3QgPSBhc3luYyAoZW1wcmVzYUlkLCBlbXByZXNhTm9tYnJlKSA9PiB7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICBpZiAoZG93bmxvYWRpbmdFbXByZXNhSWQgfHwgKG5vdyAtIGxhc3RBY3Rpb25UaW1lc3RhbXBSZWYuY3VycmVudCA8IDIwMDApKSByZXR1cm47XG4gICAgbGFzdEFjdGlvblRpbWVzdGFtcFJlZi5jdXJyZW50ID0gbm93O1xuICAgIHNldERvd25sb2FkaW5nRW1wcmVzYUlkKGVtcHJlc2FJZCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QVBJX0JBU0VfVVJMfS9hcGkvYmFja3VwL2VtcHJlc2EvJHtlbXByZXNhSWR9L2V4cG9ydGAsIHtcbiAgICAgICAgaGVhZGVyczogZ2V0QXV0aEhlYWRlcnMoKVxuICAgICAgfSk7XG5cbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwMSB8fCByZXNwb25zZS5zdGF0dXMgPT09IDQwMykge1xuICAgICAgICB1c2VTdG9yZS5nZXRTdGF0ZSgpLmhhbmRsZUF1dGhFcnJvcj8uKHJlc3BvbnNlLnN0YXR1cyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBhbCBleHBvcnRhciBkYXRvcyBkZSBsYSBlbXByZXNhJyk7XG5cbiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwb25zZS5ibG9iKCk7XG4gICAgICBjb25zdCBzbHVnID0gZW1wcmVzYU5vbWJyZS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1teYS16MC05XS9nLCAnXycpO1xuICAgICAgY29uc3QgZmlsZW5hbWUgPSBgYmFja3VwXyR7c2x1Z31fJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApfS5qc29uYDtcblxuICAgICAgY29uc3QgZG93bmxvYWRVcmwgPSB3aW5kb3cuVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBsaW5rLmhyZWYgPSBkb3dubG9hZFVybDtcbiAgICAgIGxpbmsuc2V0QXR0cmlidXRlKCdkb3dubG9hZCcsIGZpbGVuYW1lKTtcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgICBsaW5rLmNsaWNrKCk7XG4gICAgICBsaW5rLnJlbW92ZSgpO1xuICAgICAgd2luZG93LlVSTC5yZXZva2VPYmplY3RVUkwoZG93bmxvYWRVcmwpO1xuXG4gICAgICBpZiAoc2hvd1RvYXN0KSBzaG93VG9hc3QoYFNuYXBzaG90IGRlICR7ZW1wcmVzYU5vbWJyZX0gZGVzY2FyZ2FkbyBjb24gw6l4aXRvLmAsICdzdWNjZXNzJyk7XG4gICAgICBmZXRjaEVtcHJlc2FzUmVzdW1lbigpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKHNob3dUb2FzdCkgc2hvd1RvYXN0KGVyci5tZXNzYWdlLCAnZXJyb3InKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0RG93bmxvYWRpbmdFbXByZXNhSWQobnVsbCk7XG4gICAgfVxuICB9O1xuXG4gIC8qKlxuICAgKiBNYW5lamFkb3IgZGUgaW1wb3J0YWNpw7NuIHkgcmVzdGF1cmFjacOzbiBkZSBiYXNlIGRlIGRhdG9zXG4gICAqL1xuICBjb25zdCBoYW5kbGVGaWxlQ2hhbmdlID0gYXN5bmMgKGUpID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcblxuICAgIGlmICghZmlsZS5uYW1lLmVuZHNXaXRoKCcuanNvbicpKSB7XG4gICAgICBpZiAoc2hvd1RvYXN0KSBzaG93VG9hc3QoJ1BvciBmYXZvciBzZWxlY2Npb25hIHVuIGFyY2hpdm8gY29uIGV4dGVuc2nDs24gLmpzb24nLCAnZXJyb3InKTtcbiAgICAgIGlmIChmaWxlSW5wdXRSZWYuY3VycmVudCkgZmlsZUlucHV0UmVmLmN1cnJlbnQudmFsdWUgPSAnJztcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBjb25maXJtUmVzdG9yZSA9IHdpbmRvdy5jb25maXJtKFxuICAgICAgYOKaoO+4jyDCv0VzdMOhcyBzZWd1cm8gZGUgcXVlIGRlc2VhcyByZXN0YXVyYXIgbGEgYmFzZSBkZSBkYXRvcyBjb24gXCIke2ZpbGUubmFtZX1cIj9cXG5cXG5Fc3RhIGFjY2nDs24gcmVlbXBsYXphcsOhIGxhIGluZm9ybWFjacOzbiBleGlzdGVudGUgZW4gbGEgYmFzZSBkZSBkYXRvcy5gXG4gICAgKTtcbiAgICBpZiAoIWNvbmZpcm1SZXN0b3JlKSB7XG4gICAgICBpZiAoZmlsZUlucHV0UmVmLmN1cnJlbnQpIGZpbGVJbnB1dFJlZi5jdXJyZW50LnZhbHVlID0gJyc7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0SXNJbXBvcnRpbmcodHJ1ZSk7XG4gICAgc2V0SW1wb3J0U3RhdHMobnVsbCk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IGZpbGUudGV4dCgpO1xuICAgICAgY29uc3QgcGFyc2VkRGF0YSA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgICBjb25zdCBwYXlsb2FkRGF0YSA9IEFycmF5LmlzQXJyYXkocGFyc2VkRGF0YSkgXG4gICAgICAgID8gcGFyc2VkRGF0YSBcbiAgICAgICAgOiAocGFyc2VkRGF0YS5kYXRhIHx8IHBhcnNlZERhdGEuZW1wcmVzYXMgfHwgW10pO1xuXG4gICAgICBpZiAoIUFycmF5LmlzQXJyYXkocGF5bG9hZERhdGEpIHx8IHBheWxvYWREYXRhLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0VsIGFyY2hpdm8gbm8gY29udGllbmUgcmVnaXN0cm9zIHbDoWxpZG9zIGRlIGVtcHJlc2FzIG8gcHJveWVjdG9zLicpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0vYXBpL2JhY2t1cHMvaW1wb3J0YCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogZ2V0QXV0aEhlYWRlcnMoKSxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBkYXRhOiBwYXlsb2FkRGF0YSB9KVxuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgIGlmICghcmVzcG9uc2Uub2sgfHwgKCFyZXN1bHQub2sgJiYgIXJlc3VsdC5zdWNjZXNzKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IocmVzdWx0LmVycm9yIHx8ICdFcnJvciBhbCByZXN0YXVyYXIgZGF0b3MgZW4gZWwgc2Vydmlkb3IuJyk7XG4gICAgICB9XG5cbiAgICAgIGlmIChpbXBvcnRDb21wYW5pZXMpIGltcG9ydENvbXBhbmllcyhwYXlsb2FkRGF0YSk7XG5cbiAgICAgIHNldEltcG9ydFN0YXRzKHtcbiAgICAgICAgZmlsZW5hbWU6IGZpbGUubmFtZSxcbiAgICAgICAgZW1wcmVzYXNSZXN0YXVyYWRhczogcGF5bG9hZERhdGEubGVuZ3RoLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlcy1WRScpXG4gICAgICB9KTtcblxuICAgICAgaWYgKHNob3dUb2FzdCkgc2hvd1RvYXN0KCdCYXNlIGRlIGRhdG9zIHJlc3RhdXJhZGEgY29ycmVjdGFtZW50ZS4nLCAnc3VjY2VzcycpO1xuICAgICAgZmV0Y2hFbXByZXNhc1Jlc3VtZW4oKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChzaG93VG9hc3QpIHNob3dUb2FzdChlcnIubWVzc2FnZSB8fCAnRXJyb3IgYWwgcmVzdGF1cmFyJywgJ2Vycm9yJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzSW1wb3J0aW5nKGZhbHNlKTtcbiAgICAgIGlmIChmaWxlSW5wdXRSZWYuY3VycmVudCkgZmlsZUlucHV0UmVmLmN1cnJlbnQudmFsdWUgPSAnJztcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHNwYWNlLXktOCBwYi0xNiBweC0yIHNtOnB4LTRcIj5cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgey8qIDEuIEVOQ0FCRVpBRE8gRUpFQ1VUSVZPIFkgU0VMRUNUT1IgREUgUEVTVEHDkUFTICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTYgbWQ6cC04IHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctMnhsXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXJpZ2h0LTEyIC1ib3R0b20tMTIgdy02NCBoLTY0IGJnLWFtYmVyLTUwMC8xMCByb3VuZGVkLWZ1bGwgYmx1ci0zeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWxlZnQtMTIgLXRvcC0xMiB3LTY0IGgtNjQgYmctY3lhbi01MDAvMTAgcm91bmRlZC1mdWxsIGJsdXItM3hsIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBsZzppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC02IHJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHJvdW5kZWQtMnhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYW1iZXItNDAwIHZpYS1hbWJlci01MDAgdG8tYW1iZXItNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgc2hhZG93LXhsIHNoYWRvdy1hbWJlci01MDAvMjAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIG1kOnRleHQtM3hsIGZvbnQtYmxhY2sgdGV4dC13aGl0ZSB0cmFja2luZy10aWdodFwiPlxuICAgICAgICAgICAgICAgICAgQ2VudHJvIGRlIENvbnRyb2wgJiBSZXNpbGllbmNpYVxuICAgICAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMyBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkIGJnLWVtZXJhbGQtNTAwLzEwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC1lbWVyYWxkLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTQwMCBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICAgICAgICAgIFNpc3RlbWEgUHJvdGVnaWRvXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBtdC0xIG1heC13LTJ4bCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICBHZXN0acOzbiBpbnRlZ3JhbCBkZSBjb250aW51aWRhZCBvcGVyYXRpdmEsIHJlc3BhbGRvcyBtYWVzdHJvcyBlbiBtZW1vcmlhLCByZXNndWFyZG8gaW5kaXZpZHVhbCBwb3IgZW1wcmVzYSB5IGNlcnRpZmljYWNpw7NuIGNyaXB0b2dyw6FmaWNhIGRlIGFjdGl2b3MgZWzDqWN0cmljb3MuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1zdGFydCBnYXAtNFwiPlxuICAgICAgICAgICAgey8qIEJvdMOzbiBkZSBSZXNjYXRlIElubWVkaWF0byBPZmZsaW5lIC8gTG9jYWwgRGlyZWN0byAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2Rlc2NhcmdhckNvcGlhTG9jYWxEaXJlY3RhfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcHktMyBweC01IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTUwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLWVtZXJhbGQtNDAwIGhvdmVyOnRvLXRlYWwtNTAwIGFjdGl2ZTpzY2FsZS1bMC45OF0gdGV4dC1zbGF0ZS05NTAgZm9udC1ib2xkIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBzaGFkb3ctZW1lcmFsZC01MDAvMjAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJEZXNjYXJnYSBkaXJlY3RhIGluc3RhbnTDoW5lYSBkZXNkZSBlbCBuYXZlZ2Fkb3IgKHNpbiByZXF1ZXJpciByZWQgbmkgYmFja2VuZClcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNCBoLTQgc3Ryb2tlLVsyLjVdXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5EZXNjYXJnYSBJbm1lZGlhdGEgTG9jYWwgKC5qc29uKTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZW1lcmFsZC00MDAvOTAgbXQtMS41IGZvbnQtbWVkaXVtIHRleHQtY2VudGVyIG1heC13LVsyNjBweF1cIj5cbiAgICAgICAgICAgICAgICBSdXRhIGRlc3Rpbm86IEFsbWFjZW5hbWllbnRvIGxvY2FsIChDYXJwZXRhIGRlIERlc2NhcmdhcyAvIERvd25sb2FkcylcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVRyaWdnZXJHbG9iYWxQaXBlbGluZX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNBbnlQcm9jZXNzaW5nfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcHktMyBweC01IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1hbWJlci01MDAgdG8tYW1iZXItNjAwIGhvdmVyOmZyb20tYW1iZXItNDAwIGhvdmVyOnRvLWFtYmVyLTUwMCBhY3RpdmU6c2NhbGUtWzAuOThdIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6cG9pbnRlci1ldmVudHMtbm9uZSB0ZXh0LXNsYXRlLTk1MCBmb250LWJvbGQgcm91bmRlZC0yeGwgc2hhZG93LWxnIHNoYWRvdy1hbWJlci01MDAvMjAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgdGV4dC1zbVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7aXNFeGVjdXRpbmdHbG9iYWxQaXBlbGluZSA/IChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNCBoLTQgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+RWplY3V0YW5kbyBSZXNwYWxkbyBOdWJlLi4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy00IGgtNCBmaWxsLXNsYXRlLTk1MFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlc3BhbGRvIFNlcnZpZG9yIC8gTnViZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWFtYmVyLTQwMC85MCBtdC0xLjUgZm9udC1tZWRpdW0gdGV4dC1jZW50ZXIgbWF4LXctWzI2MHB4XVwiPlxuICAgICAgICAgICAgICAgIFJ1dGEgZGVzdGlubzogQmFzZSBkZSBEYXRvcyBDZW50cmFsIFBvc3RncmVTUUwgKC9hcGkvYmFja3VwL2Nsb3VkKVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtmZXRjaEVtcHJlc2FzUmVzdW1lbn1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ0VtcHJlc2FzIHx8IGlzQW55UHJvY2Vzc2luZ31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwIG10LTAuNVwiXG4gICAgICAgICAgICAgIHRpdGxlPVwiUmVmcmVzY2FyIG3DqXRyaWNhc1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPXtgdy00IGgtNCAke2lzTG9hZGluZ0VtcHJlc2FzID8gJ2FuaW1hdGUtc3BpbicgOiAnJ31gfSAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICB7LyogMi4gVEFSSkVUQVMgREUgTcOJVFJJQ0FTIENMQVZFIChLUElTKSAqL31cbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtMy41IG10LTggcHQtNiBib3JkZXItdCBib3JkZXItc2xhdGUtODAwLzgwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC00IGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTQwMCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxzcGFuPkVtcHJlc2FzIEF1ZGl0YWRhczwvc3Bhbj5cbiAgICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtY3lhbi00MDBcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtd2hpdGUgbXQtMlwiPnt0b3RhbEVtcHJlc2FzfTwvcD5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZW1lcmFsZC00MDAgbXQtMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPiB7dG90YWxFbXByZXNhc30gY29uIHJlc2d1YXJkbyBhY3Rpdm9cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS00MDAgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8c3Bhbj5BY3Rpdm9zIEVsw6ljdHJpY29zPC9zcGFuPlxuICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtYW1iZXItNDAwIG10LTJcIj57dG90YWxBY3Rpdm9zUHJvdGVnaWRvc308L3A+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgIHt0b3RhbFRhYmxlcm9zfSB0YWJsZXJvcyDigKIge3RvdGFsQ2lyY3VpdG9zfSBwb2xvc1xuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC00IGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTQwMCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxzcGFuPkNhbmFsZXMgZGUgUmVzZ3VhcmRvPC9zcGFuPlxuICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtaW5kaWdvLTQwMFwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtaW5kaWdvLTQwMFwiPnt0b3RhbFZpbmN1bGFkb3NUZWxlZ3JhbX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj4vIHt0b3RhbEVtcHJlc2FzfSBjaGF0czwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1pbmRpZ28tMzAwIG10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgQm90IEBTZWxlY3RyaWNCYWNrdXBfYm90XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTQgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPHNwYW4+RnJlY3VlbmNpYSBBdXRvbcOhdGljYTwvc3Bhbj5cbiAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtd2hpdGUgbXQtMlwiPjAyOjAwIEFNIChVVEMtNCk8L3A+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgIE5pZ2h0bHkgQ3JvbiArIE9uLURlbWFuZFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgey8qIE5BVkVHQUNJw5NOIEVOVFJFIFBFU1RBw5FBUyAqL31cbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtOCBiZy1zbGF0ZS05NTAvODAgcC0xLjUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdy1maXRcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2VtcHJlc2FzJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC01IHB5LTIuNSByb3VuZGVkLXhsIGZvbnQtYm9sZCB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ2VtcHJlc2FzJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctbWQgc2hhZG93LWFtYmVyLTUwMC8yMCdcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPkNvbnRyb2wgcG9yIEVtcHJlc2FzICh7ZW1wcmVzYXNSZXN1bWVuLmxlbmd0aH0pPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdnbG9iYWwnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTUgcHktMi41IHJvdW5kZWQteGwgZm9udC1ib2xkIHRleHQteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnZ2xvYmFsJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctbWQgc2hhZG93LWFtYmVyLTUwMC8yMCdcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPERhdGFiYXNlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgPHNwYW4+U25hcHNob3RzIE1hZXN0cm9zICYgRGlzYXN0ZXIgUmVjb3Zlcnk8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgey8qIFBFU1RBw5FBIDE6IENPTlRST0wgREUgUkVTR1VBUkRPIFBPUiBFTVBSRVNBICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7YWN0aXZlVGFiID09PSAnZW1wcmVzYXMnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICB7LyogQmFycmEgZGUgRmlsdHJvcyB5IELDunNxdWVkYSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTQgbWQ6cC01IGZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWQ6dy05NlwiPlxuICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS01MDAgYWJzb2x1dGUgbGVmdC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yXCIgLz5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJ1c2NhciBlbXByZXNhIHBvciBub21icmUgbyBSSUYuLi5cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC0xMCBwci00IHB5LTIuNSBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgdGV4dC1zbSB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgbWQ6dy1hdXRvIG92ZXJmbG93LXgtYXV0byBwYi0xIG1kOnBiLTBcIj5cbiAgICAgICAgICAgICAgPEZpbHRlciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNTAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0YXR1c0ZpbHRlcignQUxMJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMy41IHB5LTEuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgc3RhdHVzRmlsdGVyID09PSAnQUxMJ1xuICAgICAgICAgICAgICAgICAgICA/ICdiZy1zbGF0ZS04MDAgdGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBUb2RhcyAoe2VtcHJlc2FzUmVzdW1lbi5sZW5ndGh9KVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0YXR1c0ZpbHRlcignVklOQ1VMQURPUycpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMuNSBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgIHN0YXR1c0ZpbHRlciA9PT0gJ1ZJTkNVTEFET1MnXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLWluZGlnby01MDAvMjAgdGV4dC1pbmRpZ28tMzAwIGJvcmRlciBib3JkZXItaW5kaWdvLTUwMC8zMCdcbiAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDb24gVGVsZWdyYW0gKHt0b3RhbFZpbmN1bGFkb3NUZWxlZ3JhbX0pXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RhdHVzRmlsdGVyKCdQRU5ESUVOVEVTJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMy41IHB5LTEuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgc3RhdHVzRmlsdGVyID09PSAnUEVORElFTlRFUydcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItMzAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFNpbiBUZWxlZ3JhbSAoe3RvdGFsRW1wcmVzYXMgLSB0b3RhbFZpbmN1bGFkb3NUZWxlZ3JhbX0pXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogTGlzdGFkbyBkZSBUYXJqZXRhcyBkZSBFbXByZXNhcyAqL31cbiAgICAgICAgICB7aXNMb2FkaW5nRW1wcmVzYXMgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTEyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1hbWJlci00MDAgYW5pbWF0ZS1zcGluIG14LWF1dG8gbWItM1wiIC8+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtc21cIj5BdWRpdGFuZG8gZmljaGFzIGRlIHJlc2d1YXJkbyBwb3IgZW1wcmVzYS4uLjwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiBmaWx0ZXJlZEVtcHJlc2FzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIHAtMTIgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1zbGF0ZS02MDAgbXgtYXV0byBtYi0zXCIgLz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGVcIj5ObyBzZSBlbmNvbnRyYXJvbiBlbXByZXNhczwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBtdC0xXCI+UHJ1ZWJhIGNvbiBvdHJvIHTDqXJtaW5vIGRlIGLDunNxdWVkYSBvIGZpbHRyby48L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC01XCI+XG4gICAgICAgICAgICAgIHtmaWx0ZXJlZEVtcHJlc2FzLm1hcCgoZW1wKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAga2V5PXtlbXAuaWR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMC84MCByb3VuZGVkLTN4bCBwLTYgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gc2hhZG93LXhsIHRyYW5zaXRpb24tYWxsIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBncm91cFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIEhlYWRlciBkZSBsYSBUYXJqZXRhICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtMTEgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS04MDAgdG8tc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtYW1iZXItNDAwIGZvbnQtYm9sZCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmFzZSB0ZXh0LXdoaXRlIGdyb3VwLWhvdmVyOnRleHQtYW1iZXItNDAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcC5ub21icmV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vXCI+UklGOiB7ZW1wLnJpZn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIHtlbXAudGVsZWdyYW1DaGF0SWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1ib2xkIGJnLWluZGlnby01MDAvMTAgYm9yZGVyIGJvcmRlci1pbmRpZ28tNTAwLzMwIHRleHQtaW5kaWdvLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZW5kIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBUZWxlZ3JhbSBBY3Rpdm9cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtYm9sZCBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgdGV4dC1hbWJlci00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8S2V5IGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBQSU4gUGVuZGllbnRlXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIEZpY2hhIGRlIEFjdGl2b3MgUmVzZ3VhcmRhZG9zICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTIgYmctc2xhdGUtOTUwLzYwIHAtMyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1bMTFweF0gYmxvY2tcIj5Qcm95ZWN0b3M8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXNtXCI+e2VtcC50b3RhbGVzPy5wcm95ZWN0b3MgfHwgMH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTEuNSBib3JkZXIteCBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCB0ZXh0LVsxMXB4XSBibG9ja1wiPlRhYmxlcm9zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIHRleHQtc21cIj57ZW1wLnRvdGFsZXM/LnRhYmxlcm9zIHx8IDB9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIHRleHQtWzExcHhdIGJsb2NrXCI+VG90YWwgRXF1aXBvczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwIHRleHQtc21cIj57ZW1wLnRvdGFsZXM/LnRvdGFsQWN0aXZvcyB8fCAwfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIE1ldGFkYXRhIGRlIFJlc2d1YXJkbyAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBweC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlbXAudWx0aW1vQmFja3VwQXQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgw5psdGltbzogJHtuZXcgRGF0ZShlbXAudWx0aW1vQmFja3VwQXQpLnRvTG9jYWxlRGF0ZVN0cmluZygnZXMtVkUnKX1gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnUmVzZ3VhcmRvIHBlbmRpZW50ZSd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7ZW1wLmNlcnRpZmljYWRvSGFzaH1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBBY2Npb25lcyBkZSBsYSBUYXJqZXRhICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTUgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuQ2VydE1vZGFsKGVtcCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB5LTIgcHgtMyBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJWZXIgQ2VydGlmaWNhZG8gRWplY3V0aXZvIGRlIFJlc2d1YXJkb1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNlcnRpZmljYWRvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRG93bmxvYWRFbXByZXNhU25hcHNob3QoZW1wLmlkLCBlbXAubm9tYnJlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0FueVByb2Nlc3Npbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB5LTIgcHgtMyBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpwb2ludGVyLWV2ZW50cy1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVzY2FyZ2FyIHNuYXBzaG90IEpTT04gYWlzbGFkb1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Rvd25sb2FkaW5nRW1wcmVzYUlkID09PSBlbXAuaWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IGFuaW1hdGUtc3BpbiB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkpTT04gQWlzbGFkbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5QaW5Nb2RhbChlbXApfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHktMiBweC0zLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgZW1wLnRlbGVncmFtQ2hhdElkXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWluZGlnby01MDAvMTAgaG92ZXI6YmctaW5kaWdvLTUwMC8yMCB0ZXh0LWluZGlnby0zMDAgYm9yZGVyIGJvcmRlci1pbmRpZ28tNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1hbWJlci01MDAvMTAgaG92ZXI6YmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItNDAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPEtleSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2VtcC50ZWxlZ3JhbUNoYXRJZCA/ICdSZS12aW5jdWxhciBQSU4nIDogJ1ZpbmN1bGFyIFRlbGVncmFtJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHsvKiBQRVNUQcORQSAyOiBTTkFQU0hPVFMgTUFFU1RST1MgWSBESVNBU1RFUiBSRUNPVkVSWSAoQURNSU4pICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7YWN0aXZlVGFiID09PSAnZ2xvYmFsJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgICAgICB7LyogVGFyamV0YSAxOiBSZXNjYXRlIElubWVkaWF0byBMb2NhbCBEaXJlY3RvIChPZmZsaW5lKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgcm91bmRlZC0zeGwgcC02IG1kOnAtOCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBzaGFkb3cteGwgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGdyb3VwIGhvdmVyOmJvcmRlci1lbWVyYWxkLTUwMC81MCB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtMnhsIGJnLWVtZXJhbGQtNTAwLzEwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGQgc2hhZG93LWxnIHNoYWRvdy1lbWVyYWxkLTUwMC8xMFwiPlxuICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy02IGgtNiBzdHJva2UtWzIuNV1cIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtbGcgdGV4dC13aGl0ZVwiPkRlc2NhcmdhIExvY2FsIElubWVkaWF0YTwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1lbWVyYWxkLTQwMCBmb250LW1lZGl1bVwiPjEwMCUgT2ZmbGluZSDigKIgU2luIGJhY2tlbmQg4oCiIFJlc2NhdGUgZGlyZWN0bzwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgIEV4cG9ydGEgaW5zdGFudMOhbmVhbWVudGUgYWwgbmF2ZWdhZG9yIHRvZG9zIGxvcyBkYXRvcyBjYXJnYWRvcyBlbiBtZW1vcmlhIHkgYWxtYWNlbmFtaWVudG8gbG9jYWwgKGVtcHJlc2FzLCB0YWJsZXJvcywgY2lyY3VpdG9zLCBtZWRpY2lvbmVzKSBlbiBmb3JtYXRvIEpTT04uIEZ1bmNpb25hIGHDum4gY29uIHRva2VuIHZlbmNpZG8gbyBzaW4gY29uZXhpw7NuLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2Rlc2NhcmdhckNvcGlhTG9jYWxEaXJlY3RhfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yLjUgcHktMy41IHB4LTUgYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNTAwIHRvLXRlYWwtNjAwIGhvdmVyOmZyb20tZW1lcmFsZC00MDAgaG92ZXI6dG8tdGVhbC01MDAgYWN0aXZlOnNjYWxlLVswLjk4XSB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBzaGFkb3ctZW1lcmFsZC01MDAvMjAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNSBoLTUgc3Ryb2tlLVsyLjVdXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkRlc2NhcmdhIElubWVkaWF0YSBMb2NhbCAoLmpzb24pPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1lbWVyYWxkLTQwMC85MCBtdC0yIHRleHQtY2VudGVyIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICBSdXRhIGRlc3Rpbm86IEFsbWFjZW5hbWllbnRvIGxvY2FsIChDYXJwZXRhIGRlIERlc2NhcmdhcyAvIERvd25sb2FkcylcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBUYXJqZXRhIDI6IEV4cG9ydGFyIE1hZXN0cm8gU2Vydmlkb3IgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTYgbWQ6cC04IGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHNoYWRvdy14bCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLTJ4bCBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1hbWJlci00MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWxnIHRleHQtd2hpdGVcIj5TbmFwc2hvdCBNYWVzdHJvIGVuIE1lbW9yaWE8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+RGVzY2FyZ2EgZGlyZWN0YSBzaW4gYmxvcXVlb3MgZGUgZGlzY28gKFNlcnZlcmxlc3MgJiBEb2NrZXIpPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgR2VuZXJhIGVsIHZvbGNhZG8gdG90YWwgZXN0cnVjdHVyYWRvIGRlIGxhIGJhc2UgZGUgZGF0b3MgKGVtcHJlc2FzLCBwcm95ZWN0b3MsIHRhYmxlcm9zLCBjaXJjdWl0b3MsIGFsaW1lbnRhZG9yZXMsIG1lZGljaW9uZXMsIENDTSB5IHRlcm1vZ3JhZsOtYXMpIGVuIHVuIMO6bmljbyBhcmNoaXZvIEpTT04gY29tcGF0aWJsZSBjb24gRGlzYXN0ZXIgUmVjb3ZlcnkuXG4gICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAge2V4cG9ydFN0YXRzICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYmctc2xhdGUtOTUwLzgwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHNwYWNlLXktMSB0ZXh0LXhzIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+w5psdGltbyBzbmFwc2hvdCBtYWVzdHJvIGRlc2NhcmdhZG88L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm8gdHJ1bmNhdGVcIj57ZXhwb3J0U3RhdHMuZmlsZW5hbWV9PC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlRhbWHDsW86IHtleHBvcnRTdGF0cy5zaXplfSDigKIge2V4cG9ydFN0YXRzLnRpbWVzdGFtcH08L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggcHQtNiBib3JkZXItdCBib3JkZXItc2xhdGUtODAwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0R2xvYmFsSnNvbn1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0FueVByb2Nlc3Npbmd9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIuNSBweS0zLjUgcHgtNSBiZy1ncmFkaWVudC10by1yIGZyb20tYW1iZXItNTAwIHRvLWFtYmVyLTYwMCBob3Zlcjpmcm9tLWFtYmVyLTQwMCBob3Zlcjp0by1hbWJlci01MDAgYWN0aXZlOnNjYWxlLVswLjk4XSBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOnBvaW50ZXItZXZlbnRzLW5vbmUgdGV4dC1zbGF0ZS05NTAgZm9udC1ib2xkIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBzaGFkb3ctYW1iZXItNTAwLzIwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHRleHQtc21cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtpc0V4cG9ydGluZ0dsb2JhbCA/IChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTUgaC01IGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+R2VuZXJhbmRvIGFyY2hpdm8gSlNPTi4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5EZXNjYXJnYXIgU25hcHNob3QgTnViZSAoLmpzb24pPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWFtYmVyLTQwMC85MCBtdC0yIHRleHQtY2VudGVyIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICBSdXRhIGRlc3Rpbm86IEJhc2UgZGUgRGF0b3MgQ2VudHJhbCBQb3N0Z3JlU1FMICgvYXBpL2JhY2t1cC9jbG91ZClcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBUYXJqZXRhIDM6IEltcG9ydGFjacOzbiAvIFJlc3RhdXJhY2nDs24gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTYgbWQ6cC04IGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHNoYWRvdy14bCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLTJ4bCBiZy1jeWFuLTUwMC8xMCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtY3lhbi00MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgIDxVcGxvYWRDbG91ZCBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWxnIHRleHQtd2hpdGVcIj5SZXN0YXVyYWNpw7NuIHkgUmVjb25zdHJ1Y2Npw7NuPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlJlY3VwZXJhY2nDs24gY29tcGxldGEgYXTDs21pY2EgY29uIGludGVncmlkYWQgcmVmZXJlbmNpYWw8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIHRleHQtc20gbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICBSZXN0YXVyYSBsYSBlc3RydWN0dXJhIGNvbXBsZXRhIGRlIHByb3llY3RvcyBlbMOpY3RyaWNvcyBhIHBhcnRpciBkZSB1biByZXNwYWxkbyBtYWVzdHJvIHByZXZpby4gUmVnZW5lcmEgY2xhdmVzIGZvcsOhbmVhcywgY2lyY3VpdG9zIHkgamVyYXJxdcOtYXMgc2luIGluY29uc2lzdGVuY2lhcy5cbiAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICAgIHJlZj17ZmlsZUlucHV0UmVmfVxuICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiLmpzb24sYXBwbGljYXRpb24vanNvblwiXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgIHtpbXBvcnRTdGF0cyAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IGJnLXNsYXRlLTk1MC84MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBzcGFjZS15LTEgdGV4dC14cyB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1jeWFuLTQwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlc3RhdXJhY2nDs24gY29tcGxldGFkYSBjb24gw6l4aXRvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIHRydW5jYXRlXCI+e2ltcG9ydFN0YXRzLmZpbGVuYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj57aW1wb3J0U3RhdHMuZW1wcmVzYXNSZXN0YXVyYWRhc30gZW1wcmVzYXMgcmVzdGF1cmFkYXMg4oCiIHtpbXBvcnRTdGF0cy50aW1lc3RhbXB9PC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQW55UHJvY2Vzc2luZ31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMi41IHB5LTMuNSBweC01IGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgaG92ZXI6dGV4dC1jeWFuLTMwMCBhY3RpdmU6c2NhbGUtWzAuOThdIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6cG9pbnRlci1ldmVudHMtbm9uZSB0ZXh0LXNsYXRlLTIwMCBmb250LWJvbGQgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2lzSW1wb3J0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNSBoLTUgYW5pbWF0ZS1zcGluIHRleHQtY3lhbi00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlByb2Nlc2FuZG8gcmVzdGF1cmFjacOzbiBhdMOzbWljYS4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxVcGxvYWRDbG91ZCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtY3lhbi00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNlbGVjY2lvbmFyIEFyY2hpdm8gZGUgUmVzcGFsZG8gKC5qc29uKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEluZm9ybWFjacOzbiBkZSBBcnF1aXRlY3R1cmEgSMOtYnJpZGEgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IHRleHQteHMgdGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1zdGFydCBnYXAtNFwiPlxuICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1hbWJlci00MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHRleHQtc21cIj5BcnF1aXRlY3R1cmEgZGUgQWx0YSBEaXNwb25pYmlsaWRhZDwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgRWwgc2lzdGVtYSBlamVjdXRhIGxhIHJlY29sZWNjacOzbiBkZSBkYXRvcyBkZSBQcmlzbWEgMTAwJSBlbiBtZW1vcmlhIHBhcmEgZXZhZGlyIGxhcyByZXN0cmljY2lvbmVzIGRlIHNvbG8gbGVjdHVyYSAoPGNvZGUgY2xhc3NOYW1lPVwidGV4dC1hbWJlci0zMDBcIj5FUk9GUzwvY29kZT4pIGVuIGZ1bmNpb25lcyBzZXJ2ZXJsZXNzIGRlIFZlcmNlbC4gQWwgbWlzbW8gdGllbXBvLCBkaXN0cmlidXllIGRlIGZvcm1hIGFzw61uY3JvbmEgaGFjaWEgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMFwiPkNsb3VkZmxhcmUgUjI8L3N0cm9uZz4sIGRlc3BhY2hhIGFsZXJ0YXMgYWwgY2FuYWwgZGUgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMFwiPlRlbGVncmFtIEJvdDwvc3Ryb25nPiB5IHByZXNlcnZhIG1ldGFkYXRvcyBsaXZpYW5vcyBlbiBQb3N0Z3JlU1FMLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHsvKiBNT0RBTCAxOiBHRU5FUkFDScOTTiBZIFZJTkNVTEFDScOTTiBERSBQSU4gVEVMRUdSQU0gKi99XG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHtzZWxlY3RlZFBpbk1vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLXNsYXRlLTk1MC84MCBiYWNrZHJvcC1ibHVyLW1kIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTYgbWQ6cC04IG1heC13LW1kIHctZnVsbCBzaGFkb3ctMnhsIHJlbGF0aXZlXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBpbk1vZGFsKG51bGwpO1xuICAgICAgICAgICAgICAgIHNldENvcGllZFBpbihmYWxzZSk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTUgdG9wLTUgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC13aGl0ZSBwLTEgcm91bmRlZC14bCBiZy1zbGF0ZS04MDAvNTAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC0yeGwgYmctaW5kaWdvLTUwMC8xMCBib3JkZXIgYm9yZGVyLWluZGlnby01MDAvMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1pbmRpZ28tNDAwXCI+XG4gICAgICAgICAgICAgICAgPEtleSBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5WaW5jdWxhciBCb3QgZGUgVGVsZWdyYW08L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj57c2VsZWN0ZWRQaW5Nb2RhbC5lbXByZXNhLm5vbWJyZX08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIHRleHQteHMgbGVhZGluZy1yZWxheGVkIG1iLTZcIj5cbiAgICAgICAgICAgICAgRXN0ZSBQSU4gdGVtcG9yYWwgZGUgNiBkw61naXRvcyBwZXJtaXRlIGFsIGNsaWVudGUgdmluY3VsYXIgc3UgY2hhdCBvIGNhbmFsIGRlIFRlbGVncmFtIHBhcmEgcmVjaWJpciBjZXJ0aWZpY2Fkb3MgZGUgcmVzZ3VhcmRvIGF1dG9tw6F0aWNvcy5cbiAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAge3NlbGVjdGVkUGluTW9kYWwuaXNHZW5lcmF0aW5nID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTggdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtaW5kaWdvLTQwMCBhbmltYXRlLXNwaW4gbXgtYXV0byBtYi0yXCIgLz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+R2VuZXJhbmRvIFBJTiBjcmlwdG9ncsOhZmljby4uLjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItaW5kaWdvLTUwMC8zMCByb3VuZGVkLTJ4bCBwLTUgdGV4dC1jZW50ZXIgcmVsYXRpdmUgZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtaW5kaWdvLTQwMCB1cHBlcmNhc2UgZm9udC1ib2xkIHRyYWNraW5nLXdpZGVyIGJsb2NrIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgUElOIGRlIEFjdGl2YWNpw7NuXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJsYWNrIHRleHQtd2hpdGUgdHJhY2tpbmctd2lkZXN0IGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQaW5Nb2RhbC5waW4gfHwgJy0tLS0tLSd9XG4gICAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZFBpbk1vZGFsLnBpbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQoc2VsZWN0ZWRQaW5Nb2RhbC5waW4pO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29waWVkUGluKHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWRQaW4oZmFsc2UpLCAyNTAwKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgYmctaW5kaWdvLTUwMC8yMCBob3ZlcjpiZy1pbmRpZ28tNTAwLzMwIHRleHQtaW5kaWdvLTMwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtjb3BpZWRQaW4gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPsKhQ29waWFkbyE8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb3B5IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNvcGlhciBQSU48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzYwIHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWluZGlnby00MDBcIiAvPiBJbnN0cnVjY2lvbmVzIHBhcmEgZWwgdXN1YXJpbzpcbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDxvbCBjbGFzc05hbWU9XCJsaXN0LWRlY2ltYWwgbGlzdC1pbnNpZGUgc3BhY2UteS0xIHRleHQtc2xhdGUtNDAwIHBsLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxpPkFicmUgVGVsZWdyYW0geSBidXNjYSBlbCBib3QgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMFwiPkBTZWxlY3RyaWNCYWNrdXBfYm90PC9zdHJvbmc+PC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGxpPkVudsOtYSBlbCBjb21hbmRvOiA8Y29kZSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTMwMCBiZy1zbGF0ZS05MDAgcHgtMS41IHB5LTAuNSByb3VuZGVkXCI+L3ZpbmN1bGFyIHtzZWxlY3RlZFBpbk1vZGFsLnBpbn08L2NvZGU+PC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGxpPsKhTGlzdG8hIEVsIGNhbmFsIHJlY2liaXLDoSBsYSBjZXJ0aWZpY2FjacOzbiBkZSByZXNndWFyZG8uPC9saT5cbiAgICAgICAgICAgICAgICAgIDwvb2w+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGluTW9kYWwobnVsbCk7XG4gICAgICAgICAgICAgICAgICBzZXRDb3BpZWRQaW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMi41IHB4LTUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCBmb250LWJvbGQgcm91bmRlZC14bCB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENlcnJhclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgey8qIE1PREFMIDI6IENFUlRJRklDQURPIEVKRUNVVElWTyBERSBSRVNHVUFSRE8gKi99XG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHtzZWxlY3RlZENlcnRNb2RhbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1zbGF0ZS05NTAvODAgYmFja2Ryb3AtYmx1ci1tZCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IG1kOnAtOCBtYXgtdy1sZyB3LWZ1bGwgc2hhZG93LTJ4bCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQ2VydE1vZGFsKG51bGwpO1xuICAgICAgICAgICAgICAgIHNldENvcGllZENlcnQoZmFsc2UpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC01IHRvcC01IHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtd2hpdGUgcC0xIHJvdW5kZWQteGwgYmctc2xhdGUtODAwLzUwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAge3NlbGVjdGVkQ2VydE1vZGFsLmlzTG9hZGluZyA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xMiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1hbWJlci00MDAgYW5pbWF0ZS1zcGluIG14LWF1dG8gbWItM1wiIC8+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkdlbmVyYW5kbyBjZXJ0aWZpY2FkbyBvZmljaWFsIGRlIHJlc2d1YXJkby4uLjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogc2VsZWN0ZWRDZXJ0TW9kYWwuZmljaGEgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICAgICAgey8qIEhlYWRlciBkZWwgQ2VydGlmaWNhZG8gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTUgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IHJvdW5kZWQtMnhsIGJnLWVtZXJhbGQtNTAwLzEwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1lbWVyYWxkLTQwMCBteC1hdXRvIG1iLTMgc2hhZG93LWxnIHNoYWRvdy1lbWVyYWxkLTUwMC8xMFwiPlxuICAgICAgICAgICAgICAgICAgICA8RmlsZUNoZWNrIGNsYXNzTmFtZT1cInctNyBoLTdcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJsYWNrIHRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cbiAgICAgICAgICAgICAgICAgICAgQ2VydGlmaWNhZG8gZGUgUmVzZ3VhcmRvIEVsw6ljdHJpY29cbiAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNSBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkQ2VydE1vZGFsLmZpY2hhLmNlcnRpZmljYWRvLmNvZGlnb31cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBEYXRvcyBkZSBsYSBFbXByZXNhIHkgRXN0YWRvICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzcwIHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHktMSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwLzYwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+RW1wcmVzYTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LXNlbWlib2xkXCI+e3NlbGVjdGVkQ2VydE1vZGFsLmZpY2hhLmVtcHJlc2Eubm9tYnJlfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0xIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAvNjBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5SSUY6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBmb250LW1vbm9cIj57c2VsZWN0ZWRDZXJ0TW9kYWwuZmljaGEuZW1wcmVzYS5yaWZ9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0xIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAvNjBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj7Dmmx0aW1hIFNpbmNyb25pemFjacOzbjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYW1iZXItNDAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRDZXJ0TW9kYWwuZmljaGEuZW1wcmVzYS51bHRpbW9CYWNrdXBBdCBcbiAgICAgICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUoc2VsZWN0ZWRDZXJ0TW9kYWwuZmljaGEuZW1wcmVzYS51bHRpbW9CYWNrdXBBdCkudG9Mb2NhbGVTdHJpbmcoJ2VzLVZFJylcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ0VuIHByb2Nlc28nfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB5LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5Fc3RhZG8gZGUgUHJvdGVjY2nDs246PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkIGJnLWVtZXJhbGQtNTAwLzEwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIOKckyBTbmFwc2hvdCBDcmlwdG9ncsOhZmljbyBWZXJpZmljYWRvXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIERlc2dsb3NlIGRlIEFjdGl2b3MgUHJvdGVnaWRvcyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj5BY3Rpdm9zIEVsw6ljdHJpY29zIFJlc2d1YXJkYWRvczo8L3A+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIGZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5Qcm95ZWN0b3M6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiPntzZWxlY3RlZENlcnRNb2RhbC5maWNoYS50b3RhbGVzLnByb3llY3Rvc308L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlRhYmxlcm9zOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtYW1iZXItNDAwXCI+e3NlbGVjdGVkQ2VydE1vZGFsLmZpY2hhLnRvdGFsZXMudGFibGVyb3N9PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIGZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5DaXJjdWl0b3M6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1jeWFuLTQwMFwiPntzZWxlY3RlZENlcnRNb2RhbC5maWNoYS50b3RhbGVzLmNpcmN1aXRvc308L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlRvdGFsIEFjdGl2b3M6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMFwiPntzZWxlY3RlZENlcnRNb2RhbC5maWNoYS50b3RhbGVzLnRvdGFsQWN0aXZvc308L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBGb290ZXIgZGVsIE1vZGFsICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGV4dENlcnQgPSBg8J+boe+4jyBDRVJUSUZJQ0FETyBERSBSRVNHVUFSRE8gU0VMRUNUUklDXFxuRW1wcmVzYTogJHtzZWxlY3RlZENlcnRNb2RhbC5maWNoYS5lbXByZXNhLm5vbWJyZX1cXG5Dw7NkaWdvOiAke3NlbGVjdGVkQ2VydE1vZGFsLmZpY2hhLmNlcnRpZmljYWRvLmNvZGlnb31cXG5Ub3RhbCBBY3Rpdm9zOiAke3NlbGVjdGVkQ2VydE1vZGFsLmZpY2hhLnRvdGFsZXMudG90YWxBY3Rpdm9zfVxcbkZlY2hhOiAke25ldyBEYXRlKCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlcy1WRScpfWA7XG4gICAgICAgICAgICAgICAgICAgICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQodGV4dENlcnQpO1xuICAgICAgICAgICAgICAgICAgICAgIHNldENvcGllZENlcnQodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWRDZXJ0KGZhbHNlKSwgMjUwMCk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHktMiBweC0zLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtjb3BpZWRDZXJ0ID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7CoUNvcGlhZG8hPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29weSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Db3BpYXIgQ2VydGlmaWNhZG88L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDZXJ0TW9kYWwobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0Q29waWVkQ2VydChmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTIgcHgtNSBiZy1ncmFkaWVudC10by1yIGZyb20tYW1iZXItNTAwIHRvLWFtYmVyLTYwMCBob3Zlcjpmcm9tLWFtYmVyLTQwMCBob3Zlcjp0by1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ib2xkIHJvdW5kZWQteGwgdGV4dC14cyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBzaGFkb3ctbWQgc2hhZG93LWFtYmVyLTUwMC8yMFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEFjZXB0YXJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBCYWNrdXBWaWV3OyJdfQ==