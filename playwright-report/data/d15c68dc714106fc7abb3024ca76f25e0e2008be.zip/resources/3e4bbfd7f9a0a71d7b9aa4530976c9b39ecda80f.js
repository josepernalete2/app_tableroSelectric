import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PanelConflictosCircuitos.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { AlertTriangle, X, ExternalLink, CheckCircle2, Trash2, ShieldAlert, Zap, Layers, ArrowRight } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/PanelConflictosCircuitos.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function PanelConflictosCircuitos() {
	_s();
	const navigate = useNavigate();
	const { conflictosCircuitos = [], isPanelConflictosOpen, setPanelConflictosOpen, resolverConflictoCircuito, limpiarConflictosCircuitos } = useStore();
	const totalConflictos = conflictosCircuitos.length;
	if (totalConflictos === 0 && !isPanelConflictosOpen) {
		return null;
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [!isPanelConflictosOpen && totalConflictos > 0 && /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed bottom-6 left-6 z-45 no-print animate-bounce",
		children: /* @__PURE__ */ _jsxDEV("button", {
			onClick: () => setPanelConflictosOpen(true),
			className: "flex items-center gap-2.5 px-4 py-3 bg-amber-550 hover:bg-amber-400 text-slate-950 font-black rounded-2xl shadow-2xl border-2 border-amber-300 transition-all cursor-pointer group hover:scale-105",
			title: "Ver conflictos de circuitos detectados",
			children: [
				/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-5 h-5 text-slate-950 animate-pulse" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs tracking-wider uppercase font-mono",
					children: [
						totalConflictos,
						" ",
						totalConflictos === 1 ? "Conflicto de Polos" : "Conflictos de Polos"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-red-600 animate-ping" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 11
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 9
	}, this), isPanelConflictosOpen && /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-55 flex justify-end no-print",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity animate-in fade-in",
			onClick: () => setPanelConflictosOpen(false)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-md h-full bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-300",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30",
							children: /* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-black text-slate-100 uppercase tracking-wider font-mono",
							children: "Conflictos de Circuitos"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-400 font-sans",
							children: [
								totalConflictos,
								" ",
								totalConflictos === 1 ? "incidencia detectada" : "incidencias detectadas"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1.5",
						children: [totalConflictos > 0 && /* @__PURE__ */ _jsxDEV("button", {
							onClick: limpiarConflictosCircuitos,
							className: "p-1.5 hover:bg-slate-800 text-slate-400 hover:text-red-400 rounded-lg transition-colors cursor-pointer",
							title: "Limpiar todos los conflictos",
							children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setPanelConflictosOpen(false),
							className: "p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto p-4 space-y-3.5 custom-scrollbar",
					children: totalConflictos === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "text-center py-16 space-y-3 text-slate-400",
						children: [
							/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-10 h-10 text-emerald-400 mx-auto" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-bold text-slate-200",
								children: "No hay conflictos pendientes"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-500 max-w-xs mx-auto",
								children: "Todos los polos y circuitos del proyecto se encuentran asignados correctamente sin solapamientos."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 17
					}, this) : conflictosCircuitos.map((conflicto) => {
						const polosStr = Array.isArray(conflicto.polos) ? conflicto.polos.join(", ") : conflicto.polos || "N/A";
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 bg-slate-950/80 border border-amber-500/30 rounded-2xl space-y-3 shadow-lg hover:border-amber-500/50 transition-all group",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40",
											children: ["POLO(S): ", polosStr]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 120,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] font-mono text-slate-500",
											children: conflicto.tipo || "SOLAPAMIENTO"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 123,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 119,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => resolverConflictoCircuito(conflicto.id),
										className: "text-[10px] font-bold text-slate-400 hover:text-emerald-400 flex items-center gap-1 transition-colors cursor-pointer",
										title: "Marcar como resuelto",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 132,
											columnNumber: 27
										}, this), " Resolver"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 127,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 23
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-xs font-bold text-slate-200 flex items-center gap-1.5 font-mono",
									children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-3.5 h-3.5 text-amber-400 shrink-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 138,
										columnNumber: 27
									}, this), conflicto.tableroNombre || `Tablero ${conflicto.tableroId || ""}`]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400 font-sans mt-1 leading-relaxed",
									children: conflicto.descripcion
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 25
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 23
								}, this),
								conflicto.equipoExistente && conflicto.equipoNuevo && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-2.5 bg-slate-900/90 rounded-xl text-[10px] font-mono border border-slate-800 space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-400 truncate",
										children: [
											/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-amber-400",
												children: "Existente:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 149,
												columnNumber: 29
											}, this),
											" ",
											conflicto.equipoExistente
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 148,
										columnNumber: 27
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-400 truncate",
										children: [
											/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-sky-400",
												children: "En conflicto:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 152,
												columnNumber: 29
											}, this),
											" ",
											conflicto.equipoNuevo
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 151,
										columnNumber: 27
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 border-t border-slate-900 flex justify-end",
									children: /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setPanelConflictosOpen(false);
											if (conflicto.empresaId && conflicto.tableroId) {
												navigate(`/empresa/${conflicto.empresaId}/tablero/${conflicto.tableroId}#pole-${Array.isArray(conflicto.polos) ? conflicto.polos[0] : conflicto.polos}`);
											}
										},
										className: "px-3 py-1.5 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Resolver / Ir al Sitio" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 168,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 169,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 159,
										columnNumber: 25
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 23
								}, this)
							]
						}, conflicto.id, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 21
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-3.5 border-t border-slate-800 bg-slate-950 text-center text-[10px] text-slate-500 font-sans",
					children: "Sistema No Bloqueante de Integridad Eléctrica (Selectric)"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 179,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 11
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 53,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 5
	}, this);
}
_s(PanelConflictosCircuitos, "0PRJmyUMO9rbWyBek9awTrSl4Ss=", false, function() {
	return [useNavigate, useStore];
});
_c = PanelConflictosCircuitos;
var _c;
$RefreshReg$(_c, "PanelConflictosCircuitos");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PanelConflictosCircuitos.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/PanelConflictosCircuitos.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/PanelConflictosCircuitos.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/PanelConflictosCircuitos.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsbUJBQW1CO0FBQzVCLE9BQU8sY0FBYztBQUNyQixTQUNFLGVBQ0EsR0FDQSxjQUNBLGNBQ0EsUUFDQSxhQUNBLEtBQ0EsUUFDQSxrQkFDSzs7OztBQUVQLGVBQWUsU0FBUywyQkFBMkI7O0NBQ2pELE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sRUFDSixzQkFBc0IsQ0FBQyxHQUN2Qix1QkFDQSx3QkFDQSwyQkFDQSwrQkFDRSxTQUFTO0NBRWIsTUFBTSxrQkFBa0Isb0JBQW9CO0NBRTVDLElBQUksb0JBQW9CLEtBQUssQ0FBQyx1QkFBdUI7RUFDbkQsT0FBTztDQUNUO0NBRUEsT0FDRSxnREFFRyxDQUFDLHlCQUF5QixrQkFBa0IsS0FDM0Msd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxVQUFEO0dBQ0UsZUFBZSx1QkFBdUIsSUFBSTtHQUMxQyxXQUFVO0dBQ1YsT0FBTTthQUhSO0lBS0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUsdUNBQXdDOzs7OztJQUNqRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQjtNQUNHO01BQWdCO01BQUUsb0JBQW9CLElBQUksdUJBQXVCO0tBQzlEOzs7Ozs7SUFDTix3QkFBQyxRQUFELEVBQU0sV0FBVSwrQ0FBZ0Q7Ozs7O0dBQzFEOzs7Ozs7Q0FDTDs7OztXQUlOLHlCQUNDLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FFRSx3QkFBQyxPQUFEO0dBQ0UsV0FBVTtHQUNWLGVBQWUsdUJBQXVCLEtBQUs7RUFDNUM7Ozs7WUFHRCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsYUFBRCxFQUFhLFdBQVUsVUFBVzs7Ozs7TUFDL0I7Ozs7Z0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUF1RTtNQUVqRjs7OztnQkFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUNHO1FBQWdCO1FBQUUsb0JBQW9CLElBQUkseUJBQXlCO09BQ25FOzs7OztjQUNBOzs7O2NBQ0Y7Ozs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRyxrQkFBa0IsS0FDakIsd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxXQUFVO09BQ1YsT0FBTTtpQkFFTix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztNQUN2Qjs7OztnQkFFVix3QkFBQyxVQUFEO09BQ0UsZUFBZSx1QkFBdUIsS0FBSztPQUMzQyxXQUFVO2lCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O01BQ2xCOzs7O2NBQ0w7Ozs7O2FBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osb0JBQW9CLElBQ25CLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUscUNBQXNDOzs7OztPQUM5RCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBbUM7T0FBK0I7Ozs7O09BQy9FLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE4QztPQUV4RDs7Ozs7TUFDQTs7Ozs7Z0JBRUwsb0JBQW9CLEtBQUssY0FBYztNQUNyQyxNQUFNLFdBQVcsTUFBTSxRQUFRLFVBQVUsS0FBSyxJQUMxQyxVQUFVLE1BQU0sS0FBSyxJQUFJLElBQ3hCLFVBQVUsU0FBUztNQUV4QixPQUNFLHdCQUFDLE9BQUQ7T0FFRSxXQUFVO2lCQUZaO1FBSUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUFtSSxhQUN2SCxRQUNOOzs7OztvQkFDTix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixVQUFVLFFBQVE7VUFDZjs7OztrQkFDSDs7Ozs7bUJBQ0wsd0JBQUMsVUFBRDtVQUNFLGVBQWUsMEJBQTBCLFVBQVUsRUFBRTtVQUNyRCxXQUFVO1VBQ1YsT0FBTTtvQkFIUixDQUtFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLGNBQWU7Ozs7b0JBQUMsV0FDbEM7Ozs7O2lCQUNMOzs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxzQ0FBdUM7Ozs7bUJBQ3hELFVBQVUsaUJBQWlCLFdBQVcsVUFBVSxhQUFhLElBQzVEOzs7OztrQkFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixVQUFVO1FBQ1Y7Ozs7Z0JBQ0E7Ozs7O1FBRUosVUFBVSxtQkFBbUIsVUFBVSxlQUN0Qyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsVUFBRDtZQUFRLFdBQVU7c0JBQWlCO1dBQWtCOzs7OztXQUFDO1dBQUUsVUFBVTtVQUMvRDs7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxVQUFEO1lBQVEsV0FBVTtzQkFBZTtXQUFxQjs7Ozs7V0FBQztXQUFFLFVBQVU7VUFDaEU7Ozs7O2lCQUNGOzs7Ozs7UUFJUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxVQUFEO1VBQ0UsZUFBZTtXQUNiLHVCQUF1QixLQUFLO1dBQzVCLElBQUksVUFBVSxhQUFhLFVBQVUsV0FBVztZQUM5QyxTQUFTLFlBQVksVUFBVSxVQUFVLFdBQVcsVUFBVSxVQUFVLFFBQVEsTUFBTSxRQUFRLFVBQVUsS0FBSyxJQUFJLFVBQVUsTUFBTSxLQUFLLFVBQVUsT0FBTztXQUN6SjtVQUNGO1VBQ0EsV0FBVTtvQkFQWixDQVNFLHdCQUFDLFFBQUQsWUFBTSx5QkFBNEI7Ozs7b0JBQ2xDLHdCQUFDLFlBQUQsRUFBWSxXQUFVLGNBQWU7Ozs7a0JBQy9COzs7Ozs7UUFDTDs7Ozs7T0FDRjtTQXpERSxVQUFVOzs7O2FBeURaO0tBRVQsQ0FBQztJQUVBOzs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWdHO0lBRTFHOzs7OztHQUNGOzs7OztVQUNGOzs7OztTQUVQOzs7OztBQUVOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBhbmVsQ29uZmxpY3Rvc0NpcmN1aXRvcy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgdXNlU3RvcmUgZnJvbSAnLi4vc3RvcmUvdXNlU3RvcmUnO1xuaW1wb3J0IHsgXG4gIEFsZXJ0VHJpYW5nbGUsIFxuICBYLCBcbiAgRXh0ZXJuYWxMaW5rLCBcbiAgQ2hlY2tDaXJjbGUyLCBcbiAgVHJhc2gyLCBcbiAgU2hpZWxkQWxlcnQsIFxuICBaYXAsXG4gIExheWVycyxcbiAgQXJyb3dSaWdodFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQYW5lbENvbmZsaWN0b3NDaXJjdWl0b3MoKSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgeyBcbiAgICBjb25mbGljdG9zQ2lyY3VpdG9zID0gW10sIFxuICAgIGlzUGFuZWxDb25mbGljdG9zT3BlbiwgXG4gICAgc2V0UGFuZWxDb25mbGljdG9zT3BlbiwgXG4gICAgcmVzb2x2ZXJDb25mbGljdG9DaXJjdWl0bywgXG4gICAgbGltcGlhckNvbmZsaWN0b3NDaXJjdWl0b3MgXG4gIH0gPSB1c2VTdG9yZSgpO1xuXG4gIGNvbnN0IHRvdGFsQ29uZmxpY3RvcyA9IGNvbmZsaWN0b3NDaXJjdWl0b3MubGVuZ3RoO1xuXG4gIGlmICh0b3RhbENvbmZsaWN0b3MgPT09IDAgJiYgIWlzUGFuZWxDb25mbGljdG9zT3Blbikge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgey8qIEJvdMOzbiBmbG90YW50ZSBpbmRpY2Fkb3IgZGUgY29uZmxpY3RvcyBjdWFuZG8gZWwgZHJhd2VyIGVzdMOhIGNlcnJhZG8gKi99XG4gICAgICB7IWlzUGFuZWxDb25mbGljdG9zT3BlbiAmJiB0b3RhbENvbmZsaWN0b3MgPiAwICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tNiBsZWZ0LTYgei00NSBuby1wcmludCBhbmltYXRlLWJvdW5jZVwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBhbmVsQ29uZmxpY3Rvc09wZW4odHJ1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTQgcHktMyBiZy1hbWJlci01NTAgaG92ZXI6YmctYW1iZXItNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBib3JkZXItMiBib3JkZXItYW1iZXItMzAwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGdyb3VwIGhvdmVyOnNjYWxlLTEwNVwiXG4gICAgICAgICAgICB0aXRsZT1cIlZlciBjb25mbGljdG9zIGRlIGNpcmN1aXRvcyBkZXRlY3RhZG9zXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtc2xhdGUtOTUwIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0cmFja2luZy13aWRlciB1cHBlcmNhc2UgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgIHt0b3RhbENvbmZsaWN0b3N9IHt0b3RhbENvbmZsaWN0b3MgPT09IDEgPyAnQ29uZmxpY3RvIGRlIFBvbG9zJyA6ICdDb25mbGljdG9zIGRlIFBvbG9zJ31cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLXJlZC02MDAgYW5pbWF0ZS1waW5nXCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogRHJhd2VyIC8gUGFuZWwgbGF0ZXJhbCBkZXNsaXphYmxlICovfVxuICAgICAge2lzUGFuZWxDb25mbGljdG9zT3BlbiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTU1IGZsZXgganVzdGlmeS1lbmQgbm8tcHJpbnRcIj5cbiAgICAgICAgICB7LyogQmFja2Ryb3AgKi99XG4gICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctc2xhdGUtOTUwLzcwIGJhY2tkcm9wLWJsdXIteHMgdHJhbnNpdGlvbi1vcGFjaXR5IGFuaW1hdGUtaW4gZmFkZS1pblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQYW5lbENvbmZsaWN0b3NPcGVuKGZhbHNlKX1cbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgey8qIFBhbmVsICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LW1kIGgtZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyLWwgYm9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctMnhsIGZsZXggZmxleC1jb2wgei0xMCBhbmltYXRlLWluIHNsaWRlLWluLWZyb20tcmlnaHQgZHVyYXRpb24tMzAwXCI+XG4gICAgICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS05NTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTQwMCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwXCI+XG4gICAgICAgICAgICAgICAgICA8U2hpZWxkQWxlcnQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS0xMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICBDb25mbGljdG9zIGRlIENpcmN1aXRvc1xuICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtc2Fuc1wiPlxuICAgICAgICAgICAgICAgICAgICB7dG90YWxDb25mbGljdG9zfSB7dG90YWxDb25mbGljdG9zID09PSAxID8gJ2luY2lkZW5jaWEgZGV0ZWN0YWRhJyA6ICdpbmNpZGVuY2lhcyBkZXRlY3RhZGFzJ31cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAge3RvdGFsQ29uZmxpY3RvcyA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtsaW1waWFyQ29uZmxpY3Rvc0NpcmN1aXRvc31cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtcmVkLTQwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMaW1waWFyIHRvZG9zIGxvcyBjb25mbGljdG9zXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGFuZWxDb25mbGljdG9zT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBob3ZlcjpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIExpc3RhZG8gZGUgQ29uZmxpY3RvcyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBwLTQgc3BhY2UteS0zLjUgY3VzdG9tLXNjcm9sbGJhclwiPlxuICAgICAgICAgICAgICB7dG90YWxDb25mbGljdG9zID09PSAwID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTYgc3BhY2UteS0zIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LWVtZXJhbGQtNDAwIG14LWF1dG9cIiAvPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDBcIj5ObyBoYXkgY29uZmxpY3RvcyBwZW5kaWVudGVzPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgbWF4LXcteHMgbXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICBUb2RvcyBsb3MgcG9sb3MgeSBjaXJjdWl0b3MgZGVsIHByb3llY3RvIHNlIGVuY3VlbnRyYW4gYXNpZ25hZG9zIGNvcnJlY3RhbWVudGUgc2luIHNvbGFwYW1pZW50b3MuXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgY29uZmxpY3Rvc0NpcmN1aXRvcy5tYXAoKGNvbmZsaWN0bykgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgcG9sb3NTdHIgPSBBcnJheS5pc0FycmF5KGNvbmZsaWN0by5wb2xvcykgXG4gICAgICAgICAgICAgICAgICAgID8gY29uZmxpY3RvLnBvbG9zLmpvaW4oJywgJykgXG4gICAgICAgICAgICAgICAgICAgIDogKGNvbmZsaWN0by5wb2xvcyB8fCAnTi9BJyk7XG5cbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtjb25mbGljdG8uaWR9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IGJnLXNsYXRlLTk1MC84MCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCByb3VuZGVkLTJ4bCBzcGFjZS15LTMgc2hhZG93LWxnIGhvdmVyOmJvcmRlci1hbWJlci01MDAvNTAgdHJhbnNpdGlvbi1hbGwgZ3JvdXBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkLW1kIHRleHQtWzEwcHhdIGZvbnQtbW9ubyBmb250LWJvbGQgYmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItMzAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzQwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUE9MTyhTKToge3BvbG9zU3RyfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb25mbGljdG8udGlwbyB8fCAnU09MQVBBTUlFTlRPJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlc29sdmVyQ29uZmxpY3RvQ2lyY3VpdG8oY29uZmxpY3RvLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtZW1lcmFsZC00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIk1hcmNhciBjb21vIHJlc3VlbHRvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IFJlc29sdmVyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExheWVycyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjb25mbGljdG8udGFibGVyb05vbWJyZSB8fCBgVGFibGVybyAke2NvbmZsaWN0by50YWJsZXJvSWQgfHwgJyd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LXNhbnMgbXQtMSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbmZsaWN0by5kZXNjcmlwY2lvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIHtjb25mbGljdG8uZXF1aXBvRXhpc3RlbnRlICYmIGNvbmZsaWN0by5lcXVpcG9OdWV2byAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMi41IGJnLXNsYXRlLTkwMC85MCByb3VuZGVkLXhsIHRleHQtWzEwcHhdIGZvbnQtbW9ubyBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1hbWJlci00MDBcIj5FeGlzdGVudGU6PC9zdHJvbmc+IHtjb25mbGljdG8uZXF1aXBvRXhpc3RlbnRlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1za3ktNDAwXCI+RW4gY29uZmxpY3RvOjwvc3Ryb25nPiB7Y29uZmxpY3RvLmVxdWlwb051ZXZvfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQm90w7NuIGRlIGFjY2nDs246IElyIGFsIFNpdGlvICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwIGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBhbmVsQ29uZmxpY3Rvc09wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb25mbGljdG8uZW1wcmVzYUlkICYmIGNvbmZsaWN0by50YWJsZXJvSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKGAvZW1wcmVzYS8ke2NvbmZsaWN0by5lbXByZXNhSWR9L3RhYmxlcm8vJHtjb25mbGljdG8udGFibGVyb0lkfSNwb2xlLSR7QXJyYXkuaXNBcnJheShjb25mbGljdG8ucG9sb3MpID8gY29uZmxpY3RvLnBvbG9zWzBdIDogY29uZmxpY3RvLnBvbG9zfWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCBhY3RpdmU6c2NhbGUtOTUgdGV4dC1zbGF0ZS05NTAgZm9udC1ibGFjayB0ZXh0LXhzIHJvdW5kZWQteGwgc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SZXNvbHZlciAvIElyIGFsIFNpdGlvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS05NTAgdGV4dC1jZW50ZXIgdGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1zYW5zXCI+XG4gICAgICAgICAgICAgIFNpc3RlbWEgTm8gQmxvcXVlYW50ZSBkZSBJbnRlZ3JpZGFkIEVsw6ljdHJpY2EgKFNlbGVjdHJpYylcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC8+XG4gICk7XG59XG4iXX0=