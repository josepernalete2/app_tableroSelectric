import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/DashboardView.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
import NotificationButton from "/src/components/NotificationButton.jsx";
import { Folder, FolderPlus, Trash2, Briefcase, ChevronRight, X, Search } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/DashboardView.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export const DashboardView = () => {
	_s();
	const { user, companies, addCompany, deleteCompany, cargarDatosServidor } = useStore();
	const { confirm } = useConfirm();
	useEffect(() => {
		if (cargarDatosServidor) {
			cargarDatosServidor();
		}
	}, [cargarDatosServidor]);
	const [showModal, setShowModal] = useState(false);
	const [newCompanyName, setNewCompanyName] = useState("");
	const [rif, setRif] = useState("");
	const [direccionFiscal, setDireccionFiscal] = useState("");
	const [gerente1Nombre, setGerente1Nombre] = useState("");
	const [gerente1Telefono, setGerente1Telefono] = useState("");
	const [gerente1Email, setGerente1Email] = useState("");
	const [gerente2Nombre, setGerente2Nombre] = useState("");
	const [gerente2Telefono, setGerente2Telefono] = useState("");
	const [gerente2Email, setGerente2Email] = useState("");
	const [searchQuery, setSearchQuery] = useState("");
	const navigate = useNavigate();
	const handleCreateCompany = async (e) => {
		e.preventDefault();
		if (!newCompanyName.trim() || !rif.trim() || !direccionFiscal.trim()) return;
		await addCompany({
			nombre: newCompanyName.trim(),
			rif: rif.trim(),
			direccionFiscal: direccionFiscal.trim(),
			gerente1Nombre: gerente1Nombre.trim() || null,
			gerente1Telefono: gerente1Telefono.trim() || null,
			gerente1Email: gerente1Email.trim() || null,
			gerente2Nombre: gerente2Nombre.trim() || null,
			gerente2Telefono: gerente2Telefono.trim() || null,
			gerente2Email: gerente2Email.trim() || null
		});
		setNewCompanyName("");
		setRif("");
		setDireccionFiscal("");
		setGerente1Nombre("");
		setGerente1Telefono("");
		setGerente1Email("");
		setGerente2Nombre("");
		setGerente2Telefono("");
		setGerente2Email("");
		setShowModal(false);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased",
		children: [/* @__PURE__ */ _jsxDEV("main", {
			className: "flex-1 max-w-7xl w-full mx-auto px-6 py-8 space-y-6",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4 pb-6 border-b border-slate-800/80",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl font-extrabold text-slate-100 tracking-tight flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Briefcase, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 15
						}, this), " Mis Empresas Inspeccionadas"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400 mt-1",
						children: "Selecciona una empresa para gestionar sus tableros eléctricos o registra una nueva."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap sm:flex-nowrap items-center gap-3 justify-end w-full sm:w-auto",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "input-search-container w-full sm:w-64",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: searchQuery,
								onChange: (e) => setSearchQuery(e.target.value),
								placeholder: "Buscar empresa...",
								className: "input-search"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Search, { className: "w-4.5 h-4.5 absolute left-3.5 top-3 text-slate-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 13
						}, this), user?.role !== "CLIENT" && /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowModal(true),
							className: "bg-amber-500 text-slate-950 font-semibold hover:bg-amber-400 active:scale-98 transition-all px-4 py-2.5 rounded-lg flex flex-row items-center justify-center gap-2 h-10 whitespace-nowrap w-full sm:w-auto cursor-pointer text-xs",
							children: [/* @__PURE__ */ _jsxDEV(FolderPlus, { className: "w-4.5 h-4.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 17
							}, this), " + Registrar Empresa"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(NotificationButton, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 9
				}, this),
				(() => {
					const filteredCompanies = companies.filter((c) => {
						if (user?.role === "CLIENT") {
							return c.id === user.companyId;
						}
						return c.nombre.toLowerCase().includes(searchQuery.toLowerCase());
					});
					if (filteredCompanies.length > 0) {
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
							children: filteredCompanies.map((company) => /* @__PURE__ */ _jsxDEV("div", {
								onClick: () => navigate(`/empresa/${company.id}`),
								className: "bg-slate-950 border border-slate-800 hover:border-slate-700 p-5 rounded-2xl shadow-md hover:shadow-lg flex items-center justify-between cursor-pointer transition-all hover:translate-y-[-2px] group",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-4 min-w-0 flex-1 mr-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 bg-amber-500/10 text-amber-500 rounded-xl group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors shrink-0",
										children: /* @__PURE__ */ _jsxDEV(Folder, { className: "w-8 h-8 fill-transparent group-hover:fill-slate-950" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 130,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 129,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "text-sm font-bold text-slate-100 group-hover:text-amber-400 transition-colors truncate",
											children: company.nombre
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 133,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] text-slate-400 mt-1 truncate",
											children: [(company.elementosUnifilares || []).length + (company.proyectos || []).reduce((acc, p) => acc + (p.elementosUnifilares || []).length, 0), " Equipos Registrados"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 136,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 132,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 shrink-0",
									children: [user?.role !== "CLIENT" && /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: async (e) => {
											e.stopPropagation();
											const ok = await confirm({
												title: "Eliminar Empresa",
												message: `¿Estás seguro de que deseas eliminar la empresa "${company.nombre}" y todos sus tableros y proyectos en cascada?`,
												type: "danger",
												confirmText: "Eliminar Empresa"
											});
											if (ok) {
												deleteCompany(company.id);
											}
										},
										className: "p-2 bg-slate-900/90 hover:bg-red-950/40 text-slate-400 hover:text-red-400 border border-slate-800 hover:border-red-900/60 rounded-xl transition-all cursor-pointer opacity-100 shadow-xs",
										title: "Eliminar Empresa",
										children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 161,
											columnNumber: 27
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 144,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-5 h-5 text-slate-600 group-hover:text-slate-350 transition-colors" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 164,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 21
								}, this)]
							}, company.id, true, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 19
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 15
						}, this);
					}
					if (searchQuery.trim() !== "") {
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "p-12 border-2 border-dashed border-slate-800 rounded-2xl text-center space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV(Search, { className: "w-12 h-12 text-slate-700 mx-auto animate-pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 175,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-bold text-slate-400",
									children: "No se encontraron empresas"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 max-w-sm mx-auto",
									children: [
										"No hay registros que coincidan con la búsqueda \"",
										searchQuery,
										"\"."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 177,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 15
						}, this);
					}
					return /* @__PURE__ */ _jsxDEV("div", {
						className: "p-12 border-2 border-dashed border-slate-800 rounded-2xl text-center space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV(Folder, { className: "w-12 h-12 text-slate-700 mx-auto" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-slate-400",
								children: "No hay empresas registradas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 max-w-sm mx-auto",
								children: "Comienza registrando tu primera empresa contratante para inspeccionar sus tableros eléctricos."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 186,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowModal(true),
								className: "mt-2 bg-amber-500 text-slate-950 font-semibold hover:bg-amber-400 active:scale-98 transition-all px-4 py-2.5 rounded-lg flex flex-row items-center justify-center gap-2 h-10 whitespace-nowrap mx-auto cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(FolderPlus, { className: "w-4.5 h-4.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 191,
									columnNumber: 17
								}, this), " + Registrar Empresa"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 183,
						columnNumber: 13
					}, this);
				})()
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 71,
			columnNumber: 7
		}, this), showModal && /* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 z-50 flex items-center justify-center p-4",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200",
				onClick: () => setShowModal(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 201,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "relative w-full max-w-lg bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden animate-in zoom-in-95 duration-200",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-between items-center pb-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-sm font-bold uppercase tracking-wider text-slate-200",
						children: "Registrar Nueva Empresa"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setShowModal(false),
						className: "p-1.5 hover:bg-slate-900 rounded-lg text-slate-500 cursor-pointer",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 208,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 204,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleCreateCompany,
					className: "mt-4 space-y-4 max-h-[70vh] overflow-y-auto pr-1 text-xs",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
							children: "Nombre de la Empresa / Cliente"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							required: true,
							value: newCompanyName,
							onChange: (e) => setNewCompanyName(e.target.value),
							placeholder: "Ej. Farmatodo Sucursal Chacao",
							className: "w-full px-3 py-2 bg-slate-900 border border-slate-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-lg text-xs text-slate-100 focus:outline-none placeholder-slate-600 h-9"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 217,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "RIF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 233,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								required: true,
								value: rif,
								onChange: (e) => setRif(e.target.value),
								placeholder: "Ej. J-12345678-9",
								className: "w-full px-3 py-2 bg-slate-900 border border-slate-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-lg text-xs text-slate-100 focus:outline-none placeholder-slate-600 h-9"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 236,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Dirección Fiscal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 246,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								required: true,
								value: direccionFiscal,
								onChange: (e) => setDireccionFiscal(e.target.value),
								placeholder: "Ej. Av. Araure, San Román...",
								className: "w-full px-3 py-2 bg-slate-900 border border-slate-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-lg text-xs text-slate-100 focus:outline-none placeholder-slate-600 h-9"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 231,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border-t border-slate-800 pt-3 mt-3",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] text-sky-400 font-bold uppercase tracking-wider block mb-2",
								children: "Contacto Gerente Principal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 261,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[9px] font-bold text-slate-500 uppercase mb-0.5",
										children: "Nombre"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 264,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: gerente1Nombre,
										onChange: (e) => setGerente1Nombre(e.target.value),
										placeholder: "Nombre",
										className: "w-full px-2 py-1 bg-slate-900 border border-slate-700 focus:border-amber-500 rounded text-xs text-slate-100 focus:outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 265,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 263,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[9px] font-bold text-slate-500 uppercase mb-0.5",
										children: "Teléfono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 274,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: gerente1Telefono,
										onChange: (e) => setGerente1Telefono(e.target.value),
										placeholder: "Teléfono",
										className: "w-full px-2 py-1 bg-slate-900 border border-slate-700 focus:border-amber-500 rounded text-xs text-slate-100 focus:outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 275,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[9px] font-bold text-slate-500 uppercase mb-0.5",
										children: "Email"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 284,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "email",
										value: gerente1Email,
										onChange: (e) => setGerente1Email(e.target.value),
										placeholder: "Email",
										className: "w-full px-2 py-1 bg-slate-900 border border-slate-700 focus:border-amber-500 rounded text-xs text-slate-100 focus:outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 285,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 283,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 262,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 260,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border-t border-slate-800 pt-3 mt-3",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] text-sky-400 font-bold uppercase tracking-wider block mb-2",
								children: "Contacto Gerente Secundario"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 297,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[9px] font-bold text-slate-500 uppercase mb-0.5",
										children: "Nombre"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 300,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: gerente2Nombre,
										onChange: (e) => setGerente2Nombre(e.target.value),
										placeholder: "Nombre",
										className: "w-full px-2 py-1 bg-slate-900 border border-slate-700 focus:border-amber-500 rounded text-xs text-slate-100 focus:outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 301,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 299,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[9px] font-bold text-slate-500 uppercase mb-0.5",
										children: "Teléfono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 310,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: gerente2Telefono,
										onChange: (e) => setGerente2Telefono(e.target.value),
										placeholder: "Teléfono",
										className: "w-full px-2 py-1 bg-slate-900 border border-slate-700 focus:border-amber-500 rounded text-xs text-slate-100 focus:outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 311,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 309,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[9px] font-bold text-slate-500 uppercase mb-0.5",
										children: "Email"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 320,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "email",
										value: gerente2Email,
										onChange: (e) => setGerente2Email(e.target.value),
										placeholder: "Email",
										className: "w-full px-2 py-1 bg-slate-900 border border-slate-700 focus:border-amber-500 rounded text-xs text-slate-100 focus:outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 321,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 319,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 298,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 296,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-end gap-3 pt-4 border-t border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setShowModal(false),
								className: "px-4 py-2 bg-slate-900 hover:bg-slate-800 text-xs font-bold rounded-lg text-slate-350 cursor-pointer h-9",
								children: "Cancelar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 333,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-lg text-xs cursor-pointer shadow-md h-9",
								children: "Registrar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 340,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 332,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 216,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 203,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 200,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 5
	}, this);
};
_s(DashboardView, "EEF/MUxg6R+WKmdo5HyHhFUPVrU=", false, function() {
	return [
		useStore,
		useConfirm,
		useNavigate
	];
});
_c = DashboardView;
export default DashboardView;
var _c;
$RefreshReg$(_c, "DashboardView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/views/DashboardView.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/DashboardView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/DashboardView.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/DashboardView.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsbUJBQW1CO0FBQzVCLE9BQU8sY0FBYztBQUNyQixTQUFTLGtCQUFrQjtBQUMzQixPQUFPLHdCQUF3QjtBQUMvQixTQUNFLFFBQ0EsWUFDQSxRQUNBLFdBQ0EsY0FDQSxHQUNBLGNBQ0s7Ozs7QUFHUCxPQUFPLE1BQU0sc0JBQXNCOztDQUNqQyxNQUFNLEVBQUUsTUFBTSxXQUFXLFlBQVksZUFBZSx3QkFBd0IsU0FBUztDQUNyRixNQUFNLEVBQUUsWUFBWSxXQUFXO0NBRS9CLGdCQUFnQjtFQUNkLElBQUkscUJBQXFCO0dBQ3ZCLG9CQUFvQjtFQUN0QjtDQUNGLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQztDQUN4QixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTtDQUN2RCxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQVMsRUFBRTtDQUNqQyxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEVBQUU7Q0FDekQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsRUFBRTtDQUMzRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTtDQUN2RCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEVBQUU7Q0FDM0QsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsRUFBRTtDQUNyRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sV0FBVyxZQUFZO0NBRTdCLE1BQU0sc0JBQXNCLE9BQU8sTUFBTTtFQUN2QyxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLGVBQWUsS0FBSyxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUssQ0FBQyxnQkFBZ0IsS0FBSyxHQUFHO0VBRXRFLE1BQU0sV0FBVztHQUNmLFFBQVEsZUFBZSxLQUFLO0dBQzVCLEtBQUssSUFBSSxLQUFLO0dBQ2QsaUJBQWlCLGdCQUFnQixLQUFLO0dBQ3RDLGdCQUFnQixlQUFlLEtBQUssS0FBSztHQUN6QyxrQkFBa0IsaUJBQWlCLEtBQUssS0FBSztHQUM3QyxlQUFlLGNBQWMsS0FBSyxLQUFLO0dBQ3ZDLGdCQUFnQixlQUFlLEtBQUssS0FBSztHQUN6QyxrQkFBa0IsaUJBQWlCLEtBQUssS0FBSztHQUM3QyxlQUFlLGNBQWMsS0FBSyxLQUFLO0VBQ3pDLENBQUM7RUFFRCxrQkFBa0IsRUFBRTtFQUNwQixPQUFPLEVBQUU7RUFDVCxtQkFBbUIsRUFBRTtFQUNyQixrQkFBa0IsRUFBRTtFQUNwQixvQkFBb0IsRUFBRTtFQUN0QixpQkFBaUIsRUFBRTtFQUNuQixrQkFBa0IsRUFBRTtFQUNwQixvQkFBb0IsRUFBRTtFQUN0QixpQkFBaUIsRUFBRTtFQUNuQixhQUFhLEtBQUs7Q0FDcEI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FHRSx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFoQjtJQUdFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQsQ0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSx5QkFBMEI7Ozs7Z0JBQUMsOEJBQzlDOzs7OztlQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE4QjtLQUFzRjs7OzthQUM5SDs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztRQUM5QyxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2lCQUNELHdCQUFDLFFBQUQsRUFBUSxXQUFVLHFEQUFzRDs7OztlQUNyRTs7Ozs7Z0JBRUosTUFBTSxTQUFTLFlBQ2Qsd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxJQUFJO09BQ2hDLFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxZQUFELEVBQVksV0FBVSxjQUFlOzs7O2lCQUFDLHNCQUNoQzs7Ozs7Y0FFUDs7Ozs7YUFDRjs7Ozs7O0lBR0wsd0JBQUMsb0JBQUQsQ0FBcUI7Ozs7O1dBSWI7S0FDTixNQUFNLG9CQUFvQixVQUFVLFFBQVEsTUFBTTtNQUNoRCxJQUFJLE1BQU0sU0FBUyxVQUFVO09BQzNCLE9BQU8sRUFBRSxPQUFPLEtBQUs7TUFDdkI7TUFDQSxPQUFPLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQyxTQUFTLFlBQVksWUFBWSxDQUFDO0tBQ2xFLENBQUM7S0FFRCxJQUFJLGtCQUFrQixTQUFTLEdBQUc7TUFDaEMsT0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixrQkFBa0IsS0FBSyxZQUN0Qix3QkFBQyxPQUFEO1FBRUUsZUFBZSxTQUFTLFlBQVksUUFBUSxJQUFJO1FBQ2hELFdBQVU7a0JBSFosQ0FLRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHNEQUF1RDs7Ozs7U0FDdEU7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWCxRQUFRO1VBQ1A7Ozs7b0JBQ0osd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWIsRUFDSSxRQUFRLHVCQUF1QixDQUFDLEVBQUMsQ0FBRSxVQUFVLFFBQVEsYUFBYSxDQUFDLEVBQUMsQ0FBRSxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUUsdUJBQXVCLENBQUMsRUFBQyxDQUFFLFFBQVEsQ0FBQyxHQUFFLHNCQUN6STs7Ozs7a0JBQ0E7Ozs7O2lCQUNGOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNHLE1BQU0sU0FBUyxZQUNkLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsU0FBUyxPQUFPLE1BQU07V0FDcEIsRUFBRSxnQkFBZ0I7V0FDbEIsTUFBTSxLQUFLLE1BQU0sUUFBUTtZQUN2QixPQUFPO1lBQ1AsU0FBUyxvREFBb0QsUUFBUSxPQUFPO1lBQzVFLE1BQU07WUFDTixhQUFhO1dBQ2YsQ0FBQztXQUNELElBQUksSUFBSTtZQUNOLGNBQWMsUUFBUSxFQUFFO1dBQzFCO1VBQ0Y7VUFDQSxXQUFVO1VBQ1YsT0FBTTtvQkFFTix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztTQUN2Qjs7OzttQkFFVix3QkFBQyxjQUFELEVBQWMsV0FBVSxzRUFBdUU7Ozs7aUJBQzVGOzs7OztnQkFDRjtVQTFDRSxRQUFROzs7O2NBMENWLENBQ047TUFDRTs7Ozs7S0FFVDtLQUVBLElBQUksWUFBWSxLQUFLLE1BQU0sSUFBSTtNQUM3QixPQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsaURBQWtEOzs7OztRQUNwRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUM7UUFBOEI7Ozs7O1FBQy9FLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQXVEO1VBQWlEO1VBQVk7U0FBSzs7Ozs7O09BQ3RIOzs7Ozs7S0FFVDtLQUVBLE9BQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxtQ0FBb0M7Ozs7O09BQ3RELHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFtQztPQUErQjs7Ozs7T0FDaEYsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQTBDO09BQWlHOzs7OztPQUN4Six3QkFBQyxVQUFEO1FBQ0UsZUFBZSxhQUFhLElBQUk7UUFDaEMsV0FBVTtrQkFGWixDQUlFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLGNBQWU7Ozs7a0JBQUMsc0JBQ2hDOzs7Ozs7TUFDTDs7Ozs7O0lBRVQsRUFBQyxDQUFFO0dBQ0M7Ozs7O1lBR0wsYUFDQyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBb0YsZUFBZSxhQUFhLEtBQUs7R0FBSTs7OzthQUV4SSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUE0RDtLQUV0RTs7OztlQUNKLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGFBQWEsS0FBSztNQUNqQyxXQUFVO2dCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0tBQ2xCOzs7O2FBQ0w7Ozs7O2NBRUwsd0JBQUMsUUFBRDtLQUFNLFVBQVU7S0FBcUIsV0FBVTtlQUEvQztNQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBNEU7TUFFdEY7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTDtPQUNBLE9BQU87T0FDUCxXQUFXLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxLQUFLO09BQ2pELGFBQVk7T0FDWixXQUFVO01BQ1g7Ozs7Y0FDRTs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEU7T0FFdEY7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTDtRQUNBLE9BQU87UUFDUCxXQUFXLE1BQU0sT0FBTyxFQUFFLE9BQU8sS0FBSztRQUN0QyxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7aUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0RTtPQUV0Rjs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMO1FBQ0EsT0FBTztRQUNQLFdBQVcsTUFBTSxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7UUFDbEQsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7O2VBQ0Y7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXlFO09BQWdDOzs7O2lCQUN6SCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBNkQ7U0FBYTs7OzttQkFDM0Ysd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLGtCQUFrQixFQUFFLE9BQU8sS0FBSztVQUNqRCxhQUFZO1VBQ1osV0FBVTtTQUNYOzs7O2lCQUNFOzs7OztTQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBNkQ7U0FBZTs7OzttQkFDN0Ysd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLG9CQUFvQixFQUFFLE9BQU8sS0FBSztVQUNuRCxhQUFZO1VBQ1osV0FBVTtTQUNYOzs7O2lCQUNFOzs7OztTQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBNkQ7U0FBWTs7OzttQkFDMUYsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztVQUNoRCxhQUFZO1VBQ1osV0FBVTtTQUNYOzs7O2lCQUNFOzs7OztRQUNGOzs7OztlQUNGOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF5RTtPQUFpQzs7OztpQkFDMUgsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTZEO1NBQWE7Ozs7bUJBQzNGLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7VUFDakQsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7U0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTZEO1NBQWU7Ozs7bUJBQzdGLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSxvQkFBb0IsRUFBRSxPQUFPLEtBQUs7VUFDbkQsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7U0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTZEO1NBQVk7Ozs7bUJBQzFGLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7VUFDaEQsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7UUFDRjs7Ozs7ZUFDRjs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsYUFBYSxLQUFLO1FBQ2pDLFdBQVU7a0JBQ1g7T0FFTzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFdBQVU7a0JBQ1g7T0FFTzs7OztlQUNMOzs7Ozs7S0FDRDs7Ozs7WUFDSDs7Ozs7V0FDRjs7Ozs7VUFHSjs7Ozs7O0FBRVQ7Ozs7Ozs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkVmlldy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHVzZVN0b3JlIGZyb20gJy4uL3N0b3JlL3VzZVN0b3JlJztcbmltcG9ydCB7IHVzZUNvbmZpcm0gfSBmcm9tICcuLi9jb250ZXh0L0NvbmZpcm1Db250ZXh0JztcbmltcG9ydCBOb3RpZmljYXRpb25CdXR0b24gZnJvbSAnLi4vY29tcG9uZW50cy9Ob3RpZmljYXRpb25CdXR0b24nO1xuaW1wb3J0IHsgXG4gIEZvbGRlciwgXG4gIEZvbGRlclBsdXMsIFxuICBUcmFzaDIsIFxuICBCcmllZmNhc2UsIFxuICBDaGV2cm9uUmlnaHQsIFxuICBYLCBcbiAgU2VhcmNoIFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5cbmV4cG9ydCBjb25zdCBEYXNoYm9hcmRWaWV3ID0gKCkgPT4ge1xuICBjb25zdCB7IHVzZXIsIGNvbXBhbmllcywgYWRkQ29tcGFueSwgZGVsZXRlQ29tcGFueSwgY2FyZ2FyRGF0b3NTZXJ2aWRvciB9ID0gdXNlU3RvcmUoKTtcbiAgY29uc3QgeyBjb25maXJtIH0gPSB1c2VDb25maXJtKCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoY2FyZ2FyRGF0b3NTZXJ2aWRvcikge1xuICAgICAgY2FyZ2FyRGF0b3NTZXJ2aWRvcigpO1xuICAgIH1cbiAgfSwgW2NhcmdhckRhdG9zU2Vydmlkb3JdKTtcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW25ld0NvbXBhbnlOYW1lLCBzZXROZXdDb21wYW55TmFtZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtyaWYsIHNldFJpZl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtkaXJlY2Npb25GaXNjYWwsIHNldERpcmVjY2lvbkZpc2NhbF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtnZXJlbnRlMU5vbWJyZSwgc2V0R2VyZW50ZTFOb21icmVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZ2VyZW50ZTFUZWxlZm9ubywgc2V0R2VyZW50ZTFUZWxlZm9ub10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtnZXJlbnRlMUVtYWlsLCBzZXRHZXJlbnRlMUVtYWlsXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2dlcmVudGUyTm9tYnJlLCBzZXRHZXJlbnRlMk5vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtnZXJlbnRlMlRlbGVmb25vLCBzZXRHZXJlbnRlMlRlbGVmb25vXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2dlcmVudGUyRW1haWwsIHNldEdlcmVudGUyRW1haWxdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUNvbXBhbnkgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIW5ld0NvbXBhbnlOYW1lLnRyaW0oKSB8fCAhcmlmLnRyaW0oKSB8fCAhZGlyZWNjaW9uRmlzY2FsLnRyaW0oKSkgcmV0dXJuO1xuXG4gICAgYXdhaXQgYWRkQ29tcGFueSh7XG4gICAgICBub21icmU6IG5ld0NvbXBhbnlOYW1lLnRyaW0oKSxcbiAgICAgIHJpZjogcmlmLnRyaW0oKSxcbiAgICAgIGRpcmVjY2lvbkZpc2NhbDogZGlyZWNjaW9uRmlzY2FsLnRyaW0oKSxcbiAgICAgIGdlcmVudGUxTm9tYnJlOiBnZXJlbnRlMU5vbWJyZS50cmltKCkgfHwgbnVsbCxcbiAgICAgIGdlcmVudGUxVGVsZWZvbm86IGdlcmVudGUxVGVsZWZvbm8udHJpbSgpIHx8IG51bGwsXG4gICAgICBnZXJlbnRlMUVtYWlsOiBnZXJlbnRlMUVtYWlsLnRyaW0oKSB8fCBudWxsLFxuICAgICAgZ2VyZW50ZTJOb21icmU6IGdlcmVudGUyTm9tYnJlLnRyaW0oKSB8fCBudWxsLFxuICAgICAgZ2VyZW50ZTJUZWxlZm9ubzogZ2VyZW50ZTJUZWxlZm9uby50cmltKCkgfHwgbnVsbCxcbiAgICAgIGdlcmVudGUyRW1haWw6IGdlcmVudGUyRW1haWwudHJpbSgpIHx8IG51bGxcbiAgICB9KTtcblxuICAgIHNldE5ld0NvbXBhbnlOYW1lKCcnKTtcbiAgICBzZXRSaWYoJycpO1xuICAgIHNldERpcmVjY2lvbkZpc2NhbCgnJyk7XG4gICAgc2V0R2VyZW50ZTFOb21icmUoJycpO1xuICAgIHNldEdlcmVudGUxVGVsZWZvbm8oJycpO1xuICAgIHNldEdlcmVudGUxRW1haWwoJycpO1xuICAgIHNldEdlcmVudGUyTm9tYnJlKCcnKTtcbiAgICBzZXRHZXJlbnRlMlRlbGVmb25vKCcnKTtcbiAgICBzZXRHZXJlbnRlMkVtYWlsKCcnKTtcbiAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wgYW50aWFsaWFzZWRcIj5cbiAgICAgIFxuICAgICAgey8qIE1haW4gQ29udGFpbmVyICovfVxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG1heC13LTd4bCB3LWZ1bGwgbXgtYXV0byBweC02IHB5LTggc3BhY2UteS02XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogRGFzaGJvYXJkIFRpdGxlIC8gQWN0aW9uICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0cmV0Y2ggc206aXRlbXMtY2VudGVyIGdhcC00IHBiLTYgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMC84MFwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTEwMCB0cmFja2luZy10aWdodCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8QnJpZWZjYXNlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci01MDBcIiAvPiBNaXMgRW1wcmVzYXMgSW5zcGVjY2lvbmFkYXNcbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTFcIj5TZWxlY2Npb25hIHVuYSBlbXByZXNhIHBhcmEgZ2VzdGlvbmFyIHN1cyB0YWJsZXJvcyBlbMOpY3RyaWNvcyBvIHJlZ2lzdHJhIHVuYSBudWV2YS48L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBzbTpmbGV4LW5vd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTMganVzdGlmeS1lbmQgdy1mdWxsIHNtOnctYXV0b1wiPlxuICAgICAgICAgICAgey8qIEJ1c2NhZG9yIGRlIEVtcHJlc2FzICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbnB1dC1zZWFyY2gtY29udGFpbmVyIHctZnVsbCBzbTp3LTY0XCI+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgZW1wcmVzYS4uLlwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtc2VhcmNoXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTQuNSBoLTQuNSBhYnNvbHV0ZSBsZWZ0LTMuNSB0b3AtMyB0ZXh0LXNsYXRlLTUwMFwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge3VzZXI/LnJvbGUgIT09ICdDTElFTlQnICYmIChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNb2RhbCh0cnVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1hbWJlci00MDAgYWN0aXZlOnNjYWxlLTk4IHRyYW5zaXRpb24tYWxsIHB4LTQgcHktMi41IHJvdW5kZWQtbGcgZmxleCBmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgaC0xMCB3aGl0ZXNwYWNlLW5vd3JhcCB3LWZ1bGwgc206dy1hdXRvIGN1cnNvci1wb2ludGVyIHRleHQteHNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPEZvbGRlclBsdXMgY2xhc3NOYW1lPVwidy00LjUgaC00LjVcIiAvPiArIFJlZ2lzdHJhciBFbXByZXNhXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFBhbmVsIGRlIE5vdGlmaWNhY2lvbmVzIFB1c2ggTmF0aXZhcyBQV0EgKi99XG4gICAgICAgIDxOb3RpZmljYXRpb25CdXR0b24gLz5cblxuXG4gICAgICAgIHsvKiBFbXByZXNhcyBGb2xkZXIgR3JpZCAqL31cbiAgICAgICAgeygoKSA9PiB7XG4gICAgICAgICAgY29uc3QgZmlsdGVyZWRDb21wYW5pZXMgPSBjb21wYW5pZXMuZmlsdGVyKChjKSA9PiB7XG4gICAgICAgICAgICBpZiAodXNlcj8ucm9sZSA9PT0gJ0NMSUVOVCcpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGMuaWQgPT09IHVzZXIuY29tcGFueUlkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGMubm9tYnJlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSk7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpZiAoZmlsdGVyZWRDb21wYW5pZXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkQ29tcGFuaWVzLm1hcCgoY29tcGFueSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBrZXk9e2NvbXBhbnkuaWR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvZW1wcmVzYS8ke2NvbXBhbnkuaWR9YCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItc2xhdGUtNzAwIHAtNSByb3VuZGVkLTJ4bCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCBob3Zlcjp0cmFuc2xhdGUteS1bLTJweF0gZ3JvdXBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG1pbi13LTAgZmxleC0xIG1yLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1hbWJlci01MDAvMTAgdGV4dC1hbWJlci01MDAgcm91bmRlZC14bCBncm91cC1ob3ZlcjpiZy1hbWJlci01MDAgZ3JvdXAtaG92ZXI6dGV4dC1zbGF0ZS05NTAgdHJhbnNpdGlvbi1jb2xvcnMgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb2xkZXIgY2xhc3NOYW1lPVwidy04IGgtOCBmaWxsLXRyYW5zcGFyZW50IGdyb3VwLWhvdmVyOmZpbGwtc2xhdGUtOTUwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgZ3JvdXAtaG92ZXI6dGV4dC1hbWJlci00MDAgdHJhbnNpdGlvbi1jb2xvcnMgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbXBhbnkubm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIG10LTEgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhjb21wYW55LmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgW10pLmxlbmd0aCArIChjb21wYW55LnByb3llY3RvcyB8fCBbXSkucmVkdWNlKChhY2MsIHApID0+IGFjYyArIChwLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgW10pLmxlbmd0aCwgMCl9IEVxdWlwb3MgUmVnaXN0cmFkb3NcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHt1c2VyPy5yb2xlICE9PSAnQ0xJRU5UJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgb2sgPSBhd2FpdCBjb25maXJtKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnRWxpbWluYXIgRW1wcmVzYScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBgwr9Fc3TDoXMgc2VndXJvIGRlIHF1ZSBkZXNlYXMgZWxpbWluYXIgbGEgZW1wcmVzYSBcIiR7Y29tcGFueS5ub21icmV9XCIgeSB0b2RvcyBzdXMgdGFibGVyb3MgeSBwcm95ZWN0b3MgZW4gY2FzY2FkYT9gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2RhbmdlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25maXJtVGV4dDogJ0VsaW1pbmFyIEVtcHJlc2EnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9rKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVDb21wYW55KGNvbXBhbnkuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLXNsYXRlLTkwMC85MCBob3ZlcjpiZy1yZWQtOTUwLzQwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtcmVkLTQwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItcmVkLTkwMC82MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIG9wYWNpdHktMTAwIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRWxpbWluYXIgRW1wcmVzYVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTYwMCBncm91cC1ob3Zlcjp0ZXh0LXNsYXRlLTM1MCB0cmFuc2l0aW9uLWNvbG9yc1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoc2VhcmNoUXVlcnkudHJpbSgpICE9PSAnJykge1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEyIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCB0ZXh0LWNlbnRlciBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctMTIgaC0xMiB0ZXh0LXNsYXRlLTcwMCBteC1hdXRvIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMFwiPk5vIHNlIGVuY29udHJhcm9uIGVtcHJlc2FzPC9oMz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIG1heC13LXNtIG14LWF1dG9cIj5ObyBoYXkgcmVnaXN0cm9zIHF1ZSBjb2luY2lkYW4gY29uIGxhIGLDunNxdWVkYSBcIntzZWFyY2hRdWVyeX1cIi48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEyIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCB0ZXh0LWNlbnRlciBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPEZvbGRlciBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1zbGF0ZS03MDAgbXgtYXV0b1wiIC8+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMFwiPk5vIGhheSBlbXByZXNhcyByZWdpc3RyYWRhczwvaDM+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbWF4LXctc20gbXgtYXV0b1wiPkNvbWllbnphIHJlZ2lzdHJhbmRvIHR1IHByaW1lcmEgZW1wcmVzYSBjb250cmF0YW50ZSBwYXJhIGluc3BlY2Npb25hciBzdXMgdGFibGVyb3MgZWzDqWN0cmljb3MuPC9wPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsKHRydWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGZvbnQtc2VtaWJvbGQgaG92ZXI6YmctYW1iZXItNDAwIGFjdGl2ZTpzY2FsZS05OCB0cmFuc2l0aW9uLWFsbCBweC00IHB5LTIuNSByb3VuZGVkLWxnIGZsZXggZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGgtMTAgd2hpdGVzcGFjZS1ub3dyYXAgbXgtYXV0byBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Rm9sZGVyUGx1cyBjbGFzc05hbWU9XCJ3LTQuNSBoLTQuNVwiIC8+ICsgUmVnaXN0cmFyIEVtcHJlc2FcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApO1xuICAgICAgICB9KSgpfVxuICAgICAgPC9tYWluPlxuXG4gICAgICB7LyogTW9kYWwgTnVldmEgRW1wcmVzYSAqL31cbiAgICAgIHtzaG93TW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctc2xhdGUtOTAwLzYwIGJhY2tkcm9wLWJsdXItc20gYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9IC8+XG4gICAgICAgICAgXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctbGcgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgcC02IG92ZXJmbG93LWhpZGRlbiBhbmltYXRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMjAwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgIFJlZ2lzdHJhciBOdWV2YSBFbXByZXNhXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBob3ZlcjpiZy1zbGF0ZS05MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTUwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNyZWF0ZUNvbXBhbnl9IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS00IG1heC1oLVs3MHZoXSBvdmVyZmxvdy15LWF1dG8gcHItMSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIE5vbWJyZSBkZSBsYSBFbXByZXNhIC8gQ2xpZW50ZVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0NvbXBhbnlOYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdDb21wYW55TmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBGYXJtYXRvZG8gU3VjdXJzYWwgQ2hhY2FvXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQtbGcgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXItc2xhdGUtNjAwIGgtOVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIFJJRlxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyaWZ9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmlmKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gSi0xMjM0NTY3OC05XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC1sZyB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBwbGFjZWhvbGRlci1zbGF0ZS02MDAgaC05XCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIERpcmVjY2nDs24gRmlzY2FsXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RpcmVjY2lvbkZpc2NhbH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREaXJlY2Npb25GaXNjYWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBBdi4gQXJhdXJlLCBTYW4gUm9tw6FuLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC1sZyB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBwbGFjZWhvbGRlci1zbGF0ZS02MDAgaC05XCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBwdC0zIG10LTNcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNreS00MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9jayBtYi0yXCI+Q29udGFjdG8gR2VyZW50ZSBQcmluY2lwYWw8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIG1iLTAuNVwiPk5vbWJyZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z2VyZW50ZTFOb21icmV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRHZXJlbnRlMU5vbWJyZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb21icmVcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0yIHB5LTEgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVs5cHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgbWItMC41XCI+VGVsw6lmb25vPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnZXJlbnRlMVRlbGVmb25vfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0R2VyZW50ZTFUZWxlZm9ubyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUZWzDqWZvbm9cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0yIHB5LTEgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVs5cHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgbWItMC41XCI+RW1haWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnZXJlbnRlMUVtYWlsfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0R2VyZW50ZTFFbWFpbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgcHQtMyBtdC0zXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1za3ktNDAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2sgbWItMlwiPkNvbnRhY3RvIEdlcmVudGUgU2VjdW5kYXJpbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVs5cHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgbWItMC41XCI+Tm9tYnJlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnZXJlbnRlMk5vbWJyZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEdlcmVudGUyTm9tYnJlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWJyZVwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBtYi0wLjVcIj5UZWzDqWZvbm88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dlcmVudGUyVGVsZWZvbm99XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRHZXJlbnRlMlRlbGVmb25vKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlRlbMOpZm9ub1wiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBtYi0wLjVcIj5FbWFpbDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dlcmVudGUyRW1haWx9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRHZXJlbnRlMkVtYWlsKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWxnIHRleHQtc2xhdGUtMzUwIGN1cnNvci1wb2ludGVyIGgtOVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNjAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCByb3VuZGVkLWxnIHRleHQteHMgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kIGgtOVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgUmVnaXN0cmFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IERhc2hib2FyZFZpZXc7XG4iXX0=