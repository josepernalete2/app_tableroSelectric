import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ModalDiagramaUnifilar.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { X, ExternalLink, Info, Zap, Trash2, Link2, Unlink, Plus, Check, Cpu, ShieldAlert, FolderOpen } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f49807c8";
import DiagramaUnifilarBlueprint from "/src/components/DiagramaUnifilarBlueprint.jsx?t=1790792337841";
import SelectorAlimentadorJerarquico from "/src/components/SelectorAlimentadorJerarquico.jsx?t=1790792337841";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalDiagramaUnifilar.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function ModalDiagramaUnifilar({ isOpen, onClose, elementos = [], companyName, projectName = "SISTEMA ELÉCTRICO", proyectoId = null, companyId = null }) {
	_s();
	const navigate = useNavigate();
	const { addElementoUnifilar, updateElementoUnifilar, deleteElementoUnifilar, showToast } = useStore();
	const { confirm } = useConfirm();
	const [selectedNode, setSelectedNode] = useState(null);
	// Estados de edición del nodo seleccionado
	const [editNombre, setEditNombre] = useState("");
	const [editTipo, setEditTipo] = useState("");
	const [editUbicacion, setEditUbicacion] = useState("");
	const [editAlimentadoPor, setEditAlimentadoPor] = useState("");
	const [editKva, setEditKva] = useState("");
	const [editFases, setEditFases] = useState("");
	const [editObservaciones, setEditObservaciones] = useState("");
	// Estados de Modo Conexión
	const [isConnectionMode, setIsConnectionMode] = useState(false);
	const [connectionSource, setConnectionSource] = useState(null);
	// Sincronizar formulario cuando cambia el nodo seleccionado
	useEffect(() => {
		if (selectedNode) {
			setEditNombre(selectedNode.nombre || "");
			setEditTipo(selectedNode.tipoElemento || "TABLERO");
			setEditUbicacion(selectedNode.ubicacion || "");
			setEditAlimentadoPor(selectedNode.alimentadoPor || "");
			setEditKva(selectedNode.datosTecnicos?.kva || selectedNode.datosTecnicos?.potenciaKva || "");
			setEditFases(selectedNode.datosTecnicos?.fases || selectedNode.maxPoles || "");
			setEditObservaciones(selectedNode.observacionesGenerales || "");
		} else {
			resetEditForm();
		}
	}, [selectedNode]);
	// Actualizar la referencia del nodo seleccionado si los elementos cambian (reactividad)
	useEffect(() => {
		if (selectedNode) {
			const updated = elementos.find((el) => el.id === selectedNode.id);
			if (updated) {
				setSelectedNode(updated);
			} else {
				setSelectedNode(null);
			}
		}
	}, [elementos]);
	const resetEditForm = () => {
		setEditNombre("");
		setEditTipo("");
		setEditUbicacion("");
		setEditAlimentadoPor("");
		setEditKva("");
		setEditFases("");
		setEditObservaciones("");
	};
	// Catálogo de símbolos eléctricos para el panel izquierdo
	const catalogOfSymbols = [
		{
			type: "TABLERO",
			label: "Tablero Eléctrico",
			desc: "Panel de distribución",
			icon: /* @__PURE__ */ _jsxDEV("div", {
				className: "w-5 h-4 border border-slate-400 bg-slate-950 flex items-center justify-center text-[7px]",
				children: "⚡"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 13
			}, this)
		},
		{
			type: "TRANSFORMADOR",
			label: "Transformador",
			desc: "Reductor/Elevador",
			icon: /* @__PURE__ */ _jsxDEV("svg", {
				width: "20",
				height: "20",
				viewBox: "0 0 20 20",
				className: "overflow-visible fill-none stroke-current text-violet-400",
				children: [/* @__PURE__ */ _jsxDEV("circle", {
					cx: "10",
					cy: "7",
					r: "5",
					strokeWidth: "1.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("circle", {
					cx: "10",
					cy: "13",
					r: "5",
					strokeWidth: "1.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 9
			}, this)
		},
		{
			type: "GENERADOR",
			label: "Generador / Planta",
			desc: "Generador auxiliar",
			icon: /* @__PURE__ */ _jsxDEV("div", {
				className: "w-5 h-5 rounded-full border border-amber-500 flex items-center justify-center text-[10px] font-bold text-amber-500 bg-amber-950/20",
				children: "G"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 111,
				columnNumber: 13
			}, this)
		},
		{
			type: "TRANSFER",
			label: "ATS / Transferencia",
			desc: "Conmutación de red",
			icon: /* @__PURE__ */ _jsxDEV("div", {
				className: "w-7 h-4 border border-emerald-500 rounded text-[7px] font-black text-center text-emerald-400 bg-emerald-950/20 leading-tight",
				children: "ATS"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 13
			}, this)
		},
		{
			type: "PUESTA_TIERRA",
			label: "Puesta a Tierra",
			desc: "Malla / Electrodo",
			icon: /* @__PURE__ */ _jsxDEV("svg", {
				width: "18",
				height: "18",
				viewBox: "0 0 20 20",
				className: "stroke-current text-teal-400",
				fill: "none",
				children: [
					/* @__PURE__ */ _jsxDEV("line", {
						x1: "10",
						y1: "2",
						x2: "10",
						y2: "12",
						strokeWidth: "2"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("line", {
						x1: "4",
						y1: "12",
						x2: "16",
						y2: "12",
						strokeWidth: "2"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("line", {
						x1: "6",
						y1: "15",
						x2: "14",
						y2: "15",
						strokeWidth: "1.5"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("line", {
						x1: "8",
						y1: "18",
						x2: "12",
						y2: "18",
						strokeWidth: "1"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 9
			}, this)
		},
		{
			type: "SUBESTACION",
			label: "Celda / Subestación",
			desc: "Módulo de maniobra",
			icon: /* @__PURE__ */ _jsxDEV(Cpu, { className: "w-4 h-4 text-purple-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 136,
				columnNumber: 13
			}, this)
		},
		{
			type: "OTRO",
			label: "Carga / Banco Cond.",
			desc: "Otros componentes",
			icon: /* @__PURE__ */ _jsxDEV(Info, { className: "w-4 h-4 text-sky-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 142,
				columnNumber: 13
			}, this)
		}
	];
	// Agregar nuevo símbolo al lienzo
	const handleAddSymbol = async (type) => {
		const defaultPositions = [
			{
				x: 250,
				y: 150
			},
			{
				x: 350,
				y: 150
			},
			{
				x: 450,
				y: 150
			},
			{
				x: 550,
				y: 150
			},
			{
				x: 250,
				y: 300
			},
			{
				x: 450,
				y: 300
			}
		];
		// Evitar solapamientos iniciales burdos
		const randomPos = defaultPositions[Math.floor(Math.random() * defaultPositions.length)];
		const count = elementos.filter((el) => el.tipoElemento === type).length + 1;
		const defaultNames = {
			TABLERO: `Tablero Distribución ${count}`,
			TRANSFORMADOR: `Transformador Principal ${count}`,
			GENERADOR: `Generador Emergencia ${count}`,
			TRANSFER: `ATS Transferencia ${count}`,
			PUESTA_TIERRA: `Malla de Tierra ${count}`,
			SUBESTACION: `Celda Subestación ${count}`,
			OTRO: `Equipo Especial ${count}`
		};
		const targetCompanyId = companyId || (elementos.length > 0 ? elementos[0].empresaId || elementos[0].companyId : null);
		const payload = {
			nombre: defaultNames[type] || `Equipo ${type} ${count}`,
			tipoElemento: type,
			ubicacion: "Sala Eléctrica",
			alimentadoPor: "",
			observacionesGenerales: "",
			companyId: targetCompanyId,
			proyectoId,
			datosTecnicos: {
				positionX: randomPos.x,
				positionY: randomPos.y,
				kva: type === "TRANSFORMADOR" || type === "GENERADOR" ? "75" : "",
				fases: "3"
			}
		};
		const res = await addElementoUnifilar(proyectoId, payload);
		if (res && res.success) {
			showToast(`${type} agregado al diagrama correctamente.`, "success");
			setSelectedNode(res.elemento);
		} else {
			showToast(res?.error || "Error al agregar elemento.", "error");
		}
	};
	// Guardar propiedades editadas
	const handleSaveProperties = async (e) => {
		if (e) e.preventDefault();
		if (!selectedNode) return;
		const updated = {
			nombre: editNombre.trim(),
			tipoElemento: editTipo,
			ubicacion: editUbicacion.trim(),
			alimentadoPor: editAlimentadoPor,
			observacionesGenerales: editObservaciones.trim(),
			datosTecnicos: {
				...selectedNode.datosTecnicos,
				kva: editKva.trim(),
				fases: editFases.trim(),
				positionX: selectedNode.datosTecnicos?.positionX || 300,
				positionY: selectedNode.datosTecnicos?.positionY || 200
			}
		};
		await updateElementoUnifilar(proyectoId || selectedNode.proyectoId, selectedNode.id, updated);
		showToast("Propiedades del elemento actualizadas.", "success");
	};
	// Obtener elementos aguas abajo que quedarán huérfanos si se elimina el nodo
	const getDownstreamOrphans = (node) => {
		if (!node) return [];
		return elementos.filter((el) => {
			if (el.id === node.id) return false;
			const matchName = el.alimentadoPor && el.alimentadoPor.toLowerCase().trim() === (node.nombre || "").toLowerCase().trim();
			const matchId = el.alimentadoPor && (el.alimentadoPor.includes(node.id) || el.alimentadoPor === node.id);
			const matchDirectId = el.alimentadoPorId === node.id || el.origenId === node.id;
			return matchName || matchId || matchDirectId;
		});
	};
	// Eliminar elemento del diagrama con advertencia de huérfanos
	const handleDeleteElement = async () => {
		if (!selectedNode) return;
		const orphans = getDownstreamOrphans(selectedNode);
		let confirmMsg = `¿Estás seguro de que deseas eliminar permanentemente el equipo "${selectedNode.nombre}" (${selectedNode.id})?`;
		if (orphans.length > 0) {
			const orphanList = orphans.map((o) => `• ${o.nombre} (${o.tipoElemento || "EQUIPO"})`).join("\n");
			confirmMsg += `\n\n⚠️ ADVERTENCIA DE DEPENDENCIAS AGUAS ABAJO:\nLos siguientes ${orphans.length} equipo(s) quedarán huérfanos (sin alimentación directa):\n${orphanList}\n\nSe desvincularán automáticamente de forma segura.`;
		}
		const ok = await confirm({
			title: "Eliminar Equipo del Diagrama",
			message: confirmMsg,
			type: "danger",
			confirmText: "Eliminar Equipo"
		});
		if (ok) {
			const idToDelete = selectedNode.id;
			// Desconectar huérfanos antes de eliminar para mantener coherencia en cascada
			for (const el of elementos) {
				if (el.alimentadoPor === selectedNode.nombre || el.alimentadoPor === selectedNode.id || el.alimentadoPor?.includes(selectedNode.id) || el.alimentadoPorId === selectedNode.id) {
					await updateElementoUnifilar(proyectoId || el.proyectoId, el.id, {
						alimentadoPor: "",
						alimentadoPorId: null
					});
				}
			}
			setSelectedNode(null);
			await deleteElementoUnifilar(proyectoId || selectedNode.proyectoId, idToDelete);
			showToast(`Equipo "${selectedNode.nombre}" eliminado del diagrama.`, "info");
		}
	};
	// Atajo de teclado: Tecla Delete / Backspace para borrar nodo seleccionado
	useEffect(() => {
		if (!isOpen || !selectedNode) return;
		const handleKeyDown = (e) => {
			const activeTag = document.activeElement?.tagName?.toLowerCase();
			if (activeTag === "input" || activeTag === "textarea" || activeTag === "select") return;
			if (e.key === "Delete" || e.key === "Backspace") {
				e.preventDefault();
				handleDeleteElement();
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [
		isOpen,
		selectedNode,
		elementos
	]);
	// Desconectar elemento seleccionado
	const handleDisconnectElement = async () => {
		if (!selectedNode) return;
		setEditAlimentadoPor("");
		await updateElementoUnifilar(proyectoId || selectedNode.proyectoId, selectedNode.id, { alimentadoPor: "" });
		showToast("Conexión de alimentación removida.", "info");
	};
	// Manejar click en nodo del lienzo
	const handleNodeClick = (node) => {
		if (isConnectionMode) {
			// Flujo de Conexión
			if (!connectionSource) {
				// Seleccionar origen
				setConnectionSource(node);
				showToast(`Origen seleccionado: ${node.nombre}. Haz clic en el equipo destino para conectarlo.`, "info");
			} else {
				// Seleccionar destino
				if (connectionSource.id === node.id) {
					showToast("No puedes conectar un equipo consigo mismo.", "error");
					return;
				}
				// El destino es alimentado por el origen
				updateElementoUnifilar(proyectoId || node.proyectoId, node.id, { alimentadoPor: connectionSource.nombre });
				showToast(`Conexión establecida: ${connectionSource.nombre} ➔ ${node.nombre}`, "success");
				// Resetear modo conexión
				setIsConnectionMode(false);
				setConnectionSource(null);
			}
		} else {
			setSelectedNode(node);
		}
	};
	// Lista de posibles alimentadores (excluye al nodo mismo para evitar bucles)
	const potentialFeeders = elementos.filter((el) => selectedNode && el.id !== selectedNode.id);
	if (!isOpen) return null;
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 print:hidden",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "absolute inset-0 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200",
			onClick: onClose
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 342,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-7xl h-[95vh] bg-slate-900/90 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-between items-center p-4 border-b border-slate-800 bg-slate-950/45 shrink-0 select-none",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "p-2 bg-amber-955 rounded-xl border border-amber-800/40 animate-pulse",
							children: /* @__PURE__ */ _jsxDEV(Zap, {
								className: "w-5 h-5 text-amber-500 animate-bounce",
								style: { animationDuration: "3s" }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 351,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 350,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-black uppercase tracking-wider text-slate-100 font-mono flex items-center gap-2",
							children: ["Editor de Diagrama Unifilar CAD ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] text-amber-500 bg-amber-950/60 border border-amber-900 px-2 py-0.5 rounded-full font-sans lowercase",
								children: "interactivo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 355,
								columnNumber: 51
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 354,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[10px] text-slate-455 font-sans",
							children: [
								companyName,
								" — ",
								projectName,
								" • Arrastra equipos, haz doble clic para editar o usa el trazador de conexiones."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 353,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 349,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2.5 no-print",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setIsConnectionMode(!isConnectionMode);
									setConnectionSource(null);
									if (!isConnectionMode) {
										showToast("Modo de conexión activado. Haz clic en el equipo alimentador (origen).", "info");
									}
								},
								className: `px-3 py-1.5 border text-xs font-black rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-md ${isConnectionMode ? "bg-amber-500 border-amber-400 text-slate-950 hover:bg-amber-400 animate-pulse" : "bg-slate-950 border-slate-800 text-slate-350 hover:text-white hover:border-slate-700"}`,
								children: [/* @__PURE__ */ _jsxDEV(Link2, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 379,
									columnNumber: 17
								}, this), isConnectionMode ? "Conectando..." : "Trazar Conexión"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 365,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => window.print(),
								className: "px-3 py-1.5 bg-slate-950 border border-slate-800 text-slate-355 hover:text-white rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-md hover:border-slate-700",
								children: "Imprimir Plano"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 383,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: onClose,
								className: "p-1.5 hover:bg-slate-855 border border-slate-800 hover:border-slate-700 rounded-xl text-slate-400 hover:text-white transition-colors cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 394,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 390,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 363,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 348,
					columnNumber: 11
				}, this),
				isConnectionMode && /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-amber-500 text-slate-950 font-bold px-5 py-2.5 text-xs text-center flex items-center justify-center gap-2.5 shrink-0 font-mono animate-slideDown select-none",
					children: [
						/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 fill-current animate-bounce" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 402,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: connectionSource ? `[1/2] Origen seleccionado: ${connectionSource.nombre}. Ahora haz clic en el equipo de DESTINO para conectarlo.` : "MODO CONEXIÓN ACTIVO: Haz clic en el equipo de ORIGEN (alimentador principal / tablero de distribución)." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 403,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setIsConnectionMode(false);
								setConnectionSource(null);
							},
							className: "ml-4 px-2 py-0.5 border border-slate-950/40 rounded text-[9px] hover:bg-slate-950 hover:text-amber-500 font-bold transition-all uppercase",
							children: "Cancelar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 408,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 401,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 flex overflow-hidden min-h-0",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-56 bg-slate-955/60 p-4 border-r border-slate-850/60 flex flex-col space-y-4 select-none shrink-0 no-print",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono mb-2",
									children: "Equipos & Símbolos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 426,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[9.5px] text-slate-450 leading-relaxed",
									children: "Haz clic en cualquier símbolo para insertarlo en el plano interactivo."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 427,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 425,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 flex-1 overflow-y-auto pr-1",
									children: catalogOfSymbols.map((sym) => /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleAddSymbol(sym.type),
										className: "w-full p-2.5 bg-slate-900/40 hover:bg-slate-800/80 active:scale-98 border border-slate-850 hover:border-slate-700 rounded-xl flex items-center gap-3 transition-all text-left text-xs group cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-9 h-9 shrink-0 flex items-center justify-center bg-slate-950 rounded-xl text-slate-455 group-hover:text-amber-500 group-hover:bg-slate-900 border border-slate-855 transition-all shadow-inner",
											children: sym.icon
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 439,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "font-bold text-slate-200 group-hover:text-white transition-colors truncate",
												children: sym.label
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 443,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "text-[9px] text-slate-500 truncate",
												children: sym.desc
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 444,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 442,
											columnNumber: 21
										}, this)]
									}, sym.type, true, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-4 border-t border-slate-850/60 text-[9px] text-slate-500 leading-normal font-sans",
									children: [
										"💡 ",
										/* @__PURE__ */ _jsxDEV("strong", { children: "Consejo:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 451,
											columnNumber: 20
										}, this),
										" Arrastra libremente los símbolos una vez colocados en el lienzo para organizar el diagrama."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 450,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 424,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 overflow-hidden relative flex flex-col bg-slate-950",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 overflow-hidden",
								children: /* @__PURE__ */ _jsxDEV(DiagramaUnifilarBlueprint, {
									elementos,
									companyName,
									projectName,
									interactive: true,
									selectedNodeId: selectedNode?.id,
									onNodeSelect: handleNodeClick
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 458,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 457,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 456,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-80 bg-slate-955/60 p-5 overflow-y-auto shrink-0 flex flex-col justify-between border-l border-slate-850/60 no-print select-none",
							children: selectedNode ? /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-5 flex-1 flex flex-col justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-5",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1.5 pb-4 border-b border-slate-850",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between items-start",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[9px] font-mono font-bold text-slate-550 uppercase tracking-widest",
													children: "FICHA TÉCNICA"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 477,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[9.5px] font-mono font-bold px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-amber-500 uppercase",
													children: selectedNode.tipoElemento
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 478,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 476,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("h4", {
												className: "text-sm font-black text-slate-100 tracking-wide font-mono uppercase truncate",
												children: selectedNode.nombre
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 482,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[9.5px] font-mono font-bold text-slate-500",
												children: ["ID: ", selectedNode.id]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 483,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 475,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("form", {
										onSubmit: handleSaveProperties,
										className: "space-y-4 text-xs font-mono",
										children: [
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-450 font-bold mb-1 uppercase text-[9px] tracking-wider",
												children: "Nombre del Equipo"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 489,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: editNombre,
												onChange: (e) => setEditNombre(e.target.value),
												placeholder: "Ej. Tablero General A",
												className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-sans"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 490,
												columnNumber: 25
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 488,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-450 font-bold mb-1 uppercase text-[9px] tracking-wider",
												children: "Tipo de Equipo"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 500,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("select", {
												value: editTipo,
												onChange: (e) => setEditTipo(e.target.value),
												className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-sans cursor-pointer",
												children: [
													/* @__PURE__ */ _jsxDEV("option", {
														value: "TABLERO",
														children: "Tablero Eléctrico"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 506,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "TRANSFORMADOR",
														children: "Transformador"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 507,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "GENERADOR",
														children: "Generador / Planta"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 508,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "TRANSFER",
														children: "ATS / Transferencia"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 509,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "PUESTA_TIERRA",
														children: "Puesta a Tierra"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 510,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "SUBESTACION",
														children: "Celda Subestación"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 511,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "OTRO",
														children: "Otro Elemento"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 512,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 501,
												columnNumber: 25
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 499,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-450 font-bold mb-1 uppercase text-[9px] tracking-wider",
												children: "Ubicación Física"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 517,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: editUbicacion,
												onChange: (e) => setEditUbicacion(e.target.value),
												placeholder: "Ej. Cuarto de Bombas",
												className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-sans"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 518,
												columnNumber: 25
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 516,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV(SelectorAlimentadorJerarquico, {
												proyectoId: proyectoId || selectedNode?.proyectoId,
												tableroActualId: selectedNode?.id,
												elementosList: elementos,
												value: editAlimentadoPor,
												onChange: (val) => setEditAlimentadoPor(val),
												label: "Alimentado por (Origen de Flujo)",
												placeholder: "Ninguno (Origen del Sistema)..."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 529,
												columnNumber: 25
											}, this) }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 528,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "grid grid-cols-2 gap-3",
												children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "block text-slate-450 font-bold mb-1 uppercase text-[9px] tracking-wider",
													children: "Capacidad / KVA"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 542,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "text",
													value: editKva,
													onChange: (e) => setEditKva(e.target.value),
													placeholder: "Ej. 150 kVA",
													className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-sans"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 543,
													columnNumber: 27
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 541,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "block text-slate-450 font-bold mb-1 uppercase text-[9px] tracking-wider",
													children: "Fases / Polos"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 552,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "text",
													value: editFases,
													onChange: (e) => setEditFases(e.target.value),
													placeholder: "Ej. 3F / 42P",
													className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-sans"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 553,
													columnNumber: 27
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 551,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 540,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-450 font-bold mb-1 uppercase text-[9px] tracking-wider font-mono",
												children: "Observaciones"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 564,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("textarea", {
												value: editObservaciones,
												onChange: (e) => setEditObservaciones(e.target.value),
												placeholder: "Notas del equipo...",
												rows: "3",
												className: "w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-sans resize-none text-[11px]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 565,
												columnNumber: 25
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 563,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "submit",
												className: "w-full py-2 bg-amber-500 text-slate-950 font-black hover:bg-amber-400 active:scale-98 transition-all rounded-xl cursor-pointer text-center font-sans shadow-md flex items-center justify-center gap-1.5",
												children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 578,
													columnNumber: 25
												}, this), " Guardar Cambios"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 574,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 487,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 473,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2.5 pt-4 border-t border-slate-855 mt-6 shrink-0",
									children: [selectedNode.tipoElemento === "TABLERO" && /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											onClose();
											navigate(`/empresa/${selectedNode.empresaId || companyId}/tablero/${selectedNode.id}`);
										},
										className: "w-full bg-slate-100 text-slate-950 font-black hover:bg-white active:scale-98 transition-all px-4 py-2.5 rounded-xl flex items-center justify-center gap-2 text-xs cursor-pointer shadow-md",
										children: ["Abrir Ficha de Polos ", /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 593,
											columnNumber: 46
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 586,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDeleteElement,
										className: "w-full bg-red-950/20 hover:bg-red-900/30 border border-red-900/40 text-red-400 font-bold transition-all px-4 py-2.5 rounded-xl flex items-center justify-center gap-2 text-xs cursor-pointer shadow-sm",
										title: "Eliminar equipo (Atajo: Tecla Supr / Delete)",
										children: [/* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 602,
											columnNumber: 23
										}, this), " Eliminar Equipo (Supr)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 597,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 584,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 472,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "text-center py-20 space-y-3 flex-1 flex flex-col justify-center items-center",
								children: [/* @__PURE__ */ _jsxDEV(Info, { className: "w-8 h-8 text-slate-700" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 608,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-slate-500 max-w-[200px] font-sans leading-relaxed",
									children: "Haz clic sobre cualquier equipo en el diagrama unifilar para ver o editar sus especificaciones técnicas, cambiar sus conexiones o eliminarlo."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 609,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 607,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 470,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 421,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 345,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 340,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		className: "hidden print:block fixed inset-0 bg-white z-50 w-screen h-screen p-0 m-0",
		children: /* @__PURE__ */ _jsxDEV(DiagramaUnifilarBlueprint, {
			elementos,
			companyName,
			projectName,
			interactive: false
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 623,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 622,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 339,
		columnNumber: 5
	}, this);
}
_s(ModalDiagramaUnifilar, "P0p2hOElULitvijJaSttKTN2tlo=", false, function() {
	return [
		useNavigate,
		useStore,
		useConfirm
	];
});
_c = ModalDiagramaUnifilar;
var _c;
$RefreshReg$(_c, "ModalDiagramaUnifilar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ModalDiagramaUnifilar.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalDiagramaUnifilar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalDiagramaUnifilar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalDiagramaUnifilar.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQ0UsR0FDQSxjQUNBLE1BQ0EsS0FDQSxRQUNBLE9BQ0EsUUFDQSxNQUNBLE9BQ0EsS0FDQSxhQUNBLGtCQUNLO0FBQ1AsU0FBUyxtQkFBbUI7QUFDNUIsT0FBTywrQkFBK0I7QUFDdEMsT0FBTyxtQ0FBbUM7QUFDMUMsT0FBTyxjQUFjO0FBQ3JCLFNBQVMsa0JBQWtCOzs7O0FBRTNCLGVBQWUsU0FBUyxzQkFBc0IsRUFDNUMsUUFDQSxTQUNBLFlBQVksQ0FBQyxHQUNiLGFBQ0EsY0FBYyxxQkFDZCxhQUFhLE1BQ2IsWUFBWSxRQUNYOztDQUNELE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sRUFBRSxxQkFBcUIsd0JBQXdCLHdCQUF3QixjQUFjLFNBQVM7Q0FDcEcsTUFBTSxFQUFFLFlBQVksV0FBVztDQUUvQixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxJQUFJOztDQUdyRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEVBQUU7Q0FDckQsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxFQUFFO0NBQzdELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FDN0MsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxFQUFFOztDQUc3RCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEtBQUs7Q0FDOUQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxJQUFJOztDQUc3RCxnQkFBZ0I7RUFDZCxJQUFJLGNBQWM7R0FDaEIsY0FBYyxhQUFhLFVBQVUsRUFBRTtHQUN2QyxZQUFZLGFBQWEsZ0JBQWdCLFNBQVM7R0FDbEQsaUJBQWlCLGFBQWEsYUFBYSxFQUFFO0dBQzdDLHFCQUFxQixhQUFhLGlCQUFpQixFQUFFO0dBQ3JELFdBQVcsYUFBYSxlQUFlLE9BQU8sYUFBYSxlQUFlLGVBQWUsRUFBRTtHQUMzRixhQUFhLGFBQWEsZUFBZSxTQUFTLGFBQWEsWUFBWSxFQUFFO0dBQzdFLHFCQUFxQixhQUFhLDBCQUEwQixFQUFFO0VBQ2hFLE9BQU87R0FDTCxjQUFjO0VBQ2hCO0NBQ0YsR0FBRyxDQUFDLFlBQVksQ0FBQzs7Q0FHakIsZ0JBQWdCO0VBQ2QsSUFBSSxjQUFjO0dBQ2hCLE1BQU0sVUFBVSxVQUFVLE1BQUssT0FBTSxHQUFHLE9BQU8sYUFBYSxFQUFFO0dBQzlELElBQUksU0FBUztJQUNYLGdCQUFnQixPQUFPO0dBQ3pCLE9BQU87SUFDTCxnQkFBZ0IsSUFBSTtHQUN0QjtFQUNGO0NBQ0YsR0FBRyxDQUFDLFNBQVMsQ0FBQztDQUVkLE1BQU0sc0JBQXNCO0VBQzFCLGNBQWMsRUFBRTtFQUNoQixZQUFZLEVBQUU7RUFDZCxpQkFBaUIsRUFBRTtFQUNuQixxQkFBcUIsRUFBRTtFQUN2QixXQUFXLEVBQUU7RUFDYixhQUFhLEVBQUU7RUFDZixxQkFBcUIsRUFBRTtDQUN6Qjs7Q0FJQSxNQUFNLG1CQUFtQjtFQUN2QjtHQUNFLE1BQU07R0FDTixPQUFPO0dBQ1AsTUFBTTtHQUNOLE1BQU0sd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBMkY7R0FBTTs7Ozs7RUFDeEg7RUFDQTtHQUNFLE1BQU07R0FDTixPQUFPO0dBQ1AsTUFBTTtHQUNOLE1BQ0Usd0JBQUMsT0FBRDtJQUFLLE9BQU07SUFBSyxRQUFPO0lBQUssU0FBUTtJQUFZLFdBQVU7Y0FBMUQsQ0FDRSx3QkFBQyxVQUFEO0tBQVEsSUFBRztLQUFLLElBQUc7S0FBSSxHQUFFO0tBQUksYUFBWTtJQUFPOzs7O2NBQ2hELHdCQUFDLFVBQUQ7S0FBUSxJQUFHO0tBQUssSUFBRztLQUFLLEdBQUU7S0FBSSxhQUFZO0lBQU87Ozs7WUFDOUM7Ozs7OztFQUVUO0VBQ0E7R0FDRSxNQUFNO0dBQ04sT0FBTztHQUNQLE1BQU07R0FDTixNQUFNLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQXFJO0dBQU07Ozs7O0VBQ2xLO0VBQ0E7R0FDRSxNQUFNO0dBQ04sT0FBTztHQUNQLE1BQU07R0FDTixNQUFNLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQStIO0dBQVE7Ozs7O0VBQzlKO0VBQ0E7R0FDRSxNQUFNO0dBQ04sT0FBTztHQUNQLE1BQU07R0FDTixNQUNFLHdCQUFDLE9BQUQ7SUFBSyxPQUFNO0lBQUssUUFBTztJQUFLLFNBQVE7SUFBWSxXQUFVO0lBQStCLE1BQUs7Y0FBOUY7S0FDRSx3QkFBQyxRQUFEO01BQU0sSUFBRztNQUFLLElBQUc7TUFBSSxJQUFHO01BQUssSUFBRztNQUFLLGFBQVk7S0FBSzs7Ozs7S0FDdEQsd0JBQUMsUUFBRDtNQUFNLElBQUc7TUFBSSxJQUFHO01BQUssSUFBRztNQUFLLElBQUc7TUFBSyxhQUFZO0tBQUs7Ozs7O0tBQ3RELHdCQUFDLFFBQUQ7TUFBTSxJQUFHO01BQUksSUFBRztNQUFLLElBQUc7TUFBSyxJQUFHO01BQUssYUFBWTtLQUFPOzs7OztLQUN4RCx3QkFBQyxRQUFEO01BQU0sSUFBRztNQUFJLElBQUc7TUFBSyxJQUFHO01BQUssSUFBRztNQUFLLGFBQVk7S0FBSzs7Ozs7SUFDbkQ7Ozs7OztFQUVUO0VBQ0E7R0FDRSxNQUFNO0dBQ04sT0FBTztHQUNQLE1BQU07R0FDTixNQUFNLHdCQUFDLEtBQUQsRUFBSyxXQUFVLDBCQUEyQjs7Ozs7RUFDbEQ7RUFDQTtHQUNFLE1BQU07R0FDTixPQUFPO0dBQ1AsTUFBTTtHQUNOLE1BQU0sd0JBQUMsTUFBRCxFQUFNLFdBQVUsdUJBQXdCOzs7OztFQUNoRDtDQUNGOztDQUdBLE1BQU0sa0JBQWtCLE9BQU8sU0FBUztFQUN0QyxNQUFNLG1CQUFtQjtHQUN2QjtJQUFFLEdBQUc7SUFBSyxHQUFHO0dBQUk7R0FDakI7SUFBRSxHQUFHO0lBQUssR0FBRztHQUFJO0dBQ2pCO0lBQUUsR0FBRztJQUFLLEdBQUc7R0FBSTtHQUNqQjtJQUFFLEdBQUc7SUFBSyxHQUFHO0dBQUk7R0FDakI7SUFBRSxHQUFHO0lBQUssR0FBRztHQUFJO0dBQ2pCO0lBQUUsR0FBRztJQUFLLEdBQUc7R0FBSTtFQUNuQjs7RUFFQSxNQUFNLFlBQVksaUJBQWlCLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxpQkFBaUIsTUFBTTtFQUVyRixNQUFNLFFBQVEsVUFBVSxRQUFPLE9BQU0sR0FBRyxpQkFBaUIsSUFBSSxDQUFDLENBQUMsU0FBUztFQUN4RSxNQUFNLGVBQWU7R0FDbkIsU0FBUyx3QkFBd0I7R0FDakMsZUFBZSwyQkFBMkI7R0FDMUMsV0FBVyx3QkFBd0I7R0FDbkMsVUFBVSxxQkFBcUI7R0FDL0IsZUFBZSxtQkFBbUI7R0FDbEMsYUFBYSxxQkFBcUI7R0FDbEMsTUFBTSxtQkFBbUI7RUFDM0I7RUFFQSxNQUFNLGtCQUFrQixjQUFjLFVBQVUsU0FBUyxJQUFJLFVBQVUsRUFBRSxDQUFDLGFBQWEsVUFBVSxFQUFFLENBQUMsWUFBWTtFQUVoSCxNQUFNLFVBQVU7R0FDZCxRQUFRLGFBQWEsU0FBUyxVQUFVLEtBQUssR0FBRztHQUNoRCxjQUFjO0dBQ2QsV0FBVztHQUNYLGVBQWU7R0FDZix3QkFBd0I7R0FDeEIsV0FBVztHQUNDO0dBQ1osZUFBZTtJQUNiLFdBQVcsVUFBVTtJQUNyQixXQUFXLFVBQVU7SUFDckIsS0FBSyxTQUFTLG1CQUFtQixTQUFTLGNBQWMsT0FBTztJQUMvRCxPQUFPO0dBQ1Q7RUFDRjtFQUVBLE1BQU0sTUFBTSxNQUFNLG9CQUFvQixZQUFZLE9BQU87RUFDekQsSUFBSSxPQUFPLElBQUksU0FBUztHQUN0QixVQUFVLEdBQUcsS0FBSyx1Q0FBdUMsU0FBUztHQUNsRSxnQkFBZ0IsSUFBSSxRQUFRO0VBQzlCLE9BQU87R0FDTCxVQUFVLEtBQUssU0FBUyw4QkFBOEIsT0FBTztFQUMvRDtDQUNGOztDQUdBLE1BQU0sdUJBQXVCLE9BQU8sTUFBTTtFQUN4QyxJQUFJLEdBQUcsRUFBRSxlQUFlO0VBQ3hCLElBQUksQ0FBQyxjQUFjO0VBRW5CLE1BQU0sVUFBVTtHQUNkLFFBQVEsV0FBVyxLQUFLO0dBQ3hCLGNBQWM7R0FDZCxXQUFXLGNBQWMsS0FBSztHQUM5QixlQUFlO0dBQ2Ysd0JBQXdCLGtCQUFrQixLQUFLO0dBQy9DLGVBQWU7SUFDYixHQUFHLGFBQWE7SUFDaEIsS0FBSyxRQUFRLEtBQUs7SUFDbEIsT0FBTyxVQUFVLEtBQUs7SUFDdEIsV0FBVyxhQUFhLGVBQWUsYUFBYTtJQUNwRCxXQUFXLGFBQWEsZUFBZSxhQUFhO0dBQ3REO0VBQ0Y7RUFFQSxNQUFNLHVCQUF1QixjQUFjLGFBQWEsWUFBWSxhQUFhLElBQUksT0FBTztFQUM1RixVQUFVLDBDQUEwQyxTQUFTO0NBQy9EOztDQUdBLE1BQU0sd0JBQXdCLFNBQVM7RUFDckMsSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDO0VBQ25CLE9BQU8sVUFBVSxRQUFPLE9BQU07R0FDNUIsSUFBSSxHQUFHLE9BQU8sS0FBSyxJQUFJLE9BQU87R0FDOUIsTUFBTSxZQUFZLEdBQUcsaUJBQWlCLEdBQUcsY0FBYyxZQUFZLENBQUMsQ0FBQyxLQUFLLE9BQU8sS0FBSyxVQUFVLEdBQUUsQ0FBRSxZQUFZLENBQUMsQ0FBQyxLQUFLO0dBQ3ZILE1BQU0sVUFBVSxHQUFHLGtCQUFrQixHQUFHLGNBQWMsU0FBUyxLQUFLLEVBQUUsS0FBSyxHQUFHLGtCQUFrQixLQUFLO0dBQ3JHLE1BQU0sZ0JBQWdCLEdBQUcsb0JBQW9CLEtBQUssTUFBTSxHQUFHLGFBQWEsS0FBSztHQUM3RSxPQUFPLGFBQWEsV0FBVztFQUNqQyxDQUFDO0NBQ0g7O0NBR0EsTUFBTSxzQkFBc0IsWUFBWTtFQUN0QyxJQUFJLENBQUMsY0FBYztFQUVuQixNQUFNLFVBQVUscUJBQXFCLFlBQVk7RUFDakQsSUFBSSxhQUFhLG1FQUFtRSxhQUFhLE9BQU8sS0FBSyxhQUFhLEdBQUc7RUFFN0gsSUFBSSxRQUFRLFNBQVMsR0FBRztHQUN0QixNQUFNLGFBQWEsUUFBUSxLQUFJLE1BQUssS0FBSyxFQUFFLE9BQU8sSUFBSSxFQUFFLGdCQUFnQixTQUFTLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSTtHQUM5RixjQUFjLG1FQUFtRSxRQUFRLE9BQU8sNkRBQTZELFdBQVc7RUFDMUs7RUFFQSxNQUFNLEtBQUssTUFBTSxRQUFRO0dBQ3ZCLE9BQU87R0FDUCxTQUFTO0dBQ1QsTUFBTTtHQUNOLGFBQWE7RUFDZixDQUFDO0VBRUQsSUFBSSxJQUFJO0dBQ04sTUFBTSxhQUFhLGFBQWE7O0dBR2hDLEtBQUssTUFBTSxNQUFNLFdBQVc7SUFDMUIsSUFDRSxHQUFHLGtCQUFrQixhQUFhLFVBQ2xDLEdBQUcsa0JBQWtCLGFBQWEsTUFDbEMsR0FBRyxlQUFlLFNBQVMsYUFBYSxFQUFFLEtBQzFDLEdBQUcsb0JBQW9CLGFBQWEsSUFDcEM7S0FDQSxNQUFNLHVCQUF1QixjQUFjLEdBQUcsWUFBWSxHQUFHLElBQUk7TUFDL0QsZUFBZTtNQUNmLGlCQUFpQjtLQUNuQixDQUFDO0lBQ0g7R0FDRjtHQUVBLGdCQUFnQixJQUFJO0dBQ3BCLE1BQU0sdUJBQXVCLGNBQWMsYUFBYSxZQUFZLFVBQVU7R0FDOUUsVUFBVSxXQUFXLGFBQWEsT0FBTyw0QkFBNEIsTUFBTTtFQUM3RTtDQUNGOztDQUdBLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYztFQUU5QixNQUFNLGlCQUFpQixNQUFNO0dBQzNCLE1BQU0sWUFBWSxTQUFTLGVBQWUsU0FBUyxZQUFZO0dBQy9ELElBQUksY0FBYyxXQUFXLGNBQWMsY0FBYyxjQUFjLFVBQVU7R0FFakYsSUFBSSxFQUFFLFFBQVEsWUFBWSxFQUFFLFFBQVEsYUFBYTtJQUMvQyxFQUFFLGVBQWU7SUFDakIsb0JBQW9CO0dBQ3RCO0VBQ0Y7RUFFQSxPQUFPLGlCQUFpQixXQUFXLGFBQWE7RUFDaEQsYUFBYSxPQUFPLG9CQUFvQixXQUFXLGFBQWE7Q0FDbEUsR0FBRztFQUFDO0VBQVE7RUFBYztDQUFTLENBQUM7O0NBR3BDLE1BQU0sMEJBQTBCLFlBQVk7RUFDMUMsSUFBSSxDQUFDLGNBQWM7RUFDbkIscUJBQXFCLEVBQUU7RUFDdkIsTUFBTSx1QkFBdUIsY0FBYyxhQUFhLFlBQVksYUFBYSxJQUFJLEVBQUUsZUFBZSxHQUFHLENBQUM7RUFDMUcsVUFBVSxzQ0FBc0MsTUFBTTtDQUN4RDs7Q0FHQSxNQUFNLG1CQUFtQixTQUFTO0VBQ2hDLElBQUksa0JBQWtCOztHQUVwQixJQUFJLENBQUMsa0JBQWtCOztJQUVyQixvQkFBb0IsSUFBSTtJQUN4QixVQUFVLHdCQUF3QixLQUFLLE9BQU8sbURBQW1ELE1BQU07R0FDekcsT0FBTzs7SUFFTCxJQUFJLGlCQUFpQixPQUFPLEtBQUssSUFBSTtLQUNuQyxVQUFVLCtDQUErQyxPQUFPO0tBQ2hFO0lBQ0Y7O0lBR0EsdUJBQXVCLGNBQWMsS0FBSyxZQUFZLEtBQUssSUFBSSxFQUM3RCxlQUFlLGlCQUFpQixPQUNsQyxDQUFDO0lBRUQsVUFBVSx5QkFBeUIsaUJBQWlCLE9BQU8sS0FBSyxLQUFLLFVBQVUsU0FBUzs7SUFHeEYsb0JBQW9CLEtBQUs7SUFDekIsb0JBQW9CLElBQUk7R0FDMUI7RUFDRixPQUFPO0dBQ0wsZ0JBQWdCLElBQUk7RUFDdEI7Q0FDRjs7Q0FHQSxNQUFNLG1CQUFtQixVQUFVLFFBQU8sT0FBTSxnQkFBZ0IsR0FBRyxPQUFPLGFBQWEsRUFBRTtDQUV6RixJQUFJLENBQUMsUUFBUSxPQUFPO0NBRXBCLE9BQ0UsZ0RBQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUVFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQW9GLFNBQVM7RUFBVTs7OztZQUd0SCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBR0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsS0FBRDtRQUFLLFdBQVU7UUFBd0MsT0FBTyxFQUFFLG1CQUFtQixLQUFLO09BQUk7Ozs7O01BQ3pGOzs7O2dCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUE2RyxvQ0FDM0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWtIO09BQWlCOzs7O2VBQ2pMOzs7OztnQkFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUNHO1FBQVk7UUFBSTtRQUFZO09BQzVCOzs7OztjQUNBOzs7O2NBQ0Y7Ozs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FFRSx3QkFBQyxVQUFEO1FBQ0UsZUFBZTtTQUNiLG9CQUFvQixDQUFDLGdCQUFnQjtTQUNyQyxvQkFBb0IsSUFBSTtTQUN4QixJQUFHLENBQUMsa0JBQWtCO1VBQ3BCLFVBQVUsMEVBQTBFLE1BQU07U0FDNUY7UUFDRjtRQUNBLFdBQVcsc0hBQ1QsbUJBQ0ksa0ZBQ0E7a0JBWFIsQ0FjRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7O2tCQUMzQixtQkFBbUIsa0JBQWtCLGlCQUNoQzs7Ozs7O09BRVIsd0JBQUMsVUFBRDtRQUNFLGVBQWUsT0FBTyxNQUFNO1FBQzVCLFdBQVU7a0JBQ1g7T0FFTzs7Ozs7T0FFUix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7a0JBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7T0FDbEI7Ozs7O01BQ0w7Ozs7O2FBQ0Y7Ozs7OztJQUdKLG9CQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxLQUFELEVBQUssV0FBVSxzQ0FBdUM7Ozs7O01BQ3RELHdCQUFDLFFBQUQsWUFDRyxtQkFDRyw4QkFBOEIsaUJBQWlCLE9BQU8sNkRBQ3RELDJHQUNBOzs7OztNQUNOLHdCQUFDLFVBQUQ7T0FDRSxlQUFlO1FBQ2Isb0JBQW9CLEtBQUs7UUFDekIsb0JBQW9CLElBQUk7T0FDMUI7T0FDQSxXQUFVO2lCQUNYO01BRU87Ozs7O0tBQ0w7Ozs7OztJQUlQLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFHRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZ0Y7UUFBc0I7Ozs7a0JBQ3BILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUE4QztRQUV4RDs7OztnQkFDQTs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixpQkFBaUIsS0FBSSxRQUNwQix3QkFBQyxVQUFEO1VBRUUsZUFBZSxnQkFBZ0IsSUFBSSxJQUFJO1VBQ3ZDLFdBQVU7b0JBSFosQ0FLRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWixJQUFJO1VBQ0Y7Ozs7b0JBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBOEUsSUFBSTtXQUFXOzs7O3FCQUM1Ryx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBc0MsSUFBSTtXQUFVOzs7O21CQUNoRTs7Ozs7a0JBQ0M7WUFYRCxJQUFJOzs7O2dCQVdILENBQ1Q7UUFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUFzRztVQUNqRyx3QkFBQyxVQUFELFlBQVEsV0FBZ0I7Ozs7O1VBQUM7U0FDekI7Ozs7OztPQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQywyQkFBRDtTQUNhO1NBQ0U7U0FDQTtTQUNiLGFBQWE7U0FDYixnQkFBZ0IsY0FBYztTQUM5QixjQUFjO1FBQ2Y7Ozs7O09BQ0U7Ozs7O01BQ0Y7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osZUFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBRUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUEwRTtZQUFtQjs7OztzQkFDN0csd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQ2IsYUFBYTtZQUNWOzs7O29CQUNIOzs7Ozs7V0FDTCx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBZ0YsYUFBYTtXQUFXOzs7OztXQUN0SCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FBa0UsUUFBSyxhQUFhLEVBQVM7Ozs7OztVQUMxRjs7Ozs7bUJBR0wsd0JBQUMsUUFBRDtVQUFNLFVBQVU7VUFBc0IsV0FBVTtvQkFBaEQ7V0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQTBFO1dBQXdCOzs7O3FCQUNuSCx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztZQUM3QyxhQUFZO1lBQ1osV0FBVTtXQUNYOzs7O21CQUNFOzs7OztXQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBMEU7V0FBcUI7Ozs7cUJBQ2hILHdCQUFDLFVBQUQ7WUFDRSxPQUFPO1lBQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7WUFDM0MsV0FBVTtzQkFIWjthQUtFLHdCQUFDLFVBQUQ7Y0FBUSxPQUFNO3dCQUFVO2FBQXlCOzs7OzthQUNqRCx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBZ0I7YUFBcUI7Ozs7O2FBQ25ELHdCQUFDLFVBQUQ7Y0FBUSxPQUFNO3dCQUFZO2FBQTBCOzs7OzthQUNwRCx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBVzthQUEyQjs7Ozs7YUFDcEQsd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQWdCO2FBQXVCOzs7OzthQUNyRCx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBYzthQUF5Qjs7Ozs7YUFDckQsd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQU87YUFBcUI7Ozs7O1lBQ3BDOzs7OzttQkFDTDs7Ozs7V0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQTBFO1dBQXVCOzs7O3FCQUNsSCx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxLQUFLO1lBQ2hELGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7bUJBQ0U7Ozs7O1dBR0wsd0JBQUMsT0FBRCxZQUNFLHdCQUFDLCtCQUFEO1lBQ0UsWUFBWSxjQUFjLGNBQWM7WUFDeEMsaUJBQWlCLGNBQWM7WUFDL0IsZUFBZTtZQUNmLE9BQU87WUFDUCxXQUFXLFFBQVEscUJBQXFCLEdBQUc7WUFDM0MsT0FBTTtZQUNOLGFBQVk7V0FDYjs7OztvQkFDRTs7Ozs7V0FFTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBMEU7WUFBc0I7Ozs7c0JBQ2pILHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsT0FBTzthQUNQLFdBQVcsTUFBTSxXQUFXLEVBQUUsT0FBTyxLQUFLO2FBQzFDLGFBQVk7YUFDWixXQUFVO1lBQ1g7Ozs7b0JBQ0U7Ozs7c0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUEwRTtZQUFvQjs7OztzQkFDL0csd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxPQUFPO2FBQ1AsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7YUFDNUMsYUFBWTthQUNaLFdBQVU7WUFDWDs7OztvQkFDRTs7OztvQkFDRjs7Ozs7O1dBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUFvRjtXQUFvQjs7OztxQkFDekgsd0JBQUMsWUFBRDtZQUNFLE9BQU87WUFDUCxXQUFXLE1BQU0scUJBQXFCLEVBQUUsT0FBTyxLQUFLO1lBQ3BELGFBQVk7WUFDWixNQUFLO1lBQ0wsV0FBVTtXQUNYOzs7O21CQUNFOzs7OztXQUVMLHdCQUFDLFVBQUQ7WUFDRSxNQUFLO1lBQ0wsV0FBVTtzQkFGWixDQUlFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7c0JBQUMsa0JBQ3ZCOzs7Ozs7VUFDSjs7Ozs7aUJBQ0g7Ozs7O2tCQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0csYUFBYSxpQkFBaUIsYUFDN0Isd0JBQUMsVUFBRDtVQUNFLGVBQWU7V0FDYixRQUFRO1dBQ1IsU0FBUyxZQUFZLGFBQWEsYUFBYSxVQUFVLFdBQVcsYUFBYSxJQUFJO1VBQ3ZGO1VBQ0EsV0FBVTtvQkFMWixDQU1DLHlCQUNzQix3QkFBQyxjQUFELEVBQWMsV0FBVSxjQUFlOzs7O2tCQUN0RDs7Ozs7bUJBR1Ysd0JBQUMsVUFBRDtVQUNFLFNBQVM7VUFDVCxXQUFVO1VBQ1YsT0FBTTtvQkFIUixDQUtFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7b0JBQUMseUJBQzVCOzs7OztpQkFDTDs7Ozs7Z0JBQ0Y7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUseUJBQTBCOzs7O2tCQUMxQyx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBcUU7UUFFL0U7Ozs7Z0JBQ0E7Ozs7OztNQUVKOzs7OztLQUVGOzs7Ozs7R0FFRjs7Ozs7VUFDRjs7Ozs7V0FHTCx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLDJCQUFEO0dBQ2E7R0FDRTtHQUNBO0dBQ2IsYUFBYTtFQUNkOzs7OztDQUNFOzs7O1NBQ0w7Ozs7O0FBRU4iLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTW9kYWxEaWFncmFtYVVuaWZpbGFyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBYLCBcbiAgRXh0ZXJuYWxMaW5rLCBcbiAgSW5mbywgXG4gIFphcCwgXG4gIFRyYXNoMiwgXG4gIExpbmsyLCBcbiAgVW5saW5rLCBcbiAgUGx1cywgXG4gIENoZWNrLCBcbiAgQ3B1LCBcbiAgU2hpZWxkQWxlcnQsIFxuICBGb2xkZXJPcGVuIFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCBEaWFncmFtYVVuaWZpbGFyQmx1ZXByaW50IGZyb20gJy4vRGlhZ3JhbWFVbmlmaWxhckJsdWVwcmludCc7XG5pbXBvcnQgU2VsZWN0b3JBbGltZW50YWRvckplcmFycXVpY28gZnJvbSAnLi9TZWxlY3RvckFsaW1lbnRhZG9ySmVyYXJxdWljbyc7XG5pbXBvcnQgdXNlU3RvcmUgZnJvbSAnLi4vc3RvcmUvdXNlU3RvcmUnO1xuaW1wb3J0IHsgdXNlQ29uZmlybSB9IGZyb20gJy4uL2NvbnRleHQvQ29uZmlybUNvbnRleHQnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNb2RhbERpYWdyYW1hVW5pZmlsYXIoeyBcbiAgaXNPcGVuLCBcbiAgb25DbG9zZSwgXG4gIGVsZW1lbnRvcyA9IFtdLCBcbiAgY29tcGFueU5hbWUsIFxuICBwcm9qZWN0TmFtZSA9ICdTSVNURU1BIEVMw4lDVFJJQ08nLFxuICBwcm95ZWN0b0lkID0gbnVsbCxcbiAgY29tcGFueUlkID0gbnVsbFxufSkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHsgYWRkRWxlbWVudG9VbmlmaWxhciwgdXBkYXRlRWxlbWVudG9VbmlmaWxhciwgZGVsZXRlRWxlbWVudG9VbmlmaWxhciwgc2hvd1RvYXN0IH0gPSB1c2VTdG9yZSgpO1xuICBjb25zdCB7IGNvbmZpcm0gfSA9IHVzZUNvbmZpcm0oKTtcblxuICBjb25zdCBbc2VsZWN0ZWROb2RlLCBzZXRTZWxlY3RlZE5vZGVdID0gdXNlU3RhdGUobnVsbCk7XG4gIFxuICAvLyBFc3RhZG9zIGRlIGVkaWNpw7NuIGRlbCBub2RvIHNlbGVjY2lvbmFkb1xuICBjb25zdCBbZWRpdE5vbWJyZSwgc2V0RWRpdE5vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtlZGl0VGlwbywgc2V0RWRpdFRpcG9dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZWRpdFViaWNhY2lvbiwgc2V0RWRpdFViaWNhY2lvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtlZGl0QWxpbWVudGFkb1Bvciwgc2V0RWRpdEFsaW1lbnRhZG9Qb3JdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZWRpdEt2YSwgc2V0RWRpdEt2YV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtlZGl0RmFzZXMsIHNldEVkaXRGYXNlc10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtlZGl0T2JzZXJ2YWNpb25lcywgc2V0RWRpdE9ic2VydmFjaW9uZXNdID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIEVzdGFkb3MgZGUgTW9kbyBDb25leGnDs25cbiAgY29uc3QgW2lzQ29ubmVjdGlvbk1vZGUsIHNldElzQ29ubmVjdGlvbk1vZGVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbY29ubmVjdGlvblNvdXJjZSwgc2V0Q29ubmVjdGlvblNvdXJjZV0gPSB1c2VTdGF0ZShudWxsKTsgLy8gTm9kbyBvcmlnZW5cblxuICAvLyBTaW5jcm9uaXphciBmb3JtdWxhcmlvIGN1YW5kbyBjYW1iaWEgZWwgbm9kbyBzZWxlY2Npb25hZG9cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoc2VsZWN0ZWROb2RlKSB7XG4gICAgICBzZXRFZGl0Tm9tYnJlKHNlbGVjdGVkTm9kZS5ub21icmUgfHwgJycpO1xuICAgICAgc2V0RWRpdFRpcG8oc2VsZWN0ZWROb2RlLnRpcG9FbGVtZW50byB8fCAnVEFCTEVSTycpO1xuICAgICAgc2V0RWRpdFViaWNhY2lvbihzZWxlY3RlZE5vZGUudWJpY2FjaW9uIHx8ICcnKTtcbiAgICAgIHNldEVkaXRBbGltZW50YWRvUG9yKHNlbGVjdGVkTm9kZS5hbGltZW50YWRvUG9yIHx8ICcnKTtcbiAgICAgIHNldEVkaXRLdmEoc2VsZWN0ZWROb2RlLmRhdG9zVGVjbmljb3M/Lmt2YSB8fCBzZWxlY3RlZE5vZGUuZGF0b3NUZWNuaWNvcz8ucG90ZW5jaWFLdmEgfHwgJycpO1xuICAgICAgc2V0RWRpdEZhc2VzKHNlbGVjdGVkTm9kZS5kYXRvc1RlY25pY29zPy5mYXNlcyB8fCBzZWxlY3RlZE5vZGUubWF4UG9sZXMgfHwgJycpO1xuICAgICAgc2V0RWRpdE9ic2VydmFjaW9uZXMoc2VsZWN0ZWROb2RlLm9ic2VydmFjaW9uZXNHZW5lcmFsZXMgfHwgJycpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXNldEVkaXRGb3JtKCk7XG4gICAgfVxuICB9LCBbc2VsZWN0ZWROb2RlXSk7XG5cbiAgLy8gQWN0dWFsaXphciBsYSByZWZlcmVuY2lhIGRlbCBub2RvIHNlbGVjY2lvbmFkbyBzaSBsb3MgZWxlbWVudG9zIGNhbWJpYW4gKHJlYWN0aXZpZGFkKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChzZWxlY3RlZE5vZGUpIHtcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBlbGVtZW50b3MuZmluZChlbCA9PiBlbC5pZCA9PT0gc2VsZWN0ZWROb2RlLmlkKTtcbiAgICAgIGlmICh1cGRhdGVkKSB7XG4gICAgICAgIHNldFNlbGVjdGVkTm9kZSh1cGRhdGVkKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldFNlbGVjdGVkTm9kZShudWxsKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFtlbGVtZW50b3NdKTtcblxuICBjb25zdCByZXNldEVkaXRGb3JtID0gKCkgPT4ge1xuICAgIHNldEVkaXROb21icmUoJycpO1xuICAgIHNldEVkaXRUaXBvKCcnKTtcbiAgICBzZXRFZGl0VWJpY2FjaW9uKCcnKTtcbiAgICBzZXRFZGl0QWxpbWVudGFkb1BvcignJyk7XG4gICAgc2V0RWRpdEt2YSgnJyk7XG4gICAgc2V0RWRpdEZhc2VzKCcnKTtcbiAgICBzZXRFZGl0T2JzZXJ2YWNpb25lcygnJyk7XG4gIH07XG5cbiAgLy8gQ2F0w6Fsb2dvIGRlIHPDrW1ib2xvcyBlbMOpY3RyaWNvcyBwYXJhIGVsIHBhbmVsIGl6cXVpZXJkb1xuXG4gIGNvbnN0IGNhdGFsb2dPZlN5bWJvbHMgPSBbXG4gICAgeyBcbiAgICAgIHR5cGU6ICdUQUJMRVJPJywgXG4gICAgICBsYWJlbDogJ1RhYmxlcm8gRWzDqWN0cmljbycsIFxuICAgICAgZGVzYzogJ1BhbmVsIGRlIGRpc3RyaWJ1Y2nDs24nLCBcbiAgICAgIGljb246IDxkaXYgY2xhc3NOYW1lPVwidy01IGgtNCBib3JkZXIgYm9yZGVyLXNsYXRlLTQwMCBiZy1zbGF0ZS05NTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1bN3B4XVwiPuKaoTwvZGl2PiBcbiAgICB9LFxuICAgIHsgXG4gICAgICB0eXBlOiAnVFJBTlNGT1JNQURPUicsIFxuICAgICAgbGFiZWw6ICdUcmFuc2Zvcm1hZG9yJywgXG4gICAgICBkZXNjOiAnUmVkdWN0b3IvRWxldmFkb3InLCBcbiAgICAgIGljb246IChcbiAgICAgICAgPHN2ZyB3aWR0aD1cIjIwXCIgaGVpZ2h0PVwiMjBcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCIgY2xhc3NOYW1lPVwib3ZlcmZsb3ctdmlzaWJsZSBmaWxsLW5vbmUgc3Ryb2tlLWN1cnJlbnQgdGV4dC12aW9sZXQtNDAwXCI+XG4gICAgICAgICAgPGNpcmNsZSBjeD1cIjEwXCIgY3k9XCI3XCIgcj1cIjVcIiBzdHJva2VXaWR0aD1cIjEuNVwiIC8+XG4gICAgICAgICAgPGNpcmNsZSBjeD1cIjEwXCIgY3k9XCIxM1wiIHI9XCI1XCIgc3Ryb2tlV2lkdGg9XCIxLjVcIiAvPlxuICAgICAgICA8L3N2Zz5cbiAgICAgICkgXG4gICAgfSxcbiAgICB7IFxuICAgICAgdHlwZTogJ0dFTkVSQURPUicsIFxuICAgICAgbGFiZWw6ICdHZW5lcmFkb3IgLyBQbGFudGEnLCBcbiAgICAgIGRlc2M6ICdHZW5lcmFkb3IgYXV4aWxpYXInLCBcbiAgICAgIGljb246IDxkaXYgY2xhc3NOYW1lPVwidy01IGgtNSByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1hbWJlci01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtYW1iZXItNTAwIGJnLWFtYmVyLTk1MC8yMFwiPkc8L2Rpdj4gXG4gICAgfSxcbiAgICB7IFxuICAgICAgdHlwZTogJ1RSQU5TRkVSJywgXG4gICAgICBsYWJlbDogJ0FUUyAvIFRyYW5zZmVyZW5jaWEnLCBcbiAgICAgIGRlc2M6ICdDb25tdXRhY2nDs24gZGUgcmVkJywgXG4gICAgICBpY29uOiA8ZGl2IGNsYXNzTmFtZT1cInctNyBoLTQgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMCByb3VuZGVkIHRleHQtWzdweF0gZm9udC1ibGFjayB0ZXh0LWNlbnRlciB0ZXh0LWVtZXJhbGQtNDAwIGJnLWVtZXJhbGQtOTUwLzIwIGxlYWRpbmctdGlnaHRcIj5BVFM8L2Rpdj4gXG4gICAgfSxcbiAgICB7IFxuICAgICAgdHlwZTogJ1BVRVNUQV9USUVSUkEnLCBcbiAgICAgIGxhYmVsOiAnUHVlc3RhIGEgVGllcnJhJywgXG4gICAgICBkZXNjOiAnTWFsbGEgLyBFbGVjdHJvZG8nLCBcbiAgICAgIGljb246IChcbiAgICAgICAgPHN2ZyB3aWR0aD1cIjE4XCIgaGVpZ2h0PVwiMThcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCIgY2xhc3NOYW1lPVwic3Ryb2tlLWN1cnJlbnQgdGV4dC10ZWFsLTQwMFwiIGZpbGw9XCJub25lXCI+XG4gICAgICAgICAgPGxpbmUgeDE9XCIxMFwiIHkxPVwiMlwiIHgyPVwiMTBcIiB5Mj1cIjEyXCIgc3Ryb2tlV2lkdGg9XCIyXCIgLz5cbiAgICAgICAgICA8bGluZSB4MT1cIjRcIiB5MT1cIjEyXCIgeDI9XCIxNlwiIHkyPVwiMTJcIiBzdHJva2VXaWR0aD1cIjJcIiAvPlxuICAgICAgICAgIDxsaW5lIHgxPVwiNlwiIHkxPVwiMTVcIiB4Mj1cIjE0XCIgeTI9XCIxNVwiIHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICA8bGluZSB4MT1cIjhcIiB5MT1cIjE4XCIgeDI9XCIxMlwiIHkyPVwiMThcIiBzdHJva2VXaWR0aD1cIjFcIiAvPlxuICAgICAgICA8L3N2Zz5cbiAgICAgICkgXG4gICAgfSxcbiAgICB7IFxuICAgICAgdHlwZTogJ1NVQkVTVEFDSU9OJywgXG4gICAgICBsYWJlbDogJ0NlbGRhIC8gU3ViZXN0YWNpw7NuJywgXG4gICAgICBkZXNjOiAnTcOzZHVsbyBkZSBtYW5pb2JyYScsIFxuICAgICAgaWNvbjogPENwdSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcHVycGxlLTQwMFwiIC8+IFxuICAgIH0sXG4gICAgeyBcbiAgICAgIHR5cGU6ICdPVFJPJywgXG4gICAgICBsYWJlbDogJ0NhcmdhIC8gQmFuY28gQ29uZC4nLCBcbiAgICAgIGRlc2M6ICdPdHJvcyBjb21wb25lbnRlcycsIFxuICAgICAgaWNvbjogPEluZm8gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNreS00MDBcIiAvPiBcbiAgICB9XG4gIF07XG5cbiAgLy8gQWdyZWdhciBudWV2byBzw61tYm9sbyBhbCBsaWVuem9cbiAgY29uc3QgaGFuZGxlQWRkU3ltYm9sID0gYXN5bmMgKHR5cGUpID0+IHtcbiAgICBjb25zdCBkZWZhdWx0UG9zaXRpb25zID0gW1xuICAgICAgeyB4OiAyNTAsIHk6IDE1MCB9LFxuICAgICAgeyB4OiAzNTAsIHk6IDE1MCB9LFxuICAgICAgeyB4OiA0NTAsIHk6IDE1MCB9LFxuICAgICAgeyB4OiA1NTAsIHk6IDE1MCB9LFxuICAgICAgeyB4OiAyNTAsIHk6IDMwMCB9LFxuICAgICAgeyB4OiA0NTAsIHk6IDMwMCB9XG4gICAgXTtcbiAgICAvLyBFdml0YXIgc29sYXBhbWllbnRvcyBpbmljaWFsZXMgYnVyZG9zXG4gICAgY29uc3QgcmFuZG9tUG9zID0gZGVmYXVsdFBvc2l0aW9uc1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBkZWZhdWx0UG9zaXRpb25zLmxlbmd0aCldO1xuICAgIFxuICAgIGNvbnN0IGNvdW50ID0gZWxlbWVudG9zLmZpbHRlcihlbCA9PiBlbC50aXBvRWxlbWVudG8gPT09IHR5cGUpLmxlbmd0aCArIDE7XG4gICAgY29uc3QgZGVmYXVsdE5hbWVzID0ge1xuICAgICAgVEFCTEVSTzogYFRhYmxlcm8gRGlzdHJpYnVjacOzbiAke2NvdW50fWAsXG4gICAgICBUUkFOU0ZPUk1BRE9SOiBgVHJhbnNmb3JtYWRvciBQcmluY2lwYWwgJHtjb3VudH1gLFxuICAgICAgR0VORVJBRE9SOiBgR2VuZXJhZG9yIEVtZXJnZW5jaWEgJHtjb3VudH1gLFxuICAgICAgVFJBTlNGRVI6IGBBVFMgVHJhbnNmZXJlbmNpYSAke2NvdW50fWAsXG4gICAgICBQVUVTVEFfVElFUlJBOiBgTWFsbGEgZGUgVGllcnJhICR7Y291bnR9YCxcbiAgICAgIFNVQkVTVEFDSU9OOiBgQ2VsZGEgU3ViZXN0YWNpw7NuICR7Y291bnR9YCxcbiAgICAgIE9UUk86IGBFcXVpcG8gRXNwZWNpYWwgJHtjb3VudH1gXG4gICAgfTtcblxuICAgIGNvbnN0IHRhcmdldENvbXBhbnlJZCA9IGNvbXBhbnlJZCB8fCAoZWxlbWVudG9zLmxlbmd0aCA+IDAgPyBlbGVtZW50b3NbMF0uZW1wcmVzYUlkIHx8IGVsZW1lbnRvc1swXS5jb21wYW55SWQgOiBudWxsKTtcblxuICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICBub21icmU6IGRlZmF1bHROYW1lc1t0eXBlXSB8fCBgRXF1aXBvICR7dHlwZX0gJHtjb3VudH1gLFxuICAgICAgdGlwb0VsZW1lbnRvOiB0eXBlLFxuICAgICAgdWJpY2FjaW9uOiAnU2FsYSBFbMOpY3RyaWNhJyxcbiAgICAgIGFsaW1lbnRhZG9Qb3I6ICcnLFxuICAgICAgb2JzZXJ2YWNpb25lc0dlbmVyYWxlczogJycsXG4gICAgICBjb21wYW55SWQ6IHRhcmdldENvbXBhbnlJZCxcbiAgICAgIHByb3llY3RvSWQ6IHByb3llY3RvSWQsXG4gICAgICBkYXRvc1RlY25pY29zOiB7XG4gICAgICAgIHBvc2l0aW9uWDogcmFuZG9tUG9zLngsXG4gICAgICAgIHBvc2l0aW9uWTogcmFuZG9tUG9zLnksXG4gICAgICAgIGt2YTogdHlwZSA9PT0gJ1RSQU5TRk9STUFET1InIHx8IHR5cGUgPT09ICdHRU5FUkFET1InID8gJzc1JyA6ICcnLFxuICAgICAgICBmYXNlczogJzMnXG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkZEVsZW1lbnRvVW5pZmlsYXIocHJveWVjdG9JZCwgcGF5bG9hZCk7XG4gICAgaWYgKHJlcyAmJiByZXMuc3VjY2Vzcykge1xuICAgICAgc2hvd1RvYXN0KGAke3R5cGV9IGFncmVnYWRvIGFsIGRpYWdyYW1hIGNvcnJlY3RhbWVudGUuYCwgJ3N1Y2Nlc3MnKTtcbiAgICAgIHNldFNlbGVjdGVkTm9kZShyZXMuZWxlbWVudG8pO1xuICAgIH0gZWxzZSB7XG4gICAgICBzaG93VG9hc3QocmVzPy5lcnJvciB8fCAnRXJyb3IgYWwgYWdyZWdhciBlbGVtZW50by4nLCAnZXJyb3InKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gR3VhcmRhciBwcm9waWVkYWRlcyBlZGl0YWRhc1xuICBjb25zdCBoYW5kbGVTYXZlUHJvcGVydGllcyA9IGFzeW5jIChlKSA9PiB7XG4gICAgaWYgKGUpIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIXNlbGVjdGVkTm9kZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgdXBkYXRlZCA9IHtcbiAgICAgIG5vbWJyZTogZWRpdE5vbWJyZS50cmltKCksXG4gICAgICB0aXBvRWxlbWVudG86IGVkaXRUaXBvLFxuICAgICAgdWJpY2FjaW9uOiBlZGl0VWJpY2FjaW9uLnRyaW0oKSxcbiAgICAgIGFsaW1lbnRhZG9Qb3I6IGVkaXRBbGltZW50YWRvUG9yLFxuICAgICAgb2JzZXJ2YWNpb25lc0dlbmVyYWxlczogZWRpdE9ic2VydmFjaW9uZXMudHJpbSgpLFxuICAgICAgZGF0b3NUZWNuaWNvczoge1xuICAgICAgICAuLi5zZWxlY3RlZE5vZGUuZGF0b3NUZWNuaWNvcyxcbiAgICAgICAga3ZhOiBlZGl0S3ZhLnRyaW0oKSxcbiAgICAgICAgZmFzZXM6IGVkaXRGYXNlcy50cmltKCksXG4gICAgICAgIHBvc2l0aW9uWDogc2VsZWN0ZWROb2RlLmRhdG9zVGVjbmljb3M/LnBvc2l0aW9uWCB8fCAzMDAsXG4gICAgICAgIHBvc2l0aW9uWTogc2VsZWN0ZWROb2RlLmRhdG9zVGVjbmljb3M/LnBvc2l0aW9uWSB8fCAyMDBcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgYXdhaXQgdXBkYXRlRWxlbWVudG9VbmlmaWxhcihwcm95ZWN0b0lkIHx8IHNlbGVjdGVkTm9kZS5wcm95ZWN0b0lkLCBzZWxlY3RlZE5vZGUuaWQsIHVwZGF0ZWQpO1xuICAgIHNob3dUb2FzdCgnUHJvcGllZGFkZXMgZGVsIGVsZW1lbnRvIGFjdHVhbGl6YWRhcy4nLCAnc3VjY2VzcycpO1xuICB9O1xuXG4gIC8vIE9idGVuZXIgZWxlbWVudG9zIGFndWFzIGFiYWpvIHF1ZSBxdWVkYXLDoW4gaHXDqXJmYW5vcyBzaSBzZSBlbGltaW5hIGVsIG5vZG9cbiAgY29uc3QgZ2V0RG93bnN0cmVhbU9ycGhhbnMgPSAobm9kZSkgPT4ge1xuICAgIGlmICghbm9kZSkgcmV0dXJuIFtdO1xuICAgIHJldHVybiBlbGVtZW50b3MuZmlsdGVyKGVsID0+IHtcbiAgICAgIGlmIChlbC5pZCA9PT0gbm9kZS5pZCkgcmV0dXJuIGZhbHNlO1xuICAgICAgY29uc3QgbWF0Y2hOYW1lID0gZWwuYWxpbWVudGFkb1BvciAmJiBlbC5hbGltZW50YWRvUG9yLnRvTG93ZXJDYXNlKCkudHJpbSgpID09PSAobm9kZS5ub21icmUgfHwgJycpLnRvTG93ZXJDYXNlKCkudHJpbSgpO1xuICAgICAgY29uc3QgbWF0Y2hJZCA9IGVsLmFsaW1lbnRhZG9Qb3IgJiYgKGVsLmFsaW1lbnRhZG9Qb3IuaW5jbHVkZXMobm9kZS5pZCkgfHwgZWwuYWxpbWVudGFkb1BvciA9PT0gbm9kZS5pZCk7XG4gICAgICBjb25zdCBtYXRjaERpcmVjdElkID0gZWwuYWxpbWVudGFkb1BvcklkID09PSBub2RlLmlkIHx8IGVsLm9yaWdlbklkID09PSBub2RlLmlkO1xuICAgICAgcmV0dXJuIG1hdGNoTmFtZSB8fCBtYXRjaElkIHx8IG1hdGNoRGlyZWN0SWQ7XG4gICAgfSk7XG4gIH07XG5cbiAgLy8gRWxpbWluYXIgZWxlbWVudG8gZGVsIGRpYWdyYW1hIGNvbiBhZHZlcnRlbmNpYSBkZSBodcOpcmZhbm9zXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUVsZW1lbnQgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFzZWxlY3RlZE5vZGUpIHJldHVybjtcblxuICAgIGNvbnN0IG9ycGhhbnMgPSBnZXREb3duc3RyZWFtT3JwaGFucyhzZWxlY3RlZE5vZGUpO1xuICAgIGxldCBjb25maXJtTXNnID0gYMK/RXN0w6FzIHNlZ3VybyBkZSBxdWUgZGVzZWFzIGVsaW1pbmFyIHBlcm1hbmVudGVtZW50ZSBlbCBlcXVpcG8gXCIke3NlbGVjdGVkTm9kZS5ub21icmV9XCIgKCR7c2VsZWN0ZWROb2RlLmlkfSk/YDtcblxuICAgIGlmIChvcnBoYW5zLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IG9ycGhhbkxpc3QgPSBvcnBoYW5zLm1hcChvID0+IGDigKIgJHtvLm5vbWJyZX0gKCR7by50aXBvRWxlbWVudG8gfHwgJ0VRVUlQTyd9KWApLmpvaW4oJ1xcbicpO1xuICAgICAgY29uZmlybU1zZyArPSBgXFxuXFxu4pqg77iPIEFEVkVSVEVOQ0lBIERFIERFUEVOREVOQ0lBUyBBR1VBUyBBQkFKTzpcXG5Mb3Mgc2lndWllbnRlcyAke29ycGhhbnMubGVuZ3RofSBlcXVpcG8ocykgcXVlZGFyw6FuIGh1w6lyZmFub3MgKHNpbiBhbGltZW50YWNpw7NuIGRpcmVjdGEpOlxcbiR7b3JwaGFuTGlzdH1cXG5cXG5TZSBkZXN2aW5jdWxhcsOhbiBhdXRvbcOhdGljYW1lbnRlIGRlIGZvcm1hIHNlZ3VyYS5gO1xuICAgIH1cblxuICAgIGNvbnN0IG9rID0gYXdhaXQgY29uZmlybSh7XG4gICAgICB0aXRsZTogJ0VsaW1pbmFyIEVxdWlwbyBkZWwgRGlhZ3JhbWEnLFxuICAgICAgbWVzc2FnZTogY29uZmlybU1zZyxcbiAgICAgIHR5cGU6ICdkYW5nZXInLFxuICAgICAgY29uZmlybVRleHQ6ICdFbGltaW5hciBFcXVpcG8nXG4gICAgfSk7XG5cbiAgICBpZiAob2spIHtcbiAgICAgIGNvbnN0IGlkVG9EZWxldGUgPSBzZWxlY3RlZE5vZGUuaWQ7XG4gICAgICBcbiAgICAgIC8vIERlc2NvbmVjdGFyIGh1w6lyZmFub3MgYW50ZXMgZGUgZWxpbWluYXIgcGFyYSBtYW50ZW5lciBjb2hlcmVuY2lhIGVuIGNhc2NhZGFcbiAgICAgIGZvciAoY29uc3QgZWwgb2YgZWxlbWVudG9zKSB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICBlbC5hbGltZW50YWRvUG9yID09PSBzZWxlY3RlZE5vZGUubm9tYnJlIHx8IFxuICAgICAgICAgIGVsLmFsaW1lbnRhZG9Qb3IgPT09IHNlbGVjdGVkTm9kZS5pZCB8fFxuICAgICAgICAgIGVsLmFsaW1lbnRhZG9Qb3I/LmluY2x1ZGVzKHNlbGVjdGVkTm9kZS5pZCkgfHxcbiAgICAgICAgICBlbC5hbGltZW50YWRvUG9ySWQgPT09IHNlbGVjdGVkTm9kZS5pZFxuICAgICAgICApIHtcbiAgICAgICAgICBhd2FpdCB1cGRhdGVFbGVtZW50b1VuaWZpbGFyKHByb3llY3RvSWQgfHwgZWwucHJveWVjdG9JZCwgZWwuaWQsIHsgXG4gICAgICAgICAgICBhbGltZW50YWRvUG9yOiAnJyxcbiAgICAgICAgICAgIGFsaW1lbnRhZG9Qb3JJZDogbnVsbFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHNldFNlbGVjdGVkTm9kZShudWxsKTtcbiAgICAgIGF3YWl0IGRlbGV0ZUVsZW1lbnRvVW5pZmlsYXIocHJveWVjdG9JZCB8fCBzZWxlY3RlZE5vZGUucHJveWVjdG9JZCwgaWRUb0RlbGV0ZSk7XG4gICAgICBzaG93VG9hc3QoYEVxdWlwbyBcIiR7c2VsZWN0ZWROb2RlLm5vbWJyZX1cIiBlbGltaW5hZG8gZGVsIGRpYWdyYW1hLmAsICdpbmZvJyk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEF0YWpvIGRlIHRlY2xhZG86IFRlY2xhIERlbGV0ZSAvIEJhY2tzcGFjZSBwYXJhIGJvcnJhciBub2RvIHNlbGVjY2lvbmFkb1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghaXNPcGVuIHx8ICFzZWxlY3RlZE5vZGUpIHJldHVybjtcblxuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZSkgPT4ge1xuICAgICAgY29uc3QgYWN0aXZlVGFnID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudD8udGFnTmFtZT8udG9Mb3dlckNhc2UoKTtcbiAgICAgIGlmIChhY3RpdmVUYWcgPT09ICdpbnB1dCcgfHwgYWN0aXZlVGFnID09PSAndGV4dGFyZWEnIHx8IGFjdGl2ZVRhZyA9PT0gJ3NlbGVjdCcpIHJldHVybjtcblxuICAgICAgaWYgKGUua2V5ID09PSAnRGVsZXRlJyB8fCBlLmtleSA9PT0gJ0JhY2tzcGFjZScpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBoYW5kbGVEZWxldGVFbGVtZW50KCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gIH0sIFtpc09wZW4sIHNlbGVjdGVkTm9kZSwgZWxlbWVudG9zXSk7XG5cbiAgLy8gRGVzY29uZWN0YXIgZWxlbWVudG8gc2VsZWNjaW9uYWRvXG4gIGNvbnN0IGhhbmRsZURpc2Nvbm5lY3RFbGVtZW50ID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWROb2RlKSByZXR1cm47XG4gICAgc2V0RWRpdEFsaW1lbnRhZG9Qb3IoJycpO1xuICAgIGF3YWl0IHVwZGF0ZUVsZW1lbnRvVW5pZmlsYXIocHJveWVjdG9JZCB8fCBzZWxlY3RlZE5vZGUucHJveWVjdG9JZCwgc2VsZWN0ZWROb2RlLmlkLCB7IGFsaW1lbnRhZG9Qb3I6ICcnIH0pO1xuICAgIHNob3dUb2FzdCgnQ29uZXhpw7NuIGRlIGFsaW1lbnRhY2nDs24gcmVtb3ZpZGEuJywgJ2luZm8nKTtcbiAgfTtcblxuICAvLyBNYW5lamFyIGNsaWNrIGVuIG5vZG8gZGVsIGxpZW56b1xuICBjb25zdCBoYW5kbGVOb2RlQ2xpY2sgPSAobm9kZSkgPT4ge1xuICAgIGlmIChpc0Nvbm5lY3Rpb25Nb2RlKSB7XG4gICAgICAvLyBGbHVqbyBkZSBDb25leGnDs25cbiAgICAgIGlmICghY29ubmVjdGlvblNvdXJjZSkge1xuICAgICAgICAvLyBTZWxlY2Npb25hciBvcmlnZW5cbiAgICAgICAgc2V0Q29ubmVjdGlvblNvdXJjZShub2RlKTtcbiAgICAgICAgc2hvd1RvYXN0KGBPcmlnZW4gc2VsZWNjaW9uYWRvOiAke25vZGUubm9tYnJlfS4gSGF6IGNsaWMgZW4gZWwgZXF1aXBvIGRlc3Rpbm8gcGFyYSBjb25lY3RhcmxvLmAsICdpbmZvJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBTZWxlY2Npb25hciBkZXN0aW5vXG4gICAgICAgIGlmIChjb25uZWN0aW9uU291cmNlLmlkID09PSBub2RlLmlkKSB7XG4gICAgICAgICAgc2hvd1RvYXN0KCdObyBwdWVkZXMgY29uZWN0YXIgdW4gZXF1aXBvIGNvbnNpZ28gbWlzbW8uJywgJ2Vycm9yJyk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAvLyBFbCBkZXN0aW5vIGVzIGFsaW1lbnRhZG8gcG9yIGVsIG9yaWdlblxuICAgICAgICB1cGRhdGVFbGVtZW50b1VuaWZpbGFyKHByb3llY3RvSWQgfHwgbm9kZS5wcm95ZWN0b0lkLCBub2RlLmlkLCB7IFxuICAgICAgICAgIGFsaW1lbnRhZG9Qb3I6IGNvbm5lY3Rpb25Tb3VyY2Uubm9tYnJlIFxuICAgICAgICB9KTtcblxuICAgICAgICBzaG93VG9hc3QoYENvbmV4acOzbiBlc3RhYmxlY2lkYTogJHtjb25uZWN0aW9uU291cmNlLm5vbWJyZX0g4p6UICR7bm9kZS5ub21icmV9YCwgJ3N1Y2Nlc3MnKTtcbiAgICAgICAgXG4gICAgICAgIC8vIFJlc2V0ZWFyIG1vZG8gY29uZXhpw7NuXG4gICAgICAgIHNldElzQ29ubmVjdGlvbk1vZGUoZmFsc2UpO1xuICAgICAgICBzZXRDb25uZWN0aW9uU291cmNlKG51bGwpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzZXRTZWxlY3RlZE5vZGUobm9kZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIExpc3RhIGRlIHBvc2libGVzIGFsaW1lbnRhZG9yZXMgKGV4Y2x1eWUgYWwgbm9kbyBtaXNtbyBwYXJhIGV2aXRhciBidWNsZXMpXG4gIGNvbnN0IHBvdGVudGlhbEZlZWRlcnMgPSBlbGVtZW50b3MuZmlsdGVyKGVsID0+IHNlbGVjdGVkTm9kZSAmJiBlbC5pZCAhPT0gc2VsZWN0ZWROb2RlLmlkKTtcblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IHByaW50OmhpZGRlblwiPlxuICAgICAgICB7LyogQmFja2Ryb3AgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1zbGF0ZS05NTAvODAgYmFja2Ryb3AtYmx1ci1tZCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCIgb25DbGljaz17b25DbG9zZX0gLz5cblxuICAgICAgICB7LyogVmVudGFuYSBQcmluY2lwYWwgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LTd4bCBoLVs5NXZoXSBiZy1zbGF0ZS05MDAvOTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgc2hhZG93LTJ4bCBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCBhbmltYXRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMjAwXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIENhYmVjZXJhICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHAtNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTk1MC80NSBzaHJpbmstMCBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1hbWJlci05NTUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWFtYmVyLTgwMC80MCBhbmltYXRlLXB1bHNlXCI+XG4gICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNTAwIGFuaW1hdGUtYm91bmNlXCIgc3R5bGU9e3sgYW5pbWF0aW9uRHVyYXRpb246ICczcycgfX0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS0xMDAgZm9udC1tb25vIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICBFZGl0b3IgZGUgRGlhZ3JhbWEgVW5pZmlsYXIgQ0FEIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNTAwIGJnLWFtYmVyLTk1MC82MCBib3JkZXIgYm9yZGVyLWFtYmVyLTkwMCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1zYW5zIGxvd2VyY2FzZVwiPmludGVyYWN0aXZvPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00NTUgZm9udC1zYW5zXCI+XG4gICAgICAgICAgICAgICAgICB7Y29tcGFueU5hbWV9IOKAlCB7cHJvamVjdE5hbWV9IOKAoiBBcnJhc3RyYSBlcXVpcG9zLCBoYXogZG9ibGUgY2xpYyBwYXJhIGVkaXRhciBvIHVzYSBlbCB0cmF6YWRvciBkZSBjb25leGlvbmVzLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IG5vLXByaW50XCI+XG4gICAgICAgICAgICAgIHsvKiBCb3TDs24gZGUgTW9kbyBDb25leGnDs24gKi99XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRJc0Nvbm5lY3Rpb25Nb2RlKCFpc0Nvbm5lY3Rpb25Nb2RlKTtcbiAgICAgICAgICAgICAgICAgIHNldENvbm5lY3Rpb25Tb3VyY2UobnVsbCk7XG4gICAgICAgICAgICAgICAgICBpZighaXNDb25uZWN0aW9uTW9kZSkge1xuICAgICAgICAgICAgICAgICAgICBzaG93VG9hc3QoJ01vZG8gZGUgY29uZXhpw7NuIGFjdGl2YWRvLiBIYXogY2xpYyBlbiBlbCBlcXVpcG8gYWxpbWVudGFkb3IgKG9yaWdlbikuJywgJ2luZm8nKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IGJvcmRlciB0ZXh0LXhzIGZvbnQtYmxhY2sgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyIHNoYWRvdy1tZCAke1xuICAgICAgICAgICAgICAgICAgaXNDb25uZWN0aW9uTW9kZSBcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwIGJvcmRlci1hbWJlci00MDAgdGV4dC1zbGF0ZS05NTAgaG92ZXI6YmctYW1iZXItNDAwIGFuaW1hdGUtcHVsc2UnIFxuICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTM1MCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8TGluazIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IFxuICAgICAgICAgICAgICAgIHtpc0Nvbm5lY3Rpb25Nb2RlID8gJ0NvbmVjdGFuZG8uLi4nIDogJ1RyYXphciBDb25leGnDs24nfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LnByaW50KCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMzU1IGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYmxhY2sgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBjdXJzb3ItcG9pbnRlciBzaGFkb3ctbWQgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBJbXByaW1pciBQbGFub1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBob3ZlcjpiZy1zbGF0ZS04NTUgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQmFubmVyIGluZm9ybWF0aXZvIGRlIE1vZG8gQ29uZXhpw7NuICovfVxuICAgICAgICAgIHtpc0Nvbm5lY3Rpb25Nb2RlICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCBweC01IHB5LTIuNSB0ZXh0LXhzIHRleHQtY2VudGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yLjUgc2hyaW5rLTAgZm9udC1tb25vIGFuaW1hdGUtc2xpZGVEb3duIHNlbGVjdC1ub25lXCI+XG4gICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy00IGgtNCBmaWxsLWN1cnJlbnQgYW5pbWF0ZS1ib3VuY2VcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICB7Y29ubmVjdGlvblNvdXJjZSBcbiAgICAgICAgICAgICAgICAgID8gYFsxLzJdIE9yaWdlbiBzZWxlY2Npb25hZG86ICR7Y29ubmVjdGlvblNvdXJjZS5ub21icmV9LiBBaG9yYSBoYXogY2xpYyBlbiBlbCBlcXVpcG8gZGUgREVTVElOTyBwYXJhIGNvbmVjdGFybG8uYCBcbiAgICAgICAgICAgICAgICAgIDogJ01PRE8gQ09ORVhJw5NOIEFDVElWTzogSGF6IGNsaWMgZW4gZWwgZXF1aXBvIGRlIE9SSUdFTiAoYWxpbWVudGFkb3IgcHJpbmNpcGFsIC8gdGFibGVybyBkZSBkaXN0cmlidWNpw7NuKS4nfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0SXNDb25uZWN0aW9uTW9kZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgICBzZXRDb25uZWN0aW9uU291cmNlKG51bGwpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBweC0yIHB5LTAuNSBib3JkZXIgYm9yZGVyLXNsYXRlLTk1MC80MCByb3VuZGVkIHRleHQtWzlweF0gaG92ZXI6Ymctc2xhdGUtOTUwIGhvdmVyOnRleHQtYW1iZXItNTAwIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCB1cHBlcmNhc2VcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIENvbnRlbmlkbyBQcmluY2lwYWwgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBvdmVyZmxvdy1oaWRkZW4gbWluLWgtMFwiPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICB7LyogMS4gUEFMRVRBIERFIFPDjU1CT0xPUyAoSXpxdWllcmRhKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy01NiBiZy1zbGF0ZS05NTUvNjAgcC00IGJvcmRlci1yIGJvcmRlci1zbGF0ZS04NTAvNjAgZmxleCBmbGV4LWNvbCBzcGFjZS15LTQgc2VsZWN0LW5vbmUgc2hyaW5rLTAgbm8tcHJpbnRcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgZm9udC1tb25vIG1iLTJcIj5FcXVpcG9zICYgU8OtbWJvbG9zPC9oND5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVs5LjVweF0gdGV4dC1zbGF0ZS00NTAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICBIYXogY2xpYyBlbiBjdWFscXVpZXIgc8OtbWJvbG8gcGFyYSBpbnNlcnRhcmxvIGVuIGVsIHBsYW5vIGludGVyYWN0aXZvLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiBmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHByLTFcIj5cbiAgICAgICAgICAgICAgICB7Y2F0YWxvZ09mU3ltYm9scy5tYXAoc3ltID0+IChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAga2V5PXtzeW0udHlwZX1cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQWRkU3ltYm9sKHN5bS50eXBlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMi41IGJnLXNsYXRlLTkwMC80MCBob3ZlcjpiZy1zbGF0ZS04MDAvODAgYWN0aXZlOnNjYWxlLTk4IGJvcmRlciBib3JkZXItc2xhdGUtODUwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0cmFuc2l0aW9uLWFsbCB0ZXh0LWxlZnQgdGV4dC14cyBncm91cCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSBzaHJpbmstMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1zbGF0ZS05NTAgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTQ1NSBncm91cC1ob3Zlcjp0ZXh0LWFtYmVyLTUwMCBncm91cC1ob3ZlcjpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04NTUgdHJhbnNpdGlvbi1hbGwgc2hhZG93LWlubmVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3N5bS5pY29ufVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDAgZ3JvdXAtaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyB0cnVuY2F0ZVwiPntzeW0ubGFiZWx9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwIHRydW5jYXRlXCI+e3N5bS5kZXNjfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTg1MC82MCB0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwIGxlYWRpbmctbm9ybWFsIGZvbnQtc2Fuc1wiPlxuICAgICAgICAgICAgICAgIPCfkqEgPHN0cm9uZz5Db25zZWpvOjwvc3Ryb25nPiBBcnJhc3RyYSBsaWJyZW1lbnRlIGxvcyBzw61tYm9sb3MgdW5hIHZleiBjb2xvY2Fkb3MgZW4gZWwgbGllbnpvIHBhcmEgb3JnYW5pemFyIGVsIGRpYWdyYW1hLlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogMi4gTElFTlpPIChDZW50cm8pICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3ctaGlkZGVuIHJlbGF0aXZlIGZsZXggZmxleC1jb2wgYmctc2xhdGUtOTUwXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgIDxEaWFncmFtYVVuaWZpbGFyQmx1ZXByaW50XG4gICAgICAgICAgICAgICAgICBlbGVtZW50b3M9e2VsZW1lbnRvc31cbiAgICAgICAgICAgICAgICAgIGNvbXBhbnlOYW1lPXtjb21wYW55TmFtZX1cbiAgICAgICAgICAgICAgICAgIHByb2plY3ROYW1lPXtwcm9qZWN0TmFtZX1cbiAgICAgICAgICAgICAgICAgIGludGVyYWN0aXZlPXt0cnVlfVxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWROb2RlSWQ9e3NlbGVjdGVkTm9kZT8uaWR9XG4gICAgICAgICAgICAgICAgICBvbk5vZGVTZWxlY3Q9e2hhbmRsZU5vZGVDbGlja31cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogMy4gUEFORUwgREUgUFJPUElFREFERVMgKERlcmVjaGEpICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTgwIGJnLXNsYXRlLTk1NS82MCBwLTUgb3ZlcmZsb3cteS1hdXRvIHNocmluay0wIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1sIGJvcmRlci1zbGF0ZS04NTAvNjAgbm8tcHJpbnQgc2VsZWN0LW5vbmVcIj5cbiAgICAgICAgICAgICAge3NlbGVjdGVkTm9kZSA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNSBmbGV4LTEgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBGaWNoYSB0w6ljbmljYSBjYWJlY2VyYSAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04NTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1zbGF0ZS01NTAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiPkZJQ0hBIFTDiUNOSUNBPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOS41cHhdIGZvbnQtbW9ubyBmb250LWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1hbWJlci01MDAgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZE5vZGUudGlwb0VsZW1lbnRvfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS0xMDAgdHJhY2tpbmctd2lkZSBmb250LW1vbm8gdXBwZXJjYXNlIHRydW5jYXRlXCI+e3NlbGVjdGVkTm9kZS5ub21icmV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5LjVweF0gZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMFwiPklEOiB7c2VsZWN0ZWROb2RlLmlkfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIEZvcm11bGFyaW8gZGUgRWRpY2nDs24gKi99XG4gICAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlUHJvcGVydGllc30gY2xhc3NOYW1lPVwic3BhY2UteS00IHRleHQteHMgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQ1MCBmb250LWJvbGQgbWItMSB1cHBlcmNhc2UgdGV4dC1bOXB4XSB0cmFja2luZy13aWRlclwiPk5vbWJyZSBkZWwgRXF1aXBvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0Tm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXROb21icmUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBUYWJsZXJvIEdlbmVyYWwgQVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0zIHB5LTIgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9udC1zYW5zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDUwIGZvbnQtYm9sZCBtYi0xIHVwcGVyY2FzZSB0ZXh0LVs5cHhdIHRyYWNraW5nLXdpZGVyXCI+VGlwbyBkZSBFcXVpcG88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdFRpcG99XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdFRpcG8oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMyBweS0yIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvbnQtc2FucyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUQUJMRVJPXCI+VGFibGVybyBFbMOpY3RyaWNvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUUkFOU0ZPUk1BRE9SXCI+VHJhbnNmb3JtYWRvcjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiR0VORVJBRE9SXCI+R2VuZXJhZG9yIC8gUGxhbnRhPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUUkFOU0ZFUlwiPkFUUyAvIFRyYW5zZmVyZW5jaWE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlBVRVNUQV9USUVSUkFcIj5QdWVzdGEgYSBUaWVycmE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNVQkVTVEFDSU9OXCI+Q2VsZGEgU3ViZXN0YWNpw7NuPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJPVFJPXCI+T3RybyBFbGVtZW50bzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDUwIGZvbnQtYm9sZCBtYi0xIHVwcGVyY2FzZSB0ZXh0LVs5cHhdIHRyYWNraW5nLXdpZGVyXCI+VWJpY2FjacOzbiBGw61zaWNhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0VWJpY2FjaW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRVYmljYWNpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBDdWFydG8gZGUgQm9tYmFzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb250LXNhbnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBEcm9wZG93biBkZSBBbGltZW50YWNpw7NuIEplcsOhcnF1aWNvICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0b3JBbGltZW50YWRvckplcmFycXVpY29cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcHJveWVjdG9JZD17cHJveWVjdG9JZCB8fCBzZWxlY3RlZE5vZGU/LnByb3llY3RvSWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRhYmxlcm9BY3R1YWxJZD17c2VsZWN0ZWROb2RlPy5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudG9zTGlzdD17ZWxlbWVudG9zfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdEFsaW1lbnRhZG9Qb3J9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBzZXRFZGl0QWxpbWVudGFkb1Bvcih2YWwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkFsaW1lbnRhZG8gcG9yIChPcmlnZW4gZGUgRmx1am8pXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOaW5ndW5vIChPcmlnZW4gZGVsIFNpc3RlbWEpLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQ1MCBmb250LWJvbGQgbWItMSB1cHBlcmNhc2UgdGV4dC1bOXB4XSB0cmFja2luZy13aWRlclwiPkNhcGFjaWRhZCAvIEtWQTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdEt2YX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRLdmEoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDE1MCBrVkFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0zIHB5LTIgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9udC1zYW5zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDUwIGZvbnQtYm9sZCBtYi0xIHVwcGVyY2FzZSB0ZXh0LVs5cHhdIHRyYWNraW5nLXdpZGVyXCI+RmFzZXMgLyBQb2xvczwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdEZhc2VzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdEZhc2VzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAzRiAvIDQyUFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb250LXNhbnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDUwIGZvbnQtYm9sZCBtYi0xIHVwcGVyY2FzZSB0ZXh0LVs5cHhdIHRyYWNraW5nLXdpZGVyIGZvbnQtbW9ub1wiPk9ic2VydmFjaW9uZXM8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0T2JzZXJ2YWNpb25lc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0T2JzZXJ2YWNpb25lcyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm90YXMgZGVsIGVxdWlwby4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9XCIzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb250LXNhbnMgcmVzaXplLW5vbmUgdGV4dC1bMTFweF1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgaG92ZXI6YmctYW1iZXItNDAwIGFjdGl2ZTpzY2FsZS05OCB0cmFuc2l0aW9uLWFsbCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIHRleHQtY2VudGVyIGZvbnQtc2FucyBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNVwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBHdWFyZGFyIENhbWJpb3NcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBBY2Npb25lcyBSw6FwaWRhcyBkZWwgTm9kbyAoTmF2ZWdhciB5IEVsaW1pbmFyKSAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yLjUgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtODU1IG10LTYgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkTm9kZS50aXBvRWxlbWVudG8gPT09ICdUQUJMRVJPJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKGAvZW1wcmVzYS8ke3NlbGVjdGVkTm9kZS5lbXByZXNhSWQgfHwgY29tcGFueUlkfS90YWJsZXJvLyR7c2VsZWN0ZWROb2RlLmlkfWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ibGFjayBob3ZlcjpiZy13aGl0ZSBhY3RpdmU6c2NhbGUtOTggdHJhbnNpdGlvbi1hbGwgcHgtNCBweS0yLjUgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiB0ZXh0LXhzIGN1cnNvci1wb2ludGVyIHNoYWRvdy1tZFwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgQWJyaXIgRmljaGEgZGUgUG9sb3MgPEV4dGVybmFsTGluayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGVsZXRlRWxlbWVudH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctcmVkLTk1MC8yMCBob3ZlcjpiZy1yZWQtOTAwLzMwIGJvcmRlciBib3JkZXItcmVkLTkwMC80MCB0ZXh0LXJlZC00MDAgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIHB4LTQgcHktMi41IHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdGV4dC14cyBjdXJzb3ItcG9pbnRlciBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRWxpbWluYXIgZXF1aXBvIChBdGFqbzogVGVjbGEgU3VwciAvIERlbGV0ZSlcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IEVsaW1pbmFyIEVxdWlwbyAoU3VwcilcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTIwIHNwYWNlLXktMyBmbGV4LTEgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxJbmZvIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1zbGF0ZS03MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgbWF4LXctWzIwMHB4XSBmb250LXNhbnMgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgIEhheiBjbGljIHNvYnJlIGN1YWxxdWllciBlcXVpcG8gZW4gZWwgZGlhZ3JhbWEgdW5pZmlsYXIgcGFyYSB2ZXIgbyBlZGl0YXIgc3VzIGVzcGVjaWZpY2FjaW9uZXMgdMOpY25pY2FzLCBjYW1iaWFyIHN1cyBjb25leGlvbmVzIG8gZWxpbWluYXJsby5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFZlcnNpw7NuIGludmlzaWJsZSBwYXJhIGltcHJpbWlyIHF1ZSBzZSBhY3RpdmEgY29uIGVsIHByaW50IENTUyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHByaW50OmJsb2NrIGZpeGVkIGluc2V0LTAgYmctd2hpdGUgei01MCB3LXNjcmVlbiBoLXNjcmVlbiBwLTAgbS0wXCI+XG4gICAgICAgIDxEaWFncmFtYVVuaWZpbGFyQmx1ZXByaW50XG4gICAgICAgICAgZWxlbWVudG9zPXtlbGVtZW50b3N9XG4gICAgICAgICAgY29tcGFueU5hbWU9e2NvbXBhbnlOYW1lfVxuICAgICAgICAgIHByb2plY3ROYW1lPXtwcm9qZWN0TmFtZX1cbiAgICAgICAgICBpbnRlcmFjdGl2ZT17ZmFsc2V9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdfQ==