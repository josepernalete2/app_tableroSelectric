import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransferComponent.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { RefreshCw, Zap, Shield, Layers, Activity, Gauge, Camera, Printer, Save, Edit3, Check, AlertTriangle, Sliders, Cpu, ArrowRightLeft, CheckCircle2, Clock, Settings, Info, RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
import SelectorAlimentadorJerarquico from "/src/components/SelectorAlimentadorJerarquico.jsx?t=1790792337841";
import MetrologiaElectricaSection from "/src/components/MetrologiaElectricaSection.jsx";
import DualPhotoUploader from "/src/components/DualPhotoUploader.jsx?t=1790793566895";
import { TENSIONES_COVENIN_159_BT, TENSIONES_COVENIN_TODAS, FRECUENCIAS_NORMALIZADAS, POLOS_TRANSFERENCIA } from "/src/utils/constants.js";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/TransferComponent.jsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function TransferComponent({ transferData, elementoData, onUpdate, readOnly = false }) {
	_s();
	const data = transferData || elementoData;
	const { alert: customAlert, confirm: customConfirm } = useConfirm();
	const companies = useStore((state) => state.companies || []);
	const [isEditing, setIsEditing] = useState(false);
	const { addElementoUnifilar, showToast } = useStore();
	// Estados para creación rápida en línea de fuentes
	const [quickCreateOpen, setQuickCreateOpen] = useState(false);
	const [quickCreateTargetField, setQuickCreateTargetField] = useState("fuenteNormal");
	const [newSourceTipo, setNewSourceTipo] = useState("TRANSFORMADOR");
	const [newSourceNombre, setNewSourceNombre] = useState("");
	const [newSourceUbicacion, setNewSourceUbicacion] = useState("Sala Eléctrica");
	const [newSourceCapacidad, setNewSourceCapacidad] = useState("");
	const [newSourceTension, setNewSourceTension] = useState("208/120 V");
	// Lista de elementos de jerarquía del proyecto para alimentar los selectores (completa con todos los activos)
	const projectElements = useMemo(() => {
		const list = [];
		const compId = data?.empresaId || data?.companyId;
		const company = companies.find((c) => c.id === compId);
		const extractFromProject = (p) => {
			if (p.elementosUnifilares) list.push(...p.elementosUnifilares);
			if (p.tableros) list.push(...p.tableros);
			if (p.subestaciones) list.push(...p.subestaciones);
			if (p.inspeccionesSubestacion) list.push(...p.inspeccionesSubestacion);
			if (p.puntosMedicion) list.push(...p.puntosMedicion);
			if (p.ccmList) list.push(...p.ccmList);
		};
		if (!company) {
			companies.forEach((c) => {
				if (c.elementosUnifilares) list.push(...c.elementosUnifilares);
				if (c.proyectos) c.proyectos.forEach(extractFromProject);
			});
		} else {
			if (company.elementosUnifilares) list.push(...company.elementosUnifilares);
			if (company.proyectos) company.proyectos.forEach(extractFromProject);
		}
		// Deduplicar por ID y excluir al propio elemento transfer
		const seen = new Set();
		return list.filter((e) => {
			if (!e || !e.id || e.id === data?.id || seen.has(e.id)) return false;
			seen.add(e.id);
			return true;
		});
	}, [companies, data]);
	// Handler para guardar nueva fuente rápida
	const handleCreateQuickSource = async (e) => {
		if (e) e.preventDefault();
		if (!newSourceNombre.trim()) {
			showToast("Por favor introduce un nombre para la fuente.", "error");
			return;
		}
		const targetProjId = data.proyectoId || companies.find((c) => c.id === (data.empresaId || data.companyId))?.proyectos?.[0]?.id;
		const payload = {
			nombre: newSourceNombre.trim(),
			tipoElemento: newSourceTipo,
			ubicacion: newSourceUbicacion.trim() || "Sala Eléctrica",
			datosTecnicos: {
				kva: newSourceCapacidad.trim(),
				amperaje: newSourceCapacidad.trim(),
				tensionNominal: newSourceTension
			}
		};
		const res = await addElementoUnifilar(targetProjId, payload);
		if (res && res.success) {
			const createdElem = res.elemento;
			const createdName = createdElem.nombre || newSourceNombre;
			if (quickCreateTargetField === "fuenteNormal") {
				handleDtChange("fuenteNormalNombre", createdName);
				if (newSourceTension) handleDtChange("fuenteNormalTension", newSourceTension);
			} else {
				handleDtChange("fuenteEmergenciaNombre", createdName);
				if (newSourceTension) handleDtChange("fuenteEmergenciaTension", newSourceTension);
			}
			showToast(`Fuente "${createdName}" creada y asignada exitosamente.`, "success");
			setQuickCreateOpen(false);
		} else {
			showToast(res?.error || "Error al crear la fuente.", "error");
		}
	};
	// Estados locales editables - Sin datos demo quemados
	const [nombre, setNombre] = useState(data?.nombre || "");
	const [ubicacion, setUbicacion] = useState(data?.ubicacion || "");
	const [observaciones, setObservaciones] = useState(data?.observacionesGenerales || data?.datosTecnicos?.observacionTransferencia || "");
	// Datos Técnicos JSON
	const [dt, setDt] = useState(data?.datosTecnicos || {});
	// Foto
	const [fotoBlob, setFotoBlob] = useState(data?.fotoBlob || null);
	const [fotoSrc, setFotoSrc] = useState(data?.foto || null);
	const [previewUrl, setPreviewUrl] = useState(null);
	// Sincronizar si cambian los props
	useEffect(() => {
		if (data) {
			setNombre(data.nombre || "");
			setUbicacion(data.ubicacion || "");
			setObservaciones(data.observacionesGenerales || data.datosTecnicos?.observacionTransferencia || "");
			setDt(data.datosTecnicos || {});
			setFotoBlob(data.fotoBlob || null);
			setFotoSrc(data.foto || null);
		}
	}, [data]);
	// Fallback si no hay datos
	if (!data) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center p-12 text-slate-400 font-sans",
			children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-12 h-12 text-slate-600 mx-auto mb-3 animate-spin" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 164,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm",
				children: "No se han encontrado datos para esta unidad de Transferencia."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 165,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 163,
			columnNumber: 7
		}, this);
	}
	const handleDtChange = (key, value) => {
		if (readOnly) return;
		setDt((prev) => ({
			...prev,
			[key]: value
		}));
	};
	const handleNestedDtChange = (parentKey, key, value) => {
		if (readOnly) return;
		setDt((prev) => ({
			...prev,
			[parentKey]: {
				...prev[parentKey] || {},
				[key]: value
			}
		}));
	};
	const handleSave = () => {
		if (readOnly) return;
		if (onUpdate) {
			onUpdate({
				...data,
				nombre,
				ubicacion,
				observacionesGenerales: observaciones,
				fotoBlob,
				foto: fotoSrc,
				datosTecnicos: {
					...dt,
					observacionTransferencia: observaciones
				}
			});
		}
		setIsEditing(false);
	};
	const handleLimpiarFormulario = async () => {
		if (readOnly) return;
		const confirmed = await customConfirm("¿Deseas reiniciar todos los campos de esta transferencia a valores en blanco?");
		if (!confirmed) return;
		setNombre("");
		setUbicacion("");
		setObservaciones("");
		setDt({});
		setFotoBlob(null);
		setFotoSrc(null);
		if (previewUrl) URL.revokeObjectURL(previewUrl);
		setPreviewUrl(null);
	};
	// Valores de configuración operativa
	const modoOperativo = dt.modoOperativo || dt.tipoTransferenciaOperativa || (dt.tipoTransferencia?.toUpperCase().includes("MANUAL") || dt.tipoTransferencia?.toUpperCase().includes("MTS") ? "MTS" : "ATS");
	const estadoServicio = dt.estadoServicio || "En Servicio";
	const tipoTransicion = dt.tipoTransicion || "ABIERTA";
	const tipoEnclavamiento = dt.tipoEnclavamiento || "MECANICO_ELECTRICO";
	const polos = dt.polos || "4P";
	const frecuencia = dt.frecuencia || "60 Hz";
	// Valores de Fuente Normal (Fuente A)
	const fuenteNormalNombre = dt.fuenteNormalNombre || dt.alimentacionGenerador1 || dt.alimentacionCorpoelec || "";
	const fuenteNormalTension = dt.fuenteNormalTension || "";
	const fuenteNormalAmperaje = dt.fuenteNormalAmperaje || dt.amperaje || "";
	const fuenteNormalConductor = dt.fuenteNormalConductor || dt.conductorFuenteNormal || "";
	// Valores de Fuente Emergencia (Fuente B)
	const fuenteEmergenciaNombre = dt.fuenteEmergenciaNombre || dt.alimentacionGenerador2 || dt.alimentacionTransfDomosa || "";
	const fuenteEmergenciaTension = dt.fuenteEmergenciaTension || "";
	const fuenteEmergenciaAmperaje = dt.fuenteEmergenciaAmperaje || dt.amperaje || "";
	const fuenteEmergenciaConductor = dt.fuenteEmergenciaConductor || dt.conductorFuenteEmergencia || "";
	// Salida a Carga
	const salidaCargaNombre = dt.salidaCargaNombre || dt.carga || "";
	const salidaCargaConductor = dt.salidaCargaConductor || "";
	const neutroConductor = dt.neutroConductor || dt.neutro || "";
	const tierraConductor = dt.tierraConductor || dt.tierra || "";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `max-w-6xl mx-auto space-y-6 animate-fade-in font-sans pb-16 print-card print:p-0 print:m-0 ${readOnly ? "pointer-events-none opacity-95" : ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-center justify-between gap-4 no-print bg-slate-950/80 backdrop-blur-md p-4 rounded-2xl border border-slate-800 shadow-xl",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "p-2.5 bg-gradient-to-br from-amber-500/20 to-amber-600/10 border border-amber-500/30 rounded-xl",
						children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-6 h-6 text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 255,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 254,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/10 text-amber-400 border border-amber-500/20",
								children: modoOperativo === "ATS" ? "🔄 TRANSFERENCIA AUTOMÁTICA (ATS)" : "🔀 TRANSFERENCIA MANUAL (MTS)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 259,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: `px-2 py-0.5 rounded text-[10px] font-bold ${estadoServicio === "En Servicio" ? "bg-emerald-950 text-emerald-400 border border-emerald-800" : "bg-red-950 text-red-400 border border-red-800"}`,
								children: estadoServicio
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 262,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono text-xs font-bold text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800",
								children: ["ID: ", data.id]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 265,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 258,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-lg font-black text-slate-100 mt-0.5",
						children: nombre || "Unidad de Transferencia"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 269,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 257,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 253,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => window.print(),
						className: "px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded-xl transition-all cursor-pointer flex items-center gap-2 text-xs font-bold shadow-sm",
						title: "Guardar como PDF o Imprimir Ficha",
						children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 281,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline",
							children: "Guardar PDF"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 282,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 276,
						columnNumber: 11
					}, this), !readOnly && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [isEditing && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleLimpiarFormulario,
						className: "px-3.5 py-2 bg-slate-900 hover:bg-red-950/60 text-slate-400 hover:text-red-400 border border-slate-800 hover:border-red-800 rounded-xl transition-all font-bold text-xs cursor-pointer flex items-center gap-1.5",
						title: "Reiniciar todos los campos a blanco",
						children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 294,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline",
							children: "Limpiar Formulario"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 295,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 288,
						columnNumber: 17
					}, this), isEditing ? /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleSave,
						className: "px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl transition-all font-black text-xs cursor-pointer flex items-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95",
						children: [/* @__PURE__ */ _jsxDEV(Save, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 304,
							columnNumber: 19
						}, this), " Guardar Cambios"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 300,
						columnNumber: 17
					}, this) : /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setIsEditing(true),
						className: "px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl transition-all font-black text-xs cursor-pointer flex items-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95",
						children: [/* @__PURE__ */ _jsxDEV(Edit3, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 19
						}, this), " Editar Transferencia"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 307,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 275,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 252,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950 border-2 border-slate-800 rounded-2xl overflow-hidden shadow-2xl print:border-black print:bg-white print:text-black",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-gradient-to-r from-slate-900 via-slate-900 to-slate-850 border-b-2 border-slate-800 p-4 print:bg-gray-100 print:border-black",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col md:flex-row md:items-center justify-between gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-mono font-bold tracking-widest text-amber-400 uppercase",
								children: ["SISTEMA DE CONMUTACIÓN DE POTENCIA • ", modoOperativo === "ATS" ? "AUTOMATIC TRANSFER SWITCH" : "MANUAL TRANSFER SWITCH"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 328,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-black text-slate-100 tracking-wide uppercase font-mono print:text-black",
								children: isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: nombre,
									onChange: (e) => setNombre(e.target.value),
									placeholder: "Ej. ATS-1 - Transferencia Principal Sótano",
									className: "bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 w-full focus:outline-none focus:border-amber-500 text-slate-100 font-bold placeholder-slate-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 333,
									columnNumber: 19
								}, this) : nombre || "ATS - Transferencia"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 327,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-mono font-bold text-slate-400",
									children: "Capacidad Nominal:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 347,
									columnNumber: 15
								}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: dt.amperaje || dt.capacidadAmperios || "",
									onChange: (e) => handleDtChange("amperaje", e.target.value),
									placeholder: "Ej. 3200 A",
									className: "bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs font-mono font-bold text-amber-400 text-center w-28"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV("span", {
									className: "px-3 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-lg font-mono font-black text-sm",
									children: dt.amperaje || dt.capacidadAmperios ? `${dt.amperaje || dt.capacidadAmperios}` : "—"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 357,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 346,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 325,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-800 border-b-2 border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "lg:col-span-5 p-5 space-y-4 bg-slate-900/40",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-black text-slate-300 uppercase tracking-wider flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Cpu, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 371,
									columnNumber: 15
								}, this), "Especificaciones Constructivas del ATS / MTS"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 370,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3 text-xs font-mono",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between items-center bg-slate-900/80 p-2.5 rounded-xl border border-slate-800",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400 font-bold",
											children: "UBICACIÓN:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 377,
											columnNumber: 17
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: ubicacion,
											onChange: (e) => setUbicacion(e.target.value),
											placeholder: "Ej. Sala Técnica / Sótano",
											className: "bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-right text-xs placeholder-slate-600"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 379,
											columnNumber: 19
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-200 font-semibold",
											children: ubicacion || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 387,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 376,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between items-center bg-slate-900/80 p-2.5 rounded-xl border border-slate-800",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400 font-bold",
											children: "MODELO / MARCA:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 392,
											columnNumber: 17
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: dt.modelo || "",
											onChange: (e) => handleDtChange("modelo", e.target.value),
											placeholder: "Ej. Socomec ATyS / YUYE-YES1",
											className: "bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-right text-xs placeholder-slate-600"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 394,
											columnNumber: 19
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-200 font-semibold",
											children: dt.modelo || dt.tipoTransferencia || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 402,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 391,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 space-y-1",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-400 block font-bold",
											children: "TENSIÓN NOMINAL (COVENIN 159):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 408,
											columnNumber: 17
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
											value: dt.tensionNominal || "",
											onChange: (e) => handleDtChange("tensionNominal", e.target.value),
											className: "w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs font-bold",
											children: [/* @__PURE__ */ _jsxDEV("option", {
												value: "",
												children: "-- Seleccionar Tensión Normalizada --"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 415,
												columnNumber: 21
											}, this), TENSIONES_COVENIN_159_BT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
												value: v,
												children: v
											}, v, false, {
												fileName: _jsxFileName,
												lineNumber: 417,
												columnNumber: 23
											}, this))]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 410,
											columnNumber: 19
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-emerald-400 font-bold text-sm block mt-0.5",
											children: dt.tensionNominal || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 421,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 407,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-2.5",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-900/80 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-slate-400 block font-bold",
												children: "N° DE POLOS:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 428,
												columnNumber: 19
											}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
												value: polos,
												onChange: (e) => handleDtChange("polos", e.target.value),
												className: "w-full mt-1 bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs font-bold",
												children: POLOS_TRANSFERENCIA.map((p) => /* @__PURE__ */ _jsxDEV("option", {
													value: p,
													children: p
												}, p, false, {
													fileName: _jsxFileName,
													lineNumber: 436,
													columnNumber: 25
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 430,
												columnNumber: 21
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-amber-400 font-bold text-sm block mt-0.5",
												children: polos
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 440,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 427,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-900/80 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-slate-400 block font-bold",
												children: "FRECUENCIA:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 445,
												columnNumber: 19
											}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
												value: frecuencia,
												onChange: (e) => handleDtChange("frecuencia", e.target.value),
												className: "w-full mt-1 bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs font-bold",
												children: FRECUENCIAS_NORMALIZADAS.map((f) => /* @__PURE__ */ _jsxDEV("option", {
													value: f,
													children: f
												}, f, false, {
													fileName: _jsxFileName,
													lineNumber: 453,
													columnNumber: 25
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 447,
												columnNumber: 21
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-sky-400 font-bold text-sm block mt-0.5",
												children: frecuencia
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 457,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 444,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 426,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: `flex justify-between items-center p-2.5 rounded-xl border ${modoOperativo === "MTS" ? "bg-slate-950/40 border-slate-850 opacity-60" : "bg-slate-900/80 border-slate-800"}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-col",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-400 font-bold",
												children: "CONTROLADOR ATS:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 465,
												columnNumber: 19
											}, this), modoOperativo === "MTS" && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[9px] text-amber-500 font-semibold",
												children: "(No Aplica en modo Manual)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 467,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 464,
											columnNumber: 17
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											disabled: modoOperativo === "MTS",
											value: modoOperativo === "MTS" ? "No Aplica (Transferencia Manual)" : dt.controladorAts || "",
											onChange: (e) => handleDtChange("controladorAts", e.target.value),
											placeholder: "Ej. Deep Sea DSE 334 / ComAp",
											className: "bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-right text-xs placeholder-slate-600 disabled:bg-slate-900 disabled:text-slate-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 471,
											columnNumber: 19
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-300 font-semibold",
											children: modoOperativo === "MTS" ? "No Aplica (Transferencia Manual)" : dt.controladorAts || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 480,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 463,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 375,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 369,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "lg:col-span-7 p-5 space-y-4 bg-slate-950/60",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-black text-slate-200 uppercase tracking-wider flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 492,
										columnNumber: 17
									}, this), "Doble Fuente de Alimentación de la Transferencia"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 491,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800",
									children: "Jerarquía Activa"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 495,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 490,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-3.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-gradient-to-b from-emerald-950/30 to-slate-900/90 border border-emerald-500/30 rounded-xl p-3.5 space-y-2.5 shadow-lg relative overflow-hidden",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between border-b border-emerald-500/20 pb-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/40",
												children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 506,
													columnNumber: 21
												}, this), "Fuente Normal (Prioridad 1)"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 505,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-mono font-bold text-emerald-400",
												children: "RED"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 509,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 504,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[9px] font-bold uppercase tracking-wider text-slate-400 mb-1",
											children: "Origen / Alimentador Normal:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 513,
											columnNumber: 19
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV(SelectorAlimentadorJerarquico, {
											value: fuenteNormalNombre,
											onChange: (val) => handleDtChange("fuenteNormalNombre", val),
											proyectoId: data.proyectoId,
											tableroActualId: data.id,
											elementosList: projectElements,
											placeholder: "Seleccionar Subestación, Transformador...",
											className: "text-xs",
											label: "",
											allowQuickCreate: true,
											onQuickCreate: () => {
												setQuickCreateTargetField("fuenteNormal");
												setNewSourceTipo("TRANSFORMADOR");
												setNewSourceNombre(`Transformador Alimentador ${projectElements.filter((e) => e.tipoElemento === "TRANSFORMADOR").length + 1}`);
												setNewSourceCapacidad(dt.amperaje || "500");
												setNewSourceTension(dt.tensionNominal || "208/120 V");
												setQuickCreateOpen(true);
											}
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 517,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV("p", {
											className: "font-bold text-slate-100 text-xs font-mono truncate",
											title: fuenteNormalNombre,
											children: fuenteNormalNombre || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 537,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 512,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-2 gap-2 text-[10px] font-mono pt-1 border-t border-slate-800/80",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 block font-bold",
												children: "TENSIÓN:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 545,
												columnNumber: 21
											}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: fuenteNormalTension,
												onChange: (e) => handleDtChange("fuenteNormalTension", e.target.value),
												placeholder: "Ej. 208/120V",
												className: "w-full bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-slate-100 text-[10px]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 547,
												columnNumber: 23
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-300 font-bold",
												children: fuenteNormalTension || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 555,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 544,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 block font-bold",
												children: "CAPACIDAD BREAKER:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 559,
												columnNumber: 21
											}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: fuenteNormalAmperaje,
												onChange: (e) => handleDtChange("fuenteNormalAmperaje", e.target.value),
												placeholder: "Ej. 3200 A",
												className: "w-full bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-slate-100 text-[10px]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 561,
												columnNumber: 23
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-300 font-bold",
												children: fuenteNormalAmperaje || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 569,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 558,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 543,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] font-mono pt-1 border-t border-slate-800/80",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 block font-bold",
												children: "CONDUCTOR DE ACOMETIDA:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 575,
												columnNumber: 19
											}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: fuenteNormalConductor,
												onChange: (e) => handleDtChange("fuenteNormalConductor", e.target.value),
												placeholder: "Ej. 2(3X500 MCM)",
												className: "w-full mt-1 bg-slate-900 border border-slate-700 rounded px-2 py-0.5 text-slate-100 text-xs"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 577,
												columnNumber: 21
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-200 font-bold block mt-0.5",
												children: fuenteNormalConductor || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 585,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 574,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 503,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-gradient-to-b from-amber-950/30 to-slate-900/90 border border-amber-500/30 rounded-xl p-3.5 space-y-2.5 shadow-lg relative overflow-hidden",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between border-b border-amber-500/20 pb-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-400 border border-amber-500/40",
												children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-amber-400 animate-pulse" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 594,
													columnNumber: 21
												}, this), "Fuente Emergencia (Prioridad 2)"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 593,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-mono font-bold text-amber-400",
												children: "GEN"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 597,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 592,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[9px] font-bold uppercase tracking-wider text-slate-400 mb-1",
											children: "Origen / Planta Generador:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 601,
											columnNumber: 19
										}, this), isEditing ? /* @__PURE__ */ _jsxDEV(SelectorAlimentadorJerarquico, {
											value: fuenteEmergenciaNombre,
											onChange: (val) => handleDtChange("fuenteEmergenciaNombre", val),
											proyectoId: data.proyectoId,
											tableroActualId: data.id,
											elementosList: projectElements,
											placeholder: "Seleccionar Generador / Planta...",
											className: "text-xs",
											label: "",
											allowQuickCreate: true,
											onQuickCreate: () => {
												setQuickCreateTargetField("fuenteEmergencia");
												setNewSourceTipo("GENERADOR");
												setNewSourceNombre(`Generador Emergencia ${projectElements.filter((e) => e.tipoElemento === "GENERADOR").length + 1}`);
												setNewSourceCapacidad(dt.amperaje || "500");
												setNewSourceTension(dt.tensionNominal || "208/120 V");
												setQuickCreateOpen(true);
											}
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 605,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV("p", {
											className: "font-bold text-slate-100 text-xs font-mono truncate",
											title: fuenteEmergenciaNombre,
											children: fuenteEmergenciaNombre || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 625,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 600,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-2 gap-2 text-[10px] font-mono pt-1 border-t border-slate-800/80",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 block font-bold",
												children: "TENSIÓN:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 633,
												columnNumber: 21
											}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: fuenteEmergenciaTension,
												onChange: (e) => handleDtChange("fuenteEmergenciaTension", e.target.value),
												placeholder: "Ej. 208/120V",
												className: "w-full bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-slate-100 text-[10px]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 635,
												columnNumber: 23
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-300 font-bold",
												children: fuenteEmergenciaTension || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 643,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 632,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 block font-bold",
												children: "CAPACIDAD BREAKER:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 647,
												columnNumber: 21
											}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: fuenteEmergenciaAmperaje,
												onChange: (e) => handleDtChange("fuenteEmergenciaAmperaje", e.target.value),
												placeholder: "Ej. 3200 A",
												className: "w-full bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-slate-100 text-[10px]"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 649,
												columnNumber: 23
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-300 font-bold",
												children: fuenteEmergenciaAmperaje || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 657,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 646,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 631,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] font-mono pt-1 border-t border-slate-800/80",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 block font-bold",
												children: "CONDUCTOR DE ACOMETIDA:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 663,
												columnNumber: 19
											}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: fuenteEmergenciaConductor,
												onChange: (e) => handleDtChange("fuenteEmergenciaConductor", e.target.value),
												placeholder: "Ej. 2(3X500 MCM)",
												className: "w-full mt-1 bg-slate-900 border border-slate-700 rounded px-2 py-0.5 text-slate-100 text-xs"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 665,
												columnNumber: 21
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-200 font-bold block mt-0.5",
												children: fuenteEmergenciaConductor || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 673,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 662,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 591,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 500,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 489,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 366,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-900/90 border-b-2 border-slate-800",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col md:flex-row md:items-center justify-between gap-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 font-mono",
										children: [/* @__PURE__ */ _jsxDEV(Sliders, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 691,
											columnNumber: 17
										}, this), "Modo de Operación:"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 690,
										columnNumber: 15
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => handleDtChange("modoOperativo", "ATS"),
											className: `px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${modoOperativo === "ATS" ? "bg-amber-500 text-slate-950 shadow-md" : "bg-slate-900 text-slate-400 border border-slate-700 hover:text-slate-200"}`,
											children: "🔄 Automática (ATS)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 696,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => handleDtChange("modoOperativo", "MTS"),
											className: `px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${modoOperativo === "MTS" ? "bg-amber-500 text-slate-950 shadow-md" : "bg-slate-900 text-slate-400 border border-slate-700 hover:text-slate-200"}`,
											children: "🔀 Manual (MTS)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 707,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 695,
										columnNumber: 17
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "px-3 py-1 bg-slate-900 text-amber-400 border border-amber-500/30 rounded-lg text-xs font-black font-mono",
										children: modoOperativo === "ATS" ? "🔄 AUTOMÁTICA (ATS)" : "🔀 MANUAL (MTS)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 720,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 689,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 font-mono",
										children: [/* @__PURE__ */ _jsxDEV(Shield, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 729,
											columnNumber: 17
										}, this), "Estado de Operatividad:"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 728,
										columnNumber: 15
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: estadoServicio,
										onChange: (e) => handleDtChange("estadoServicio", e.target.value),
										className: "bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 font-bold focus:outline-none focus:border-amber-500 cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "En Servicio",
											children: "🟢 En Servicio"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 738,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("option", {
											value: "Fuera de Servicio",
											children: "🔴 Fuera de Servicio"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 739,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 733,
										columnNumber: 17
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: `px-3 py-1 rounded-lg text-xs font-bold font-mono ${estadoServicio === "En Servicio" ? "bg-emerald-950 text-emerald-400 border border-emerald-800" : "bg-red-950 text-red-400 border border-red-800"}`,
										children: estadoServicio === "En Servicio" ? "🟢 En Servicio" : "🔴 Fuera de Servicio"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 742,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 727,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 font-mono",
										children: [/* @__PURE__ */ _jsxDEV(ArrowRightLeft, { className: "w-4 h-4 text-sky-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 755,
											columnNumber: 17
										}, this), "Transición:"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 754,
										columnNumber: 15
									}, this), isEditing ? /* @__PURE__ */ _jsxDEV("select", {
										value: tipoTransicion,
										onChange: (e) => handleDtChange("tipoTransicion", e.target.value),
										className: "bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 font-bold focus:outline-none focus:border-amber-500 cursor-pointer",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "ABIERTA",
												children: "Abierta (Break-Before-Make / I-0-II)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 764,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "CERRADA",
												children: "Cerrada (Make-Before-Break / Sin Corte)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 765,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "RETARDADA",
												children: "Retardada (Pausa Programada en Cero)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 766,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 759,
										columnNumber: 17
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "px-3 py-1 bg-slate-900 text-sky-400 border border-sky-500/30 rounded-lg text-xs font-bold font-mono",
										children: tipoTransicion === "CERRADA" ? "⚡ Cerrada" : tipoTransicion === "RETARDADA" ? "⏱️ Retardada" : "🔌 Abierta"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 769,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 753,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 686,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 685,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-950 border-b-2 border-slate-800",
						children: /* @__PURE__ */ _jsxDEV(MetrologiaElectricaSection, {
							mediciones: dt.mediciones || {},
							onChange: (nuevasMediciones) => handleDtChange("mediciones", nuevasMediciones),
							readOnly: !isEditing,
							titulo: "Parámetros de Medición en Barra de Carga Común (COVENIN 159)",
							subtitulo: "Tensiones L-L, L-N y 5 canales de corriente (Fases A, B, C, Neutro N y Tierra PE)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 784,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 783,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-5 space-y-4 border-b-2 border-slate-800 bg-slate-950",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-xs font-black text-slate-200 uppercase tracking-wider flex items-center gap-2 font-mono",
							children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 798,
								columnNumber: 13
							}, this), "Líneas de Salida Conmutada hacia la Carga del Proyecto"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 797,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 space-y-1.5",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-400 font-bold uppercase block",
											children: "CARGA O TABLERO ALIMENTADO:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 804,
											columnNumber: 15
										}, this),
										isEditing ? /* @__PURE__ */ _jsxDEV(SelectorAlimentadorJerarquico, {
											value: salidaCargaNombre,
											onChange: (val) => handleDtChange("salidaCargaNombre", val),
											proyectoId: data.proyectoId,
											tableroActualId: data.id,
											elementosList: projectElements,
											placeholder: "Seleccionar Tablero Destino...",
											className: "text-xs",
											label: ""
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 808,
											columnNumber: 17
										}, this) : /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-100 font-black text-sm truncate",
											title: salidaCargaNombre,
											children: salidaCargaNombre || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 819,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "pt-1",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-slate-500 block",
												children: "Conductor Salida:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 824,
												columnNumber: 17
											}, this), isEditing ? /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: salidaCargaConductor,
												onChange: (e) => handleDtChange("salidaCargaConductor", e.target.value),
												placeholder: "Ej. 2(3X500 MCM)",
												className: "w-full bg-slate-950 border border-slate-700 rounded px-2 py-0.5 text-slate-100 text-xs mt-0.5"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 826,
												columnNumber: 19
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-300 font-bold text-xs",
												children: salidaCargaConductor || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 834,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 823,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 803,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 space-y-1.5",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-cyan-400 font-bold uppercase block",
											children: "BARRA Y CONDUCTOR DE NEUTRO (N):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 840,
											columnNumber: 15
										}, this),
										isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: neutroConductor,
											onChange: (e) => handleDtChange("neutroConductor", e.target.value),
											placeholder: "Ej. 1X500 MCM (Barra directa)",
											className: "w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 844,
											columnNumber: 17
										}, this) : /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-200 font-bold text-xs",
											children: neutroConductor || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 852,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 block",
											children: "Configuración: Barra sólida pasante"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 854,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 839,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 space-y-1.5",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-emerald-400 font-bold uppercase block",
											children: "TIERRA DE PROTECCIÓN (PE / SPT):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 858,
											columnNumber: 15
										}, this),
										isEditing ? /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: tierraConductor,
											onChange: (e) => handleDtChange("tierraConductor", e.target.value),
											placeholder: "Ej. 1X4/0 AWG (SPT)",
											className: "w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 text-xs"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 862,
											columnNumber: 17
										}, this) : /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-200 font-bold text-xs",
											children: tierraConductor || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 870,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 block",
											children: "Conexión directa a barra de equipotencialidad"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 872,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 857,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 802,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 796,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-800 bg-slate-900/30",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "lg:col-span-7 p-5 space-y-2.5",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-black text-slate-300 uppercase tracking-wider flex items-center gap-2 font-mono",
								children: [/* @__PURE__ */ _jsxDEV(Info, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 885,
									columnNumber: 15
								}, this), "Observaciones Técnicas y Diagnóstico"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 884,
								columnNumber: 13
							}, this), isEditing ? /* @__PURE__ */ _jsxDEV("textarea", {
								rows: 5,
								value: observaciones,
								onChange: (e) => setObservaciones(e.target.value),
								placeholder: "Indique notas de conmutación, secuencias de arranque de generadores, hallazgos, etc.",
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-slate-100 font-mono focus:outline-none focus:border-amber-500 placeholder-slate-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 890,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 bg-slate-950/70 rounded-xl border border-slate-800 text-xs font-mono text-slate-300 leading-relaxed whitespace-pre-wrap",
								children: observaciones || "Sin observaciones registradas para esta transferencia."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 898,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 883,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "lg:col-span-5 p-5",
							children: /* @__PURE__ */ _jsxDEV(DualPhotoUploader, {
								fotoBlob,
								fotoSrc,
								previewUrl,
								onImageSelected: (file) => {
									setFotoBlob(file);
									const reader = new FileReader();
									reader.onloadend = () => {
										setFotoSrc(reader.result);
									};
									reader.readAsDataURL(file);
									if (previewUrl) URL.revokeObjectURL(previewUrl);
									setPreviewUrl(URL.createObjectURL(file));
								},
								onRemove: () => {
									setFotoBlob(null);
									setFotoSrc(null);
									if (previewUrl) URL.revokeObjectURL(previewUrl);
									setPreviewUrl(null);
								},
								readOnly: !isEditing,
								label: "Fotografía de la Transferencia",
								sublabel: "Cámara en vivo o selección de galería"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 906,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 905,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 880,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 322,
				columnNumber: 7
			}, this),
			quickCreateOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm no-print animate-in fade-in",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full max-w-md bg-slate-900 border border-slate-750 rounded-2xl shadow-2xl p-5 space-y-4 animate-in zoom-in-95",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between border-b border-slate-800 pb-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30",
								children: /* @__PURE__ */ _jsxDEV(Zap, { className: "w-5 h-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 943,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 942,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-black uppercase text-slate-100 font-mono",
								children: "Crear Fuente de Alimentación"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 946,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-400 font-sans",
								children: quickCreateTargetField === "fuenteNormal" ? "Fuente Normal (Prioridad 1)" : "Fuente Emergencia (Prioridad 2)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 949,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 945,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 941,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setQuickCreateOpen(false),
							className: "p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 959,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 954,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 940,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCreateQuickSource,
						className: "space-y-3.5 text-xs font-mono",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase mb-1",
								children: "Tipo de Fuente"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 965,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: newSourceTipo,
								onChange: (e) => {
									const t = e.target.value;
									setNewSourceTipo(t);
									if (t === "GENERADOR") setNewSourceNombre(`Generador Emergencia ${projectElements.filter((el) => el.tipoElemento === "GENERADOR").length + 1}`);
									else if (t === "TRANSFORMADOR") setNewSourceNombre(`Transformador Principal ${projectElements.filter((el) => el.tipoElemento === "TRANSFORMADOR").length + 1}`);
									else if (t === "SUBESTACION") setNewSourceNombre(`Subestación ${projectElements.filter((el) => el.tipoElemento === "SUBESTACION").length + 1}`);
									else if (t === "PUNTO_SUMINISTRO" || t === "PUNTO_MEDICION") setNewSourceNombre("Punto de Suministro CORPOELEC");
								},
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 font-bold focus:outline-none focus:border-amber-500 cursor-pointer",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "TRANSFORMADOR",
										children: "Transformador"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 980,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "GENERADOR",
										children: "Generador / Planta Eléctrica"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 981,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "SUBESTACION",
										children: "Subestación / Celda MT"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 982,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "PUNTO_SUMINISTRO",
										children: "Punto de Suministro / Acometida"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 983,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "TABLERO",
										children: "Tablero de Distribución"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 984,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 968,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 964,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase mb-1",
								children: "Nombre / Identificador de la Fuente"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 989,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								required: true,
								value: newSourceNombre,
								onChange: (e) => setNewSourceNombre(e.target.value),
								placeholder: "Ej. Generador Planta Diésel 150 kVA",
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-sans"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 992,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 988,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase mb-1",
									children: "Capacidad (kVA / A)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1004,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: newSourceCapacidad,
									onChange: (e) => setNewSourceCapacidad(e.target.value),
									placeholder: "Ej. 150 kVA",
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1007,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1003,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase mb-1",
									children: "Tensión Normalizada"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1016,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: newSourceTension,
									onChange: (e) => setNewSourceTension(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-2 py-2 text-slate-100 text-xs font-bold focus:outline-none focus:border-amber-500 cursor-pointer",
									children: TENSIONES_COVENIN_159_BT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
										value: v,
										children: v
									}, v, false, {
										fileName: _jsxFileName,
										lineNumber: 1025,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1019,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1015,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1002,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase mb-1",
								children: "Ubicación Física"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1032,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: newSourceUbicacion,
								onChange: (e) => setNewSourceUbicacion(e.target.value),
								placeholder: "Ej. Caseta de Generación / Sala Eléctrica",
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-sans"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1035,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1031,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-3 border-t border-slate-800 flex items-center justify-end gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setQuickCreateOpen(false),
									className: "px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all cursor-pointer",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1045,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									className: "px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1056,
										columnNumber: 19
									}, this), " Crear y Vincular"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1052,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1044,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 963,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 939,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 938,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 247,
		columnNumber: 5
	}, this);
}
_s(TransferComponent, "GPATGV8IXFsNYWS90HXCoEH8W0s=", false, function() {
	return [
		useConfirm,
		useStore,
		useStore
	];
});
_c = TransferComponent;
var _c;
$RefreshReg$(_c, "TransferComponent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TransferComponent.jsx?t=1790793572890";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/TransferComponent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/TransferComponent.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/TransferComponent.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxlQUFlO0FBQ3BELFNBQ0UsV0FDQSxLQUNBLFFBQ0EsUUFDQSxVQUNBLE9BQ0EsUUFDQSxTQUNBLE1BQ0EsT0FDQSxPQUNBLGVBQ0EsU0FDQSxLQUNBLGdCQUNBLGNBQ0EsT0FDQSxVQUNBLE1BQ0EsaUJBQ0s7QUFDUCxPQUFPLGNBQWM7QUFDckIsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTyxtQ0FBbUM7QUFDMUMsT0FBTyxnQ0FBZ0M7QUFDdkMsT0FBTyx1QkFBdUI7QUFDOUIsU0FDRSwwQkFDQSx5QkFDQSwwQkFDQSwyQkFDSzs7OztBQUVQLGVBQWUsU0FBUyxrQkFBa0IsRUFDeEMsY0FDQSxjQUNBLFVBQ0EsV0FBVyxTQUNWOztDQUNELE1BQU0sT0FBTyxnQkFBZ0I7Q0FDN0IsTUFBTSxFQUFFLE9BQU8sYUFBYSxTQUFTLGtCQUFrQixXQUFXO0NBQ2xFLE1BQU0sWUFBWSxVQUFVLFVBQVUsTUFBTSxhQUFhLENBQUMsQ0FBQztDQUUzRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sRUFBRSxxQkFBcUIsY0FBYyxTQUFTOztDQUdwRCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEtBQUs7Q0FDNUQsTUFBTSxDQUFDLHdCQUF3Qiw2QkFBNkIsU0FBUyxjQUFjO0NBQ25GLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLGVBQWU7Q0FDbEUsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFO0NBQ3pELE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsZ0JBQWdCO0NBQzdFLE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsRUFBRTtDQUMvRCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLFdBQVc7O0NBR3BFLE1BQU0sa0JBQWtCLGNBQWM7RUFDcEMsTUFBTSxPQUFPLENBQUM7RUFDZCxNQUFNLFNBQVMsTUFBTSxhQUFhLE1BQU07RUFDeEMsTUFBTSxVQUFVLFVBQVUsTUFBSyxNQUFLLEVBQUUsT0FBTyxNQUFNO0VBRW5ELE1BQU0sc0JBQXNCLE1BQU07R0FDaEMsSUFBSSxFQUFFLHFCQUFxQixLQUFLLEtBQUssR0FBRyxFQUFFLG1CQUFtQjtHQUM3RCxJQUFJLEVBQUUsVUFBVSxLQUFLLEtBQUssR0FBRyxFQUFFLFFBQVE7R0FDdkMsSUFBSSxFQUFFLGVBQWUsS0FBSyxLQUFLLEdBQUcsRUFBRSxhQUFhO0dBQ2pELElBQUksRUFBRSx5QkFBeUIsS0FBSyxLQUFLLEdBQUcsRUFBRSx1QkFBdUI7R0FDckUsSUFBSSxFQUFFLGdCQUFnQixLQUFLLEtBQUssR0FBRyxFQUFFLGNBQWM7R0FDbkQsSUFBSSxFQUFFLFNBQVMsS0FBSyxLQUFLLEdBQUcsRUFBRSxPQUFPO0VBQ3ZDO0VBRUEsSUFBSSxDQUFDLFNBQVM7R0FDWixVQUFVLFNBQVEsTUFBSztJQUNyQixJQUFJLEVBQUUscUJBQXFCLEtBQUssS0FBSyxHQUFHLEVBQUUsbUJBQW1CO0lBQzdELElBQUksRUFBRSxXQUFXLEVBQUUsVUFBVSxRQUFRLGtCQUFrQjtHQUN6RCxDQUFDO0VBQ0gsT0FBTztHQUNMLElBQUksUUFBUSxxQkFBcUIsS0FBSyxLQUFLLEdBQUcsUUFBUSxtQkFBbUI7R0FDekUsSUFBSSxRQUFRLFdBQVcsUUFBUSxVQUFVLFFBQVEsa0JBQWtCO0VBQ3JFOztFQUdBLE1BQU0sT0FBTyxJQUFJLElBQUk7RUFDckIsT0FBTyxLQUFLLFFBQU8sTUFBSztHQUN0QixJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsTUFBTSxFQUFFLE9BQU8sTUFBTSxNQUFNLEtBQUssSUFBSSxFQUFFLEVBQUUsR0FBRyxPQUFPO0dBQy9ELEtBQUssSUFBSSxFQUFFLEVBQUU7R0FDYixPQUFPO0VBQ1QsQ0FBQztDQUNILEdBQUcsQ0FBQyxXQUFXLElBQUksQ0FBQzs7Q0FHcEIsTUFBTSwwQkFBMEIsT0FBTyxNQUFNO0VBQzNDLElBQUksR0FBRyxFQUFFLGVBQWU7RUFDeEIsSUFBSSxDQUFDLGdCQUFnQixLQUFLLEdBQUc7R0FDM0IsVUFBVSxpREFBaUQsT0FBTztHQUNsRTtFQUNGO0VBRUEsTUFBTSxlQUFlLEtBQUssY0FBZSxVQUFVLE1BQUssTUFBSyxFQUFFLFFBQVEsS0FBSyxhQUFhLEtBQUssVUFBVSxDQUFDLEVBQUUsWUFBWSxFQUFFLEVBQUU7RUFFM0gsTUFBTSxVQUFVO0dBQ2QsUUFBUSxnQkFBZ0IsS0FBSztHQUM3QixjQUFjO0dBQ2QsV0FBVyxtQkFBbUIsS0FBSyxLQUFLO0dBQ3hDLGVBQWU7SUFDYixLQUFLLG1CQUFtQixLQUFLO0lBQzdCLFVBQVUsbUJBQW1CLEtBQUs7SUFDbEMsZ0JBQWdCO0dBQ2xCO0VBQ0Y7RUFFQSxNQUFNLE1BQU0sTUFBTSxvQkFBb0IsY0FBYyxPQUFPO0VBQzNELElBQUksT0FBTyxJQUFJLFNBQVM7R0FDdEIsTUFBTSxjQUFjLElBQUk7R0FDeEIsTUFBTSxjQUFjLFlBQVksVUFBVTtHQUUxQyxJQUFJLDJCQUEyQixnQkFBZ0I7SUFDN0MsZUFBZSxzQkFBc0IsV0FBVztJQUNoRCxJQUFJLGtCQUFrQixlQUFlLHVCQUF1QixnQkFBZ0I7R0FDOUUsT0FBTztJQUNMLGVBQWUsMEJBQTBCLFdBQVc7SUFDcEQsSUFBSSxrQkFBa0IsZUFBZSwyQkFBMkIsZ0JBQWdCO0dBQ2xGO0dBRUEsVUFBVSxXQUFXLFlBQVksb0NBQW9DLFNBQVM7R0FDOUUsbUJBQW1CLEtBQUs7RUFDMUIsT0FBTztHQUNMLFVBQVUsS0FBSyxTQUFTLDZCQUE2QixPQUFPO0VBQzlEO0NBQ0Y7O0NBR0EsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLE1BQU0sVUFBVSxFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLE1BQU0sYUFBYSxFQUFFO0NBQ2hFLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUN4QyxNQUFNLDBCQUEwQixNQUFNLGVBQWUsNEJBQTRCLEVBQ25GOztDQUdBLE1BQU0sQ0FBQyxJQUFJLFNBQVMsU0FBUyxNQUFNLGlCQUFpQixDQUFDLENBQUM7O0NBR3RELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxNQUFNLFlBQVksSUFBSTtDQUMvRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsTUFBTSxRQUFRLElBQUk7Q0FDekQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsSUFBSTs7Q0FHakQsZ0JBQWdCO0VBQ2QsSUFBSSxNQUFNO0dBQ1IsVUFBVSxLQUFLLFVBQVUsRUFBRTtHQUMzQixhQUFhLEtBQUssYUFBYSxFQUFFO0dBQ2pDLGlCQUFpQixLQUFLLDBCQUEwQixLQUFLLGVBQWUsNEJBQTRCLEVBQUU7R0FDbEcsTUFBTSxLQUFLLGlCQUFpQixDQUFDLENBQUM7R0FDOUIsWUFBWSxLQUFLLFlBQVksSUFBSTtHQUNqQyxXQUFXLEtBQUssUUFBUSxJQUFJO0VBQzlCO0NBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQzs7Q0FHVCxJQUFJLENBQUMsTUFBTTtFQUNULE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHFEQUFzRDs7OzthQUMzRSx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFVO0dBQWdFOzs7O1dBQ3BGOzs7Ozs7Q0FFVDtDQUVBLE1BQU0sa0JBQWtCLEtBQUssVUFBVTtFQUNyQyxJQUFJLFVBQVU7RUFDZCxPQUFNLFVBQVM7R0FBRSxHQUFHO0lBQU8sTUFBTTtFQUFNLEVBQUU7Q0FDM0M7Q0FFQSxNQUFNLHdCQUF3QixXQUFXLEtBQUssVUFBVTtFQUN0RCxJQUFJLFVBQVU7RUFDZCxPQUFNLFVBQVM7R0FDYixHQUFHO0lBQ0YsWUFBWTtJQUNYLEdBQUksS0FBSyxjQUFjLENBQUM7S0FDdkIsTUFBTTtHQUNUO0VBQ0YsRUFBRTtDQUNKO0NBRUEsTUFBTSxtQkFBbUI7RUFDdkIsSUFBSSxVQUFVO0VBQ2QsSUFBSSxVQUFVO0dBQ1osU0FBUztJQUNQLEdBQUc7SUFDSDtJQUNBO0lBQ0Esd0JBQXdCO0lBQ3hCO0lBQ0EsTUFBTTtJQUNOLGVBQWU7S0FDYixHQUFHO0tBQ0gsMEJBQTBCO0lBQzVCO0dBQ0YsQ0FBQztFQUNIO0VBQ0EsYUFBYSxLQUFLO0NBQ3BCO0NBRUEsTUFBTSwwQkFBMEIsWUFBWTtFQUMxQyxJQUFJLFVBQVU7RUFDZCxNQUFNLFlBQVksTUFBTSxjQUFjLCtFQUErRTtFQUNySCxJQUFJLENBQUMsV0FBVztFQUVoQixVQUFVLEVBQUU7RUFDWixhQUFhLEVBQUU7RUFDZixpQkFBaUIsRUFBRTtFQUNuQixNQUFNLENBQUMsQ0FBQztFQUNSLFlBQVksSUFBSTtFQUNoQixXQUFXLElBQUk7RUFDZixJQUFJLFlBQVksSUFBSSxnQkFBZ0IsVUFBVTtFQUM5QyxjQUFjLElBQUk7Q0FDcEI7O0NBR0EsTUFBTSxnQkFBZ0IsR0FBRyxpQkFBaUIsR0FBRywrQkFBK0IsR0FBRyxtQkFBbUIsWUFBWSxDQUFDLENBQUMsU0FBUyxRQUFRLEtBQUssR0FBRyxtQkFBbUIsWUFBWSxDQUFDLENBQUMsU0FBUyxLQUFLLElBQUksUUFBUTtDQUNwTSxNQUFNLGlCQUFpQixHQUFHLGtCQUFrQjtDQUM1QyxNQUFNLGlCQUFpQixHQUFHLGtCQUFrQjtDQUM1QyxNQUFNLG9CQUFvQixHQUFHLHFCQUFxQjtDQUNsRCxNQUFNLFFBQVEsR0FBRyxTQUFTO0NBQzFCLE1BQU0sYUFBYSxHQUFHLGNBQWM7O0NBR3BDLE1BQU0scUJBQXFCLEdBQUcsc0JBQXNCLEdBQUcsMEJBQTBCLEdBQUcseUJBQXlCO0NBQzdHLE1BQU0sc0JBQXNCLEdBQUcsdUJBQXVCO0NBQ3RELE1BQU0sdUJBQXVCLEdBQUcsd0JBQXdCLEdBQUcsWUFBWTtDQUN2RSxNQUFNLHdCQUF3QixHQUFHLHlCQUF5QixHQUFHLHlCQUF5Qjs7Q0FHdEYsTUFBTSx5QkFBeUIsR0FBRywwQkFBMEIsR0FBRywwQkFBMEIsR0FBRyw0QkFBNEI7Q0FDeEgsTUFBTSwwQkFBMEIsR0FBRywyQkFBMkI7Q0FDOUQsTUFBTSwyQkFBMkIsR0FBRyw0QkFBNEIsR0FBRyxZQUFZO0NBQy9FLE1BQU0sNEJBQTRCLEdBQUcsNkJBQTZCLEdBQUcsNkJBQTZCOztDQUdsRyxNQUFNLG9CQUFvQixHQUFHLHFCQUFxQixHQUFHLFNBQVM7Q0FDOUQsTUFBTSx1QkFBdUIsR0FBRyx3QkFBd0I7Q0FDeEQsTUFBTSxrQkFBa0IsR0FBRyxtQkFBbUIsR0FBRyxVQUFVO0NBQzNELE1BQU0sa0JBQWtCLEdBQUcsbUJBQW1CLEdBQUcsVUFBVTtDQUUzRCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFXLDhGQUE4RixXQUFXLG1DQUFtQztZQUE1SjtHQUtFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsV0FBRCxFQUFXLFdBQVUseUJBQTBCOzs7OztLQUM1Qzs7OztlQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLGtCQUFrQixRQUFRLHNDQUFzQztPQUM3RDs7Ozs7T0FDTix3QkFBQyxRQUFEO1FBQU0sV0FBVyw2Q0FBNkMsbUJBQW1CLGdCQUFnQiw4REFBOEQ7a0JBQzVKO09BQ0c7Ozs7O09BQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQXNILFFBQy9HLEtBQUssRUFDTjs7Ozs7O01BQ0g7Ozs7O2VBQ0wsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsVUFBVTtLQUNUOzs7O2FBQ0Q7Ozs7YUFDRjs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsT0FBTyxNQUFNO01BQzVCLFdBQVU7TUFDVixPQUFNO2dCQUhSLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUseUJBQTBCOzs7O2dCQUM3Qyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBbUI7TUFBaUI7Ozs7Y0FDOUM7Ozs7O2VBRVAsQ0FBQyxZQUNBLGdEQUNHLGFBQ0Msd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxTQUFTO01BQ1QsV0FBVTtNQUNWLE9BQU07Z0JBSlIsQ0FNRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7O2dCQUNwQyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBbUI7TUFBd0I7Ozs7Y0FDckQ7Ozs7O2VBR1QsWUFDQyx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7O2dCQUFDLGtCQUN0Qjs7Ozs7Z0JBRVIsd0JBQUMsVUFBRDtNQUNFLGVBQWUsYUFBYSxJQUFJO01BQ2hDLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7O2dCQUFDLHVCQUN2Qjs7Ozs7YUFFVjs7OzthQUVEOzs7OztZQUNGOzs7Ozs7R0FLTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBR0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQTJGLHlDQUNuRCxrQkFBa0IsUUFBUSw4QkFBOEIsd0JBQzFGOzs7OztpQkFDTix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxZQUNDLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxVQUFVLEVBQUUsT0FBTyxLQUFLO1NBQ3pDLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7bUJBRUQsVUFBVTtPQUVWOzs7O2VBQ0Q7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBNkM7UUFBd0I7Ozs7a0JBQ3BGLFlBQ0Msd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPLEdBQUcsWUFBWSxHQUFHLHFCQUFxQjtTQUM5QyxXQUFXLE1BQU0sZUFBZSxZQUFZLEVBQUUsT0FBTyxLQUFLO1NBQzFELGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7bUJBRUQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsR0FBRyxZQUFZLEdBQUcsb0JBQW9CLEdBQUcsR0FBRyxZQUFZLEdBQUcsc0JBQXNCO1FBQzlFOzs7O2dCQUVMOzs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUdFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7a0JBQUMsOENBRXhDOzs7OztpQkFFSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTJCO1VBQWdCOzs7O29CQUMxRCxZQUNDLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTztXQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1dBQzVDLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7cUJBRUQsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWdDLGFBQWE7VUFBVTs7OztrQkFFdEU7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTJCO1VBQXFCOzs7O29CQUMvRCxZQUNDLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxHQUFHLFVBQVU7V0FDcEIsV0FBVyxNQUFNLGVBQWUsVUFBVSxFQUFFLE9BQU8sS0FBSztXQUN4RCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7O3FCQUVELHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFnQyxHQUFHLFVBQVUsR0FBRyxxQkFBcUI7VUFBVTs7OztrQkFFOUY7Ozs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTZDO1VBQW9DOzs7O29CQUNoRyxZQUNDLHdCQUFDLFVBQUQ7V0FDRSxPQUFPLEdBQUcsa0JBQWtCO1dBQzVCLFdBQVcsTUFBTSxlQUFlLGtCQUFrQixFQUFFLE9BQU8sS0FBSztXQUNoRSxXQUFVO3FCQUhaLENBS0Usd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQUc7V0FBNkM7Ozs7cUJBQzdELHlCQUF5QixLQUFJLE1BQzVCLHdCQUFDLFVBQUQ7WUFBZ0IsT0FBTztzQkFBSTtXQUFVLEdBQXhCOzs7O2tCQUF3QixDQUN0QyxDQUNLOzs7OztxQkFFUix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBbUQsR0FBRyxrQkFBa0I7VUFBVTs7OztrQkFFakc7Ozs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNkM7V0FBa0I7Ozs7cUJBQzlFLFlBQ0Msd0JBQUMsVUFBRDtZQUNFLE9BQU87WUFDUCxXQUFXLE1BQU0sZUFBZSxTQUFTLEVBQUUsT0FBTyxLQUFLO1lBQ3ZELFdBQVU7c0JBRVQsb0JBQW9CLEtBQUksTUFDdkIsd0JBQUMsVUFBRDthQUFnQixPQUFPO3VCQUFJO1lBQVUsR0FBeEI7Ozs7bUJBQXdCLENBQ3RDO1dBQ0s7Ozs7c0JBRVIsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWlEO1dBQVk7Ozs7bUJBRTVFOzs7OztvQkFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUE2QztXQUFpQjs7OztxQkFDN0UsWUFDQyx3QkFBQyxVQUFEO1lBQ0UsT0FBTztZQUNQLFdBQVcsTUFBTSxlQUFlLGNBQWMsRUFBRSxPQUFPLEtBQUs7WUFDNUQsV0FBVTtzQkFFVCx5QkFBeUIsS0FBSSxNQUM1Qix3QkFBQyxVQUFEO2FBQWdCLE9BQU87dUJBQUk7WUFBVSxHQUF4Qjs7OzttQkFBd0IsQ0FDdEM7V0FDSzs7OztzQkFFUix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBK0M7V0FBaUI7Ozs7bUJBRS9FOzs7OztrQkFDRjs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVcsNkRBQTZELGtCQUFrQixRQUFRLGdEQUFnRDtvQkFBdkosQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUEyQjtXQUFzQjs7OztxQkFDaEUsa0JBQWtCLFNBQ2pCLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUEwQztXQUFnQzs7OzttQkFFekY7Ozs7O29CQUNKLFlBQ0Msd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxVQUFVLGtCQUFrQjtXQUM1QixPQUFPLGtCQUFrQixRQUFRLHFDQUFzQyxHQUFHLGtCQUFrQjtXQUM1RixXQUFXLE1BQU0sZUFBZSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7V0FDaEUsYUFBWTtXQUNaLFdBQVU7VUFDWDs7OztxQkFFRCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixrQkFBa0IsUUFBUSxxQ0FBc0MsR0FBRyxrQkFBa0I7VUFDbEY7Ozs7a0JBRUw7Ozs7OztRQUNGOzs7OztlQUNGOzs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSwyQkFBNEI7Ozs7bUJBQUMsa0RBRTFDOzs7OztrQkFDSix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBZ0c7UUFFMUc7Ozs7Z0JBQ0g7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBR0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLG9EQUEwRDs7OztzQkFBQyw2QkFFdkU7Ozs7O3FCQUNOLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFtRDtXQUFTOzs7O21CQUN6RTs7Ozs7O1VBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUEwRTtVQUVwRjs7OztvQkFDTixZQUNDLHdCQUFDLCtCQUFEO1dBQ0UsT0FBTztXQUNQLFdBQVcsUUFBUSxlQUFlLHNCQUFzQixHQUFHO1dBQzNELFlBQVksS0FBSztXQUNqQixpQkFBaUIsS0FBSztXQUN0QixlQUFlO1dBQ2YsYUFBWTtXQUNaLFdBQVU7V0FDVixPQUFNO1dBQ04sa0JBQWtCO1dBQ2xCLHFCQUFxQjtZQUNuQiwwQkFBMEIsY0FBYztZQUN4QyxpQkFBaUIsZUFBZTtZQUNoQyxtQkFBbUIsNkJBQTZCLGdCQUFnQixRQUFPLE1BQUssRUFBRSxpQkFBaUIsZUFBZSxDQUFDLENBQUMsU0FBUyxHQUFHO1lBQzVILHNCQUFzQixHQUFHLFlBQVksS0FBSztZQUMxQyxvQkFBb0IsR0FBRyxrQkFBa0IsV0FBVztZQUNwRCxtQkFBbUIsSUFBSTtXQUN6QjtVQUNEOzs7O3FCQUVELHdCQUFDLEtBQUQ7V0FBRyxXQUFVO1dBQXNELE9BQU87cUJBQ3ZFLHNCQUFzQjtVQUN0Qjs7OztrQkFFRjs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUM7V0FBYzs7OztxQkFDOUQsWUFDQyx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0sZUFBZSx1QkFBdUIsRUFBRSxPQUFPLEtBQUs7WUFDckUsYUFBWTtZQUNaLFdBQVU7V0FDWDs7OztzQkFFRCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNEIsdUJBQXVCO1dBQVU7Ozs7bUJBRTVFOzs7O3FCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUM7V0FBd0I7Ozs7cUJBQ3hFLFlBQ0Msd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLGVBQWUsd0JBQXdCLEVBQUUsT0FBTyxLQUFLO1lBQ3RFLGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7c0JBRUQsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTRCLHdCQUF3QjtXQUFVOzs7O21CQUU3RTs7OzttQkFDRjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUM7V0FBNkI7Ozs7cUJBQzdFLFlBQ0Msd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLGVBQWUseUJBQXlCLEVBQUUsT0FBTyxLQUFLO1lBQ3ZFLGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7c0JBRUQsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXlDLHlCQUF5QjtXQUFVOzs7O21CQUUzRjs7Ozs7O1NBQ0Y7Ozs7O2tCQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxrREFBd0Q7Ozs7c0JBQUMsaUNBRXJFOzs7OztxQkFDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUQ7V0FBUzs7OzttQkFDdkU7Ozs7OztVQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBMEU7VUFFcEY7Ozs7b0JBQ04sWUFDQyx3QkFBQywrQkFBRDtXQUNFLE9BQU87V0FDUCxXQUFXLFFBQVEsZUFBZSwwQkFBMEIsR0FBRztXQUMvRCxZQUFZLEtBQUs7V0FDakIsaUJBQWlCLEtBQUs7V0FDdEIsZUFBZTtXQUNmLGFBQVk7V0FDWixXQUFVO1dBQ1YsT0FBTTtXQUNOLGtCQUFrQjtXQUNsQixxQkFBcUI7WUFDbkIsMEJBQTBCLGtCQUFrQjtZQUM1QyxpQkFBaUIsV0FBVztZQUM1QixtQkFBbUIsd0JBQXdCLGdCQUFnQixRQUFPLE1BQUssRUFBRSxpQkFBaUIsV0FBVyxDQUFDLENBQUMsU0FBUyxHQUFHO1lBQ25ILHNCQUFzQixHQUFHLFlBQVksS0FBSztZQUMxQyxvQkFBb0IsR0FBRyxrQkFBa0IsV0FBVztZQUNwRCxtQkFBbUIsSUFBSTtXQUN6QjtVQUNEOzs7O3FCQUVELHdCQUFDLEtBQUQ7V0FBRyxXQUFVO1dBQXNELE9BQU87cUJBQ3ZFLDBCQUEwQjtVQUMxQjs7OztrQkFFRjs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUM7V0FBYzs7OztxQkFDOUQsWUFDQyx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0sZUFBZSwyQkFBMkIsRUFBRSxPQUFPLEtBQUs7WUFDekUsYUFBWTtZQUNaLFdBQVU7V0FDWDs7OztzQkFFRCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNEIsMkJBQTJCO1dBQVU7Ozs7bUJBRWhGOzs7O3FCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUM7V0FBd0I7Ozs7cUJBQ3hFLFlBQ0Msd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLGVBQWUsNEJBQTRCLEVBQUUsT0FBTyxLQUFLO1lBQzFFLGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7c0JBRUQsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTRCLDRCQUE0QjtXQUFVOzs7O21CQUVqRjs7OzttQkFDRjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUM7V0FBNkI7Ozs7cUJBQzdFLFlBQ0Msd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLGVBQWUsNkJBQTZCLEVBQUUsT0FBTyxLQUFLO1lBQzNFLGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7c0JBRUQsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXlDLDZCQUE2QjtXQUFVOzs7O21CQUUvRjs7Ozs7O1NBQ0Y7Ozs7O2dCQUVGOzs7OztlQUNGOzs7OztjQUNGOzs7Ozs7S0FLTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUdFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUseUJBQTBCOzs7O29CQUFDLG9CQUUxQzs7Ozs7bUJBQ0wsWUFDQyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFVBQUQ7V0FDRSxNQUFLO1dBQ0wsZUFBZSxlQUFlLGlCQUFpQixLQUFLO1dBQ3BELFdBQVcsMkVBQ1Qsa0JBQWtCLFFBQ2QsMENBQ0E7cUJBRVA7VUFFTzs7OztvQkFDUix3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLGVBQWUsZUFBZSxpQkFBaUIsS0FBSztXQUNwRCxXQUFXLDJFQUNULGtCQUFrQixRQUNkLDBDQUNBO3FCQUVQO1VBRU87Ozs7a0JBQ0w7Ozs7O29CQUVMLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLGtCQUFrQixRQUFRLHdCQUF3QjtTQUMvQzs7OztpQkFFTDs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSwyQkFBNEI7Ozs7b0JBQUMseUJBRTNDOzs7OzttQkFDTCxZQUNDLHdCQUFDLFVBQUQ7VUFDRSxPQUFPO1VBQ1AsV0FBVyxNQUFNLGVBQWUsa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1VBQ2hFLFdBQVU7b0JBSFosQ0FLRSx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBYztVQUFzQjs7OztvQkFDbEQsd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQW9CO1VBQTRCOzs7O2tCQUN4RDs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVcsb0RBQ2YsbUJBQW1CLGdCQUNmLDhEQUNBO29CQUVILG1CQUFtQixnQkFBZ0IsbUJBQW1CO1NBQ25EOzs7O2lCQUVMOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLGdCQUFELEVBQWdCLFdBQVUsdUJBQXdCOzs7O29CQUFDLGFBRS9DOzs7OzttQkFDTCxZQUNDLHdCQUFDLFVBQUQ7VUFDRSxPQUFPO1VBQ1AsV0FBVyxNQUFNLGVBQWUsa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1VBQ2hFLFdBQVU7b0JBSFo7V0FLRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBVTtXQUE0Qzs7Ozs7V0FDcEUsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVU7V0FBK0M7Ozs7O1dBQ3ZFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFZO1dBQTRDOzs7OztVQUNoRTs7Ozs7b0JBRVIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsbUJBQW1CLFlBQVksY0FDL0IsbUJBQW1CLGNBQWMsaUJBQ2pDO1NBQ0c7Ozs7aUJBRUw7Ozs7OztPQUVGOzs7Ozs7S0FDRjs7Ozs7S0FLTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyw0QkFBRDtPQUNFLFlBQVksR0FBRyxjQUFjLENBQUM7T0FDOUIsV0FBVyxxQkFBcUIsZUFBZSxjQUFjLGdCQUFnQjtPQUM3RSxVQUFVLENBQUM7T0FDWCxRQUFPO09BQ1AsV0FBVTtNQUNYOzs7OztLQUNFOzs7OztLQUtMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx5QkFBMEI7Ozs7aUJBQUMsd0RBRTNDOzs7OztnQkFFSix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXVEO1VBRWpFOzs7OztVQUNMLFlBQ0Msd0JBQUMsK0JBQUQ7V0FDRSxPQUFPO1dBQ1AsV0FBVyxRQUFRLGVBQWUscUJBQXFCLEdBQUc7V0FDMUQsWUFBWSxLQUFLO1dBQ2pCLGlCQUFpQixLQUFLO1dBQ3RCLGVBQWU7V0FDZixhQUFZO1dBQ1osV0FBVTtXQUNWLE9BQU07VUFDUDs7OztxQkFFRCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtXQUE2QyxPQUFPO3FCQUM5RCxxQkFBcUI7VUFDckI7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBbUM7V0FBdUI7Ozs7cUJBQ3pFLFlBQ0Msd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLGVBQWUsd0JBQXdCLEVBQUUsT0FBTyxLQUFLO1lBQ3RFLGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7c0JBRUQsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQW9DLHdCQUF3QjtXQUFVOzs7O21CQUVyRjs7Ozs7O1NBQ0Y7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXNEO1VBRWhFOzs7OztVQUNMLFlBQ0Msd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPO1dBQ1AsV0FBVyxNQUFNLGVBQWUsbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1dBQ2pFLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7cUJBRUQsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQW9DLG1CQUFtQjtVQUFPOzs7OztVQUU3RSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBbUM7VUFBeUM7Ozs7O1NBQ3pGOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5RDtVQUVuRTs7Ozs7VUFDTCxZQUNDLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTztXQUNQLFdBQVcsTUFBTSxlQUFlLG1CQUFtQixFQUFFLE9BQU8sS0FBSztXQUNqRSxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7O3FCQUVELHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFvQyxtQkFBbUI7VUFBTzs7Ozs7VUFFN0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQW1DO1VBQW1EOzs7OztTQUNuRzs7Ozs7O09BQ0Y7Ozs7O2NBQ0Y7Ozs7OztLQUtMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBR0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHlCQUEwQjs7OztrQkFBQyxzQ0FFekM7Ozs7O2lCQUVILFlBQ0Msd0JBQUMsWUFBRDtRQUNFLE1BQU07UUFDTixPQUFPO1FBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztRQUNoRCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2tCQUVELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLGlCQUFpQjtPQUNmOzs7O2VBRUo7Ozs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLG1CQUFEO1FBQ1k7UUFDRDtRQUNHO1FBQ1osa0JBQWtCLFNBQVM7U0FDekIsWUFBWSxJQUFJO1NBQ2hCLE1BQU0sU0FBUyxJQUFJLFdBQVc7U0FDOUIsT0FBTyxrQkFBa0I7VUFDdkIsV0FBVyxPQUFPLE1BQU07U0FDMUI7U0FDQSxPQUFPLGNBQWMsSUFBSTtTQUN6QixJQUFJLFlBQVksSUFBSSxnQkFBZ0IsVUFBVTtTQUM5QyxjQUFjLElBQUksZ0JBQWdCLElBQUksQ0FBQztRQUN6QztRQUNBLGdCQUFnQjtTQUNkLFlBQVksSUFBSTtTQUNoQixXQUFXLElBQUk7U0FDZixJQUFJLFlBQVksSUFBSSxnQkFBZ0IsVUFBVTtTQUM5QyxjQUFjLElBQUk7UUFDcEI7UUFDQSxVQUFVLENBQUM7UUFDWCxPQUFNO1FBQ04sVUFBUztPQUNWOzs7OztNQUNFOzs7O2NBRUY7Ozs7OztJQUVGOzs7Ozs7R0FHSixtQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsS0FBRCxFQUFLLFdBQVUsVUFBVzs7Ozs7T0FDdkI7Ozs7aUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF3RDtPQUVsRTs7OztpQkFDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDViwyQkFBMkIsaUJBQWlCLGdDQUFnQztPQUM1RTs7OztlQUNBOzs7O2VBQ0Y7Ozs7O2dCQUNMLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsZUFBZSxtQkFBbUIsS0FBSztPQUN2QyxXQUFVO2lCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O01BQ2xCOzs7O2NBQ0w7Ozs7O2VBRUwsd0JBQUMsUUFBRDtNQUFNLFVBQVU7TUFBeUIsV0FBVTtnQkFBbkQ7T0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTREO09BRXRFOzs7O2lCQUNQLHdCQUFDLFVBQUQ7UUFDRSxPQUFPO1FBQ1AsV0FBVyxNQUFNO1NBQ2YsTUFBTSxJQUFJLEVBQUUsT0FBTztTQUNuQixpQkFBaUIsQ0FBQztTQUNsQixJQUFJLE1BQU0sYUFBYSxtQkFBbUIsd0JBQXdCLGdCQUFnQixRQUFPLE9BQU0sR0FBRyxpQkFBaUIsV0FBVyxDQUFDLENBQUMsU0FBUyxHQUFHO2NBQ3ZJLElBQUksTUFBTSxpQkFBaUIsbUJBQW1CLDJCQUEyQixnQkFBZ0IsUUFBTyxPQUFNLEdBQUcsaUJBQWlCLGVBQWUsQ0FBQyxDQUFDLFNBQVMsR0FBRztjQUN2SixJQUFJLE1BQU0sZUFBZSxtQkFBbUIsZUFBZSxnQkFBZ0IsUUFBTyxPQUFNLEdBQUcsaUJBQWlCLGFBQWEsQ0FBQyxDQUFDLFNBQVMsR0FBRztjQUN2SSxJQUFJLE1BQU0sc0JBQXNCLE1BQU0sa0JBQWtCLG1CQUFtQiwrQkFBK0I7UUFDakg7UUFDQSxXQUFVO2tCQVZaO1NBWUUsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQWdCO1NBQXFCOzs7OztTQUNuRCx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBWTtTQUFvQzs7Ozs7U0FDOUQsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQWM7U0FBOEI7Ozs7O1NBQzFELHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFtQjtTQUF1Qzs7Ozs7U0FDeEUsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVU7U0FBK0I7Ozs7O1FBQ2pEOzs7OztlQUNMOzs7OztPQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FFdEU7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTDtRQUNBLE9BQU87UUFDUCxXQUFXLE1BQU0sbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1FBQ2xELGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEQ7UUFFdEU7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVyxNQUFNLHNCQUFzQixFQUFFLE9BQU8sS0FBSztTQUNyRCxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEQ7UUFFdEU7Ozs7a0JBQ1Asd0JBQUMsVUFBRDtTQUNFLE9BQU87U0FDUCxXQUFXLE1BQU0sb0JBQW9CLEVBQUUsT0FBTyxLQUFLO1NBQ25ELFdBQVU7bUJBRVQseUJBQXlCLEtBQUksTUFDNUIsd0JBQUMsVUFBRDtVQUFnQixPQUFPO29CQUFJO1NBQVUsR0FBeEI7Ozs7Z0JBQXdCLENBQ3RDO1FBQ0s7Ozs7Z0JBQ0w7Ozs7Z0JBQ0Y7Ozs7OztPQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FFdEU7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLHNCQUFzQixFQUFFLE9BQU8sS0FBSztRQUNyRCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsbUJBQW1CLEtBQUs7U0FDdkMsV0FBVTttQkFDWDtRQUVPOzs7O2tCQUNSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsV0FBVTttQkFGWixDQUlFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7bUJBQUMsbUJBQ3ZCOzs7OztnQkFDTDs7Ozs7O01BQ0Q7Ozs7O2FBQ0g7Ozs7OztHQUNGOzs7OztFQUdKOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUcmFuc2ZlckNvbXBvbmVudC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgUmVmcmVzaEN3LCBcbiAgWmFwLCBcbiAgU2hpZWxkLCBcbiAgTGF5ZXJzLCBcbiAgQWN0aXZpdHksIFxuICBHYXVnZSwgXG4gIENhbWVyYSwgXG4gIFByaW50ZXIsIFxuICBTYXZlLCBcbiAgRWRpdDMsIFxuICBDaGVjaywgXG4gIEFsZXJ0VHJpYW5nbGUsIFxuICBTbGlkZXJzLCBcbiAgQ3B1LCBcbiAgQXJyb3dSaWdodExlZnQsXG4gIENoZWNrQ2lyY2xlMixcbiAgQ2xvY2ssXG4gIFNldHRpbmdzLFxuICBJbmZvLFxuICBSb3RhdGVDY3dcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB1c2VTdG9yZSBmcm9tICcuLi9zdG9yZS91c2VTdG9yZSc7XG5pbXBvcnQgeyB1c2VDb25maXJtIH0gZnJvbSAnLi4vY29udGV4dC9Db25maXJtQ29udGV4dCc7XG5pbXBvcnQgU2VsZWN0b3JBbGltZW50YWRvckplcmFycXVpY28gZnJvbSAnLi9TZWxlY3RvckFsaW1lbnRhZG9ySmVyYXJxdWljbyc7XG5pbXBvcnQgTWV0cm9sb2dpYUVsZWN0cmljYVNlY3Rpb24gZnJvbSAnLi9NZXRyb2xvZ2lhRWxlY3RyaWNhU2VjdGlvbic7XG5pbXBvcnQgRHVhbFBob3RvVXBsb2FkZXIgZnJvbSAnLi9EdWFsUGhvdG9VcGxvYWRlcic7XG5pbXBvcnQgeyBcbiAgVEVOU0lPTkVTX0NPVkVOSU5fMTU5X0JULCBcbiAgVEVOU0lPTkVTX0NPVkVOSU5fVE9EQVMsIFxuICBGUkVDVUVOQ0lBU19OT1JNQUxJWkFEQVMsIFxuICBQT0xPU19UUkFOU0ZFUkVOQ0lBIFxufSBmcm9tICcuLi91dGlscy9jb25zdGFudHMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBUcmFuc2ZlckNvbXBvbmVudCh7IFxuICB0cmFuc2ZlckRhdGEsIFxuICBlbGVtZW50b0RhdGEsIFxuICBvblVwZGF0ZSwgXG4gIHJlYWRPbmx5ID0gZmFsc2UgXG59KSB7XG4gIGNvbnN0IGRhdGEgPSB0cmFuc2ZlckRhdGEgfHwgZWxlbWVudG9EYXRhO1xuICBjb25zdCB7IGFsZXJ0OiBjdXN0b21BbGVydCwgY29uZmlybTogY3VzdG9tQ29uZmlybSB9ID0gdXNlQ29uZmlybSgpO1xuICBjb25zdCBjb21wYW5pZXMgPSB1c2VTdG9yZSgoc3RhdGUpID0+IHN0YXRlLmNvbXBhbmllcyB8fCBbXSk7XG5cbiAgY29uc3QgW2lzRWRpdGluZywgc2V0SXNFZGl0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgeyBhZGRFbGVtZW50b1VuaWZpbGFyLCBzaG93VG9hc3QgfSA9IHVzZVN0b3JlKCk7XG5cbiAgLy8gRXN0YWRvcyBwYXJhIGNyZWFjacOzbiByw6FwaWRhIGVuIGzDrW5lYSBkZSBmdWVudGVzXG4gIGNvbnN0IFtxdWlja0NyZWF0ZU9wZW4sIHNldFF1aWNrQ3JlYXRlT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtxdWlja0NyZWF0ZVRhcmdldEZpZWxkLCBzZXRRdWlja0NyZWF0ZVRhcmdldEZpZWxkXSA9IHVzZVN0YXRlKCdmdWVudGVOb3JtYWwnKTsgLy8gJ2Z1ZW50ZU5vcm1hbCcgfCAnZnVlbnRlRW1lcmdlbmNpYSdcbiAgY29uc3QgW25ld1NvdXJjZVRpcG8sIHNldE5ld1NvdXJjZVRpcG9dID0gdXNlU3RhdGUoJ1RSQU5TRk9STUFET1InKTtcbiAgY29uc3QgW25ld1NvdXJjZU5vbWJyZSwgc2V0TmV3U291cmNlTm9tYnJlXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW25ld1NvdXJjZVViaWNhY2lvbiwgc2V0TmV3U291cmNlVWJpY2FjaW9uXSA9IHVzZVN0YXRlKCdTYWxhIEVsw6ljdHJpY2EnKTtcbiAgY29uc3QgW25ld1NvdXJjZUNhcGFjaWRhZCwgc2V0TmV3U291cmNlQ2FwYWNpZGFkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW25ld1NvdXJjZVRlbnNpb24sIHNldE5ld1NvdXJjZVRlbnNpb25dID0gdXNlU3RhdGUoJzIwOC8xMjAgVicpO1xuXG4gIC8vIExpc3RhIGRlIGVsZW1lbnRvcyBkZSBqZXJhcnF1w61hIGRlbCBwcm95ZWN0byBwYXJhIGFsaW1lbnRhciBsb3Mgc2VsZWN0b3JlcyAoY29tcGxldGEgY29uIHRvZG9zIGxvcyBhY3Rpdm9zKVxuICBjb25zdCBwcm9qZWN0RWxlbWVudHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBsaXN0ID0gW107XG4gICAgY29uc3QgY29tcElkID0gZGF0YT8uZW1wcmVzYUlkIHx8IGRhdGE/LmNvbXBhbnlJZDtcbiAgICBjb25zdCBjb21wYW55ID0gY29tcGFuaWVzLmZpbmQoYyA9PiBjLmlkID09PSBjb21wSWQpO1xuXG4gICAgY29uc3QgZXh0cmFjdEZyb21Qcm9qZWN0ID0gKHApID0+IHtcbiAgICAgIGlmIChwLmVsZW1lbnRvc1VuaWZpbGFyZXMpIGxpc3QucHVzaCguLi5wLmVsZW1lbnRvc1VuaWZpbGFyZXMpO1xuICAgICAgaWYgKHAudGFibGVyb3MpIGxpc3QucHVzaCguLi5wLnRhYmxlcm9zKTtcbiAgICAgIGlmIChwLnN1YmVzdGFjaW9uZXMpIGxpc3QucHVzaCguLi5wLnN1YmVzdGFjaW9uZXMpO1xuICAgICAgaWYgKHAuaW5zcGVjY2lvbmVzU3ViZXN0YWNpb24pIGxpc3QucHVzaCguLi5wLmluc3BlY2Npb25lc1N1YmVzdGFjaW9uKTtcbiAgICAgIGlmIChwLnB1bnRvc01lZGljaW9uKSBsaXN0LnB1c2goLi4ucC5wdW50b3NNZWRpY2lvbik7XG4gICAgICBpZiAocC5jY21MaXN0KSBsaXN0LnB1c2goLi4ucC5jY21MaXN0KTtcbiAgICB9O1xuXG4gICAgaWYgKCFjb21wYW55KSB7XG4gICAgICBjb21wYW5pZXMuZm9yRWFjaChjID0+IHtcbiAgICAgICAgaWYgKGMuZWxlbWVudG9zVW5pZmlsYXJlcykgbGlzdC5wdXNoKC4uLmMuZWxlbWVudG9zVW5pZmlsYXJlcyk7XG4gICAgICAgIGlmIChjLnByb3llY3RvcykgYy5wcm95ZWN0b3MuZm9yRWFjaChleHRyYWN0RnJvbVByb2plY3QpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChjb21wYW55LmVsZW1lbnRvc1VuaWZpbGFyZXMpIGxpc3QucHVzaCguLi5jb21wYW55LmVsZW1lbnRvc1VuaWZpbGFyZXMpO1xuICAgICAgaWYgKGNvbXBhbnkucHJveWVjdG9zKSBjb21wYW55LnByb3llY3Rvcy5mb3JFYWNoKGV4dHJhY3RGcm9tUHJvamVjdCk7XG4gICAgfVxuXG4gICAgLy8gRGVkdXBsaWNhciBwb3IgSUQgeSBleGNsdWlyIGFsIHByb3BpbyBlbGVtZW50byB0cmFuc2ZlclxuICAgIGNvbnN0IHNlZW4gPSBuZXcgU2V0KCk7XG4gICAgcmV0dXJuIGxpc3QuZmlsdGVyKGUgPT4ge1xuICAgICAgaWYgKCFlIHx8ICFlLmlkIHx8IGUuaWQgPT09IGRhdGE/LmlkIHx8IHNlZW4uaGFzKGUuaWQpKSByZXR1cm4gZmFsc2U7XG4gICAgICBzZWVuLmFkZChlLmlkKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0pO1xuICB9LCBbY29tcGFuaWVzLCBkYXRhXSk7XG5cbiAgLy8gSGFuZGxlciBwYXJhIGd1YXJkYXIgbnVldmEgZnVlbnRlIHLDoXBpZGFcbiAgY29uc3QgaGFuZGxlQ3JlYXRlUXVpY2tTb3VyY2UgPSBhc3luYyAoZSkgPT4ge1xuICAgIGlmIChlKSBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFuZXdTb3VyY2VOb21icmUudHJpbSgpKSB7XG4gICAgICBzaG93VG9hc3QoJ1BvciBmYXZvciBpbnRyb2R1Y2UgdW4gbm9tYnJlIHBhcmEgbGEgZnVlbnRlLicsICdlcnJvcicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHRhcmdldFByb2pJZCA9IGRhdGEucHJveWVjdG9JZCB8fCAoY29tcGFuaWVzLmZpbmQoYyA9PiBjLmlkID09PSAoZGF0YS5lbXByZXNhSWQgfHwgZGF0YS5jb21wYW55SWQpKT8ucHJveWVjdG9zPy5bMF0/LmlkKTtcblxuICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICBub21icmU6IG5ld1NvdXJjZU5vbWJyZS50cmltKCksXG4gICAgICB0aXBvRWxlbWVudG86IG5ld1NvdXJjZVRpcG8sXG4gICAgICB1YmljYWNpb246IG5ld1NvdXJjZVViaWNhY2lvbi50cmltKCkgfHwgJ1NhbGEgRWzDqWN0cmljYScsXG4gICAgICBkYXRvc1RlY25pY29zOiB7XG4gICAgICAgIGt2YTogbmV3U291cmNlQ2FwYWNpZGFkLnRyaW0oKSxcbiAgICAgICAgYW1wZXJhamU6IG5ld1NvdXJjZUNhcGFjaWRhZC50cmltKCksXG4gICAgICAgIHRlbnNpb25Ob21pbmFsOiBuZXdTb3VyY2VUZW5zaW9uXG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFkZEVsZW1lbnRvVW5pZmlsYXIodGFyZ2V0UHJvaklkLCBwYXlsb2FkKTtcbiAgICBpZiAocmVzICYmIHJlcy5zdWNjZXNzKSB7XG4gICAgICBjb25zdCBjcmVhdGVkRWxlbSA9IHJlcy5lbGVtZW50bztcbiAgICAgIGNvbnN0IGNyZWF0ZWROYW1lID0gY3JlYXRlZEVsZW0ubm9tYnJlIHx8IG5ld1NvdXJjZU5vbWJyZTtcbiAgICAgIFxuICAgICAgaWYgKHF1aWNrQ3JlYXRlVGFyZ2V0RmllbGQgPT09ICdmdWVudGVOb3JtYWwnKSB7XG4gICAgICAgIGhhbmRsZUR0Q2hhbmdlKCdmdWVudGVOb3JtYWxOb21icmUnLCBjcmVhdGVkTmFtZSk7XG4gICAgICAgIGlmIChuZXdTb3VyY2VUZW5zaW9uKSBoYW5kbGVEdENoYW5nZSgnZnVlbnRlTm9ybWFsVGVuc2lvbicsIG5ld1NvdXJjZVRlbnNpb24pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaGFuZGxlRHRDaGFuZ2UoJ2Z1ZW50ZUVtZXJnZW5jaWFOb21icmUnLCBjcmVhdGVkTmFtZSk7XG4gICAgICAgIGlmIChuZXdTb3VyY2VUZW5zaW9uKSBoYW5kbGVEdENoYW5nZSgnZnVlbnRlRW1lcmdlbmNpYVRlbnNpb24nLCBuZXdTb3VyY2VUZW5zaW9uKTtcbiAgICAgIH1cblxuICAgICAgc2hvd1RvYXN0KGBGdWVudGUgXCIke2NyZWF0ZWROYW1lfVwiIGNyZWFkYSB5IGFzaWduYWRhIGV4aXRvc2FtZW50ZS5gLCAnc3VjY2VzcycpO1xuICAgICAgc2V0UXVpY2tDcmVhdGVPcGVuKGZhbHNlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2hvd1RvYXN0KHJlcz8uZXJyb3IgfHwgJ0Vycm9yIGFsIGNyZWFyIGxhIGZ1ZW50ZS4nLCAnZXJyb3InKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gRXN0YWRvcyBsb2NhbGVzIGVkaXRhYmxlcyAtIFNpbiBkYXRvcyBkZW1vIHF1ZW1hZG9zXG4gIGNvbnN0IFtub21icmUsIHNldE5vbWJyZV0gPSB1c2VTdGF0ZShkYXRhPy5ub21icmUgfHwgJycpO1xuICBjb25zdCBbdWJpY2FjaW9uLCBzZXRVYmljYWNpb25dID0gdXNlU3RhdGUoZGF0YT8udWJpY2FjaW9uIHx8ICcnKTtcbiAgY29uc3QgW29ic2VydmFjaW9uZXMsIHNldE9ic2VydmFjaW9uZXNdID0gdXNlU3RhdGUoXG4gICAgZGF0YT8ub2JzZXJ2YWNpb25lc0dlbmVyYWxlcyB8fCBkYXRhPy5kYXRvc1RlY25pY29zPy5vYnNlcnZhY2lvblRyYW5zZmVyZW5jaWEgfHwgJydcbiAgKTtcblxuICAvLyBEYXRvcyBUw6ljbmljb3MgSlNPTlxuICBjb25zdCBbZHQsIHNldER0XSA9IHVzZVN0YXRlKGRhdGE/LmRhdG9zVGVjbmljb3MgfHwge30pO1xuXG4gIC8vIEZvdG9cbiAgY29uc3QgW2ZvdG9CbG9iLCBzZXRGb3RvQmxvYl0gPSB1c2VTdGF0ZShkYXRhPy5mb3RvQmxvYiB8fCBudWxsKTtcbiAgY29uc3QgW2ZvdG9TcmMsIHNldEZvdG9TcmNdID0gdXNlU3RhdGUoZGF0YT8uZm90byB8fCBudWxsKTtcbiAgY29uc3QgW3ByZXZpZXdVcmwsIHNldFByZXZpZXdVcmxdID0gdXNlU3RhdGUobnVsbCk7XG5cbiAgLy8gU2luY3Jvbml6YXIgc2kgY2FtYmlhbiBsb3MgcHJvcHNcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGF0YSkge1xuICAgICAgc2V0Tm9tYnJlKGRhdGEubm9tYnJlIHx8ICcnKTtcbiAgICAgIHNldFViaWNhY2lvbihkYXRhLnViaWNhY2lvbiB8fCAnJyk7XG4gICAgICBzZXRPYnNlcnZhY2lvbmVzKGRhdGEub2JzZXJ2YWNpb25lc0dlbmVyYWxlcyB8fCBkYXRhLmRhdG9zVGVjbmljb3M/Lm9ic2VydmFjaW9uVHJhbnNmZXJlbmNpYSB8fCAnJyk7XG4gICAgICBzZXREdChkYXRhLmRhdG9zVGVjbmljb3MgfHwge30pO1xuICAgICAgc2V0Rm90b0Jsb2IoZGF0YS5mb3RvQmxvYiB8fCBudWxsKTtcbiAgICAgIHNldEZvdG9TcmMoZGF0YS5mb3RvIHx8IG51bGwpO1xuICAgIH1cbiAgfSwgW2RhdGFdKTtcblxuICAvLyBGYWxsYmFjayBzaSBubyBoYXkgZGF0b3NcbiAgaWYgKCFkYXRhKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC0xMiB0ZXh0LXNsYXRlLTQwMCBmb250LXNhbnNcIj5cbiAgICAgICAgPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1zbGF0ZS02MDAgbXgtYXV0byBtYi0zIGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc21cIj5ObyBzZSBoYW4gZW5jb250cmFkbyBkYXRvcyBwYXJhIGVzdGEgdW5pZGFkIGRlIFRyYW5zZmVyZW5jaWEuPC9wPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUR0Q2hhbmdlID0gKGtleSwgdmFsdWUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBzZXREdChwcmV2ID0+ICh7IC4uLnByZXYsIFtrZXldOiB2YWx1ZSB9KSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlTmVzdGVkRHRDaGFuZ2UgPSAocGFyZW50S2V5LCBrZXksIHZhbHVlKSA9PiB7XG4gICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgc2V0RHQocHJldiA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIFtwYXJlbnRLZXldOiB7XG4gICAgICAgIC4uLihwcmV2W3BhcmVudEtleV0gfHwge30pLFxuICAgICAgICBba2V5XTogdmFsdWVcbiAgICAgIH1cbiAgICB9KSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2F2ZSA9ICgpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBpZiAob25VcGRhdGUpIHtcbiAgICAgIG9uVXBkYXRlKHtcbiAgICAgICAgLi4uZGF0YSxcbiAgICAgICAgbm9tYnJlLFxuICAgICAgICB1YmljYWNpb24sXG4gICAgICAgIG9ic2VydmFjaW9uZXNHZW5lcmFsZXM6IG9ic2VydmFjaW9uZXMsXG4gICAgICAgIGZvdG9CbG9iLFxuICAgICAgICBmb3RvOiBmb3RvU3JjLFxuICAgICAgICBkYXRvc1RlY25pY29zOiB7XG4gICAgICAgICAgLi4uZHQsXG4gICAgICAgICAgb2JzZXJ2YWNpb25UcmFuc2ZlcmVuY2lhOiBvYnNlcnZhY2lvbmVzXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICBzZXRJc0VkaXRpbmcoZmFsc2UpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxpbXBpYXJGb3JtdWxhcmlvID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmIChyZWFkT25seSkgcmV0dXJuO1xuICAgIGNvbnN0IGNvbmZpcm1lZCA9IGF3YWl0IGN1c3RvbUNvbmZpcm0oXCLCv0Rlc2VhcyByZWluaWNpYXIgdG9kb3MgbG9zIGNhbXBvcyBkZSBlc3RhIHRyYW5zZmVyZW5jaWEgYSB2YWxvcmVzIGVuIGJsYW5jbz9cIik7XG4gICAgaWYgKCFjb25maXJtZWQpIHJldHVybjtcblxuICAgIHNldE5vbWJyZSgnJyk7XG4gICAgc2V0VWJpY2FjaW9uKCcnKTtcbiAgICBzZXRPYnNlcnZhY2lvbmVzKCcnKTtcbiAgICBzZXREdCh7fSk7XG4gICAgc2V0Rm90b0Jsb2IobnVsbCk7XG4gICAgc2V0Rm90b1NyYyhudWxsKTtcbiAgICBpZiAocHJldmlld1VybCkgVVJMLnJldm9rZU9iamVjdFVSTChwcmV2aWV3VXJsKTtcbiAgICBzZXRQcmV2aWV3VXJsKG51bGwpO1xuICB9O1xuXG4gIC8vIFZhbG9yZXMgZGUgY29uZmlndXJhY2nDs24gb3BlcmF0aXZhXG4gIGNvbnN0IG1vZG9PcGVyYXRpdm8gPSBkdC5tb2RvT3BlcmF0aXZvIHx8IGR0LnRpcG9UcmFuc2ZlcmVuY2lhT3BlcmF0aXZhIHx8IChkdC50aXBvVHJhbnNmZXJlbmNpYT8udG9VcHBlckNhc2UoKS5pbmNsdWRlcygnTUFOVUFMJykgfHwgZHQudGlwb1RyYW5zZmVyZW5jaWE/LnRvVXBwZXJDYXNlKCkuaW5jbHVkZXMoJ01UUycpID8gJ01UUycgOiAnQVRTJyk7XG4gIGNvbnN0IGVzdGFkb1NlcnZpY2lvID0gZHQuZXN0YWRvU2VydmljaW8gfHwgJ0VuIFNlcnZpY2lvJzsgLy8gJ0VuIFNlcnZpY2lvJyB8ICdGdWVyYSBkZSBTZXJ2aWNpbydcbiAgY29uc3QgdGlwb1RyYW5zaWNpb24gPSBkdC50aXBvVHJhbnNpY2lvbiB8fCAnQUJJRVJUQSc7IC8vICdBQklFUlRBJyB8ICdDRVJSQURBJyB8ICdSRVRBUkRBREEnXG4gIGNvbnN0IHRpcG9FbmNsYXZhbWllbnRvID0gZHQudGlwb0VuY2xhdmFtaWVudG8gfHwgJ01FQ0FOSUNPX0VMRUNUUklDTyc7XG4gIGNvbnN0IHBvbG9zID0gZHQucG9sb3MgfHwgJzRQJztcbiAgY29uc3QgZnJlY3VlbmNpYSA9IGR0LmZyZWN1ZW5jaWEgfHwgJzYwIEh6JztcblxuICAvLyBWYWxvcmVzIGRlIEZ1ZW50ZSBOb3JtYWwgKEZ1ZW50ZSBBKVxuICBjb25zdCBmdWVudGVOb3JtYWxOb21icmUgPSBkdC5mdWVudGVOb3JtYWxOb21icmUgfHwgZHQuYWxpbWVudGFjaW9uR2VuZXJhZG9yMSB8fCBkdC5hbGltZW50YWNpb25Db3Jwb2VsZWMgfHwgJyc7XG4gIGNvbnN0IGZ1ZW50ZU5vcm1hbFRlbnNpb24gPSBkdC5mdWVudGVOb3JtYWxUZW5zaW9uIHx8ICcnO1xuICBjb25zdCBmdWVudGVOb3JtYWxBbXBlcmFqZSA9IGR0LmZ1ZW50ZU5vcm1hbEFtcGVyYWplIHx8IGR0LmFtcGVyYWplIHx8ICcnO1xuICBjb25zdCBmdWVudGVOb3JtYWxDb25kdWN0b3IgPSBkdC5mdWVudGVOb3JtYWxDb25kdWN0b3IgfHwgZHQuY29uZHVjdG9yRnVlbnRlTm9ybWFsIHx8ICcnO1xuXG4gIC8vIFZhbG9yZXMgZGUgRnVlbnRlIEVtZXJnZW5jaWEgKEZ1ZW50ZSBCKVxuICBjb25zdCBmdWVudGVFbWVyZ2VuY2lhTm9tYnJlID0gZHQuZnVlbnRlRW1lcmdlbmNpYU5vbWJyZSB8fCBkdC5hbGltZW50YWNpb25HZW5lcmFkb3IyIHx8IGR0LmFsaW1lbnRhY2lvblRyYW5zZkRvbW9zYSB8fCAnJztcbiAgY29uc3QgZnVlbnRlRW1lcmdlbmNpYVRlbnNpb24gPSBkdC5mdWVudGVFbWVyZ2VuY2lhVGVuc2lvbiB8fCAnJztcbiAgY29uc3QgZnVlbnRlRW1lcmdlbmNpYUFtcGVyYWplID0gZHQuZnVlbnRlRW1lcmdlbmNpYUFtcGVyYWplIHx8IGR0LmFtcGVyYWplIHx8ICcnO1xuICBjb25zdCBmdWVudGVFbWVyZ2VuY2lhQ29uZHVjdG9yID0gZHQuZnVlbnRlRW1lcmdlbmNpYUNvbmR1Y3RvciB8fCBkdC5jb25kdWN0b3JGdWVudGVFbWVyZ2VuY2lhIHx8ICcnO1xuXG4gIC8vIFNhbGlkYSBhIENhcmdhXG4gIGNvbnN0IHNhbGlkYUNhcmdhTm9tYnJlID0gZHQuc2FsaWRhQ2FyZ2FOb21icmUgfHwgZHQuY2FyZ2EgfHwgJyc7XG4gIGNvbnN0IHNhbGlkYUNhcmdhQ29uZHVjdG9yID0gZHQuc2FsaWRhQ2FyZ2FDb25kdWN0b3IgfHwgJyc7XG4gIGNvbnN0IG5ldXRyb0NvbmR1Y3RvciA9IGR0Lm5ldXRyb0NvbmR1Y3RvciB8fCBkdC5uZXV0cm8gfHwgJyc7XG4gIGNvbnN0IHRpZXJyYUNvbmR1Y3RvciA9IGR0LnRpZXJyYUNvbmR1Y3RvciB8fCBkdC50aWVycmEgfHwgJyc7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YG1heC13LTZ4bCBteC1hdXRvIHNwYWNlLXktNiBhbmltYXRlLWZhZGUtaW4gZm9udC1zYW5zIHBiLTE2IHByaW50LWNhcmQgcHJpbnQ6cC0wIHByaW50Om0tMCAke3JlYWRPbmx5ID8gJ3BvaW50ZXItZXZlbnRzLW5vbmUgb3BhY2l0eS05NScgOiAnJ31gfT5cbiAgICAgIFxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7LyogMS4gQkFSUkEgREUgSEVSUkFNSUVOVEFTIFkgQUNDSU9ORVMgU1VQRVJJT1JFUyAoTk8gUFJJTlQpICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgbm8tcHJpbnQgYmctc2xhdGUtOTUwLzgwIGJhY2tkcm9wLWJsdXItbWQgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNoYWRvdy14bFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSBiZy1ncmFkaWVudC10by1iciBmcm9tLWFtYmVyLTUwMC8yMCB0by1hbWJlci02MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LWJsYWNrIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBiZy1hbWJlci01MDAvMTAgdGV4dC1hbWJlci00MDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMjBcIj5cbiAgICAgICAgICAgICAgICB7bW9kb09wZXJhdGl2byA9PT0gJ0FUUycgPyAn8J+UhCBUUkFOU0ZFUkVOQ0lBIEFVVE9Nw4FUSUNBIChBVFMpJyA6ICfwn5SAIFRSQU5TRkVSRU5DSUEgTUFOVUFMIChNVFMpJ31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCAke2VzdGFkb1NlcnZpY2lvID09PSAnRW4gU2VydmljaW8nID8gJ2JnLWVtZXJhbGQtOTUwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTgwMCcgOiAnYmctcmVkLTk1MCB0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtODAwJ31gfT5cbiAgICAgICAgICAgICAgICB7ZXN0YWRvU2VydmljaW99XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGJnLXNsYXRlLTkwMCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgSUQ6IHtkYXRhLmlkfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS0xMDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgIHtub21icmUgfHwgJ1VuaWRhZCBkZSBUcmFuc2ZlcmVuY2lhJ31cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5wcmludCgpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTIwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICB0aXRsZT1cIkd1YXJkYXIgY29tbyBQREYgbyBJbXByaW1pciBGaWNoYVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+R3VhcmRhciBQREY8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICB7IXJlYWRPbmx5ICYmIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIHtpc0VkaXRpbmcgJiYgKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTGltcGlhckZvcm11bGFyaW99XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgaG92ZXI6YmctcmVkLTk1MC82MCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXJlZC04MDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBmb250LWJvbGQgdGV4dC14cyBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVpbmljaWFyIHRvZG9zIGxvcyBjYW1wb3MgYSBibGFuY29cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPkxpbXBpYXIgRm9ybXVsYXJpbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctZW1lcmFsZC01MDAgaG92ZXI6YmctZW1lcmFsZC00MDAgdGV4dC1zbGF0ZS05NTAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBmb250LWJsYWNrIHRleHQteHMgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgc2hhZG93LWxnIHNoYWRvdy1lbWVyYWxkLTUwMC8yMCBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxTYXZlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBHdWFyZGFyIENhbWJpb3NcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0VkaXRpbmcodHJ1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCB0ZXh0LXNsYXRlLTk1MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGZvbnQtYmxhY2sgdGV4dC14cyBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaGFkb3ctbGcgc2hhZG93LWFtYmVyLTUwMC8yMCBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxFZGl0MyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gRWRpdGFyIFRyYW5zZmVyZW5jaWFcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgey8qIDIuIENVQURSTyBQUklOQ0lQQUwgQ09OIFRBUkpFVEEgU1VQRVJJT1IgREVSRUNIQSBERSBET0JMRSBGVUVOVEUgKi99XG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlci0yIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy0yeGwgcHJpbnQ6Ym9yZGVyLWJsYWNrIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBDYWJlY2VyYSBQcmluY2lwYWwgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXNsYXRlLTkwMCB2aWEtc2xhdGUtOTAwIHRvLXNsYXRlLTg1MCBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS04MDAgcC00IHByaW50OmJnLWdyYXktMTAwIHByaW50OmJvcmRlci1ibGFja1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1ib2xkIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWFtYmVyLTQwMCB1cHBlcmNhc2VcIj5cbiAgICAgICAgICAgICAgICBTSVNURU1BIERFIENPTk1VVEFDScOTTiBERSBQT1RFTkNJQSDigKIge21vZG9PcGVyYXRpdm8gPT09ICdBVFMnID8gJ0FVVE9NQVRJQyBUUkFOU0ZFUiBTV0lUQ0gnIDogJ01BTlVBTCBUUkFOU0ZFUiBTV0lUQ0gnfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS0xMDAgdHJhY2tpbmctd2lkZSB1cHBlcmNhc2UgZm9udC1tb25vIHByaW50OnRleHQtYmxhY2tcIj5cbiAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25vbWJyZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROb21icmUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBBVFMtMSAtIFRyYW5zZmVyZW5jaWEgUHJpbmNpcGFsIFPDs3Rhbm9cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBweC0zIHB5LTEuNSB3LWZ1bGwgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgdGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIHBsYWNlaG9sZGVyLXNsYXRlLTYwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICBub21icmUgfHwgJ0FUUyAtIFRyYW5zZmVyZW5jaWEnXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMFwiPkNhcGFjaWRhZCBOb21pbmFsOjwvc3Bhbj5cbiAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC5hbXBlcmFqZSB8fCBkdC5jYXBhY2lkYWRBbXBlcmlvcyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2FtcGVyYWplJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMzIwMCBBXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXhzIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1hbWJlci00MDAgdGV4dC1jZW50ZXIgdy0yOFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgYmctYW1iZXItNTAwLzEwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIHRleHQtYW1iZXItNDAwIHJvdW5kZWQtbGcgZm9udC1tb25vIGZvbnQtYmxhY2sgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAge2R0LmFtcGVyYWplIHx8IGR0LmNhcGFjaWRhZEFtcGVyaW9zID8gYCR7ZHQuYW1wZXJhamUgfHwgZHQuY2FwYWNpZGFkQW1wZXJpb3N9YCA6ICfigJQnfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTGF5b3V0IGRlIDIgQ29sdW1uYXMgU3VwZXJpb3JlczogSXpxdWllcmRhIChHZW5lcmFsZXMpIHkgRGVyZWNoYSAoRG9ibGUgRnVlbnRlKSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0xMiBkaXZpZGUteSBsZzpkaXZpZGUteS0wIGxnOmRpdmlkZS14IGRpdmlkZS1zbGF0ZS04MDAgYm9yZGVyLWItMiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIENvbHVtbmEgSXpxdWllcmRhOiBEYXRvcyBkZWwgRXF1aXBvIHkgUGFyw6FtZXRyb3MgQ29uc3RydWN0aXZvcyAoNSBjb2x1bW5hcykgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IHAtNSBzcGFjZS15LTQgYmctc2xhdGUtOTAwLzQwXCI+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJsYWNrIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8Q3B1IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgICBFc3BlY2lmaWNhY2lvbmVzIENvbnN0cnVjdGl2YXMgZGVsIEFUUyAvIE1UU1xuICAgICAgICAgICAgPC9oMz5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC14cyBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYmctc2xhdGUtOTAwLzgwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGRcIj5VQklDQUNJw5NOOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3ViaWNhY2lvbn1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVYmljYWNpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBTYWxhIFTDqWNuaWNhIC8gU8OzdGFub1wiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXJpZ2h0IHRleHQteHMgcGxhY2Vob2xkZXItc2xhdGUtNjAwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIGZvbnQtc2VtaWJvbGRcIj57dWJpY2FjaW9uIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBiZy1zbGF0ZS05MDAvODAgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZFwiPk1PREVMTyAvIE1BUkNBOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2R0Lm1vZGVsbyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnbW9kZWxvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBTb2NvbWVjIEFUeVMgLyBZVVlFLVlFUzFcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgdGV4dC1yaWdodCB0ZXh0LXhzIHBsYWNlaG9sZGVyLXNsYXRlLTYwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBmb250LXNlbWlib2xkXCI+e2R0Lm1vZGVsbyB8fCBkdC50aXBvVHJhbnNmZXJlbmNpYSB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFRlbnNpw7NuIE5vbWluYWwgTm9ybWFsaXphZGEgKENPVkVOSU4gMTU5KSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvODAgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBibG9jayBmb250LWJvbGRcIj5URU5TScOTTiBOT01JTkFMIChDT1ZFTklOIDE1OSk6PC9zcGFuPlxuICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdC50ZW5zaW9uTm9taW5hbCB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgndGVuc2lvbk5vbWluYWwnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgdGV4dC14cyBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+LS0gU2VsZWNjaW9uYXIgVGVuc2nDs24gTm9ybWFsaXphZGEgLS08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAge1RFTlNJT05FU19DT1ZFTklOXzE1OV9CVC5tYXAodiA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3Z9IHZhbHVlPXt2fT57dn08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGQgdGV4dC1zbSBibG9jayBtdC0wLjVcIj57ZHQudGVuc2lvbk5vbWluYWwgfHwgJ+KAlCd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBQb2xvcyB5IEZyZWN1ZW5jaWEgZGVzYWNvcGxhZG9zICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzgwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGJsb2NrIGZvbnQtYm9sZFwiPk7CsCBERSBQT0xPUzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BvbG9zfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3BvbG9zJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtdC0xIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7UE9MT1NfVFJBTlNGRVJFTkNJQS5tYXAocCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17cH0gdmFsdWU9e3B9PntwfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYW1iZXItNDAwIGZvbnQtYm9sZCB0ZXh0LXNtIGJsb2NrIG10LTAuNVwiPntwb2xvc308L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvODAgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgYmxvY2sgZm9udC1ib2xkXCI+RlJFQ1VFTkNJQTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZyZWN1ZW5jaWF9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnZnJlY3VlbmNpYScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbXQtMSBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgdGV4dC14cyBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge0ZSRUNVRU5DSUFTX05PUk1BTElaQURBUy5tYXAoZiA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Zn0gdmFsdWU9e2Z9PntmfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2t5LTQwMCBmb250LWJvbGQgdGV4dC1zbSBibG9jayBtdC0wLjVcIj57ZnJlY3VlbmNpYX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQ29udHJvbGFkb3IgQVRTOiBCbG9xdWVhZG8geSBkZXNoYWJpbGl0YWRvIHNpIHRpcG8gZXMgTUFOVUFMIChNVFMpICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciAke21vZG9PcGVyYXRpdm8gPT09ICdNVFMnID8gJ2JnLXNsYXRlLTk1MC80MCBib3JkZXItc2xhdGUtODUwIG9wYWNpdHktNjAnIDogJ2JnLXNsYXRlLTkwMC84MCBib3JkZXItc2xhdGUtODAwJ31gfT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZFwiPkNPTlRST0xBRE9SIEFUUzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7bW9kb09wZXJhdGl2byA9PT0gJ01UUycgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtYW1iZXItNTAwIGZvbnQtc2VtaWJvbGRcIj4oTm8gQXBsaWNhIGVuIG1vZG8gTWFudWFsKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXttb2RvT3BlcmF0aXZvID09PSAnTVRTJ31cbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21vZG9PcGVyYXRpdm8gPT09ICdNVFMnID8gJ05vIEFwbGljYSAoVHJhbnNmZXJlbmNpYSBNYW51YWwpJyA6IChkdC5jb250cm9sYWRvckF0cyB8fCAnJyl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2NvbnRyb2xhZG9yQXRzJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBEZWVwIFNlYSBEU0UgMzM0IC8gQ29tQXBcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC1zbGF0ZS0xMDAgdGV4dC1yaWdodCB0ZXh0LXhzIHBsYWNlaG9sZGVyLXNsYXRlLTYwMCBkaXNhYmxlZDpiZy1zbGF0ZS05MDAgZGlzYWJsZWQ6dGV4dC1zbGF0ZS01MDBcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICB7bW9kb09wZXJhdGl2byA9PT0gJ01UUycgPyAnTm8gQXBsaWNhIChUcmFuc2ZlcmVuY2lhIE1hbnVhbCknIDogKGR0LmNvbnRyb2xhZG9yQXRzIHx8ICfigJQnKX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENvbHVtbmEgRGVyZWNoYTogVEFSSkVUQSBTVVBFUklPUiBERVJFQ0hBIC0gRE9CTEUgRlVFTlRFIERFIEFMSU1FTlRBQ0nDk04gKDcgY29sdW1uYXMpICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyBwLTUgc3BhY2UteS00IGJnLXNsYXRlLTk1MC82MFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTIwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgRG9ibGUgRnVlbnRlIGRlIEFsaW1lbnRhY2nDs24gZGUgbGEgVHJhbnNmZXJlbmNpYVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDAgYmctc2xhdGUtOTAwIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICBKZXJhcnF1w61hIEFjdGl2YVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC0zLjVcIj5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBUYXJqZXRhIDE6IEZVRU5URSBOT1JNQUwgLyBQUklOQ0lQQUwgKFZFUkRFKSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iIGZyb20tZW1lcmFsZC05NTAvMzAgdG8tc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgcm91bmRlZC14bCBwLTMuNSBzcGFjZS15LTIuNSBzaGFkb3ctbGcgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLWVtZXJhbGQtNTAwLzIwIHBiLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LWJsYWNrIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvNDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC00MDAgYW5pbWF0ZS1wdWxzZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgRnVlbnRlIE5vcm1hbCAoUHJpb3JpZGFkIDEpXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtZW1lcmFsZC00MDBcIj5SRUQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzlweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIE9yaWdlbiAvIEFsaW1lbnRhZG9yIE5vcm1hbDpcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0b3JBbGltZW50YWRvckplcmFycXVpY29cbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZnVlbnRlTm9ybWFsTm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVEdENoYW5nZSgnZnVlbnRlTm9ybWFsTm9tYnJlJywgdmFsKX1cbiAgICAgICAgICAgICAgICAgICAgICBwcm95ZWN0b0lkPXtkYXRhLnByb3llY3RvSWR9XG4gICAgICAgICAgICAgICAgICAgICAgdGFibGVyb0FjdHVhbElkPXtkYXRhLmlkfVxuICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnRvc0xpc3Q9e3Byb2plY3RFbGVtZW50c31cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjY2lvbmFyIFN1YmVzdGFjacOzbiwgVHJhbnNmb3JtYWRvci4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJcIlxuICAgICAgICAgICAgICAgICAgICAgIGFsbG93UXVpY2tDcmVhdGU9e3RydWV9XG4gICAgICAgICAgICAgICAgICAgICAgb25RdWlja0NyZWF0ZT17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0UXVpY2tDcmVhdGVUYXJnZXRGaWVsZCgnZnVlbnRlTm9ybWFsJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXROZXdTb3VyY2VUaXBvKCdUUkFOU0ZPUk1BRE9SJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXROZXdTb3VyY2VOb21icmUoYFRyYW5zZm9ybWFkb3IgQWxpbWVudGFkb3IgJHtwcm9qZWN0RWxlbWVudHMuZmlsdGVyKGUgPT4gZS50aXBvRWxlbWVudG8gPT09ICdUUkFOU0ZPUk1BRE9SJykubGVuZ3RoICsgMX1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldE5ld1NvdXJjZUNhcGFjaWRhZChkdC5hbXBlcmFqZSB8fCAnNTAwJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXROZXdTb3VyY2VUZW5zaW9uKGR0LnRlbnNpb25Ob21pbmFsIHx8ICcyMDgvMTIwIFYnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFF1aWNrQ3JlYXRlT3Blbih0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIHRleHQteHMgZm9udC1tb25vIHRydW5jYXRlXCIgdGl0bGU9e2Z1ZW50ZU5vcm1hbE5vbWJyZX0+XG4gICAgICAgICAgICAgICAgICAgICAge2Z1ZW50ZU5vcm1hbE5vbWJyZSB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiB0ZXh0LVsxMHB4XSBmb250LW1vbm8gcHQtMSBib3JkZXItdCBib3JkZXItc2xhdGUtODAwLzgwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LWJvbGRcIj5URU5TScOTTjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZnVlbnRlTm9ybWFsVGVuc2lvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2Z1ZW50ZU5vcm1hbFRlbnNpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAyMDgvMTIwVlwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMS41IHB5LTAuNSB0ZXh0LXNsYXRlLTEwMCB0ZXh0LVsxMHB4XVwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGRcIj57ZnVlbnRlTm9ybWFsVGVuc2lvbiB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtYm9sZFwiPkNBUEFDSURBRCBCUkVBS0VSOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmdWVudGVOb3JtYWxBbXBlcmFqZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRHRDaGFuZ2UoJ2Z1ZW50ZU5vcm1hbEFtcGVyYWplJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMzIwMCBBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0xLjUgcHktMC41IHRleHQtc2xhdGUtMTAwIHRleHQtWzEwcHhdXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZFwiPntmdWVudGVOb3JtYWxBbXBlcmFqZSB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tb25vIHB0LTEgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1ib2xkXCI+Q09ORFVDVE9SIERFIEFDT01FVElEQTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Z1ZW50ZU5vcm1hbENvbmR1Y3Rvcn1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdmdWVudGVOb3JtYWxDb25kdWN0b3InLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMigzWDUwMCBNQ00pXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbXQtMSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTAuNSB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIGZvbnQtYm9sZCBibG9jayBtdC0wLjVcIj57ZnVlbnRlTm9ybWFsQ29uZHVjdG9yIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBUYXJqZXRhIDI6IEZVRU5URSBFTUVSR0VOQ0lBICjDgU1CQVIvUk9KTykgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYiBmcm9tLWFtYmVyLTk1MC8zMCB0by1zbGF0ZS05MDAvOTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcm91bmRlZC14bCBwLTMuNSBzcGFjZS15LTIuNSBzaGFkb3ctbGcgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLWFtYmVyLTUwMC8yMCBwYi0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItNDAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzQwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTQwMCBhbmltYXRlLXB1bHNlXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICBGdWVudGUgRW1lcmdlbmNpYSAoUHJpb3JpZGFkIDIpXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwXCI+R0VOPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVs5cHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICBPcmlnZW4gLyBQbGFudGEgR2VuZXJhZG9yOlxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RvckFsaW1lbnRhZG9ySmVyYXJxdWljb1xuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmdWVudGVFbWVyZ2VuY2lhTm9tYnJlfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVEdENoYW5nZSgnZnVlbnRlRW1lcmdlbmNpYU5vbWJyZScsIHZhbCl9XG4gICAgICAgICAgICAgICAgICAgICAgcHJveWVjdG9JZD17ZGF0YS5wcm95ZWN0b0lkfVxuICAgICAgICAgICAgICAgICAgICAgIHRhYmxlcm9BY3R1YWxJZD17ZGF0YS5pZH1cbiAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50b3NMaXN0PXtwcm9qZWN0RWxlbWVudHN9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY2Npb25hciBHZW5lcmFkb3IgLyBQbGFudGEuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiXCJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd1F1aWNrQ3JlYXRlPXt0cnVlfVxuICAgICAgICAgICAgICAgICAgICAgIG9uUXVpY2tDcmVhdGU9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFF1aWNrQ3JlYXRlVGFyZ2V0RmllbGQoJ2Z1ZW50ZUVtZXJnZW5jaWEnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldE5ld1NvdXJjZVRpcG8oJ0dFTkVSQURPUicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0TmV3U291cmNlTm9tYnJlKGBHZW5lcmFkb3IgRW1lcmdlbmNpYSAke3Byb2plY3RFbGVtZW50cy5maWx0ZXIoZSA9PiBlLnRpcG9FbGVtZW50byA9PT0gJ0dFTkVSQURPUicpLmxlbmd0aCArIDF9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXROZXdTb3VyY2VDYXBhY2lkYWQoZHQuYW1wZXJhamUgfHwgJzUwMCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0TmV3U291cmNlVGVuc2lvbihkdC50ZW5zaW9uTm9taW5hbCB8fCAnMjA4LzEyMCBWJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRRdWlja0NyZWF0ZU9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIGZvbnQtbW9ubyB0cnVuY2F0ZVwiIHRpdGxlPXtmdWVudGVFbWVyZ2VuY2lhTm9tYnJlfT5cbiAgICAgICAgICAgICAgICAgICAgICB7ZnVlbnRlRW1lcmdlbmNpYU5vbWJyZSB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiB0ZXh0LVsxMHB4XSBmb250LW1vbm8gcHQtMSBib3JkZXItdCBib3JkZXItc2xhdGUtODAwLzgwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LWJvbGRcIj5URU5TScOTTjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZnVlbnRlRW1lcmdlbmNpYVRlbnNpb259XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdmdWVudGVFbWVyZ2VuY2lhVGVuc2lvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDIwOC8xMjBWXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0xLjUgcHktMC41IHRleHQtc2xhdGUtMTAwIHRleHQtWzEwcHhdXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZFwiPntmdWVudGVFbWVyZ2VuY2lhVGVuc2lvbiB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtYm9sZFwiPkNBUEFDSURBRCBCUkVBS0VSOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmdWVudGVFbWVyZ2VuY2lhQW1wZXJhamV9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdmdWVudGVFbWVyZ2VuY2lhQW1wZXJhamUnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAzMjAwIEFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTEuNSBweS0wLjUgdGV4dC1zbGF0ZS0xMDAgdGV4dC1bMTBweF1cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkXCI+e2Z1ZW50ZUVtZXJnZW5jaWFBbXBlcmFqZSB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tb25vIHB0LTEgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1ib2xkXCI+Q09ORFVDVE9SIERFIEFDT01FVElEQTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Z1ZW50ZUVtZXJnZW5jaWFDb25kdWN0b3J9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnZnVlbnRlRW1lcmdlbmNpYUNvbmR1Y3RvcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAyKDNYNTAwIE1DTSlcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtdC0xIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMC41IHRleHQtc2xhdGUtMTAwIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIGJsb2NrIG10LTAuNVwiPntmdWVudGVFbWVyZ2VuY2lhQ29uZHVjdG9yIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgIHsvKiAzLiBFTkNMQVZBTUlFTlRPLCBNT0RPIE9QRVJBVElWTyBZIEVTVEFETyBERSBTRVJWSUNJTyAqL31cbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXNsYXRlLTkwMC85MCBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgbWQ6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICB7LyogTW9kbyBPcGVyYXRpdm8gKEFUUyAvIE1UUykgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgIDxTbGlkZXJzIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgICAgIE1vZG8gZGUgT3BlcmFjacOzbjpcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRHRDaGFuZ2UoJ21vZG9PcGVyYXRpdm8nLCAnQVRTJyl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJsYWNrIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgbW9kb09wZXJhdGl2byA9PT0gJ0FUUydcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICDwn5SEIEF1dG9tw6F0aWNhIChBVFMpXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUR0Q2hhbmdlKCdtb2RvT3BlcmF0aXZvJywgJ01UUycpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1ibGFjayB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgIG1vZG9PcGVyYXRpdm8gPT09ICdNVFMnXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgc2hhZG93LW1kJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGhvdmVyOnRleHQtc2xhdGUtMjAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAg8J+UgCBNYW51YWwgKE1UUylcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMgcHktMSBiZy1zbGF0ZS05MDAgdGV4dC1hbWJlci00MDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYmxhY2sgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICB7bW9kb09wZXJhdGl2byA9PT0gJ0FUUycgPyAn8J+UhCBBVVRPTcOBVElDQSAoQVRTKScgOiAn8J+UgCBNQU5VQUwgKE1UUyknfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU2VsZWN0b3IgZGUgRXN0YWRvIGRlIFNlcnZpY2lvIChFbiBTZXJ2aWNpbyAvIEZ1ZXJhIGRlIFNlcnZpY2lvKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgIEVzdGFkbyBkZSBPcGVyYXRpdmlkYWQ6XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZXN0YWRvU2VydmljaW99XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCdlc3RhZG9TZXJ2aWNpbycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHB4LTMgcHktMS41IHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYW1iZXItNTAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRW4gU2VydmljaW9cIj7wn5+iIEVuIFNlcnZpY2lvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRnVlcmEgZGUgU2VydmljaW9cIj7wn5S0IEZ1ZXJhIGRlIFNlcnZpY2lvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMyBweS0xIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgZm9udC1tb25vICR7XG4gICAgICAgICAgICAgICAgICBlc3RhZG9TZXJ2aWNpbyA9PT0gJ0VuIFNlcnZpY2lvJyBcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC05NTAgdGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtODAwJyBcbiAgICAgICAgICAgICAgICAgICAgOiAnYmctcmVkLTk1MCB0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtODAwJ1xuICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgIHtlc3RhZG9TZXJ2aWNpbyA9PT0gJ0VuIFNlcnZpY2lvJyA/ICfwn5+iIEVuIFNlcnZpY2lvJyA6ICfwn5S0IEZ1ZXJhIGRlIFNlcnZpY2lvJ31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNlbGVjdG9yIGRlIFRpcG8gZGUgVHJhbnNpY2nDs24gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0TGVmdCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2t5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgVHJhbnNpY2nDs246XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dGlwb1RyYW5zaWNpb259XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCd0aXBvVHJhbnNpY2lvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHB4LTMgcHktMS41IHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYW1iZXItNTAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQUJJRVJUQVwiPkFiaWVydGEgKEJyZWFrLUJlZm9yZS1NYWtlIC8gSS0wLUlJKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNFUlJBREFcIj5DZXJyYWRhIChNYWtlLUJlZm9yZS1CcmVhayAvIFNpbiBDb3J0ZSk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJSRVRBUkRBREFcIj5SZXRhcmRhZGEgKFBhdXNhIFByb2dyYW1hZGEgZW4gQ2Vybyk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgYmctc2xhdGUtOTAwIHRleHQtc2t5LTQwMCBib3JkZXIgYm9yZGVyLXNreS01MDAvMzAgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIHt0aXBvVHJhbnNpY2lvbiA9PT0gJ0NFUlJBREEnID8gJ+KaoSBDZXJyYWRhJyA6XG4gICAgICAgICAgICAgICAgICAgdGlwb1RyYW5zaWNpb24gPT09ICdSRVRBUkRBREEnID8gJ+KPse+4jyBSZXRhcmRhZGEnIDpcbiAgICAgICAgICAgICAgICAgICAn8J+UjCBBYmllcnRhJ31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgey8qIDQuIE1FVFJPTE9Hw41BIEVMw4lDVFJJQ0EgQ09NUExFVEEgKENPVkVOSU4gMTU5KSAqL31cbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXNsYXRlLTk1MCBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICA8TWV0cm9sb2dpYUVsZWN0cmljYVNlY3Rpb25cbiAgICAgICAgICAgIG1lZGljaW9uZXM9e2R0Lm1lZGljaW9uZXMgfHwge319XG4gICAgICAgICAgICBvbkNoYW5nZT17KG51ZXZhc01lZGljaW9uZXMpID0+IGhhbmRsZUR0Q2hhbmdlKCdtZWRpY2lvbmVzJywgbnVldmFzTWVkaWNpb25lcyl9XG4gICAgICAgICAgICByZWFkT25seT17IWlzRWRpdGluZ31cbiAgICAgICAgICAgIHRpdHVsbz1cIlBhcsOhbWV0cm9zIGRlIE1lZGljacOzbiBlbiBCYXJyYSBkZSBDYXJnYSBDb23Dum4gKENPVkVOSU4gMTU5KVwiXG4gICAgICAgICAgICBzdWJ0aXR1bG89XCJUZW5zaW9uZXMgTC1MLCBMLU4geSA1IGNhbmFsZXMgZGUgY29ycmllbnRlIChGYXNlcyBBLCBCLCBDLCBOZXV0cm8gTiB5IFRpZXJyYSBQRSlcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICB7LyogNS4gQ1VBRFJPIERFIENPTkRVQ1RPUkVTLCBTQUxJREEgQSBDQVJHQSBZIE5FVVRSTyAqL31cbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHNwYWNlLXktNCBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS04MDAgYmctc2xhdGUtOTUwXCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTIwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZm9udC1tb25vXCI+XG4gICAgICAgICAgICA8TGF5ZXJzIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgTMOtbmVhcyBkZSBTYWxpZGEgQ29ubXV0YWRhIGhhY2lhIGxhIENhcmdhIGRlbCBQcm95ZWN0b1xuICAgICAgICAgIDwvaDM+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgZm9udC1tb25vIHRleHQteHNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzgwIHAtMy41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIHVwcGVyY2FzZSBibG9ja1wiPlxuICAgICAgICAgICAgICAgIENBUkdBIE8gVEFCTEVSTyBBTElNRU5UQURPOlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgPFNlbGVjdG9yQWxpbWVudGFkb3JKZXJhcnF1aWNvXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2FsaWRhQ2FyZ2FOb21icmV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gaGFuZGxlRHRDaGFuZ2UoJ3NhbGlkYUNhcmdhTm9tYnJlJywgdmFsKX1cbiAgICAgICAgICAgICAgICAgIHByb3llY3RvSWQ9e2RhdGEucHJveWVjdG9JZH1cbiAgICAgICAgICAgICAgICAgIHRhYmxlcm9BY3R1YWxJZD17ZGF0YS5pZH1cbiAgICAgICAgICAgICAgICAgIGVsZW1lbnRvc0xpc3Q9e3Byb2plY3RFbGVtZW50c31cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWNjaW9uYXIgVGFibGVybyBEZXN0aW5vLi4uXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0xMDAgZm9udC1ibGFjayB0ZXh0LXNtIHRydW5jYXRlXCIgdGl0bGU9e3NhbGlkYUNhcmdhTm9tYnJlfT5cbiAgICAgICAgICAgICAgICAgIHtzYWxpZGFDYXJnYU5vbWJyZSB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGJsb2NrXCI+Q29uZHVjdG9yIFNhbGlkYTo8L3NwYW4+XG4gICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzYWxpZGFDYXJnYUNvbmR1Y3Rvcn1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnc2FsaWRhQ2FyZ2FDb25kdWN0b3InLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDIoM1g1MDAgTUNNKVwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTAuNSB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzIG10LTAuNVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgdGV4dC14c1wiPntzYWxpZGFDYXJnYUNvbmR1Y3RvciB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvODAgcC0zLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWN5YW4tNDAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICBCQVJSQSBZIENPTkRVQ1RPUiBERSBORVVUUk8gKE4pOlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV1dHJvQ29uZHVjdG9yfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVEdENoYW5nZSgnbmV1dHJvQ29uZHVjdG9yJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMVg1MDAgTUNNIChCYXJyYSBkaXJlY3RhKVwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMiBweS0xIHRleHQtc2xhdGUtMTAwIHRleHQteHNcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHRleHQteHNcIj57bmV1dHJvQ29uZHVjdG9yIHx8ICfigJQnfTwvcD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgYmxvY2tcIj5Db25maWd1cmFjacOzbjogQmFycmEgc8OzbGlkYSBwYXNhbnRlPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzgwIHAtMy41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGQgdXBwZXJjYXNlIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAgVElFUlJBIERFIFBST1RFQ0NJw5NOIChQRSAvIFNQVCk6XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aWVycmFDb25kdWN0b3J9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUR0Q2hhbmdlKCd0aWVycmFDb25kdWN0b3InLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAxWDQvMCBBV0cgKFNQVClcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXNsYXRlLTEwMCB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIGZvbnQtYm9sZCB0ZXh0LXhzXCI+e3RpZXJyYUNvbmR1Y3RvciB8fCAn4oCUJ308L3A+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGJsb2NrXCI+Q29uZXhpw7NuIGRpcmVjdGEgYSBiYXJyYSBkZSBlcXVpcG90ZW5jaWFsaWRhZDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgey8qIDYuIFJFR0lTVFJPIEZPVE9HUsOBRklDTyBZIE9CU0VSVkFDSU9ORVMgVMOJQ05JQ0FTICovfVxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0xMiBkaXZpZGUteSBsZzpkaXZpZGUteS0wIGxnOmRpdmlkZS14IGRpdmlkZS1zbGF0ZS04MDAgYmctc2xhdGUtOTAwLzMwXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIE9ic2VydmFjaW9uZXMgKDcgY29sdW1uYXMpICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyBwLTUgc3BhY2UteS0yLjVcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICA8SW5mbyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgT2JzZXJ2YWNpb25lcyBUw6ljbmljYXMgeSBEaWFnbsOzc3RpY29cbiAgICAgICAgICAgIDwvaDM+XG5cbiAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXG4gICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgIHJvd3M9ezV9XG4gICAgICAgICAgICAgICAgdmFsdWU9e29ic2VydmFjaW9uZXN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRPYnNlcnZhY2lvbmVzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkluZGlxdWUgbm90YXMgZGUgY29ubXV0YWNpw7NuLCBzZWN1ZW5jaWFzIGRlIGFycmFucXVlIGRlIGdlbmVyYWRvcmVzLCBoYWxsYXpnb3MsIGV0Yy5cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTMgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBmb250LW1vbm8gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcGxhY2Vob2xkZXItc2xhdGUtNjAwXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXNsYXRlLTk1MC83MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQteHMgZm9udC1tb25vIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZCB3aGl0ZXNwYWNlLXByZS13cmFwXCI+XG4gICAgICAgICAgICAgICAge29ic2VydmFjaW9uZXMgfHwgJ1NpbiBvYnNlcnZhY2lvbmVzIHJlZ2lzdHJhZGFzIHBhcmEgZXN0YSB0cmFuc2ZlcmVuY2lhLid9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBGb3RvZ3JhZsOtYSBkZSBsYSBUcmFuc2ZlcmVuY2lhIGNvbiBDYXJnYSBEdWFsICg1IGNvbHVtbmFzKSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTUgcC01XCI+XG4gICAgICAgICAgICA8RHVhbFBob3RvVXBsb2FkZXJcbiAgICAgICAgICAgICAgZm90b0Jsb2I9e2ZvdG9CbG9ifVxuICAgICAgICAgICAgICBmb3RvU3JjPXtmb3RvU3JjfVxuICAgICAgICAgICAgICBwcmV2aWV3VXJsPXtwcmV2aWV3VXJsfVxuICAgICAgICAgICAgICBvbkltYWdlU2VsZWN0ZWQ9eyhmaWxlKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0Rm90b0Jsb2IoZmlsZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgICAgICAgICAgICByZWFkZXIub25sb2FkZW5kID0gKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0Rm90b1NyYyhyZWFkZXIucmVzdWx0KTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpO1xuICAgICAgICAgICAgICAgIGlmIChwcmV2aWV3VXJsKSBVUkwucmV2b2tlT2JqZWN0VVJMKHByZXZpZXdVcmwpO1xuICAgICAgICAgICAgICAgIHNldFByZXZpZXdVcmwoVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKSk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIG9uUmVtb3ZlPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0Rm90b0Jsb2IobnVsbCk7XG4gICAgICAgICAgICAgICAgc2V0Rm90b1NyYyhudWxsKTtcbiAgICAgICAgICAgICAgICBpZiAocHJldmlld1VybCkgVVJMLnJldm9rZU9iamVjdFVSTChwcmV2aWV3VXJsKTtcbiAgICAgICAgICAgICAgICBzZXRQcmV2aWV3VXJsKG51bGwpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICByZWFkT25seT17IWlzRWRpdGluZ31cbiAgICAgICAgICAgICAgbGFiZWw9XCJGb3RvZ3JhZsOtYSBkZSBsYSBUcmFuc2ZlcmVuY2lhXCJcbiAgICAgICAgICAgICAgc3VibGFiZWw9XCJDw6FtYXJhIGVuIHZpdm8gbyBzZWxlY2Npw7NuIGRlIGdhbGVyw61hXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTW9kYWwgUsOhcGlkbyBkZSBDcmVhY2nDs24gZGUgRnVlbnRlIC8gR2VuZXJhZG9yIGVuIEzDrW5lYSAqL31cbiAgICAgIHtxdWlja0NyZWF0ZU9wZW4gJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctc2xhdGUtOTUwLzgwIGJhY2tkcm9wLWJsdXItc20gbm8tcHJpbnQgYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctbWQgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzUwIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgcC01IHNwYWNlLXktNCBhbmltYXRlLWluIHpvb20taW4tOTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItNDAwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzBcIj5cbiAgICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYmxhY2sgdXBwZXJjYXNlIHRleHQtc2xhdGUtMTAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICBDcmVhciBGdWVudGUgZGUgQWxpbWVudGFjacOzblxuICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtc2Fuc1wiPlxuICAgICAgICAgICAgICAgICAgICB7cXVpY2tDcmVhdGVUYXJnZXRGaWVsZCA9PT0gJ2Z1ZW50ZU5vcm1hbCcgPyAnRnVlbnRlIE5vcm1hbCAoUHJpb3JpZGFkIDEpJyA6ICdGdWVudGUgRW1lcmdlbmNpYSAoUHJpb3JpZGFkIDIpJ31cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRRdWlja0NyZWF0ZU9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSBob3ZlcjpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQ3JlYXRlUXVpY2tTb3VyY2V9IGNsYXNzTmFtZT1cInNwYWNlLXktMy41IHRleHQteHMgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgVGlwbyBkZSBGdWVudGVcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdTb3VyY2VUaXBvfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHQgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgc2V0TmV3U291cmNlVGlwbyh0KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHQgPT09ICdHRU5FUkFET1InKSBzZXROZXdTb3VyY2VOb21icmUoYEdlbmVyYWRvciBFbWVyZ2VuY2lhICR7cHJvamVjdEVsZW1lbnRzLmZpbHRlcihlbCA9PiBlbC50aXBvRWxlbWVudG8gPT09ICdHRU5FUkFET1InKS5sZW5ndGggKyAxfWApO1xuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICh0ID09PSAnVFJBTlNGT1JNQURPUicpIHNldE5ld1NvdXJjZU5vbWJyZShgVHJhbnNmb3JtYWRvciBQcmluY2lwYWwgJHtwcm9qZWN0RWxlbWVudHMuZmlsdGVyKGVsID0+IGVsLnRpcG9FbGVtZW50byA9PT0gJ1RSQU5TRk9STUFET1InKS5sZW5ndGggKyAxfWApO1xuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICh0ID09PSAnU1VCRVNUQUNJT04nKSBzZXROZXdTb3VyY2VOb21icmUoYFN1YmVzdGFjacOzbiAke3Byb2plY3RFbGVtZW50cy5maWx0ZXIoZWwgPT4gZWwudGlwb0VsZW1lbnRvID09PSAnU1VCRVNUQUNJT04nKS5sZW5ndGggKyAxfWApO1xuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICh0ID09PSAnUFVOVE9fU1VNSU5JU1RSTycgfHwgdCA9PT0gJ1BVTlRPX01FRElDSU9OJykgc2V0TmV3U291cmNlTm9tYnJlKCdQdW50byBkZSBTdW1pbmlzdHJvIENPUlBPRUxFQycpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYW1iZXItNTAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVFJBTlNGT1JNQURPUlwiPlRyYW5zZm9ybWFkb3I8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJHRU5FUkFET1JcIj5HZW5lcmFkb3IgLyBQbGFudGEgRWzDqWN0cmljYTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNVQkVTVEFDSU9OXCI+U3ViZXN0YWNpw7NuIC8gQ2VsZGEgTVQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQVU5UT19TVU1JTklTVFJPXCI+UHVudG8gZGUgU3VtaW5pc3RybyAvIEFjb21ldGlkYTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRBQkxFUk9cIj5UYWJsZXJvIGRlIERpc3RyaWJ1Y2nDs248L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICBOb21icmUgLyBJZGVudGlmaWNhZG9yIGRlIGxhIEZ1ZW50ZVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1NvdXJjZU5vbWJyZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3U291cmNlTm9tYnJlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIEdlbmVyYWRvciBQbGFudGEgRGnDqXNlbCAxNTAga1ZBXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9udC1zYW5zXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICBDYXBhY2lkYWQgKGtWQSAvIEEpXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1NvdXJjZUNhcGFjaWRhZH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdTb3VyY2VDYXBhY2lkYWQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAxNTAga1ZBXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICBUZW5zacOzbiBOb3JtYWxpemFkYVxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1NvdXJjZVRlbnNpb259XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3U291cmNlVGVuc2lvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0yIHB5LTIgdGV4dC1zbGF0ZS0xMDAgdGV4dC14cyBmb250LWJvbGQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7VEVOU0lPTkVTX0NPVkVOSU5fMTU5X0JULm1hcCh2ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dn0gdmFsdWU9e3Z9Pnt2fTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIFViaWNhY2nDs24gRsOtc2ljYVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3U291cmNlVWJpY2FjaW9ufVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdTb3VyY2VVYmljYWNpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gQ2FzZXRhIGRlIEdlbmVyYWNpw7NuIC8gU2FsYSBFbMOpY3RyaWNhXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9udC1zYW5zXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRRdWlja0NyZWF0ZU9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgcm91bmRlZC14bCB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCBhY3RpdmU6c2NhbGUtOTUgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBDcmVhciB5IFZpbmN1bGFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==