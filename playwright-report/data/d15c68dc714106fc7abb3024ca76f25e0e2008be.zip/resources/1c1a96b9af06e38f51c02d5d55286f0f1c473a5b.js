import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ModalEdicionCircuito.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { X, ArrowLeft, Camera, Check, Search, PlusCircle, AlertCircle, Settings, ClipboardList, Cpu, Zap, Activity, ShieldCheck, Layers, Building2, Gauge, Radio, RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import { AMP_OPTIONS, COND_OPTIONS, MARCA_OPTIONS, TIPO_OPTIONS } from "/src/utils/constants.js";
import { validatePoleOccupancy, getRequiredPoles } from "/src/utils/poleValidation.js";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
import DualPhotoUploader from "/src/components/DualPhotoUploader.jsx?t=1790793566895";
import useStore from "/src/store/useStore.js?t=1790792337841";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalEdicionCircuito.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
const normalizeText = (str) => {
	if (typeof str !== "string" || !str) return str || "";
	return str.trim().replace(/\s+/g, " ").toUpperCase();
};
const MOCK_ELEMENTOS_CREADOS = [
	{
		id: "TAB-1",
		nombre: "TABLERO PRINCIPAL DE BAJA TENSIÓN",
		tipo: "TABLERO"
	},
	{
		id: "SUB-1",
		nombre: "SUBESTACIÓN PRINCIPAL 13.8KV",
		tipo: "SUBESTACION"
	},
	{
		id: "ATS-1",
		nombre: "TRANSFERENCIA AUTOMÁTICA SÓTANO",
		tipo: "TRANSFER"
	},
	{
		id: "CCM-1",
		nombre: "CCM BOMBAS DE AGUA",
		tipo: "CCM"
	}
];
export const ModalEdicionCircuito = ({ isOpen, onClose, circuitData, onSave, elementosCreados = MOCK_ELEMENTOS_CREADOS, tableroCircuits = [], maxPolos = 42, onAgregarPorCrear, tipoOrigen = "TABLERO", modo = "SALIDA" }) => {
	_s();
	const { alert: customAlert } = useConfirm();
	const { registrarConflictoCircuito, showToast, setPanelConflictosOpen } = useStore();
	const isTablero = !tipoOrigen || tipoOrigen === "TABLERO";
	const [step, setStep] = useState("PREGUNTA_ES_ARTEFACTO");
	// Campos Tablero / Artefacto
	const [breakerAmp, setBreakerAmp] = useState("");
	const [breakerMarca, setBreakerMarca] = useState("");
	const [breakerTipo, setBreakerTipo] = useState("");
	const [conductor, setConductor] = useState("");
	const [nombreArtefacto, setNombreArtefacto] = useState("");
	const [descArtefacto, setDescArtefacto] = useState("");
	const [potenciaWatts, setPotenciaWatts] = useState("");
	// Parámetros Físicos Tablero
	const [numPolos, setNumPolos] = useState(1);
	const [posicionPolo, setPosicionPolo] = useState(1);
	const [estado, setEstado] = useState("ACTIVO");
	// Búsqueda y vinculación
	const [searchQuery, setSearchQuery] = useState("");
	const [selectedLink, setSelectedLink] = useState(null);
	const [selectedLinks, setSelectedLinks] = useState([]);
	const [selectedElementoDestinoId, setSelectedElementoDestinoId] = useState("");
	const [selectedTipoElementoDestino, setSelectedTipoElementoDestino] = useState("");
	const [selectorValue, setSelectorValue] = useState("");
	const [isCreatingNewProvisional, setIsCreatingNewProvisional] = useState(false);
	const [provisionalCustomName, setProvisionalCustomName] = useState("");
	const [provisionalTipo, setProvisionalTipo] = useState("TABLERO");
	const isMultiSelect = tipoOrigen === "TRANSFORMADOR" && (modo === "SECUNDARIA" || modo === "SALIDA");
	// Rótulo y foto
	const [rotulo, setRotulo] = useState("");
	const [fotoUrl, setFotoUrl] = useState(null);
	// Agrupación universal de elementos creados
	const groupedElements = useMemo(() => {
		const groups = {
			TABLERO: [],
			TRANSFER: [],
			CCM: [],
			GENERADOR: [],
			SUBESTACION: [],
			TRANSFORMADOR: [],
			PUNTO_MEDICION: [],
			OTROS: []
		};
		(elementosCreados || []).forEach((el) => {
			const type = (el.tipo || el.tipoElemento || "").toUpperCase();
			if (type.includes("TRANSFER") || type.includes("ATS") || type.includes("MTS")) {
				groups.TRANSFER.push(el);
			} else if (type.includes("GENERADOR") || type.includes("GEN") || type.includes("PLANTA")) {
				groups.GENERADOR.push(el);
			} else if (type.includes("CCM") || type.includes("MOTOR")) {
				groups.CCM.push(el);
			} else if (type.includes("SUBESTACION") || type.includes("SE")) {
				groups.SUBESTACION.push(el);
			} else if (type.includes("TRANSFO") || type.includes("TRAFO")) {
				groups.TRANSFORMADOR.push(el);
			} else if (type.includes("MEDICION") || type.includes("MEDIDA") || type.includes("PUNTO")) {
				groups.PUNTO_MEDICION.push(el);
			} else if (type.includes("TABLERO") || type === "SUB_TABLERO" || type === "PANEL") {
				groups.TABLERO.push(el);
			} else {
				groups.OTROS.push(el);
			}
		});
		return groups;
	}, [elementosCreados]);
	// Manejar cambio en el selector universal con autocompletado editable
	const handleUniversalElementChange = (e) => {
		const val = e.target.value;
		setSelectorValue(val);
		if (!val || val === "DIRECTO" || val === "NINGUNO") {
			setSelectedElementoDestinoId("");
			setSelectedTipoElementoDestino("");
			setSelectedLink(null);
			setIsCreatingNewProvisional(false);
			setProvisionalCustomName("");
			return;
		}
		if (val.startsWith("NEW_")) {
			setIsCreatingNewProvisional(true);
			setSelectedLink(null);
			setSelectedElementoDestinoId("");
			const requiredList = validation?.requiredPoles || getPolesArray(posicionPolo, numPolos);
			const polesStr = requiredList.join(", ");
			let mappedType = "TABLERO";
			let typeLabel = "Sub-Tablero";
			if (val === "NEW_TRANSFER") {
				mappedType = "TRANSFER";
				typeLabel = "Transferencia Automática (ATS)";
			} else if (val === "NEW_CCM") {
				mappedType = "CCM";
				typeLabel = "Centro de Control de Motores (CCM)";
			} else if (val === "NEW_GENERADOR") {
				mappedType = "GENERADOR";
				typeLabel = "Generador / Planta de Emergencia";
			} else if (val === "NEW_TRANSFORMADOR") {
				mappedType = "TRANSFORMADOR";
				typeLabel = "Transformador de Potencia";
			} else if (val === "NEW_SUBESTACION") {
				mappedType = "SUBESTACION";
				typeLabel = "Subestación Eléctrica";
			} else if (val === "NEW_PUNTO_MEDICION") {
				mappedType = "PUNTO_MEDICION";
				typeLabel = "Punto de Medición / Analizador";
			} else if (val === "NEW_CARGA") {
				mappedType = "CARGA_DIRECTA";
				typeLabel = "Carga Directa";
			}
			setProvisionalTipo(mappedType);
			setSelectedTipoElementoDestino(mappedType);
			const defaultProvisionalName = `Nuevo ${typeLabel} (Polo ${polesStr})`;
			setProvisionalCustomName(defaultProvisionalName);
			const autoDesc = `Reserva para ${typeLabel}: ${defaultProvisionalName}`;
			setNombreArtefacto(autoDesc);
			setRotulo(autoDesc);
			if (!descArtefacto) {
				setDescArtefacto(`Reserva proyectada para alimentar ${typeLabel} desde Polo(s) [${polesStr}]`);
			}
			return;
		}
		// Elemento existente ya registrado
		setIsCreatingNewProvisional(false);
		setProvisionalCustomName("");
		const found = (elementosCreados || []).find((el) => String(el.id) === String(val));
		if (found) {
			setSelectedElementoDestinoId(found.id);
			const t = found.tipo || found.tipoElemento || "TABLERO";
			setSelectedTipoElementoDestino(t);
			setSelectedLink(found);
			const tipoLabel = t === "CCM" ? "CCM" : t === "TRANSFER" ? "Transferencia ATS" : t === "GENERADOR" ? "Generador" : t === "SUBESTACION" ? "Subestación" : t === "TRANSFORMADOR" ? "Transformador" : t === "PUNTO_MEDICION" ? "Equipo de Medida" : t === "TABLERO" ? "Tablero" : t || "Elemento";
			const autoDesc = `Alimentación a ${tipoLabel}: ${found.nombre}`;
			setNombreArtefacto(autoDesc);
			setRotulo(autoDesc);
			if (!descArtefacto) {
				setDescArtefacto(`Alimentación directa hacia ${found.nombre} (ID: ${found.id})`);
			}
		}
	};
	// Campos Equipos de Potencia / Trafo / Gen / ATS / CCM / Punto Medicion / Puesta Tierra
	const [nivelMT, setNivelMT] = useState("");
	const [fusibleMT, setFusibleMT] = useState("");
	const [pararrayos, setPararrayos] = useState("");
	const [canalizacion, setCanalizacion] = useState("");
	const [esquemaArranque, setEsquemaArranque] = useState("");
	const [hpKw, setHpKw] = useState("");
	const [corrienteNominal, setCorrienteNominal] = useState("");
	const [proteccion, setProteccion] = useState("");
	const [redComms, setRedComms] = useState("");
	const [tipoConmutador, setTipoConmutador] = useState("");
	const [relacionTc, setRelacionTc] = useState("");
	const [relacionTp, setRelacionTp] = useState("");
	const [resistenciaOhms, setResistenciaOhms] = useState("");
	const [senalArranque, setSenalArranque] = useState("");
	const [potenciaKvaKw, setPotenciaKvaKw] = useState("");
	const [tensionSecundaria, setTensionSecundaria] = useState("");
	const [interruptorAguasAbajo, setInterruptorAguasAbajo] = useState("");
	// Reversión explícita a Reserva
	const handleRevertirAReserva = () => {
		onSave(circuitData.id, {
			equipo: "RESERVA",
			tipoDestino: "RESERVA",
			vinculadoId: null,
			elementoDestinoId: null,
			tipoElementoDestino: null,
			tipoElementoProvisional: undefined,
			nombreProvisional: undefined,
			breaker: {
				amp: "",
				marca: "",
				tipo: ""
			},
			conductor: "",
			poles: isTablero ? validation.requiredPoles : [
				1,
				2,
				3
			],
			numPolos: isTablero ? numPolos : 1,
			posicionPolo: isTablero ? posicionPolo : 1,
			codigoPolo: circuitData?.codigoPolo || circuitData?.polo_label || "",
			polo_label: circuitData?.polo_label || circuitData?.codigoPolo || "",
			estado: "RESERVA",
			ficha: {
				descripcion: "",
				potenciaWatts: null
			},
			fotografia: null,
			detallesTecnicos: {}
		});
		onClose();
	};
	// Cargar datos al abrir modal
	useEffect(() => {
		if (circuitData && isOpen) {
			setBreakerAmp(circuitData.breaker?.amp || "");
			setBreakerMarca(circuitData.breaker?.marca || "");
			setBreakerTipo(circuitData.breaker?.tipo || "");
			setConductor(circuitData.conductor || "");
			setNombreArtefacto(circuitData.tipoDestino === "ARTEFACTO" ? circuitData.equipo : "");
			setDescArtefacto(circuitData.ficha?.descripcion || "");
			setPotenciaWatts(circuitData.ficha?.potenciaWatts || "");
			setRotulo(circuitData.equipo || circuitData.nombre || "");
			setSelectedLinks([]);
			setIsCreatingNewProvisional(false);
			setProvisionalCustomName("");
			// Pre-inicializar elemento vinculado previamente
			const prevDestinoId = circuitData.elementoDestinoId || circuitData.vinculadoId || "";
			const prevTipoDestino = circuitData.tipoElementoDestino || circuitData.tipoDestino || "";
			setSelectedElementoDestinoId(prevDestinoId);
			setSelectedTipoElementoDestino(prevTipoDestino);
			if (prevDestinoId) {
				setSelectorValue(prevDestinoId);
				const found = (elementosCreados || []).find((el) => String(el.id) === String(prevDestinoId) || el.nombre === circuitData.equipo);
				if (found) {
					setSelectedLink(found);
					setSearchQuery(found.nombre);
				} else {
					setSelectedLink(null);
					setSearchQuery(circuitData.equipo || "");
				}
			} else {
				setSelectorValue("");
				setSelectedLink(null);
				setSearchQuery("");
			}
			// Cargar parámetros físicos de polos para tableros
			const initPolo = circuitData.posicionPolo !== undefined ? circuitData.posicionPolo : circuitData.poles && circuitData.poles.length > 0 ? circuitData.poles[0] : 1;
			const initNum = circuitData.numPolos !== undefined ? circuitData.numPolos : circuitData.poles && circuitData.poles.length > 0 ? circuitData.poles.length : 1;
			setPosicionPolo(parseInt(initPolo, 10) || 1);
			setNumPolos(parseInt(initNum, 10) || 1);
			setEstado(circuitData.estado || (circuitData.equipo === "RESERVA" ? "RESERVA" : "ACTIVO"));
			// Cargar otros campos técnicos si existen
			const dt = circuitData.detallesTecnicos || {};
			if (dt.nivelMT) setNivelMT(dt.nivelMT);
			if (dt.fusibleMT !== undefined) setFusibleMT(dt.fusibleMT);
			if (dt.pararrayos) setPararrayos(dt.pararrayos);
			if (dt.canalizacion) setCanalizacion(dt.canalizacion);
			if (dt.esquemaArranque) setEsquemaArranque(dt.esquemaArranque);
			if (dt.hpKw) setHpKw(dt.hpKw);
			if (dt.corrienteNominal) setCorrienteNominal(dt.corrienteNominal);
			if (dt.proteccion) setProteccion(dt.proteccion);
			if (dt.redComms) setRedComms(dt.redComms);
			if (dt.tipoConmutador) setTipoConmutador(dt.tipoConmutador);
			if (dt.relacionTc) setRelacionTc(dt.relacionTc);
			if (dt.relacionTp) setRelacionTp(dt.relacionTp);
			if (dt.resistenciaOhms) setResistenciaOhms(dt.resistenciaOhms);
			if (dt.senalArranque) setSenalArranque(dt.senalArranque);
			if (dt.potenciaKvaKw) setPotenciaKvaKw(dt.potenciaKvaKw);
			if (dt.tensionSecundaria) setTensionSecundaria(dt.tensionSecundaria);
			if (dt.interruptorAguasAbajo) setInterruptorAguasAbajo(dt.interruptorAguasAbajo);
			// Selección de paso según tipoOrigen y modo
			if (isTablero) {
				if (circuitData.tipoDestino === "ARTEFACTO") {
					setStep("FORMULARIO_ARTEFACTO");
				} else if (circuitData.tipoDestino === "SUB_TABLERO" || circuitData.tipoDestino === "ELEMENTO") {
					setStep("VINCULAR_EXISTENTE");
					const found = elementosCreados.find((el) => el.nombre === circuitData.equipo || el.id === circuitData.vinculadoId);
					if (found) {
						setSelectedLink(found);
						setSearchQuery(found.nombre);
					} else {
						setSearchQuery(circuitData.equipo || "");
					}
				} else if (circuitData.tipoDestino === "SUB_TABLERO_PENDIENTE" || circuitData.tipoDestino === "ELEMENTO_PENDIENTE") {
					setStep("ALIMENTAR_POR_CREAR");
				} else {
					setStep("PREGUNTA_ES_ARTEFACTO");
				}
			} else {
				if (tipoOrigen === "TRANSFORMADOR") {
					if (modo === "ENTRADA" || modo === "PRIMARIA") setStep("PREGUNTA_ORIGEN_MT");
					else setStep("VINCULAR_EXISTENTE");
				} else if (tipoOrigen === "GENERADOR") {
					setStep("PREGUNTA_DESTINO_GEN");
				} else if (tipoOrigen === "TRANSFER") {
					if (modo === "ENTRADA_1" || modo === "ENTRADA") setStep("PREGUNTA_FUENTE_ATS1");
					else if (modo === "ENTRADA_2") setStep("PREGUNTA_FUENTE_ATS2");
					else setStep("PREGUNTA_DESTINO_ATS");
				} else if (tipoOrigen === "CCM") {
					setStep("PREGUNTA_CARGA_CCM");
				} else if (tipoOrigen === "PUNTO_MEDICION") {
					setStep("PREGUNTA_ORIGEN_MEDICION");
				} else if (tipoOrigen === "PUESTA_TIERRA") {
					setStep("PREGUNTA_CONEXION_TIERRA");
				} else {
					setStep("VINCULAR_EXISTENTE");
				}
			}
		}
	}, [
		circuitData,
		isOpen,
		elementosCreados,
		isTablero,
		tipoOrigen,
		modo
	]);
	// Validación de colisión y ocupación de polos en tiempo real
	const validation = useMemo(() => {
		if (!isOpen || !circuitData || !isTablero) {
			return {
				isValid: true,
				requiredPoles: [
					1,
					2,
					3
				],
				exceedsMax: false,
				conflicts: [],
				conflictMessages: []
			};
		}
		return validatePoleOccupancy({
			posicionPolo,
			numPolos,
			maxPolos,
			circuits: tableroCircuits,
			excludeCircuitId: circuitData?.id
		});
	}, [
		isOpen,
		circuitData?.id,
		isTablero,
		posicionPolo,
		numPolos,
		maxPolos,
		tableroCircuits
	]);
	if (!isOpen || !circuitData) return null;
	const filteredElements = (elementosCreados || []).filter((el) => (el.nombre || "").toLowerCase().includes(searchQuery.toLowerCase()) || (el.id || "").toLowerCase().includes(searchQuery.toLowerCase()));
	const getPolesArray = (startPole, n) => {
		const arr = [];
		for (let i = 0; i < n; i++) {
			arr.push(startPole + i * 2);
		}
		return arr;
	};
	const getHeaderTitle = () => {
		if (isTablero) {
			return modo === "ENTRADA" ? "Configurar Fuente de Alimentación" : "Configurar Salida / Circuito";
		}
		if (tipoOrigen === "TRANSFORMADOR") {
			return modo === "ENTRADA" || modo === "PRIMARIA" ? "Configurar Alimentación Primaria MT (Lado Primario)" : "Configurar Salida / Distribución BT (Lado Secundario)";
		}
		if (tipoOrigen === "GENERADOR") {
			return "Configurar Salida de Generación / Respaldo";
		}
		if (tipoOrigen === "TRANSFER") {
			if (modo === "ENTRADA_1" || modo === "ENTRADA") return "Configurar Fuente 1 (Red Principal / Normal)";
			if (modo === "ENTRADA_2") return "Configurar Fuente 2 (Emergencia / Generador)";
			return "Configurar Salida / Cargas Respaldo";
		}
		if (tipoOrigen === "CCM") {
			return "Configurar Gaveta / Bucket CCM";
		}
		if (tipoOrigen === "PUNTO_MEDICION") {
			return "Configurar Entrada de Acometida / Suministro";
		}
		if (tipoOrigen === "PUESTA_TIERRA") {
			return "Configurar Conexión a Malla / Puesta a Tierra";
		}
		return `Configurar Conexión - ${tipoOrigen}`;
	};
	const handleSaveEquipment = (equipoName, tipoDestinoVal, extra = {}) => {
		let finalTipoDestino = tipoDestinoVal || selectedTipoElementoDestino || "SUB_TABLERO";
		let finalDestinoId = selectedElementoDestinoId || extra.elementoDestinoId || extra.vinculadoId || selectedLink?.id || null;
		if (isCreatingNewProvisional) {
			finalTipoDestino = "SUB_TABLERO_PENDIENTE";
		}
		const finalEquipo = normalizeText(equipoName || extra.equipo || provisionalCustomName || rotulo || "EQUIPO DE POTENCIA");
		if (isTablero && !validation.isValid && validation.conflicts && validation.conflicts.length > 0) {
			validation.conflicts.forEach((conf) => {
				registrarConflictoCircuito({
					tableroId: circuitData?.tableroId || circuitData?.id || "TABLERO",
					tableroNombre: circuitData?.tableroNombre || "Tablero Eléctrico",
					polos: [conf.pole],
					circuitoId: circuitData.id,
					circuitoNombre: finalEquipo,
					equipoExistente: conf.occupiedBy?.descripcion,
					equipoNuevo: finalEquipo,
					descripcion: `Polo ${conf.pole} ocupado por "${conf.occupiedBy?.descripcion || "Circuito existente"}". Asignado a "${finalEquipo}".`,
					tipo: "SOLAPAMIENTO_POLOS"
				});
			});
			showToast(`Conflicto en Polo(s) [${validation.requiredPoles.join(", ")}]. Incidencia registrada en la cola.`, "warning", {
				label: "Ver Conflicto",
				onClick: () => setPanelConflictosOpen(true)
			});
		}
		onSave(circuitData.id, {
			equipo: finalEquipo,
			tipoDestino: finalTipoDestino,
			vinculadoId: finalDestinoId,
			elementoDestinoId: finalDestinoId,
			tipoElementoDestino: isCreatingNewProvisional ? provisionalTipo : selectedTipoElementoDestino || finalTipoDestino,
			tipoElementoProvisional: isCreatingNewProvisional ? provisionalTipo : undefined,
			nombreProvisional: isCreatingNewProvisional ? provisionalCustomName || finalEquipo : undefined,
			breaker: {
				amp: normalizeText(breakerAmp || extra.breakerAmp),
				marca: normalizeText(breakerMarca),
				tipo: normalizeText(breakerTipo)
			},
			conductor: normalizeText(conductor || extra.conductor),
			poles: isTablero ? validation.requiredPoles : [
				1,
				2,
				3
			],
			numPolos: isTablero ? numPolos : 3,
			posicionPolo: isTablero ? posicionPolo : 1,
			codigoPolo: circuitData?.codigoPolo || circuitData?.polo_label || extra.codigoPolo || "",
			polo_label: circuitData?.polo_label || circuitData?.codigoPolo || extra.polo_label || "",
			estado,
			ficha: {
				descripcion: descArtefacto,
				potenciaWatts: potenciaWatts ? parseFloat(potenciaWatts) : null
			},
			fotografia: fotoUrl,
			detallesTecnicos: {
				nivelMT,
				fusibleMT,
				pararrayos,
				canalizacion,
				esquemaArranque,
				hpKw,
				corrienteNominal,
				proteccion,
				redComms,
				tipoConmutador,
				relacionTc,
				relacionTp,
				resistenciaOhms,
				senalArranque,
				potenciaKvaKw,
				tensionSecundaria,
				interruptorAguasAbajo,
				...extra
			}
		});
		onClose();
	};
	const handleSaveArtefacto = () => {
		if (!nombreArtefacto.trim()) return customAlert("Por favor, ingresa el nombre del artefacto.");
		handleSaveEquipment(nombreArtefacto, "ARTEFACTO");
	};
	const handleSaveVinculo = (linkElement) => {
		if (isMultiSelect) {
			if (selectedLinks.length === 0) return customAlert("Por favor, selecciona al menos un elemento para vincular.");
			const names = selectedLinks.map((el) => `${el.nombre} (ID: ${el.id})`).join(", ");
			const ids = selectedLinks.map((el) => el.id).join(", ");
			handleSaveEquipment(names, "SUB_TABLERO", {
				vinculadoId: ids,
				elementoDestinoId: ids,
				tipoElementoDestino: "SUB_TABLERO",
				vinculados: selectedLinks
			});
			return;
		}
		const el = linkElement || selectedLink;
		if (!el) return customAlert("Por favor, selecciona un elemento para vincular.");
		handleSaveEquipment(`${el.nombre} (ID: ${el.id})`, el.tipo || "SUB_TABLERO", {
			vinculadoId: el.id,
			elementoDestinoId: el.id,
			tipoElementoDestino: el.tipo || "SUB_TABLERO"
		});
	};
	const handleSavePorCrear = () => {
		const calculatedPoles = validation?.requiredPoles || getPolesArray(posicionPolo, numPolos);
		const pendingName = `Equipo / Sub-Elemento (${isTablero ? `Polo ${calculatedPoles.join(", ")}` : "Provisional"})`;
		handleSaveEquipment(pendingName, "SUB_TABLERO_PENDIENTE", {
			nombreProvisional: pendingName,
			tipoElementoProvisional: provisionalTipo || "TABLERO",
			poles: isTablero ? validation?.requiredPoles || calculatedPoles : [
				1,
				2,
				3
			]
		});
	};
	const handleSaveRotuloFoto = () => {
		handleSaveEquipment(rotulo || "RESERVA", "RESERVA");
	};
	const simularCapturaFoto = () => {
		const mockPhotos = ["https://images.unsplash.com/photo-1621905252507-b354bc25edac?auto=format&fit=crop&w=400&q=80", "https://images.unsplash.com/photo-1558346490-a72e53ae2d4f?auto=format&fit=crop&w=400&q=80"];
		const randomPhoto = mockPhotos[Math.floor(Math.random() * mockPhotos.length)];
		setFotoUrl(randomPhoto);
	};
	const renderUniversalElementSelector = () => /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-slate-950/80 p-3.5 border border-slate-800 rounded-xl space-y-2.5 text-xs font-sans",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ _jsxDEV("label", {
					className: "text-slate-300 font-bold uppercase tracking-wider text-[10px] flex items-center gap-1.5",
					children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 560,
						columnNumber: 11
					}, this), "Destino / Vinculación de la Reserva o Salida:"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 559,
					columnNumber: 9
				}, this), selectedElementoDestinoId ? /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[9px] font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded",
					children: ["ID: ", selectedElementoDestinoId]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 564,
					columnNumber: 11
				}, this) : isCreatingNewProvisional ? /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[9px] font-mono font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded",
					children: [
						"NUEVO (",
						provisionalTipo,
						")"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 568,
					columnNumber: 11
				}, this) : null]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 558,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("select", {
				value: selectorValue,
				onChange: handleUniversalElementChange,
				className: "w-full bg-slate-900 border border-slate-750 hover:border-slate-600 rounded-lg px-3 py-2 text-slate-100 text-xs font-medium focus:outline-none focus:border-amber-500 cursor-pointer transition-colors",
				children: [
					/* @__PURE__ */ _jsxDEV("option", {
						value: "",
						children: "-- Carga directa / Sin vinculación específica --"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 579,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("optgroup", {
						label: "➕ NUEVO ELEMENTO POR CREAR (RESERVA FUTURA)",
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "NEW_TABLERO",
								children: "➕ Crear Nuevo Sub-Tablero / Panel"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 583,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "NEW_TRANSFER",
								children: "➕ Crear Nueva Transferencia Automática (ATS/MTS)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 584,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "NEW_CCM",
								children: "➕ Crear Nuevo Centro de Control de Motores (CCM)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 585,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "NEW_GENERADOR",
								children: "➕ Crear Nuevo Generador / Planta Eléctrica"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 586,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "NEW_TRANSFORMADOR",
								children: "➕ Crear Nuevo Transformador de Potencia"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 587,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "NEW_SUBESTACION",
								children: "➕ Crear Nueva Subestación Eléctrica"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 588,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "NEW_PUNTO_MEDICION",
								children: "➕ Crear Nuevo Punto de Medición / Analizador"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 589,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "NEW_CARGA",
								children: "➕ Crear Carga Directa (Bomba, Motor, etc.)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 590,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 582,
						columnNumber: 9
					}, this),
					groupedElements.TABLERO.length > 0 && /* @__PURE__ */ _jsxDEV("optgroup", {
						label: "🏢 Tableros y Subtableros Existentes",
						children: groupedElements.TABLERO.map((el) => /* @__PURE__ */ _jsxDEV("option", {
							value: el.id,
							children: [
								el.nombre,
								" (",
								el.id,
								")"
							]
						}, el.id, true, {
							fileName: _jsxFileName,
							lineNumber: 597,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 595,
						columnNumber: 11
					}, this),
					groupedElements.TRANSFER.length > 0 && /* @__PURE__ */ _jsxDEV("optgroup", {
						label: "🔄 Transferencias (ATS/MTS) Existentes",
						children: groupedElements.TRANSFER.map((el) => /* @__PURE__ */ _jsxDEV("option", {
							value: el.id,
							children: [
								el.nombre,
								" (",
								el.id,
								")"
							]
						}, el.id, true, {
							fileName: _jsxFileName,
							lineNumber: 606,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 604,
						columnNumber: 11
					}, this),
					groupedElements.CCM.length > 0 && /* @__PURE__ */ _jsxDEV("optgroup", {
						label: "⚙️ Centros de Control de Motores (CCM) Existentes",
						children: groupedElements.CCM.map((el) => /* @__PURE__ */ _jsxDEV("option", {
							value: el.id,
							children: [
								el.nombre,
								" (",
								el.id,
								")"
							]
						}, el.id, true, {
							fileName: _jsxFileName,
							lineNumber: 615,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 613,
						columnNumber: 11
					}, this),
					groupedElements.GENERADOR.length > 0 && /* @__PURE__ */ _jsxDEV("optgroup", {
						label: "⚡ Generadores y Plantas Existentes",
						children: groupedElements.GENERADOR.map((el) => /* @__PURE__ */ _jsxDEV("option", {
							value: el.id,
							children: [
								el.nombre,
								" (",
								el.id,
								")"
							]
						}, el.id, true, {
							fileName: _jsxFileName,
							lineNumber: 624,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 622,
						columnNumber: 11
					}, this),
					groupedElements.SUBESTACION.length > 0 && /* @__PURE__ */ _jsxDEV("optgroup", {
						label: "🏛️ Subestaciones Eléctricas Existentes",
						children: groupedElements.SUBESTACION.map((el) => /* @__PURE__ */ _jsxDEV("option", {
							value: el.id,
							children: [
								el.nombre,
								" (",
								el.id,
								")"
							]
						}, el.id, true, {
							fileName: _jsxFileName,
							lineNumber: 633,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 631,
						columnNumber: 11
					}, this),
					groupedElements.TRANSFORMADOR.length > 0 && /* @__PURE__ */ _jsxDEV("optgroup", {
						label: "🔌 Transformadores Existentes",
						children: groupedElements.TRANSFORMADOR.map((el) => /* @__PURE__ */ _jsxDEV("option", {
							value: el.id,
							children: [
								el.nombre,
								" (",
								el.id,
								")"
							]
						}, el.id, true, {
							fileName: _jsxFileName,
							lineNumber: 642,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 640,
						columnNumber: 11
					}, this),
					groupedElements.PUNTO_MEDICION.length > 0 && /* @__PURE__ */ _jsxDEV("optgroup", {
						label: "📊 Equipos / Puntos de Medida Existentes",
						children: groupedElements.PUNTO_MEDICION.map((el) => /* @__PURE__ */ _jsxDEV("option", {
							value: el.id,
							children: [
								el.nombre,
								" (",
								el.id,
								")"
							]
						}, el.id, true, {
							fileName: _jsxFileName,
							lineNumber: 651,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 649,
						columnNumber: 11
					}, this),
					groupedElements.OTROS.length > 0 && /* @__PURE__ */ _jsxDEV("optgroup", {
						label: "📦 Otros Elementos Registrados",
						children: groupedElements.OTROS.map((el) => /* @__PURE__ */ _jsxDEV("option", {
							value: el.id,
							children: [
								el.nombre,
								" (",
								el.id,
								")"
							]
						}, el.id, true, {
							fileName: _jsxFileName,
							lineNumber: 660,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 658,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 574,
				columnNumber: 7
			}, this),
			isCreatingNewProvisional && /* @__PURE__ */ _jsxDEV("div", {
				className: "pt-2 border-t border-slate-800/80 space-y-1.5 animate-in fade-in duration-200",
				children: [
					/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-[10px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: "📝" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 672,
								columnNumber: 13
							}, this),
							" Nombre / Rótulo provisional para el nuevo elemento (",
							provisionalTipo,
							"):"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 671,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: provisionalCustomName,
						onChange: (e) => {
							const v = e.target.value;
							setProvisionalCustomName(v);
							setNombreArtefacto(v);
							setRotulo(v);
						},
						placeholder: `Ej. ${provisionalTipo}-01 (Planta Principal)`,
						className: "w-full bg-slate-900 border border-emerald-500/40 rounded-lg px-3 py-1.5 text-slate-100 text-xs focus:outline-none focus:border-emerald-400 font-medium"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 674,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-[10px] text-slate-400",
						children: [
							"Se registrará un elemento provisional de tipo ",
							/* @__PURE__ */ _jsxDEV("strong", {
								className: "text-emerald-300",
								children: provisionalTipo
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 687,
								columnNumber: 59
							}, this),
							" en el proyecto y quedará vinculado a este interruptor."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 686,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 670,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 557,
		columnNumber: 5
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "absolute inset-0 bg-slate-950/70 backdrop-blur-md transition-opacity",
			onClick: onClose
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 696,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-lg bg-slate-900 rounded-2xl shadow-2xl border border-slate-800 overflow-hidden flex flex-col max-h-[90vh] text-slate-100 font-sans",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between px-6 py-4 bg-gradient-to-r from-amber-500/10 to-amber-600/10 border-b border-slate-800",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [step !== "PREGUNTA_ES_ARTEFACTO" && step !== "PREGUNTA_ORIGEN_MT" && step !== "PREGUNTA_DESTINO_BT" && step !== "PREGUNTA_DESTINO_GEN" && step !== "PREGUNTA_FUENTE_ATS1" && step !== "PREGUNTA_CARGA_CCM" && /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => {
							if (isTablero) {
								if (step === "FORMULARIO_ARTEFACTO" || step === "PREGUNTA_ALIMENTA_OTRO") setStep("PREGUNTA_ES_ARTEFACTO");
								else if (step === "PREGUNTA_CREADO" || step === "ROTULAR_Y_FOTO") setStep("PREGUNTA_ALIMENTA_OTRO");
								else if (step === "VINCULAR_EXISTENTE" || step === "ALIMENTAR_POR_CREAR") setStep("PREGUNTA_CREADO");
							} else {
								if (step === "FORMULARIO_POTENCIA_TRANSFO_MT") setStep("PREGUNTA_ORIGEN_MT");
								else if (step === "FORMULARIO_POTENCIA_TRANSFO_BT") setStep("PREGUNTA_DESTINO_BT");
								else if (step === "FORMULARIO_POTENCIA_GEN") setStep("PREGUNTA_DESTINO_GEN");
								else if (step === "FORMULARIO_POTENCIA_ATS" || step === "FORMULARIO_POTENCIA_ATS_SALIDA") setStep("PREGUNTA_FUENTE_ATS1");
								else if (step === "FORMULARIO_GAVETA_CCM") setStep("PREGUNTA_CARGA_CCM");
								else if (step === "FORMULARIO_MEDICION") setStep("PREGUNTA_ORIGEN_MEDICION");
								else if (step === "FORMULARIO_TIERRA") setStep("PREGUNTA_CONEXION_TIERRA");
								else setStep("VINCULAR_EXISTENTE");
							}
						},
						className: "p-2 hover:bg-slate-800 rounded-full transition-colors cursor-pointer",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5 text-slate-300" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 726,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 707,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-lg font-bold text-slate-100",
						children: getHeaderTitle()
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 730,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: ["Identificador: ", /* @__PURE__ */ _jsxDEV("span", {
							className: "font-mono font-bold text-amber-400",
							children: circuitData.nombre || circuitData.id || "Salida"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 734,
							columnNumber: 32
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 733,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 729,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 705,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [isTablero && (circuitData.tipoDestino === "ARTEFACTO" || circuitData.tipoDestino === "SUB_TABLERO" || circuitData.equipo !== "RESERVA") && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleRevertirAReserva,
						className: "px-2.5 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 hover:text-amber-300 border border-amber-500/30 hover:border-amber-500/50 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer",
						title: "Desvincular carga/equipo y restablecer este circuito a estado Reserva",
						children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 746,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline",
							children: "Revertir a Reserva"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 747,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 740,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "p-2 hover:bg-slate-800 rounded-full transition-colors cursor-pointer",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5 text-slate-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 754,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 750,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 738,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 704,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 overflow-y-auto p-6 space-y-6",
				children: [
					isTablero && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950/70 p-4 border border-slate-800 rounded-2xl space-y-3.5 font-sans text-xs shadow-inner",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between border-b border-slate-800/80 pb-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 767,
										columnNumber: 19
									}, this), " Disposición de Polos y Fase"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 766,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800",
									children: posicionPolo % 2 !== 0 ? "Columna Izq (Impares)" : "Columna Der (Pares)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 769,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 765,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-3 gap-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold uppercase tracking-wider text-[9px] mb-1",
										children: "Cantidad de Polos"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 776,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: numPolos,
										onChange: (e) => setNumPolos(parseInt(e.target.value, 10)),
										className: "w-full bg-slate-900 border border-slate-750 rounded-xl px-2.5 py-2 text-slate-100 font-semibold focus:outline-none focus:border-amber-500 cursor-pointer",
										children: [
											1,
											2,
											3
										].map((p) => /* @__PURE__ */ _jsxDEV("option", {
											value: p,
											children: p === 1 ? "1P (Monofásico)" : p === 2 ? "2P (Bifásico)" : "3P (Trifásico)"
										}, p, false, {
											fileName: _jsxFileName,
											lineNumber: 785,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 779,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 775,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold uppercase tracking-wider text-[9px] mb-1",
										children: "Polo Inicial"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 793,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										min: "1",
										max: maxPolos,
										value: posicionPolo,
										onChange: (e) => {
											const val = parseInt(e.target.value, 10);
											if (!isNaN(val) && val > 0) setPosicionPolo(val);
											else if (e.target.value === "") setPosicionPolo("");
										},
										className: "w-full bg-slate-900 border border-slate-750 rounded-xl px-2.5 py-2 text-slate-100 font-semibold focus:outline-none focus:border-amber-500 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 796,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 792,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold uppercase tracking-wider text-[9px] mb-1",
										children: "Estado del Polo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 811,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: estado,
										onChange: (e) => {
											const val = e.target.value;
											setEstado(val);
											if (val === "RESERVA" || val === "DISPONIBLE") {
												setNombreArtefacto(val);
												setRotulo(val);
												setBreakerAmp("");
												setDescArtefacto("");
												setPotenciaWatts("");
											}
										},
										className: "w-full bg-slate-900 border border-slate-750 rounded-xl px-2.5 py-2 text-slate-100 font-semibold focus:outline-none focus:border-amber-500 cursor-pointer",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "ACTIVO",
												children: "🟢 ACTIVO (Con Carga)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 829,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "RESERVA",
												children: "🟡 RESERVA (Bloqueado)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 830,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "DISPONIBLE",
												children: "⚪ DISPONIBLE (Libre)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 831,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 814,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 810,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 774,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between flex-wrap gap-2 text-[11px] bg-slate-900/90 px-3 py-2 rounded-xl border border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400 font-medium",
											children: "Polos Requeridos:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 839,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono font-bold text-amber-400 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded",
											children: [
												"[",
												validation.requiredPoles.join(", "),
												"]"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 840,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-500 text-[10px]",
											children: [
												"(",
												numPolos === 1 ? "1 Polo" : `${numPolos} Polos`,
												")"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 843,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 838,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] text-slate-400 font-mono",
									children: ["Capacidad Total: ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-200 font-bold",
										children: [maxPolos, " Polos"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 848,
										columnNumber: 36
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 847,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 837,
								columnNumber: 15
							}, this),
							!validation.isValid ? /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-rose-500/15 border border-rose-500/40 rounded-xl space-y-1 text-rose-200 animate-in fade-in duration-150",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 font-bold text-xs text-rose-300",
									children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 text-rose-400 shrink-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 856,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Conflicto de Ocupación / Capacidad de Polos" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 857,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 855,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-0.5 pl-6",
									children: validation.conflictMessages.map((msg, idx) => /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] leading-relaxed text-rose-200",
										children: ["• ", msg]
									}, idx, true, {
										fileName: _jsxFileName,
										lineNumber: 861,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 859,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 854,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/25 rounded-xl text-[11px] text-emerald-400 font-semibold animate-in fade-in",
								children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-400 shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 869,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
									"Polos [",
									validation.requiredPoles.join(", "),
									"] libres y disponibles sin colisión."
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 870,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 868,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-2 pt-1",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setEstado("ACTIVO");
									},
									className: `flex-1 py-1.5 rounded-lg font-bold text-[9px] transition-all cursor-pointer uppercase tracking-wider border ${estado === "ACTIVO" ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40" : "bg-slate-900 hover:bg-slate-850 text-slate-400 border-slate-800"}`,
									children: "Activo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 876,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setEstado("RESERVA");
										setNombreArtefacto("RESERVA");
										setRotulo("RESERVA");
										setBreakerAmp("");
										setDescArtefacto("");
										setPotenciaWatts("");
									},
									className: `flex-1 py-1.5 rounded-lg font-bold text-[9px] transition-all cursor-pointer uppercase tracking-wider border ${estado === "RESERVA" ? "bg-amber-500/20 text-amber-300 border-amber-500/40" : "bg-slate-900 hover:bg-slate-850 text-slate-400 border-slate-800"}`,
									children: "Marcar como Reserva"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 889,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 875,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 764,
						columnNumber: 13
					}, this),
					isTablero && step === "PREGUNTA_ES_ARTEFACTO" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-center",
								children: [
									/* @__PURE__ */ _jsxDEV(Settings, { className: "w-12 h-12 text-amber-500 mx-auto mb-3" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 917,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-base font-semibold text-slate-100",
										children: "¿El circuito alimenta a un equipo o artefacto final?"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 918,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 mt-1",
										children: "Selecciona la categoría del elemento alimentado por esta salida eléctrica."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 921,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 916,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-4",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setStep("FORMULARIO_ARTEFACTO"),
									className: "flex flex-col items-center justify-center p-6 h-36 rounded-xl border-2 border-slate-800 hover:border-amber-500 hover:bg-amber-500/5 transition-all text-center group cursor-pointer active:scale-95",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-3xl mb-2",
											children: "🔌"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 930,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-200 group-hover:text-amber-400",
											children: "Sí, es un Artefacto"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 931,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-400 mt-1",
											children: "Luminarias, motores, tomacorrientes directos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 932,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 926,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setStep("PREGUNTA_ALIMENTA_OTRO"),
									className: "flex flex-col items-center justify-center p-6 h-36 rounded-xl border-2 border-slate-800 hover:border-amber-500 hover:bg-amber-500/5 transition-all text-center group cursor-pointer active:scale-95",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-3xl mb-2",
											children: "⚡"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 938,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-200 group-hover:text-amber-400",
											children: "No es un Artefacto"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 939,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-400 mt-1",
											children: "Sub-tableros, reservas, derivaciones"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 940,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 934,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 925,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 border-t border-slate-800/80",
								children: /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: handleRevertirAReserva,
									className: "w-full py-3 px-4 rounded-xl border border-dashed border-amber-500/40 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 951,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Revertir Circuito a \"Reserva\" (Liberar Carga y Elemento)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 952,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 946,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 945,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 915,
						columnNumber: 13
					}, this),
					isTablero && step === "FORMULARIO_ARTEFACTO" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg flex gap-3 items-center mb-2",
								children: [/* @__PURE__ */ _jsxDEV(ClipboardList, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 961,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-amber-300 font-bold",
									children: "Llenar Ficha del Artefacto / Circuito"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 962,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 960,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-bold text-slate-300 mb-1",
										children: "Nombre del Equipo / Artefacto"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 967,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: nombreArtefacto,
										onChange: (e) => setNombreArtefacto(e.target.value),
										placeholder: "Ej. Extractor de Aire Sótano, Motor Bomba 1",
										className: "w-full px-3 py-2 text-sm border border-slate-700 rounded-lg bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 970,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 966,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-4",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-xs font-bold text-slate-300 mb-1",
												children: "Breaker (Amperaje)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 981,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												list: "list-amp-options",
												value: breakerAmp,
												onChange: (e) => setBreakerAmp(e.target.value),
												placeholder: "Ej. 20, 30, 100, 225...",
												className: "w-full px-3 py-2 text-sm border border-slate-700 rounded-lg bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 984,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("datalist", {
												id: "list-amp-options",
												children: AMP_OPTIONS.map((opt) => /* @__PURE__ */ _jsxDEV("option", { value: opt }, opt, false, {
													fileName: _jsxFileName,
													lineNumber: 993,
													columnNumber: 47
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 992,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 980,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-xs font-bold text-slate-300 mb-1",
												children: "Conductor (Calibre)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 997,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												list: "list-cond-options",
												value: conductor,
												onChange: (e) => setConductor(e.target.value),
												placeholder: "Ej. 12, 10, 8, 4/0...",
												className: "w-full px-3 py-2 text-sm border border-slate-700 rounded-lg bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1e3,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("datalist", {
												id: "list-cond-options",
												children: COND_OPTIONS.map((opt) => /* @__PURE__ */ _jsxDEV("option", { value: opt }, opt, false, {
													fileName: _jsxFileName,
													lineNumber: 1009,
													columnNumber: 48
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1008,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 996,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 979,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-4",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-xs font-bold text-slate-300 mb-1",
												children: "Breaker (Marca)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1016,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												list: "list-marca-options",
												value: breakerMarca,
												onChange: (e) => setBreakerMarca(e.target.value),
												placeholder: "Ej. GE, EATON, ABB, CHINT...",
												className: "w-full px-3 py-2 text-sm border border-slate-700 rounded-lg bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1019,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("datalist", {
												id: "list-marca-options",
												children: MARCA_OPTIONS.map((opt) => /* @__PURE__ */ _jsxDEV("option", { value: opt }, opt, false, {
													fileName: _jsxFileName,
													lineNumber: 1028,
													columnNumber: 49
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1027,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1015,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-xs font-bold text-slate-300 mb-1",
												children: "Breaker (Tipo)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1032,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												list: "list-tipo-options",
												value: breakerTipo,
												onChange: (e) => setBreakerTipo(e.target.value),
												placeholder: "Ej. TQ, TQD, M35...",
												className: "w-full px-3 py-2 text-sm border border-slate-700 rounded-lg bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1035,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("datalist", {
												id: "list-tipo-options",
												children: TIPO_OPTIONS.map((opt) => /* @__PURE__ */ _jsxDEV("option", { value: opt }, opt, false, {
													fileName: _jsxFileName,
													lineNumber: 1044,
													columnNumber: 48
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1043,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1031,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1014,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-bold text-slate-300 mb-1",
										children: "Potencia Estimada (Watts)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1050,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										value: potenciaWatts,
										onChange: (e) => setPotenciaWatts(e.target.value),
										placeholder: "Ej. 1500",
										className: "w-full px-3 py-2 text-sm border border-slate-700 rounded-lg bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1053,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1049,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-bold text-slate-300 mb-1",
										children: "Ficha Técnica / Notas adicionales"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1063,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("textarea", {
										value: descArtefacto,
										onChange: (e) => setDescArtefacto(e.target.value),
										placeholder: "Detalles sobre marca, modelo del equipo, ubicación exacta...",
										rows: 2,
										className: "w-full px-3 py-2 text-sm border border-slate-700 rounded-lg bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 focus:outline-none resize-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1066,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1062,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 965,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-4 border-t border-slate-800 flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: handleRevertirAReserva,
									className: "px-4 py-2.5 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-amber-400 font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1082,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Revertir a Reserva" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1083,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1077,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleSaveArtefacto,
									disabled: isTablero && !validation.isValid,
									className: "flex-1 px-6 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-black text-sm shadow-md transition-colors cursor-pointer",
									children: isTablero && !validation.isValid ? "Resolver Conflicto de Polos" : "Guardar Ficha"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1085,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1076,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 959,
						columnNumber: 13
					}, this),
					isTablero && step === "PREGUNTA_ALIMENTA_OTRO" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(Cpu, { className: "w-12 h-12 text-amber-500 mx-auto mb-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1099,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-base font-semibold text-slate-100",
									children: "¿El circuito alimenta a otro elemento del sistema?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1100,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 mt-1",
									children: "Por ejemplo: alimenta a un Sub-Tablero de distribución o tablero de control secundario."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1103,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1098,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStep("PREGUNTA_CREADO"),
								className: "flex flex-col items-center justify-center p-6 h-32 rounded-xl border-2 border-slate-800 hover:border-amber-500 hover:bg-amber-500/5 transition-all cursor-pointer active:scale-95",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-2xl mb-1",
										children: "🏢"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1112,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-sm text-slate-200",
										children: "Sí, alimenta a otro elemento"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1113,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 mt-1",
										children: "Como un Sub-Tablero"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1114,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1108,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStep("ROTULAR_Y_FOTO"),
								className: "flex flex-col items-center justify-center p-6 h-32 rounded-xl border-2 border-slate-800 hover:border-amber-500 hover:bg-amber-500/5 transition-all cursor-pointer active:scale-95",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-2xl mb-1",
										children: "🏷️"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1120,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-sm text-slate-200",
										children: "No, no alimenta otro elemento"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1121,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 mt-1",
										children: "Es reserva o vacío"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1122,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1116,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1107,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1097,
						columnNumber: 13
					}, this),
					isTablero && step === "PREGUNTA_CREADO" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-12 h-12 text-amber-500 mx-auto mb-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1131,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-base font-semibold text-slate-100",
									children: "¿El elemento de destino ya está creado en el sistema?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1132,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 mt-1",
									children: "Confirma si el Sub-Tablero ya está registrado en tu listado de inspección."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1135,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1130,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStep("VINCULAR_EXISTENTE"),
								className: "flex flex-col items-center justify-center p-6 h-32 rounded-xl border-2 border-slate-800 hover:border-amber-500 hover:bg-amber-500/5 transition-all cursor-pointer active:scale-95",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-2xl mb-1",
										children: "🔗"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1144,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-sm text-slate-200",
										children: "Sí, ya está creado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1145,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 mt-1",
										children: "Buscar y vincular"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1146,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1140,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStep("ALIMENTAR_POR_CREAR"),
								className: "flex flex-col items-center justify-center p-6 h-32 rounded-xl border-2 border-slate-800 hover:border-amber-500 hover:bg-amber-500/5 transition-all cursor-pointer active:scale-95",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-2xl mb-1",
										children: "📝"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1152,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-sm text-slate-200",
										children: "No está creado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1153,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 mt-1",
										children: "Añadir a pendientes"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1154,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1148,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1139,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1129,
						columnNumber: 13
					}, this),
					!isTablero && tipoOrigen === "TRANSFORMADOR" && (step === "PREGUNTA_ORIGEN_MT" || modo === "ENTRADA" || modo === "PRIMARIA") && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(Zap, { className: "w-12 h-12 text-amber-500 mx-auto mb-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1166,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-base font-bold text-slate-100",
									children: "¿Desde dónde se alimenta el Lado Primario (MT)?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1167,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400",
									children: "Selecciona la fuente de Media Tensión de este Transformador."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1170,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1165,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("RED PÚBLICA / POSTE CORPOELEC");
										setStep("FORMULARIO_POTENCIA_TRANSFO_MT");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "⚡"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1181,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Red Pública / CORPOELEC"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1182,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Acometida Aérea / Poste MT"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1183,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1173,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("SUBESTACIÓN PRINCIPAL MT");
										setStep("FORMULARIO_POTENCIA_TRANSFO_MT");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🏢"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1193,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Subestación Principal MT"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1194,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Barra / Celda de MT"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1195,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1185,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("CELDA DE SECCIONAMIENTO MT");
										setStep("FORMULARIO_POTENCIA_TRANSFO_MT");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🔌"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1205,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Celda Seccionamiento MT"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1206,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Interruptor SF6 / Vacío"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1207,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1197,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setStep("VINCULAR_EXISTENTE"),
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🔗"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1214,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Vincular Elemento Creado"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1215,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Buscar en la lista del proyecto"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1216,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1209,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1172,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1164,
						columnNumber: 13
					}, this),
					!isTablero && step === "FORMULARIO_POTENCIA_TRANSFO_MT" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1225,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-amber-300",
									children: "Parámetros de Alimentación Primaria MT"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1226,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1224,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold mb-1",
										children: "Nivel Tensión MT"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1230,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: nivelMT,
										onChange: (e) => setNivelMT(e.target.value),
										className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "13.8 kV",
												children: "13.8 kV"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1236,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "24 kV",
												children: "24 kV"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1237,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "34.5 kV",
												children: "34.5 kV"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1238,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "4.16 kV",
												children: "4.16 kV"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1239,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1231,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1229,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold mb-1",
										children: "Calibre Conductor MT"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1243,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: conductor,
										onChange: (e) => setConductor(e.target.value),
										placeholder: "Ej. 1/0 XLPE 15kV",
										className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1244,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1242,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold mb-1",
										children: "Fusible MT (Capacidad/Curva)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1253,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: fusibleMT,
										onChange: (e) => setFusibleMT(e.target.value),
										placeholder: "Ej. 15A Curva K",
										className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1254,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1252,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold mb-1",
										children: "Pararrayos MT Instalado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1263,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: pararrayos,
										onChange: (e) => setPararrayos(e.target.value),
										className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "Sí",
											children: "Sí"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1269,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("option", {
											value: "No",
											children: "No"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1270,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1264,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1262,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1228,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => handleSaveEquipment(rotulo || "ALIMENTACIÓN MT CORPOELEC", "SUBESTACION"),
								className: "w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-sm transition-colors cursor-pointer mt-4",
								children: "Guardar Configuración MT"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1274,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1223,
						columnNumber: 13
					}, this),
					!isTablero && tipoOrigen === "TRANSFORMADOR" && (step === "PREGUNTA_DESTINO_BT" || modo === "SECUNDARIA") && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(Activity, { className: "w-12 h-12 text-amber-500 mx-auto mb-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1290,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-base font-bold text-slate-100",
									children: "¿Hacia dónde entrega la potencia el Lado Secundario (BT)?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1291,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400",
									children: "Selecciona el destino de Baja Tensión alimentado por el Transformador."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1294,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1289,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("TABLERO GENERAL DE BT (TG)");
										setStep("FORMULARIO_POTENCIA_TRANSFO_BT");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🏢"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1305,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Tablero General (TG)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1306,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Distribución BT"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1307,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1297,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("TRANSFERENCIA AUTOMÁTICA (ATS)");
										setStep("FORMULARIO_POTENCIA_TRANSFO_BT");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🔄"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1317,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Transferencia (ATS)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1318,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Entrada Fuente Normal"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1319,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1309,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("CENTRO CONTROL DE MOTORES (CCM)");
										setStep("FORMULARIO_POTENCIA_TRANSFO_BT");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "⚙️"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1329,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "CCM Industrial"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1330,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Alimentación de Motores"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1331,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1321,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setStep("VINCULAR_EXISTENTE"),
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🔗"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1338,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Vincular Elemento Creado"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1339,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Buscar en el proyecto"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1340,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1333,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1296,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1288,
						columnNumber: 13
					}, this),
					!isTablero && step === "FORMULARIO_POTENCIA_TRANSFO_BT" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1349,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-amber-300",
									children: "Parámetros de Distribución BT (Secundario)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1350,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1348,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold mb-1",
										children: "Tensión Secundaria BT"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1354,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: tensionSecundaria,
										onChange: (e) => setTensionSecundaria(e.target.value),
										className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "208/120V",
												children: "208/120 V"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1360,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "480/277V",
												children: "480/277 V"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1361,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "380/220V",
												children: "380/220 V"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1362,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1355,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1353,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold mb-1",
										children: "Configuración Conductores"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1366,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: conductor,
										onChange: (e) => setConductor(e.target.value),
										placeholder: "Ej. 3(4x500 MCM)",
										className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1367,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1365,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold mb-1",
										children: "Canalización de Salida"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1376,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: canalizacion,
										onChange: (e) => setCanalizacion(e.target.value),
										className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Bandeja Portacables",
												children: "Bandeja Portacables"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1382,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Tubería Conduit",
												children: "Tubería Conduit"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1383,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Trinchera Subterránea",
												children: "Trinchera Subterránea"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1384,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1377,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1375,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-400 font-bold mb-1",
										children: "Capacidad Breaker Aguas Abajo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1388,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: interruptorAguasAbajo,
										onChange: (e) => setInterruptorAguasAbajo(e.target.value),
										placeholder: "Ej. 1600 A",
										className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1389,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1387,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1352,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => handleSaveEquipment(rotulo || "SALIDA SECUNDARIA BT", "TABLERO"),
								className: "w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-sm transition-colors cursor-pointer mt-4",
								children: "Guardar Configuración BT"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1398,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1347,
						columnNumber: 13
					}, this),
					!isTablero && tipoOrigen === "GENERADOR" && (step === "PREGUNTA_DESTINO_GEN" || step === "FORMULARIO_POTENCIA_GEN") && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [step === "PREGUNTA_DESTINO_GEN" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(Radio, { className: "w-12 h-12 text-amber-500 mx-auto mb-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1416,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-base font-bold text-slate-100",
									children: "¿A qué equipo alimenta el respaldo del Generador?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1417,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400",
									children: "Define el destino de la potencia de emergencia."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1420,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1415,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("TRANSFERENCIA AUTOMÁTICA (ATS)");
										setStep("FORMULARIO_POTENCIA_GEN");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🔄"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1431,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Transferencia ATS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1432,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Conmutación Automática"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1433,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1423,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("TRANSFERENCIA MANUAL (MTS)");
										setStep("FORMULARIO_POTENCIA_GEN");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🔀"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1443,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Transferencia Manual (MTS)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1444,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Conmutación Manual"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1445,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1435,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("TABLERO DE EMERGENCIA");
										setStep("FORMULARIO_POTENCIA_GEN");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "⚡"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1455,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Tablero Emergencia"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1456,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Alimentación Directa"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1457,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1447,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setStep("VINCULAR_EXISTENTE"),
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🔗"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1464,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Vincular Elemento Creado"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1465,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Buscar en el proyecto"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1466,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1459,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1422,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1414,
							columnNumber: 17
						}, this), step === "FORMULARIO_POTENCIA_GEN" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(Radio, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1475,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-amber-300",
										children: "Parámetros del Generador / Respaldo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1476,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1474,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-400 font-bold mb-1",
											children: "Capacidad Breaker Generador"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1480,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: breakerAmp,
											onChange: (e) => setBreakerAmp(e.target.value),
											placeholder: "Ej. 800 A",
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1481,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1479,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-400 font-bold mb-1",
											children: "Conductor de Fuerza Respaldo"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1490,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: conductor,
											onChange: (e) => setConductor(e.target.value),
											placeholder: "Ej. 2(3x500 MCM)",
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1491,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1489,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-400 font-bold mb-1",
											children: "Señal Arranque Cableada"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1500,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: senalArranque,
											onChange: (e) => setSenalArranque(e.target.value),
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Sí - Cableado 24VDC",
													children: "Sí - Cableado 24VDC"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1506,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Sí - Modbus/Comms",
													children: "Sí - Modbus/Comms"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1507,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "No - Arranque Manual",
													children: "No - Arranque Manual"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1508,
													columnNumber: 25
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1501,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1499,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-400 font-bold mb-1",
											children: "Potencia Respaldo (kVA/kW)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1512,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: potenciaKvaKw,
											onChange: (e) => setPotenciaKvaKw(e.target.value),
											placeholder: "Ej. 580 kVA / 460 kW",
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1513,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1511,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1478,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleSaveEquipment(rotulo || "SALIDA PLANTA GENERACIÓN", "GENERADOR"),
									className: "w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-sm transition-colors cursor-pointer mt-4",
									children: "Guardar Configuración Generador"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1522,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1473,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1412,
						columnNumber: 13
					}, this),
					!isTablero && tipoOrigen === "TRANSFER" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [
							(step === "PREGUNTA_FUENTE_ATS1" || step === "PREGUNTA_FUENTE_ATS2" || step === "PREGUNTA_DESTINO_ATS") && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-center",
								children: [
									/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-12 h-12 text-amber-500 mx-auto mb-2" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1542,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-base font-bold text-slate-100",
										children: "Configuración de Conexión de Transferencia (ATS)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1543,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400",
										children: "Selecciona la fuente o carga a configurar en el conmutador."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1546,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1541,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => {
											setRotulo("FUENTE 1 - RED PRINCIPAL");
											setStep("FORMULARIO_POTENCIA_ATS");
										},
										className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xl block mb-1",
												children: "⚡"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1557,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-xs text-slate-200 block",
												children: "Fuente 1 (Red Normal)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1558,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[9px] text-slate-500",
												children: "Transformador / Subestación"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1559,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1549,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => {
											setRotulo("FUENTE 2 - GENERADOR RESPALDO");
											setStep("FORMULARIO_POTENCIA_ATS");
										},
										className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xl block mb-1",
												children: "📻"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1569,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-xs text-slate-200 block",
												children: "Fuente 2 (Emergencia)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1570,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[9px] text-slate-500",
												children: "Planta Eléctrica"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1571,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1561,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => {
											setRotulo("SALIDA A CARGAS RESPALDADAS");
											setStep("FORMULARIO_POTENCIA_ATS_SALIDA");
										},
										className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xl block mb-1",
												children: "🏢"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1581,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-xs text-slate-200 block",
												children: "Salida a Cargas"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1582,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[9px] text-slate-500",
												children: "Tablero Principal / CCM"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1583,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1573,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setStep("VINCULAR_EXISTENTE"),
										className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xl block mb-1",
												children: "🔗"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1590,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-xs text-slate-200 block",
												children: "Vincular Elemento Creado"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1591,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[9px] text-slate-500",
												children: "Buscar en el proyecto"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1592,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1585,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1548,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1540,
								columnNumber: 17
							}, this),
							step === "FORMULARIO_POTENCIA_ATS" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1601,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-amber-300",
											children: "Parámetros de Fuente ATS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1602,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1600,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-3 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-400 font-bold mb-1",
											children: "Conductor de Acometida"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1606,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: conductor,
											onChange: (e) => setConductor(e.target.value),
											placeholder: "Ej. 3x500 MCM",
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1607,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1605,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-400 font-bold mb-1",
											children: "Tipo de Conmutador"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1616,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: tipoConmutador,
											onChange: (e) => setTipoConmutador(e.target.value),
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Motorizado Interlocked",
													children: "Motorizado Interlocked"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1622,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Contactores Mecánicos",
													children: "Contactores Mecánicos"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1623,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Estático STS",
													children: "Estático STS"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1624,
													columnNumber: 25
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1617,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1615,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1604,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => handleSaveEquipment(rotulo || "FUENTE ATS", "TRANSFER"),
										className: "w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-sm transition-colors cursor-pointer mt-4",
										children: "Guardar Fuente ATS"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1628,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1599,
								columnNumber: 17
							}, this),
							step === "FORMULARIO_POTENCIA_ATS_SALIDA" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1641,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-amber-300",
											children: "Parámetros de Salida / Cargas ATS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1642,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1640,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-3 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-400 font-bold mb-1",
											children: "Corriente Nominal ATS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1646,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: breakerAmp,
											onChange: (e) => setBreakerAmp(e.target.value),
											placeholder: "Ej. 1600 A",
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1647,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1645,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-400 font-bold mb-1",
											children: "Enclavamiento Verificado"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1656,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: pararrayos,
											onChange: (e) => setPararrayos(e.target.value),
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Mecánico y Eléctrico",
													children: "Mecánico y Eléctrico"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1662,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Solo Eléctrico",
													children: "Solo Eléctrico"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1663,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Pendiente",
													children: "Pendiente"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1664,
													columnNumber: 25
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1657,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1655,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1644,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => handleSaveEquipment(rotulo || "SALIDA ATS A CARGAS", "TABLERO"),
										className: "w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-sm transition-colors cursor-pointer mt-4",
										children: "Guardar Salida ATS"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1668,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1639,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1538,
						columnNumber: 13
					}, this),
					!isTablero && tipoOrigen === "CCM" && (step === "PREGUNTA_CARGA_CCM" || step === "FORMULARIO_GAVETA_CCM") && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [step === "PREGUNTA_CARGA_CCM" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(Layers, { className: "w-12 h-12 text-amber-500 mx-auto mb-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1688,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-base font-bold text-slate-100",
									children: "¿Qué tipo de carga industrial acciona esta Gaveta / Bucket?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1689,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400",
									children: "Selecciona el uso del motor o carga alimentada."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1692,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1687,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("BOMBA DE AGUAPOTABLE / PROCESO");
										setStep("FORMULARIO_GAVETA_CCM");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🚰"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1703,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Bomba de Agua"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1704,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Hidroneumático / Proceso"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1705,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1695,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("COMPRESOR DE AIRE");
										setStep("FORMULARIO_GAVETA_CCM");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "🌀"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1715,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Compresor"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1716,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Neumático / Frío"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1717,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1707,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("EXTRACTOR / VENTILACIÓN");
										setStep("FORMULARIO_GAVETA_CCM");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "💨"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1727,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Extractor / Ventilación"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1728,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Tiro Forzado"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1729,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1719,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setRotulo("BANDA TRANSPORTADORA");
										setStep("FORMULARIO_GAVETA_CCM");
									},
									className: "p-4 rounded-xl border border-slate-800 hover:border-amber-500 bg-slate-950/60 text-left hover:bg-amber-500/5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl block mb-1",
											children: "⚙️"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1739,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-slate-200 block",
											children: "Banda / Agitador"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1740,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] text-slate-500",
											children: "Proceso Continuo"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1741,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1731,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1694,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1686,
							columnNumber: 17
						}, this), step === "FORMULARIO_GAVETA_CCM" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1750,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-amber-300",
										children: "Ficha Técnica de Gaveta CCM"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1751,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1749,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-3 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-400 font-bold mb-1",
											children: "Tag / Nombre del Equipo"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1755,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: rotulo,
											onChange: (e) => setRotulo(e.target.value),
											placeholder: "Ej. Bomba de Agua 1",
											className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1756,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1754,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-2 gap-3",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-400 font-bold mb-1",
												children: "Esquema de Arranque"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1766,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("select", {
												value: esquemaArranque,
												onChange: (e) => setEsquemaArranque(e.target.value),
												className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white",
												children: [
													/* @__PURE__ */ _jsxDEV("option", {
														value: "Directo (DOL)",
														children: "Directo (DOL)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1772,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "Estrella-Triángulo",
														children: "Estrella-Triángulo"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1773,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "Variador de Frecuencia (VFD)",
														children: "Variador de Frecuencia (VFD)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1774,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "Arrancador Suave (Soft Starter)",
														children: "Arrancador Suave (Soft Starter)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1775,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1767,
												columnNumber: 25
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1765,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-400 font-bold mb-1",
												children: "Potencia Motor (HP/kW)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1779,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: hpKw,
												onChange: (e) => setHpKw(e.target.value),
												placeholder: "Ej. 25 HP",
												className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1780,
												columnNumber: 25
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1778,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1764,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-2 gap-3",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-400 font-bold mb-1",
												children: "Protección / Guardamotor"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1791,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: proteccion,
												onChange: (e) => setProteccion(e.target.value),
												placeholder: "Ej. Guardamotor 32A",
												className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1792,
												columnNumber: 25
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1790,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-400 font-bold mb-1",
												children: "Red / Comms Control"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1801,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: redComms,
												onChange: (e) => setRedComms(e.target.value),
												placeholder: "Ej. Modbus RTU / Ethernet",
												className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1802,
												columnNumber: 25
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1800,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1789,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1753,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleSaveEquipment(rotulo || "GAVETA MOTOR", "ARTEFACTO", {
										esquemaArranque,
										hpKw,
										proteccion,
										redComms
									}),
									className: "w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-sm transition-colors cursor-pointer mt-4",
									children: "Guardar Ficha Gaveta CCM"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1812,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1748,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1684,
						columnNumber: 13
					}, this),
					!isTablero && tipoOrigen === "PUNTO_MEDICION" && (step === "PREGUNTA_ORIGEN_MEDICION" || step === "FORMULARIO_MEDICION") && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Gauge, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1830,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-amber-300",
									children: "Configuración Acometida Medida"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1831,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1829,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-400 font-bold mb-1",
									children: "Relación TCs (Corriente)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1835,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: relacionTc,
									onChange: (e) => setRelacionTc(e.target.value),
									placeholder: "Ej. 800/5A",
									className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1836,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1834,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-400 font-bold mb-1",
									children: "Relación TPs (Tensión)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1845,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: relacionTp,
									onChange: (e) => setRelacionTp(e.target.value),
									placeholder: "Ej. 13800/120V o N/A",
									className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1846,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1844,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1833,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => handleSaveEquipment("PUNTO DE CONEXIÓN PCC / ACOMETIDA", "PUNTO_MEDICION", {
									relacionTc,
									relacionTp
								}),
								className: "w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-sm transition-colors cursor-pointer mt-4",
								children: "Guardar Acometida Medición"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1855,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1828,
						columnNumber: 13
					}, this),
					!isTablero && tipoOrigen === "PUESTA_TIERRA" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1871,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-amber-300",
									children: "Conexión a Malla de Puesta a Tierra"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1872,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1870,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-400 font-bold mb-1",
									children: "Conductor de Tierra"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1876,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: conductor,
									onChange: (e) => setConductor(e.target.value),
									placeholder: "Ej. 4/0 AWG Desnudo",
									className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1877,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1875,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-400 font-bold mb-1",
									children: "Resistencia Medida (Ω)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1886,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: resistenciaOhms,
									onChange: (e) => setResistenciaOhms(e.target.value),
									placeholder: "Ej. 2.5 Ω",
									className: "w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1887,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1885,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1874,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => handleSaveEquipment("MALLA PUESTA A TIERRA", "PUESTA_TIERRA", { resistenciaOhms }),
								className: "w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-sm transition-colors cursor-pointer mt-4",
								children: "Guardar Conexión Tierra"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1896,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1869,
						columnNumber: 13
					}, this),
					step === "VINCULAR_EXISTENTE" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: [
							renderUniversalElementSelector(),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold text-slate-300 mb-1",
									children: isMultiSelect ? "O Buscar Elemento(s) en el Proyecto" : "O Buscar por Texto / ID en el Proyecto"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1914,
									columnNumber: 17
								}, this),
								isMultiSelect && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-amber-400 font-semibold mb-2",
									children: "✓ Puedes seleccionar varios elementos alimentados por esta acometida secundaria."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1918,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: searchQuery,
										onChange: (e) => {
											setSearchQuery(e.target.value);
											if (!isMultiSelect) setSelectedLink(null);
										},
										placeholder: "Escribe el nombre o ID del elemento...",
										className: "w-full pl-10 pr-4 py-2 border border-slate-700 rounded-lg bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 focus:outline-none text-sm"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1923,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV(Search, { className: "w-5 h-5 absolute left-3 top-2.5 text-slate-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1933,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1922,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1913,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "border border-slate-800 rounded-lg max-h-48 overflow-y-auto divide-y divide-slate-800 bg-slate-950",
								children: filteredElements.length > 0 ? filteredElements.map((el) => {
									const isSelected = isMultiSelect ? selectedLinks.some((item) => item.id === el.id) : selectedLink?.id === el.id || selectedElementoDestinoId === el.id;
									return /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => {
											if (isMultiSelect) {
												if (selectedLinks.some((item) => item.id === el.id)) {
													setSelectedLinks(selectedLinks.filter((item) => item.id !== el.id));
												} else {
													setSelectedLinks([...selectedLinks, el]);
												}
											} else {
												setSelectedLink(el);
												setSelectedElementoDestinoId(el.id);
												setSelectedTipoElementoDestino(el.tipo || el.tipoElemento || "TABLERO");
												setSearchQuery(el.nombre);
											}
										},
										className: `w-full text-left px-4 py-2.5 text-sm hover:bg-slate-900 flex justify-between items-center transition-colors cursor-pointer ${isSelected ? "bg-amber-500/10 hover:bg-amber-500/15" : ""}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-3",
											children: [isMultiSelect && /* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: isSelected,
												onChange: () => {},
												className: "w-4 h-4 accent-amber-500 rounded cursor-pointer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1968,
												columnNumber: 29
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "font-semibold text-slate-200",
												children: el.nombre
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1976,
												columnNumber: 29
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] text-amber-500 font-mono",
												children: [
													"ID: ",
													el.id,
													" ",
													el.tipo ? `• [${el.tipo}]` : ""
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1977,
												columnNumber: 29
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1975,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1966,
											columnNumber: 25
										}, this), isSelected && /* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1980,
											columnNumber: 40
										}, this)]
									}, el.id, true, {
										fileName: _jsxFileName,
										lineNumber: 1945,
										columnNumber: 23
									}, this);
								}) : /* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 text-center text-xs text-slate-400",
									children: "No se encontraron elementos con ese nombre."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1985,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1937,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-4 border-t border-slate-800 flex justify-end",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleSaveVinculo(),
									disabled: (isMultiSelect ? selectedLinks.length === 0 : !selectedLink && !selectedElementoDestinoId) || isTablero && !validation.isValid,
									className: "px-6 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-black text-sm shadow-md transition-colors w-full cursor-pointer",
									children: isTablero && !validation.isValid ? "Resolver Conflicto de Polos para Guardar" : isMultiSelect ? `Vincular ${selectedLinks.length} Elemento${selectedLinks.length === 1 ? "" : "s"} y Guardar` : "Vincular y Guardar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1992,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1991,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1910,
						columnNumber: 13
					}, this),
					step === "ALIMENTAR_POR_CREAR" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6 text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto border border-amber-500/30",
								children: /* @__PURE__ */ _jsxDEV(PlusCircle, { className: "w-10 h-10 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2013,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2012,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "text-base font-bold text-slate-100",
								children: "¿Agregar a la Lista de Elementos por Crear?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2016,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 mt-2 px-4 leading-relaxed",
								children: "Al confirmar, se registrará una tarea pendiente para crear este nuevo Sub-Elemento en el proyecto."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2019,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2015,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-4 border-t border-slate-800",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleSavePorCrear,
									disabled: isTablero && !validation.isValid,
									className: "px-6 py-3 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-black text-sm shadow-md transition-colors w-full cursor-pointer active:scale-[0.98]",
									children: isTablero && !validation.isValid ? "Resolver Conflicto de Polos" : "Agregar a la Lista de Pendientes"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2024,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2023,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2011,
						columnNumber: 13
					}, this),
					isTablero && step === "ROTULAR_Y_FOTO" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-5",
						children: [
							renderUniversalElementSelector(),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold text-slate-300 mb-1",
								children: "Rótulo del Circuito / Descripción"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2044,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: rotulo,
								onChange: (e) => setRotulo(e.target.value),
								placeholder: "Ej. RESERVA, VACÍO, ALIMENTACIÓN A CCM-01",
								className: "w-full px-3 py-2 text-sm border border-slate-700 rounded-lg bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2047,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2043,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold text-slate-300 mb-1",
								children: "Conductor (Calibre opcional)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2057,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: conductor,
								onChange: (e) => setConductor(e.target.value),
								className: "w-full px-3 py-2 text-sm border border-slate-700 rounded-lg bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 focus:outline-none",
								children: COND_OPTIONS.map((opt) => /* @__PURE__ */ _jsxDEV("option", {
									value: opt,
									children: opt
								}, opt, false, {
									fileName: _jsxFileName,
									lineNumber: 2065,
									columnNumber: 44
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2060,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2056,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold text-slate-300 mb-2",
								children: "Fotografía de Evidencia / Circuito"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2070,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV(DualPhotoUploader, {
								value: fotoUrl,
								onChange: (val) => setFotoUrl(val),
								label: "Fotografía del Circuito o Breaker"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2073,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2069,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-4 border-t border-slate-800 flex justify-end",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleSaveRotuloFoto,
									disabled: isTablero && !validation.isValid,
									className: "px-6 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-black text-sm shadow-md transition-colors w-full cursor-pointer",
									children: isTablero && !validation.isValid ? "Resolver Conflicto de Polos para Guardar" : "Guardar Cambios"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2081,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2080,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2039,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 760,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 701,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 695,
		columnNumber: 5
	}, this);
};
_s(ModalEdicionCircuito, "NdNro1ZAxBgJEBa+9OBPVL5sPUo=", false, function() {
	return [useConfirm, useStore];
});
_c = ModalEdicionCircuito;
export default ModalEdicionCircuito;
var _c;
$RefreshReg$(_c, "ModalEdicionCircuito");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ModalEdicionCircuito.jsx?t=1790793566895";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalEdicionCircuito.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalEdicionCircuito.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ModalEdicionCircuito.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxlQUFlO0FBQ3BELFNBQ0UsR0FDQSxXQUNBLFFBQ0EsT0FDQSxRQUNBLFlBQ0EsYUFDQSxVQUNBLGVBQ0EsS0FDQSxLQUNBLFVBQ0EsYUFDQSxRQUNBLFdBQ0EsT0FDQSxPQUNBLGlCQUNLO0FBQ1AsU0FBUyxhQUFhLGNBQWMsZUFBZSxvQkFBb0I7QUFDdkUsU0FBUyx1QkFBdUIsd0JBQXdCO0FBQ3hELFNBQVMsa0JBQWtCO0FBQzNCLE9BQU8sdUJBQXVCO0FBQzlCLE9BQU8sY0FBYzs7OztBQUVyQixNQUFNLGlCQUFpQixRQUFRO0NBQzdCLElBQUksT0FBTyxRQUFRLFlBQVksQ0FBQyxLQUFLLE9BQU8sT0FBTztDQUNuRCxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsUUFBUSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFlBQVk7QUFDckQ7QUFFQSxNQUFNLHlCQUF5QjtDQUM3QjtFQUFFLElBQUk7RUFBUyxRQUFRO0VBQXFDLE1BQU07Q0FBVTtDQUM1RTtFQUFFLElBQUk7RUFBUyxRQUFRO0VBQWdDLE1BQU07Q0FBYztDQUMzRTtFQUFFLElBQUk7RUFBUyxRQUFRO0VBQW1DLE1BQU07Q0FBVztDQUMzRTtFQUFFLElBQUk7RUFBUyxRQUFRO0VBQXNCLE1BQU07Q0FBTTtBQUMzRDtBQUVBLE9BQU8sTUFBTSx3QkFBd0IsRUFDbkMsUUFDQSxTQUNBLGFBQ0EsUUFDQSxtQkFBbUIsd0JBQ25CLGtCQUFrQixDQUFDLEdBQ25CLFdBQVcsSUFDWCxtQkFDQSxhQUFhLFdBQ2IsT0FBTyxlQUNIOztDQUNKLE1BQU0sRUFBRSxPQUFPLGdCQUFnQixXQUFXO0NBQzFDLE1BQU0sRUFBRSw0QkFBNEIsV0FBVywyQkFBMkIsU0FBUztDQUNuRixNQUFNLFlBQVksQ0FBQyxjQUFjLGVBQWU7Q0FFaEQsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLHVCQUF1Qjs7Q0FHeEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFO0NBQ25ELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUM3QyxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEVBQUU7Q0FDekQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsRUFBRTtDQUNyRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFOztDQUdyRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQztDQUMxQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxDQUFDO0NBQ2xELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxRQUFROztDQUc3QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLElBQUk7Q0FDckQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsQ0FBQyxDQUFDO0NBQ3JELE1BQU0sQ0FBQywyQkFBMkIsZ0NBQWdDLFNBQVMsRUFBRTtDQUM3RSxNQUFNLENBQUMsNkJBQTZCLGtDQUFrQyxTQUFTLEVBQUU7Q0FDakYsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsRUFBRTtDQUNyRCxNQUFNLENBQUMsMEJBQTBCLCtCQUErQixTQUFTLEtBQUs7Q0FDOUUsTUFBTSxDQUFDLHVCQUF1Qiw0QkFBNEIsU0FBUyxFQUFFO0NBQ3JFLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsU0FBUztDQUVoRSxNQUFNLGdCQUFnQixlQUFlLG9CQUFvQixTQUFTLGdCQUFnQixTQUFTOztDQUczRixNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRTtDQUN2QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTs7Q0FHM0MsTUFBTSxrQkFBa0IsY0FBYztFQUNwQyxNQUFNLFNBQVM7R0FDYixTQUFTLENBQUM7R0FDVixVQUFVLENBQUM7R0FDWCxLQUFLLENBQUM7R0FDTixXQUFXLENBQUM7R0FDWixhQUFhLENBQUM7R0FDZCxlQUFlLENBQUM7R0FDaEIsZ0JBQWdCLENBQUM7R0FDakIsT0FBTyxDQUFDO0VBQ1Y7RUFDQSxDQUFDLG9CQUFvQixDQUFDLEVBQUMsQ0FBRSxTQUFRLE9BQU07R0FDckMsTUFBTSxRQUFRLEdBQUcsUUFBUSxHQUFHLGdCQUFnQixHQUFFLENBQUUsWUFBWTtHQUM1RCxJQUFJLEtBQUssU0FBUyxVQUFVLEtBQUssS0FBSyxTQUFTLEtBQUssS0FBSyxLQUFLLFNBQVMsS0FBSyxHQUFHO0lBQzdFLE9BQU8sU0FBUyxLQUFLLEVBQUU7R0FDekIsT0FBTyxJQUFJLEtBQUssU0FBUyxXQUFXLEtBQUssS0FBSyxTQUFTLEtBQUssS0FBSyxLQUFLLFNBQVMsUUFBUSxHQUFHO0lBQ3hGLE9BQU8sVUFBVSxLQUFLLEVBQUU7R0FDMUIsT0FBTyxJQUFJLEtBQUssU0FBUyxLQUFLLEtBQUssS0FBSyxTQUFTLE9BQU8sR0FBRztJQUN6RCxPQUFPLElBQUksS0FBSyxFQUFFO0dBQ3BCLE9BQU8sSUFBSSxLQUFLLFNBQVMsYUFBYSxLQUFLLEtBQUssU0FBUyxJQUFJLEdBQUc7SUFDOUQsT0FBTyxZQUFZLEtBQUssRUFBRTtHQUM1QixPQUFPLElBQUksS0FBSyxTQUFTLFNBQVMsS0FBSyxLQUFLLFNBQVMsT0FBTyxHQUFHO0lBQzdELE9BQU8sY0FBYyxLQUFLLEVBQUU7R0FDOUIsT0FBTyxJQUFJLEtBQUssU0FBUyxVQUFVLEtBQUssS0FBSyxTQUFTLFFBQVEsS0FBSyxLQUFLLFNBQVMsT0FBTyxHQUFHO0lBQ3pGLE9BQU8sZUFBZSxLQUFLLEVBQUU7R0FDL0IsT0FBTyxJQUFJLEtBQUssU0FBUyxTQUFTLEtBQUssU0FBUyxpQkFBaUIsU0FBUyxTQUFTO0lBQ2pGLE9BQU8sUUFBUSxLQUFLLEVBQUU7R0FDeEIsT0FBTztJQUNMLE9BQU8sTUFBTSxLQUFLLEVBQUU7R0FDdEI7RUFDRixDQUFDO0VBQ0QsT0FBTztDQUNULEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQzs7Q0FHckIsTUFBTSxnQ0FBZ0MsTUFBTTtFQUMxQyxNQUFNLE1BQU0sRUFBRSxPQUFPO0VBQ3JCLGlCQUFpQixHQUFHO0VBRXBCLElBQUksQ0FBQyxPQUFPLFFBQVEsYUFBYSxRQUFRLFdBQVc7R0FDbEQsNkJBQTZCLEVBQUU7R0FDL0IsK0JBQStCLEVBQUU7R0FDakMsZ0JBQWdCLElBQUk7R0FDcEIsNEJBQTRCLEtBQUs7R0FDakMseUJBQXlCLEVBQUU7R0FDM0I7RUFDRjtFQUVBLElBQUksSUFBSSxXQUFXLE1BQU0sR0FBRztHQUMxQiw0QkFBNEIsSUFBSTtHQUNoQyxnQkFBZ0IsSUFBSTtHQUNwQiw2QkFBNkIsRUFBRTtHQUUvQixNQUFNLGVBQWUsWUFBWSxpQkFBaUIsY0FBYyxjQUFjLFFBQVE7R0FDdEYsTUFBTSxXQUFXLGFBQWEsS0FBSyxJQUFJO0dBQ3ZDLElBQUksYUFBYTtHQUNqQixJQUFJLFlBQVk7R0FFaEIsSUFBSSxRQUFRLGdCQUFnQjtJQUMxQixhQUFhO0lBQ2IsWUFBWTtHQUNkLE9BQU8sSUFBSSxRQUFRLFdBQVc7SUFDNUIsYUFBYTtJQUNiLFlBQVk7R0FDZCxPQUFPLElBQUksUUFBUSxpQkFBaUI7SUFDbEMsYUFBYTtJQUNiLFlBQVk7R0FDZCxPQUFPLElBQUksUUFBUSxxQkFBcUI7SUFDdEMsYUFBYTtJQUNiLFlBQVk7R0FDZCxPQUFPLElBQUksUUFBUSxtQkFBbUI7SUFDcEMsYUFBYTtJQUNiLFlBQVk7R0FDZCxPQUFPLElBQUksUUFBUSxzQkFBc0I7SUFDdkMsYUFBYTtJQUNiLFlBQVk7R0FDZCxPQUFPLElBQUksUUFBUSxhQUFhO0lBQzlCLGFBQWE7SUFDYixZQUFZO0dBQ2Q7R0FFQSxtQkFBbUIsVUFBVTtHQUM3QiwrQkFBK0IsVUFBVTtHQUV6QyxNQUFNLHlCQUF5QixTQUFTLFVBQVUsU0FBUyxTQUFTO0dBQ3BFLHlCQUF5QixzQkFBc0I7R0FFL0MsTUFBTSxXQUFXLGdCQUFnQixVQUFVLElBQUk7R0FDL0MsbUJBQW1CLFFBQVE7R0FDM0IsVUFBVSxRQUFRO0dBQ2xCLElBQUksQ0FBQyxlQUFlO0lBQ2xCLGlCQUFpQixxQ0FBcUMsVUFBVSxrQkFBa0IsU0FBUyxFQUFFO0dBQy9GO0dBQ0E7RUFDRjs7RUFHQSw0QkFBNEIsS0FBSztFQUNqQyx5QkFBeUIsRUFBRTtFQUMzQixNQUFNLFNBQVMsb0JBQW9CLENBQUMsRUFBQyxDQUFFLE1BQUssT0FBTSxPQUFPLEdBQUcsRUFBRSxNQUFNLE9BQU8sR0FBRyxDQUFDO0VBQy9FLElBQUksT0FBTztHQUNULDZCQUE2QixNQUFNLEVBQUU7R0FDckMsTUFBTSxJQUFJLE1BQU0sUUFBUSxNQUFNLGdCQUFnQjtHQUM5QywrQkFBK0IsQ0FBQztHQUNoQyxnQkFBZ0IsS0FBSztHQUVyQixNQUFNLFlBQVksTUFBTSxRQUFRLFFBQ2QsTUFBTSxhQUFhLHNCQUNuQixNQUFNLGNBQWMsY0FDcEIsTUFBTSxnQkFBZ0IsZ0JBQ3RCLE1BQU0sa0JBQWtCLGtCQUN4QixNQUFNLG1CQUFtQixxQkFDekIsTUFBTSxZQUFZLFlBQWEsS0FBSztHQUN0RCxNQUFNLFdBQVcsa0JBQWtCLFVBQVUsSUFBSSxNQUFNO0dBQ3ZELG1CQUFtQixRQUFRO0dBQzNCLFVBQVUsUUFBUTtHQUNsQixJQUFJLENBQUMsZUFBZTtJQUNsQixpQkFBaUIsOEJBQThCLE1BQU0sT0FBTyxRQUFRLE1BQU0sR0FBRyxFQUFFO0dBQ2pGO0VBQ0Y7Q0FDRjs7Q0FHQSxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxFQUFFO0NBQzdDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEVBQUU7Q0FDL0MsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsRUFBRTtDQUNuRCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEVBQUU7Q0FDekQsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEVBQUU7Q0FDbkMsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxFQUFFO0NBQzNELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEVBQUU7Q0FDL0MsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEVBQUU7Q0FDL0MsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEVBQUU7Q0FDekQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsRUFBRTtDQUNyRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsRUFBRTtDQUM3RCxNQUFNLENBQUMsdUJBQXVCLDRCQUE0QixTQUFTLEVBQUU7O0NBR3JFLE1BQU0sK0JBQStCO0VBQ25DLE9BQU8sWUFBWSxJQUFJO0dBQ3JCLFFBQVE7R0FDUixhQUFhO0dBQ2IsYUFBYTtHQUNiLG1CQUFtQjtHQUNuQixxQkFBcUI7R0FDckIseUJBQXlCO0dBQ3pCLG1CQUFtQjtHQUNuQixTQUFTO0lBQ1AsS0FBSztJQUNMLE9BQU87SUFDUCxNQUFNO0dBQ1I7R0FDQSxXQUFXO0dBQ1gsT0FBTyxZQUFZLFdBQVcsZ0JBQWdCO0lBQUM7SUFBRztJQUFHO0dBQUM7R0FDdEQsVUFBVSxZQUFZLFdBQVc7R0FDakMsY0FBYyxZQUFZLGVBQWU7R0FDekMsWUFBWSxhQUFhLGNBQWMsYUFBYSxjQUFjO0dBQ2xFLFlBQVksYUFBYSxjQUFjLGFBQWEsY0FBYztHQUNsRSxRQUFRO0dBQ1IsT0FBTztJQUNMLGFBQWE7SUFDYixlQUFlO0dBQ2pCO0dBQ0EsWUFBWTtHQUNaLGtCQUFrQixDQUFDO0VBQ3JCLENBQUM7RUFDRCxRQUFRO0NBQ1Y7O0NBR0EsZ0JBQWdCO0VBQ2QsSUFBSSxlQUFlLFFBQVE7R0FDekIsY0FBYyxZQUFZLFNBQVMsT0FBTyxFQUFFO0dBQzVDLGdCQUFnQixZQUFZLFNBQVMsU0FBUyxFQUFFO0dBQ2hELGVBQWUsWUFBWSxTQUFTLFFBQVEsRUFBRTtHQUM5QyxhQUFhLFlBQVksYUFBYSxFQUFFO0dBQ3hDLG1CQUFtQixZQUFZLGdCQUFnQixjQUFjLFlBQVksU0FBUyxFQUFFO0dBQ3BGLGlCQUFpQixZQUFZLE9BQU8sZUFBZSxFQUFFO0dBQ3JELGlCQUFpQixZQUFZLE9BQU8saUJBQWlCLEVBQUU7R0FDdkQsVUFBVSxZQUFZLFVBQVUsWUFBWSxVQUFVLEVBQUU7R0FDeEQsaUJBQWlCLENBQUMsQ0FBQztHQUNuQiw0QkFBNEIsS0FBSztHQUNqQyx5QkFBeUIsRUFBRTs7R0FHM0IsTUFBTSxnQkFBZ0IsWUFBWSxxQkFBcUIsWUFBWSxlQUFlO0dBQ2xGLE1BQU0sa0JBQWtCLFlBQVksdUJBQXVCLFlBQVksZUFBZTtHQUN0Riw2QkFBNkIsYUFBYTtHQUMxQywrQkFBK0IsZUFBZTtHQUU5QyxJQUFJLGVBQWU7SUFDakIsaUJBQWlCLGFBQWE7SUFDOUIsTUFBTSxTQUFTLG9CQUFvQixDQUFDLEVBQUMsQ0FBRSxNQUFLLE9BQU0sT0FBTyxHQUFHLEVBQUUsTUFBTSxPQUFPLGFBQWEsS0FBSyxHQUFHLFdBQVcsWUFBWSxNQUFNO0lBQzdILElBQUksT0FBTztLQUNULGdCQUFnQixLQUFLO0tBQ3JCLGVBQWUsTUFBTSxNQUFNO0lBQzdCLE9BQU87S0FDTCxnQkFBZ0IsSUFBSTtLQUNwQixlQUFlLFlBQVksVUFBVSxFQUFFO0lBQ3pDO0dBQ0YsT0FBTztJQUNMLGlCQUFpQixFQUFFO0lBQ25CLGdCQUFnQixJQUFJO0lBQ3BCLGVBQWUsRUFBRTtHQUNuQjs7R0FHQSxNQUFNLFdBQVcsWUFBWSxpQkFBaUIsWUFBWSxZQUFZLGVBQWdCLFlBQVksU0FBUyxZQUFZLE1BQU0sU0FBUyxJQUFJLFlBQVksTUFBTSxLQUFLO0dBQ2pLLE1BQU0sVUFBVSxZQUFZLGFBQWEsWUFBWSxZQUFZLFdBQVksWUFBWSxTQUFTLFlBQVksTUFBTSxTQUFTLElBQUksWUFBWSxNQUFNLFNBQVM7R0FDNUosZ0JBQWdCLFNBQVMsVUFBVSxFQUFFLEtBQUssQ0FBQztHQUMzQyxZQUFZLFNBQVMsU0FBUyxFQUFFLEtBQUssQ0FBQztHQUN0QyxVQUFVLFlBQVksV0FBVyxZQUFZLFdBQVcsWUFBWSxZQUFZLFNBQVM7O0dBR3pGLE1BQU0sS0FBSyxZQUFZLG9CQUFvQixDQUFDO0dBQzVDLElBQUksR0FBRyxTQUFTLFdBQVcsR0FBRyxPQUFPO0dBQ3JDLElBQUksR0FBRyxjQUFjLFdBQVcsYUFBYSxHQUFHLFNBQVM7R0FDekQsSUFBSSxHQUFHLFlBQVksY0FBYyxHQUFHLFVBQVU7R0FDOUMsSUFBSSxHQUFHLGNBQWMsZ0JBQWdCLEdBQUcsWUFBWTtHQUNwRCxJQUFJLEdBQUcsaUJBQWlCLG1CQUFtQixHQUFHLGVBQWU7R0FDN0QsSUFBSSxHQUFHLE1BQU0sUUFBUSxHQUFHLElBQUk7R0FDNUIsSUFBSSxHQUFHLGtCQUFrQixvQkFBb0IsR0FBRyxnQkFBZ0I7R0FDaEUsSUFBSSxHQUFHLFlBQVksY0FBYyxHQUFHLFVBQVU7R0FDOUMsSUFBSSxHQUFHLFVBQVUsWUFBWSxHQUFHLFFBQVE7R0FDeEMsSUFBSSxHQUFHLGdCQUFnQixrQkFBa0IsR0FBRyxjQUFjO0dBQzFELElBQUksR0FBRyxZQUFZLGNBQWMsR0FBRyxVQUFVO0dBQzlDLElBQUksR0FBRyxZQUFZLGNBQWMsR0FBRyxVQUFVO0dBQzlDLElBQUksR0FBRyxpQkFBaUIsbUJBQW1CLEdBQUcsZUFBZTtHQUM3RCxJQUFJLEdBQUcsZUFBZSxpQkFBaUIsR0FBRyxhQUFhO0dBQ3ZELElBQUksR0FBRyxlQUFlLGlCQUFpQixHQUFHLGFBQWE7R0FDdkQsSUFBSSxHQUFHLG1CQUFtQixxQkFBcUIsR0FBRyxpQkFBaUI7R0FDbkUsSUFBSSxHQUFHLHVCQUF1Qix5QkFBeUIsR0FBRyxxQkFBcUI7O0dBRy9FLElBQUksV0FBVztJQUNiLElBQUksWUFBWSxnQkFBZ0IsYUFBYTtLQUMzQyxRQUFRLHNCQUFzQjtJQUNoQyxPQUFPLElBQUksWUFBWSxnQkFBZ0IsaUJBQWlCLFlBQVksZ0JBQWdCLFlBQVk7S0FDOUYsUUFBUSxvQkFBb0I7S0FDNUIsTUFBTSxRQUFRLGlCQUFpQixNQUFLLE9BQU0sR0FBRyxXQUFXLFlBQVksVUFBVSxHQUFHLE9BQU8sWUFBWSxXQUFXO0tBQy9HLElBQUksT0FBTztNQUNULGdCQUFnQixLQUFLO01BQ3JCLGVBQWUsTUFBTSxNQUFNO0tBQzdCLE9BQU87TUFDTCxlQUFlLFlBQVksVUFBVSxFQUFFO0tBQ3pDO0lBQ0YsT0FBTyxJQUFJLFlBQVksZ0JBQWdCLDJCQUEyQixZQUFZLGdCQUFnQixzQkFBc0I7S0FDbEgsUUFBUSxxQkFBcUI7SUFDL0IsT0FBTztLQUNMLFFBQVEsdUJBQXVCO0lBQ2pDO0dBQ0YsT0FBTztJQUNMLElBQUksZUFBZSxpQkFBaUI7S0FDbEMsSUFBSSxTQUFTLGFBQWEsU0FBUyxZQUFZLFFBQVEsb0JBQW9CO1VBQ3RFLFFBQVEsb0JBQW9CO0lBQ25DLE9BQU8sSUFBSSxlQUFlLGFBQWE7S0FDckMsUUFBUSxzQkFBc0I7SUFDaEMsT0FBTyxJQUFJLGVBQWUsWUFBWTtLQUNwQyxJQUFJLFNBQVMsZUFBZSxTQUFTLFdBQVcsUUFBUSxzQkFBc0I7VUFDekUsSUFBSSxTQUFTLGFBQWEsUUFBUSxzQkFBc0I7VUFDeEQsUUFBUSxzQkFBc0I7SUFDckMsT0FBTyxJQUFJLGVBQWUsT0FBTztLQUMvQixRQUFRLG9CQUFvQjtJQUM5QixPQUFPLElBQUksZUFBZSxrQkFBa0I7S0FDMUMsUUFBUSwwQkFBMEI7SUFDcEMsT0FBTyxJQUFJLGVBQWUsaUJBQWlCO0tBQ3pDLFFBQVEsMEJBQTBCO0lBQ3BDLE9BQU87S0FDTCxRQUFRLG9CQUFvQjtJQUM5QjtHQUNGO0VBQ0Y7Q0FDRixHQUFHO0VBQUM7RUFBYTtFQUFRO0VBQWtCO0VBQVc7RUFBWTtDQUFJLENBQUM7O0NBR3ZFLE1BQU0sYUFBYSxjQUFjO0VBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLFdBQVc7R0FDekMsT0FBTztJQUNMLFNBQVM7SUFDVCxlQUFlO0tBQUM7S0FBRztLQUFHO0lBQUM7SUFDdkIsWUFBWTtJQUNaLFdBQVcsQ0FBQztJQUNaLGtCQUFrQixDQUFDO0dBQ3JCO0VBQ0Y7RUFDQSxPQUFPLHNCQUFzQjtHQUMzQjtHQUNBO0dBQ0E7R0FDQSxVQUFVO0dBQ1Ysa0JBQWtCLGFBQWE7RUFDakMsQ0FBQztDQUNILEdBQUc7RUFBQztFQUFRLGFBQWE7RUFBSTtFQUFXO0VBQWM7RUFBVTtFQUFVO0NBQWUsQ0FBQztDQUUxRixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsT0FBTztDQUVwQyxNQUFNLG9CQUFvQixvQkFBb0IsQ0FBQyxFQUFDLENBQUUsUUFBUSxRQUN2RCxHQUFHLFVBQVUsR0FBRSxDQUFFLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsTUFDakUsR0FBRyxNQUFNLEdBQUUsQ0FBRSxZQUFZLENBQUMsQ0FBQyxTQUFTLFlBQVksWUFBWSxDQUFDLENBQ2hFO0NBRUEsTUFBTSxpQkFBaUIsV0FBVyxNQUFNO0VBQ3RDLE1BQU0sTUFBTSxDQUFDO0VBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztHQUMxQixJQUFJLEtBQUssWUFBWSxJQUFJLENBQUM7RUFDNUI7RUFDQSxPQUFPO0NBQ1Q7Q0FFQSxNQUFNLHVCQUF1QjtFQUMzQixJQUFJLFdBQVc7R0FDYixPQUFPLFNBQVMsWUFBWSxzQ0FBc0M7RUFDcEU7RUFDQSxJQUFJLGVBQWUsaUJBQWlCO0dBQ2xDLE9BQVEsU0FBUyxhQUFhLFNBQVMsYUFDbkMsd0RBQ0E7RUFDTjtFQUNBLElBQUksZUFBZSxhQUFhO0dBQzlCLE9BQU87RUFDVDtFQUNBLElBQUksZUFBZSxZQUFZO0dBQzdCLElBQUksU0FBUyxlQUFlLFNBQVMsV0FBVyxPQUFPO0dBQ3ZELElBQUksU0FBUyxhQUFhLE9BQU87R0FDakMsT0FBTztFQUNUO0VBQ0EsSUFBSSxlQUFlLE9BQU87R0FDeEIsT0FBTztFQUNUO0VBQ0EsSUFBSSxlQUFlLGtCQUFrQjtHQUNuQyxPQUFPO0VBQ1Q7RUFDQSxJQUFJLGVBQWUsaUJBQWlCO0dBQ2xDLE9BQU87RUFDVDtFQUNBLE9BQU8seUJBQXlCO0NBQ2xDO0NBRUEsTUFBTSx1QkFBdUIsWUFBWSxnQkFBZ0IsUUFBUSxDQUFDLE1BQU07RUFDdEUsSUFBSSxtQkFBbUIsa0JBQWtCLCtCQUErQjtFQUN4RSxJQUFJLGlCQUFpQiw2QkFBNkIsTUFBTSxxQkFBcUIsTUFBTSxlQUFlLGNBQWMsTUFBTTtFQUV0SCxJQUFJLDBCQUEwQjtHQUM1QixtQkFBbUI7RUFDckI7RUFFQSxNQUFNLGNBQWMsY0FBYyxjQUFjLE1BQU0sVUFBVSx5QkFBeUIsVUFBVSxvQkFBb0I7RUFFdkgsSUFBSSxhQUFhLENBQUMsV0FBVyxXQUFXLFdBQVcsYUFBYSxXQUFXLFVBQVUsU0FBUyxHQUFHO0dBQy9GLFdBQVcsVUFBVSxTQUFRLFNBQVE7SUFDbkMsMkJBQTJCO0tBQ3pCLFdBQVcsYUFBYSxhQUFhLGFBQWEsTUFBTTtLQUN4RCxlQUFlLGFBQWEsaUJBQWlCO0tBQzdDLE9BQU8sQ0FBQyxLQUFLLElBQUk7S0FDakIsWUFBWSxZQUFZO0tBQ3hCLGdCQUFnQjtLQUNoQixpQkFBaUIsS0FBSyxZQUFZO0tBQ2xDLGFBQWE7S0FDYixhQUFhLFFBQVEsS0FBSyxLQUFLLGdCQUFnQixLQUFLLFlBQVksZUFBZSxxQkFBcUIsaUJBQWlCLFlBQVk7S0FDakksTUFBTTtJQUNSLENBQUM7R0FDSCxDQUFDO0dBQ0QsVUFDRSx5QkFBeUIsV0FBVyxjQUFjLEtBQUssSUFBSSxFQUFFLHVDQUM3RCxXQUNBO0lBQ0UsT0FBTztJQUNQLGVBQWUsdUJBQXVCLElBQUk7R0FDNUMsQ0FDRjtFQUNGO0VBRUEsT0FBTyxZQUFZLElBQUk7R0FDckIsUUFBUTtHQUNSLGFBQWE7R0FDYixhQUFhO0dBQ2IsbUJBQW1CO0dBQ25CLHFCQUFxQiwyQkFBMkIsa0JBQW1CLCtCQUErQjtHQUNsRyx5QkFBeUIsMkJBQTJCLGtCQUFrQjtHQUN0RSxtQkFBbUIsMkJBQTRCLHlCQUF5QixjQUFlO0dBQ3ZGLFNBQVM7SUFDUCxLQUFLLGNBQWMsY0FBYyxNQUFNLFVBQVU7SUFDakQsT0FBTyxjQUFjLFlBQVk7SUFDakMsTUFBTSxjQUFjLFdBQVc7R0FDakM7R0FDQSxXQUFXLGNBQWMsYUFBYSxNQUFNLFNBQVM7R0FDckQsT0FBTyxZQUFZLFdBQVcsZ0JBQWdCO0lBQUM7SUFBRztJQUFHO0dBQUM7R0FDdEQsVUFBVSxZQUFZLFdBQVc7R0FDakMsY0FBYyxZQUFZLGVBQWU7R0FDekMsWUFBWSxhQUFhLGNBQWMsYUFBYSxjQUFjLE1BQU0sY0FBYztHQUN0RixZQUFZLGFBQWEsY0FBYyxhQUFhLGNBQWMsTUFBTSxjQUFjO0dBQzlFO0dBQ1IsT0FBTztJQUNMLGFBQWE7SUFDYixlQUFlLGdCQUFnQixXQUFXLGFBQWEsSUFBSTtHQUM3RDtHQUNBLFlBQVk7R0FDWixrQkFBa0I7SUFDaEI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLEdBQUc7R0FDTDtFQUNGLENBQUM7RUFDRCxRQUFRO0NBQ1Y7Q0FFQSxNQUFNLDRCQUE0QjtFQUNoQyxJQUFJLENBQUMsZ0JBQWdCLEtBQUssR0FBRyxPQUFPLFlBQVksNkNBQTZDO0VBQzdGLG9CQUFvQixpQkFBaUIsV0FBVztDQUNsRDtDQUVBLE1BQU0scUJBQXFCLGdCQUFnQjtFQUN6QyxJQUFJLGVBQWU7R0FDakIsSUFBSSxjQUFjLFdBQVcsR0FBRyxPQUFPLFlBQVksMkRBQTJEO0dBQzlHLE1BQU0sUUFBUSxjQUFjLEtBQUksT0FBTSxHQUFHLEdBQUcsT0FBTyxRQUFRLEdBQUcsR0FBRyxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUk7R0FDOUUsTUFBTSxNQUFNLGNBQWMsS0FBSSxPQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJO0dBQ3BELG9CQUFvQixPQUFPLGVBQWU7SUFBRSxhQUFhO0lBQUssbUJBQW1CO0lBQUsscUJBQXFCO0lBQWUsWUFBWTtHQUFjLENBQUM7R0FDcko7RUFDRjtFQUNBLE1BQU0sS0FBSyxlQUFlO0VBQzFCLElBQUksQ0FBQyxJQUFJLE9BQU8sWUFBWSxrREFBa0Q7RUFDOUUsb0JBQW9CLEdBQUcsR0FBRyxPQUFPLFFBQVEsR0FBRyxHQUFHLElBQUksR0FBRyxRQUFRLGVBQWU7R0FBRSxhQUFhLEdBQUc7R0FBSSxtQkFBbUIsR0FBRztHQUFJLHFCQUFxQixHQUFHLFFBQVE7RUFBYyxDQUFDO0NBQzlLO0NBRUEsTUFBTSwyQkFBMkI7RUFDL0IsTUFBTSxrQkFBa0IsWUFBWSxpQkFBaUIsY0FBYyxjQUFjLFFBQVE7RUFDekYsTUFBTSxjQUFjLDBCQUEwQixZQUFZLFFBQVEsZ0JBQWdCLEtBQUssSUFBSSxNQUFNLGNBQWM7RUFDL0csb0JBQW9CLGFBQWEseUJBQXlCO0dBQ3hELG1CQUFtQjtHQUNuQix5QkFBeUIsbUJBQW1CO0dBQzVDLE9BQU8sWUFBYSxZQUFZLGlCQUFpQixrQkFBbUI7SUFBQztJQUFHO0lBQUc7R0FBQztFQUM5RSxDQUFDO0NBQ0g7Q0FFQSxNQUFNLDZCQUE2QjtFQUNqQyxvQkFBb0IsVUFBVSxXQUFXLFNBQVM7Q0FDcEQ7Q0FFQSxNQUFNLDJCQUEyQjtFQUMvQixNQUFNLGFBQWEsQ0FDakIsZ0dBQ0EsMkZBQ0Y7RUFDQSxNQUFNLGNBQWMsV0FBVyxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksV0FBVyxNQUFNO0VBQzNFLFdBQVcsV0FBVztDQUN4QjtDQUVBLE1BQU0sdUNBQ0osd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQixDQUNFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLDZCQUE4Qjs7OztlQUFDLCtDQUV6Qzs7Ozs7Y0FDTiw0QkFDQyx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUFpSSxRQUMxSCx5QkFDRDs7Ozs7ZUFDSiwyQkFDRix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQjtNQUF1STtNQUM3SDtNQUFnQjtLQUNwQjs7Ozs7ZUFDSixJQUNEOzs7Ozs7R0FFTCx3QkFBQyxVQUFEO0lBQ0UsT0FBTztJQUNQLFVBQVU7SUFDVixXQUFVO2NBSFo7S0FLRSx3QkFBQyxVQUFEO01BQVEsT0FBTTtnQkFBRztLQUF3RDs7Ozs7S0FHekUsd0JBQUMsWUFBRDtNQUFVLE9BQU07Z0JBQWhCO09BQ0Usd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQWM7T0FBeUM7Ozs7O09BQ3JFLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFlO09BQXdEOzs7OztPQUNyRix3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBVTtPQUF3RDs7Ozs7T0FDaEYsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQWdCO09BQWtEOzs7OztPQUNoRix3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBb0I7T0FBK0M7Ozs7O09BQ2pGLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFrQjtPQUEyQzs7Ozs7T0FDM0Usd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQXFCO09BQW9EOzs7OztPQUN2Rix3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBWTtPQUFrRDs7Ozs7TUFDcEU7Ozs7OztLQUdULGdCQUFnQixRQUFRLFNBQVMsS0FDaEMsd0JBQUMsWUFBRDtNQUFVLE9BQU07Z0JBQ2IsZ0JBQWdCLFFBQVEsS0FBSSxPQUMzQix3QkFBQyxVQUFEO09BQW9CLE9BQU8sR0FBRztpQkFBOUI7UUFDRyxHQUFHO1FBQU87UUFBRyxHQUFHO1FBQUc7T0FDZDtTQUZLLEdBQUc7Ozs7YUFFUixDQUNUO0tBQ087Ozs7O0tBRVgsZ0JBQWdCLFNBQVMsU0FBUyxLQUNqQyx3QkFBQyxZQUFEO01BQVUsT0FBTTtnQkFDYixnQkFBZ0IsU0FBUyxLQUFJLE9BQzVCLHdCQUFDLFVBQUQ7T0FBb0IsT0FBTyxHQUFHO2lCQUE5QjtRQUNHLEdBQUc7UUFBTztRQUFHLEdBQUc7UUFBRztPQUNkO1NBRkssR0FBRzs7OzthQUVSLENBQ1Q7S0FDTzs7Ozs7S0FFWCxnQkFBZ0IsSUFBSSxTQUFTLEtBQzVCLHdCQUFDLFlBQUQ7TUFBVSxPQUFNO2dCQUNiLGdCQUFnQixJQUFJLEtBQUksT0FDdkIsd0JBQUMsVUFBRDtPQUFvQixPQUFPLEdBQUc7aUJBQTlCO1FBQ0csR0FBRztRQUFPO1FBQUcsR0FBRztRQUFHO09BQ2Q7U0FGSyxHQUFHOzs7O2FBRVIsQ0FDVDtLQUNPOzs7OztLQUVYLGdCQUFnQixVQUFVLFNBQVMsS0FDbEMsd0JBQUMsWUFBRDtNQUFVLE9BQU07Z0JBQ2IsZ0JBQWdCLFVBQVUsS0FBSSxPQUM3Qix3QkFBQyxVQUFEO09BQW9CLE9BQU8sR0FBRztpQkFBOUI7UUFDRyxHQUFHO1FBQU87UUFBRyxHQUFHO1FBQUc7T0FDZDtTQUZLLEdBQUc7Ozs7YUFFUixDQUNUO0tBQ087Ozs7O0tBRVgsZ0JBQWdCLFlBQVksU0FBUyxLQUNwQyx3QkFBQyxZQUFEO01BQVUsT0FBTTtnQkFDYixnQkFBZ0IsWUFBWSxLQUFJLE9BQy9CLHdCQUFDLFVBQUQ7T0FBb0IsT0FBTyxHQUFHO2lCQUE5QjtRQUNHLEdBQUc7UUFBTztRQUFHLEdBQUc7UUFBRztPQUNkO1NBRkssR0FBRzs7OzthQUVSLENBQ1Q7S0FDTzs7Ozs7S0FFWCxnQkFBZ0IsY0FBYyxTQUFTLEtBQ3RDLHdCQUFDLFlBQUQ7TUFBVSxPQUFNO2dCQUNiLGdCQUFnQixjQUFjLEtBQUksT0FDakMsd0JBQUMsVUFBRDtPQUFvQixPQUFPLEdBQUc7aUJBQTlCO1FBQ0csR0FBRztRQUFPO1FBQUcsR0FBRztRQUFHO09BQ2Q7U0FGSyxHQUFHOzs7O2FBRVIsQ0FDVDtLQUNPOzs7OztLQUVYLGdCQUFnQixlQUFlLFNBQVMsS0FDdkMsd0JBQUMsWUFBRDtNQUFVLE9BQU07Z0JBQ2IsZ0JBQWdCLGVBQWUsS0FBSSxPQUNsQyx3QkFBQyxVQUFEO09BQW9CLE9BQU8sR0FBRztpQkFBOUI7UUFDRyxHQUFHO1FBQU87UUFBRyxHQUFHO1FBQUc7T0FDZDtTQUZLLEdBQUc7Ozs7YUFFUixDQUNUO0tBQ087Ozs7O0tBRVgsZ0JBQWdCLE1BQU0sU0FBUyxLQUM5Qix3QkFBQyxZQUFEO01BQVUsT0FBTTtnQkFDYixnQkFBZ0IsTUFBTSxLQUFJLE9BQ3pCLHdCQUFDLFVBQUQ7T0FBb0IsT0FBTyxHQUFHO2lCQUE5QjtRQUNHLEdBQUc7UUFBTztRQUFHLEdBQUc7UUFBRztPQUNkO1NBRkssR0FBRzs7OzthQUVSLENBQ1Q7S0FDTzs7Ozs7SUFFTjs7Ozs7O0dBR1AsNEJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQjtPQUNFLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7OztPQUFDO09BQXNEO09BQWdCO01BQ2hGOzs7Ozs7S0FDUCx3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLE9BQU87TUFDUCxXQUFXLE1BQU07T0FDZixNQUFNLElBQUksRUFBRSxPQUFPO09BQ25CLHlCQUF5QixDQUFDO09BQzFCLG1CQUFtQixDQUFDO09BQ3BCLFVBQVUsQ0FBQztNQUNiO01BQ0EsYUFBYSxPQUFPLGdCQUFnQjtNQUNwQyxXQUFVO0tBQ1g7Ozs7O0tBQ0Qsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FBMEM7T0FDTSx3QkFBQyxVQUFEO1FBQVEsV0FBVTtrQkFBb0I7T0FBd0I7Ozs7O09BQUM7TUFDNUc7Ozs7OztJQUNBOzs7Ozs7RUFFSjs7Ozs7O0NBR1AsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUNFLFdBQVU7R0FDVixTQUFTO0VBQ1Y7Ozs7WUFFRCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBR0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRyxTQUFTLDJCQUEyQixTQUFTLHdCQUF3QixTQUFTLHlCQUF5QixTQUFTLDBCQUEwQixTQUFTLDBCQUEwQixTQUFTLHdCQUNyTCx3QkFBQyxVQUFEO01BQ0UsZUFBZTtPQUNiLElBQUksV0FBVztRQUNiLElBQUksU0FBUywwQkFBMEIsU0FBUywwQkFBMEIsUUFBUSx1QkFBdUI7YUFDcEcsSUFBSSxTQUFTLHFCQUFxQixTQUFTLGtCQUFrQixRQUFRLHdCQUF3QjthQUM3RixJQUFJLFNBQVMsd0JBQXdCLFNBQVMsdUJBQXVCLFFBQVEsaUJBQWlCO09BQ3JHLE9BQU87UUFDTCxJQUFJLFNBQVMsa0NBQWtDLFFBQVEsb0JBQW9CO2FBQ3RFLElBQUksU0FBUyxrQ0FBa0MsUUFBUSxxQkFBcUI7YUFDNUUsSUFBSSxTQUFTLDJCQUEyQixRQUFRLHNCQUFzQjthQUN0RSxJQUFJLFNBQVMsNkJBQTZCLFNBQVMsa0NBQWtDLFFBQVEsc0JBQXNCO2FBQ25ILElBQUksU0FBUyx5QkFBeUIsUUFBUSxvQkFBb0I7YUFDbEUsSUFBSSxTQUFTLHVCQUF1QixRQUFRLDBCQUEwQjthQUN0RSxJQUFJLFNBQVMscUJBQXFCLFFBQVEsMEJBQTBCO2FBQ3BFLFFBQVEsb0JBQW9CO09BQ25DO01BQ0Y7TUFDQSxXQUFVO2dCQUVWLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHlCQUEwQjs7Ozs7S0FDekM7Ozs7ZUFFVix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsZUFBZTtLQUNkOzs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWIsQ0FBc0MsbUJBQ3JCLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFzQyxZQUFZLFVBQVUsWUFBWSxNQUFNO01BQWU7Ozs7Y0FDM0g7Ozs7O2FBQ0E7Ozs7YUFDRjs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0csY0FBYyxZQUFZLGdCQUFnQixlQUFlLFlBQVksZ0JBQWdCLGlCQUFpQixZQUFZLFdBQVcsY0FDNUgsd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxTQUFTO01BQ1QsV0FBVTtNQUNWLE9BQU07Z0JBSlIsQ0FNRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7O2dCQUNwQyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBbUI7TUFBd0I7Ozs7Y0FDckQ7Ozs7O2VBRVYsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLHlCQUEwQjs7Ozs7S0FDakM7Ozs7YUFDTDs7Ozs7WUFDRjs7Ozs7YUFHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBR0csYUFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsNkJBQThCOzs7O21CQUFDLDhCQUM3Qzs7Ozs7a0JBQ04sd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsZUFBZSxNQUFNLElBQUksMEJBQTBCO1FBQ2hEOzs7O2dCQUNIOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FFcEY7Ozs7bUJBQ1Asd0JBQUMsVUFBRDtVQUNFLE9BQU87VUFDUCxXQUFXLE1BQU0sWUFBWSxTQUFTLEVBQUUsT0FBTyxPQUFPLEVBQUUsQ0FBQztVQUN6RCxXQUFVO29CQUVUO1dBQUM7V0FBRztXQUFHO1VBQUMsQ0FBQyxDQUFDLEtBQUssTUFDZCx3QkFBQyxVQUFEO1dBQWdCLE9BQU87cUJBQ3BCLE1BQU0sSUFBSSxvQkFBb0IsTUFBTSxJQUFJLGtCQUFrQjtVQUNyRCxHQUZLOzs7O2lCQUVMLENBQ1Q7U0FDSzs7OztpQkFDTDs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBRXBGOzs7O21CQUNQLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsS0FBSTtVQUNKLEtBQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNO1dBQ2YsTUFBTSxNQUFNLFNBQVMsRUFBRSxPQUFPLE9BQU8sRUFBRTtXQUN2QyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssTUFBTSxHQUFHLGdCQUFnQixHQUFHO2dCQUMxQyxJQUFJLEVBQUUsT0FBTyxVQUFVLElBQUksZ0JBQWdCLEVBQUU7VUFDcEQ7VUFDQSxXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUVwRjs7OzttQkFDUCx3QkFBQyxVQUFEO1VBQ0UsT0FBTztVQUNQLFdBQVcsTUFBTTtXQUNmLE1BQU0sTUFBTSxFQUFFLE9BQU87V0FDckIsVUFBVSxHQUFHO1dBQ2IsSUFBSSxRQUFRLGFBQWEsUUFBUSxjQUFjO1lBQzdDLG1CQUFtQixHQUFHO1lBQ3RCLFVBQVUsR0FBRztZQUNiLGNBQWMsRUFBRTtZQUNoQixpQkFBaUIsRUFBRTtZQUNuQixpQkFBaUIsRUFBRTtXQUNyQjtVQUNGO1VBQ0EsV0FBVTtvQkFiWjtXQWVFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFTO1dBQTZCOzs7OztXQUNwRCx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBVTtXQUE4Qjs7Ozs7V0FDdEQsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQWE7V0FBNEI7Ozs7O1VBQ2pEOzs7OztpQkFDTDs7Ozs7UUFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE2QjtVQUF1Qjs7Ozs7VUFDcEUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCO1lBQW9IO1lBQ2hILFdBQVcsY0FBYyxLQUFLLElBQUk7WUFBRTtXQUNsQzs7Ozs7O1VBQ04sd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCO1lBQTZDO1lBQ3pDLGFBQWEsSUFBSSxXQUFXLEdBQUcsU0FBUztZQUFRO1dBQzlDOzs7Ozs7U0FDSDs7Ozs7a0JBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FBc0QscUJBQ25DLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUE0QyxVQUFTLFFBQVk7Ozs7O2lCQUMvRTs7Ozs7Z0JBQ0Y7Ozs7OztPQUdKLENBQUMsV0FBVyxVQUNYLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxpQ0FBa0M7Ozs7bUJBQ3pELHdCQUFDLFFBQUQsWUFBTSw4Q0FBaUQ7Ozs7aUJBQ3BEOzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixXQUFXLGlCQUFpQixLQUFLLEtBQUssUUFDckMsd0JBQUMsS0FBRDtVQUFhLFdBQVU7b0JBQXZCLENBQW1FLE1BQzlELEdBQ0Y7WUFGSzs7OztnQkFFTCxDQUNKO1FBQ0U7Ozs7Z0JBQ0Y7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsb0NBQXFDOzs7O2tCQUN0RCx3QkFBQyxRQUFEO1NBQU07U0FBUSxXQUFXLGNBQWMsS0FBSyxJQUFJO1NBQUU7UUFBMEM7Ozs7Z0JBQ3pGOzs7Ozs7T0FJUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZTtVQUNiLFVBQVUsUUFBUTtTQUNwQjtTQUNBLFdBQVcsK0dBQ1QsV0FBVyxXQUNQLDZEQUNBO21CQUVQO1FBRU87Ozs7a0JBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlO1VBQ2IsVUFBVSxTQUFTO1VBQ25CLG1CQUFtQixTQUFTO1VBQzVCLFVBQVUsU0FBUztVQUNuQixjQUFjLEVBQUU7VUFDaEIsaUJBQWlCLEVBQUU7VUFDbkIsaUJBQWlCLEVBQUU7U0FDckI7U0FDQSxXQUFXLCtHQUNULFdBQVcsWUFDUCx1REFDQTttQkFFUDtRQUVPOzs7O2dCQUNMOzs7Ozs7TUFDRjs7Ozs7O0tBTU4sYUFBYSxTQUFTLDJCQUNyQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsd0NBQXlDOzs7OztTQUM3RCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBeUM7U0FFbkQ7Ozs7O1NBQ0osd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQThCO1NBRXhDOzs7OztRQUNBOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLFFBQVEsc0JBQXNCO1NBQzdDLFdBQVU7bUJBRlo7VUFJRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZ0I7VUFBUTs7Ozs7VUFDeEMsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXNEO1VBQXlCOzs7OztVQUMvRix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBa0M7VUFBa0Q7Ozs7O1NBQzlGOzs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsZUFBZSxRQUFRLHdCQUF3QjtTQUMvQyxXQUFVO21CQUZaO1VBSUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWdCO1VBQU87Ozs7O1VBQ3ZDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFzRDtVQUF3Qjs7Ozs7VUFDOUYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWtDO1VBQTBDOzs7OztTQUN0Rjs7Ozs7Z0JBQ0w7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsU0FBUztTQUNULFdBQVU7bUJBSFosQ0FLRSx3QkFBQyxXQUFELEVBQVcsV0FBVSx5QkFBMEI7Ozs7bUJBQy9DLHdCQUFDLFFBQUQsWUFBTSw2REFBOEQ7Ozs7aUJBQzlEOzs7Ozs7T0FDTDs7Ozs7TUFDRjs7Ozs7O0tBR04sYUFBYSxTQUFTLDBCQUNyQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUseUJBQTBCOzs7O2tCQUNuRCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBbUM7UUFBMkM7Ozs7Z0JBQzNGOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBOEM7U0FFeEQ7Ozs7bUJBQ1Asd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLG1CQUFtQixFQUFFLE9BQU8sS0FBSztVQUNsRCxhQUFZO1VBQ1osV0FBVTtTQUNYOzs7O2lCQUNFOzs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUE4QztXQUV4RDs7Ozs7V0FDUCx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7WUFDN0MsYUFBWTtZQUNaLFdBQVU7V0FDWDs7Ozs7V0FDRCx3QkFBQyxZQUFEO1lBQVUsSUFBRztzQkFDVixZQUFZLEtBQUksUUFBTyx3QkFBQyxVQUFELEVBQWtCLE9BQU8sSUFBTSxHQUFsQjs7OzttQkFBa0IsQ0FBQztXQUNoRDs7Ozs7VUFDUDs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQThDO1dBRXhEOzs7OztXQUNQLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztZQUM1QyxhQUFZO1lBQ1osV0FBVTtXQUNYOzs7OztXQUNELHdCQUFDLFlBQUQ7WUFBVSxJQUFHO3NCQUNWLGFBQWEsS0FBSSxRQUFPLHdCQUFDLFVBQUQsRUFBa0IsT0FBTyxJQUFNLEdBQWxCOzs7O21CQUFrQixDQUFDO1dBQ2pEOzs7OztVQUNQOzs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBOEM7V0FFeEQ7Ozs7O1dBQ1Asd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxNQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7WUFDL0MsYUFBWTtZQUNaLFdBQVU7V0FDWDs7Ozs7V0FDRCx3QkFBQyxZQUFEO1lBQVUsSUFBRztzQkFDVixjQUFjLEtBQUksUUFBTyx3QkFBQyxVQUFELEVBQWtCLE9BQU8sSUFBTSxHQUFsQjs7OzttQkFBa0IsQ0FBQztXQUNsRDs7Ozs7VUFDUDs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQThDO1dBRXhEOzs7OztXQUNQLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztZQUM5QyxhQUFZO1lBQ1osV0FBVTtXQUNYOzs7OztXQUNELHdCQUFDLFlBQUQ7WUFBVSxJQUFHO3NCQUNWLGFBQWEsS0FBSSxRQUFPLHdCQUFDLFVBQUQsRUFBa0IsT0FBTyxJQUFNLEdBQWxCOzs7O21CQUFrQixDQUFDO1dBQ2pEOzs7OztVQUNQOzs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQThDO1NBRXhEOzs7O21CQUNQLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7VUFDaEQsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQThDO1NBRXhEOzs7O21CQUNQLHdCQUFDLFlBQUQ7VUFDRSxPQUFPO1VBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztVQUNoRCxhQUFZO1VBQ1osTUFBTTtVQUNOLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7UUFDRjs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFNBQVM7U0FDVCxXQUFVO21CQUhaLENBS0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsNkJBQThCOzs7O21CQUNuRCx3QkFBQyxRQUFELFlBQU0scUJBQXdCOzs7O2lCQUN4Qjs7Ozs7a0JBQ1Isd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxVQUFVLGFBQWEsQ0FBQyxXQUFXO1NBQ25DLFdBQVU7bUJBRVQsYUFBYSxDQUFDLFdBQVcsVUFBVSxnQ0FBZ0M7UUFDOUQ7Ozs7Z0JBQ0w7Ozs7OztNQUNGOzs7Ozs7S0FHTixhQUFhLFNBQVMsNEJBQ3JCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx3Q0FBeUM7Ozs7O1FBQ3hELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QztRQUVuRDs7Ozs7UUFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBOEI7UUFFeEM7Ozs7O09BQ0E7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLGVBQWUsUUFBUSxpQkFBaUI7UUFDeEMsV0FBVTtrQkFGWjtTQUlFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFROzs7OztTQUN4Qyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBbUM7U0FBa0M7Ozs7O1NBQ3JGLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFrQztTQUF5Qjs7Ozs7UUFDckU7Ozs7O2lCQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLFFBQVEsZ0JBQWdCO1FBQ3ZDLFdBQVU7a0JBRlo7U0FJRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBZ0I7U0FBUzs7Ozs7U0FDekMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW1DO1NBQW1DOzs7OztTQUN0Rix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBa0M7U0FBd0I7Ozs7O1FBQ3BFOzs7OztlQUNMOzs7OztjQUNGOzs7Ozs7S0FHTixhQUFhLFNBQVMscUJBQ3JCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx3Q0FBeUM7Ozs7O1FBQ2hFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QztRQUVuRDs7Ozs7UUFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBOEI7UUFFeEM7Ozs7O09BQ0E7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLGVBQWUsUUFBUSxvQkFBb0I7UUFDM0MsV0FBVTtrQkFGWjtTQUlFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFROzs7OztTQUN4Qyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBbUM7U0FBd0I7Ozs7O1NBQzNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFrQztTQUF1Qjs7Ozs7UUFDbkU7Ozs7O2lCQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLFFBQVEscUJBQXFCO1FBQzVDLFdBQVU7a0JBRlo7U0FJRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBZ0I7U0FBUTs7Ozs7U0FDeEMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW1DO1NBQW9COzs7OztTQUN2RSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBa0M7U0FBeUI7Ozs7O1FBQ3JFOzs7OztlQUNMOzs7OztjQUNGOzs7Ozs7S0FNTixDQUFDLGFBQWEsZUFBZSxvQkFBb0IsU0FBUyx3QkFBd0IsU0FBUyxhQUFhLFNBQVMsZUFDaEgsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLHdDQUF5Qzs7Ozs7UUFDeEQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXFDO1FBRS9DOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QjtRQUErRDs7Ozs7T0FDbEc7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlO1VBQ2IsVUFBVSwrQkFBK0I7VUFDekMsUUFBUSxnQ0FBZ0M7U0FDMUM7U0FDQSxXQUFVO21CQU5aO1VBUUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXFCO1VBQU87Ozs7O1VBQzVDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5QztVQUE2Qjs7Ozs7VUFDdEYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRCO1VBQWdDOzs7OztTQUN0RTs7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlO1VBQ2IsVUFBVSwwQkFBMEI7VUFDcEMsUUFBUSxnQ0FBZ0M7U0FDMUM7U0FDQSxXQUFVO21CQU5aO1VBUUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXFCO1VBQVE7Ozs7O1VBQzdDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5QztVQUE4Qjs7Ozs7VUFDdkYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRCO1VBQXlCOzs7OztTQUMvRDs7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlO1VBQ2IsVUFBVSw0QkFBNEI7VUFDdEMsUUFBUSxnQ0FBZ0M7U0FDMUM7U0FDQSxXQUFVO21CQU5aO1VBUUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXFCO1VBQVE7Ozs7O1VBQzdDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5QztVQUE2Qjs7Ozs7VUFDdEYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRCO1VBQTZCOzs7OztTQUNuRTs7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLFFBQVEsb0JBQW9CO1NBQzNDLFdBQVU7bUJBSFo7VUFLRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBcUI7VUFBUTs7Ozs7VUFDN0Msd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXlDO1VBQThCOzs7OztVQUN2Rix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEI7VUFBcUM7Ozs7O1NBQzNFOzs7Ozs7T0FDTDs7Ozs7Y0FDRjs7Ozs7O0tBR04sQ0FBQyxhQUFhLFNBQVMsb0NBQ3RCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7a0JBQ3pDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFtQztRQUE0Qzs7OztnQkFDNUY7Ozs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFzQztTQUF1Qjs7OzttQkFDOUUsd0JBQUMsVUFBRDtVQUNFLE9BQU87VUFDUCxXQUFXLE1BQU0sV0FBVyxFQUFFLE9BQU8sS0FBSztVQUMxQyxXQUFVO29CQUhaO1dBS0Usd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVU7V0FBZTs7Ozs7V0FDdkMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVE7V0FBYTs7Ozs7V0FDbkMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVU7V0FBZTs7Ozs7V0FDdkMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVU7V0FBZTs7Ozs7VUFDakM7Ozs7O2lCQUNMOzs7OztTQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBc0M7U0FBMkI7Ozs7bUJBQ2xGLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1VBQzVDLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O1NBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFzQztTQUFtQzs7OzttQkFDMUYsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7VUFDNUMsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7U0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQXNDO1NBQThCOzs7O21CQUNyRix3QkFBQyxVQUFEO1VBQ0UsT0FBTztVQUNQLFdBQVcsTUFBTSxjQUFjLEVBQUUsT0FBTyxLQUFLO1VBQzdDLFdBQVU7b0JBSFosQ0FLRSx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBSztVQUFVOzs7O29CQUM3Qix3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBSztVQUFVOzs7O2tCQUN2Qjs7Ozs7aUJBQ0w7Ozs7O1FBQ0Y7Ozs7OztPQUNMLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZSxvQkFBb0IsVUFBVSw2QkFBNkIsYUFBYTtRQUN2RixXQUFVO2tCQUNYO09BRU87Ozs7O01BQ0w7Ozs7OztLQU1OLENBQUMsYUFBYSxlQUFlLG9CQUFvQixTQUFTLHlCQUF5QixTQUFTLGlCQUMzRix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsd0NBQXlDOzs7OztRQUM3RCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBcUM7UUFFL0M7Ozs7O1FBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlCO1FBQXlFOzs7OztPQUM1Rzs7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWU7VUFDYixVQUFVLDRCQUE0QjtVQUN0QyxRQUFRLGdDQUFnQztTQUMxQztTQUNBLFdBQVU7bUJBTlo7VUFRRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBcUI7VUFBUTs7Ozs7VUFDN0Msd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXlDO1VBQTBCOzs7OztVQUNuRix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEI7VUFBcUI7Ozs7O1NBQzNEOzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWU7VUFDYixVQUFVLGdDQUFnQztVQUMxQyxRQUFRLGdDQUFnQztTQUMxQztTQUNBLFdBQVU7bUJBTlo7VUFRRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBcUI7VUFBUTs7Ozs7VUFDN0Msd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXlDO1VBQXlCOzs7OztVQUNsRix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEI7VUFBMkI7Ozs7O1NBQ2pFOzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWU7VUFDYixVQUFVLGlDQUFpQztVQUMzQyxRQUFRLGdDQUFnQztTQUMxQztTQUNBLFdBQVU7bUJBTlo7VUFRRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBcUI7VUFBUTs7Ozs7VUFDN0Msd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXlDO1VBQW9COzs7OztVQUM3RSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEI7VUFBNkI7Ozs7O1NBQ25FOzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsUUFBUSxvQkFBb0I7U0FDM0MsV0FBVTttQkFIWjtVQUtFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFxQjtVQUFROzs7OztVQUM3Qyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBeUM7VUFBOEI7Ozs7O1VBQ3ZGLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE0QjtVQUEyQjs7Ozs7U0FDakU7Ozs7OztPQUNMOzs7OztjQUNGOzs7Ozs7S0FHTixDQUFDLGFBQWEsU0FBUyxvQ0FDdEIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OztrQkFDOUMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW1DO1FBQWdEOzs7O2dCQUNoRzs7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQXNDO1NBQTRCOzs7O21CQUNuRix3QkFBQyxVQUFEO1VBQ0UsT0FBTztVQUNQLFdBQVcsTUFBTSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7VUFDcEQsV0FBVTtvQkFIWjtXQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFXO1dBQWlCOzs7OztXQUMxQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBVztXQUFpQjs7Ozs7V0FDMUMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVc7V0FBaUI7Ozs7O1VBQ3BDOzs7OztpQkFDTDs7Ozs7U0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQXNDO1NBQWdDOzs7O21CQUN2Rix3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU87VUFDUCxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztVQUM1QyxhQUFZO1VBQ1osV0FBVTtTQUNYOzs7O2lCQUNFOzs7OztTQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBc0M7U0FBNkI7Ozs7bUJBQ3BGLHdCQUFDLFVBQUQ7VUFDRSxPQUFPO1VBQ1AsV0FBVyxNQUFNLGdCQUFnQixFQUFFLE9BQU8sS0FBSztVQUMvQyxXQUFVO29CQUhaO1dBS0Usd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQXNCO1dBQTJCOzs7OztXQUMvRCx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBa0I7V0FBdUI7Ozs7O1dBQ3ZELHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUF3QjtXQUE2Qjs7Ozs7VUFDN0Q7Ozs7O2lCQUNMOzs7OztTQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBc0M7U0FBb0M7Ozs7bUJBQzNGLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTztVQUNQLFdBQVcsTUFBTSx5QkFBeUIsRUFBRSxPQUFPLEtBQUs7VUFDeEQsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7UUFDRjs7Ozs7O09BQ0wsd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLG9CQUFvQixVQUFVLHdCQUF3QixTQUFTO1FBQzlFLFdBQVU7a0JBQ1g7T0FFTzs7Ozs7TUFDTDs7Ozs7O0tBTU4sQ0FBQyxhQUFhLGVBQWUsZ0JBQWdCLFNBQVMsMEJBQTBCLFNBQVMsOEJBQ3hGLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0csU0FBUywwQkFDUixnREFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHdDQUF5Qzs7Ozs7UUFDMUQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXFDO1FBRS9DOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QjtRQUFrRDs7Ozs7T0FDckY7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlO1VBQ2IsVUFBVSxnQ0FBZ0M7VUFDMUMsUUFBUSx5QkFBeUI7U0FDbkM7U0FDQSxXQUFVO21CQU5aO1VBUUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXFCO1VBQVE7Ozs7O1VBQzdDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5QztVQUF1Qjs7Ozs7VUFDaEYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRCO1VBQTRCOzs7OztTQUNsRTs7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlO1VBQ2IsVUFBVSw0QkFBNEI7VUFDdEMsUUFBUSx5QkFBeUI7U0FDbkM7U0FDQSxXQUFVO21CQU5aO1VBUUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXFCO1VBQVE7Ozs7O1VBQzdDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5QztVQUFnQzs7Ozs7VUFDekYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRCO1VBQXdCOzs7OztTQUM5RDs7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlO1VBQ2IsVUFBVSx1QkFBdUI7VUFDakMsUUFBUSx5QkFBeUI7U0FDbkM7U0FDQSxXQUFVO21CQU5aO1VBUUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXFCO1VBQU87Ozs7O1VBQzVDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5QztVQUF3Qjs7Ozs7VUFDakYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRCO1VBQTBCOzs7OztTQUNoRTs7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLFFBQVEsb0JBQW9CO1NBQzNDLFdBQVU7bUJBSFo7VUFLRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBcUI7VUFBUTs7Ozs7VUFDN0Msd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXlDO1VBQThCOzs7OztVQUN2Rix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEI7VUFBMkI7Ozs7O1NBQ2pFOzs7Ozs7T0FDTDs7Ozs7Y0FDTDs7OztnQkFHSCxTQUFTLDZCQUNSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSx5QkFBMEI7Ozs7bUJBQzNDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFtQztTQUF5Qzs7OztpQkFDekY7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFzQztVQUFrQzs7OztvQkFDekYsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPO1dBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7V0FDN0MsYUFBWTtXQUNaLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7VUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQXNDO1VBQW1DOzs7O29CQUMxRix3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU87V0FDUCxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztXQUM1QyxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztVQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBc0M7VUFBOEI7Ozs7b0JBQ3JGLHdCQUFDLFVBQUQ7V0FDRSxPQUFPO1dBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztXQUNoRCxXQUFVO3FCQUhaO1lBS0Usd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQXNCO1lBQTJCOzs7OztZQUMvRCx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBb0I7WUFBeUI7Ozs7O1lBQzNELHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUF1QjtZQUE0Qjs7Ozs7V0FDM0Q7Ozs7O2tCQUNMOzs7OztVQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBc0M7VUFBaUM7Ozs7b0JBQ3hGLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTztXQUNQLFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7V0FDaEQsYUFBWTtXQUNaLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7U0FDRjs7Ozs7O1FBQ0wsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLG9CQUFvQixVQUFVLDRCQUE0QixXQUFXO1NBQ3BGLFdBQVU7bUJBQ1g7UUFFTzs7Ozs7T0FDTDs7Ozs7Y0FFSjs7Ozs7O0tBTU4sQ0FBQyxhQUFhLGVBQWUsY0FDNUIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7UUFDSSxTQUFTLDBCQUEwQixTQUFTLDBCQUEwQixTQUFTLDJCQUMvRSxnREFDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHdDQUF5Qzs7Ozs7U0FDaEUsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXFDO1NBRS9DOzs7OztTQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF5QjtTQUE4RDs7Ozs7UUFDakc7Ozs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxlQUFlO1dBQ2IsVUFBVSwwQkFBMEI7V0FDcEMsUUFBUSx5QkFBeUI7VUFDbkM7VUFDQSxXQUFVO29CQU5aO1dBUUUsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXFCO1dBQU87Ozs7O1dBQzVDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUF5QztXQUEyQjs7Ozs7V0FDcEYsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTRCO1dBQWlDOzs7OztVQUN2RTs7Ozs7O1NBQ1Isd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxlQUFlO1dBQ2IsVUFBVSwrQkFBK0I7V0FDekMsUUFBUSx5QkFBeUI7VUFDbkM7VUFDQSxXQUFVO29CQU5aO1dBUUUsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXFCO1dBQVE7Ozs7O1dBQzdDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUF5QztXQUEyQjs7Ozs7V0FDcEYsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTRCO1dBQXNCOzs7OztVQUM1RDs7Ozs7O1NBQ1Isd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxlQUFlO1dBQ2IsVUFBVSw2QkFBNkI7V0FDdkMsUUFBUSxnQ0FBZ0M7VUFDMUM7VUFDQSxXQUFVO29CQU5aO1dBUUUsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXFCO1dBQVE7Ozs7O1dBQzdDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUF5QztXQUFxQjs7Ozs7V0FDOUUsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTRCO1dBQTZCOzs7OztVQUNuRTs7Ozs7O1NBQ1Isd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxlQUFlLFFBQVEsb0JBQW9CO1VBQzNDLFdBQVU7b0JBSFo7V0FLRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBcUI7V0FBUTs7Ozs7V0FDN0Msd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXlDO1dBQThCOzs7OztXQUN2Rix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNEI7V0FBMkI7Ozs7O1VBQ2pFOzs7Ozs7UUFDTDs7Ozs7ZUFDTDs7Ozs7T0FHSCxTQUFTLDZCQUNSLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx5QkFBMEI7Ozs7b0JBQ2pELHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFtQztVQUE4Qjs7OztrQkFDOUU7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFzQztVQUE2Qjs7OztvQkFDcEYsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPO1dBQ1AsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7V0FDNUMsYUFBWTtXQUNaLFdBQVU7VUFDWDs7OztrQkFDRTs7OztvQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQXNDO1VBQXlCOzs7O29CQUNoRix3QkFBQyxVQUFEO1dBQ0UsT0FBTztXQUNQLFdBQVcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7V0FDakQsV0FBVTtxQkFIWjtZQUtFLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUF5QjtZQUE4Qjs7Ozs7WUFDckUsd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQXdCO1lBQTZCOzs7OztZQUNuRSx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBZTtZQUFvQjs7Ozs7V0FDM0M7Ozs7O2tCQUNMOzs7O2tCQUNGOzs7Ozs7U0FDTCx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLGVBQWUsb0JBQW9CLFVBQVUsY0FBYyxVQUFVO1VBQ3JFLFdBQVU7b0JBQ1g7U0FFTzs7Ozs7UUFDTDs7Ozs7O09BR04sU0FBUyxvQ0FDUix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUseUJBQTBCOzs7O29CQUNqRCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBbUM7VUFBdUM7Ozs7a0JBQ3ZGOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBc0M7VUFBNEI7Ozs7b0JBQ25GLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTztXQUNQLFdBQVcsTUFBTSxjQUFjLEVBQUUsT0FBTyxLQUFLO1dBQzdDLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7b0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFzQztVQUErQjs7OztvQkFDdEYsd0JBQUMsVUFBRDtXQUNFLE9BQU87V0FDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztXQUM3QyxXQUFVO3FCQUhaO1lBS0Usd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQXVCO1lBQTRCOzs7OztZQUNqRSx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBaUI7WUFBc0I7Ozs7O1lBQ3JELHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFZO1lBQWlCOzs7OztXQUNyQzs7Ozs7a0JBQ0w7Ozs7a0JBQ0Y7Ozs7OztTQUNMLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxvQkFBb0IsVUFBVSx1QkFBdUIsU0FBUztVQUM3RSxXQUFVO29CQUNYO1NBRU87Ozs7O1FBQ0w7Ozs7OztNQUVKOzs7Ozs7S0FNTixDQUFDLGFBQWEsZUFBZSxVQUFVLFNBQVMsd0JBQXdCLFNBQVMsNEJBQ2hGLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0csU0FBUyx3QkFDUixnREFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHdDQUF5Qzs7Ozs7UUFDM0Qsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXFDO1FBRS9DOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QjtRQUFrRDs7Ozs7T0FDckY7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlO1VBQ2IsVUFBVSxnQ0FBZ0M7VUFDMUMsUUFBUSx1QkFBdUI7U0FDakM7U0FDQSxXQUFVO21CQU5aO1VBUUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXFCO1VBQVE7Ozs7O1VBQzdDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5QztVQUFtQjs7Ozs7VUFDNUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRCO1VBQThCOzs7OztTQUNwRTs7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlO1VBQ2IsVUFBVSxtQkFBbUI7VUFDN0IsUUFBUSx1QkFBdUI7U0FDakM7U0FDQSxXQUFVO21CQU5aO1VBUUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXFCO1VBQVE7Ozs7O1VBQzdDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF5QztVQUFlOzs7OztVQUN4RSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEI7VUFBc0I7Ozs7O1NBQzVEOzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWU7VUFDYixVQUFVLHlCQUF5QjtVQUNuQyxRQUFRLHVCQUF1QjtTQUNqQztTQUNBLFdBQVU7bUJBTlo7VUFRRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBcUI7VUFBUTs7Ozs7VUFDN0Msd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXlDO1VBQTZCOzs7OztVQUN0Rix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEI7VUFBa0I7Ozs7O1NBQ3hEOzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWU7VUFDYixVQUFVLHNCQUFzQjtVQUNoQyxRQUFRLHVCQUF1QjtTQUNqQztTQUNBLFdBQVU7bUJBTlo7VUFRRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBcUI7VUFBUTs7Ozs7VUFDN0Msd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXlDO1VBQXNCOzs7OztVQUMvRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEI7VUFBc0I7Ozs7O1NBQzVEOzs7Ozs7T0FDTDs7Ozs7Y0FDTDs7OztnQkFHSCxTQUFTLDJCQUNSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx5QkFBMEI7Ozs7bUJBQzVDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFtQztTQUFpQzs7OztpQkFDakY7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFzQztVQUE4Qjs7OztvQkFDckYsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPO1dBQ1AsV0FBVyxNQUFNLFVBQVUsRUFBRSxPQUFPLEtBQUs7V0FDekMsYUFBWTtXQUNaLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBc0M7V0FBMEI7Ozs7cUJBQ2pGLHdCQUFDLFVBQUQ7WUFDRSxPQUFPO1lBQ1AsV0FBVyxNQUFNLG1CQUFtQixFQUFFLE9BQU8sS0FBSztZQUNsRCxXQUFVO3NCQUhaO2FBS0Usd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQWdCO2FBQXFCOzs7OzthQUNuRCx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBcUI7YUFBMEI7Ozs7O2FBQzdELHdCQUFDLFVBQUQ7Y0FBUSxPQUFNO3dCQUErQjthQUFvQzs7Ozs7YUFDakYsd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQWtDO2FBQXVDOzs7OztZQUNqRjs7Ozs7bUJBQ0w7Ozs7cUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUFzQztXQUE2Qjs7OztxQkFDcEYsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLFFBQVEsRUFBRSxPQUFPLEtBQUs7WUFDdkMsYUFBWTtZQUNaLFdBQVU7V0FDWDs7OzttQkFDRTs7OzttQkFDRjs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQXNDO1dBQStCOzs7O3FCQUN0Rix3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztZQUM3QyxhQUFZO1lBQ1osV0FBVTtXQUNYOzs7O21CQUNFOzs7O3FCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBc0M7V0FBMEI7Ozs7cUJBQ2pGLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO1lBQzNDLGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7bUJBQ0U7Ozs7bUJBQ0Y7Ozs7OztTQUNGOzs7Ozs7UUFDTCx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsb0JBQW9CLFVBQVUsZ0JBQWdCLGFBQWE7VUFBRTtVQUFpQjtVQUFNO1VBQVk7U0FBUyxDQUFDO1NBQ3pILFdBQVU7bUJBQ1g7UUFFTzs7Ozs7T0FDTDs7Ozs7Y0FFSjs7Ozs7O0tBTU4sQ0FBQyxhQUFhLGVBQWUscUJBQXFCLFNBQVMsOEJBQThCLFNBQVMsMEJBQ2pHLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSx5QkFBMEI7Ozs7a0JBQzNDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFtQztRQUFvQzs7OztnQkFDcEY7Ozs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFzQztRQUErQjs7OztrQkFDdEYsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7U0FDN0MsYUFBWTtTQUNaLFdBQVU7UUFDWDs7OztnQkFDRTs7OztrQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQXNDO1FBQTZCOzs7O2tCQUNwRix3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU87U0FDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztTQUM3QyxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2dCQUNGOzs7Ozs7T0FDTCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsb0JBQW9CLHFDQUFxQyxrQkFBa0I7U0FBRTtTQUFZO1FBQVcsQ0FBQztRQUNwSCxXQUFVO2tCQUNYO09BRU87Ozs7O01BQ0w7Ozs7OztLQU1OLENBQUMsYUFBYSxlQUFlLG1CQUM1Qix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUseUJBQTBCOzs7O2tCQUNqRCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBbUM7UUFBeUM7Ozs7Z0JBQ3pGOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBc0M7UUFBMEI7Ozs7a0JBQ2pGLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1NBQzVDLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFzQztRQUE2Qjs7OztrQkFDcEYsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVyxNQUFNLG1CQUFtQixFQUFFLE9BQU8sS0FBSztTQUNsRCxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2dCQUNGOzs7Ozs7T0FDTCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsb0JBQW9CLHlCQUF5QixpQkFBaUIsRUFBRSxnQkFBZ0IsQ0FBQztRQUNoRyxXQUFVO2tCQUNYO09BRU87Ozs7O01BQ0w7Ozs7OztLQU1OLFNBQVMsd0JBQ1Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRywrQkFBK0I7T0FFaEMsd0JBQUMsT0FBRDtRQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUNkLGdCQUFnQix3Q0FBd0M7UUFDcEQ7Ozs7O1FBQ04saUJBQ0Msd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWdEO1FBRTFEOzs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNO1dBQ2YsZUFBZSxFQUFFLE9BQU8sS0FBSztXQUM3QixJQUFJLENBQUMsZUFBZSxnQkFBZ0IsSUFBSTtVQUMxQztVQUNBLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7bUJBQ0Qsd0JBQUMsUUFBRCxFQUFRLFdBQVUsaURBQWtEOzs7O2lCQUNqRTs7Ozs7O09BQ0Y7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osaUJBQWlCLFNBQVMsSUFDekIsaUJBQWlCLEtBQUssT0FBTztTQUMzQixNQUFNLGFBQWEsZ0JBQ2YsY0FBYyxNQUFLLFNBQVEsS0FBSyxPQUFPLEdBQUcsRUFBRSxJQUM1QyxjQUFjLE9BQU8sR0FBRyxNQUFNLDhCQUE4QixHQUFHO1NBRW5FLE9BQ0Usd0JBQUMsVUFBRDtVQUVFLE1BQUs7VUFDTCxlQUFlO1dBQ2IsSUFBSSxlQUFlO1lBQ2pCLElBQUksY0FBYyxNQUFLLFNBQVEsS0FBSyxPQUFPLEdBQUcsRUFBRSxHQUFHO2FBQ2pELGlCQUFpQixjQUFjLFFBQU8sU0FBUSxLQUFLLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDbEUsT0FBTzthQUNMLGlCQUFpQixDQUFDLEdBQUcsZUFBZSxFQUFFLENBQUM7WUFDekM7V0FDRixPQUFPO1lBQ0wsZ0JBQWdCLEVBQUU7WUFDbEIsNkJBQTZCLEdBQUcsRUFBRTtZQUNsQywrQkFBK0IsR0FBRyxRQUFRLEdBQUcsZ0JBQWdCLFNBQVM7WUFDdEUsZUFBZSxHQUFHLE1BQU07V0FDMUI7VUFDRjtVQUNBLFdBQVcsOEhBQ1QsYUFBYSwwQ0FBMEM7b0JBbEIzRCxDQXFCRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNHLGlCQUNDLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsU0FBUztZQUNULGdCQUFnQixDQUFDO1lBQ2pCLFdBQVU7V0FDWDs7OztxQkFFSCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQWdDLEdBQUc7V0FBVTs7OztxQkFDMUQsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQWI7YUFBb0Q7YUFBSyxHQUFHO2FBQUc7YUFBRSxHQUFHLE9BQU8sTUFBTSxHQUFHLEtBQUssS0FBSztZQUFNOzs7OzttQkFDakc7Ozs7bUJBQ0Y7Ozs7O29CQUNKLGNBQWMsd0JBQUMsT0FBRCxFQUFPLFdBQVUseUJBQTBCOzs7O2tCQUNwRDtZQW5DRCxHQUFHOzs7O2dCQW1DRjtRQUVaLENBQUMsSUFFRCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBeUM7UUFFbkQ7Ozs7O09BRUo7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsVUFBRDtTQUNFLGVBQWUsa0JBQWtCO1NBQ2pDLFdBQVcsZ0JBQWdCLGNBQWMsV0FBVyxJQUFLLENBQUMsZ0JBQWdCLENBQUMsOEJBQWdDLGFBQWEsQ0FBQyxXQUFXO1NBQ3BJLFdBQVU7bUJBRVQsYUFBYSxDQUFDLFdBQVcsVUFDdEIsNkNBQ0EsZ0JBQ0EsWUFBWSxjQUFjLE9BQU8sV0FBVyxjQUFjLFdBQVcsSUFBSSxLQUFLLElBQUksY0FDbEY7UUFDRTs7Ozs7T0FDTDs7Ozs7TUFDRjs7Ozs7O0tBTU4sU0FBUyx5QkFDUix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFlBQUQsRUFBWSxXQUFVLDJCQUE0Qjs7Ozs7T0FDL0M7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFxQztPQUUvQzs7OztpQkFDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBbUQ7T0FFN0Q7Ozs7ZUFDQTs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFVBQVUsYUFBYSxDQUFDLFdBQVc7U0FDbkMsV0FBVTttQkFFVCxhQUFhLENBQUMsV0FBVyxVQUFVLGdDQUFnQztRQUM5RDs7Ozs7T0FDTDs7Ozs7TUFDRjs7Ozs7O0tBTU4sYUFBYSxTQUFTLG9CQUNyQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUVHLCtCQUErQjtPQUVoQyx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQThDO09BRXhEOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxVQUFVLEVBQUUsT0FBTyxLQUFLO1FBQ3pDLGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQThDO09BRXhEOzs7O2lCQUNQLHdCQUFDLFVBQUQ7UUFDRSxPQUFPO1FBQ1AsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7UUFDNUMsV0FBVTtrQkFFVCxhQUFhLEtBQUksUUFBTyx3QkFBQyxVQUFEO1NBQWtCLE9BQU87bUJBQU07UUFBWSxHQUE5Qjs7OztlQUE4QixDQUFDO09BQy9EOzs7O2VBQ0w7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE4QztPQUV4RDs7OztpQkFDUCx3QkFBQyxtQkFBRDtRQUNFLE9BQU87UUFDUCxXQUFXLFFBQVEsV0FBVyxHQUFHO1FBQ2pDLE9BQU07T0FDUDs7OztlQUNFOzs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsVUFBVSxhQUFhLENBQUMsV0FBVztTQUNuQyxXQUFVO21CQUVULGFBQWEsQ0FBQyxXQUFXLFVBQVUsNkNBQTZDO1FBQzNFOzs7OztPQUNMOzs7OztNQUNGOzs7Ozs7SUFHSjs7Ozs7V0FDRjs7Ozs7VUFDRjs7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJNb2RhbEVkaWNpb25DaXJjdWl0by5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgWCwgXG4gIEFycm93TGVmdCwgXG4gIENhbWVyYSwgXG4gIENoZWNrLCBcbiAgU2VhcmNoLCBcbiAgUGx1c0NpcmNsZSwgXG4gIEFsZXJ0Q2lyY2xlLCBcbiAgU2V0dGluZ3MsIFxuICBDbGlwYm9hcmRMaXN0LCBcbiAgQ3B1LCBcbiAgWmFwLCBcbiAgQWN0aXZpdHksIFxuICBTaGllbGRDaGVjaywgXG4gIExheWVycywgXG4gIEJ1aWxkaW5nMiwgXG4gIEdhdWdlLCBcbiAgUmFkaW8sXG4gIFJvdGF0ZUNjd1xufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgQU1QX09QVElPTlMsIENPTkRfT1BUSU9OUywgTUFSQ0FfT1BUSU9OUywgVElQT19PUFRJT05TIH0gZnJvbSAnLi4vdXRpbHMvY29uc3RhbnRzJztcbmltcG9ydCB7IHZhbGlkYXRlUG9sZU9jY3VwYW5jeSwgZ2V0UmVxdWlyZWRQb2xlcyB9IGZyb20gJy4uL3V0aWxzL3BvbGVWYWxpZGF0aW9uJztcbmltcG9ydCB7IHVzZUNvbmZpcm0gfSBmcm9tICcuLi9jb250ZXh0L0NvbmZpcm1Db250ZXh0JztcbmltcG9ydCBEdWFsUGhvdG9VcGxvYWRlciBmcm9tICcuL0R1YWxQaG90b1VwbG9hZGVyJztcbmltcG9ydCB1c2VTdG9yZSBmcm9tICcuLi9zdG9yZS91c2VTdG9yZSc7XG5cbmNvbnN0IG5vcm1hbGl6ZVRleHQgPSAoc3RyKSA9PiB7XG4gIGlmICh0eXBlb2Ygc3RyICE9PSAnc3RyaW5nJyB8fCAhc3RyKSByZXR1cm4gc3RyIHx8ICcnO1xuICByZXR1cm4gc3RyLnRyaW0oKS5yZXBsYWNlKC9cXHMrL2csICcgJykudG9VcHBlckNhc2UoKTtcbn07XG5cbmNvbnN0IE1PQ0tfRUxFTUVOVE9TX0NSRUFET1MgPSBbXG4gIHsgaWQ6ICdUQUItMScsIG5vbWJyZTogJ1RBQkxFUk8gUFJJTkNJUEFMIERFIEJBSkEgVEVOU0nDk04nLCB0aXBvOiAnVEFCTEVSTycgfSxcbiAgeyBpZDogJ1NVQi0xJywgbm9tYnJlOiAnU1VCRVNUQUNJw5NOIFBSSU5DSVBBTCAxMy44S1YnLCB0aXBvOiAnU1VCRVNUQUNJT04nIH0sXG4gIHsgaWQ6ICdBVFMtMScsIG5vbWJyZTogJ1RSQU5TRkVSRU5DSUEgQVVUT03DgVRJQ0EgU8OTVEFOTycsIHRpcG86ICdUUkFOU0ZFUicgfSxcbiAgeyBpZDogJ0NDTS0xJywgbm9tYnJlOiAnQ0NNIEJPTUJBUyBERSBBR1VBJywgdGlwbzogJ0NDTScgfVxuXTtcblxuZXhwb3J0IGNvbnN0IE1vZGFsRWRpY2lvbkNpcmN1aXRvID0gKHtcbiAgaXNPcGVuLFxuICBvbkNsb3NlLFxuICBjaXJjdWl0RGF0YSxcbiAgb25TYXZlLFxuICBlbGVtZW50b3NDcmVhZG9zID0gTU9DS19FTEVNRU5UT1NfQ1JFQURPUyxcbiAgdGFibGVyb0NpcmN1aXRzID0gW10sXG4gIG1heFBvbG9zID0gNDIsXG4gIG9uQWdyZWdhclBvckNyZWFyLFxuICB0aXBvT3JpZ2VuID0gJ1RBQkxFUk8nLFxuICBtb2RvID0gJ1NBTElEQSdcbn0pID0+IHtcbiAgY29uc3QgeyBhbGVydDogY3VzdG9tQWxlcnQgfSA9IHVzZUNvbmZpcm0oKTtcbiAgY29uc3QgeyByZWdpc3RyYXJDb25mbGljdG9DaXJjdWl0bywgc2hvd1RvYXN0LCBzZXRQYW5lbENvbmZsaWN0b3NPcGVuIH0gPSB1c2VTdG9yZSgpO1xuICBjb25zdCBpc1RhYmxlcm8gPSAhdGlwb09yaWdlbiB8fCB0aXBvT3JpZ2VuID09PSAnVEFCTEVSTyc7XG5cbiAgY29uc3QgW3N0ZXAsIHNldFN0ZXBdID0gdXNlU3RhdGUoJ1BSRUdVTlRBX0VTX0FSVEVGQUNUTycpO1xuXG4gIC8vIENhbXBvcyBUYWJsZXJvIC8gQXJ0ZWZhY3RvXG4gIGNvbnN0IFticmVha2VyQW1wLCBzZXRCcmVha2VyQW1wXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2JyZWFrZXJNYXJjYSwgc2V0QnJlYWtlck1hcmNhXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2JyZWFrZXJUaXBvLCBzZXRCcmVha2VyVGlwb10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjb25kdWN0b3IsIHNldENvbmR1Y3Rvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtub21icmVBcnRlZmFjdG8sIHNldE5vbWJyZUFydGVmYWN0b10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtkZXNjQXJ0ZWZhY3RvLCBzZXREZXNjQXJ0ZWZhY3RvXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3BvdGVuY2lhV2F0dHMsIHNldFBvdGVuY2lhV2F0dHNdID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIFBhcsOhbWV0cm9zIEbDrXNpY29zIFRhYmxlcm9cbiAgY29uc3QgW251bVBvbG9zLCBzZXROdW1Qb2xvc10gPSB1c2VTdGF0ZSgxKTtcbiAgY29uc3QgW3Bvc2ljaW9uUG9sbywgc2V0UG9zaWNpb25Qb2xvXSA9IHVzZVN0YXRlKDEpO1xuICBjb25zdCBbZXN0YWRvLCBzZXRFc3RhZG9dID0gdXNlU3RhdGUoJ0FDVElWTycpO1xuXG4gIC8vIELDunNxdWVkYSB5IHZpbmN1bGFjacOzblxuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3NlbGVjdGVkTGluaywgc2V0U2VsZWN0ZWRMaW5rXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbc2VsZWN0ZWRMaW5rcywgc2V0U2VsZWN0ZWRMaW5rc10gPSB1c2VTdGF0ZShbXSk7XG4gIGNvbnN0IFtzZWxlY3RlZEVsZW1lbnRvRGVzdGlub0lkLCBzZXRTZWxlY3RlZEVsZW1lbnRvRGVzdGlub0lkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3NlbGVjdGVkVGlwb0VsZW1lbnRvRGVzdGlubywgc2V0U2VsZWN0ZWRUaXBvRWxlbWVudG9EZXN0aW5vXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3NlbGVjdG9yVmFsdWUsIHNldFNlbGVjdG9yVmFsdWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbaXNDcmVhdGluZ05ld1Byb3Zpc2lvbmFsLCBzZXRJc0NyZWF0aW5nTmV3UHJvdmlzaW9uYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbcHJvdmlzaW9uYWxDdXN0b21OYW1lLCBzZXRQcm92aXNpb25hbEN1c3RvbU5hbWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcHJvdmlzaW9uYWxUaXBvLCBzZXRQcm92aXNpb25hbFRpcG9dID0gdXNlU3RhdGUoJ1RBQkxFUk8nKTtcblxuICBjb25zdCBpc011bHRpU2VsZWN0ID0gdGlwb09yaWdlbiA9PT0gJ1RSQU5TRk9STUFET1InICYmIChtb2RvID09PSAnU0VDVU5EQVJJQScgfHwgbW9kbyA9PT0gJ1NBTElEQScpO1xuXG4gIC8vIFLDs3R1bG8geSBmb3RvXG4gIGNvbnN0IFtyb3R1bG8sIHNldFJvdHVsb10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtmb3RvVXJsLCBzZXRGb3RvVXJsXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIC8vIEFncnVwYWNpw7NuIHVuaXZlcnNhbCBkZSBlbGVtZW50b3MgY3JlYWRvc1xuICBjb25zdCBncm91cGVkRWxlbWVudHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBncm91cHMgPSB7XG4gICAgICBUQUJMRVJPOiBbXSxcbiAgICAgIFRSQU5TRkVSOiBbXSxcbiAgICAgIENDTTogW10sXG4gICAgICBHRU5FUkFET1I6IFtdLFxuICAgICAgU1VCRVNUQUNJT046IFtdLFxuICAgICAgVFJBTlNGT1JNQURPUjogW10sXG4gICAgICBQVU5UT19NRURJQ0lPTjogW10sXG4gICAgICBPVFJPUzogW11cbiAgICB9O1xuICAgIChlbGVtZW50b3NDcmVhZG9zIHx8IFtdKS5mb3JFYWNoKGVsID0+IHtcbiAgICAgIGNvbnN0IHR5cGUgPSAoZWwudGlwbyB8fCBlbC50aXBvRWxlbWVudG8gfHwgJycpLnRvVXBwZXJDYXNlKCk7XG4gICAgICBpZiAodHlwZS5pbmNsdWRlcygnVFJBTlNGRVInKSB8fCB0eXBlLmluY2x1ZGVzKCdBVFMnKSB8fCB0eXBlLmluY2x1ZGVzKCdNVFMnKSkge1xuICAgICAgICBncm91cHMuVFJBTlNGRVIucHVzaChlbCk7XG4gICAgICB9IGVsc2UgaWYgKHR5cGUuaW5jbHVkZXMoJ0dFTkVSQURPUicpIHx8IHR5cGUuaW5jbHVkZXMoJ0dFTicpIHx8IHR5cGUuaW5jbHVkZXMoJ1BMQU5UQScpKSB7XG4gICAgICAgIGdyb3Vwcy5HRU5FUkFET1IucHVzaChlbCk7XG4gICAgICB9IGVsc2UgaWYgKHR5cGUuaW5jbHVkZXMoJ0NDTScpIHx8IHR5cGUuaW5jbHVkZXMoJ01PVE9SJykpIHtcbiAgICAgICAgZ3JvdXBzLkNDTS5wdXNoKGVsKTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZS5pbmNsdWRlcygnU1VCRVNUQUNJT04nKSB8fCB0eXBlLmluY2x1ZGVzKCdTRScpKSB7XG4gICAgICAgIGdyb3Vwcy5TVUJFU1RBQ0lPTi5wdXNoKGVsKTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZS5pbmNsdWRlcygnVFJBTlNGTycpIHx8IHR5cGUuaW5jbHVkZXMoJ1RSQUZPJykpIHtcbiAgICAgICAgZ3JvdXBzLlRSQU5TRk9STUFET1IucHVzaChlbCk7XG4gICAgICB9IGVsc2UgaWYgKHR5cGUuaW5jbHVkZXMoJ01FRElDSU9OJykgfHwgdHlwZS5pbmNsdWRlcygnTUVESURBJykgfHwgdHlwZS5pbmNsdWRlcygnUFVOVE8nKSkge1xuICAgICAgICBncm91cHMuUFVOVE9fTUVESUNJT04ucHVzaChlbCk7XG4gICAgICB9IGVsc2UgaWYgKHR5cGUuaW5jbHVkZXMoJ1RBQkxFUk8nKSB8fCB0eXBlID09PSAnU1VCX1RBQkxFUk8nIHx8IHR5cGUgPT09ICdQQU5FTCcpIHtcbiAgICAgICAgZ3JvdXBzLlRBQkxFUk8ucHVzaChlbCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBncm91cHMuT1RST1MucHVzaChlbCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGdyb3VwcztcbiAgfSwgW2VsZW1lbnRvc0NyZWFkb3NdKTtcblxuICAvLyBNYW5lamFyIGNhbWJpbyBlbiBlbCBzZWxlY3RvciB1bml2ZXJzYWwgY29uIGF1dG9jb21wbGV0YWRvIGVkaXRhYmxlXG4gIGNvbnN0IGhhbmRsZVVuaXZlcnNhbEVsZW1lbnRDaGFuZ2UgPSAoZSkgPT4ge1xuICAgIGNvbnN0IHZhbCA9IGUudGFyZ2V0LnZhbHVlO1xuICAgIHNldFNlbGVjdG9yVmFsdWUodmFsKTtcblxuICAgIGlmICghdmFsIHx8IHZhbCA9PT0gJ0RJUkVDVE8nIHx8IHZhbCA9PT0gJ05JTkdVTk8nKSB7XG4gICAgICBzZXRTZWxlY3RlZEVsZW1lbnRvRGVzdGlub0lkKCcnKTtcbiAgICAgIHNldFNlbGVjdGVkVGlwb0VsZW1lbnRvRGVzdGlubygnJyk7XG4gICAgICBzZXRTZWxlY3RlZExpbmsobnVsbCk7XG4gICAgICBzZXRJc0NyZWF0aW5nTmV3UHJvdmlzaW9uYWwoZmFsc2UpO1xuICAgICAgc2V0UHJvdmlzaW9uYWxDdXN0b21OYW1lKCcnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAodmFsLnN0YXJ0c1dpdGgoJ05FV18nKSkge1xuICAgICAgc2V0SXNDcmVhdGluZ05ld1Byb3Zpc2lvbmFsKHRydWUpO1xuICAgICAgc2V0U2VsZWN0ZWRMaW5rKG51bGwpO1xuICAgICAgc2V0U2VsZWN0ZWRFbGVtZW50b0Rlc3Rpbm9JZCgnJyk7XG5cbiAgICAgIGNvbnN0IHJlcXVpcmVkTGlzdCA9IHZhbGlkYXRpb24/LnJlcXVpcmVkUG9sZXMgfHwgZ2V0UG9sZXNBcnJheShwb3NpY2lvblBvbG8sIG51bVBvbG9zKTtcbiAgICAgIGNvbnN0IHBvbGVzU3RyID0gcmVxdWlyZWRMaXN0LmpvaW4oJywgJyk7XG4gICAgICBsZXQgbWFwcGVkVHlwZSA9ICdUQUJMRVJPJztcbiAgICAgIGxldCB0eXBlTGFiZWwgPSAnU3ViLVRhYmxlcm8nO1xuXG4gICAgICBpZiAodmFsID09PSAnTkVXX1RSQU5TRkVSJykge1xuICAgICAgICBtYXBwZWRUeXBlID0gJ1RSQU5TRkVSJztcbiAgICAgICAgdHlwZUxhYmVsID0gJ1RyYW5zZmVyZW5jaWEgQXV0b23DoXRpY2EgKEFUUyknO1xuICAgICAgfSBlbHNlIGlmICh2YWwgPT09ICdORVdfQ0NNJykge1xuICAgICAgICBtYXBwZWRUeXBlID0gJ0NDTSc7XG4gICAgICAgIHR5cGVMYWJlbCA9ICdDZW50cm8gZGUgQ29udHJvbCBkZSBNb3RvcmVzIChDQ00pJztcbiAgICAgIH0gZWxzZSBpZiAodmFsID09PSAnTkVXX0dFTkVSQURPUicpIHtcbiAgICAgICAgbWFwcGVkVHlwZSA9ICdHRU5FUkFET1InO1xuICAgICAgICB0eXBlTGFiZWwgPSAnR2VuZXJhZG9yIC8gUGxhbnRhIGRlIEVtZXJnZW5jaWEnO1xuICAgICAgfSBlbHNlIGlmICh2YWwgPT09ICdORVdfVFJBTlNGT1JNQURPUicpIHtcbiAgICAgICAgbWFwcGVkVHlwZSA9ICdUUkFOU0ZPUk1BRE9SJztcbiAgICAgICAgdHlwZUxhYmVsID0gJ1RyYW5zZm9ybWFkb3IgZGUgUG90ZW5jaWEnO1xuICAgICAgfSBlbHNlIGlmICh2YWwgPT09ICdORVdfU1VCRVNUQUNJT04nKSB7XG4gICAgICAgIG1hcHBlZFR5cGUgPSAnU1VCRVNUQUNJT04nO1xuICAgICAgICB0eXBlTGFiZWwgPSAnU3ViZXN0YWNpw7NuIEVsw6ljdHJpY2EnO1xuICAgICAgfSBlbHNlIGlmICh2YWwgPT09ICdORVdfUFVOVE9fTUVESUNJT04nKSB7XG4gICAgICAgIG1hcHBlZFR5cGUgPSAnUFVOVE9fTUVESUNJT04nO1xuICAgICAgICB0eXBlTGFiZWwgPSAnUHVudG8gZGUgTWVkaWNpw7NuIC8gQW5hbGl6YWRvcic7XG4gICAgICB9IGVsc2UgaWYgKHZhbCA9PT0gJ05FV19DQVJHQScpIHtcbiAgICAgICAgbWFwcGVkVHlwZSA9ICdDQVJHQV9ESVJFQ1RBJztcbiAgICAgICAgdHlwZUxhYmVsID0gJ0NhcmdhIERpcmVjdGEnO1xuICAgICAgfVxuXG4gICAgICBzZXRQcm92aXNpb25hbFRpcG8obWFwcGVkVHlwZSk7XG4gICAgICBzZXRTZWxlY3RlZFRpcG9FbGVtZW50b0Rlc3Rpbm8obWFwcGVkVHlwZSk7XG5cbiAgICAgIGNvbnN0IGRlZmF1bHRQcm92aXNpb25hbE5hbWUgPSBgTnVldm8gJHt0eXBlTGFiZWx9IChQb2xvICR7cG9sZXNTdHJ9KWA7XG4gICAgICBzZXRQcm92aXNpb25hbEN1c3RvbU5hbWUoZGVmYXVsdFByb3Zpc2lvbmFsTmFtZSk7XG5cbiAgICAgIGNvbnN0IGF1dG9EZXNjID0gYFJlc2VydmEgcGFyYSAke3R5cGVMYWJlbH06ICR7ZGVmYXVsdFByb3Zpc2lvbmFsTmFtZX1gO1xuICAgICAgc2V0Tm9tYnJlQXJ0ZWZhY3RvKGF1dG9EZXNjKTtcbiAgICAgIHNldFJvdHVsbyhhdXRvRGVzYyk7XG4gICAgICBpZiAoIWRlc2NBcnRlZmFjdG8pIHtcbiAgICAgICAgc2V0RGVzY0FydGVmYWN0byhgUmVzZXJ2YSBwcm95ZWN0YWRhIHBhcmEgYWxpbWVudGFyICR7dHlwZUxhYmVsfSBkZXNkZSBQb2xvKHMpIFske3BvbGVzU3RyfV1gKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBFbGVtZW50byBleGlzdGVudGUgeWEgcmVnaXN0cmFkb1xuICAgIHNldElzQ3JlYXRpbmdOZXdQcm92aXNpb25hbChmYWxzZSk7XG4gICAgc2V0UHJvdmlzaW9uYWxDdXN0b21OYW1lKCcnKTtcbiAgICBjb25zdCBmb3VuZCA9IChlbGVtZW50b3NDcmVhZG9zIHx8IFtdKS5maW5kKGVsID0+IFN0cmluZyhlbC5pZCkgPT09IFN0cmluZyh2YWwpKTtcbiAgICBpZiAoZm91bmQpIHtcbiAgICAgIHNldFNlbGVjdGVkRWxlbWVudG9EZXN0aW5vSWQoZm91bmQuaWQpO1xuICAgICAgY29uc3QgdCA9IGZvdW5kLnRpcG8gfHwgZm91bmQudGlwb0VsZW1lbnRvIHx8ICdUQUJMRVJPJztcbiAgICAgIHNldFNlbGVjdGVkVGlwb0VsZW1lbnRvRGVzdGlubyh0KTtcbiAgICAgIHNldFNlbGVjdGVkTGluayhmb3VuZCk7XG5cbiAgICAgIGNvbnN0IHRpcG9MYWJlbCA9IHQgPT09ICdDQ00nID8gJ0NDTScgOlxuICAgICAgICAgICAgICAgICAgICAgICAgdCA9PT0gJ1RSQU5TRkVSJyA/ICdUcmFuc2ZlcmVuY2lhIEFUUycgOlxuICAgICAgICAgICAgICAgICAgICAgICAgdCA9PT0gJ0dFTkVSQURPUicgPyAnR2VuZXJhZG9yJyA6XG4gICAgICAgICAgICAgICAgICAgICAgICB0ID09PSAnU1VCRVNUQUNJT04nID8gJ1N1YmVzdGFjacOzbicgOlxuICAgICAgICAgICAgICAgICAgICAgICAgdCA9PT0gJ1RSQU5TRk9STUFET1InID8gJ1RyYW5zZm9ybWFkb3InIDpcbiAgICAgICAgICAgICAgICAgICAgICAgIHQgPT09ICdQVU5UT19NRURJQ0lPTicgPyAnRXF1aXBvIGRlIE1lZGlkYScgOlxuICAgICAgICAgICAgICAgICAgICAgICAgdCA9PT0gJ1RBQkxFUk8nID8gJ1RhYmxlcm8nIDogKHQgfHwgJ0VsZW1lbnRvJyk7XG4gICAgICBjb25zdCBhdXRvRGVzYyA9IGBBbGltZW50YWNpw7NuIGEgJHt0aXBvTGFiZWx9OiAke2ZvdW5kLm5vbWJyZX1gO1xuICAgICAgc2V0Tm9tYnJlQXJ0ZWZhY3RvKGF1dG9EZXNjKTtcbiAgICAgIHNldFJvdHVsbyhhdXRvRGVzYyk7XG4gICAgICBpZiAoIWRlc2NBcnRlZmFjdG8pIHtcbiAgICAgICAgc2V0RGVzY0FydGVmYWN0byhgQWxpbWVudGFjacOzbiBkaXJlY3RhIGhhY2lhICR7Zm91bmQubm9tYnJlfSAoSUQ6ICR7Zm91bmQuaWR9KWApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICAvLyBDYW1wb3MgRXF1aXBvcyBkZSBQb3RlbmNpYSAvIFRyYWZvIC8gR2VuIC8gQVRTIC8gQ0NNIC8gUHVudG8gTWVkaWNpb24gLyBQdWVzdGEgVGllcnJhXG4gIGNvbnN0IFtuaXZlbE1ULCBzZXROaXZlbE1UXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2Z1c2libGVNVCwgc2V0RnVzaWJsZU1UXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3BhcmFycmF5b3MsIHNldFBhcmFycmF5b3NdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbY2FuYWxpemFjaW9uLCBzZXRDYW5hbGl6YWNpb25dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZXNxdWVtYUFycmFucXVlLCBzZXRFc3F1ZW1hQXJyYW5xdWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbaHBLdywgc2V0SHBLd10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjb3JyaWVudGVOb21pbmFsLCBzZXRDb3JyaWVudGVOb21pbmFsXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3Byb3RlY2Npb24sIHNldFByb3RlY2Npb25dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcmVkQ29tbXMsIHNldFJlZENvbW1zXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3RpcG9Db25tdXRhZG9yLCBzZXRUaXBvQ29ubXV0YWRvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtyZWxhY2lvblRjLCBzZXRSZWxhY2lvblRjXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3JlbGFjaW9uVHAsIHNldFJlbGFjaW9uVHBdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcmVzaXN0ZW5jaWFPaG1zLCBzZXRSZXNpc3RlbmNpYU9obXNdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2VuYWxBcnJhbnF1ZSwgc2V0U2VuYWxBcnJhbnF1ZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwb3RlbmNpYUt2YUt3LCBzZXRQb3RlbmNpYUt2YUt3XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3RlbnNpb25TZWN1bmRhcmlhLCBzZXRUZW5zaW9uU2VjdW5kYXJpYV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtpbnRlcnJ1cHRvckFndWFzQWJham8sIHNldEludGVycnVwdG9yQWd1YXNBYmFqb10gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gUmV2ZXJzacOzbiBleHBsw61jaXRhIGEgUmVzZXJ2YVxuICBjb25zdCBoYW5kbGVSZXZlcnRpckFSZXNlcnZhID0gKCkgPT4ge1xuICAgIG9uU2F2ZShjaXJjdWl0RGF0YS5pZCwge1xuICAgICAgZXF1aXBvOiAnUkVTRVJWQScsXG4gICAgICB0aXBvRGVzdGlubzogJ1JFU0VSVkEnLFxuICAgICAgdmluY3VsYWRvSWQ6IG51bGwsXG4gICAgICBlbGVtZW50b0Rlc3Rpbm9JZDogbnVsbCxcbiAgICAgIHRpcG9FbGVtZW50b0Rlc3Rpbm86IG51bGwsXG4gICAgICB0aXBvRWxlbWVudG9Qcm92aXNpb25hbDogdW5kZWZpbmVkLFxuICAgICAgbm9tYnJlUHJvdmlzaW9uYWw6IHVuZGVmaW5lZCxcbiAgICAgIGJyZWFrZXI6IHtcbiAgICAgICAgYW1wOiAnJyxcbiAgICAgICAgbWFyY2E6ICcnLFxuICAgICAgICB0aXBvOiAnJ1xuICAgICAgfSxcbiAgICAgIGNvbmR1Y3RvcjogJycsXG4gICAgICBwb2xlczogaXNUYWJsZXJvID8gdmFsaWRhdGlvbi5yZXF1aXJlZFBvbGVzIDogWzEsIDIsIDNdLFxuICAgICAgbnVtUG9sb3M6IGlzVGFibGVybyA/IG51bVBvbG9zIDogMSxcbiAgICAgIHBvc2ljaW9uUG9sbzogaXNUYWJsZXJvID8gcG9zaWNpb25Qb2xvIDogMSxcbiAgICAgIGNvZGlnb1BvbG86IGNpcmN1aXREYXRhPy5jb2RpZ29Qb2xvIHx8IGNpcmN1aXREYXRhPy5wb2xvX2xhYmVsIHx8ICcnLFxuICAgICAgcG9sb19sYWJlbDogY2lyY3VpdERhdGE/LnBvbG9fbGFiZWwgfHwgY2lyY3VpdERhdGE/LmNvZGlnb1BvbG8gfHwgJycsXG4gICAgICBlc3RhZG86ICdSRVNFUlZBJyxcbiAgICAgIGZpY2hhOiB7XG4gICAgICAgIGRlc2NyaXBjaW9uOiAnJyxcbiAgICAgICAgcG90ZW5jaWFXYXR0czogbnVsbCxcbiAgICAgIH0sXG4gICAgICBmb3RvZ3JhZmlhOiBudWxsLFxuICAgICAgZGV0YWxsZXNUZWNuaWNvczoge31cbiAgICB9KTtcbiAgICBvbkNsb3NlKCk7XG4gIH07XG5cbiAgLy8gQ2FyZ2FyIGRhdG9zIGFsIGFicmlyIG1vZGFsXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGNpcmN1aXREYXRhICYmIGlzT3Blbikge1xuICAgICAgc2V0QnJlYWtlckFtcChjaXJjdWl0RGF0YS5icmVha2VyPy5hbXAgfHwgJycpO1xuICAgICAgc2V0QnJlYWtlck1hcmNhKGNpcmN1aXREYXRhLmJyZWFrZXI/Lm1hcmNhIHx8ICcnKTtcbiAgICAgIHNldEJyZWFrZXJUaXBvKGNpcmN1aXREYXRhLmJyZWFrZXI/LnRpcG8gfHwgJycpO1xuICAgICAgc2V0Q29uZHVjdG9yKGNpcmN1aXREYXRhLmNvbmR1Y3RvciB8fCAnJyk7XG4gICAgICBzZXROb21icmVBcnRlZmFjdG8oY2lyY3VpdERhdGEudGlwb0Rlc3Rpbm8gPT09ICdBUlRFRkFDVE8nID8gY2lyY3VpdERhdGEuZXF1aXBvIDogJycpO1xuICAgICAgc2V0RGVzY0FydGVmYWN0byhjaXJjdWl0RGF0YS5maWNoYT8uZGVzY3JpcGNpb24gfHwgJycpO1xuICAgICAgc2V0UG90ZW5jaWFXYXR0cyhjaXJjdWl0RGF0YS5maWNoYT8ucG90ZW5jaWFXYXR0cyB8fCAnJyk7XG4gICAgICBzZXRSb3R1bG8oY2lyY3VpdERhdGEuZXF1aXBvIHx8IGNpcmN1aXREYXRhLm5vbWJyZSB8fCAnJyk7XG4gICAgICBzZXRTZWxlY3RlZExpbmtzKFtdKTtcbiAgICAgIHNldElzQ3JlYXRpbmdOZXdQcm92aXNpb25hbChmYWxzZSk7XG4gICAgICBzZXRQcm92aXNpb25hbEN1c3RvbU5hbWUoJycpO1xuXG4gICAgICAvLyBQcmUtaW5pY2lhbGl6YXIgZWxlbWVudG8gdmluY3VsYWRvIHByZXZpYW1lbnRlXG4gICAgICBjb25zdCBwcmV2RGVzdGlub0lkID0gY2lyY3VpdERhdGEuZWxlbWVudG9EZXN0aW5vSWQgfHwgY2lyY3VpdERhdGEudmluY3VsYWRvSWQgfHwgJyc7XG4gICAgICBjb25zdCBwcmV2VGlwb0Rlc3Rpbm8gPSBjaXJjdWl0RGF0YS50aXBvRWxlbWVudG9EZXN0aW5vIHx8IGNpcmN1aXREYXRhLnRpcG9EZXN0aW5vIHx8ICcnO1xuICAgICAgc2V0U2VsZWN0ZWRFbGVtZW50b0Rlc3Rpbm9JZChwcmV2RGVzdGlub0lkKTtcbiAgICAgIHNldFNlbGVjdGVkVGlwb0VsZW1lbnRvRGVzdGlubyhwcmV2VGlwb0Rlc3Rpbm8pO1xuXG4gICAgICBpZiAocHJldkRlc3Rpbm9JZCkge1xuICAgICAgICBzZXRTZWxlY3RvclZhbHVlKHByZXZEZXN0aW5vSWQpO1xuICAgICAgICBjb25zdCBmb3VuZCA9IChlbGVtZW50b3NDcmVhZG9zIHx8IFtdKS5maW5kKGVsID0+IFN0cmluZyhlbC5pZCkgPT09IFN0cmluZyhwcmV2RGVzdGlub0lkKSB8fCBlbC5ub21icmUgPT09IGNpcmN1aXREYXRhLmVxdWlwbyk7XG4gICAgICAgIGlmIChmb3VuZCkge1xuICAgICAgICAgIHNldFNlbGVjdGVkTGluayhmb3VuZCk7XG4gICAgICAgICAgc2V0U2VhcmNoUXVlcnkoZm91bmQubm9tYnJlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXRTZWxlY3RlZExpbmsobnVsbCk7XG4gICAgICAgICAgc2V0U2VhcmNoUXVlcnkoY2lyY3VpdERhdGEuZXF1aXBvIHx8ICcnKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0U2VsZWN0b3JWYWx1ZSgnJyk7XG4gICAgICAgIHNldFNlbGVjdGVkTGluayhudWxsKTtcbiAgICAgICAgc2V0U2VhcmNoUXVlcnkoJycpO1xuICAgICAgfVxuXG4gICAgICAvLyBDYXJnYXIgcGFyw6FtZXRyb3MgZsOtc2ljb3MgZGUgcG9sb3MgcGFyYSB0YWJsZXJvc1xuICAgICAgY29uc3QgaW5pdFBvbG8gPSBjaXJjdWl0RGF0YS5wb3NpY2lvblBvbG8gIT09IHVuZGVmaW5lZCA/IGNpcmN1aXREYXRhLnBvc2ljaW9uUG9sbyA6IChjaXJjdWl0RGF0YS5wb2xlcyAmJiBjaXJjdWl0RGF0YS5wb2xlcy5sZW5ndGggPiAwID8gY2lyY3VpdERhdGEucG9sZXNbMF0gOiAxKTtcbiAgICAgIGNvbnN0IGluaXROdW0gPSBjaXJjdWl0RGF0YS5udW1Qb2xvcyAhPT0gdW5kZWZpbmVkID8gY2lyY3VpdERhdGEubnVtUG9sb3MgOiAoY2lyY3VpdERhdGEucG9sZXMgJiYgY2lyY3VpdERhdGEucG9sZXMubGVuZ3RoID4gMCA/IGNpcmN1aXREYXRhLnBvbGVzLmxlbmd0aCA6IDEpO1xuICAgICAgc2V0UG9zaWNpb25Qb2xvKHBhcnNlSW50KGluaXRQb2xvLCAxMCkgfHwgMSk7XG4gICAgICBzZXROdW1Qb2xvcyhwYXJzZUludChpbml0TnVtLCAxMCkgfHwgMSk7XG4gICAgICBzZXRFc3RhZG8oY2lyY3VpdERhdGEuZXN0YWRvIHx8IChjaXJjdWl0RGF0YS5lcXVpcG8gPT09ICdSRVNFUlZBJyA/ICdSRVNFUlZBJyA6ICdBQ1RJVk8nKSk7XG5cbiAgICAgIC8vIENhcmdhciBvdHJvcyBjYW1wb3MgdMOpY25pY29zIHNpIGV4aXN0ZW5cbiAgICAgIGNvbnN0IGR0ID0gY2lyY3VpdERhdGEuZGV0YWxsZXNUZWNuaWNvcyB8fCB7fTtcbiAgICAgIGlmIChkdC5uaXZlbE1UKSBzZXROaXZlbE1UKGR0Lm5pdmVsTVQpO1xuICAgICAgaWYgKGR0LmZ1c2libGVNVCAhPT0gdW5kZWZpbmVkKSBzZXRGdXNpYmxlTVQoZHQuZnVzaWJsZU1UKTtcbiAgICAgIGlmIChkdC5wYXJhcnJheW9zKSBzZXRQYXJhcnJheW9zKGR0LnBhcmFycmF5b3MpO1xuICAgICAgaWYgKGR0LmNhbmFsaXphY2lvbikgc2V0Q2FuYWxpemFjaW9uKGR0LmNhbmFsaXphY2lvbik7XG4gICAgICBpZiAoZHQuZXNxdWVtYUFycmFucXVlKSBzZXRFc3F1ZW1hQXJyYW5xdWUoZHQuZXNxdWVtYUFycmFucXVlKTtcbiAgICAgIGlmIChkdC5ocEt3KSBzZXRIcEt3KGR0LmhwS3cpO1xuICAgICAgaWYgKGR0LmNvcnJpZW50ZU5vbWluYWwpIHNldENvcnJpZW50ZU5vbWluYWwoZHQuY29ycmllbnRlTm9taW5hbCk7XG4gICAgICBpZiAoZHQucHJvdGVjY2lvbikgc2V0UHJvdGVjY2lvbihkdC5wcm90ZWNjaW9uKTtcbiAgICAgIGlmIChkdC5yZWRDb21tcykgc2V0UmVkQ29tbXMoZHQucmVkQ29tbXMpO1xuICAgICAgaWYgKGR0LnRpcG9Db25tdXRhZG9yKSBzZXRUaXBvQ29ubXV0YWRvcihkdC50aXBvQ29ubXV0YWRvcik7XG4gICAgICBpZiAoZHQucmVsYWNpb25UYykgc2V0UmVsYWNpb25UYyhkdC5yZWxhY2lvblRjKTtcbiAgICAgIGlmIChkdC5yZWxhY2lvblRwKSBzZXRSZWxhY2lvblRwKGR0LnJlbGFjaW9uVHApO1xuICAgICAgaWYgKGR0LnJlc2lzdGVuY2lhT2htcykgc2V0UmVzaXN0ZW5jaWFPaG1zKGR0LnJlc2lzdGVuY2lhT2htcyk7XG4gICAgICBpZiAoZHQuc2VuYWxBcnJhbnF1ZSkgc2V0U2VuYWxBcnJhbnF1ZShkdC5zZW5hbEFycmFucXVlKTtcbiAgICAgIGlmIChkdC5wb3RlbmNpYUt2YUt3KSBzZXRQb3RlbmNpYUt2YUt3KGR0LnBvdGVuY2lhS3ZhS3cpO1xuICAgICAgaWYgKGR0LnRlbnNpb25TZWN1bmRhcmlhKSBzZXRUZW5zaW9uU2VjdW5kYXJpYShkdC50ZW5zaW9uU2VjdW5kYXJpYSk7XG4gICAgICBpZiAoZHQuaW50ZXJydXB0b3JBZ3Vhc0FiYWpvKSBzZXRJbnRlcnJ1cHRvckFndWFzQWJham8oZHQuaW50ZXJydXB0b3JBZ3Vhc0FiYWpvKTtcblxuICAgICAgLy8gU2VsZWNjacOzbiBkZSBwYXNvIHNlZ8O6biB0aXBvT3JpZ2VuIHkgbW9kb1xuICAgICAgaWYgKGlzVGFibGVybykge1xuICAgICAgICBpZiAoY2lyY3VpdERhdGEudGlwb0Rlc3Rpbm8gPT09ICdBUlRFRkFDVE8nKSB7XG4gICAgICAgICAgc2V0U3RlcCgnRk9STVVMQVJJT19BUlRFRkFDVE8nKTtcbiAgICAgICAgfSBlbHNlIGlmIChjaXJjdWl0RGF0YS50aXBvRGVzdGlubyA9PT0gJ1NVQl9UQUJMRVJPJyB8fCBjaXJjdWl0RGF0YS50aXBvRGVzdGlubyA9PT0gJ0VMRU1FTlRPJykge1xuICAgICAgICAgIHNldFN0ZXAoJ1ZJTkNVTEFSX0VYSVNURU5URScpO1xuICAgICAgICAgIGNvbnN0IGZvdW5kID0gZWxlbWVudG9zQ3JlYWRvcy5maW5kKGVsID0+IGVsLm5vbWJyZSA9PT0gY2lyY3VpdERhdGEuZXF1aXBvIHx8IGVsLmlkID09PSBjaXJjdWl0RGF0YS52aW5jdWxhZG9JZCk7XG4gICAgICAgICAgaWYgKGZvdW5kKSB7XG4gICAgICAgICAgICBzZXRTZWxlY3RlZExpbmsoZm91bmQpO1xuICAgICAgICAgICAgc2V0U2VhcmNoUXVlcnkoZm91bmQubm9tYnJlKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0U2VhcmNoUXVlcnkoY2lyY3VpdERhdGEuZXF1aXBvIHx8ICcnKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoY2lyY3VpdERhdGEudGlwb0Rlc3Rpbm8gPT09ICdTVUJfVEFCTEVST19QRU5ESUVOVEUnIHx8IGNpcmN1aXREYXRhLnRpcG9EZXN0aW5vID09PSAnRUxFTUVOVE9fUEVORElFTlRFJykge1xuICAgICAgICAgIHNldFN0ZXAoJ0FMSU1FTlRBUl9QT1JfQ1JFQVInKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXRTdGVwKCdQUkVHVU5UQV9FU19BUlRFRkFDVE8nKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHRpcG9PcmlnZW4gPT09ICdUUkFOU0ZPUk1BRE9SJykge1xuICAgICAgICAgIGlmIChtb2RvID09PSAnRU5UUkFEQScgfHwgbW9kbyA9PT0gJ1BSSU1BUklBJykgc2V0U3RlcCgnUFJFR1VOVEFfT1JJR0VOX01UJyk7XG4gICAgICAgICAgZWxzZSBzZXRTdGVwKCdWSU5DVUxBUl9FWElTVEVOVEUnKTtcbiAgICAgICAgfSBlbHNlIGlmICh0aXBvT3JpZ2VuID09PSAnR0VORVJBRE9SJykge1xuICAgICAgICAgIHNldFN0ZXAoJ1BSRUdVTlRBX0RFU1RJTk9fR0VOJyk7XG4gICAgICAgIH0gZWxzZSBpZiAodGlwb09yaWdlbiA9PT0gJ1RSQU5TRkVSJykge1xuICAgICAgICAgIGlmIChtb2RvID09PSAnRU5UUkFEQV8xJyB8fCBtb2RvID09PSAnRU5UUkFEQScpIHNldFN0ZXAoJ1BSRUdVTlRBX0ZVRU5URV9BVFMxJyk7XG4gICAgICAgICAgZWxzZSBpZiAobW9kbyA9PT0gJ0VOVFJBREFfMicpIHNldFN0ZXAoJ1BSRUdVTlRBX0ZVRU5URV9BVFMyJyk7XG4gICAgICAgICAgZWxzZSBzZXRTdGVwKCdQUkVHVU5UQV9ERVNUSU5PX0FUUycpO1xuICAgICAgICB9IGVsc2UgaWYgKHRpcG9PcmlnZW4gPT09ICdDQ00nKSB7XG4gICAgICAgICAgc2V0U3RlcCgnUFJFR1VOVEFfQ0FSR0FfQ0NNJyk7XG4gICAgICAgIH0gZWxzZSBpZiAodGlwb09yaWdlbiA9PT0gJ1BVTlRPX01FRElDSU9OJykge1xuICAgICAgICAgIHNldFN0ZXAoJ1BSRUdVTlRBX09SSUdFTl9NRURJQ0lPTicpO1xuICAgICAgICB9IGVsc2UgaWYgKHRpcG9PcmlnZW4gPT09ICdQVUVTVEFfVElFUlJBJykge1xuICAgICAgICAgIHNldFN0ZXAoJ1BSRUdVTlRBX0NPTkVYSU9OX1RJRVJSQScpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNldFN0ZXAoJ1ZJTkNVTEFSX0VYSVNURU5URScpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9LCBbY2lyY3VpdERhdGEsIGlzT3BlbiwgZWxlbWVudG9zQ3JlYWRvcywgaXNUYWJsZXJvLCB0aXBvT3JpZ2VuLCBtb2RvXSk7XG5cbiAgLy8gVmFsaWRhY2nDs24gZGUgY29saXNpw7NuIHkgb2N1cGFjacOzbiBkZSBwb2xvcyBlbiB0aWVtcG8gcmVhbFxuICBjb25zdCB2YWxpZGF0aW9uID0gdXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKCFpc09wZW4gfHwgIWNpcmN1aXREYXRhIHx8ICFpc1RhYmxlcm8pIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGlzVmFsaWQ6IHRydWUsXG4gICAgICAgIHJlcXVpcmVkUG9sZXM6IFsxLCAyLCAzXSxcbiAgICAgICAgZXhjZWVkc01heDogZmFsc2UsXG4gICAgICAgIGNvbmZsaWN0czogW10sXG4gICAgICAgIGNvbmZsaWN0TWVzc2FnZXM6IFtdXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdmFsaWRhdGVQb2xlT2NjdXBhbmN5KHtcbiAgICAgIHBvc2ljaW9uUG9sbyxcbiAgICAgIG51bVBvbG9zLFxuICAgICAgbWF4UG9sb3MsXG4gICAgICBjaXJjdWl0czogdGFibGVyb0NpcmN1aXRzLFxuICAgICAgZXhjbHVkZUNpcmN1aXRJZDogY2lyY3VpdERhdGE/LmlkXG4gICAgfSk7XG4gIH0sIFtpc09wZW4sIGNpcmN1aXREYXRhPy5pZCwgaXNUYWJsZXJvLCBwb3NpY2lvblBvbG8sIG51bVBvbG9zLCBtYXhQb2xvcywgdGFibGVyb0NpcmN1aXRzXSk7XG5cbiAgaWYgKCFpc09wZW4gfHwgIWNpcmN1aXREYXRhKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBmaWx0ZXJlZEVsZW1lbnRzID0gKGVsZW1lbnRvc0NyZWFkb3MgfHwgW10pLmZpbHRlcigoZWwpID0+XG4gICAgKGVsLm5vbWJyZSB8fCAnJykudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgIChlbC5pZCB8fCAnJykudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKVxuICApO1xuXG4gIGNvbnN0IGdldFBvbGVzQXJyYXkgPSAoc3RhcnRQb2xlLCBuKSA9PiB7XG4gICAgY29uc3QgYXJyID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBuOyBpKyspIHtcbiAgICAgIGFyci5wdXNoKHN0YXJ0UG9sZSArIGkgKiAyKTtcbiAgICB9XG4gICAgcmV0dXJuIGFycjtcbiAgfTtcblxuICBjb25zdCBnZXRIZWFkZXJUaXRsZSA9ICgpID0+IHtcbiAgICBpZiAoaXNUYWJsZXJvKSB7XG4gICAgICByZXR1cm4gbW9kbyA9PT0gJ0VOVFJBREEnID8gJ0NvbmZpZ3VyYXIgRnVlbnRlIGRlIEFsaW1lbnRhY2nDs24nIDogJ0NvbmZpZ3VyYXIgU2FsaWRhIC8gQ2lyY3VpdG8nO1xuICAgIH1cbiAgICBpZiAodGlwb09yaWdlbiA9PT0gJ1RSQU5TRk9STUFET1InKSB7XG4gICAgICByZXR1cm4gKG1vZG8gPT09ICdFTlRSQURBJyB8fCBtb2RvID09PSAnUFJJTUFSSUEnKVxuICAgICAgICA/ICdDb25maWd1cmFyIEFsaW1lbnRhY2nDs24gUHJpbWFyaWEgTVQgKExhZG8gUHJpbWFyaW8pJ1xuICAgICAgICA6ICdDb25maWd1cmFyIFNhbGlkYSAvIERpc3RyaWJ1Y2nDs24gQlQgKExhZG8gU2VjdW5kYXJpbyknO1xuICAgIH1cbiAgICBpZiAodGlwb09yaWdlbiA9PT0gJ0dFTkVSQURPUicpIHtcbiAgICAgIHJldHVybiAnQ29uZmlndXJhciBTYWxpZGEgZGUgR2VuZXJhY2nDs24gLyBSZXNwYWxkbyc7XG4gICAgfVxuICAgIGlmICh0aXBvT3JpZ2VuID09PSAnVFJBTlNGRVInKSB7XG4gICAgICBpZiAobW9kbyA9PT0gJ0VOVFJBREFfMScgfHwgbW9kbyA9PT0gJ0VOVFJBREEnKSByZXR1cm4gJ0NvbmZpZ3VyYXIgRnVlbnRlIDEgKFJlZCBQcmluY2lwYWwgLyBOb3JtYWwpJztcbiAgICAgIGlmIChtb2RvID09PSAnRU5UUkFEQV8yJykgcmV0dXJuICdDb25maWd1cmFyIEZ1ZW50ZSAyIChFbWVyZ2VuY2lhIC8gR2VuZXJhZG9yKSc7XG4gICAgICByZXR1cm4gJ0NvbmZpZ3VyYXIgU2FsaWRhIC8gQ2FyZ2FzIFJlc3BhbGRvJztcbiAgICB9XG4gICAgaWYgKHRpcG9PcmlnZW4gPT09ICdDQ00nKSB7XG4gICAgICByZXR1cm4gJ0NvbmZpZ3VyYXIgR2F2ZXRhIC8gQnVja2V0IENDTSc7XG4gICAgfVxuICAgIGlmICh0aXBvT3JpZ2VuID09PSAnUFVOVE9fTUVESUNJT04nKSB7XG4gICAgICByZXR1cm4gJ0NvbmZpZ3VyYXIgRW50cmFkYSBkZSBBY29tZXRpZGEgLyBTdW1pbmlzdHJvJztcbiAgICB9XG4gICAgaWYgKHRpcG9PcmlnZW4gPT09ICdQVUVTVEFfVElFUlJBJykge1xuICAgICAgcmV0dXJuICdDb25maWd1cmFyIENvbmV4acOzbiBhIE1hbGxhIC8gUHVlc3RhIGEgVGllcnJhJztcbiAgICB9XG4gICAgcmV0dXJuIGBDb25maWd1cmFyIENvbmV4acOzbiAtICR7dGlwb09yaWdlbn1gO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNhdmVFcXVpcG1lbnQgPSAoZXF1aXBvTmFtZSwgdGlwb0Rlc3Rpbm9WYWwsIGV4dHJhID0ge30pID0+IHtcbiAgICBsZXQgZmluYWxUaXBvRGVzdGlubyA9IHRpcG9EZXN0aW5vVmFsIHx8IHNlbGVjdGVkVGlwb0VsZW1lbnRvRGVzdGlubyB8fCAnU1VCX1RBQkxFUk8nO1xuICAgIGxldCBmaW5hbERlc3Rpbm9JZCA9IHNlbGVjdGVkRWxlbWVudG9EZXN0aW5vSWQgfHwgZXh0cmEuZWxlbWVudG9EZXN0aW5vSWQgfHwgZXh0cmEudmluY3VsYWRvSWQgfHwgc2VsZWN0ZWRMaW5rPy5pZCB8fCBudWxsO1xuXG4gICAgaWYgKGlzQ3JlYXRpbmdOZXdQcm92aXNpb25hbCkge1xuICAgICAgZmluYWxUaXBvRGVzdGlubyA9ICdTVUJfVEFCTEVST19QRU5ESUVOVEUnO1xuICAgIH1cblxuICAgIGNvbnN0IGZpbmFsRXF1aXBvID0gbm9ybWFsaXplVGV4dChlcXVpcG9OYW1lIHx8IGV4dHJhLmVxdWlwbyB8fCBwcm92aXNpb25hbEN1c3RvbU5hbWUgfHwgcm90dWxvIHx8ICdFUVVJUE8gREUgUE9URU5DSUEnKTtcblxuICAgIGlmIChpc1RhYmxlcm8gJiYgIXZhbGlkYXRpb24uaXNWYWxpZCAmJiB2YWxpZGF0aW9uLmNvbmZsaWN0cyAmJiB2YWxpZGF0aW9uLmNvbmZsaWN0cy5sZW5ndGggPiAwKSB7XG4gICAgICB2YWxpZGF0aW9uLmNvbmZsaWN0cy5mb3JFYWNoKGNvbmYgPT4ge1xuICAgICAgICByZWdpc3RyYXJDb25mbGljdG9DaXJjdWl0byh7XG4gICAgICAgICAgdGFibGVyb0lkOiBjaXJjdWl0RGF0YT8udGFibGVyb0lkIHx8IGNpcmN1aXREYXRhPy5pZCB8fCAnVEFCTEVSTycsXG4gICAgICAgICAgdGFibGVyb05vbWJyZTogY2lyY3VpdERhdGE/LnRhYmxlcm9Ob21icmUgfHwgJ1RhYmxlcm8gRWzDqWN0cmljbycsXG4gICAgICAgICAgcG9sb3M6IFtjb25mLnBvbGVdLFxuICAgICAgICAgIGNpcmN1aXRvSWQ6IGNpcmN1aXREYXRhLmlkLFxuICAgICAgICAgIGNpcmN1aXRvTm9tYnJlOiBmaW5hbEVxdWlwbyxcbiAgICAgICAgICBlcXVpcG9FeGlzdGVudGU6IGNvbmYub2NjdXBpZWRCeT8uZGVzY3JpcGNpb24sXG4gICAgICAgICAgZXF1aXBvTnVldm86IGZpbmFsRXF1aXBvLFxuICAgICAgICAgIGRlc2NyaXBjaW9uOiBgUG9sbyAke2NvbmYucG9sZX0gb2N1cGFkbyBwb3IgXCIke2NvbmYub2NjdXBpZWRCeT8uZGVzY3JpcGNpb24gfHwgJ0NpcmN1aXRvIGV4aXN0ZW50ZSd9XCIuIEFzaWduYWRvIGEgXCIke2ZpbmFsRXF1aXBvfVwiLmAsXG4gICAgICAgICAgdGlwbzogJ1NPTEFQQU1JRU5UT19QT0xPUydcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICAgIHNob3dUb2FzdChcbiAgICAgICAgYENvbmZsaWN0byBlbiBQb2xvKHMpIFske3ZhbGlkYXRpb24ucmVxdWlyZWRQb2xlcy5qb2luKCcsICcpfV0uIEluY2lkZW5jaWEgcmVnaXN0cmFkYSBlbiBsYSBjb2xhLmAsXG4gICAgICAgICd3YXJuaW5nJyxcbiAgICAgICAge1xuICAgICAgICAgIGxhYmVsOiAnVmVyIENvbmZsaWN0bycsXG4gICAgICAgICAgb25DbGljazogKCkgPT4gc2V0UGFuZWxDb25mbGljdG9zT3Blbih0cnVlKVxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cblxuICAgIG9uU2F2ZShjaXJjdWl0RGF0YS5pZCwge1xuICAgICAgZXF1aXBvOiBmaW5hbEVxdWlwbyxcbiAgICAgIHRpcG9EZXN0aW5vOiBmaW5hbFRpcG9EZXN0aW5vLFxuICAgICAgdmluY3VsYWRvSWQ6IGZpbmFsRGVzdGlub0lkLFxuICAgICAgZWxlbWVudG9EZXN0aW5vSWQ6IGZpbmFsRGVzdGlub0lkLFxuICAgICAgdGlwb0VsZW1lbnRvRGVzdGlubzogaXNDcmVhdGluZ05ld1Byb3Zpc2lvbmFsID8gcHJvdmlzaW9uYWxUaXBvIDogKHNlbGVjdGVkVGlwb0VsZW1lbnRvRGVzdGlubyB8fCBmaW5hbFRpcG9EZXN0aW5vKSxcbiAgICAgIHRpcG9FbGVtZW50b1Byb3Zpc2lvbmFsOiBpc0NyZWF0aW5nTmV3UHJvdmlzaW9uYWwgPyBwcm92aXNpb25hbFRpcG8gOiB1bmRlZmluZWQsXG4gICAgICBub21icmVQcm92aXNpb25hbDogaXNDcmVhdGluZ05ld1Byb3Zpc2lvbmFsID8gKHByb3Zpc2lvbmFsQ3VzdG9tTmFtZSB8fCBmaW5hbEVxdWlwbykgOiB1bmRlZmluZWQsXG4gICAgICBicmVha2VyOiB7XG4gICAgICAgIGFtcDogbm9ybWFsaXplVGV4dChicmVha2VyQW1wIHx8IGV4dHJhLmJyZWFrZXJBbXApLFxuICAgICAgICBtYXJjYTogbm9ybWFsaXplVGV4dChicmVha2VyTWFyY2EpLFxuICAgICAgICB0aXBvOiBub3JtYWxpemVUZXh0KGJyZWFrZXJUaXBvKVxuICAgICAgfSxcbiAgICAgIGNvbmR1Y3Rvcjogbm9ybWFsaXplVGV4dChjb25kdWN0b3IgfHwgZXh0cmEuY29uZHVjdG9yKSxcbiAgICAgIHBvbGVzOiBpc1RhYmxlcm8gPyB2YWxpZGF0aW9uLnJlcXVpcmVkUG9sZXMgOiBbMSwgMiwgM10sXG4gICAgICBudW1Qb2xvczogaXNUYWJsZXJvID8gbnVtUG9sb3MgOiAzLFxuICAgICAgcG9zaWNpb25Qb2xvOiBpc1RhYmxlcm8gPyBwb3NpY2lvblBvbG8gOiAxLFxuICAgICAgY29kaWdvUG9sbzogY2lyY3VpdERhdGE/LmNvZGlnb1BvbG8gfHwgY2lyY3VpdERhdGE/LnBvbG9fbGFiZWwgfHwgZXh0cmEuY29kaWdvUG9sbyB8fCAnJyxcbiAgICAgIHBvbG9fbGFiZWw6IGNpcmN1aXREYXRhPy5wb2xvX2xhYmVsIHx8IGNpcmN1aXREYXRhPy5jb2RpZ29Qb2xvIHx8IGV4dHJhLnBvbG9fbGFiZWwgfHwgJycsXG4gICAgICBlc3RhZG86IGVzdGFkbyxcbiAgICAgIGZpY2hhOiB7XG4gICAgICAgIGRlc2NyaXBjaW9uOiBkZXNjQXJ0ZWZhY3RvLFxuICAgICAgICBwb3RlbmNpYVdhdHRzOiBwb3RlbmNpYVdhdHRzID8gcGFyc2VGbG9hdChwb3RlbmNpYVdhdHRzKSA6IG51bGwsXG4gICAgICB9LFxuICAgICAgZm90b2dyYWZpYTogZm90b1VybCxcbiAgICAgIGRldGFsbGVzVGVjbmljb3M6IHtcbiAgICAgICAgbml2ZWxNVCxcbiAgICAgICAgZnVzaWJsZU1ULFxuICAgICAgICBwYXJhcnJheW9zLFxuICAgICAgICBjYW5hbGl6YWNpb24sXG4gICAgICAgIGVzcXVlbWFBcnJhbnF1ZSxcbiAgICAgICAgaHBLdyxcbiAgICAgICAgY29ycmllbnRlTm9taW5hbCxcbiAgICAgICAgcHJvdGVjY2lvbixcbiAgICAgICAgcmVkQ29tbXMsXG4gICAgICAgIHRpcG9Db25tdXRhZG9yLFxuICAgICAgICByZWxhY2lvblRjLFxuICAgICAgICByZWxhY2lvblRwLFxuICAgICAgICByZXNpc3RlbmNpYU9obXMsXG4gICAgICAgIHNlbmFsQXJyYW5xdWUsXG4gICAgICAgIHBvdGVuY2lhS3ZhS3csXG4gICAgICAgIHRlbnNpb25TZWN1bmRhcmlhLFxuICAgICAgICBpbnRlcnJ1cHRvckFndWFzQWJham8sXG4gICAgICAgIC4uLmV4dHJhXG4gICAgICB9XG4gICAgfSk7XG4gICAgb25DbG9zZSgpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNhdmVBcnRlZmFjdG8gPSAoKSA9PiB7XG4gICAgaWYgKCFub21icmVBcnRlZmFjdG8udHJpbSgpKSByZXR1cm4gY3VzdG9tQWxlcnQoJ1BvciBmYXZvciwgaW5ncmVzYSBlbCBub21icmUgZGVsIGFydGVmYWN0by4nKTtcbiAgICBoYW5kbGVTYXZlRXF1aXBtZW50KG5vbWJyZUFydGVmYWN0bywgJ0FSVEVGQUNUTycpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNhdmVWaW5jdWxvID0gKGxpbmtFbGVtZW50KSA9PiB7XG4gICAgaWYgKGlzTXVsdGlTZWxlY3QpIHtcbiAgICAgIGlmIChzZWxlY3RlZExpbmtzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIGN1c3RvbUFsZXJ0KCdQb3IgZmF2b3IsIHNlbGVjY2lvbmEgYWwgbWVub3MgdW4gZWxlbWVudG8gcGFyYSB2aW5jdWxhci4nKTtcbiAgICAgIGNvbnN0IG5hbWVzID0gc2VsZWN0ZWRMaW5rcy5tYXAoZWwgPT4gYCR7ZWwubm9tYnJlfSAoSUQ6ICR7ZWwuaWR9KWApLmpvaW4oJywgJyk7XG4gICAgICBjb25zdCBpZHMgPSBzZWxlY3RlZExpbmtzLm1hcChlbCA9PiBlbC5pZCkuam9pbignLCAnKTtcbiAgICAgIGhhbmRsZVNhdmVFcXVpcG1lbnQobmFtZXMsICdTVUJfVEFCTEVSTycsIHsgdmluY3VsYWRvSWQ6IGlkcywgZWxlbWVudG9EZXN0aW5vSWQ6IGlkcywgdGlwb0VsZW1lbnRvRGVzdGlubzogJ1NVQl9UQUJMRVJPJywgdmluY3VsYWRvczogc2VsZWN0ZWRMaW5rcyB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZWwgPSBsaW5rRWxlbWVudCB8fCBzZWxlY3RlZExpbms7XG4gICAgaWYgKCFlbCkgcmV0dXJuIGN1c3RvbUFsZXJ0KCdQb3IgZmF2b3IsIHNlbGVjY2lvbmEgdW4gZWxlbWVudG8gcGFyYSB2aW5jdWxhci4nKTtcbiAgICBoYW5kbGVTYXZlRXF1aXBtZW50KGAke2VsLm5vbWJyZX0gKElEOiAke2VsLmlkfSlgLCBlbC50aXBvIHx8ICdTVUJfVEFCTEVSTycsIHsgdmluY3VsYWRvSWQ6IGVsLmlkLCBlbGVtZW50b0Rlc3Rpbm9JZDogZWwuaWQsIHRpcG9FbGVtZW50b0Rlc3Rpbm86IGVsLnRpcG8gfHwgJ1NVQl9UQUJMRVJPJyB9KTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTYXZlUG9yQ3JlYXIgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FsY3VsYXRlZFBvbGVzID0gdmFsaWRhdGlvbj8ucmVxdWlyZWRQb2xlcyB8fCBnZXRQb2xlc0FycmF5KHBvc2ljaW9uUG9sbywgbnVtUG9sb3MpO1xuICAgIGNvbnN0IHBlbmRpbmdOYW1lID0gYEVxdWlwbyAvIFN1Yi1FbGVtZW50byAoJHtpc1RhYmxlcm8gPyBgUG9sbyAke2NhbGN1bGF0ZWRQb2xlcy5qb2luKCcsICcpfWAgOiAnUHJvdmlzaW9uYWwnfSlgO1xuICAgIGhhbmRsZVNhdmVFcXVpcG1lbnQocGVuZGluZ05hbWUsICdTVUJfVEFCTEVST19QRU5ESUVOVEUnLCB7XG4gICAgICBub21icmVQcm92aXNpb25hbDogcGVuZGluZ05hbWUsXG4gICAgICB0aXBvRWxlbWVudG9Qcm92aXNpb25hbDogcHJvdmlzaW9uYWxUaXBvIHx8ICdUQUJMRVJPJyxcbiAgICAgIHBvbGVzOiBpc1RhYmxlcm8gPyAodmFsaWRhdGlvbj8ucmVxdWlyZWRQb2xlcyB8fCBjYWxjdWxhdGVkUG9sZXMpIDogWzEsIDIsIDNdXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2F2ZVJvdHVsb0ZvdG8gPSAoKSA9PiB7XG4gICAgaGFuZGxlU2F2ZUVxdWlwbWVudChyb3R1bG8gfHwgJ1JFU0VSVkEnLCAnUkVTRVJWQScpO1xuICB9O1xuXG4gIGNvbnN0IHNpbXVsYXJDYXB0dXJhRm90byA9ICgpID0+IHtcbiAgICBjb25zdCBtb2NrUGhvdG9zID0gW1xuICAgICAgJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNjIxOTA1MjUyNTA3LWIzNTRiYzI1ZWRhYz9hdXRvPWZvcm1hdCZmaXQ9Y3JvcCZ3PTQwMCZxPTgwJyxcbiAgICAgICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU1ODM0NjQ5MC1hNzJlNTNhZTJkNGY/YXV0bz1mb3JtYXQmZml0PWNyb3Amdz00MDAmcT04MCcsXG4gICAgXTtcbiAgICBjb25zdCByYW5kb21QaG90byA9IG1vY2tQaG90b3NbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogbW9ja1Bob3Rvcy5sZW5ndGgpXTtcbiAgICBzZXRGb3RvVXJsKHJhbmRvbVBob3RvKTtcbiAgfTtcblxuICBjb25zdCByZW5kZXJVbml2ZXJzYWxFbGVtZW50U2VsZWN0b3IgPSAoKSA9PiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvODAgcC0zLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBzcGFjZS15LTIuNSB0ZXh0LXhzIGZvbnQtc2Fuc1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1bMTBweF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgIERlc3Rpbm8gLyBWaW5jdWxhY2nDs24gZGUgbGEgUmVzZXJ2YSBvIFNhbGlkYTpcbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAge3NlbGVjdGVkRWxlbWVudG9EZXN0aW5vSWQgPyAoXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIGJnLWFtYmVyLTUwMC8xMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8yMCBweC0xLjUgcHktMC41IHJvdW5kZWRcIj5cbiAgICAgICAgICAgIElEOiB7c2VsZWN0ZWRFbGVtZW50b0Rlc3Rpbm9JZH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICkgOiBpc0NyZWF0aW5nTmV3UHJvdmlzaW9uYWwgPyAoXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtZW1lcmFsZC00MDAgYmctZW1lcmFsZC01MDAvMTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8yMCBweC0xLjUgcHktMC41IHJvdW5kZWRcIj5cbiAgICAgICAgICAgIE5VRVZPICh7cHJvdmlzaW9uYWxUaXBvfSlcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxzZWxlY3RcbiAgICAgICAgdmFsdWU9e3NlbGVjdG9yVmFsdWV9XG4gICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVVbml2ZXJzYWxFbGVtZW50Q2hhbmdlfVxuICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzUwIGhvdmVyOmJvcmRlci1zbGF0ZS02MDAgcm91bmRlZC1sZyBweC0zIHB5LTIgdGV4dC1zbGF0ZS0xMDAgdGV4dC14cyBmb250LW1lZGl1bSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICA+XG4gICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj4tLSBDYXJnYSBkaXJlY3RhIC8gU2luIHZpbmN1bGFjacOzbiBlc3BlY8OtZmljYSAtLTwvb3B0aW9uPlxuICAgICAgICBcbiAgICAgICAgey8qIFNFQ0NJw5NOIDE6IE5VRVZPIEVMRU1FTlRPIFBPUiBDUkVBUiAoUkVTRVJWQSBGVVRVUkEpICovfVxuICAgICAgICA8b3B0Z3JvdXAgbGFiZWw9XCLinpUgTlVFVk8gRUxFTUVOVE8gUE9SIENSRUFSIChSRVNFUlZBIEZVVFVSQSlcIj5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTkVXX1RBQkxFUk9cIj7inpUgQ3JlYXIgTnVldm8gU3ViLVRhYmxlcm8gLyBQYW5lbDwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJORVdfVFJBTlNGRVJcIj7inpUgQ3JlYXIgTnVldmEgVHJhbnNmZXJlbmNpYSBBdXRvbcOhdGljYSAoQVRTL01UUyk8L29wdGlvbj5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTkVXX0NDTVwiPuKelSBDcmVhciBOdWV2byBDZW50cm8gZGUgQ29udHJvbCBkZSBNb3RvcmVzIChDQ00pPC9vcHRpb24+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk5FV19HRU5FUkFET1JcIj7inpUgQ3JlYXIgTnVldm8gR2VuZXJhZG9yIC8gUGxhbnRhIEVsw6ljdHJpY2E8L29wdGlvbj5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTkVXX1RSQU5TRk9STUFET1JcIj7inpUgQ3JlYXIgTnVldm8gVHJhbnNmb3JtYWRvciBkZSBQb3RlbmNpYTwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJORVdfU1VCRVNUQUNJT05cIj7inpUgQ3JlYXIgTnVldmEgU3ViZXN0YWNpw7NuIEVsw6ljdHJpY2E8L29wdGlvbj5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTkVXX1BVTlRPX01FRElDSU9OXCI+4p6VIENyZWFyIE51ZXZvIFB1bnRvIGRlIE1lZGljacOzbiAvIEFuYWxpemFkb3I8L29wdGlvbj5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTkVXX0NBUkdBXCI+4p6VIENyZWFyIENhcmdhIERpcmVjdGEgKEJvbWJhLCBNb3RvciwgZXRjLik8L29wdGlvbj5cbiAgICAgICAgPC9vcHRncm91cD5cblxuICAgICAgICB7LyogU0VDQ0nDk04gMjogRUxFTUVOVE9TIEVYSVNURU5URVMgUkVHSVNUUkFET1MgRU4gRUwgUFJPWUVDVE8gKi99XG4gICAgICAgIHtncm91cGVkRWxlbWVudHMuVEFCTEVSTy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICA8b3B0Z3JvdXAgbGFiZWw9XCLwn4+iIFRhYmxlcm9zIHkgU3VidGFibGVyb3MgRXhpc3RlbnRlc1wiPlxuICAgICAgICAgICAge2dyb3VwZWRFbGVtZW50cy5UQUJMRVJPLm1hcChlbCA9PiAoXG4gICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtlbC5pZH0gdmFsdWU9e2VsLmlkfT5cbiAgICAgICAgICAgICAgICB7ZWwubm9tYnJlfSAoe2VsLmlkfSlcbiAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L29wdGdyb3VwPlxuICAgICAgICApfVxuICAgICAgICB7Z3JvdXBlZEVsZW1lbnRzLlRSQU5TRkVSLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxvcHRncm91cCBsYWJlbD1cIvCflIQgVHJhbnNmZXJlbmNpYXMgKEFUUy9NVFMpIEV4aXN0ZW50ZXNcIj5cbiAgICAgICAgICAgIHtncm91cGVkRWxlbWVudHMuVFJBTlNGRVIubWFwKGVsID0+IChcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2VsLmlkfSB2YWx1ZT17ZWwuaWR9PlxuICAgICAgICAgICAgICAgIHtlbC5ub21icmV9ICh7ZWwuaWR9KVxuICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvb3B0Z3JvdXA+XG4gICAgICAgICl9XG4gICAgICAgIHtncm91cGVkRWxlbWVudHMuQ0NNLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxvcHRncm91cCBsYWJlbD1cIuKame+4jyBDZW50cm9zIGRlIENvbnRyb2wgZGUgTW90b3JlcyAoQ0NNKSBFeGlzdGVudGVzXCI+XG4gICAgICAgICAgICB7Z3JvdXBlZEVsZW1lbnRzLkNDTS5tYXAoZWwgPT4gKFxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZWwuaWR9IHZhbHVlPXtlbC5pZH0+XG4gICAgICAgICAgICAgICAge2VsLm5vbWJyZX0gKHtlbC5pZH0pXG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9vcHRncm91cD5cbiAgICAgICAgKX1cbiAgICAgICAge2dyb3VwZWRFbGVtZW50cy5HRU5FUkFET1IubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPG9wdGdyb3VwIGxhYmVsPVwi4pqhIEdlbmVyYWRvcmVzIHkgUGxhbnRhcyBFeGlzdGVudGVzXCI+XG4gICAgICAgICAgICB7Z3JvdXBlZEVsZW1lbnRzLkdFTkVSQURPUi5tYXAoZWwgPT4gKFxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZWwuaWR9IHZhbHVlPXtlbC5pZH0+XG4gICAgICAgICAgICAgICAge2VsLm5vbWJyZX0gKHtlbC5pZH0pXG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9vcHRncm91cD5cbiAgICAgICAgKX1cbiAgICAgICAge2dyb3VwZWRFbGVtZW50cy5TVUJFU1RBQ0lPTi5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICA8b3B0Z3JvdXAgbGFiZWw9XCLwn4+b77iPIFN1YmVzdGFjaW9uZXMgRWzDqWN0cmljYXMgRXhpc3RlbnRlc1wiPlxuICAgICAgICAgICAge2dyb3VwZWRFbGVtZW50cy5TVUJFU1RBQ0lPTi5tYXAoZWwgPT4gKFxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZWwuaWR9IHZhbHVlPXtlbC5pZH0+XG4gICAgICAgICAgICAgICAge2VsLm5vbWJyZX0gKHtlbC5pZH0pXG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9vcHRncm91cD5cbiAgICAgICAgKX1cbiAgICAgICAge2dyb3VwZWRFbGVtZW50cy5UUkFOU0ZPUk1BRE9SLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxvcHRncm91cCBsYWJlbD1cIvCflIwgVHJhbnNmb3JtYWRvcmVzIEV4aXN0ZW50ZXNcIj5cbiAgICAgICAgICAgIHtncm91cGVkRWxlbWVudHMuVFJBTlNGT1JNQURPUi5tYXAoZWwgPT4gKFxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZWwuaWR9IHZhbHVlPXtlbC5pZH0+XG4gICAgICAgICAgICAgICAge2VsLm5vbWJyZX0gKHtlbC5pZH0pXG4gICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9vcHRncm91cD5cbiAgICAgICAgKX1cbiAgICAgICAge2dyb3VwZWRFbGVtZW50cy5QVU5UT19NRURJQ0lPTi5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICA8b3B0Z3JvdXAgbGFiZWw9XCLwn5OKIEVxdWlwb3MgLyBQdW50b3MgZGUgTWVkaWRhIEV4aXN0ZW50ZXNcIj5cbiAgICAgICAgICAgIHtncm91cGVkRWxlbWVudHMuUFVOVE9fTUVESUNJT04ubWFwKGVsID0+IChcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2VsLmlkfSB2YWx1ZT17ZWwuaWR9PlxuICAgICAgICAgICAgICAgIHtlbC5ub21icmV9ICh7ZWwuaWR9KVxuICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvb3B0Z3JvdXA+XG4gICAgICAgICl9XG4gICAgICAgIHtncm91cGVkRWxlbWVudHMuT1RST1MubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPG9wdGdyb3VwIGxhYmVsPVwi8J+TpiBPdHJvcyBFbGVtZW50b3MgUmVnaXN0cmFkb3NcIj5cbiAgICAgICAgICAgIHtncm91cGVkRWxlbWVudHMuT1RST1MubWFwKGVsID0+IChcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2VsLmlkfSB2YWx1ZT17ZWwuaWR9PlxuICAgICAgICAgICAgICAgIHtlbC5ub21icmV9ICh7ZWwuaWR9KVxuICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvb3B0Z3JvdXA+XG4gICAgICAgICl9XG4gICAgICA8L3NlbGVjdD5cblxuICAgICAgey8qIElucHV0IGNvbnRleHR1YWwgc2kgc2UgZWxpZ2UgY3JlYXIgdW4gZWxlbWVudG8gbnVldm8gY29tbyByZXNlcnZhIGZ1dHVyYSAqL31cbiAgICAgIHtpc0NyZWF0aW5nTmV3UHJvdmlzaW9uYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MCBzcGFjZS15LTEuNSBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgPHNwYW4+8J+TnTwvc3Bhbj4gTm9tYnJlIC8gUsOzdHVsbyBwcm92aXNpb25hbCBwYXJhIGVsIG51ZXZvIGVsZW1lbnRvICh7cHJvdmlzaW9uYWxUaXBvfSk6XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIHZhbHVlPXtwcm92aXNpb25hbEN1c3RvbU5hbWV9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgdiA9IGUudGFyZ2V0LnZhbHVlO1xuICAgICAgICAgICAgICBzZXRQcm92aXNpb25hbEN1c3RvbU5hbWUodik7XG4gICAgICAgICAgICAgIHNldE5vbWJyZUFydGVmYWN0byh2KTtcbiAgICAgICAgICAgICAgc2V0Um90dWxvKHYpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtgRWouICR7cHJvdmlzaW9uYWxUaXBvfS0wMSAoUGxhbnRhIFByaW5jaXBhbClgfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzQwIHJvdW5kZWQtbGcgcHgtMyBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgdGV4dC14cyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNDAwIGZvbnQtbWVkaXVtXCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICBTZSByZWdpc3RyYXLDoSB1biBlbGVtZW50byBwcm92aXNpb25hbCBkZSB0aXBvIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTMwMFwiPntwcm92aXNpb25hbFRpcG99PC9zdHJvbmc+IGVuIGVsIHByb3llY3RvIHkgcXVlZGFyw6EgdmluY3VsYWRvIGEgZXN0ZSBpbnRlcnJ1cHRvci5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgPGRpdiBcbiAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1zbGF0ZS05NTAvNzAgYmFja2Ryb3AtYmx1ci1tZCB0cmFuc2l0aW9uLW9wYWNpdHlcIiBcbiAgICAgICAgb25DbGljaz17b25DbG9zZX0gXG4gICAgICAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1sZyBiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCBtYXgtaC1bOTB2aF0gdGV4dC1zbGF0ZS0xMDAgZm9udC1zYW5zXCI+XG4gICAgICAgIFxuICAgICAgICB7LyogQ2FiZWNlcmEgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTYgcHktNCBiZy1ncmFkaWVudC10by1yIGZyb20tYW1iZXItNTAwLzEwIHRvLWFtYmVyLTYwMC8xMCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAge3N0ZXAgIT09ICdQUkVHVU5UQV9FU19BUlRFRkFDVE8nICYmIHN0ZXAgIT09ICdQUkVHVU5UQV9PUklHRU5fTVQnICYmIHN0ZXAgIT09ICdQUkVHVU5UQV9ERVNUSU5PX0JUJyAmJiBzdGVwICE9PSAnUFJFR1VOVEFfREVTVElOT19HRU4nICYmIHN0ZXAgIT09ICdQUkVHVU5UQV9GVUVOVEVfQVRTMScgJiYgc3RlcCAhPT0gJ1BSRUdVTlRBX0NBUkdBX0NDTScgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChpc1RhYmxlcm8pIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN0ZXAgPT09ICdGT1JNVUxBUklPX0FSVEVGQUNUTycgfHwgc3RlcCA9PT0gJ1BSRUdVTlRBX0FMSU1FTlRBX09UUk8nKSBzZXRTdGVwKCdQUkVHVU5UQV9FU19BUlRFRkFDVE8nKTtcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoc3RlcCA9PT0gJ1BSRUdVTlRBX0NSRUFETycgfHwgc3RlcCA9PT0gJ1JPVFVMQVJfWV9GT1RPJykgc2V0U3RlcCgnUFJFR1VOVEFfQUxJTUVOVEFfT1RSTycpO1xuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzdGVwID09PSAnVklOQ1VMQVJfRVhJU1RFTlRFJyB8fCBzdGVwID09PSAnQUxJTUVOVEFSX1BPUl9DUkVBUicpIHNldFN0ZXAoJ1BSRUdVTlRBX0NSRUFETycpO1xuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN0ZXAgPT09ICdGT1JNVUxBUklPX1BPVEVOQ0lBX1RSQU5TRk9fTVQnKSBzZXRTdGVwKCdQUkVHVU5UQV9PUklHRU5fTVQnKTtcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoc3RlcCA9PT0gJ0ZPUk1VTEFSSU9fUE9URU5DSUFfVFJBTlNGT19CVCcpIHNldFN0ZXAoJ1BSRUdVTlRBX0RFU1RJTk9fQlQnKTtcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoc3RlcCA9PT0gJ0ZPUk1VTEFSSU9fUE9URU5DSUFfR0VOJykgc2V0U3RlcCgnUFJFR1VOVEFfREVTVElOT19HRU4nKTtcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoc3RlcCA9PT0gJ0ZPUk1VTEFSSU9fUE9URU5DSUFfQVRTJyB8fCBzdGVwID09PSAnRk9STVVMQVJJT19QT1RFTkNJQV9BVFNfU0FMSURBJykgc2V0U3RlcCgnUFJFR1VOVEFfRlVFTlRFX0FUUzEnKTtcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoc3RlcCA9PT0gJ0ZPUk1VTEFSSU9fR0FWRVRBX0NDTScpIHNldFN0ZXAoJ1BSRUdVTlRBX0NBUkdBX0NDTScpO1xuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzdGVwID09PSAnRk9STVVMQVJJT19NRURJQ0lPTicpIHNldFN0ZXAoJ1BSRUdVTlRBX09SSUdFTl9NRURJQ0lPTicpO1xuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzdGVwID09PSAnRk9STVVMQVJJT19USUVSUkEnKSBzZXRTdGVwKCdQUkVHVU5UQV9DT05FWElPTl9USUVSUkEnKTtcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBzZXRTdGVwKCdWSU5DVUxBUl9FWElTVEVOVEUnKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTMwMFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgIHtnZXRIZWFkZXJUaXRsZSgpfVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgSWRlbnRpZmljYWRvcjogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMFwiPntjaXJjdWl0RGF0YS5ub21icmUgfHwgY2lyY3VpdERhdGEuaWQgfHwgJ1NhbGlkYSd9PC9zcGFuPlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICB7aXNUYWJsZXJvICYmIChjaXJjdWl0RGF0YS50aXBvRGVzdGlubyA9PT0gJ0FSVEVGQUNUTycgfHwgY2lyY3VpdERhdGEudGlwb0Rlc3Rpbm8gPT09ICdTVUJfVEFCTEVSTycgfHwgY2lyY3VpdERhdGEuZXF1aXBvICE9PSAnUkVTRVJWQScpICYmIChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJldmVydGlyQVJlc2VydmF9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEuNSBiZy1hbWJlci01MDAvMTAgaG92ZXI6YmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItNDAwIGhvdmVyOnRleHQtYW1iZXItMzAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIGhvdmVyOmJvcmRlci1hbWJlci01MDAvNTAgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkRlc3ZpbmN1bGFyIGNhcmdhL2VxdWlwbyB5IHJlc3RhYmxlY2VyIGVzdGUgY2lyY3VpdG8gYSBlc3RhZG8gUmVzZXJ2YVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+UmV2ZXJ0aXIgYSBSZXNlcnZhPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgaG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1zbGF0ZS00MDBcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBDb250ZW5pZG8gcHJpbmNpcGFsICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC02IHNwYWNlLXktNlwiPlxuICAgICAgICAgIFxuICAgICAgICAgIHsvKiBQYXLDoW1ldHJvcyBGw61zaWNvcyBkZWwgQnJlYWtlciAoU09MTyBQQVJBIFRBQkxFUk9TKSAqL31cbiAgICAgICAgICB7aXNUYWJsZXJvICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzcwIHAtNCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBzcGFjZS15LTMuNSBmb250LXNhbnMgdGV4dC14cyBzaGFkb3ctaW5uZXJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMC84MCBwYi0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPExheWVycyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTUwMFwiIC8+IERpc3Bvc2ljacOzbiBkZSBQb2xvcyB5IEZhc2VcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNDAwIGJnLXNsYXRlLTkwMCBweC0yIHB5LTAuNSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICB7cG9zaWNpb25Qb2xvICUgMiAhPT0gMCA/ICdDb2x1bW5hIEl6cSAoSW1wYXJlcyknIDogJ0NvbHVtbmEgRGVyIChQYXJlcyknfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtWzlweF0gbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICBDYW50aWRhZCBkZSBQb2xvc1xuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e251bVBvbG9zfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE51bVBvbG9zKHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlLCAxMCkpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzUwIHJvdW5kZWQteGwgcHgtMi41IHB5LTIgdGV4dC1zbGF0ZS0xMDAgZm9udC1zZW1pYm9sZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtbMSwgMiwgM10ubWFwKChwKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3B9IHZhbHVlPXtwfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwID09PSAxID8gJzFQIChNb25vZsOhc2ljbyknIDogcCA9PT0gMiA/ICcyUCAoQmlmw6FzaWNvKScgOiAnM1AgKFRyaWbDoXNpY28pJ31cbiAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVs5cHhdIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgUG9sbyBJbmljaWFsXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICBtaW49XCIxXCJcbiAgICAgICAgICAgICAgICAgICAgbWF4PXttYXhQb2xvc31cbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bvc2ljaW9uUG9sb31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsID0gcGFyc2VJbnQoZS50YXJnZXQudmFsdWUsIDEwKTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzTmFOKHZhbCkgJiYgdmFsID4gMCkgc2V0UG9zaWNpb25Qb2xvKHZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoZS50YXJnZXQudmFsdWUgPT09ICcnKSBzZXRQb3NpY2lvblBvbG8oJycpO1xuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzUwIHJvdW5kZWQteGwgcHgtMi41IHB5LTIgdGV4dC1zbGF0ZS0xMDAgZm9udC1zZW1pYm9sZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVs5cHhdIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgRXN0YWRvIGRlbCBQb2xvXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZXN0YWRvfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRFc3RhZG8odmFsKTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsID09PSAnUkVTRVJWQScgfHwgdmFsID09PSAnRElTUE9OSUJMRScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldE5vbWJyZUFydGVmYWN0byh2YWwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Um90dWxvKHZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRCcmVha2VyQW1wKCcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldERlc2NBcnRlZmFjdG8oJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0UG90ZW5jaWFXYXR0cygnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzUwIHJvdW5kZWQteGwgcHgtMi41IHB5LTIgdGV4dC1zbGF0ZS0xMDAgZm9udC1zZW1pYm9sZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBQ1RJVk9cIj7wn5+iIEFDVElWTyAoQ29uIENhcmdhKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUkVTRVJWQVwiPvCfn6EgUkVTRVJWQSAoQmxvcXVlYWRvKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRElTUE9OSUJMRVwiPuKaqiBESVNQT05JQkxFIChMaWJyZSk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogSFVFTExBIERFIFBPTE9TIENBTENVTEFET1MgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGZsZXgtd3JhcCBnYXAtMiB0ZXh0LVsxMXB4XSBiZy1zbGF0ZS05MDAvOTAgcHgtMyBweS0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtXCI+UG9sb3MgUmVxdWVyaWRvczo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIGJnLWFtYmVyLTUwMC8xNSBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBweC0yIHB5LTAuNSByb3VuZGVkXCI+XG4gICAgICAgICAgICAgICAgICAgIFt7dmFsaWRhdGlvbi5yZXF1aXJlZFBvbGVzLmpvaW4oJywgJyl9XVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1bMTBweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgKHtudW1Qb2xvcyA9PT0gMSA/ICcxIFBvbG8nIDogYCR7bnVtUG9sb3N9IFBvbG9zYH0pXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIENhcGFjaWRhZCBUb3RhbDogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkXCI+e21heFBvbG9zfSBQb2xvczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEFMRVJUQSBWSVNVQUwgRU4gVElFTVBPIFJFQUw6IENPTElTScOTTiBPIERJU1BPTklCTEUgKi99XG4gICAgICAgICAgICAgIHshdmFsaWRhdGlvbi5pc1ZhbGlkID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXJvc2UtNTAwLzE1IGJvcmRlciBib3JkZXItcm9zZS01MDAvNDAgcm91bmRlZC14bCBzcGFjZS15LTEgdGV4dC1yb3NlLTIwMCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMTUwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtcm9zZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yb3NlLTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkNvbmZsaWN0byBkZSBPY3VwYWNpw7NuIC8gQ2FwYWNpZGFkIGRlIFBvbG9zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMC41IHBsLTZcIj5cbiAgICAgICAgICAgICAgICAgICAge3ZhbGlkYXRpb24uY29uZmxpY3RNZXNzYWdlcy5tYXAoKG1zZywgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHAga2V5PXtpZHh9IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZCB0ZXh0LXJvc2UtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICDigKIge21zZ31cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTEuNSBiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzI1IHJvdW5kZWQteGwgdGV4dC1bMTFweF0gdGV4dC1lbWVyYWxkLTQwMCBmb250LXNlbWlib2xkIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5Qb2xvcyBbe3ZhbGlkYXRpb24ucmVxdWlyZWRQb2xlcy5qb2luKCcsICcpfV0gbGlicmVzIHkgZGlzcG9uaWJsZXMgc2luIGNvbGlzacOzbi48L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIEJPVE9ORVMgREUgQUNDRVNPIFLDgVBJRE8gUEFSQSBFU1RBRE8gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBwdC0xXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldEVzdGFkbygnQUNUSVZPJyk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHB5LTEuNSByb3VuZGVkLWxnIGZvbnQtYm9sZCB0ZXh0LVs5cHhdIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBib3JkZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgZXN0YWRvID09PSAnQUNUSVZPJ1xuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC0zMDAgYm9yZGVyLWVtZXJhbGQtNTAwLzQwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04NTAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEFjdGl2b1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRFc3RhZG8oJ1JFU0VSVkEnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Tm9tYnJlQXJ0ZWZhY3RvKCdSRVNFUlZBJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldFJvdHVsbygnUkVTRVJWQScpO1xuICAgICAgICAgICAgICAgICAgICBzZXRCcmVha2VyQW1wKCcnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0RGVzY0FydGVmYWN0bygnJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldFBvdGVuY2lhV2F0dHMoJycpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBweS0xLjUgcm91bmRlZC1sZyBmb250LWJvbGQgdGV4dC1bOXB4XSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYm9yZGVyICR7XG4gICAgICAgICAgICAgICAgICAgIGVzdGFkbyA9PT0gJ1JFU0VSVkEnXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItMzAwIGJvcmRlci1hbWJlci01MDAvNDAnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTg1MCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgTWFyY2FyIGNvbW8gUmVzZXJ2YVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAgey8qIEZMT1cgVEFCTEVSTyBDT01QT05FTlQgKi99XG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHtpc1RhYmxlcm8gJiYgc3RlcCA9PT0gJ1BSRUdVTlRBX0VTX0FSVEVGQUNUTycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxTZXR0aW5ncyBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1hbWJlci01MDAgbXgtYXV0byBtYi0zXCIgLz5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgIMK/RWwgY2lyY3VpdG8gYWxpbWVudGEgYSB1biBlcXVpcG8gbyBhcnRlZmFjdG8gZmluYWw/XG4gICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgIFNlbGVjY2lvbmEgbGEgY2F0ZWdvcsOtYSBkZWwgZWxlbWVudG8gYWxpbWVudGFkbyBwb3IgZXN0YSBzYWxpZGEgZWzDqWN0cmljYS5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKCdGT1JNVUxBUklPX0FSVEVGQUNUTycpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC02IGgtMzYgcm91bmRlZC14bCBib3JkZXItMiBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNTAwLzUgdHJhbnNpdGlvbi1hbGwgdGV4dC1jZW50ZXIgZ3JvdXAgY3Vyc29yLXBvaW50ZXIgYWN0aXZlOnNjYWxlLTk1XCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBtYi0yXCI+8J+UjDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTIwMCBncm91cC1ob3Zlcjp0ZXh0LWFtYmVyLTQwMFwiPlPDrSwgZXMgdW4gQXJ0ZWZhY3RvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgbXQtMVwiPkx1bWluYXJpYXMsIG1vdG9yZXMsIHRvbWFjb3JyaWVudGVzIGRpcmVjdG9zPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoJ1BSRUdVTlRBX0FMSU1FTlRBX09UUk8nKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNiBoLTM2IHJvdW5kZWQteGwgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTUwMC81IHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyIGdyb3VwIGN1cnNvci1wb2ludGVyIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0zeGwgbWItMlwiPuKaoTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTIwMCBncm91cC1ob3Zlcjp0ZXh0LWFtYmVyLTQwMFwiPk5vIGVzIHVuIEFydGVmYWN0bzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIG10LTFcIj5TdWItdGFibGVyb3MsIHJlc2VydmFzLCBkZXJpdmFjaW9uZXM8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBCb3TDs24gZXhwbMOtY2l0byBwYXJhIGRlc3ZpbmN1bGFyIHkgcmV2ZXJ0aXIgYSBSZXNlcnZhICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUmV2ZXJ0aXJBUmVzZXJ2YX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIHB4LTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItYW1iZXItNTAwLzQwIGJnLWFtYmVyLTUwMC8xMCBob3ZlcjpiZy1hbWJlci01MDAvMjAgdGV4dC1hbWJlci0zMDAgZm9udC1ib2xkIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5SZXZlcnRpciBDaXJjdWl0byBhIFwiUmVzZXJ2YVwiIChMaWJlcmFyIENhcmdhIHkgRWxlbWVudG8pPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7aXNUYWJsZXJvICYmIHN0ZXAgPT09ICdGT1JNVUxBUklPX0FSVEVGQUNUTycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcC0zIHJvdW5kZWQtbGcgZmxleCBnYXAtMyBpdGVtcy1jZW50ZXIgbWItMlwiPlxuICAgICAgICAgICAgICAgIDxDbGlwYm9hcmRMaXN0IGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1hbWJlci0zMDAgZm9udC1ib2xkXCI+TGxlbmFyIEZpY2hhIGRlbCBBcnRlZmFjdG8gLyBDaXJjdWl0bzwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgTm9tYnJlIGRlbCBFcXVpcG8gLyBBcnRlZmFjdG9cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bm9tYnJlQXJ0ZWZhY3RvfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5vbWJyZUFydGVmYWN0byhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIEV4dHJhY3RvciBkZSBBaXJlIFPDs3Rhbm8sIE1vdG9yIEJvbWJhIDFcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgdGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hbWJlci01MDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgQnJlYWtlciAoQW1wZXJhamUpXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICBsaXN0PVwibGlzdC1hbXAtb3B0aW9uc1wiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2JyZWFrZXJBbXB9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRCcmVha2VyQW1wKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAyMCwgMzAsIDEwMCwgMjI1Li4uXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgdGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hbWJlci01MDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRhdGFsaXN0IGlkPVwibGlzdC1hbXAtb3B0aW9uc1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtBTVBfT1BUSU9OUy5tYXAob3B0ID0+IDxvcHRpb24ga2V5PXtvcHR9IHZhbHVlPXtvcHR9IC8+KX1cbiAgICAgICAgICAgICAgICAgICAgPC9kYXRhbGlzdD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICBDb25kdWN0b3IgKENhbGlicmUpXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICBsaXN0PVwibGlzdC1jb25kLW9wdGlvbnNcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25kdWN0b3J9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb25kdWN0b3IoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDEyLCAxMCwgOCwgNC8wLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgdGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hbWJlci01MDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRhdGFsaXN0IGlkPVwibGlzdC1jb25kLW9wdGlvbnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7Q09ORF9PUFRJT05TLm1hcChvcHQgPT4gPG9wdGlvbiBrZXk9e29wdH0gdmFsdWU9e29wdH0gLz4pfVxuICAgICAgICAgICAgICAgICAgICA8L2RhdGFsaXN0PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgQnJlYWtlciAoTWFyY2EpXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICBsaXN0PVwibGlzdC1tYXJjYS1vcHRpb25zXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnJlYWtlck1hcmNhfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJlYWtlck1hcmNhKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBHRSwgRUFUT04sIEFCQiwgQ0hJTlQuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC1zbSBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIGJnLXNsYXRlLTk1MCB0ZXh0LXdoaXRlIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFtYmVyLTUwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGF0YWxpc3QgaWQ9XCJsaXN0LW1hcmNhLW9wdGlvbnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7TUFSQ0FfT1BUSU9OUy5tYXAob3B0ID0+IDxvcHRpb24ga2V5PXtvcHR9IHZhbHVlPXtvcHR9IC8+KX1cbiAgICAgICAgICAgICAgICAgICAgPC9kYXRhbGlzdD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICBCcmVha2VyIChUaXBvKVxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgbGlzdD1cImxpc3QtdGlwby1vcHRpb25zXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnJlYWtlclRpcG99XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRCcmVha2VyVGlwbyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gVFEsIFRRRCwgTTM1Li4uXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgdGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hbWJlci01MDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRhdGFsaXN0IGlkPVwibGlzdC10aXBvLW9wdGlvbnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7VElQT19PUFRJT05TLm1hcChvcHQgPT4gPG9wdGlvbiBrZXk9e29wdH0gdmFsdWU9e29wdH0gLz4pfVxuICAgICAgICAgICAgICAgICAgICA8L2RhdGFsaXN0PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgUG90ZW5jaWEgRXN0aW1hZGEgKFdhdHRzKVxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BvdGVuY2lhV2F0dHN9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UG90ZW5jaWFXYXR0cyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDE1MDBcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgdGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hbWJlci01MDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgRmljaGEgVMOpY25pY2EgLyBOb3RhcyBhZGljaW9uYWxlc1xuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGVzY0FydGVmYWN0b31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREZXNjQXJ0ZWZhY3RvKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEZXRhbGxlcyBzb2JyZSBtYXJjYSwgbW9kZWxvIGRlbCBlcXVpcG8sIHViaWNhY2nDs24gZXhhY3RhLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXNtIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgYmctc2xhdGUtOTUwIHRleHQtd2hpdGUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYW1iZXItNTAwIGZvY3VzOm91dGxpbmUtbm9uZSByZXNpemUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJldmVydGlyQVJlc2VydmF9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03NTAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC1hbWJlci00MDAgZm9udC1zZW1pYm9sZCB0ZXh0LXhzIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+UmV2ZXJ0aXIgYSBSZXNlcnZhPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmVBcnRlZmFjdG99XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNUYWJsZXJvICYmICF2YWxpZGF0aW9uLmlzVmFsaWR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtNiBweS0yLjUgcm91bmRlZC1sZyBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgdGV4dC1zbSBzaGFkb3ctbWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtpc1RhYmxlcm8gJiYgIXZhbGlkYXRpb24uaXNWYWxpZCA/ICdSZXNvbHZlciBDb25mbGljdG8gZGUgUG9sb3MnIDogJ0d1YXJkYXIgRmljaGEnfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7aXNUYWJsZXJvICYmIHN0ZXAgPT09ICdQUkVHVU5UQV9BTElNRU5UQV9PVFJPJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPENwdSBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1hbWJlci01MDAgbXgtYXV0byBtYi0zXCIgLz5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgIMK/RWwgY2lyY3VpdG8gYWxpbWVudGEgYSBvdHJvIGVsZW1lbnRvIGRlbCBzaXN0ZW1hP1xuICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICBQb3IgZWplbXBsbzogYWxpbWVudGEgYSB1biBTdWItVGFibGVybyBkZSBkaXN0cmlidWNpw7NuIG8gdGFibGVybyBkZSBjb250cm9sIHNlY3VuZGFyaW8uXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RlcCgnUFJFR1VOVEFfQ1JFQURPJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTYgaC0zMiByb3VuZGVkLXhsIGJvcmRlci0yIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci01MDAvNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIG1iLTFcIj7wn4+iPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc20gdGV4dC1zbGF0ZS0yMDBcIj5Tw60sIGFsaW1lbnRhIGEgb3RybyBlbGVtZW50bzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIG10LTFcIj5Db21vIHVuIFN1Yi1UYWJsZXJvPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoJ1JPVFVMQVJfWV9GT1RPJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTYgaC0zMiByb3VuZGVkLXhsIGJvcmRlci0yIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci01MDAvNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIG1iLTFcIj7wn4+377iPPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc20gdGV4dC1zbGF0ZS0yMDBcIj5Obywgbm8gYWxpbWVudGEgb3RybyBlbGVtZW50bzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIG10LTFcIj5FcyByZXNlcnZhIG8gdmFjw61vPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7aXNUYWJsZXJvICYmIHN0ZXAgPT09ICdQUkVHVU5UQV9DUkVBRE8nICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtYW1iZXItNTAwIG14LWF1dG8gbWItM1wiIC8+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICDCv0VsIGVsZW1lbnRvIGRlIGRlc3Rpbm8geWEgZXN0w6EgY3JlYWRvIGVuIGVsIHNpc3RlbWE/XG4gICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgIENvbmZpcm1hIHNpIGVsIFN1Yi1UYWJsZXJvIHlhIGVzdMOhIHJlZ2lzdHJhZG8gZW4gdHUgbGlzdGFkbyBkZSBpbnNwZWNjacOzbi5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKCdWSU5DVUxBUl9FWElTVEVOVEUnKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNiBoLTMyIHJvdW5kZWQteGwgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTUwMC81IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgbWItMVwiPvCflJc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTIwMFwiPlPDrSwgeWEgZXN0w6EgY3JlYWRvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgbXQtMVwiPkJ1c2NhciB5IHZpbmN1bGFyPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoJ0FMSU1FTlRBUl9QT1JfQ1JFQVInKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNiBoLTMyIHJvdW5kZWQteGwgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTUwMC81IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgbWItMVwiPvCfk508L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTIwMFwiPk5vIGVzdMOhIGNyZWFkbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIG10LTFcIj5Bw7FhZGlyIGEgcGVuZGllbnRlczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHsvKiBGTE9XIFRSQU5TRk9STUFET1IgKFBSSU1BUklPIE1UKSAqL31cbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAgeyFpc1RhYmxlcm8gJiYgdGlwb09yaWdlbiA9PT0gJ1RSQU5TRk9STUFET1InICYmIChzdGVwID09PSAnUFJFR1VOVEFfT1JJR0VOX01UJyB8fCBtb2RvID09PSAnRU5UUkFEQScgfHwgbW9kbyA9PT0gJ1BSSU1BUklBJykgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtYW1iZXItNTAwIG14LWF1dG8gbWItMlwiIC8+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgIMK/RGVzZGUgZMOzbmRlIHNlIGFsaW1lbnRhIGVsIExhZG8gUHJpbWFyaW8gKE1UKT9cbiAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5TZWxlY2Npb25hIGxhIGZ1ZW50ZSBkZSBNZWRpYSBUZW5zacOzbiBkZSBlc3RlIFRyYW5zZm9ybWFkb3IuPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldFJvdHVsbygnUkVEIFDDmkJMSUNBIC8gUE9TVEUgQ09SUE9FTEVDJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldFN0ZXAoJ0ZPUk1VTEFSSU9fUE9URU5DSUFfVFJBTlNGT19NVCcpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAgYmctc2xhdGUtOTUwLzYwIHRleHQtbGVmdCBob3ZlcjpiZy1hbWJlci01MDAvNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBibG9jayBtYi0xXCI+4pqhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5SZWQgUMO6YmxpY2EgLyBDT1JQT0VMRUM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwXCI+QWNvbWV0aWRhIEHDqXJlYSAvIFBvc3RlIE1UPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRSb3R1bG8oJ1NVQkVTVEFDScOTTiBQUklOQ0lQQUwgTVQnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U3RlcCgnRk9STVVMQVJJT19QT1RFTkNJQV9UUkFOU0ZPX01UJyk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTUwMCBiZy1zbGF0ZS05NTAvNjAgdGV4dC1sZWZ0IGhvdmVyOmJnLWFtYmVyLTUwMC81IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGJsb2NrIG1iLTFcIj7wn4+iPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5TdWJlc3RhY2nDs24gUHJpbmNpcGFsIE1UPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTUwMFwiPkJhcnJhIC8gQ2VsZGEgZGUgTVQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldFJvdHVsbygnQ0VMREEgREUgU0VDQ0lPTkFNSUVOVE8gTVQnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U3RlcCgnRk9STVVMQVJJT19QT1RFTkNJQV9UUkFOU0ZPX01UJyk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTUwMCBiZy1zbGF0ZS05NTAvNjAgdGV4dC1sZWZ0IGhvdmVyOmJnLWFtYmVyLTUwMC81IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGJsb2NrIG1iLTFcIj7wn5SMPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5DZWxkYSBTZWNjaW9uYW1pZW50byBNVDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1zbGF0ZS01MDBcIj5JbnRlcnJ1cHRvciBTRjYgLyBWYWPDrW88L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKCdWSU5DVUxBUl9FWElTVEVOVEUnKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAgYmctc2xhdGUtOTUwLzYwIHRleHQtbGVmdCBob3ZlcjpiZy1hbWJlci01MDAvNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBibG9jayBtYi0xXCI+8J+Ulzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtMjAwIGJsb2NrXCI+VmluY3VsYXIgRWxlbWVudG8gQ3JlYWRvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTUwMFwiPkJ1c2NhciBlbiBsYSBsaXN0YSBkZWwgcHJveWVjdG88L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHshaXNUYWJsZXJvICYmIHN0ZXAgPT09ICdGT1JNVUxBUklPX1BPVEVOQ0lBX1RSQU5TRk9fTVQnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwLzEwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIHAtMyByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTMwMFwiPlBhcsOhbWV0cm9zIGRlIEFsaW1lbnRhY2nDs24gUHJpbWFyaWEgTVQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIG1iLTFcIj5OaXZlbCBUZW5zacOzbiBNVDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuaXZlbE1UfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5pdmVsTVQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcC0yIHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMTMuOCBrVlwiPjEzLjgga1Y8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjI0IGtWXCI+MjQga1Y8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjM0LjUga1ZcIj4zNC41IGtWPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCI0LjE2IGtWXCI+NC4xNiBrVjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgbWItMVwiPkNhbGlicmUgQ29uZHVjdG9yIE1UPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25kdWN0b3J9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29uZHVjdG9yKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMS8wIFhMUEUgMTVrVlwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIG1iLTFcIj5GdXNpYmxlIE1UIChDYXBhY2lkYWQvQ3VydmEpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmdXNpYmxlTVR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RnVzaWJsZU1UKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMTVBIEN1cnZhIEtcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcC0yIHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBtYi0xXCI+UGFyYXJyYXlvcyBNVCBJbnN0YWxhZG88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGFyYXJyYXlvc31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXJhcnJheW9zKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlPDrVwiPlPDrTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTm9cIj5Obzwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2F2ZUVxdWlwbWVudChyb3R1bG8gfHwgJ0FMSU1FTlRBQ0nDk04gTVQgQ09SUE9FTEVDJywgJ1NVQkVTVEFDSU9OJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIHJvdW5kZWQteGwgdGV4dC1zbSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBtdC00XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEd1YXJkYXIgQ29uZmlndXJhY2nDs24gTVRcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHsvKiBGTE9XIFRSQU5TRk9STUFET1IgKFNFQ1VOREFSSU8gQlQpICovfVxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgICB7IWlzVGFibGVybyAmJiB0aXBvT3JpZ2VuID09PSAnVFJBTlNGT1JNQURPUicgJiYgKHN0ZXAgPT09ICdQUkVHVU5UQV9ERVNUSU5PX0JUJyB8fCBtb2RvID09PSAnU0VDVU5EQVJJQScpICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8QWN0aXZpdHkgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtYW1iZXItNTAwIG14LWF1dG8gbWItMlwiIC8+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgIMK/SGFjaWEgZMOzbmRlIGVudHJlZ2EgbGEgcG90ZW5jaWEgZWwgTGFkbyBTZWN1bmRhcmlvIChCVCk/XG4gICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+U2VsZWNjaW9uYSBlbCBkZXN0aW5vIGRlIEJhamEgVGVuc2nDs24gYWxpbWVudGFkbyBwb3IgZWwgVHJhbnNmb3JtYWRvci48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0Um90dWxvKCdUQUJMRVJPIEdFTkVSQUwgREUgQlQgKFRHKScpO1xuICAgICAgICAgICAgICAgICAgICBzZXRTdGVwKCdGT1JNVUxBUklPX1BPVEVOQ0lBX1RSQU5TRk9fQlQnKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwIGJnLXNsYXRlLTk1MC82MCB0ZXh0LWxlZnQgaG92ZXI6YmctYW1iZXItNTAwLzUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgYmxvY2sgbWItMVwiPvCfj6I8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC14cyB0ZXh0LXNsYXRlLTIwMCBibG9ja1wiPlRhYmxlcm8gR2VuZXJhbCAoVEcpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTUwMFwiPkRpc3RyaWJ1Y2nDs24gQlQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldFJvdHVsbygnVFJBTlNGRVJFTkNJQSBBVVRPTcOBVElDQSAoQVRTKScpO1xuICAgICAgICAgICAgICAgICAgICBzZXRTdGVwKCdGT1JNVUxBUklPX1BPVEVOQ0lBX1RSQU5TRk9fQlQnKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwIGJnLXNsYXRlLTk1MC82MCB0ZXh0LWxlZnQgaG92ZXI6YmctYW1iZXItNTAwLzUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgYmxvY2sgbWItMVwiPvCflIQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC14cyB0ZXh0LXNsYXRlLTIwMCBibG9ja1wiPlRyYW5zZmVyZW5jaWEgKEFUUyk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwXCI+RW50cmFkYSBGdWVudGUgTm9ybWFsPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRSb3R1bG8oJ0NFTlRSTyBDT05UUk9MIERFIE1PVE9SRVMgKENDTSknKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U3RlcCgnRk9STVVMQVJJT19QT1RFTkNJQV9UUkFOU0ZPX0JUJyk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTUwMCBiZy1zbGF0ZS05NTAvNjAgdGV4dC1sZWZ0IGhvdmVyOmJnLWFtYmVyLTUwMC81IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGJsb2NrIG1iLTFcIj7impnvuI88L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC14cyB0ZXh0LXNsYXRlLTIwMCBibG9ja1wiPkNDTSBJbmR1c3RyaWFsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTUwMFwiPkFsaW1lbnRhY2nDs24gZGUgTW90b3Jlczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoJ1ZJTkNVTEFSX0VYSVNURU5URScpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTUwMCBiZy1zbGF0ZS05NTAvNjAgdGV4dC1sZWZ0IGhvdmVyOmJnLWFtYmVyLTUwMC81IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGJsb2NrIG1iLTFcIj7wn5SXPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5WaW5jdWxhciBFbGVtZW50byBDcmVhZG88L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwXCI+QnVzY2FyIGVuIGVsIHByb3llY3RvPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7IWlzVGFibGVybyAmJiBzdGVwID09PSAnRk9STVVMQVJJT19QT1RFTkNJQV9UUkFOU0ZPX0JUJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWFtYmVyLTUwMC8xMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBwLTMgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxBY3Rpdml0eSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTMwMFwiPlBhcsOhbWV0cm9zIGRlIERpc3RyaWJ1Y2nDs24gQlQgKFNlY3VuZGFyaW8pPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBtYi0xXCI+VGVuc2nDs24gU2VjdW5kYXJpYSBCVDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW5zaW9uU2VjdW5kYXJpYX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUZW5zaW9uU2VjdW5kYXJpYShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIyMDgvMTIwVlwiPjIwOC8xMjAgVjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiNDgwLzI3N1ZcIj40ODAvMjc3IFY8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjM4MC8yMjBWXCI+MzgwLzIyMCBWPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBtYi0xXCI+Q29uZmlndXJhY2nDs24gQ29uZHVjdG9yZXM8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbmR1Y3Rvcn1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb25kdWN0b3IoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAzKDR4NTAwIE1DTSlcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcC0yIHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBtYi0xXCI+Q2FuYWxpemFjacOzbiBkZSBTYWxpZGE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FuYWxpemFjaW9ufVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENhbmFsaXphY2lvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJCYW5kZWphIFBvcnRhY2FibGVzXCI+QmFuZGVqYSBQb3J0YWNhYmxlczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVHViZXLDrWEgQ29uZHVpdFwiPlR1YmVyw61hIENvbmR1aXQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRyaW5jaGVyYSBTdWJ0ZXJyw6FuZWFcIj5UcmluY2hlcmEgU3VidGVycsOhbmVhPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBtYi0xXCI+Q2FwYWNpZGFkIEJyZWFrZXIgQWd1YXMgQWJham88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ludGVycnVwdG9yQWd1YXNBYmFqb31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRJbnRlcnJ1cHRvckFndWFzQWJham8oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAxNjAwIEFcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcC0yIHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTYXZlRXF1aXBtZW50KHJvdHVsbyB8fCAnU0FMSURBIFNFQ1VOREFSSUEgQlQnLCAnVEFCTEVSTycpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ibGFjayByb3VuZGVkLXhsIHRleHQtc20gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgbXQtNFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBHdWFyZGFyIENvbmZpZ3VyYWNpw7NuIEJUXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgICB7LyogRkxPVyBHRU5FUkFET1IgKi99XG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHshaXNUYWJsZXJvICYmIHRpcG9PcmlnZW4gPT09ICdHRU5FUkFET1InICYmIChzdGVwID09PSAnUFJFR1VOVEFfREVTVElOT19HRU4nIHx8IHN0ZXAgPT09ICdGT1JNVUxBUklPX1BPVEVOQ0lBX0dFTicpICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICAgIHtzdGVwID09PSAnUFJFR1VOVEFfREVTVElOT19HRU4nICYmIChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8UmFkaW8gY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtYW1iZXItNTAwIG14LWF1dG8gbWItMlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgwr9BIHF1w6kgZXF1aXBvIGFsaW1lbnRhIGVsIHJlc3BhbGRvIGRlbCBHZW5lcmFkb3I/XG4gICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5EZWZpbmUgZWwgZGVzdGlubyBkZSBsYSBwb3RlbmNpYSBkZSBlbWVyZ2VuY2lhLjwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRSb3R1bG8oJ1RSQU5TRkVSRU5DSUEgQVVUT03DgVRJQ0EgKEFUUyknKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFN0ZXAoJ0ZPUk1VTEFSSU9fUE9URU5DSUFfR0VOJyk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwIGJnLXNsYXRlLTk1MC82MCB0ZXh0LWxlZnQgaG92ZXI6YmctYW1iZXItNTAwLzUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBibG9jayBtYi0xXCI+8J+UhDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC14cyB0ZXh0LXNsYXRlLTIwMCBibG9ja1wiPlRyYW5zZmVyZW5jaWEgQVRTPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1zbGF0ZS01MDBcIj5Db25tdXRhY2nDs24gQXV0b23DoXRpY2E8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Um90dWxvKCdUUkFOU0ZFUkVOQ0lBIE1BTlVBTCAoTVRTKScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U3RlcCgnRk9STVVMQVJJT19QT1RFTkNJQV9HRU4nKTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAgYmctc2xhdGUtOTUwLzYwIHRleHQtbGVmdCBob3ZlcjpiZy1hbWJlci01MDAvNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGJsb2NrIG1iLTFcIj7wn5SAPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtMjAwIGJsb2NrXCI+VHJhbnNmZXJlbmNpYSBNYW51YWwgKE1UUyk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTUwMFwiPkNvbm11dGFjacOzbiBNYW51YWw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Um90dWxvKCdUQUJMRVJPIERFIEVNRVJHRU5DSUEnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFN0ZXAoJ0ZPUk1VTEFSSU9fUE9URU5DSUFfR0VOJyk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwIGJnLXNsYXRlLTk1MC82MCB0ZXh0LWxlZnQgaG92ZXI6YmctYW1iZXItNTAwLzUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBibG9jayBtYi0xXCI+4pqhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtMjAwIGJsb2NrXCI+VGFibGVybyBFbWVyZ2VuY2lhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1zbGF0ZS01MDBcIj5BbGltZW50YWNpw7NuIERpcmVjdGE8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RlcCgnVklOQ1VMQVJfRVhJU1RFTlRFJyl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTUwMCBiZy1zbGF0ZS05NTAvNjAgdGV4dC1sZWZ0IGhvdmVyOmJnLWFtYmVyLTUwMC81IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgYmxvY2sgbWItMVwiPvCflJc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5WaW5jdWxhciBFbGVtZW50byBDcmVhZG88L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTUwMFwiPkJ1c2NhciBlbiBlbCBwcm95ZWN0bzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7c3RlcCA9PT0gJ0ZPUk1VTEFSSU9fUE9URU5DSUFfR0VOJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwLzEwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIHAtMyByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxSYWRpbyBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1hbWJlci0zMDBcIj5QYXLDoW1ldHJvcyBkZWwgR2VuZXJhZG9yIC8gUmVzcGFsZG88L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBtYi0xXCI+Q2FwYWNpZGFkIEJyZWFrZXIgR2VuZXJhZG9yPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXticmVha2VyQW1wfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRCcmVha2VyQW1wKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDgwMCBBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBtYi0xXCI+Q29uZHVjdG9yIGRlIEZ1ZXJ6YSBSZXNwYWxkbzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29uZHVjdG9yfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb25kdWN0b3IoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMigzeDUwMCBNQ00pXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBtYi0xXCI+U2XDsWFsIEFycmFucXVlIENhYmxlYWRhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VuYWxBcnJhbnF1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VuYWxBcnJhbnF1ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcC0yIHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTw60gLSBDYWJsZWFkbyAyNFZEQ1wiPlPDrSAtIENhYmxlYWRvIDI0VkRDPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU8OtIC0gTW9kYnVzL0NvbW1zXCI+U8OtIC0gTW9kYnVzL0NvbW1zPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTm8gLSBBcnJhbnF1ZSBNYW51YWxcIj5ObyAtIEFycmFucXVlIE1hbnVhbDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIG1iLTFcIj5Qb3RlbmNpYSBSZXNwYWxkbyAoa1ZBL2tXKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cG90ZW5jaWFLdmFLd31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UG90ZW5jaWFLdmFLdyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiA1ODAga1ZBIC8gNDYwIGtXXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNhdmVFcXVpcG1lbnQocm90dWxvIHx8ICdTQUxJREEgUExBTlRBIEdFTkVSQUNJw5NOJywgJ0dFTkVSQURPUicpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMyBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgcm91bmRlZC14bCB0ZXh0LXNtIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIG10LTRcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBHdWFyZGFyIENvbmZpZ3VyYWNpw7NuIEdlbmVyYWRvclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHsvKiBGTE9XIFRSQU5TRkVSRU5DSUEgKEFUUykgKi99XG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHshaXNUYWJsZXJvICYmIHRpcG9PcmlnZW4gPT09ICdUUkFOU0ZFUicgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgeyhzdGVwID09PSAnUFJFR1VOVEFfRlVFTlRFX0FUUzEnIHx8IHN0ZXAgPT09ICdQUkVHVU5UQV9GVUVOVEVfQVRTMicgfHwgc3RlcCA9PT0gJ1BSRUdVTlRBX0RFU1RJTk9fQVRTJykgJiYgKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1hbWJlci01MDAgbXgtYXV0byBtYi0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBDb25maWd1cmFjacOzbiBkZSBDb25leGnDs24gZGUgVHJhbnNmZXJlbmNpYSAoQVRTKVxuICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+U2VsZWNjaW9uYSBsYSBmdWVudGUgbyBjYXJnYSBhIGNvbmZpZ3VyYXIgZW4gZWwgY29ubXV0YWRvci48L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Um90dWxvKCdGVUVOVEUgMSAtIFJFRCBQUklOQ0lQQUwnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFN0ZXAoJ0ZPUk1VTEFSSU9fUE9URU5DSUFfQVRTJyk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwIGJnLXNsYXRlLTk1MC82MCB0ZXh0LWxlZnQgaG92ZXI6YmctYW1iZXItNTAwLzUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBibG9jayBtYi0xXCI+4pqhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtMjAwIGJsb2NrXCI+RnVlbnRlIDEgKFJlZCBOb3JtYWwpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1zbGF0ZS01MDBcIj5UcmFuc2Zvcm1hZG9yIC8gU3ViZXN0YWNpw7NuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFJvdHVsbygnRlVFTlRFIDIgLSBHRU5FUkFET1IgUkVTUEFMRE8nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFN0ZXAoJ0ZPUk1VTEFSSU9fUE9URU5DSUFfQVRTJyk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwIGJnLXNsYXRlLTk1MC82MCB0ZXh0LWxlZnQgaG92ZXI6YmctYW1iZXItNTAwLzUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBibG9jayBtYi0xXCI+8J+Tuzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC14cyB0ZXh0LXNsYXRlLTIwMCBibG9ja1wiPkZ1ZW50ZSAyIChFbWVyZ2VuY2lhKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwXCI+UGxhbnRhIEVsw6ljdHJpY2E8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Um90dWxvKCdTQUxJREEgQSBDQVJHQVMgUkVTUEFMREFEQVMnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFN0ZXAoJ0ZPUk1VTEFSSU9fUE9URU5DSUFfQVRTX1NBTElEQScpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTUwMCBiZy1zbGF0ZS05NTAvNjAgdGV4dC1sZWZ0IGhvdmVyOmJnLWFtYmVyLTUwMC81IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgYmxvY2sgbWItMVwiPvCfj6I8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5TYWxpZGEgYSBDYXJnYXM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTUwMFwiPlRhYmxlcm8gUHJpbmNpcGFsIC8gQ0NNPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoJ1ZJTkNVTEFSX0VYSVNURU5URScpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAgYmctc2xhdGUtOTUwLzYwIHRleHQtbGVmdCBob3ZlcjpiZy1hbWJlci01MDAvNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGJsb2NrIG1iLTFcIj7wn5SXPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtMjAwIGJsb2NrXCI+VmluY3VsYXIgRWxlbWVudG8gQ3JlYWRvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1zbGF0ZS01MDBcIj5CdXNjYXIgZW4gZWwgcHJveWVjdG88L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAge3N0ZXAgPT09ICdGT1JNVUxBUklPX1BPVEVOQ0lBX0FUUycgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWFtYmVyLTUwMC8xMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBwLTMgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtYW1iZXItMzAwXCI+UGFyw6FtZXRyb3MgZGUgRnVlbnRlIEFUUzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIG1iLTFcIj5Db25kdWN0b3IgZGUgQWNvbWV0aWRhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25kdWN0b3J9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbmR1Y3RvcihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAzeDUwMCBNQ01cIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIG1iLTFcIj5UaXBvIGRlIENvbm11dGFkb3I8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0aXBvQ29ubXV0YWRvcn1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGlwb0Nvbm11dGFkb3IoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTW90b3JpemFkbyBJbnRlcmxvY2tlZFwiPk1vdG9yaXphZG8gSW50ZXJsb2NrZWQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDb250YWN0b3JlcyBNZWPDoW5pY29zXCI+Q29udGFjdG9yZXMgTWVjw6FuaWNvczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkVzdMOhdGljbyBTVFNcIj5Fc3TDoXRpY28gU1RTPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTYXZlRXF1aXBtZW50KHJvdHVsbyB8fCAnRlVFTlRFIEFUUycsICdUUkFOU0ZFUicpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMyBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgcm91bmRlZC14bCB0ZXh0LXNtIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIG10LTRcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBHdWFyZGFyIEZ1ZW50ZSBBVFNcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHtzdGVwID09PSAnRk9STVVMQVJJT19QT1RFTkNJQV9BVFNfU0FMSURBJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwLzEwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIHAtMyByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1hbWJlci0zMDBcIj5QYXLDoW1ldHJvcyBkZSBTYWxpZGEgLyBDYXJnYXMgQVRTPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgbWItMVwiPkNvcnJpZW50ZSBOb21pbmFsIEFUUzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnJlYWtlckFtcH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJlYWtlckFtcChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAxNjAwIEFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIG1iLTFcIj5FbmNsYXZhbWllbnRvIFZlcmlmaWNhZG88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXJhcnJheW9zfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXJhcnJheW9zKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk1lY8OhbmljbyB5IEVsw6ljdHJpY29cIj5NZWPDoW5pY28geSBFbMOpY3RyaWNvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU29sbyBFbMOpY3RyaWNvXCI+U29sbyBFbMOpY3RyaWNvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUGVuZGllbnRlXCI+UGVuZGllbnRlPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTYXZlRXF1aXBtZW50KHJvdHVsbyB8fCAnU0FMSURBIEFUUyBBIENBUkdBUycsICdUQUJMRVJPJyl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ibGFjayByb3VuZGVkLXhsIHRleHQtc20gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgbXQtNFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEd1YXJkYXIgU2FsaWRhIEFUU1xuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHsvKiBGTE9XIENDTSAoQ0VOVFJPIENPTlRST0wgREUgTU9UT1JFUykgKi99XG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHshaXNUYWJsZXJvICYmIHRpcG9PcmlnZW4gPT09ICdDQ00nICYmIChzdGVwID09PSAnUFJFR1VOVEFfQ0FSR0FfQ0NNJyB8fCBzdGVwID09PSAnRk9STVVMQVJJT19HQVZFVEFfQ0NNJykgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAge3N0ZXAgPT09ICdQUkVHVU5UQV9DQVJHQV9DQ00nICYmIChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8TGF5ZXJzIGNsYXNzTmFtZT1cInctMTIgaC0xMiB0ZXh0LWFtYmVyLTUwMCBteC1hdXRvIG1iLTJcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIMK/UXXDqSB0aXBvIGRlIGNhcmdhIGluZHVzdHJpYWwgYWNjaW9uYSBlc3RhIEdhdmV0YSAvIEJ1Y2tldD9cbiAgICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlNlbGVjY2lvbmEgZWwgdXNvIGRlbCBtb3RvciBvIGNhcmdhIGFsaW1lbnRhZGEuPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFJvdHVsbygnQk9NQkEgREUgQUdVQVBPVEFCTEUgLyBQUk9DRVNPJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTdGVwKCdGT1JNVUxBUklPX0dBVkVUQV9DQ00nKTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAgYmctc2xhdGUtOTUwLzYwIHRleHQtbGVmdCBob3ZlcjpiZy1hbWJlci01MDAvNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGJsb2NrIG1iLTFcIj7wn5qwPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtMjAwIGJsb2NrXCI+Qm9tYmEgZGUgQWd1YTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwXCI+SGlkcm9uZXVtw6F0aWNvIC8gUHJvY2Vzbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRSb3R1bG8oJ0NPTVBSRVNPUiBERSBBSVJFJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTdGVwKCdGT1JNVUxBUklPX0dBVkVUQV9DQ00nKTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAgYmctc2xhdGUtOTUwLzYwIHRleHQtbGVmdCBob3ZlcjpiZy1hbWJlci01MDAvNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGJsb2NrIG1iLTFcIj7wn4yAPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtMjAwIGJsb2NrXCI+Q29tcHJlc29yPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1zbGF0ZS01MDBcIj5OZXVtw6F0aWNvIC8gRnLDrW88L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Um90dWxvKCdFWFRSQUNUT1IgLyBWRU5USUxBQ0nDk04nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFN0ZXAoJ0ZPUk1VTEFSSU9fR0FWRVRBX0NDTScpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTUwMCBiZy1zbGF0ZS05NTAvNjAgdGV4dC1sZWZ0IGhvdmVyOmJnLWFtYmVyLTUwMC81IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgYmxvY2sgbWItMVwiPvCfkqg8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5FeHRyYWN0b3IgLyBWZW50aWxhY2nDs248L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTUwMFwiPlRpcm8gRm9yemFkbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRSb3R1bG8oJ0JBTkRBIFRSQU5TUE9SVEFET1JBJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTdGVwKCdGT1JNVUxBUklPX0dBVkVUQV9DQ00nKTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAgYmctc2xhdGUtOTUwLzYwIHRleHQtbGVmdCBob3ZlcjpiZy1hbWJlci01MDAvNSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGJsb2NrIG1iLTFcIj7impnvuI88L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5CYW5kYSAvIEFnaXRhZG9yPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1zbGF0ZS01MDBcIj5Qcm9jZXNvIENvbnRpbnVvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHtzdGVwID09PSAnRk9STVVMQVJJT19HQVZFVEFfQ0NNJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwLzEwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIHAtMyByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxMYXllcnMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtYW1iZXItMzAwXCI+RmljaGEgVMOpY25pY2EgZGUgR2F2ZXRhIENDTTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgbWItMVwiPlRhZyAvIE5vbWJyZSBkZWwgRXF1aXBvPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyb3R1bG99XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJvdHVsbyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBCb21iYSBkZSBBZ3VhIDFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgbWItMVwiPkVzcXVlbWEgZGUgQXJyYW5xdWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZXNxdWVtYUFycmFucXVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVzcXVlbWFBcnJhbnF1ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJEaXJlY3RvIChET0wpXCI+RGlyZWN0byAoRE9MKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRXN0cmVsbGEtVHJpw6FuZ3Vsb1wiPkVzdHJlbGxhLVRyacOhbmd1bG88L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlZhcmlhZG9yIGRlIEZyZWN1ZW5jaWEgKFZGRClcIj5WYXJpYWRvciBkZSBGcmVjdWVuY2lhIChWRkQpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBcnJhbmNhZG9yIFN1YXZlIChTb2Z0IFN0YXJ0ZXIpXCI+QXJyYW5jYWRvciBTdWF2ZSAoU29mdCBTdGFydGVyKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgbWItMVwiPlBvdGVuY2lhIE1vdG9yIChIUC9rVyk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2hwS3d9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SHBLdyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDI1IEhQXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBtYi0xXCI+UHJvdGVjY2nDs24gLyBHdWFyZGFtb3RvcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cHJvdGVjY2lvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQcm90ZWNjaW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gR3VhcmRhbW90b3IgMzJBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgbWItMVwiPlJlZCAvIENvbW1zIENvbnRyb2w8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JlZENvbW1zfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlZENvbW1zKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gTW9kYnVzIFJUVSAvIEV0aGVybmV0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTYXZlRXF1aXBtZW50KHJvdHVsbyB8fCAnR0FWRVRBIE1PVE9SJywgJ0FSVEVGQUNUTycsIHsgZXNxdWVtYUFycmFucXVlLCBocEt3LCBwcm90ZWNjaW9uLCByZWRDb21tcyB9KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIHJvdW5kZWQteGwgdGV4dC1zbSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBtdC00XCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgR3VhcmRhciBGaWNoYSBHYXZldGEgQ0NNXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAgey8qIEZMT1cgUFVOVE8gTUVESUNJw5NOICovfVxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgICB7IWlzVGFibGVybyAmJiB0aXBvT3JpZ2VuID09PSAnUFVOVE9fTUVESUNJT04nICYmIChzdGVwID09PSAnUFJFR1VOVEFfT1JJR0VOX01FRElDSU9OJyB8fCBzdGVwID09PSAnRk9STVVMQVJJT19NRURJQ0lPTicpICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwLzEwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIHAtMyByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPEdhdWdlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtYW1iZXItMzAwXCI+Q29uZmlndXJhY2nDs24gQWNvbWV0aWRhIE1lZGlkYTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgbWItMVwiPlJlbGFjacOzbiBUQ3MgKENvcnJpZW50ZSk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JlbGFjaW9uVGN9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVsYWNpb25UYyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDgwMC81QVwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZSBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCBtYi0xXCI+UmVsYWNpw7NuIFRQcyAoVGVuc2nDs24pPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyZWxhY2lvblRwfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlbGFjaW9uVHAoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAxMzgwMC8xMjBWIG8gTi9BXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNhdmVFcXVpcG1lbnQoJ1BVTlRPIERFIENPTkVYScOTTiBQQ0MgLyBBQ09NRVRJREEnLCAnUFVOVE9fTUVESUNJT04nLCB7IHJlbGFjaW9uVGMsIHJlbGFjaW9uVHAgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIHJvdW5kZWQteGwgdGV4dC1zbSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBtdC00XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEd1YXJkYXIgQWNvbWV0aWRhIE1lZGljacOzblxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAgey8qIEZMT1cgUFVFU1RBIEEgVElFUlJBICovfVxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgICB7IWlzVGFibGVybyAmJiB0aXBvT3JpZ2VuID09PSAnUFVFU1RBX1RJRVJSQScgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcC0zIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1hbWJlci0zMDBcIj5Db25leGnDs24gYSBNYWxsYSBkZSBQdWVzdGEgYSBUaWVycmE8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIG1iLTFcIj5Db25kdWN0b3IgZGUgVGllcnJhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25kdWN0b3J9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29uZHVjdG9yKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gNC8wIEFXRyBEZXNudWRvXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIG1iLTFcIj5SZXNpc3RlbmNpYSBNZWRpZGEgKM6pKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cmVzaXN0ZW5jaWFPaG1zfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlc2lzdGVuY2lhT2htcyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDIuNSDOqVwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZSBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTYXZlRXF1aXBtZW50KCdNQUxMQSBQVUVTVEEgQSBUSUVSUkEnLCAnUFVFU1RBX1RJRVJSQScsIHsgcmVzaXN0ZW5jaWFPaG1zIH0pfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ibGFjayByb3VuZGVkLXhsIHRleHQtc20gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgbXQtNFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBHdWFyZGFyIENvbmV4acOzbiBUaWVycmFcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHsvKiBCVVNDQURPUiBERSBFTEVNRU5UT1MgRVhJU1RFTlRFUyAoQ09NUEFSVElETykgKi99XG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHtzdGVwID09PSAnVklOQ1VMQVJfRVhJU1RFTlRFJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICB7cmVuZGVyVW5pdmVyc2FsRWxlbWVudFNlbGVjdG9yKCl9XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAge2lzTXVsdGlTZWxlY3QgPyAnTyBCdXNjYXIgRWxlbWVudG8ocykgZW4gZWwgUHJveWVjdG8nIDogJ08gQnVzY2FyIHBvciBUZXh0byAvIElEIGVuIGVsIFByb3llY3RvJ31cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIHtpc011bHRpU2VsZWN0ICYmIChcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYW1iZXItNDAwIGZvbnQtc2VtaWJvbGQgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICDinJMgUHVlZGVzIHNlbGVjY2lvbmFyIHZhcmlvcyBlbGVtZW50b3MgYWxpbWVudGFkb3MgcG9yIGVzdGEgYWNvbWV0aWRhIHNlY3VuZGFyaWEuXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzTXVsdGlTZWxlY3QpIHNldFNlbGVjdGVkTGluayhudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFc2NyaWJlIGVsIG5vbWJyZSBvIElEIGRlbCBlbGVtZW50by4uLlwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC0xMCBwci00IHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgdGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hbWJlci01MDAgZm9jdXM6b3V0bGluZS1ub25lIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwidy01IGgtNSBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTIuNSB0ZXh0LXNsYXRlLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBtYXgtaC00OCBvdmVyZmxvdy15LWF1dG8gZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTgwMCBiZy1zbGF0ZS05NTBcIj5cbiAgICAgICAgICAgICAgICB7ZmlsdGVyZWRFbGVtZW50cy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICAgICAgZmlsdGVyZWRFbGVtZW50cy5tYXAoKGVsKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBpc011bHRpU2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgPyBzZWxlY3RlZExpbmtzLnNvbWUoaXRlbSA9PiBpdGVtLmlkID09PSBlbC5pZClcbiAgICAgICAgICAgICAgICAgICAgICA6IHNlbGVjdGVkTGluaz8uaWQgPT09IGVsLmlkIHx8IHNlbGVjdGVkRWxlbWVudG9EZXN0aW5vSWQgPT09IGVsLmlkO1xuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtlbC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNNdWx0aVNlbGVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZExpbmtzLnNvbWUoaXRlbSA9PiBpdGVtLmlkID09PSBlbC5pZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkTGlua3Moc2VsZWN0ZWRMaW5rcy5maWx0ZXIoaXRlbSA9PiBpdGVtLmlkICE9PSBlbC5pZCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZExpbmtzKFsuLi5zZWxlY3RlZExpbmtzLCBlbF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZExpbmsoZWwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRWxlbWVudG9EZXN0aW5vSWQoZWwuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkVGlwb0VsZW1lbnRvRGVzdGlubyhlbC50aXBvIHx8IGVsLnRpcG9FbGVtZW50byB8fCAnVEFCTEVSTycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlYXJjaFF1ZXJ5KGVsLm5vbWJyZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgdGV4dC1sZWZ0IHB4LTQgcHktMi41IHRleHQtc20gaG92ZXI6Ymctc2xhdGUtOTAwIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkID8gJ2JnLWFtYmVyLTUwMC8xMCBob3ZlcjpiZy1hbWJlci01MDAvMTUnIDogJydcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2lzTXVsdGlTZWxlY3QgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4ge319XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IGFjY2VudC1hbWJlci01MDAgcm91bmRlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMjAwXCI+e2VsLm5vbWJyZX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci01MDAgZm9udC1tb25vXCI+SUQ6IHtlbC5pZH0ge2VsLnRpcG8gPyBg4oCiIFske2VsLnRpcG99XWAgOiAnJ308L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNTZWxlY3RlZCAmJiA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBObyBzZSBlbmNvbnRyYXJvbiBlbGVtZW50b3MgY29uIGVzZSBub21icmUuXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2F2ZVZpbmN1bG8oKX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXsoaXNNdWx0aVNlbGVjdCA/IHNlbGVjdGVkTGlua3MubGVuZ3RoID09PSAwIDogKCFzZWxlY3RlZExpbmsgJiYgIXNlbGVjdGVkRWxlbWVudG9EZXN0aW5vSWQpKSB8fCAoaXNUYWJsZXJvICYmICF2YWxpZGF0aW9uLmlzVmFsaWQpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yLjUgcm91bmRlZC1sZyBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgdGV4dC1zbSBzaGFkb3ctbWQgdHJhbnNpdGlvbi1jb2xvcnMgdy1mdWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7aXNUYWJsZXJvICYmICF2YWxpZGF0aW9uLmlzVmFsaWRcbiAgICAgICAgICAgICAgICAgICAgPyAnUmVzb2x2ZXIgQ29uZmxpY3RvIGRlIFBvbG9zIHBhcmEgR3VhcmRhcidcbiAgICAgICAgICAgICAgICAgICAgOiBpc011bHRpU2VsZWN0XG4gICAgICAgICAgICAgICAgICAgID8gYFZpbmN1bGFyICR7c2VsZWN0ZWRMaW5rcy5sZW5ndGh9IEVsZW1lbnRvJHtzZWxlY3RlZExpbmtzLmxlbmd0aCA9PT0gMSA/ICcnIDogJ3MnfSB5IEd1YXJkYXJgXG4gICAgICAgICAgICAgICAgICAgIDogJ1ZpbmN1bGFyIHkgR3VhcmRhcid9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgICB7LyogQUdSRUdBUiBBIExBIExJU1RBIFBPUiBDUkVBUiAoQ09NUEFSVElETykgKi99XG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHtzdGVwID09PSAnQUxJTUVOVEFSX1BPUl9DUkVBUicgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgYmctYW1iZXItNTAwLzEwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwXCI+XG4gICAgICAgICAgICAgICAgPFBsdXNDaXJjbGUgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHRleHQtYW1iZXItNTAwXCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgIMK/QWdyZWdhciBhIGxhIExpc3RhIGRlIEVsZW1lbnRvcyBwb3IgQ3JlYXI/XG4gICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTIgcHgtNCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgIEFsIGNvbmZpcm1hciwgc2UgcmVnaXN0cmFyw6EgdW5hIHRhcmVhIHBlbmRpZW50ZSBwYXJhIGNyZWFyIGVzdGUgbnVldm8gU3ViLUVsZW1lbnRvIGVuIGVsIHByb3llY3RvLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZVBvckNyZWFyfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVGFibGVybyAmJiAhdmFsaWRhdGlvbi5pc1ZhbGlkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0zIHJvdW5kZWQtbGcgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIHRleHQtc20gc2hhZG93LW1kIHRyYW5zaXRpb24tY29sb3JzIHctZnVsbCBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtWzAuOThdXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7aXNUYWJsZXJvICYmICF2YWxpZGF0aW9uLmlzVmFsaWQgPyAnUmVzb2x2ZXIgQ29uZmxpY3RvIGRlIFBvbG9zJyA6ICdBZ3JlZ2FyIGEgbGEgTGlzdGEgZGUgUGVuZGllbnRlcyd9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgICAgICB7LyogUk9UVUxBUiBZIEZPVE8gKENPTVBBUlRJRE8gUEFSQSBUQUJMRVJPUykgKi99XG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHtpc1RhYmxlcm8gJiYgc3RlcCA9PT0gJ1JPVFVMQVJfWV9GT1RPJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICAgICAgICB7LyogU2VsZWN0b3IgVW5pdmVyc2FsIGRlIEVsZW1lbnRvcyAqL31cbiAgICAgICAgICAgICAge3JlbmRlclVuaXZlcnNhbEVsZW1lbnRTZWxlY3RvcigpfVxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIFLDs3R1bG8gZGVsIENpcmN1aXRvIC8gRGVzY3JpcGNpw7NuXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtyb3R1bG99XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJvdHVsbyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBSRVNFUlZBLCBWQUPDjU8sIEFMSU1FTlRBQ0nDk04gQSBDQ00tMDFcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXNtIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgYmctc2xhdGUtOTUwIHRleHQtd2hpdGUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYW1iZXItNTAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgQ29uZHVjdG9yIChDYWxpYnJlIG9wY2lvbmFsKVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbmR1Y3Rvcn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29uZHVjdG9yKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC1zbSBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIGJnLXNsYXRlLTk1MCB0ZXh0LXdoaXRlIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFtYmVyLTUwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtDT05EX09QVElPTlMubWFwKG9wdCA9PiA8b3B0aW9uIGtleT17b3B0fSB2YWx1ZT17b3B0fT57b3B0fTwvb3B0aW9uPil9XG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgIEZvdG9ncmFmw61hIGRlIEV2aWRlbmNpYSAvIENpcmN1aXRvXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8RHVhbFBob3RvVXBsb2FkZXJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3RvVXJsfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldEZvdG9VcmwodmFsKX1cbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiRm90b2dyYWbDrWEgZGVsIENpcmN1aXRvIG8gQnJlYWtlclwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmVSb3R1bG9Gb3RvfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVGFibGVybyAmJiAhdmFsaWRhdGlvbi5pc1ZhbGlkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yLjUgcm91bmRlZC1sZyBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgdGV4dC1zbSBzaGFkb3ctbWQgdHJhbnNpdGlvbi1jb2xvcnMgdy1mdWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7aXNUYWJsZXJvICYmICF2YWxpZGF0aW9uLmlzVmFsaWQgPyAnUmVzb2x2ZXIgQ29uZmxpY3RvIGRlIFBvbG9zIHBhcmEgR3VhcmRhcicgOiAnR3VhcmRhciBDYW1iaW9zJ31cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBNb2RhbEVkaWNpb25DaXJjdWl0bztcbiJdfQ==