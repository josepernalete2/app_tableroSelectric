import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/LoginView.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { Zap, ShieldCheck, Loader2, AlertCircle, WifiOff, Eye, EyeOff } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/LoginView.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export const LoginView = () => {
	_s();
	const [username, setUsername] = useState("");
	const [password, setPassword] = useState("");
	const [showPassword, setShowPassword] = useState(false);
	const [error, setError] = useState("");
	const [isNetworkError, setIsNetworkError] = useState(false);
	const [isLoading, setIsLoading] = useState(false);
	const login = useStore((state) => state.login);
	const navigate = useNavigate();
	const handleSubmit = async (e) => {
		e.preventDefault();
		setError("");
		setIsNetworkError(false);
		if (!username || !password) {
			setError("Por favor, ingresa tus credenciales.");
			return;
		}
		if (username.trim().length >= 3 && password.length >= 4) {
			setIsLoading(true);
			try {
				const result = await login(username.trim(), password);
				if (result.success) {
					navigate("/");
				} else {
					setError(result.error);
					setIsNetworkError(Boolean(result.isNetworkError));
				}
			} catch (err) {
				setError(err.message || "Error inesperado al iniciar sesión.");
			} finally {
				setIsLoading(false);
			}
		} else {
			setError("El usuario debe tener al menos 3 caracteres y la contraseña al menos 4 caracteres.");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 flex items-center justify-center p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl p-8 shadow-2xl flex flex-col justify-between",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-center space-y-2 mb-8",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex bg-amber-500 text-slate-950 p-3 rounded-2xl shadow-lg shadow-amber-500/20 mb-2",
							children: /* @__PURE__ */ _jsxDEV(Zap, { className: "w-8 h-8 fill-slate-950" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-2xl font-bold tracking-tight bg-gradient-to-r from-amber-400 to-amber-200 bg-clip-text text-transparent",
							children: "TableroSelectric Pro"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-slate-400",
							children: "Plataforma Profesional de Inspección de Tableros"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleSubmit,
					className: "space-y-6",
					children: [
						error && /* @__PURE__ */ _jsxDEV("div", {
							className: `p-4 rounded-xl text-xs flex items-start gap-2.5 leading-relaxed ${isNetworkError ? "bg-amber-950/40 border border-amber-800/80 text-amber-300" : "bg-red-950/40 border border-red-800/80 text-red-400"}`,
							children: [isNetworkError ? /* @__PURE__ */ _jsxDEV(WifiOff, { className: "w-4 h-4 shrink-0 mt-0.5 text-amber-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 shrink-0 mt-0.5 text-red-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 75,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "font-bold mb-0.5",
									children: isNetworkError ? "Aviso de Conectividad" : "Error de Autenticación"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 78,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2",
								children: "Nombre de Usuario"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: username,
								onChange: (e) => setUsername(e.target.value),
								placeholder: "ej. admin1, inspector1",
								disabled: isLoading,
								className: "w-full px-4 py-3 bg-slate-900 border border-slate-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm focus:outline-none text-slate-100 placeholder-slate-500 h-12 disabled:opacity-50"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2",
								children: "Contraseña"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "relative",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: showPassword ? "text" : "password",
									value: password,
									onChange: (e) => setPassword(e.target.value),
									placeholder: "••••••",
									disabled: isLoading,
									className: "w-full pl-4 pr-11 py-3 bg-slate-900 border border-slate-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm focus:outline-none text-slate-100 placeholder-slate-500 h-12 disabled:opacity-50 font-sans"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowPassword(!showPassword),
									disabled: isLoading,
									className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-amber-400 p-1.5 rounded-lg transition-colors focus:outline-none cursor-pointer",
									title: showPassword ? "Ocultar contraseña" : "Ver contraseña",
									tabIndex: -1,
									children: showPassword ? /* @__PURE__ */ _jsxDEV(EyeOff, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV(Eye, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: isLoading,
							className: "w-full h-12 bg-amber-500 hover:bg-amber-600 active:scale-98 text-slate-950 font-bold rounded-xl shadow-lg hover:shadow-amber-500/15 transition-all text-sm cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2",
							children: isLoading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin text-slate-950" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Verificando credenciales..." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("span", { children: "Iniciar Sesión" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-8 text-center flex items-center justify-center gap-1.5 text-[10px] text-slate-500",
					children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Acceso seguro para inspectores de campo (Tablet PWA)" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 5
	}, this);
};
_s(LoginView, "aZu+4doWc/BQm/2fjd1HklRuLYM=", false, function() {
	return [useStore, useNavigate];
});
_c = LoginView;
export default LoginView;
var _c;
$RefreshReg$(_c, "LoginView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/views/LoginView.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/LoginView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/LoginView.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/LoginView.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLG1CQUFtQjtBQUM1QixPQUFPLGNBQWM7QUFDckIsU0FBUyxLQUFLLGFBQWEsU0FBUyxhQUFhLFNBQVMsS0FBSyxjQUFjOzs7O0FBRTdFLE9BQU8sTUFBTSxrQkFBa0I7O0NBQzdCLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxLQUFLO0NBQzFELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxRQUFRLFVBQVUsVUFBVSxNQUFNLEtBQUs7Q0FDN0MsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsTUFBTSxlQUFlLE9BQU8sTUFBTTtFQUNoQyxFQUFFLGVBQWU7RUFDakIsU0FBUyxFQUFFO0VBQ1gsa0JBQWtCLEtBQUs7RUFFdkIsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVO0dBQzFCLFNBQVMsc0NBQXNDO0dBQy9DO0VBQ0Y7RUFFQSxJQUFJLFNBQVMsS0FBSyxDQUFDLENBQUMsVUFBVSxLQUFLLFNBQVMsVUFBVSxHQUFHO0dBQ3ZELGFBQWEsSUFBSTtHQUNqQixJQUFJO0lBQ0YsTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLEtBQUssR0FBRyxRQUFRO0lBQ3BELElBQUksT0FBTyxTQUFTO0tBQ2xCLFNBQVMsR0FBRztJQUNkLE9BQU87S0FDTCxTQUFTLE9BQU8sS0FBSztLQUNyQixrQkFBa0IsUUFBUSxPQUFPLGNBQWMsQ0FBQztJQUNsRDtHQUNGLFNBQVMsS0FBSztJQUNaLFNBQVMsSUFBSSxXQUFXLHFDQUFxQztHQUMvRCxVQUFVO0lBQ1IsYUFBYSxLQUFLO0dBQ3BCO0VBQ0YsT0FBTztHQUNMLFNBQVMsb0ZBQW9GO0VBQy9GO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBRWIsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUdFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7O01BQ3RDOzs7OztNQUNMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUErRztNQUV6SDs7Ozs7TUFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUI7TUFFbkM7Ozs7O0tBQ0E7Ozs7OztJQUdMLHdCQUFDLFFBQUQ7S0FBTSxVQUFVO0tBQWMsV0FBVTtlQUF4QztNQUNHLFNBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVcsbUVBQ2QsaUJBQ0ksOERBQ0E7aUJBSE4sQ0FLRyxpQkFDQyx3QkFBQyxTQUFELEVBQVMsV0FBVSx5Q0FBMEM7Ozs7a0JBRTdELHdCQUFDLGFBQUQsRUFBYSxXQUFVLHVDQUF3Qzs7OztpQkFFakUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBb0IsaUJBQWlCLDBCQUEwQjtRQUE0Qjs7OztrQkFDeEcsd0JBQUMsS0FBRCxZQUFJLE1BQVM7Ozs7Z0JBQ1Y7Ozs7O2VBQ0Y7Ozs7OztNQUdQLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBRUUsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUF1RTtPQUVqRjs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sWUFBWSxFQUFFLE9BQU8sS0FBSztRQUMzQyxhQUFZO1FBQ1osVUFBVTtRQUNWLFdBQVU7T0FDWDs7OztlQUNFOzs7O2lCQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBdUU7T0FFakY7Ozs7aUJBQ1Asd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1NBQ0UsTUFBTSxlQUFlLFNBQVM7U0FDOUIsT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO1NBQzNDLGFBQVk7U0FDWixVQUFVO1NBQ1YsV0FBVTtRQUNYOzs7O2tCQUNELHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxnQkFBZ0IsQ0FBQyxZQUFZO1NBQzVDLFVBQVU7U0FDVixXQUFVO1NBQ1YsT0FBTyxlQUFlLHVCQUF1QjtTQUM3QyxVQUFVLENBQUM7bUJBRVYsZUFDQyx3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7O29CQUU3Qix3QkFBQyxLQUFELEVBQUssV0FBVSxVQUFXOzs7OztRQUV0Qjs7OztnQkFDTDs7Ozs7ZUFDRjs7OztlQUNGOzs7Ozs7TUFFTCx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFVBQVU7T0FDVixXQUFVO2lCQUVULFlBQ0MsZ0RBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsc0NBQXVDOzs7O2lCQUMxRCx3QkFBQyxRQUFELFlBQU0sOEJBQWlDOzs7O2VBQ3ZDOzs7O2tCQUVGLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7O01BRXRCOzs7OztLQUNKOzs7Ozs7SUFHTix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsY0FBZTs7OztlQUN0Qyx3QkFBQyxRQUFELFlBQU0sdURBQTBEOzs7O2FBQzdEOzs7Ozs7R0FDRjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJMb2dpblZpZXcuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgdXNlU3RvcmUgZnJvbSAnLi4vc3RvcmUvdXNlU3RvcmUnO1xuaW1wb3J0IHsgWmFwLCBTaGllbGRDaGVjaywgTG9hZGVyMiwgQWxlcnRDaXJjbGUsIFdpZmlPZmYsIEV5ZSwgRXllT2ZmIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IGNvbnN0IExvZ2luVmlldyA9ICgpID0+IHtcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2hvd1Bhc3N3b3JkLCBzZXRTaG93UGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2lzTmV0d29ya0Vycm9yLCBzZXRJc05ldHdvcmtFcnJvcl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IGxvZ2luID0gdXNlU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5sb2dpbik7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRFcnJvcignJyk7XG4gICAgc2V0SXNOZXR3b3JrRXJyb3IoZmFsc2UpO1xuXG4gICAgaWYgKCF1c2VybmFtZSB8fCAhcGFzc3dvcmQpIHtcbiAgICAgIHNldEVycm9yKCdQb3IgZmF2b3IsIGluZ3Jlc2EgdHVzIGNyZWRlbmNpYWxlcy4nKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgXG4gICAgaWYgKHVzZXJuYW1lLnRyaW0oKS5sZW5ndGggPj0gMyAmJiBwYXNzd29yZC5sZW5ndGggPj0gNCkge1xuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgbG9naW4odXNlcm5hbWUudHJpbSgpLCBwYXNzd29yZCk7XG4gICAgICAgIGlmIChyZXN1bHQuc3VjY2Vzcykge1xuICAgICAgICAgIG5hdmlnYXRlKCcvJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2V0RXJyb3IocmVzdWx0LmVycm9yKTtcbiAgICAgICAgICBzZXRJc05ldHdvcmtFcnJvcihCb29sZWFuKHJlc3VsdC5pc05ldHdvcmtFcnJvcikpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgJ0Vycm9yIGluZXNwZXJhZG8gYWwgaW5pY2lhciBzZXNpw7NuLicpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgc2V0RXJyb3IoJ0VsIHVzdWFyaW8gZGViZSB0ZW5lciBhbCBtZW5vcyAzIGNhcmFjdGVyZXMgeSBsYSBjb250cmFzZcOxYSBhbCBtZW5vcyA0IGNhcmFjdGVyZXMuJyk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgey8qIFRhcmpldGEgZGUgTG9naW4gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC04IHNoYWRvdy0yeGwgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBDYWJlY2VyYSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBzcGFjZS15LTIgbWItOFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIHAtMyByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgc2hhZG93LWFtYmVyLTUwMC8yMCBtYi0yXCI+XG4gICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctOCBoLTggZmlsbC1zbGF0ZS05NTBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWFtYmVyLTQwMCB0by1hbWJlci0yMDAgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnRcIj5cbiAgICAgICAgICAgIFRhYmxlcm9TZWxlY3RyaWMgUHJvXG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICBQbGF0YWZvcm1hIFByb2Zlc2lvbmFsIGRlIEluc3BlY2Npw7NuIGRlIFRhYmxlcm9zXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRm9ybXVsYXJpbyAqL31cbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC00IHJvdW5kZWQteGwgdGV4dC14cyBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yLjUgbGVhZGluZy1yZWxheGVkICR7XG4gICAgICAgICAgICAgIGlzTmV0d29ya0Vycm9yIFxuICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTk1MC80MCBib3JkZXIgYm9yZGVyLWFtYmVyLTgwMC84MCB0ZXh0LWFtYmVyLTMwMCcgXG4gICAgICAgICAgICAgICAgOiAnYmctcmVkLTk1MC80MCBib3JkZXIgYm9yZGVyLXJlZC04MDAvODAgdGV4dC1yZWQtNDAwJ1xuICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICB7aXNOZXR3b3JrRXJyb3IgPyAoXG4gICAgICAgICAgICAgICAgPFdpZmlPZmYgY2xhc3NOYW1lPVwidy00IGgtNCBzaHJpbmstMCBtdC0wLjUgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wIG10LTAuNSB0ZXh0LXJlZC00MDBcIiAvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBtYi0wLjVcIj57aXNOZXR3b3JrRXJyb3IgPyAnQXZpc28gZGUgQ29uZWN0aXZpZGFkJyA6ICdFcnJvciBkZSBBdXRlbnRpY2FjacOzbid9PC9wPlxuICAgICAgICAgICAgICAgIDxwPntlcnJvcn08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICB7LyogVXNlcm5hbWUgKi99XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTJcIj5cbiAgICAgICAgICAgICAgICBOb21icmUgZGUgVXN1YXJpb1xuICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXNlcm5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZWouIGFkbWluMSwgaW5zcGVjdG9yMVwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIHRleHQtc2xhdGUtMTAwIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCBoLTEyIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDb250cmFzZcOxYSAqL31cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMlwiPlxuICAgICAgICAgICAgICAgIENvbnRyYXNlw7FhXG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dQYXNzd29yZCA/ICd0ZXh0JyA6ICdwYXNzd29yZCd9XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtNCBwci0xMSBweS0zIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIHRleHQtc2xhdGUtMTAwIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCBoLTEyIGRpc2FibGVkOm9wYWNpdHktNTAgZm9udC1zYW5zXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1Bhc3N3b3JkKCFzaG93UGFzc3dvcmQpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtYW1iZXItNDAwIHAtMS41IHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZm9jdXM6b3V0bGluZS1ub25lIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPXtzaG93UGFzc3dvcmQgPyAnT2N1bHRhciBjb250cmFzZcOxYScgOiAnVmVyIGNvbnRyYXNlw7FhJ31cbiAgICAgICAgICAgICAgICAgIHRhYkluZGV4PXstMX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7c2hvd1Bhc3N3b3JkID8gKFxuICAgICAgICAgICAgICAgICAgICA8RXllT2ZmIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPEV5ZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMiBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNjAwIGFjdGl2ZTpzY2FsZS05OCB0ZXh0LXNsYXRlLTk1MCBmb250LWJvbGQgcm91bmRlZC14bCBzaGFkb3ctbGcgaG92ZXI6c2hhZG93LWFtYmVyLTUwMC8xNSB0cmFuc2l0aW9uLWFsbCB0ZXh0LXNtIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW4gdGV4dC1zbGF0ZS05NTBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlZlcmlmaWNhbmRvIGNyZWRlbmNpYWxlcy4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8c3Bhbj5JbmljaWFyIFNlc2nDs248L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHRleHQtY2VudGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgdGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgIDxzcGFuPkFjY2VzbyBzZWd1cm8gcGFyYSBpbnNwZWN0b3JlcyBkZSBjYW1wbyAoVGFibGV0IFBXQSk8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBMb2dpblZpZXc7XG4iXX0=