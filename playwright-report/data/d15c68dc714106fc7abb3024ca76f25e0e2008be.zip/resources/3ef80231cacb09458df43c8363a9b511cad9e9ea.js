import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AvanceProgressBar.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { calcularPorcentajeAvance } from "/src/utils/calcularAvance.js";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/AvanceProgressBar.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
export const AvanceProgressBar = ({ elemento, tipoElemento, className = "" }) => {
	const { porcentaje, colorClass, textClass, label } = calcularPorcentajeAvance(elemento, tipoElemento);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `space-y-1.5 w-full ${className}`,
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between text-[10px] font-bold",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "text-slate-400",
				children: "Completitud Técnica:"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: `${textClass} font-mono font-black`,
				children: label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full bg-slate-900 rounded-full h-1.5 overflow-hidden border border-slate-800",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: `h-full ${colorClass} transition-all duration-500 rounded-full`,
				style: { width: `${porcentaje}%` }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
};
_c = AvanceProgressBar;
export default AvanceProgressBar;
var _c;
$RefreshReg$(_c, "AvanceProgressBar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AvanceProgressBar.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/AvanceProgressBar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/AvanceProgressBar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/AvanceProgressBar.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZ0NBQWdDOzs7QUFFekMsT0FBTyxNQUFNLHFCQUFxQixFQUFFLFVBQVUsY0FBYyxZQUFZLFNBQVM7Q0FDL0UsTUFBTSxFQUFFLFlBQVksWUFBWSxXQUFXLFVBQVUseUJBQXlCLFVBQVUsWUFBWTtDQUVwRyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFXLHNCQUFzQjtZQUF0QyxDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFpQjtHQUEwQjs7OzthQUMzRCx3QkFBQyxRQUFEO0lBQU0sV0FBVyxHQUFHLFVBQVU7Y0FBeUI7R0FBWTs7OztXQUNoRTs7Ozs7WUFDTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLE9BQUQ7SUFDRSxXQUFXLFVBQVUsV0FBVztJQUNoQyxPQUFPLEVBQUUsT0FBTyxHQUFHLFdBQVcsR0FBRztHQUNsQzs7Ozs7RUFDRTs7OztVQUNGOzs7Ozs7QUFFVDs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkF2YW5jZVByb2dyZXNzQmFyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY2FsY3VsYXJQb3JjZW50YWplQXZhbmNlIH0gZnJvbSAnLi4vdXRpbHMvY2FsY3VsYXJBdmFuY2UnO1xuXG5leHBvcnQgY29uc3QgQXZhbmNlUHJvZ3Jlc3NCYXIgPSAoeyBlbGVtZW50bywgdGlwb0VsZW1lbnRvLCBjbGFzc05hbWUgPSAnJyB9KSA9PiB7XG4gIGNvbnN0IHsgcG9yY2VudGFqZSwgY29sb3JDbGFzcywgdGV4dENsYXNzLCBsYWJlbCB9ID0gY2FsY3VsYXJQb3JjZW50YWplQXZhbmNlKGVsZW1lbnRvLCB0aXBvRWxlbWVudG8pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2BzcGFjZS15LTEuNSB3LWZ1bGwgJHtjbGFzc05hbWV9YH0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMHB4XSBmb250LWJvbGRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5Db21wbGV0aXR1ZCBUw6ljbmljYTo8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7dGV4dENsYXNzfSBmb250LW1vbm8gZm9udC1ibGFja2B9PntsYWJlbH08L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCByb3VuZGVkLWZ1bGwgaC0xLjUgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgIDxkaXYgXG4gICAgICAgICAgY2xhc3NOYW1lPXtgaC1mdWxsICR7Y29sb3JDbGFzc30gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwIHJvdW5kZWQtZnVsbGB9XG4gICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke3BvcmNlbnRhamV9JWAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQXZhbmNlUHJvZ3Jlc3NCYXI7XG4iXX0=