import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ToastNotification.jsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { CheckCircle2, XCircle, AlertCircle, X } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ToastNotification.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function ToastNotification() {
	_s();
	const { toast, hideToast } = useStore();
	const [progress, setProgress] = useState(100);
	useEffect(() => {
		if (!toast.show) return;
		setProgress(100);
		const duration = 4e3;
		const intervalTime = 40;
		const step = intervalTime / duration * 100;
		const timer = setTimeout(() => {
			hideToast();
		}, duration);
		const progressTimer = setInterval(() => {
			setProgress((prev) => {
				if (prev <= 0) {
					clearInterval(progressTimer);
					return 0;
				}
				return prev - step;
			});
		}, intervalTime);
		return () => {
			clearTimeout(timer);
			clearInterval(progressTimer);
		};
	}, [
		toast.show,
		toast.message,
		hideToast
	]);
	if (!toast.show) return null;
	let Icon = CheckCircle2;
	let themeClass = "border-emerald-500/30 text-emerald-400 shadow-emerald-500/5 bg-emerald-950/20";
	let progressColor = "bg-emerald-500";
	if (toast.type === "error") {
		Icon = XCircle;
		themeClass = "border-rose-500/30 text-rose-400 shadow-rose-500/5 bg-rose-950/20";
		progressColor = "bg-rose-500";
	} else if (toast.type === "warning" || toast.type === "info") {
		Icon = AlertCircle;
		themeClass = "border-amber-500/30 text-amber-400 shadow-amber-500/5 bg-amber-950/20";
		progressColor = "bg-amber-500";
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed top-6 left-1/2 -translate-x-1/2 z-55 w-full max-w-sm px-4 no-print animate-in slide-in-from-top duration-300 ease-out",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: `relative flex items-start gap-3 p-4 rounded-2xl border backdrop-blur-md shadow-2xl overflow-hidden ${themeClass}`,
			children: [
				/* @__PURE__ */ _jsxDEV(Icon, { className: "w-5 h-5 shrink-0 mt-0.5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 min-w-0",
					children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs font-semibold leading-relaxed break-words font-sans text-slate-100 pr-2",
						children: toast.message
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this), toast.action && /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-2 flex items-center gap-2",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								if (typeof toast.action.onClick === "function") {
									toast.action.onClick();
								}
								hideToast();
							},
							className: "px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] rounded-lg shadow transition-all cursor-pointer flex items-center gap-1",
							children: toast.action.label || "Ver Detalles"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: hideToast,
					className: "p-0.5 hover:bg-slate-900 rounded-lg text-slate-500 hover:text-slate-300 transition-colors cursor-pointer",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute bottom-0 left-0 w-full h-[3px] bg-slate-900/60",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: `h-full transition-all duration-75 ease-linear ${progressColor}`,
						style: { width: `${progress}%` }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 5
	}, this);
}
_s(ToastNotification, "w7kaR+3d1pyjaXbYHO2BWSZ9NEQ=", false, function() {
	return [useStore];
});
_c = ToastNotification;
var _c;
$RefreshReg$(_c, "ToastNotification");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ToastNotification.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ToastNotification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ToastNotification.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ToastNotification.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsZ0JBQWdCO0FBQzNDLE9BQU8sY0FBYztBQUNyQixTQUFTLGNBQWMsU0FBUyxhQUFhLFNBQVM7Ozs7QUFFdEQsZUFBZSxTQUFTLG9CQUFvQjs7Q0FDMUMsTUFBTSxFQUFFLE9BQU8sY0FBYyxTQUFTO0NBQ3RDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxHQUFHO0NBRTVDLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxNQUFNLE1BQU07RUFFakIsWUFBWSxHQUFHO0VBQ2YsTUFBTSxXQUFXO0VBQ2pCLE1BQU0sZUFBZTtFQUNyQixNQUFNLE9BQVEsZUFBZSxXQUFZO0VBRXpDLE1BQU0sUUFBUSxpQkFBaUI7R0FDN0IsVUFBVTtFQUNaLEdBQUcsUUFBUTtFQUVYLE1BQU0sZ0JBQWdCLGtCQUFrQjtHQUN0QyxhQUFhLFNBQVM7SUFDcEIsSUFBSSxRQUFRLEdBQUc7S0FDYixjQUFjLGFBQWE7S0FDM0IsT0FBTztJQUNUO0lBQ0EsT0FBTyxPQUFPO0dBQ2hCLENBQUM7RUFDSCxHQUFHLFlBQVk7RUFFZixhQUFhO0dBQ1gsYUFBYSxLQUFLO0dBQ2xCLGNBQWMsYUFBYTtFQUM3QjtDQUNGLEdBQUc7RUFBQyxNQUFNO0VBQU0sTUFBTTtFQUFTO0NBQVMsQ0FBQztDQUV6QyxJQUFJLENBQUMsTUFBTSxNQUFNLE9BQU87Q0FFeEIsSUFBSSxPQUFPO0NBQ1gsSUFBSSxhQUFhO0NBQ2pCLElBQUksZ0JBQWdCO0NBRXBCLElBQUksTUFBTSxTQUFTLFNBQVM7RUFDMUIsT0FBTztFQUNQLGFBQWE7RUFDYixnQkFBZ0I7Q0FDbEIsT0FBTyxJQUFJLE1BQU0sU0FBUyxhQUFhLE1BQU0sU0FBUyxRQUFRO0VBQzVELE9BQU87RUFDUCxhQUFhO0VBQ2IsZ0JBQWdCO0NBQ2xCO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFXLHNHQUFzRzthQUF0SDtJQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLDBCQUEyQjs7Ozs7SUFFM0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWLE1BQU07S0FDTjs7OztlQUNGLE1BQU0sVUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxVQUFEO09BQ0UsZUFBZTtRQUNiLElBQUksT0FBTyxNQUFNLE9BQU8sWUFBWSxZQUFZO1NBQzlDLE1BQU0sT0FBTyxRQUFRO1FBQ3ZCO1FBQ0EsVUFBVTtPQUNaO09BQ0EsV0FBVTtpQkFFVCxNQUFNLE9BQU8sU0FBUztNQUNqQjs7Ozs7S0FDTDs7OzthQUVKOzs7Ozs7SUFFTCx3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7ZUFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxjQUFlOzs7OztJQUN0Qjs7Ozs7SUFHUix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFDRSxXQUFXLGlEQUFpRDtNQUM1RCxPQUFPLEVBQUUsT0FBTyxHQUFHLFNBQVMsR0FBRztLQUNoQzs7Ozs7SUFDRTs7Ozs7R0FDRjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVG9hc3ROb3RpZmljYXRpb24uanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHVzZVN0b3JlIGZyb20gJy4uL3N0b3JlL3VzZVN0b3JlJztcbmltcG9ydCB7IENoZWNrQ2lyY2xlMiwgWENpcmNsZSwgQWxlcnRDaXJjbGUsIFggfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBUb2FzdE5vdGlmaWNhdGlvbigpIHtcbiAgY29uc3QgeyB0b2FzdCwgaGlkZVRvYXN0IH0gPSB1c2VTdG9yZSgpO1xuICBjb25zdCBbcHJvZ3Jlc3MsIHNldFByb2dyZXNzXSA9IHVzZVN0YXRlKDEwMCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXRvYXN0LnNob3cpIHJldHVybjtcblxuICAgIHNldFByb2dyZXNzKDEwMCk7XG4gICAgY29uc3QgZHVyYXRpb24gPSA0MDAwOyAvLyA0IHNlY29uZHNcbiAgICBjb25zdCBpbnRlcnZhbFRpbWUgPSA0MDtcbiAgICBjb25zdCBzdGVwID0gKGludGVydmFsVGltZSAvIGR1cmF0aW9uKSAqIDEwMDtcblxuICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBoaWRlVG9hc3QoKTtcbiAgICB9LCBkdXJhdGlvbik7XG5cbiAgICBjb25zdCBwcm9ncmVzc1RpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgc2V0UHJvZ3Jlc3MoKHByZXYpID0+IHtcbiAgICAgICAgaWYgKHByZXYgPD0gMCkge1xuICAgICAgICAgIGNsZWFySW50ZXJ2YWwocHJvZ3Jlc3NUaW1lcik7XG4gICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHByZXYgLSBzdGVwO1xuICAgICAgfSk7XG4gICAgfSwgaW50ZXJ2YWxUaW1lKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgICAgY2xlYXJJbnRlcnZhbChwcm9ncmVzc1RpbWVyKTtcbiAgICB9O1xuICB9LCBbdG9hc3Quc2hvdywgdG9hc3QubWVzc2FnZSwgaGlkZVRvYXN0XSk7XG5cbiAgaWYgKCF0b2FzdC5zaG93KSByZXR1cm4gbnVsbDtcblxuICBsZXQgSWNvbiA9IENoZWNrQ2lyY2xlMjtcbiAgbGV0IHRoZW1lQ2xhc3MgPSAnYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC00MDAgc2hhZG93LWVtZXJhbGQtNTAwLzUgYmctZW1lcmFsZC05NTAvMjAnO1xuICBsZXQgcHJvZ3Jlc3NDb2xvciA9ICdiZy1lbWVyYWxkLTUwMCc7XG5cbiAgaWYgKHRvYXN0LnR5cGUgPT09ICdlcnJvcicpIHtcbiAgICBJY29uID0gWENpcmNsZTtcbiAgICB0aGVtZUNsYXNzID0gJ2JvcmRlci1yb3NlLTUwMC8zMCB0ZXh0LXJvc2UtNDAwIHNoYWRvdy1yb3NlLTUwMC81IGJnLXJvc2UtOTUwLzIwJztcbiAgICBwcm9ncmVzc0NvbG9yID0gJ2JnLXJvc2UtNTAwJztcbiAgfSBlbHNlIGlmICh0b2FzdC50eXBlID09PSAnd2FybmluZycgfHwgdG9hc3QudHlwZSA9PT0gJ2luZm8nKSB7XG4gICAgSWNvbiA9IEFsZXJ0Q2lyY2xlO1xuICAgIHRoZW1lQ2xhc3MgPSAnYm9yZGVyLWFtYmVyLTUwMC8zMCB0ZXh0LWFtYmVyLTQwMCBzaGFkb3ctYW1iZXItNTAwLzUgYmctYW1iZXItOTUwLzIwJztcbiAgICBwcm9ncmVzc0NvbG9yID0gJ2JnLWFtYmVyLTUwMCc7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgdG9wLTYgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiB6LTU1IHctZnVsbCBtYXgtdy1zbSBweC00IG5vLXByaW50IGFuaW1hdGUtaW4gc2xpZGUtaW4tZnJvbS10b3AgZHVyYXRpb24tMzAwIGVhc2Utb3V0XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YHJlbGF0aXZlIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBiYWNrZHJvcC1ibHVyLW1kIHNoYWRvdy0yeGwgb3ZlcmZsb3ctaGlkZGVuICR7dGhlbWVDbGFzc31gfT5cbiAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy01IGgtNSBzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICBcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCBsZWFkaW5nLXJlbGF4ZWQgYnJlYWstd29yZHMgZm9udC1zYW5zIHRleHQtc2xhdGUtMTAwIHByLTJcIj5cbiAgICAgICAgICAgIHt0b2FzdC5tZXNzYWdlfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICB7dG9hc3QuYWN0aW9uICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0b2FzdC5hY3Rpb24ub25DbGljayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgICB0b2FzdC5hY3Rpb24ub25DbGljaygpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgaGlkZVRvYXN0KCk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCB0ZXh0LVsxMXB4XSByb3VuZGVkLWxnIHNoYWRvdyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7dG9hc3QuYWN0aW9uLmxhYmVsIHx8ICdWZXIgRGV0YWxsZXMnfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgb25DbGljaz17aGlkZVRvYXN0fVxuICAgICAgICAgIGNsYXNzTmFtZT1cInAtMC41IGhvdmVyOmJnLXNsYXRlLTkwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtMzAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgey8qIEJhcnJhIGRlIHByb2dyZXNvIGRlIGR1cmFjacOzbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCBsZWZ0LTAgdy1mdWxsIGgtWzNweF0gYmctc2xhdGUtOTAwLzYwXCI+XG4gICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi03NSBlYXNlLWxpbmVhciAke3Byb2dyZXNzQ29sb3J9YH1cbiAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtwcm9ncmVzc30lYCB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=