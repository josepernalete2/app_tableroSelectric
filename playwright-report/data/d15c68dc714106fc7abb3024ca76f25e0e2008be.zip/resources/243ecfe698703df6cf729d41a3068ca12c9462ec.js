import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport18_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { BrowserRouter, Routes, Route, Navigate, useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f49807c8";
import useStore, { formatElementTitleWithId } from "/src/store/useStore.js?t=1790792337841";
// Vistas
import LoginView from "/src/views/LoginView.jsx?t=1790792337841";
import DashboardView from "/src/views/DashboardView.jsx?t=1790792337841";
import EmpresaView from "/src/views/EmpresaView.jsx?t=1790792337841";
import ProyectoView from "/src/views/ProyectoView.jsx?t=1790792337841";
import TableroComponent from "/src/components/TableroComponent.jsx?t=1790793566895";
import SubestacionComponent from "/src/components/SubestacionComponent.jsx?t=1790793566895";
import PuntoMedicionComponent from "/src/components/PuntoMedicionComponent.jsx?t=1790793566895";
import CcmComponent from "/src/components/CcmComponent.jsx?t=1790793566895";
import TransferComponent from "/src/components/TransferComponent.jsx?t=1790793572890";
import FichaTecnicaComponent from "/src/components/FichaTecnicaComponent.jsx?t=1790793862643";
import InformeCompiladoView from "/src/views/InformeCompiladoView.jsx?t=1790793862643";
import ReportesView from "/src/views/ReportesView.jsx?t=1790792337841";
import BackupView from "/src/views/BackupView.jsx?t=1790792337841";
import SidebarLayout from "/src/components/SidebarLayout.jsx?t=1790792337841";
import { ArrowLeft, User, LogOut, Printer } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/App.jsx";
import __vite__cjsImport18_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
// Wrapper para Rutas Protegidas
const ProtectedRoute = ({ children }) => {
	_s();
	const user = useStore((state) => state.user);
	const hasToken = typeof localStorage !== "undefined" ? localStorage.getItem("token") : null;
	if (!user && !hasToken) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/login",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 12
		}, this);
	}
	return children;
};
_s(ProtectedRoute, "Ffgj8TzL1arI64iK5ZpcnqNEsJU=", false, function() {
	return [useStore];
});
_c = ProtectedRoute;
// Wrapper para cargar el TableroComponent, SubestacionComponent, PuntoMedicionComponent o CcmComponent con los parámetros de la URL
const TableroWrapper = () => {
	_s2();
	const { companyId, tableroId } = useParams();
	const navigate = useNavigate();
	const { companies, updateTablero, updateSubestacion, updatePuntoMedicion, updateCcm, updateElementoUnifilar } = useStore();
	const user = useStore((state) => state.user);
	const logout = useStore((state) => state.logout);
	let company = companies.find((c) => c.id === companyId);
	// Buscar en elementos unifilares, subestaciones, puntos de medición o CCM
	let element = null;
	let subestacion = null;
	let puntoMedicion = null;
	let ccmItem = null;
	let targetProyecto = null;
	// 1. Buscar en la empresa especificada por URL
	if (company) {
		const compElList = company.elementosUnifilares || [];
		const compEl = compElList.find((e) => e.id === tableroId);
		if (compEl) {
			element = compEl;
		} else if (company.proyectos) {
			for (const p of company.proyectos) {
				const elList = p.elementosUnifilares || p.tableros || [];
				const el = elList.find((e) => e.id === tableroId);
				if (el) {
					element = el;
					targetProyecto = p;
					break;
				}
				const subList = p.inspeccionesSubestacion || p.subestaciones || [];
				const s = subList.find((sub) => sub.id === tableroId);
				if (s) {
					subestacion = s;
					targetProyecto = p;
					break;
				}
				const pmList = p.puntosMedicion || [];
				const pm = pmList.find((item) => item.id === tableroId);
				if (pm) {
					puntoMedicion = pm;
					targetProyecto = p;
					break;
				}
				const ccmList = p.ccmList || [];
				const ccm = ccmList.find((item) => item.id === tableroId);
				if (ccm) {
					ccmItem = ccm;
					targetProyecto = p;
					break;
				}
			}
		}
	}
	// 2. Si no se encontró en la empresa dada, buscar transversalmente en todas las empresas de la tienda
	if (!element && !subestacion && !puntoMedicion && !ccmItem) {
		for (const c of companies) {
			if (c.proyectos) {
				for (const p of c.proyectos) {
					const elList = p.elementosUnifilares || p.tableros || [];
					const el = elList.find((e) => e.id === tableroId);
					if (el) {
						element = el;
						targetProyecto = p;
						company = c;
						break;
					}
					const subList = p.inspeccionesSubestacion || p.subestaciones || [];
					const s = subList.find((sub) => sub.id === tableroId);
					if (s) {
						subestacion = s;
						targetProyecto = p;
						company = c;
						break;
					}
					const pmList = p.puntosMedicion || [];
					const pm = pmList.find((item) => item.id === tableroId);
					if (pm) {
						puntoMedicion = pm;
						targetProyecto = p;
						company = c;
						break;
					}
					const ccmList = p.ccmList || [];
					const ccm = ccmList.find((item) => item.id === tableroId);
					if (ccm) {
						ccmItem = ccm;
						targetProyecto = p;
						company = c;
						break;
					}
				}
			}
			if (element || subestacion || puntoMedicion || ccmItem) break;
		}
	}
	// 3. Fallback a arreglos de estado local si el elemento fue recién creado
	if (!element && !subestacion && !puntoMedicion && !ccmItem) {
		const puntosLocales = useStore.getState().puntosMedicionLocales || [];
		const pmLocal = puntosLocales.find((item) => item.id === tableroId);
		if (pmLocal) {
			puntoMedicion = pmLocal;
		}
		const ccmLocales = useStore.getState().ccmLocales || [];
		const ccmLocal = ccmLocales.find((item) => item.id === tableroId);
		if (ccmLocal) {
			ccmItem = ccmLocal;
		}
	}
	const backPath = targetProyecto ? `/empresa/${companyId}/proyecto/${targetProyecto.id}` : `/empresa/${companyId}`;
	if (!element && !subestacion && !puntoMedicion && !ccmItem) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center p-6 text-center space-y-4 font-sans",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-lg font-bold",
				children: "Elemento o Empresa no encontrado"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 154,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => navigate("/"),
				className: "px-4 py-2 bg-slate-800 rounded-lg text-xs",
				children: "Volver al Dashboard"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 153,
			columnNumber: 7
		}, this);
	}
	const handleLogout = () => {
		logout();
		navigate("/login");
	};
	// 1. Renderizar Inspección de Subestación
	if (subestacion) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased",
			children: [/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-slate-950 border-b border-slate-800 px-4 py-3 md:px-6 md:py-4 flex items-center justify-between shadow-md no-print",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigate(backPath),
						className: "p-2 hover:bg-slate-900 rounded-xl text-slate-400 hover:text-slate-200 transition-colors cursor-pointer",
						title: "Volver al Proyecto",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider",
						children: ["Subestación en: ", company.nombre]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-base font-bold text-slate-100 animate-fade-in",
						children: subestacion.nombre
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 181,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => window.print(),
							className: "px-3.5 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 rounded-xl transition-all cursor-pointer flex items-center gap-2 text-xs font-black shadow-sm",
							title: "Guardar como PDF o Imprimir esta Inspección",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden sm:inline",
								children: "Guardar PDF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl",
							children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 201,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-300",
								children: user?.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleLogout,
							className: "p-2.5 bg-slate-900 hover:bg-red-950/40 hover:text-red-400 border border-slate-800 hover:border-red-900/60 rounded-xl transition-all cursor-pointer",
							title: "Cerrar Sesión",
							children: /* @__PURE__ */ _jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 172,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-3 py-4 md:px-6 md:py-8",
				children: /* @__PURE__ */ _jsxDEV(SubestacionComponent, {
					subestacionData: subestacion,
					onUpdate: (updatedData) => updateSubestacion(targetProyecto.id, tableroId, updatedData),
					readOnly: user?.role === "CLIENT"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 216,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 215,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 170,
			columnNumber: 7
		}, this);
	}
	// 1.5. Renderizar Punto de Medición y Suministro
	if (puntoMedicion) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased",
			children: [/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-slate-950 border-b border-slate-800 px-4 py-3 md:px-6 md:py-4 flex items-center justify-between shadow-md no-print",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigate(backPath),
						className: "p-2 hover:bg-slate-900 rounded-xl text-slate-400 hover:text-slate-200 transition-colors cursor-pointer",
						title: "Volver al Proyecto",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider",
						children: ["Punto de Medición en: ", company.nombre]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 241,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-base font-bold text-slate-100 animate-fade-in",
						children: puntoMedicion.nombre
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 244,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 240,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 232,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => window.print(),
							className: "px-3.5 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 rounded-xl transition-all cursor-pointer flex items-center gap-2 text-xs font-black shadow-sm",
							title: "Guardar como PDF o Imprimir este Levantamiento",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden sm:inline",
								children: "Guardar PDF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 257,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 251,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl",
							children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 260,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-300",
								children: user?.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 261,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 259,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleLogout,
							className: "p-2.5 bg-slate-900 hover:bg-red-950/40 hover:text-red-400 border border-slate-800 hover:border-red-900/60 rounded-xl transition-all cursor-pointer",
							title: "Cerrar Sesión",
							children: /* @__PURE__ */ _jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 268,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 263,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 250,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 231,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-3 py-4 md:px-6 md:py-8",
				children: /* @__PURE__ */ _jsxDEV(PuntoMedicionComponent, {
					puntoData: puntoMedicion,
					onUpdate: (updatedData) => updatePuntoMedicion(targetProyecto?.id || puntoMedicion?.proyectoId, tableroId, updatedData),
					readOnly: user?.role === "CLIENT"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 275,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 274,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 229,
			columnNumber: 7
		}, this);
	}
	// 1.2 Renderizar Centro de Control de Motores (CCM)
	if (ccmItem) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased",
			children: [/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-slate-950 border-b border-slate-800 px-4 py-3 md:px-6 md:py-4 flex items-center justify-between shadow-md no-print",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigate(backPath),
						className: "p-2 hover:bg-slate-900 rounded-xl text-slate-400 hover:text-slate-200 transition-colors cursor-pointer",
						title: "Volver al Proyecto",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 297,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 292,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider",
						children: "Levantamiento de CCM"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 300,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-base font-bold text-slate-100 animate-fade-in",
						children: ccmItem.nombre
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 303,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 299,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 291,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => window.print(),
							className: "px-3.5 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 rounded-xl transition-all cursor-pointer flex items-center gap-2 text-xs font-black shadow-sm",
							title: "Guardar como PDF o Imprimir este Levantamiento",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden sm:inline",
								children: "Guardar PDF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 316,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 310,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl",
							children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 319,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-300",
								children: user?.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 320,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 318,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleLogout,
							className: "p-2.5 bg-slate-900 hover:bg-red-950/40 hover:text-red-400 border border-slate-800 hover:border-red-900/60 rounded-xl transition-all cursor-pointer",
							title: "Cerrar Sesión",
							children: /* @__PURE__ */ _jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 327,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 322,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 309,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 290,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-3 py-4 md:px-6 md:py-8",
				children: /* @__PURE__ */ _jsxDEV(CcmComponent, {
					ccmData: ccmItem,
					onUpdate: (updatedData) => updateCcm(targetProyecto?.id || ccmItem?.proyectoId, tableroId, updatedData),
					readOnly: user?.role === "CLIENT"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 334,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 333,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 288,
			columnNumber: 7
		}, this);
	}
	// 1.3 Renderizar Transferencia Eléctrica (TRANSFER / ATS / MTS)
	if (element && element.tipoElemento === "TRANSFER") {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased",
			children: [/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-slate-950 border-b border-slate-800 px-4 py-3 md:px-6 md:py-4 flex items-center justify-between shadow-md no-print",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigate(backPath),
						className: "p-2 hover:bg-slate-900 rounded-xl text-slate-400 hover:text-slate-200 transition-colors cursor-pointer",
						title: "Volver al Proyecto",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 356,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 351,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider",
						children: "Unidad de Transferencia (ATS / MTS)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 359,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-base font-bold text-slate-100 animate-fade-in",
						children: element.nombre
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 362,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 358,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 350,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => window.print(),
							className: "px-3.5 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 rounded-xl transition-all cursor-pointer flex items-center gap-2 text-xs font-black shadow-sm",
							title: "Guardar como PDF o Imprimir esta Transferencia",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 374,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden sm:inline",
								children: "Guardar PDF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 375,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 369,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl",
							children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 378,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-300",
								children: user?.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 379,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 377,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleLogout,
							className: "p-2.5 bg-slate-900 hover:bg-red-950/40 hover:text-red-400 border border-slate-800 hover:border-red-900/60 rounded-xl transition-all cursor-pointer",
							title: "Cerrar Sesión",
							children: /* @__PURE__ */ _jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 386,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 381,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 368,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 349,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-3 py-4 md:px-6 md:py-8",
				children: /* @__PURE__ */ _jsxDEV(TransferComponent, {
					transferData: element,
					onUpdate: (updatedData) => updateElementoUnifilar(targetProyecto?.id || null, tableroId, updatedData),
					readOnly: user?.role === "CLIENT"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 393,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 392,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 347,
			columnNumber: 7
		}, this);
	}
	// 2. Renderizar Elemento Especial (Generador / Trafo / Otro)
	if (element && element.tipoElemento !== "TABLERO") {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased",
			children: [/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-slate-950 border-b border-slate-800 px-4 py-3 md:px-6 md:py-4 flex items-center justify-between shadow-md no-print",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigate(backPath),
						className: "p-2 hover:bg-slate-900 rounded-xl text-slate-400 hover:text-slate-200 transition-colors cursor-pointer",
						title: "Volver al Proyecto",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 415,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 410,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider",
						children: ["Ficha Técnica en: ", company.nombre]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 418,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-base font-bold text-slate-100",
						children: element.nombre
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 421,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 417,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 409,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => window.print(),
							className: "px-3.5 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 rounded-xl transition-all cursor-pointer flex items-center gap-2 text-xs font-black shadow-sm",
							title: "Guardar como PDF o Imprimir esta Ficha Técnica",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 433,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden sm:inline",
								children: "Guardar PDF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 428,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl",
							children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 437,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-300",
								children: user?.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 438,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleLogout,
							className: "p-2.5 bg-slate-900 hover:bg-red-950/40 hover:text-red-400 border border-slate-800 hover:border-red-900/60 rounded-xl transition-all cursor-pointer",
							title: "Cerrar Sesión",
							children: /* @__PURE__ */ _jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 445,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 440,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 427,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 408,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-3 py-4 md:px-6 md:py-8",
				children: /* @__PURE__ */ _jsxDEV(FichaTecnicaComponent, {
					elementoData: element,
					onUpdate: (updatedData) => updateElementoUnifilar(targetProyecto?.id || null, tableroId, updatedData),
					readOnly: user?.role === "CLIENT"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 452,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 451,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 406,
			columnNumber: 7
		}, this);
	}
	// 3. Renderizar Ficha de Tablero Termográfico (TABLERO)
	const enrichedTablero = {
		id: element?.id || tableroId,
		nombre: element?.nombre || "Tablero Eléctrico",
		ubicacion: element?.ubicacion || "",
		alimentadoPor: element?.alimentadoPor || "",
		foto: element?.foto || null,
		fotoBlob: element?.fotoBlob || null,
		observacionesGenerales: element?.observacionesGenerales || "",
		...element?.datosTecnicos || {},
		circuits: Array.isArray(element?.datosTecnicos?.circuits) ? element.datosTecnicos.circuits : Array.isArray(element?.circuits) ? element.circuits : [],
		nombreEmpresa: company?.nombre || ""
	};
	const handleUpdateTablero = (updatedData) => {
		const { id, nombre, ubicacion, alimentadoPor, foto, fotoBlob, observacionesGenerales, nombreEmpresa, ...datosTecnicos } = updatedData;
		updateElementoUnifilar(targetProyecto?.id || null, tableroId, {
			nombre,
			ubicacion,
			alimentadoPor,
			foto,
			fotoBlob,
			observacionesGenerales,
			datosTecnicos
		});
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased",
		children: [/* @__PURE__ */ _jsxDEV("header", {
			className: "bg-slate-950 border-b border-slate-800 px-4 py-3 md:px-6 md:py-4 flex items-center justify-between shadow-md no-print",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => navigate(backPath),
					className: "p-2 hover:bg-slate-900 rounded-xl text-slate-400 hover:text-slate-200 transition-colors cursor-pointer",
					title: "Volver al Proyecto",
					children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 505,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 500,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider",
					children: ["Inspeccionando para: ", company.nombre]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 508,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-base font-bold text-slate-100",
						children: formatElementTitleWithId(element.nombre, element.id)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 512,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "font-mono font-black text-amber-400 bg-slate-900 border border-amber-500/30 px-2.5 py-0.5 rounded-lg text-xs shadow-sm",
						children: ["ID: ", element.id]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 515,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 511,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 507,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 499,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => window.print(),
						className: "px-3.5 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 rounded-xl transition-all cursor-pointer flex items-center gap-2 text-xs font-black shadow-sm",
						title: "Guardar como PDF o Imprimir esta Plantilla",
						children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 529,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline",
							children: "Guardar PDF"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 530,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 524,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl",
						children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 533,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-semibold text-slate-300",
							children: user?.email
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 534,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 532,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: handleLogout,
						className: "p-2.5 bg-slate-900 hover:bg-red-950/40 hover:text-red-400 border border-slate-800 hover:border-red-900/60 rounded-xl transition-all cursor-pointer",
						title: "Cerrar Sesión",
						children: /* @__PURE__ */ _jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 541,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 536,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 523,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 498,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("main", {
			className: "flex-1 max-w-7xl w-full mx-auto px-3 py-4 md:px-6 md:py-8",
			children: /* @__PURE__ */ _jsxDEV(TableroComponent, {
				tableroData: enrichedTablero,
				onUpdateTablero: handleUpdateTablero,
				readOnly: user?.role === "CLIENT"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 548,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 547,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 496,
		columnNumber: 5
	}, this);
};
_s2(TableroWrapper, "Osje9NxGV5pUIrZWJO+hy/LqBFw=", false, function() {
	return [
		useParams,
		useNavigate,
		useStore,
		useStore,
		useStore
	];
});
_c2 = TableroWrapper;
import SyncStatusBanner from "/src/components/SyncStatusBanner.jsx?t=1790792337841";
import ToastNotification from "/src/components/ToastNotification.jsx?t=1790792337841";
import PanelConflictosCircuitos from "/src/components/PanelConflictosCircuitos.jsx?t=1790792337841";
import { ConfirmProvider } from "/src/context/ConfirmContext.jsx";
export function App() {
	return /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(ConfirmProvider, { children: [
		/* @__PURE__ */ _jsxDEV(SyncStatusBanner, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 567,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(ToastNotification, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 568,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(PanelConflictosCircuitos, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 569,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Routes, { children: [
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/login",
				element: /* @__PURE__ */ _jsxDEV(LoginView, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 571,
					columnNumber: 41
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 571,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(SidebarLayout, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 574,
					columnNumber: 43
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 574,
					columnNumber: 27
				}, this),
				children: [
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/",
						element: /* @__PURE__ */ _jsxDEV(DashboardView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 575,
							columnNumber: 38
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 575,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/reportes",
						element: /* @__PURE__ */ _jsxDEV(ReportesView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 576,
							columnNumber: 46
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 576,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/backups",
						element: /* @__PURE__ */ _jsxDEV(BackupView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 577,
							columnNumber: 45
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 577,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/backup",
						element: /* @__PURE__ */ _jsxDEV(BackupView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 578,
							columnNumber: 44
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 578,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/empresa/:companyId",
						element: /* @__PURE__ */ _jsxDEV(EmpresaView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 579,
							columnNumber: 56
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 579,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/empresa/:companyId/proyecto/:proyectoId",
						element: /* @__PURE__ */ _jsxDEV(ProyectoView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 580,
							columnNumber: 77
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 580,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/empresa/:companyId/proyecto/:proyectoId/informe",
						element: /* @__PURE__ */ _jsxDEV(InformeCompiladoView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 581,
							columnNumber: 85
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 581,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/empresa/:companyId/tablero/:tableroId",
						element: /* @__PURE__ */ _jsxDEV(TableroWrapper, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 582,
							columnNumber: 75
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 582,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 574,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "*",
				element: /* @__PURE__ */ _jsxDEV(Navigate, {
					to: "/",
					replace: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 585,
					columnNumber: 36
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 585,
				columnNumber: 11
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 570,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 566,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 565,
		columnNumber: 5
	}, this);
}
_c3 = App;
export default App;
var _c, _c2, _c3;
$RefreshReg$(_c, "ProtectedRoute");
$RefreshReg$(_c2, "TableroWrapper");
$RefreshReg$(_c3, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx?t=1790793862643";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZUFBZSxRQUFRLE9BQU8sVUFBVSxXQUFXLG1CQUFtQjtBQUMvRSxPQUFPLFlBQVksZ0NBQWdDOztBQUduRCxPQUFPLGVBQWU7QUFDdEIsT0FBTyxtQkFBbUI7QUFDMUIsT0FBTyxpQkFBaUI7QUFDeEIsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyxzQkFBc0I7QUFDN0IsT0FBTywwQkFBMEI7QUFDakMsT0FBTyw0QkFBNEI7QUFDbkMsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyx1QkFBdUI7QUFDOUIsT0FBTywyQkFBMkI7QUFDbEMsT0FBTywwQkFBMEI7QUFDakMsT0FBTyxrQkFBa0I7QUFDekIsT0FBTyxnQkFBZ0I7QUFDdkIsT0FBTyxtQkFBbUI7QUFDMUIsU0FBUyxXQUFXLE1BQU0sUUFBUSxlQUFlOzs7OztBQUdqRCxNQUFNLGtCQUFrQixFQUFFLGVBQWU7O0NBQ3ZDLE1BQU0sT0FBTyxVQUFVLFVBQVUsTUFBTSxJQUFJO0NBQzNDLE1BQU0sV0FBVyxPQUFPLGlCQUFpQixjQUFjLGFBQWEsUUFBUSxPQUFPLElBQUk7Q0FDdkYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVO0VBQ3RCLE9BQU8sd0JBQUMsVUFBRDtHQUFVLElBQUc7R0FBUztFQUFTOzs7OztDQUN4QztDQUNBLE9BQU87QUFDVDs7Ozs7O0FBR0EsTUFBTSx1QkFBdUI7O0NBQzNCLE1BQU0sRUFBRSxXQUFXLGNBQWMsVUFBVTtDQUMzQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLEVBQUUsV0FBVyxlQUFlLG1CQUFtQixxQkFBcUIsV0FBVywyQkFBMkIsU0FBUztDQUN6SCxNQUFNLE9BQU8sVUFBVSxVQUFVLE1BQU0sSUFBSTtDQUMzQyxNQUFNLFNBQVMsVUFBVSxVQUFVLE1BQU0sTUFBTTtDQUUvQyxJQUFJLFVBQVUsVUFBVSxNQUFNLE1BQU0sRUFBRSxPQUFPLFNBQVM7O0NBR3RELElBQUksVUFBVTtDQUNkLElBQUksY0FBYztDQUNsQixJQUFJLGdCQUFnQjtDQUNwQixJQUFJLFVBQVU7Q0FDZCxJQUFJLGlCQUFpQjs7Q0FHckIsSUFBSSxTQUFTO0VBQ1gsTUFBTSxhQUFhLFFBQVEsdUJBQXVCLENBQUM7RUFDbkQsTUFBTSxTQUFTLFdBQVcsTUFBTSxNQUFNLEVBQUUsT0FBTyxTQUFTO0VBQ3hELElBQUksUUFBUTtHQUNWLFVBQVU7RUFDWixPQUFPLElBQUksUUFBUSxXQUFXO0dBQzVCLEtBQUssTUFBTSxLQUFLLFFBQVEsV0FBVztJQUNqQyxNQUFNLFNBQVMsRUFBRSx1QkFBdUIsRUFBRSxZQUFZLENBQUM7SUFDdkQsTUFBTSxLQUFLLE9BQU8sTUFBTSxNQUFNLEVBQUUsT0FBTyxTQUFTO0lBQ2hELElBQUksSUFBSTtLQUNOLFVBQVU7S0FDVixpQkFBaUI7S0FDakI7SUFDRjtJQUNBLE1BQU0sVUFBVSxFQUFFLDJCQUEyQixFQUFFLGlCQUFpQixDQUFDO0lBQ2pFLE1BQU0sSUFBSSxRQUFRLE1BQU0sUUFBUSxJQUFJLE9BQU8sU0FBUztJQUNwRCxJQUFJLEdBQUc7S0FDTCxjQUFjO0tBQ2QsaUJBQWlCO0tBQ2pCO0lBQ0Y7SUFDQSxNQUFNLFNBQVMsRUFBRSxrQkFBa0IsQ0FBQztJQUNwQyxNQUFNLEtBQUssT0FBTyxNQUFNLFNBQVMsS0FBSyxPQUFPLFNBQVM7SUFDdEQsSUFBSSxJQUFJO0tBQ04sZ0JBQWdCO0tBQ2hCLGlCQUFpQjtLQUNqQjtJQUNGO0lBQ0EsTUFBTSxVQUFVLEVBQUUsV0FBVyxDQUFDO0lBQzlCLE1BQU0sTUFBTSxRQUFRLE1BQU0sU0FBUyxLQUFLLE9BQU8sU0FBUztJQUN4RCxJQUFJLEtBQUs7S0FDUCxVQUFVO0tBQ1YsaUJBQWlCO0tBQ2pCO0lBQ0Y7R0FDRjtFQUNGO0NBQ0Y7O0NBR0EsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUMsU0FBUztFQUMxRCxLQUFLLE1BQU0sS0FBSyxXQUFXO0dBQ3pCLElBQUksRUFBRSxXQUFXO0lBQ2YsS0FBSyxNQUFNLEtBQUssRUFBRSxXQUFXO0tBQzNCLE1BQU0sU0FBUyxFQUFFLHVCQUF1QixFQUFFLFlBQVksQ0FBQztLQUN2RCxNQUFNLEtBQUssT0FBTyxNQUFNLE1BQU0sRUFBRSxPQUFPLFNBQVM7S0FDaEQsSUFBSSxJQUFJO01BQ04sVUFBVTtNQUNWLGlCQUFpQjtNQUNqQixVQUFVO01BQ1Y7S0FDRjtLQUNBLE1BQU0sVUFBVSxFQUFFLDJCQUEyQixFQUFFLGlCQUFpQixDQUFDO0tBQ2pFLE1BQU0sSUFBSSxRQUFRLE1BQU0sUUFBUSxJQUFJLE9BQU8sU0FBUztLQUNwRCxJQUFJLEdBQUc7TUFDTCxjQUFjO01BQ2QsaUJBQWlCO01BQ2pCLFVBQVU7TUFDVjtLQUNGO0tBQ0EsTUFBTSxTQUFTLEVBQUUsa0JBQWtCLENBQUM7S0FDcEMsTUFBTSxLQUFLLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxTQUFTO0tBQ3RELElBQUksSUFBSTtNQUNOLGdCQUFnQjtNQUNoQixpQkFBaUI7TUFDakIsVUFBVTtNQUNWO0tBQ0Y7S0FDQSxNQUFNLFVBQVUsRUFBRSxXQUFXLENBQUM7S0FDOUIsTUFBTSxNQUFNLFFBQVEsTUFBTSxTQUFTLEtBQUssT0FBTyxTQUFTO0tBQ3hELElBQUksS0FBSztNQUNQLFVBQVU7TUFDVixpQkFBaUI7TUFDakIsVUFBVTtNQUNWO0tBQ0Y7SUFDRjtHQUNGO0dBQ0EsSUFBSSxXQUFXLGVBQWUsaUJBQWlCLFNBQVM7RUFDMUQ7Q0FDRjs7Q0FHQSxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTO0VBQzFELE1BQU0sZ0JBQWdCLFNBQVMsU0FBUyxDQUFDLENBQUMseUJBQXlCLENBQUM7RUFDcEUsTUFBTSxVQUFVLGNBQWMsTUFBTSxTQUFTLEtBQUssT0FBTyxTQUFTO0VBQ2xFLElBQUksU0FBUztHQUNYLGdCQUFnQjtFQUNsQjtFQUVBLE1BQU0sYUFBYSxTQUFTLFNBQVMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztFQUN0RCxNQUFNLFdBQVcsV0FBVyxNQUFNLFNBQVMsS0FBSyxPQUFPLFNBQVM7RUFDaEUsSUFBSSxVQUFVO0dBQ1osVUFBVTtFQUNaO0NBQ0Y7Q0FFQSxNQUFNLFdBQVcsaUJBQ2IsWUFBWSxVQUFVLFlBQVksZUFBZSxPQUNqRCxZQUFZO0NBRWhCLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDLFNBQVM7RUFDMUQsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBb0I7R0FBb0M7Ozs7YUFDdEUsd0JBQUMsVUFBRDtJQUFRLGVBQWUsU0FBUyxHQUFHO0lBQUcsV0FBVTtjQUE0QztHQUVwRjs7OztXQUNMOzs7Ozs7Q0FFVDtDQUVBLE1BQU0scUJBQXFCO0VBQ3pCLE9BQU87RUFDUCxTQUFTLFFBQVE7Q0FDbkI7O0NBR0EsSUFBSSxhQUFhO0VBQ2YsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBRUUsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsU0FBUyxRQUFRO01BQ2hDLFdBQVU7TUFDVixPQUFNO2dCQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O0tBQzFCOzs7O2VBQ1Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUFnRixvQkFDN0QsUUFBUSxNQUNyQjs7Ozs7ZUFDTix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDWCxZQUFZO0tBQ1g7Ozs7YUFDRDs7OzthQUNGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSxPQUFPLE1BQU07T0FDNUIsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7O2lCQUM5Qix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUI7T0FBaUI7Ozs7ZUFDOUM7Ozs7OztNQUNSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUseUJBQTBCOzs7O2lCQUMxQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBd0MsTUFBTTtPQUFZOzs7O2VBQ3ZFOzs7Ozs7TUFDTCx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUVOLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7O01BQ3ZCOzs7OztLQUNMOzs7OztZQUNDOzs7OzthQUdSLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQ2Qsd0JBQUMsc0JBQUQ7S0FDRSxpQkFBaUI7S0FDakIsV0FBVyxnQkFBZ0Isa0JBQWtCLGVBQWUsSUFBSSxXQUFXLFdBQVc7S0FDdEYsVUFBVSxNQUFNLFNBQVM7SUFDMUI7Ozs7O0dBQ0c7Ozs7V0FDSDs7Ozs7O0NBRVQ7O0NBR0EsSUFBSSxlQUFlO0VBQ2pCLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUVFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLFNBQVMsUUFBUTtNQUNoQyxXQUFVO01BQ1YsT0FBTTtnQkFFTix3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7OztLQUMxQjs7OztlQUNSLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FBZ0YsMEJBQ3ZELFFBQVEsTUFDM0I7Ozs7O2VBQ04sd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsY0FBYztLQUNiOzs7O2FBQ0Q7Ozs7YUFDRjs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsVUFBRDtPQUNFLGVBQWUsT0FBTyxNQUFNO09BQzVCLFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7OztpQkFDOUIsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1CO09BQWlCOzs7O2VBQzlDOzs7Ozs7TUFDUix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHlCQUEwQjs7OztpQkFDMUMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXdDLE1BQU07T0FBWTs7OztlQUN2RTs7Ozs7O01BQ0wsd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxXQUFVO09BQ1YsT0FBTTtpQkFFTix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztNQUN2Qjs7Ozs7S0FDTDs7Ozs7WUFDQzs7Ozs7YUFHUix3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUNkLHdCQUFDLHdCQUFEO0tBQ0UsV0FBVztLQUNYLFdBQVcsZ0JBQWdCLG9CQUFvQixnQkFBZ0IsTUFBTSxlQUFlLFlBQVksV0FBVyxXQUFXO0tBQ3RILFVBQVUsTUFBTSxTQUFTO0lBQzFCOzs7OztHQUNHOzs7O1dBQ0g7Ozs7OztDQUVUOztDQUdBLElBQUksU0FBUztFQUNYLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUVFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLFNBQVMsUUFBUTtNQUNoQyxXQUFVO01BQ1YsT0FBTTtnQkFFTix3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7OztLQUMxQjs7OztlQUNSLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBZ0U7S0FFMUU7Ozs7ZUFDTix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDWCxRQUFRO0tBQ1A7Ozs7YUFDRDs7OzthQUNGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSxPQUFPLE1BQU07T0FDNUIsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7O2lCQUM5Qix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUI7T0FBaUI7Ozs7ZUFDOUM7Ozs7OztNQUNSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUseUJBQTBCOzs7O2lCQUMxQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBd0MsTUFBTTtPQUFZOzs7O2VBQ3ZFOzs7Ozs7TUFDTCx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUVOLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7O01BQ3ZCOzs7OztLQUNMOzs7OztZQUNDOzs7OzthQUdSLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQ2Qsd0JBQUMsY0FBRDtLQUNFLFNBQVM7S0FDVCxXQUFXLGdCQUFnQixVQUFVLGdCQUFnQixNQUFNLFNBQVMsWUFBWSxXQUFXLFdBQVc7S0FDdEcsVUFBVSxNQUFNLFNBQVM7SUFDMUI7Ozs7O0dBQ0c7Ozs7V0FDSDs7Ozs7O0NBRVQ7O0NBR0EsSUFBSSxXQUFXLFFBQVEsaUJBQWlCLFlBQVk7RUFDbEQsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBRUUsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsU0FBUyxRQUFRO01BQ2hDLFdBQVU7TUFDVixPQUFNO2dCQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O0tBQzFCOzs7O2VBQ1Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFnRTtLQUUxRTs7OztlQUNOLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNYLFFBQVE7S0FDUDs7OzthQUNEOzs7O2FBQ0Y7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLE9BQU8sTUFBTTtPQUM1QixXQUFVO09BQ1YsT0FBTTtpQkFIUixDQUtFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7aUJBQzlCLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFtQjtPQUFpQjs7OztlQUM5Qzs7Ozs7O01BQ1Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSx5QkFBMEI7Ozs7aUJBQzFDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF3QyxNQUFNO09BQVk7Ozs7ZUFDdkU7Ozs7OztNQUNMLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtPQUNWLE9BQU07aUJBRU4sd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7TUFDdkI7Ozs7O0tBQ0w7Ozs7O1lBQ0M7Ozs7O2FBR1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FDZCx3QkFBQyxtQkFBRDtLQUNFLGNBQWM7S0FDZCxXQUFXLGdCQUFnQix1QkFBdUIsZ0JBQWdCLE1BQU0sTUFBTSxXQUFXLFdBQVc7S0FDcEcsVUFBVSxNQUFNLFNBQVM7SUFDMUI7Ozs7O0dBQ0c7Ozs7V0FDSDs7Ozs7O0NBRVQ7O0NBR0EsSUFBSSxXQUFXLFFBQVEsaUJBQWlCLFdBQVc7RUFDakQsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBRUUsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsU0FBUyxRQUFRO01BQ2hDLFdBQVU7TUFDVixPQUFNO2dCQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O0tBQzFCOzs7O2VBQ1Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUFnRixzQkFDM0QsUUFBUSxNQUN2Qjs7Ozs7ZUFDTix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDWCxRQUFRO0tBQ1A7Ozs7YUFDRDs7OzthQUNGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSxPQUFPLE1BQU07T0FDNUIsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7O2lCQUM5Qix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUI7T0FBaUI7Ozs7ZUFDOUM7Ozs7OztNQUNSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUseUJBQTBCOzs7O2lCQUMxQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBd0MsTUFBTTtPQUFZOzs7O2VBQ3ZFOzs7Ozs7TUFDTCx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUVOLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7O01BQ3ZCOzs7OztLQUNMOzs7OztZQUNDOzs7OzthQUdSLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQ2Qsd0JBQUMsdUJBQUQ7S0FDRSxjQUFjO0tBQ2QsV0FBVyxnQkFBZ0IsdUJBQXVCLGdCQUFnQixNQUFNLE1BQU0sV0FBVyxXQUFXO0tBQ3BHLFVBQVUsTUFBTSxTQUFTO0lBQzFCOzs7OztHQUNHOzs7O1dBQ0g7Ozs7OztDQUVUOztDQUdBLE1BQU0sa0JBQWtCO0VBQ3RCLElBQUksU0FBUyxNQUFNO0VBQ25CLFFBQVEsU0FBUyxVQUFVO0VBQzNCLFdBQVcsU0FBUyxhQUFhO0VBQ2pDLGVBQWUsU0FBUyxpQkFBaUI7RUFDekMsTUFBTSxTQUFTLFFBQVE7RUFDdkIsVUFBVSxTQUFTLFlBQVk7RUFDL0Isd0JBQXdCLFNBQVMsMEJBQTBCO0VBQzNELEdBQUksU0FBUyxpQkFBaUIsQ0FBQztFQUMvQixVQUFVLE1BQU0sUUFBUSxTQUFTLGVBQWUsUUFBUSxJQUNwRCxRQUFRLGNBQWMsV0FDckIsTUFBTSxRQUFRLFNBQVMsUUFBUSxJQUFJLFFBQVEsV0FBVyxDQUFDO0VBQzVELGVBQWUsU0FBUyxVQUFVO0NBQ3BDO0NBRUEsTUFBTSx1QkFBdUIsZ0JBQWdCO0VBQzNDLE1BQU0sRUFDSixJQUFJLFFBQVEsV0FBVyxlQUFlLE1BQU0sVUFBVSx3QkFDdEQsZUFBZSxHQUFHLGtCQUNoQjtFQUVKLHVCQUF1QixnQkFBZ0IsTUFBTSxNQUFNLFdBQVc7R0FDNUQ7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRixDQUFDO0NBQ0g7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FFRSx3QkFBQyxVQUFEO0dBQVEsV0FBVTthQUFsQixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQ0UsZUFBZSxTQUFTLFFBQVE7S0FDaEMsV0FBVTtLQUNWLE9BQU07ZUFFTix3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7OztJQUMxQjs7OztjQUNSLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUFnRix5QkFDeEQsUUFBUSxNQUMxQjs7Ozs7Y0FDTix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gseUJBQXlCLFFBQVEsUUFBUSxRQUFRLEVBQUU7S0FDbEQ7Ozs7ZUFDSix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FBeUksUUFDbEksUUFBUSxFQUNUOzs7OzthQUNIOzs7OztZQUNGOzs7O1lBQ0Y7Ozs7O2FBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLE9BQU8sTUFBTTtNQUM1QixXQUFVO01BQ1YsT0FBTTtnQkFIUixDQUtFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7Z0JBQzlCLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFtQjtNQUFpQjs7OztjQUM5Qzs7Ozs7O0tBQ1Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSx5QkFBMEI7Ozs7Z0JBQzFDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF3QyxNQUFNO01BQVk7Ozs7Y0FDdkU7Ozs7OztLQUNMLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtNQUNWLE9BQU07Z0JBRU4sd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7S0FDdkI7Ozs7O0lBQ0w7Ozs7O1dBQ0M7Ozs7O1lBR1Isd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFDZCx3QkFBQyxrQkFBRDtJQUNFLGFBQWE7SUFDYixpQkFBaUI7SUFDakIsVUFBVSxNQUFNLFNBQVM7R0FDMUI7Ozs7O0VBQ0c7Ozs7VUFDSDs7Ozs7O0FBRVQ7Ozs7Ozs7Ozs7O0FBRUEsT0FBTyxzQkFBc0I7QUFDN0IsT0FBTyx1QkFBdUI7QUFDOUIsT0FBTyw4QkFBOEI7QUFDckMsU0FBUyx1QkFBdUI7QUFFaEMsT0FBTyxTQUFTLE1BQU07Q0FDcEIsT0FDRSx3QkFBQyxlQUFELFlBQ0Usd0JBQUMsaUJBQUQ7RUFDRSx3QkFBQyxrQkFBRCxDQUFtQjs7Ozs7RUFDbkIsd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7O0VBQ3BCLHdCQUFDLDBCQUFELENBQTJCOzs7OztFQUMzQix3QkFBQyxRQUFEO0dBQ0Usd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBUyxTQUFTLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7R0FBSTs7Ozs7R0FHOUMsd0JBQUMsT0FBRDtJQUFPLFNBQVMsd0JBQUMsZ0JBQUQsWUFBZ0Isd0JBQUMsZUFBRCxDQUFnQjs7OzthQUFpQjs7Ozs7Y0FBakU7S0FDRSx3QkFBQyxPQUFEO01BQU8sTUFBSztNQUFJLFNBQVMsd0JBQUMsZUFBRCxDQUFnQjs7Ozs7S0FBSTs7Ozs7S0FDN0Msd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBWSxTQUFTLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7S0FBSTs7Ozs7S0FDcEQsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBVyxTQUFTLHdCQUFDLFlBQUQsQ0FBYTs7Ozs7S0FBSTs7Ozs7S0FDakQsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBVSxTQUFTLHdCQUFDLFlBQUQsQ0FBYTs7Ozs7S0FBSTs7Ozs7S0FDaEQsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBc0IsU0FBUyx3QkFBQyxhQUFELENBQWM7Ozs7O0tBQUk7Ozs7O0tBQzdELHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQTJDLFNBQVMsd0JBQUMsY0FBRCxDQUFlOzs7OztLQUFJOzs7OztLQUNuRix3QkFBQyxPQUFEO01BQU8sTUFBSztNQUFtRCxTQUFTLHdCQUFDLHNCQUFELENBQXVCOzs7OztLQUFJOzs7OztLQUNuRyx3QkFBQyxPQUFEO01BQU8sTUFBSztNQUF5QyxTQUFTLHdCQUFDLGdCQUFELENBQWlCOzs7OztLQUFJOzs7OztJQUM5RTs7Ozs7O0dBRVAsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBSSxTQUFTLHdCQUFDLFVBQUQ7S0FBVSxJQUFHO0tBQUk7SUFBUzs7Ozs7R0FBSTs7Ozs7RUFDakQ7Ozs7O0NBQ087Ozs7VUFDSjs7Ozs7QUFFbkI7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IEJyb3dzZXJSb3V0ZXIsIFJvdXRlcywgUm91dGUsIE5hdmlnYXRlLCB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB1c2VTdG9yZSwgeyBmb3JtYXRFbGVtZW50VGl0bGVXaXRoSWQgfSBmcm9tICcuL3N0b3JlL3VzZVN0b3JlJztcclxuXHJcbi8vIFZpc3Rhc1xyXG5pbXBvcnQgTG9naW5WaWV3IGZyb20gJy4vdmlld3MvTG9naW5WaWV3JztcclxuaW1wb3J0IERhc2hib2FyZFZpZXcgZnJvbSAnLi92aWV3cy9EYXNoYm9hcmRWaWV3JztcclxuaW1wb3J0IEVtcHJlc2FWaWV3IGZyb20gJy4vdmlld3MvRW1wcmVzYVZpZXcnO1xyXG5pbXBvcnQgUHJveWVjdG9WaWV3IGZyb20gJy4vdmlld3MvUHJveWVjdG9WaWV3JztcclxuaW1wb3J0IFRhYmxlcm9Db21wb25lbnQgZnJvbSAnLi9jb21wb25lbnRzL1RhYmxlcm9Db21wb25lbnQnO1xyXG5pbXBvcnQgU3ViZXN0YWNpb25Db21wb25lbnQgZnJvbSAnLi9jb21wb25lbnRzL1N1YmVzdGFjaW9uQ29tcG9uZW50JztcclxuaW1wb3J0IFB1bnRvTWVkaWNpb25Db21wb25lbnQgZnJvbSAnLi9jb21wb25lbnRzL1B1bnRvTWVkaWNpb25Db21wb25lbnQnO1xyXG5pbXBvcnQgQ2NtQ29tcG9uZW50IGZyb20gJy4vY29tcG9uZW50cy9DY21Db21wb25lbnQnO1xyXG5pbXBvcnQgVHJhbnNmZXJDb21wb25lbnQgZnJvbSAnLi9jb21wb25lbnRzL1RyYW5zZmVyQ29tcG9uZW50JztcclxuaW1wb3J0IEZpY2hhVGVjbmljYUNvbXBvbmVudCBmcm9tICcuL2NvbXBvbmVudHMvRmljaGFUZWNuaWNhQ29tcG9uZW50JztcclxuaW1wb3J0IEluZm9ybWVDb21waWxhZG9WaWV3IGZyb20gJy4vdmlld3MvSW5mb3JtZUNvbXBpbGFkb1ZpZXcnO1xyXG5pbXBvcnQgUmVwb3J0ZXNWaWV3IGZyb20gJy4vdmlld3MvUmVwb3J0ZXNWaWV3JztcclxuaW1wb3J0IEJhY2t1cFZpZXcgZnJvbSAnLi92aWV3cy9CYWNrdXBWaWV3JztcclxuaW1wb3J0IFNpZGViYXJMYXlvdXQgZnJvbSAnLi9jb21wb25lbnRzL1NpZGViYXJMYXlvdXQnO1xyXG5pbXBvcnQgeyBBcnJvd0xlZnQsIFVzZXIsIExvZ091dCwgUHJpbnRlciB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XHJcblxyXG4vLyBXcmFwcGVyIHBhcmEgUnV0YXMgUHJvdGVnaWRhc1xyXG5jb25zdCBQcm90ZWN0ZWRSb3V0ZSA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICBjb25zdCB1c2VyID0gdXNlU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS51c2VyKTtcclxuICBjb25zdCBoYXNUb2tlbiA9IHR5cGVvZiBsb2NhbFN0b3JhZ2UgIT09ICd1bmRlZmluZWQnID8gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Rva2VuJykgOiBudWxsO1xyXG4gIGlmICghdXNlciAmJiAhaGFzVG9rZW4pIHtcclxuICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIC8+O1xyXG4gIH1cclxuICByZXR1cm4gY2hpbGRyZW47XHJcbn07XHJcblxyXG4vLyBXcmFwcGVyIHBhcmEgY2FyZ2FyIGVsIFRhYmxlcm9Db21wb25lbnQsIFN1YmVzdGFjaW9uQ29tcG9uZW50LCBQdW50b01lZGljaW9uQ29tcG9uZW50IG8gQ2NtQ29tcG9uZW50IGNvbiBsb3MgcGFyw6FtZXRyb3MgZGUgbGEgVVJMXHJcbmNvbnN0IFRhYmxlcm9XcmFwcGVyID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgY29tcGFueUlkLCB0YWJsZXJvSWQgfSA9IHVzZVBhcmFtcygpO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCB7IGNvbXBhbmllcywgdXBkYXRlVGFibGVybywgdXBkYXRlU3ViZXN0YWNpb24sIHVwZGF0ZVB1bnRvTWVkaWNpb24sIHVwZGF0ZUNjbSwgdXBkYXRlRWxlbWVudG9VbmlmaWxhciB9ID0gdXNlU3RvcmUoKTtcclxuICBjb25zdCB1c2VyID0gdXNlU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS51c2VyKTtcclxuICBjb25zdCBsb2dvdXQgPSB1c2VTdG9yZSgoc3RhdGUpID0+IHN0YXRlLmxvZ291dCk7XHJcblxyXG4gIGxldCBjb21wYW55ID0gY29tcGFuaWVzLmZpbmQoKGMpID0+IGMuaWQgPT09IGNvbXBhbnlJZCk7XHJcblxyXG4gIC8vIEJ1c2NhciBlbiBlbGVtZW50b3MgdW5pZmlsYXJlcywgc3ViZXN0YWNpb25lcywgcHVudG9zIGRlIG1lZGljacOzbiBvIENDTVxyXG4gIGxldCBlbGVtZW50ID0gbnVsbDtcclxuICBsZXQgc3ViZXN0YWNpb24gPSBudWxsO1xyXG4gIGxldCBwdW50b01lZGljaW9uID0gbnVsbDtcclxuICBsZXQgY2NtSXRlbSA9IG51bGw7XHJcbiAgbGV0IHRhcmdldFByb3llY3RvID0gbnVsbDtcclxuXHJcbiAgLy8gMS4gQnVzY2FyIGVuIGxhIGVtcHJlc2EgZXNwZWNpZmljYWRhIHBvciBVUkxcclxuICBpZiAoY29tcGFueSkge1xyXG4gICAgY29uc3QgY29tcEVsTGlzdCA9IGNvbXBhbnkuZWxlbWVudG9zVW5pZmlsYXJlcyB8fCBbXTtcclxuICAgIGNvbnN0IGNvbXBFbCA9IGNvbXBFbExpc3QuZmluZCgoZSkgPT4gZS5pZCA9PT0gdGFibGVyb0lkKTtcclxuICAgIGlmIChjb21wRWwpIHtcclxuICAgICAgZWxlbWVudCA9IGNvbXBFbDtcclxuICAgIH0gZWxzZSBpZiAoY29tcGFueS5wcm95ZWN0b3MpIHtcclxuICAgICAgZm9yIChjb25zdCBwIG9mIGNvbXBhbnkucHJveWVjdG9zKSB7XHJcbiAgICAgICAgY29uc3QgZWxMaXN0ID0gcC5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IHAudGFibGVyb3MgfHwgW107XHJcbiAgICAgICAgY29uc3QgZWwgPSBlbExpc3QuZmluZCgoZSkgPT4gZS5pZCA9PT0gdGFibGVyb0lkKTtcclxuICAgICAgICBpZiAoZWwpIHtcclxuICAgICAgICAgIGVsZW1lbnQgPSBlbDtcclxuICAgICAgICAgIHRhcmdldFByb3llY3RvID0gcDtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBzdWJMaXN0ID0gcC5pbnNwZWNjaW9uZXNTdWJlc3RhY2lvbiB8fCBwLnN1YmVzdGFjaW9uZXMgfHwgW107XHJcbiAgICAgICAgY29uc3QgcyA9IHN1Ykxpc3QuZmluZCgoc3ViKSA9PiBzdWIuaWQgPT09IHRhYmxlcm9JZCk7XHJcbiAgICAgICAgaWYgKHMpIHtcclxuICAgICAgICAgIHN1YmVzdGFjaW9uID0gcztcclxuICAgICAgICAgIHRhcmdldFByb3llY3RvID0gcDtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBwbUxpc3QgPSBwLnB1bnRvc01lZGljaW9uIHx8IFtdO1xyXG4gICAgICAgIGNvbnN0IHBtID0gcG1MaXN0LmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IHRhYmxlcm9JZCk7XHJcbiAgICAgICAgaWYgKHBtKSB7XHJcbiAgICAgICAgICBwdW50b01lZGljaW9uID0gcG07XHJcbiAgICAgICAgICB0YXJnZXRQcm95ZWN0byA9IHA7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgY2NtTGlzdCA9IHAuY2NtTGlzdCB8fCBbXTtcclxuICAgICAgICBjb25zdCBjY20gPSBjY21MaXN0LmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IHRhYmxlcm9JZCk7XHJcbiAgICAgICAgaWYgKGNjbSkge1xyXG4gICAgICAgICAgY2NtSXRlbSA9IGNjbTtcclxuICAgICAgICAgIHRhcmdldFByb3llY3RvID0gcDtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gMi4gU2kgbm8gc2UgZW5jb250csOzIGVuIGxhIGVtcHJlc2EgZGFkYSwgYnVzY2FyIHRyYW5zdmVyc2FsbWVudGUgZW4gdG9kYXMgbGFzIGVtcHJlc2FzIGRlIGxhIHRpZW5kYVxyXG4gIGlmICghZWxlbWVudCAmJiAhc3ViZXN0YWNpb24gJiYgIXB1bnRvTWVkaWNpb24gJiYgIWNjbUl0ZW0pIHtcclxuICAgIGZvciAoY29uc3QgYyBvZiBjb21wYW5pZXMpIHtcclxuICAgICAgaWYgKGMucHJveWVjdG9zKSB7XHJcbiAgICAgICAgZm9yIChjb25zdCBwIG9mIGMucHJveWVjdG9zKSB7XHJcbiAgICAgICAgICBjb25zdCBlbExpc3QgPSBwLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgcC50YWJsZXJvcyB8fCBbXTtcclxuICAgICAgICAgIGNvbnN0IGVsID0gZWxMaXN0LmZpbmQoKGUpID0+IGUuaWQgPT09IHRhYmxlcm9JZCk7XHJcbiAgICAgICAgICBpZiAoZWwpIHtcclxuICAgICAgICAgICAgZWxlbWVudCA9IGVsO1xyXG4gICAgICAgICAgICB0YXJnZXRQcm95ZWN0byA9IHA7XHJcbiAgICAgICAgICAgIGNvbXBhbnkgPSBjO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGNvbnN0IHN1Ykxpc3QgPSBwLmluc3BlY2Npb25lc1N1YmVzdGFjaW9uIHx8IHAuc3ViZXN0YWNpb25lcyB8fCBbXTtcclxuICAgICAgICAgIGNvbnN0IHMgPSBzdWJMaXN0LmZpbmQoKHN1YikgPT4gc3ViLmlkID09PSB0YWJsZXJvSWQpO1xyXG4gICAgICAgICAgaWYgKHMpIHtcclxuICAgICAgICAgICAgc3ViZXN0YWNpb24gPSBzO1xyXG4gICAgICAgICAgICB0YXJnZXRQcm95ZWN0byA9IHA7XHJcbiAgICAgICAgICAgIGNvbXBhbnkgPSBjO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGNvbnN0IHBtTGlzdCA9IHAucHVudG9zTWVkaWNpb24gfHwgW107XHJcbiAgICAgICAgICBjb25zdCBwbSA9IHBtTGlzdC5maW5kKChpdGVtKSA9PiBpdGVtLmlkID09PSB0YWJsZXJvSWQpO1xyXG4gICAgICAgICAgaWYgKHBtKSB7XHJcbiAgICAgICAgICAgIHB1bnRvTWVkaWNpb24gPSBwbTtcclxuICAgICAgICAgICAgdGFyZ2V0UHJveWVjdG8gPSBwO1xyXG4gICAgICAgICAgICBjb21wYW55ID0gYztcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBjb25zdCBjY21MaXN0ID0gcC5jY21MaXN0IHx8IFtdO1xyXG4gICAgICAgICAgY29uc3QgY2NtID0gY2NtTGlzdC5maW5kKChpdGVtKSA9PiBpdGVtLmlkID09PSB0YWJsZXJvSWQpO1xyXG4gICAgICAgICAgaWYgKGNjbSkge1xyXG4gICAgICAgICAgICBjY21JdGVtID0gY2NtO1xyXG4gICAgICAgICAgICB0YXJnZXRQcm95ZWN0byA9IHA7XHJcbiAgICAgICAgICAgIGNvbXBhbnkgPSBjO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGVsZW1lbnQgfHwgc3ViZXN0YWNpb24gfHwgcHVudG9NZWRpY2lvbiB8fCBjY21JdGVtKSBicmVhaztcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIDMuIEZhbGxiYWNrIGEgYXJyZWdsb3MgZGUgZXN0YWRvIGxvY2FsIHNpIGVsIGVsZW1lbnRvIGZ1ZSByZWNpw6luIGNyZWFkb1xyXG4gIGlmICghZWxlbWVudCAmJiAhc3ViZXN0YWNpb24gJiYgIXB1bnRvTWVkaWNpb24gJiYgIWNjbUl0ZW0pIHtcclxuICAgIGNvbnN0IHB1bnRvc0xvY2FsZXMgPSB1c2VTdG9yZS5nZXRTdGF0ZSgpLnB1bnRvc01lZGljaW9uTG9jYWxlcyB8fCBbXTtcclxuICAgIGNvbnN0IHBtTG9jYWwgPSBwdW50b3NMb2NhbGVzLmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IHRhYmxlcm9JZCk7XHJcbiAgICBpZiAocG1Mb2NhbCkge1xyXG4gICAgICBwdW50b01lZGljaW9uID0gcG1Mb2NhbDtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBjY21Mb2NhbGVzID0gdXNlU3RvcmUuZ2V0U3RhdGUoKS5jY21Mb2NhbGVzIHx8IFtdO1xyXG4gICAgY29uc3QgY2NtTG9jYWwgPSBjY21Mb2NhbGVzLmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IHRhYmxlcm9JZCk7XHJcbiAgICBpZiAoY2NtTG9jYWwpIHtcclxuICAgICAgY2NtSXRlbSA9IGNjbUxvY2FsO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgYmFja1BhdGggPSB0YXJnZXRQcm95ZWN0b1xyXG4gICAgPyBgL2VtcHJlc2EvJHtjb21wYW55SWR9L3Byb3llY3RvLyR7dGFyZ2V0UHJveWVjdG8uaWR9YFxyXG4gICAgOiBgL2VtcHJlc2EvJHtjb21wYW55SWR9YDtcclxuXHJcbiAgaWYgKCFlbGVtZW50ICYmICFzdWJlc3RhY2lvbiAmJiAhcHVudG9NZWRpY2lvbiAmJiAhY2NtSXRlbSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNiB0ZXh0LWNlbnRlciBzcGFjZS15LTQgZm9udC1zYW5zXCI+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkXCI+RWxlbWVudG8gbyBFbXByZXNhIG5vIGVuY29udHJhZG88L2gyPlxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy8nKX0gY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIHRleHQteHNcIj5cclxuICAgICAgICAgIFZvbHZlciBhbCBEYXNoYm9hcmRcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgbG9nb3V0KCk7XHJcbiAgICBuYXZpZ2F0ZSgnL2xvZ2luJyk7XHJcbiAgfTtcclxuXHJcbiAgLy8gMS4gUmVuZGVyaXphciBJbnNwZWNjacOzbiBkZSBTdWJlc3RhY2nDs25cclxuICBpZiAoc3ViZXN0YWNpb24pIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTEwMCBmbGV4IGZsZXgtY29sIGFudGlhbGlhc2VkXCI+XHJcbiAgICAgICAgey8qIFRvcCBOYXZiYXIgKi99XHJcbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBweC00IHB5LTMgbWQ6cHgtNiBtZDpweS00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzaGFkb3ctbWQgbm8tcHJpbnRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGJhY2tQYXRoKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgaG92ZXI6Ymctc2xhdGUtOTAwIHJvdW5kZWQteGwgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiVm9sdmVyIGFsIFByb3llY3RvXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNTAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgIFN1YmVzdGFjacOzbiBlbjoge2NvbXBhbnkubm9tYnJlfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBhbmltYXRlLWZhZGUtaW5cIj5cclxuICAgICAgICAgICAgICAgIHtzdWJlc3RhY2lvbi5ub21icmV9XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB3aW5kb3cucHJpbnQoKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIGFjdGl2ZTpzY2FsZS05NSB0ZXh0LXNsYXRlLTk1MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ibGFjayBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiR3VhcmRhciBjb21vIFBERiBvIEltcHJpbWlyIGVzdGEgSW5zcGVjY2nDs25cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPkd1YXJkYXIgUERGPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gc206ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0xLjUgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwXCIgLz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj57dXNlcj8uZW1haWx9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIuNSBiZy1zbGF0ZS05MDAgaG92ZXI6YmctcmVkLTk1MC80MCBob3Zlcjp0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXJlZC05MDAvNjAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgdGl0bGU9XCJDZXJyYXIgU2VzacOzblwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8TG9nT3V0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvaGVhZGVyPlxyXG5cclxuICAgICAgICB7LyogRm9ybXVsYXJpbyBkZSBTdWJlc3RhY2nDs24gKi99XHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG1heC13LTd4bCB3LWZ1bGwgbXgtYXV0byBweC0zIHB5LTQgbWQ6cHgtNiBtZDpweS04XCI+XHJcbiAgICAgICAgICA8U3ViZXN0YWNpb25Db21wb25lbnRcclxuICAgICAgICAgICAgc3ViZXN0YWNpb25EYXRhPXtzdWJlc3RhY2lvbn1cclxuICAgICAgICAgICAgb25VcGRhdGU9eyh1cGRhdGVkRGF0YSkgPT4gdXBkYXRlU3ViZXN0YWNpb24odGFyZ2V0UHJveWVjdG8uaWQsIHRhYmxlcm9JZCwgdXBkYXRlZERhdGEpfVxyXG4gICAgICAgICAgICByZWFkT25seT17dXNlcj8ucm9sZSA9PT0gJ0NMSUVOVCd9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gMS41LiBSZW5kZXJpemFyIFB1bnRvIGRlIE1lZGljacOzbiB5IFN1bWluaXN0cm9cclxuICBpZiAocHVudG9NZWRpY2lvbikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wgYW50aWFsaWFzZWRcIj5cclxuICAgICAgICB7LyogVG9wIE5hdmJhciAqL31cclxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHB4LTQgcHktMyBtZDpweC02IG1kOnB5LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNoYWRvdy1tZCBuby1wcmludFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYmFja1BhdGgpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBob3ZlcjpiZy1zbGF0ZS05MDAgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgdGl0bGU9XCJWb2x2ZXIgYWwgUHJveWVjdG9cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci01MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgUHVudG8gZGUgTWVkaWNpw7NuIGVuOiB7Y29tcGFueS5ub21icmV9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIGFuaW1hdGUtZmFkZS1pblwiPlxyXG4gICAgICAgICAgICAgICAge3B1bnRvTWVkaWNpb24ubm9tYnJlfVxyXG4gICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LnByaW50KCl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCBhY3RpdmU6c2NhbGUtOTUgdGV4dC1zbGF0ZS05NTAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtYmxhY2sgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICB0aXRsZT1cIkd1YXJkYXIgY29tbyBQREYgbyBJbXByaW1pciBlc3RlIExldmFudGFtaWVudG9cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPkd1YXJkYXIgUERGPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gc206ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0xLjUgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwXCIgLz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj57dXNlcj8uZW1haWx9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIuNSBiZy1zbGF0ZS05MDAgaG92ZXI6YmctcmVkLTk1MC80MCBob3Zlcjp0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXJlZC05MDAvNjAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgdGl0bGU9XCJDZXJyYXIgU2VzacOzblwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8TG9nT3V0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvaGVhZGVyPlxyXG5cclxuICAgICAgICB7LyogRm9ybXVsYXJpbyBkZSBQdW50byBkZSBNZWRpY2nDs24gKi99XHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG1heC13LTd4bCB3LWZ1bGwgbXgtYXV0byBweC0zIHB5LTQgbWQ6cHgtNiBtZDpweS04XCI+XHJcbiAgICAgICAgICA8UHVudG9NZWRpY2lvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICBwdW50b0RhdGE9e3B1bnRvTWVkaWNpb259XHJcbiAgICAgICAgICAgIG9uVXBkYXRlPXsodXBkYXRlZERhdGEpID0+IHVwZGF0ZVB1bnRvTWVkaWNpb24odGFyZ2V0UHJveWVjdG8/LmlkIHx8IHB1bnRvTWVkaWNpb24/LnByb3llY3RvSWQsIHRhYmxlcm9JZCwgdXBkYXRlZERhdGEpfVxyXG4gICAgICAgICAgICByZWFkT25seT17dXNlcj8ucm9sZSA9PT0gJ0NMSUVOVCd9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gMS4yIFJlbmRlcml6YXIgQ2VudHJvIGRlIENvbnRyb2wgZGUgTW90b3JlcyAoQ0NNKVxyXG4gIGlmIChjY21JdGVtKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBhbnRpYWxpYXNlZFwiPlxyXG4gICAgICAgIHsvKiBUb3AgTmF2YmFyICovfVxyXG4gICAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHgtNCBweS0zIG1kOnB4LTYgbWQ6cHktNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc2hhZG93LW1kIG5vLXByaW50XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShiYWNrUGF0aCl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGhvdmVyOmJnLXNsYXRlLTkwMCByb3VuZGVkLXhsIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICB0aXRsZT1cIlZvbHZlciBhbCBQcm95ZWN0b1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTUwMCBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICBMZXZhbnRhbWllbnRvIGRlIENDTVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBhbmltYXRlLWZhZGUtaW5cIj5cclxuICAgICAgICAgICAgICAgIHtjY21JdGVtLm5vbWJyZX1cclxuICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5wcmludCgpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0yIGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgYWN0aXZlOnNjYWxlLTk1IHRleHQtc2xhdGUtOTUwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LWJsYWNrIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgdGl0bGU9XCJHdWFyZGFyIGNvbW8gUERGIG8gSW1wcmltaXIgZXN0ZSBMZXZhbnRhbWllbnRvXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5HdWFyZGFyIFBERjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMS41IGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwXCI+e3VzZXI/LmVtYWlsfTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yLjUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXJlZC05NTAvNDAgaG92ZXI6dGV4dC1yZWQtNDAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1yZWQtOTAwLzYwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiQ2VycmFyIFNlc2nDs25cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPExvZ091dCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgICAgey8qIEZvcm11bGFyaW8gZGUgQ0NNICovfVxyXG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBtYXgtdy03eGwgdy1mdWxsIG14LWF1dG8gcHgtMyBweS00IG1kOnB4LTYgbWQ6cHktOFwiPlxyXG4gICAgICAgICAgPENjbUNvbXBvbmVudFxyXG4gICAgICAgICAgICBjY21EYXRhPXtjY21JdGVtfVxyXG4gICAgICAgICAgICBvblVwZGF0ZT17KHVwZGF0ZWREYXRhKSA9PiB1cGRhdGVDY20odGFyZ2V0UHJveWVjdG8/LmlkIHx8IGNjbUl0ZW0/LnByb3llY3RvSWQsIHRhYmxlcm9JZCwgdXBkYXRlZERhdGEpfVxyXG4gICAgICAgICAgICByZWFkT25seT17dXNlcj8ucm9sZSA9PT0gJ0NMSUVOVCd9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gMS4zIFJlbmRlcml6YXIgVHJhbnNmZXJlbmNpYSBFbMOpY3RyaWNhIChUUkFOU0ZFUiAvIEFUUyAvIE1UUylcclxuICBpZiAoZWxlbWVudCAmJiBlbGVtZW50LnRpcG9FbGVtZW50byA9PT0gJ1RSQU5TRkVSJykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wgYW50aWFsaWFzZWRcIj5cclxuICAgICAgICB7LyogVG9wIE5hdmJhciAqL31cclxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHB4LTQgcHktMyBtZDpweC02IG1kOnB5LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNoYWRvdy1tZCBuby1wcmludFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYmFja1BhdGgpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBob3ZlcjpiZy1zbGF0ZS05MDAgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgdGl0bGU9XCJWb2x2ZXIgYWwgUHJveWVjdG9cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci01MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgVW5pZGFkIGRlIFRyYW5zZmVyZW5jaWEgKEFUUyAvIE1UUylcclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgYW5pbWF0ZS1mYWRlLWluXCI+XHJcbiAgICAgICAgICAgICAgICB7ZWxlbWVudC5ub21icmV9XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB3aW5kb3cucHJpbnQoKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIGFjdGl2ZTpzY2FsZS05NSB0ZXh0LXNsYXRlLTk1MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ibGFjayBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiR3VhcmRhciBjb21vIFBERiBvIEltcHJpbWlyIGVzdGEgVHJhbnNmZXJlbmNpYVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+R3VhcmRhciBQREY8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTEuNSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bFwiPlxyXG4gICAgICAgICAgICAgIDxVc2VyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTMwMFwiPnt1c2VyPy5lbWFpbH08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTG9nb3V0fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1yZWQtOTUwLzQwIGhvdmVyOnRleHQtcmVkLTQwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItcmVkLTkwMC82MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICB0aXRsZT1cIkNlcnJhciBTZXNpw7NuXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxMb2dPdXQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9oZWFkZXI+XHJcblxyXG4gICAgICAgIHsvKiBDb21wb25lbnRlIGRlIFRyYW5zZmVyZW5jaWEgKi99XHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG1heC13LTd4bCB3LWZ1bGwgbXgtYXV0byBweC0zIHB5LTQgbWQ6cHgtNiBtZDpweS04XCI+XHJcbiAgICAgICAgICA8VHJhbnNmZXJDb21wb25lbnRcclxuICAgICAgICAgICAgdHJhbnNmZXJEYXRhPXtlbGVtZW50fVxyXG4gICAgICAgICAgICBvblVwZGF0ZT17KHVwZGF0ZWREYXRhKSA9PiB1cGRhdGVFbGVtZW50b1VuaWZpbGFyKHRhcmdldFByb3llY3RvPy5pZCB8fCBudWxsLCB0YWJsZXJvSWQsIHVwZGF0ZWREYXRhKX1cclxuICAgICAgICAgICAgcmVhZE9ubHk9e3VzZXI/LnJvbGUgPT09ICdDTElFTlQnfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L21haW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIC8vIDIuIFJlbmRlcml6YXIgRWxlbWVudG8gRXNwZWNpYWwgKEdlbmVyYWRvciAvIFRyYWZvIC8gT3RybylcclxuICBpZiAoZWxlbWVudCAmJiBlbGVtZW50LnRpcG9FbGVtZW50byAhPT0gJ1RBQkxFUk8nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBhbnRpYWxpYXNlZFwiPlxyXG4gICAgICAgIHsvKiBUb3AgTmF2YmFyICovfVxyXG4gICAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHgtNCBweS0zIG1kOnB4LTYgbWQ6cHktNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc2hhZG93LW1kIG5vLXByaW50XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShiYWNrUGF0aCl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGhvdmVyOmJnLXNsYXRlLTkwMCByb3VuZGVkLXhsIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICB0aXRsZT1cIlZvbHZlciBhbCBQcm95ZWN0b1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTUwMCBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICBGaWNoYSBUw6ljbmljYSBlbjoge2NvbXBhbnkubm9tYnJlfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAge2VsZW1lbnQubm9tYnJlfVxyXG4gICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LnByaW50KCl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCBhY3RpdmU6c2NhbGUtOTUgdGV4dC1zbGF0ZS05NTAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtYmxhY2sgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICB0aXRsZT1cIkd1YXJkYXIgY29tbyBQREYgbyBJbXByaW1pciBlc3RhIEZpY2hhIFTDqWNuaWNhXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5HdWFyZGFyIFBERjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMS41IGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwXCI+e3VzZXI/LmVtYWlsfTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yLjUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXJlZC05NTAvNDAgaG92ZXI6dGV4dC1yZWQtNDAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1yZWQtOTAwLzYwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiQ2VycmFyIFNlc2nDs25cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPExvZ091dCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgICAgey8qIEZpY2hhIFTDqWNuaWNhIGRlbCBFbGVtZW50byAqL31cclxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LTEgbWF4LXctN3hsIHctZnVsbCBteC1hdXRvIHB4LTMgcHktNCBtZDpweC02IG1kOnB5LThcIj5cclxuICAgICAgICAgIDxGaWNoYVRlY25pY2FDb21wb25lbnRcclxuICAgICAgICAgICAgZWxlbWVudG9EYXRhPXtlbGVtZW50fVxyXG4gICAgICAgICAgICBvblVwZGF0ZT17KHVwZGF0ZWREYXRhKSA9PiB1cGRhdGVFbGVtZW50b1VuaWZpbGFyKHRhcmdldFByb3llY3RvPy5pZCB8fCBudWxsLCB0YWJsZXJvSWQsIHVwZGF0ZWREYXRhKX1cclxuICAgICAgICAgICAgcmVhZE9ubHk9e3VzZXI/LnJvbGUgPT09ICdDTElFTlQnfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L21haW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIC8vIDMuIFJlbmRlcml6YXIgRmljaGEgZGUgVGFibGVybyBUZXJtb2dyw6FmaWNvIChUQUJMRVJPKVxyXG4gIGNvbnN0IGVucmljaGVkVGFibGVybyA9IHtcclxuICAgIGlkOiBlbGVtZW50Py5pZCB8fCB0YWJsZXJvSWQsXHJcbiAgICBub21icmU6IGVsZW1lbnQ/Lm5vbWJyZSB8fCAnVGFibGVybyBFbMOpY3RyaWNvJyxcclxuICAgIHViaWNhY2lvbjogZWxlbWVudD8udWJpY2FjaW9uIHx8ICcnLFxyXG4gICAgYWxpbWVudGFkb1BvcjogZWxlbWVudD8uYWxpbWVudGFkb1BvciB8fCAnJyxcclxuICAgIGZvdG86IGVsZW1lbnQ/LmZvdG8gfHwgbnVsbCxcclxuICAgIGZvdG9CbG9iOiBlbGVtZW50Py5mb3RvQmxvYiB8fCBudWxsLFxyXG4gICAgb2JzZXJ2YWNpb25lc0dlbmVyYWxlczogZWxlbWVudD8ub2JzZXJ2YWNpb25lc0dlbmVyYWxlcyB8fCAnJyxcclxuICAgIC4uLihlbGVtZW50Py5kYXRvc1RlY25pY29zIHx8IHt9KSxcclxuICAgIGNpcmN1aXRzOiBBcnJheS5pc0FycmF5KGVsZW1lbnQ/LmRhdG9zVGVjbmljb3M/LmNpcmN1aXRzKVxyXG4gICAgICA/IGVsZW1lbnQuZGF0b3NUZWNuaWNvcy5jaXJjdWl0c1xyXG4gICAgICA6IChBcnJheS5pc0FycmF5KGVsZW1lbnQ/LmNpcmN1aXRzKSA/IGVsZW1lbnQuY2lyY3VpdHMgOiBbXSksXHJcbiAgICBub21icmVFbXByZXNhOiBjb21wYW55Py5ub21icmUgfHwgJydcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVUYWJsZXJvID0gKHVwZGF0ZWREYXRhKSA9PiB7XHJcbiAgICBjb25zdCB7IFxyXG4gICAgICBpZCwgbm9tYnJlLCB1YmljYWNpb24sIGFsaW1lbnRhZG9Qb3IsIGZvdG8sIGZvdG9CbG9iLCBvYnNlcnZhY2lvbmVzR2VuZXJhbGVzLCBcclxuICAgICAgbm9tYnJlRW1wcmVzYSwgLi4uZGF0b3NUZWNuaWNvcyBcclxuICAgIH0gPSB1cGRhdGVkRGF0YTtcclxuXHJcbiAgICB1cGRhdGVFbGVtZW50b1VuaWZpbGFyKHRhcmdldFByb3llY3RvPy5pZCB8fCBudWxsLCB0YWJsZXJvSWQsIHtcclxuICAgICAgbm9tYnJlLFxyXG4gICAgICB1YmljYWNpb24sXHJcbiAgICAgIGFsaW1lbnRhZG9Qb3IsXHJcbiAgICAgIGZvdG8sXHJcbiAgICAgIGZvdG9CbG9iLFxyXG4gICAgICBvYnNlcnZhY2lvbmVzR2VuZXJhbGVzLFxyXG4gICAgICBkYXRvc1RlY25pY29zXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wgYW50aWFsaWFzZWRcIj5cclxuICAgICAgey8qIFRvcCBOYXZiYXIgKi99XHJcbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHgtNCBweS0zIG1kOnB4LTYgbWQ6cHktNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc2hhZG93LW1kIG5vLXByaW50XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShiYWNrUGF0aCl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBob3ZlcjpiZy1zbGF0ZS05MDAgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgIHRpdGxlPVwiVm9sdmVyIGFsIFByb3llY3RvXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci01MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIEluc3BlY2Npb25hbmRvIHBhcmE6IHtjb21wYW55Lm5vbWJyZX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAge2Zvcm1hdEVsZW1lbnRUaXRsZVdpdGhJZChlbGVtZW50Lm5vbWJyZSwgZWxlbWVudC5pZCl9XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1ibGFjayB0ZXh0LWFtYmVyLTQwMCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcHgtMi41IHB5LTAuNSByb3VuZGVkLWxnIHRleHQteHMgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICBJRDoge2VsZW1lbnQuaWR9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogVXNlciAvIExvZ291dCAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5wcmludCgpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiBiZy1hbWJlci01MDAgaG92ZXI6YmctYW1iZXItNDAwIGFjdGl2ZTpzY2FsZS05NSB0ZXh0LXNsYXRlLTk1MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ibGFjayBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICB0aXRsZT1cIkd1YXJkYXIgY29tbyBQREYgbyBJbXByaW1pciBlc3RhIFBsYW50aWxsYVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+R3VhcmRhciBQREY8L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMS41IGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgIDxVc2VyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS00MDBcIiAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj57dXNlcj8uZW1haWx9PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yLjUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXJlZC05NTAvNDAgaG92ZXI6dGV4dC1yZWQtNDAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1yZWQtOTAwLzYwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICB0aXRsZT1cIkNlcnJhciBTZXNpw7NuXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPExvZ091dCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgIHsvKiBSZW5kZXJzIFRhYmxlcm8gQ29tcG9uZW50ICovfVxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LTEgbWF4LXctN3hsIHctZnVsbCBteC1hdXRvIHB4LTMgcHktNCBtZDpweC02IG1kOnB5LThcIj5cclxuICAgICAgICA8VGFibGVyb0NvbXBvbmVudFxyXG4gICAgICAgICAgdGFibGVyb0RhdGE9e2VucmljaGVkVGFibGVyb31cclxuICAgICAgICAgIG9uVXBkYXRlVGFibGVybz17aGFuZGxlVXBkYXRlVGFibGVyb31cclxuICAgICAgICAgIHJlYWRPbmx5PXt1c2VyPy5yb2xlID09PSAnQ0xJRU5UJ31cclxuICAgICAgICAvPlxyXG4gICAgICA8L21haW4+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuaW1wb3J0IFN5bmNTdGF0dXNCYW5uZXIgZnJvbSAnLi9jb21wb25lbnRzL1N5bmNTdGF0dXNCYW5uZXInO1xyXG5pbXBvcnQgVG9hc3ROb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL1RvYXN0Tm90aWZpY2F0aW9uJztcclxuaW1wb3J0IFBhbmVsQ29uZmxpY3Rvc0NpcmN1aXRvcyBmcm9tICcuL2NvbXBvbmVudHMvUGFuZWxDb25mbGljdG9zQ2lyY3VpdG9zJztcclxuaW1wb3J0IHsgQ29uZmlybVByb3ZpZGVyIH0gZnJvbSAnLi9jb250ZXh0L0NvbmZpcm1Db250ZXh0JztcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBcHAoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxCcm93c2VyUm91dGVyPlxyXG4gICAgICA8Q29uZmlybVByb3ZpZGVyPlxyXG4gICAgICAgIDxTeW5jU3RhdHVzQmFubmVyIC8+XHJcbiAgICAgICAgPFRvYXN0Tm90aWZpY2F0aW9uIC8+XHJcbiAgICAgICAgPFBhbmVsQ29uZmxpY3Rvc0NpcmN1aXRvcyAvPlxyXG4gICAgICAgIDxSb3V0ZXM+XHJcbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxMb2dpblZpZXcgLz59IC8+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIHsvKiBSdXRhcyBwcm90ZWdpZGFzIGJham8gZWwgTGF5b3V0IGNvbiBCYXJyYSBMYXRlcmFsICovfVxyXG4gICAgICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxQcm90ZWN0ZWRSb3V0ZT48U2lkZWJhckxheW91dCAvPjwvUHJvdGVjdGVkUm91dGU+fT5cclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PERhc2hib2FyZFZpZXcgLz59IC8+XHJcbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3JlcG9ydGVzXCIgZWxlbWVudD17PFJlcG9ydGVzVmlldyAvPn0gLz5cclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvYmFja3Vwc1wiIGVsZW1lbnQ9ezxCYWNrdXBWaWV3IC8+fSAvPlxyXG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9iYWNrdXBcIiBlbGVtZW50PXs8QmFja3VwVmlldyAvPn0gLz5cclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvZW1wcmVzYS86Y29tcGFueUlkXCIgZWxlbWVudD17PEVtcHJlc2FWaWV3IC8+fSAvPlxyXG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9lbXByZXNhLzpjb21wYW55SWQvcHJveWVjdG8vOnByb3llY3RvSWRcIiBlbGVtZW50PXs8UHJveWVjdG9WaWV3IC8+fSAvPlxyXG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9lbXByZXNhLzpjb21wYW55SWQvcHJveWVjdG8vOnByb3llY3RvSWQvaW5mb3JtZVwiIGVsZW1lbnQ9ezxJbmZvcm1lQ29tcGlsYWRvVmlldyAvPn0gLz5cclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvZW1wcmVzYS86Y29tcGFueUlkL3RhYmxlcm8vOnRhYmxlcm9JZFwiIGVsZW1lbnQ9ezxUYWJsZXJvV3JhcHBlciAvPn0gLz5cclxuICAgICAgICAgIDwvUm91dGU+XHJcblxyXG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIqXCIgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL1wiIHJlcGxhY2UgLz59IC8+XHJcbiAgICAgICAgPC9Sb3V0ZXM+XHJcbiAgICAgIDwvQ29uZmlybVByb3ZpZGVyPlxyXG4gICAgPC9Ccm93c2VyUm91dGVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFwcDtcclxuIl19