import { r as __require, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-B4lejLz5.js?v=f49807c8";
//#region node_modules/localforage/dist/localforage.js
var require_localforage = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/*!
	localForage -- Offline Storage, Improved
	Version 1.10.0
	https://localforage.github.io/localForage
	(c) 2013-2017 Mozilla, Apache License 2.0
	*/
	(function(f) {
		if (typeof exports === "object" && typeof module !== "undefined") module.exports = f();
		else if (typeof define === "function" && define.amd) define([], f);
		else {
			var g;
			if (typeof window !== "undefined") g = window;
			else if (typeof global !== "undefined") g = global;
			else if (typeof self !== "undefined") g = self;
			else g = this;
			g.localforage = f();
		}
	})(function() {
		return (function e(t, n, r) {
			function s(o, u) {
				if (!n[o]) {
					if (!t[o]) {
						var a = typeof __require == "function" && __require;
						if (!u && a) return a(o, !0);
						if (i) return i(o, !0);
						var f = /* @__PURE__ */ new Error("Cannot find module '" + o + "'");
						throw f.code = "MODULE_NOT_FOUND", f;
					}
					var l = n[o] = { exports: {} };
					t[o][0].call(l.exports, function(e) {
						var n = t[o][1][e];
						return s(n ? n : e);
					}, l, l.exports, e, t, n, r);
				}
				return n[o].exports;
			}
			var i = typeof __require == "function" && __require;
			for (var o = 0; o < r.length; o++) s(r[o]);
			return s;
		})({
			1: [function(_dereq_, module$1, exports$1) {
				(function(global) {
					"use strict";
					var Mutation = global.MutationObserver || global.WebKitMutationObserver;
					var scheduleDrain;
					if (Mutation) {
						var called = 0;
						var observer = new Mutation(nextTick);
						var element = global.document.createTextNode("");
						observer.observe(element, { characterData: true });
						scheduleDrain = function() {
							element.data = called = ++called % 2;
						};
					} else if (!global.setImmediate && typeof global.MessageChannel !== "undefined") {
						var channel = new global.MessageChannel();
						channel.port1.onmessage = nextTick;
						scheduleDrain = function() {
							channel.port2.postMessage(0);
						};
					} else if ("document" in global && "onreadystatechange" in global.document.createElement("script")) scheduleDrain = function() {
						var scriptEl = global.document.createElement("script");
						scriptEl.onreadystatechange = function() {
							nextTick();
							scriptEl.onreadystatechange = null;
							scriptEl.parentNode.removeChild(scriptEl);
							scriptEl = null;
						};
						global.document.documentElement.appendChild(scriptEl);
					};
					else scheduleDrain = function() {
						setTimeout(nextTick, 0);
					};
					var draining;
					var queue = [];
					function nextTick() {
						draining = true;
						var i, oldQueue;
						var len = queue.length;
						while (len) {
							oldQueue = queue;
							queue = [];
							i = -1;
							while (++i < len) oldQueue[i]();
							len = queue.length;
						}
						draining = false;
					}
					module$1.exports = immediate;
					function immediate(task) {
						if (queue.push(task) === 1 && !draining) scheduleDrain();
					}
				}).call(this, typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {});
			}, {}],
			2: [function(_dereq_, module$2, exports$2) {
				"use strict";
				var immediate = _dereq_(1);
				/* istanbul ignore next */
				function INTERNAL() {}
				var handlers = {};
				var REJECTED = ["REJECTED"];
				var FULFILLED = ["FULFILLED"];
				var PENDING = ["PENDING"];
				module$2.exports = Promise;
				function Promise(resolver) {
					if (typeof resolver !== "function") throw new TypeError("resolver must be a function");
					this.state = PENDING;
					this.queue = [];
					this.outcome = void 0;
					if (resolver !== INTERNAL) safelyResolveThenable(this, resolver);
				}
				Promise.prototype["catch"] = function(onRejected) {
					return this.then(null, onRejected);
				};
				Promise.prototype.then = function(onFulfilled, onRejected) {
					if (typeof onFulfilled !== "function" && this.state === FULFILLED || typeof onRejected !== "function" && this.state === REJECTED) return this;
					var promise = new this.constructor(INTERNAL);
					if (this.state !== PENDING) unwrap(promise, this.state === FULFILLED ? onFulfilled : onRejected, this.outcome);
					else this.queue.push(new QueueItem(promise, onFulfilled, onRejected));
					return promise;
				};
				function QueueItem(promise, onFulfilled, onRejected) {
					this.promise = promise;
					if (typeof onFulfilled === "function") {
						this.onFulfilled = onFulfilled;
						this.callFulfilled = this.otherCallFulfilled;
					}
					if (typeof onRejected === "function") {
						this.onRejected = onRejected;
						this.callRejected = this.otherCallRejected;
					}
				}
				QueueItem.prototype.callFulfilled = function(value) {
					handlers.resolve(this.promise, value);
				};
				QueueItem.prototype.otherCallFulfilled = function(value) {
					unwrap(this.promise, this.onFulfilled, value);
				};
				QueueItem.prototype.callRejected = function(value) {
					handlers.reject(this.promise, value);
				};
				QueueItem.prototype.otherCallRejected = function(value) {
					unwrap(this.promise, this.onRejected, value);
				};
				function unwrap(promise, func, value) {
					immediate(function() {
						var returnValue;
						try {
							returnValue = func(value);
						} catch (e) {
							return handlers.reject(promise, e);
						}
						if (returnValue === promise) handlers.reject(promise, /* @__PURE__ */ new TypeError("Cannot resolve promise with itself"));
						else handlers.resolve(promise, returnValue);
					});
				}
				handlers.resolve = function(self, value) {
					var result = tryCatch(getThen, value);
					if (result.status === "error") return handlers.reject(self, result.value);
					var thenable = result.value;
					if (thenable) safelyResolveThenable(self, thenable);
					else {
						self.state = FULFILLED;
						self.outcome = value;
						var i = -1;
						var len = self.queue.length;
						while (++i < len) self.queue[i].callFulfilled(value);
					}
					return self;
				};
				handlers.reject = function(self, error) {
					self.state = REJECTED;
					self.outcome = error;
					var i = -1;
					var len = self.queue.length;
					while (++i < len) self.queue[i].callRejected(error);
					return self;
				};
				function getThen(obj) {
					var then = obj && obj.then;
					if (obj && (typeof obj === "object" || typeof obj === "function") && typeof then === "function") return function appyThen() {
						then.apply(obj, arguments);
					};
				}
				function safelyResolveThenable(self, thenable) {
					var called = false;
					function onError(value) {
						if (called) return;
						called = true;
						handlers.reject(self, value);
					}
					function onSuccess(value) {
						if (called) return;
						called = true;
						handlers.resolve(self, value);
					}
					function tryToUnwrap() {
						thenable(onSuccess, onError);
					}
					var result = tryCatch(tryToUnwrap);
					if (result.status === "error") onError(result.value);
				}
				function tryCatch(func, value) {
					var out = {};
					try {
						out.value = func(value);
						out.status = "success";
					} catch (e) {
						out.status = "error";
						out.value = e;
					}
					return out;
				}
				Promise.resolve = resolve;
				function resolve(value) {
					if (value instanceof this) return value;
					return handlers.resolve(new this(INTERNAL), value);
				}
				Promise.reject = reject;
				function reject(reason) {
					var promise = new this(INTERNAL);
					return handlers.reject(promise, reason);
				}
				Promise.all = all;
				function all(iterable) {
					var self = this;
					if (Object.prototype.toString.call(iterable) !== "[object Array]") return this.reject(/* @__PURE__ */ new TypeError("must be an array"));
					var len = iterable.length;
					var called = false;
					if (!len) return this.resolve([]);
					var values = new Array(len);
					var resolved = 0;
					var i = -1;
					var promise = new this(INTERNAL);
					while (++i < len) allResolver(iterable[i], i);
					return promise;
					function allResolver(value, i) {
						self.resolve(value).then(resolveFromAll, function(error) {
							if (!called) {
								called = true;
								handlers.reject(promise, error);
							}
						});
						function resolveFromAll(outValue) {
							values[i] = outValue;
							if (++resolved === len && !called) {
								called = true;
								handlers.resolve(promise, values);
							}
						}
					}
				}
				Promise.race = race;
				function race(iterable) {
					var self = this;
					if (Object.prototype.toString.call(iterable) !== "[object Array]") return this.reject(/* @__PURE__ */ new TypeError("must be an array"));
					var len = iterable.length;
					var called = false;
					if (!len) return this.resolve([]);
					var i = -1;
					var promise = new this(INTERNAL);
					while (++i < len) resolver(iterable[i]);
					return promise;
					function resolver(value) {
						self.resolve(value).then(function(response) {
							if (!called) {
								called = true;
								handlers.resolve(promise, response);
							}
						}, function(error) {
							if (!called) {
								called = true;
								handlers.reject(promise, error);
							}
						});
					}
				}
			}, { "1": 1 }],
			3: [function(_dereq_, module$3, exports$3) {
				(function(global) {
					"use strict";
					if (typeof global.Promise !== "function") global.Promise = _dereq_(2);
				}).call(this, typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {});
			}, { "2": 2 }],
			4: [function(_dereq_, module$4, exports$4) {
				"use strict";
				var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
					return typeof obj;
				} : function(obj) {
					return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
				};
				function _classCallCheck(instance, Constructor) {
					if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
				}
				function getIDB() {
					try {
						if (typeof indexedDB !== "undefined") return indexedDB;
						if (typeof webkitIndexedDB !== "undefined") return webkitIndexedDB;
						if (typeof mozIndexedDB !== "undefined") return mozIndexedDB;
						if (typeof OIndexedDB !== "undefined") return OIndexedDB;
						if (typeof msIndexedDB !== "undefined") return msIndexedDB;
					} catch (e) {
						return;
					}
				}
				var idb = getIDB();
				function isIndexedDBValid() {
					try {
						if (!idb || !idb.open) return false;
						var isSafari = typeof openDatabase !== "undefined" && /(Safari|iPhone|iPad|iPod)/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent) && !/BlackBerry/.test(navigator.platform);
						var hasFetch = typeof fetch === "function" && fetch.toString().indexOf("[native code") !== -1;
						return (!isSafari || hasFetch) && typeof indexedDB !== "undefined" && typeof IDBKeyRange !== "undefined";
					} catch (e) {
						return false;
					}
				}
				function createBlob(parts, properties) {
					parts = parts || [];
					properties = properties || {};
					try {
						return new Blob(parts, properties);
					} catch (e) {
						if (e.name !== "TypeError") throw e;
						var builder = new (typeof BlobBuilder !== "undefined" ? BlobBuilder : typeof MSBlobBuilder !== "undefined" ? MSBlobBuilder : typeof MozBlobBuilder !== "undefined" ? MozBlobBuilder : WebKitBlobBuilder)();
						for (var i = 0; i < parts.length; i += 1) builder.append(parts[i]);
						return builder.getBlob(properties.type);
					}
				}
				if (typeof Promise === "undefined") _dereq_(3);
				var Promise$1 = Promise;
				function executeCallback(promise, callback) {
					if (callback) promise.then(function(result) {
						callback(null, result);
					}, function(error) {
						callback(error);
					});
				}
				function executeTwoCallbacks(promise, callback, errorCallback) {
					if (typeof callback === "function") promise.then(callback);
					if (typeof errorCallback === "function") promise["catch"](errorCallback);
				}
				function normalizeKey(key) {
					if (typeof key !== "string") {
						console.warn(key + " used as a key, but it is not a string.");
						key = String(key);
					}
					return key;
				}
				function getCallback() {
					if (arguments.length && typeof arguments[arguments.length - 1] === "function") return arguments[arguments.length - 1];
				}
				var DETECT_BLOB_SUPPORT_STORE = "local-forage-detect-blob-support";
				var supportsBlobs = void 0;
				var dbContexts = {};
				var toString = Object.prototype.toString;
				var READ_ONLY = "readonly";
				var READ_WRITE = "readwrite";
				function _binStringToArrayBuffer(bin) {
					var length = bin.length;
					var buf = new ArrayBuffer(length);
					var arr = new Uint8Array(buf);
					for (var i = 0; i < length; i++) arr[i] = bin.charCodeAt(i);
					return buf;
				}
				function _checkBlobSupportWithoutCaching(idb) {
					return new Promise$1(function(resolve) {
						var txn = idb.transaction(DETECT_BLOB_SUPPORT_STORE, READ_WRITE);
						var blob = createBlob([""]);
						txn.objectStore(DETECT_BLOB_SUPPORT_STORE).put(blob, "key");
						txn.onabort = function(e) {
							e.preventDefault();
							e.stopPropagation();
							resolve(false);
						};
						txn.oncomplete = function() {
							var matchedChrome = navigator.userAgent.match(/Chrome\/(\d+)/);
							resolve(navigator.userAgent.match(/Edge\//) || !matchedChrome || parseInt(matchedChrome[1], 10) >= 43);
						};
					})["catch"](function() {
						return false;
					});
				}
				function _checkBlobSupport(idb) {
					if (typeof supportsBlobs === "boolean") return Promise$1.resolve(supportsBlobs);
					return _checkBlobSupportWithoutCaching(idb).then(function(value) {
						supportsBlobs = value;
						return supportsBlobs;
					});
				}
				function _deferReadiness(dbInfo) {
					var dbContext = dbContexts[dbInfo.name];
					var deferredOperation = {};
					deferredOperation.promise = new Promise$1(function(resolve, reject) {
						deferredOperation.resolve = resolve;
						deferredOperation.reject = reject;
					});
					dbContext.deferredOperations.push(deferredOperation);
					if (!dbContext.dbReady) dbContext.dbReady = deferredOperation.promise;
					else dbContext.dbReady = dbContext.dbReady.then(function() {
						return deferredOperation.promise;
					});
				}
				function _advanceReadiness(dbInfo) {
					var deferredOperation = dbContexts[dbInfo.name].deferredOperations.pop();
					if (deferredOperation) {
						deferredOperation.resolve();
						return deferredOperation.promise;
					}
				}
				function _rejectReadiness(dbInfo, err) {
					var deferredOperation = dbContexts[dbInfo.name].deferredOperations.pop();
					if (deferredOperation) {
						deferredOperation.reject(err);
						return deferredOperation.promise;
					}
				}
				function _getConnection(dbInfo, upgradeNeeded) {
					return new Promise$1(function(resolve, reject) {
						dbContexts[dbInfo.name] = dbContexts[dbInfo.name] || createDbContext();
						if (dbInfo.db) if (upgradeNeeded) {
							_deferReadiness(dbInfo);
							dbInfo.db.close();
						} else return resolve(dbInfo.db);
						var dbArgs = [dbInfo.name];
						if (upgradeNeeded) dbArgs.push(dbInfo.version);
						var openreq = idb.open.apply(idb, dbArgs);
						if (upgradeNeeded) openreq.onupgradeneeded = function(e) {
							var db = openreq.result;
							try {
								db.createObjectStore(dbInfo.storeName);
								if (e.oldVersion <= 1) db.createObjectStore(DETECT_BLOB_SUPPORT_STORE);
							} catch (ex) {
								if (ex.name === "ConstraintError") console.warn("The database \"" + dbInfo.name + "\" has been upgraded from version " + e.oldVersion + " to version " + e.newVersion + ", but the storage \"" + dbInfo.storeName + "\" already exists.");
								else throw ex;
							}
						};
						openreq.onerror = function(e) {
							e.preventDefault();
							reject(openreq.error);
						};
						openreq.onsuccess = function() {
							var db = openreq.result;
							db.onversionchange = function(e) {
								e.target.close();
							};
							resolve(db);
							_advanceReadiness(dbInfo);
						};
					});
				}
				function _getOriginalConnection(dbInfo) {
					return _getConnection(dbInfo, false);
				}
				function _getUpgradedConnection(dbInfo) {
					return _getConnection(dbInfo, true);
				}
				function _isUpgradeNeeded(dbInfo, defaultVersion) {
					if (!dbInfo.db) return true;
					var isNewStore = !dbInfo.db.objectStoreNames.contains(dbInfo.storeName);
					var isDowngrade = dbInfo.version < dbInfo.db.version;
					var isUpgrade = dbInfo.version > dbInfo.db.version;
					if (isDowngrade) {
						if (dbInfo.version !== defaultVersion) console.warn("The database \"" + dbInfo.name + "\" can't be downgraded from version " + dbInfo.db.version + " to version " + dbInfo.version + ".");
						dbInfo.version = dbInfo.db.version;
					}
					if (isUpgrade || isNewStore) {
						if (isNewStore) {
							var incVersion = dbInfo.db.version + 1;
							if (incVersion > dbInfo.version) dbInfo.version = incVersion;
						}
						return true;
					}
					return false;
				}
				function _encodeBlob(blob) {
					return new Promise$1(function(resolve, reject) {
						var reader = new FileReader();
						reader.onerror = reject;
						reader.onloadend = function(e) {
							resolve({
								__local_forage_encoded_blob: true,
								data: btoa(e.target.result || ""),
								type: blob.type
							});
						};
						reader.readAsBinaryString(blob);
					});
				}
				function _decodeBlob(encodedBlob) {
					return createBlob([_binStringToArrayBuffer(atob(encodedBlob.data))], { type: encodedBlob.type });
				}
				function _isEncodedBlob(value) {
					return value && value.__local_forage_encoded_blob;
				}
				function _fullyReady(callback) {
					var self = this;
					var promise = self._initReady().then(function() {
						var dbContext = dbContexts[self._dbInfo.name];
						if (dbContext && dbContext.dbReady) return dbContext.dbReady;
					});
					executeTwoCallbacks(promise, callback, callback);
					return promise;
				}
				function _tryReconnect(dbInfo) {
					_deferReadiness(dbInfo);
					var dbContext = dbContexts[dbInfo.name];
					var forages = dbContext.forages;
					for (var i = 0; i < forages.length; i++) {
						var forage = forages[i];
						if (forage._dbInfo.db) {
							forage._dbInfo.db.close();
							forage._dbInfo.db = null;
						}
					}
					dbInfo.db = null;
					return _getOriginalConnection(dbInfo).then(function(db) {
						dbInfo.db = db;
						if (_isUpgradeNeeded(dbInfo)) return _getUpgradedConnection(dbInfo);
						return db;
					}).then(function(db) {
						dbInfo.db = dbContext.db = db;
						for (var i = 0; i < forages.length; i++) forages[i]._dbInfo.db = db;
					})["catch"](function(err) {
						_rejectReadiness(dbInfo, err);
						throw err;
					});
				}
				function createTransaction(dbInfo, mode, callback, retries) {
					if (retries === void 0) retries = 1;
					try {
						callback(null, dbInfo.db.transaction(dbInfo.storeName, mode));
					} catch (err) {
						if (retries > 0 && (!dbInfo.db || err.name === "InvalidStateError" || err.name === "NotFoundError")) return Promise$1.resolve().then(function() {
							if (!dbInfo.db || err.name === "NotFoundError" && !dbInfo.db.objectStoreNames.contains(dbInfo.storeName) && dbInfo.version <= dbInfo.db.version) {
								if (dbInfo.db) dbInfo.version = dbInfo.db.version + 1;
								return _getUpgradedConnection(dbInfo);
							}
						}).then(function() {
							return _tryReconnect(dbInfo).then(function() {
								createTransaction(dbInfo, mode, callback, retries - 1);
							});
						})["catch"](callback);
						callback(err);
					}
				}
				function createDbContext() {
					return {
						forages: [],
						db: null,
						dbReady: null,
						deferredOperations: []
					};
				}
				function _initStorage(options) {
					var self = this;
					var dbInfo = { db: null };
					if (options) for (var i in options) dbInfo[i] = options[i];
					var dbContext = dbContexts[dbInfo.name];
					if (!dbContext) {
						dbContext = createDbContext();
						dbContexts[dbInfo.name] = dbContext;
					}
					dbContext.forages.push(self);
					if (!self._initReady) {
						self._initReady = self.ready;
						self.ready = _fullyReady;
					}
					var initPromises = [];
					function ignoreErrors() {
						return Promise$1.resolve();
					}
					for (var j = 0; j < dbContext.forages.length; j++) {
						var forage = dbContext.forages[j];
						if (forage !== self) initPromises.push(forage._initReady()["catch"](ignoreErrors));
					}
					var forages = dbContext.forages.slice(0);
					return Promise$1.all(initPromises).then(function() {
						dbInfo.db = dbContext.db;
						return _getOriginalConnection(dbInfo);
					}).then(function(db) {
						dbInfo.db = db;
						if (_isUpgradeNeeded(dbInfo, self._defaultConfig.version)) return _getUpgradedConnection(dbInfo);
						return db;
					}).then(function(db) {
						dbInfo.db = dbContext.db = db;
						self._dbInfo = dbInfo;
						for (var k = 0; k < forages.length; k++) {
							var forage = forages[k];
							if (forage !== self) {
								forage._dbInfo.db = dbInfo.db;
								forage._dbInfo.version = dbInfo.version;
							}
						}
					});
				}
				function getItem(key, callback) {
					var self = this;
					key = normalizeKey(key);
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							createTransaction(self._dbInfo, READ_ONLY, function(err, transaction) {
								if (err) return reject(err);
								try {
									var req = transaction.objectStore(self._dbInfo.storeName).get(key);
									req.onsuccess = function() {
										var value = req.result;
										if (value === void 0) value = null;
										if (_isEncodedBlob(value)) value = _decodeBlob(value);
										resolve(value);
									};
									req.onerror = function() {
										reject(req.error);
									};
								} catch (e) {
									reject(e);
								}
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function iterate(iterator, callback) {
					var self = this;
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							createTransaction(self._dbInfo, READ_ONLY, function(err, transaction) {
								if (err) return reject(err);
								try {
									var req = transaction.objectStore(self._dbInfo.storeName).openCursor();
									var iterationNumber = 1;
									req.onsuccess = function() {
										var cursor = req.result;
										if (cursor) {
											var value = cursor.value;
											if (_isEncodedBlob(value)) value = _decodeBlob(value);
											var result = iterator(value, cursor.key, iterationNumber++);
											if (result !== void 0) resolve(result);
											else cursor["continue"]();
										} else resolve();
									};
									req.onerror = function() {
										reject(req.error);
									};
								} catch (e) {
									reject(e);
								}
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function setItem(key, value, callback) {
					var self = this;
					key = normalizeKey(key);
					var promise = new Promise$1(function(resolve, reject) {
						var dbInfo;
						self.ready().then(function() {
							dbInfo = self._dbInfo;
							if (toString.call(value) === "[object Blob]") return _checkBlobSupport(dbInfo.db).then(function(blobSupport) {
								if (blobSupport) return value;
								return _encodeBlob(value);
							});
							return value;
						}).then(function(value) {
							createTransaction(self._dbInfo, READ_WRITE, function(err, transaction) {
								if (err) return reject(err);
								try {
									var store = transaction.objectStore(self._dbInfo.storeName);
									if (value === null) value = void 0;
									var req = store.put(value, key);
									transaction.oncomplete = function() {
										if (value === void 0) value = null;
										resolve(value);
									};
									transaction.onabort = transaction.onerror = function() {
										reject(req.error ? req.error : req.transaction.error);
									};
								} catch (e) {
									reject(e);
								}
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function removeItem(key, callback) {
					var self = this;
					key = normalizeKey(key);
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							createTransaction(self._dbInfo, READ_WRITE, function(err, transaction) {
								if (err) return reject(err);
								try {
									var req = transaction.objectStore(self._dbInfo.storeName)["delete"](key);
									transaction.oncomplete = function() {
										resolve();
									};
									transaction.onerror = function() {
										reject(req.error);
									};
									transaction.onabort = function() {
										reject(req.error ? req.error : req.transaction.error);
									};
								} catch (e) {
									reject(e);
								}
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function clear(callback) {
					var self = this;
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							createTransaction(self._dbInfo, READ_WRITE, function(err, transaction) {
								if (err) return reject(err);
								try {
									var req = transaction.objectStore(self._dbInfo.storeName).clear();
									transaction.oncomplete = function() {
										resolve();
									};
									transaction.onabort = transaction.onerror = function() {
										reject(req.error ? req.error : req.transaction.error);
									};
								} catch (e) {
									reject(e);
								}
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function length(callback) {
					var self = this;
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							createTransaction(self._dbInfo, READ_ONLY, function(err, transaction) {
								if (err) return reject(err);
								try {
									var req = transaction.objectStore(self._dbInfo.storeName).count();
									req.onsuccess = function() {
										resolve(req.result);
									};
									req.onerror = function() {
										reject(req.error);
									};
								} catch (e) {
									reject(e);
								}
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function key(n, callback) {
					var self = this;
					var promise = new Promise$1(function(resolve, reject) {
						if (n < 0) {
							resolve(null);
							return;
						}
						self.ready().then(function() {
							createTransaction(self._dbInfo, READ_ONLY, function(err, transaction) {
								if (err) return reject(err);
								try {
									var store = transaction.objectStore(self._dbInfo.storeName);
									var advanced = false;
									var req = store.openKeyCursor();
									req.onsuccess = function() {
										var cursor = req.result;
										if (!cursor) {
											resolve(null);
											return;
										}
										if (n === 0) resolve(cursor.key);
										else if (!advanced) {
											advanced = true;
											cursor.advance(n);
										} else resolve(cursor.key);
									};
									req.onerror = function() {
										reject(req.error);
									};
								} catch (e) {
									reject(e);
								}
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function keys(callback) {
					var self = this;
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							createTransaction(self._dbInfo, READ_ONLY, function(err, transaction) {
								if (err) return reject(err);
								try {
									var req = transaction.objectStore(self._dbInfo.storeName).openKeyCursor();
									var keys = [];
									req.onsuccess = function() {
										var cursor = req.result;
										if (!cursor) {
											resolve(keys);
											return;
										}
										keys.push(cursor.key);
										cursor["continue"]();
									};
									req.onerror = function() {
										reject(req.error);
									};
								} catch (e) {
									reject(e);
								}
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function dropInstance(options, callback) {
					callback = getCallback.apply(this, arguments);
					var currentConfig = this.config();
					options = typeof options !== "function" && options || {};
					if (!options.name) {
						options.name = options.name || currentConfig.name;
						options.storeName = options.storeName || currentConfig.storeName;
					}
					var self = this;
					var promise;
					if (!options.name) promise = Promise$1.reject("Invalid arguments");
					else {
						var dbPromise = options.name === currentConfig.name && self._dbInfo.db ? Promise$1.resolve(self._dbInfo.db) : _getOriginalConnection(options).then(function(db) {
							var dbContext = dbContexts[options.name];
							var forages = dbContext.forages;
							dbContext.db = db;
							for (var i = 0; i < forages.length; i++) forages[i]._dbInfo.db = db;
							return db;
						});
						if (!options.storeName) promise = dbPromise.then(function(db) {
							_deferReadiness(options);
							var dbContext = dbContexts[options.name];
							var forages = dbContext.forages;
							db.close();
							for (var i = 0; i < forages.length; i++) {
								var forage = forages[i];
								forage._dbInfo.db = null;
							}
							return new Promise$1(function(resolve, reject) {
								var req = idb.deleteDatabase(options.name);
								req.onerror = function() {
									var db = req.result;
									if (db) db.close();
									reject(req.error);
								};
								req.onblocked = function() {
									console.warn("dropInstance blocked for database \"" + options.name + "\" until all open connections are closed");
								};
								req.onsuccess = function() {
									var db = req.result;
									if (db) db.close();
									resolve(db);
								};
							}).then(function(db) {
								dbContext.db = db;
								for (var i = 0; i < forages.length; i++) {
									var _forage = forages[i];
									_advanceReadiness(_forage._dbInfo);
								}
							})["catch"](function(err) {
								(_rejectReadiness(options, err) || Promise$1.resolve())["catch"](function() {});
								throw err;
							});
						});
						else promise = dbPromise.then(function(db) {
							if (!db.objectStoreNames.contains(options.storeName)) return;
							var newVersion = db.version + 1;
							_deferReadiness(options);
							var dbContext = dbContexts[options.name];
							var forages = dbContext.forages;
							db.close();
							for (var i = 0; i < forages.length; i++) {
								var forage = forages[i];
								forage._dbInfo.db = null;
								forage._dbInfo.version = newVersion;
							}
							return new Promise$1(function(resolve, reject) {
								var req = idb.open(options.name, newVersion);
								req.onerror = function(err) {
									req.result.close();
									reject(err);
								};
								req.onupgradeneeded = function() {
									req.result.deleteObjectStore(options.storeName);
								};
								req.onsuccess = function() {
									var db = req.result;
									db.close();
									resolve(db);
								};
							}).then(function(db) {
								dbContext.db = db;
								for (var j = 0; j < forages.length; j++) {
									var _forage2 = forages[j];
									_forage2._dbInfo.db = db;
									_advanceReadiness(_forage2._dbInfo);
								}
							})["catch"](function(err) {
								(_rejectReadiness(options, err) || Promise$1.resolve())["catch"](function() {});
								throw err;
							});
						});
					}
					executeCallback(promise, callback);
					return promise;
				}
				var asyncStorage = {
					_driver: "asyncStorage",
					_initStorage,
					_support: isIndexedDBValid(),
					iterate,
					getItem,
					setItem,
					removeItem,
					clear,
					length,
					key,
					keys,
					dropInstance
				};
				function isWebSQLValid() {
					return typeof openDatabase === "function";
				}
				var BASE_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
				var BLOB_TYPE_PREFIX = "~~local_forage_type~";
				var BLOB_TYPE_PREFIX_REGEX = /^~~local_forage_type~([^~]+)~/;
				var SERIALIZED_MARKER = "__lfsc__:";
				var SERIALIZED_MARKER_LENGTH = SERIALIZED_MARKER.length;
				var TYPE_ARRAYBUFFER = "arbf";
				var TYPE_BLOB = "blob";
				var TYPE_INT8ARRAY = "si08";
				var TYPE_UINT8ARRAY = "ui08";
				var TYPE_UINT8CLAMPEDARRAY = "uic8";
				var TYPE_INT16ARRAY = "si16";
				var TYPE_INT32ARRAY = "si32";
				var TYPE_UINT16ARRAY = "ur16";
				var TYPE_UINT32ARRAY = "ui32";
				var TYPE_FLOAT32ARRAY = "fl32";
				var TYPE_FLOAT64ARRAY = "fl64";
				var TYPE_SERIALIZED_MARKER_LENGTH = SERIALIZED_MARKER_LENGTH + TYPE_ARRAYBUFFER.length;
				var toString$1 = Object.prototype.toString;
				function stringToBuffer(serializedString) {
					var bufferLength = serializedString.length * .75;
					var len = serializedString.length;
					var i;
					var p = 0;
					var encoded1, encoded2, encoded3, encoded4;
					if (serializedString[serializedString.length - 1] === "=") {
						bufferLength--;
						if (serializedString[serializedString.length - 2] === "=") bufferLength--;
					}
					var buffer = new ArrayBuffer(bufferLength);
					var bytes = new Uint8Array(buffer);
					for (i = 0; i < len; i += 4) {
						encoded1 = BASE_CHARS.indexOf(serializedString[i]);
						encoded2 = BASE_CHARS.indexOf(serializedString[i + 1]);
						encoded3 = BASE_CHARS.indexOf(serializedString[i + 2]);
						encoded4 = BASE_CHARS.indexOf(serializedString[i + 3]);
						bytes[p++] = encoded1 << 2 | encoded2 >> 4;
						bytes[p++] = (encoded2 & 15) << 4 | encoded3 >> 2;
						bytes[p++] = (encoded3 & 3) << 6 | encoded4 & 63;
					}
					return buffer;
				}
				function bufferToString(buffer) {
					var bytes = new Uint8Array(buffer);
					var base64String = "";
					var i;
					for (i = 0; i < bytes.length; i += 3) {
						base64String += BASE_CHARS[bytes[i] >> 2];
						base64String += BASE_CHARS[(bytes[i] & 3) << 4 | bytes[i + 1] >> 4];
						base64String += BASE_CHARS[(bytes[i + 1] & 15) << 2 | bytes[i + 2] >> 6];
						base64String += BASE_CHARS[bytes[i + 2] & 63];
					}
					if (bytes.length % 3 === 2) base64String = base64String.substring(0, base64String.length - 1) + "=";
					else if (bytes.length % 3 === 1) base64String = base64String.substring(0, base64String.length - 2) + "==";
					return base64String;
				}
				function serialize(value, callback) {
					var valueType = "";
					if (value) valueType = toString$1.call(value);
					if (value && (valueType === "[object ArrayBuffer]" || value.buffer && toString$1.call(value.buffer) === "[object ArrayBuffer]")) {
						var buffer;
						var marker = SERIALIZED_MARKER;
						if (value instanceof ArrayBuffer) {
							buffer = value;
							marker += TYPE_ARRAYBUFFER;
						} else {
							buffer = value.buffer;
							if (valueType === "[object Int8Array]") marker += TYPE_INT8ARRAY;
							else if (valueType === "[object Uint8Array]") marker += TYPE_UINT8ARRAY;
							else if (valueType === "[object Uint8ClampedArray]") marker += TYPE_UINT8CLAMPEDARRAY;
							else if (valueType === "[object Int16Array]") marker += TYPE_INT16ARRAY;
							else if (valueType === "[object Uint16Array]") marker += TYPE_UINT16ARRAY;
							else if (valueType === "[object Int32Array]") marker += TYPE_INT32ARRAY;
							else if (valueType === "[object Uint32Array]") marker += TYPE_UINT32ARRAY;
							else if (valueType === "[object Float32Array]") marker += TYPE_FLOAT32ARRAY;
							else if (valueType === "[object Float64Array]") marker += TYPE_FLOAT64ARRAY;
							else callback(/* @__PURE__ */ new Error("Failed to get type for BinaryArray"));
						}
						callback(marker + bufferToString(buffer));
					} else if (valueType === "[object Blob]") {
						var fileReader = new FileReader();
						fileReader.onload = function() {
							var str = BLOB_TYPE_PREFIX + value.type + "~" + bufferToString(this.result);
							callback(SERIALIZED_MARKER + TYPE_BLOB + str);
						};
						fileReader.readAsArrayBuffer(value);
					} else try {
						callback(JSON.stringify(value));
					} catch (e) {
						console.error("Couldn't convert value into a JSON string: ", value);
						callback(null, e);
					}
				}
				function deserialize(value) {
					if (value.substring(0, SERIALIZED_MARKER_LENGTH) !== SERIALIZED_MARKER) return JSON.parse(value);
					var serializedString = value.substring(TYPE_SERIALIZED_MARKER_LENGTH);
					var type = value.substring(SERIALIZED_MARKER_LENGTH, TYPE_SERIALIZED_MARKER_LENGTH);
					var blobType;
					if (type === TYPE_BLOB && BLOB_TYPE_PREFIX_REGEX.test(serializedString)) {
						var matcher = serializedString.match(BLOB_TYPE_PREFIX_REGEX);
						blobType = matcher[1];
						serializedString = serializedString.substring(matcher[0].length);
					}
					var buffer = stringToBuffer(serializedString);
					switch (type) {
						case TYPE_ARRAYBUFFER: return buffer;
						case TYPE_BLOB: return createBlob([buffer], { type: blobType });
						case TYPE_INT8ARRAY: return new Int8Array(buffer);
						case TYPE_UINT8ARRAY: return new Uint8Array(buffer);
						case TYPE_UINT8CLAMPEDARRAY: return new Uint8ClampedArray(buffer);
						case TYPE_INT16ARRAY: return new Int16Array(buffer);
						case TYPE_UINT16ARRAY: return new Uint16Array(buffer);
						case TYPE_INT32ARRAY: return new Int32Array(buffer);
						case TYPE_UINT32ARRAY: return new Uint32Array(buffer);
						case TYPE_FLOAT32ARRAY: return new Float32Array(buffer);
						case TYPE_FLOAT64ARRAY: return new Float64Array(buffer);
						default: throw new Error("Unkown type: " + type);
					}
				}
				var localforageSerializer = {
					serialize,
					deserialize,
					stringToBuffer,
					bufferToString
				};
				function createDbTable(t, dbInfo, callback, errorCallback) {
					t.executeSql("CREATE TABLE IF NOT EXISTS " + dbInfo.storeName + " (id INTEGER PRIMARY KEY, key unique, value)", [], callback, errorCallback);
				}
				function _initStorage$1(options) {
					var self = this;
					var dbInfo = { db: null };
					if (options) for (var i in options) dbInfo[i] = typeof options[i] !== "string" ? options[i].toString() : options[i];
					var dbInfoPromise = new Promise$1(function(resolve, reject) {
						try {
							dbInfo.db = openDatabase(dbInfo.name, String(dbInfo.version), dbInfo.description, dbInfo.size);
						} catch (e) {
							return reject(e);
						}
						dbInfo.db.transaction(function(t) {
							createDbTable(t, dbInfo, function() {
								self._dbInfo = dbInfo;
								resolve();
							}, function(t, error) {
								reject(error);
							});
						}, reject);
					});
					dbInfo.serializer = localforageSerializer;
					return dbInfoPromise;
				}
				function tryExecuteSql(t, dbInfo, sqlStatement, args, callback, errorCallback) {
					t.executeSql(sqlStatement, args, callback, function(t, error) {
						if (error.code === error.SYNTAX_ERR) t.executeSql("SELECT name FROM sqlite_master WHERE type='table' AND name = ?", [dbInfo.storeName], function(t, results) {
							if (!results.rows.length) createDbTable(t, dbInfo, function() {
								t.executeSql(sqlStatement, args, callback, errorCallback);
							}, errorCallback);
							else errorCallback(t, error);
						}, errorCallback);
						else errorCallback(t, error);
					}, errorCallback);
				}
				function getItem$1(key, callback) {
					var self = this;
					key = normalizeKey(key);
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							var dbInfo = self._dbInfo;
							dbInfo.db.transaction(function(t) {
								tryExecuteSql(t, dbInfo, "SELECT * FROM " + dbInfo.storeName + " WHERE key = ? LIMIT 1", [key], function(t, results) {
									var result = results.rows.length ? results.rows.item(0).value : null;
									if (result) result = dbInfo.serializer.deserialize(result);
									resolve(result);
								}, function(t, error) {
									reject(error);
								});
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function iterate$1(iterator, callback) {
					var self = this;
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							var dbInfo = self._dbInfo;
							dbInfo.db.transaction(function(t) {
								tryExecuteSql(t, dbInfo, "SELECT * FROM " + dbInfo.storeName, [], function(t, results) {
									var rows = results.rows;
									var length = rows.length;
									for (var i = 0; i < length; i++) {
										var item = rows.item(i);
										var result = item.value;
										if (result) result = dbInfo.serializer.deserialize(result);
										result = iterator(result, item.key, i + 1);
										if (result !== void 0) {
											resolve(result);
											return;
										}
									}
									resolve();
								}, function(t, error) {
									reject(error);
								});
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function _setItem(key, value, callback, retriesLeft) {
					var self = this;
					key = normalizeKey(key);
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							if (value === void 0) value = null;
							var originalValue = value;
							var dbInfo = self._dbInfo;
							dbInfo.serializer.serialize(value, function(value, error) {
								if (error) reject(error);
								else dbInfo.db.transaction(function(t) {
									tryExecuteSql(t, dbInfo, "INSERT OR REPLACE INTO " + dbInfo.storeName + " (key, value) VALUES (?, ?)", [key, value], function() {
										resolve(originalValue);
									}, function(t, error) {
										reject(error);
									});
								}, function(sqlError) {
									if (sqlError.code === sqlError.QUOTA_ERR) {
										if (retriesLeft > 0) {
											resolve(_setItem.apply(self, [
												key,
												originalValue,
												callback,
												retriesLeft - 1
											]));
											return;
										}
										reject(sqlError);
									}
								});
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function setItem$1(key, value, callback) {
					return _setItem.apply(this, [
						key,
						value,
						callback,
						1
					]);
				}
				function removeItem$1(key, callback) {
					var self = this;
					key = normalizeKey(key);
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							var dbInfo = self._dbInfo;
							dbInfo.db.transaction(function(t) {
								tryExecuteSql(t, dbInfo, "DELETE FROM " + dbInfo.storeName + " WHERE key = ?", [key], function() {
									resolve();
								}, function(t, error) {
									reject(error);
								});
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function clear$1(callback) {
					var self = this;
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							var dbInfo = self._dbInfo;
							dbInfo.db.transaction(function(t) {
								tryExecuteSql(t, dbInfo, "DELETE FROM " + dbInfo.storeName, [], function() {
									resolve();
								}, function(t, error) {
									reject(error);
								});
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function length$1(callback) {
					var self = this;
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							var dbInfo = self._dbInfo;
							dbInfo.db.transaction(function(t) {
								tryExecuteSql(t, dbInfo, "SELECT COUNT(key) as c FROM " + dbInfo.storeName, [], function(t, results) {
									var result = results.rows.item(0).c;
									resolve(result);
								}, function(t, error) {
									reject(error);
								});
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function key$1(n, callback) {
					var self = this;
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							var dbInfo = self._dbInfo;
							dbInfo.db.transaction(function(t) {
								tryExecuteSql(t, dbInfo, "SELECT key FROM " + dbInfo.storeName + " WHERE id = ? LIMIT 1", [n + 1], function(t, results) {
									resolve(results.rows.length ? results.rows.item(0).key : null);
								}, function(t, error) {
									reject(error);
								});
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function keys$1(callback) {
					var self = this;
					var promise = new Promise$1(function(resolve, reject) {
						self.ready().then(function() {
							var dbInfo = self._dbInfo;
							dbInfo.db.transaction(function(t) {
								tryExecuteSql(t, dbInfo, "SELECT key FROM " + dbInfo.storeName, [], function(t, results) {
									var keys = [];
									for (var i = 0; i < results.rows.length; i++) keys.push(results.rows.item(i).key);
									resolve(keys);
								}, function(t, error) {
									reject(error);
								});
							});
						})["catch"](reject);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function getAllStoreNames(db) {
					return new Promise$1(function(resolve, reject) {
						db.transaction(function(t) {
							t.executeSql("SELECT name FROM sqlite_master WHERE type='table' AND name <> '__WebKitDatabaseInfoTable__'", [], function(t, results) {
								var storeNames = [];
								for (var i = 0; i < results.rows.length; i++) storeNames.push(results.rows.item(i).name);
								resolve({
									db,
									storeNames
								});
							}, function(t, error) {
								reject(error);
							});
						}, function(sqlError) {
							reject(sqlError);
						});
					});
				}
				function dropInstance$1(options, callback) {
					callback = getCallback.apply(this, arguments);
					var currentConfig = this.config();
					options = typeof options !== "function" && options || {};
					if (!options.name) {
						options.name = options.name || currentConfig.name;
						options.storeName = options.storeName || currentConfig.storeName;
					}
					var self = this;
					var promise;
					if (!options.name) promise = Promise$1.reject("Invalid arguments");
					else promise = new Promise$1(function(resolve) {
						var db;
						if (options.name === currentConfig.name) db = self._dbInfo.db;
						else db = openDatabase(options.name, "", "", 0);
						if (!options.storeName) resolve(getAllStoreNames(db));
						else resolve({
							db,
							storeNames: [options.storeName]
						});
					}).then(function(operationInfo) {
						return new Promise$1(function(resolve, reject) {
							operationInfo.db.transaction(function(t) {
								function dropTable(storeName) {
									return new Promise$1(function(resolve, reject) {
										t.executeSql("DROP TABLE IF EXISTS " + storeName, [], function() {
											resolve();
										}, function(t, error) {
											reject(error);
										});
									});
								}
								var operations = [];
								for (var i = 0, len = operationInfo.storeNames.length; i < len; i++) operations.push(dropTable(operationInfo.storeNames[i]));
								Promise$1.all(operations).then(function() {
									resolve();
								})["catch"](function(e) {
									reject(e);
								});
							}, function(sqlError) {
								reject(sqlError);
							});
						});
					});
					executeCallback(promise, callback);
					return promise;
				}
				var webSQLStorage = {
					_driver: "webSQLStorage",
					_initStorage: _initStorage$1,
					_support: isWebSQLValid(),
					iterate: iterate$1,
					getItem: getItem$1,
					setItem: setItem$1,
					removeItem: removeItem$1,
					clear: clear$1,
					length: length$1,
					key: key$1,
					keys: keys$1,
					dropInstance: dropInstance$1
				};
				function isLocalStorageValid() {
					try {
						return typeof localStorage !== "undefined" && "setItem" in localStorage && !!localStorage.setItem;
					} catch (e) {
						return false;
					}
				}
				function _getKeyPrefix(options, defaultConfig) {
					var keyPrefix = options.name + "/";
					if (options.storeName !== defaultConfig.storeName) keyPrefix += options.storeName + "/";
					return keyPrefix;
				}
				function checkIfLocalStorageThrows() {
					var localStorageTestKey = "_localforage_support_test";
					try {
						localStorage.setItem(localStorageTestKey, true);
						localStorage.removeItem(localStorageTestKey);
						return false;
					} catch (e) {
						return true;
					}
				}
				function _isLocalStorageUsable() {
					return !checkIfLocalStorageThrows() || localStorage.length > 0;
				}
				function _initStorage$2(options) {
					var self = this;
					var dbInfo = {};
					if (options) for (var i in options) dbInfo[i] = options[i];
					dbInfo.keyPrefix = _getKeyPrefix(options, self._defaultConfig);
					if (!_isLocalStorageUsable()) return Promise$1.reject();
					self._dbInfo = dbInfo;
					dbInfo.serializer = localforageSerializer;
					return Promise$1.resolve();
				}
				function clear$2(callback) {
					var self = this;
					var promise = self.ready().then(function() {
						var keyPrefix = self._dbInfo.keyPrefix;
						for (var i = localStorage.length - 1; i >= 0; i--) {
							var key = localStorage.key(i);
							if (key.indexOf(keyPrefix) === 0) localStorage.removeItem(key);
						}
					});
					executeCallback(promise, callback);
					return promise;
				}
				function getItem$2(key, callback) {
					var self = this;
					key = normalizeKey(key);
					var promise = self.ready().then(function() {
						var dbInfo = self._dbInfo;
						var result = localStorage.getItem(dbInfo.keyPrefix + key);
						if (result) result = dbInfo.serializer.deserialize(result);
						return result;
					});
					executeCallback(promise, callback);
					return promise;
				}
				function iterate$2(iterator, callback) {
					var self = this;
					var promise = self.ready().then(function() {
						var dbInfo = self._dbInfo;
						var keyPrefix = dbInfo.keyPrefix;
						var keyPrefixLength = keyPrefix.length;
						var length = localStorage.length;
						var iterationNumber = 1;
						for (var i = 0; i < length; i++) {
							var key = localStorage.key(i);
							if (key.indexOf(keyPrefix) !== 0) continue;
							var value = localStorage.getItem(key);
							if (value) value = dbInfo.serializer.deserialize(value);
							value = iterator(value, key.substring(keyPrefixLength), iterationNumber++);
							if (value !== void 0) return value;
						}
					});
					executeCallback(promise, callback);
					return promise;
				}
				function key$2(n, callback) {
					var self = this;
					var promise = self.ready().then(function() {
						var dbInfo = self._dbInfo;
						var result;
						try {
							result = localStorage.key(n);
						} catch (error) {
							result = null;
						}
						if (result) result = result.substring(dbInfo.keyPrefix.length);
						return result;
					});
					executeCallback(promise, callback);
					return promise;
				}
				function keys$2(callback) {
					var self = this;
					var promise = self.ready().then(function() {
						var dbInfo = self._dbInfo;
						var length = localStorage.length;
						var keys = [];
						for (var i = 0; i < length; i++) {
							var itemKey = localStorage.key(i);
							if (itemKey.indexOf(dbInfo.keyPrefix) === 0) keys.push(itemKey.substring(dbInfo.keyPrefix.length));
						}
						return keys;
					});
					executeCallback(promise, callback);
					return promise;
				}
				function length$2(callback) {
					var promise = this.keys().then(function(keys) {
						return keys.length;
					});
					executeCallback(promise, callback);
					return promise;
				}
				function removeItem$2(key, callback) {
					var self = this;
					key = normalizeKey(key);
					var promise = self.ready().then(function() {
						var dbInfo = self._dbInfo;
						localStorage.removeItem(dbInfo.keyPrefix + key);
					});
					executeCallback(promise, callback);
					return promise;
				}
				function setItem$2(key, value, callback) {
					var self = this;
					key = normalizeKey(key);
					var promise = self.ready().then(function() {
						if (value === void 0) value = null;
						var originalValue = value;
						return new Promise$1(function(resolve, reject) {
							var dbInfo = self._dbInfo;
							dbInfo.serializer.serialize(value, function(value, error) {
								if (error) reject(error);
								else try {
									localStorage.setItem(dbInfo.keyPrefix + key, value);
									resolve(originalValue);
								} catch (e) {
									if (e.name === "QuotaExceededError" || e.name === "NS_ERROR_DOM_QUOTA_REACHED") reject(e);
									reject(e);
								}
							});
						});
					});
					executeCallback(promise, callback);
					return promise;
				}
				function dropInstance$2(options, callback) {
					callback = getCallback.apply(this, arguments);
					options = typeof options !== "function" && options || {};
					if (!options.name) {
						var currentConfig = this.config();
						options.name = options.name || currentConfig.name;
						options.storeName = options.storeName || currentConfig.storeName;
					}
					var self = this;
					var promise;
					if (!options.name) promise = Promise$1.reject("Invalid arguments");
					else promise = new Promise$1(function(resolve) {
						if (!options.storeName) resolve(options.name + "/");
						else resolve(_getKeyPrefix(options, self._defaultConfig));
					}).then(function(keyPrefix) {
						for (var i = localStorage.length - 1; i >= 0; i--) {
							var key = localStorage.key(i);
							if (key.indexOf(keyPrefix) === 0) localStorage.removeItem(key);
						}
					});
					executeCallback(promise, callback);
					return promise;
				}
				var localStorageWrapper = {
					_driver: "localStorageWrapper",
					_initStorage: _initStorage$2,
					_support: isLocalStorageValid(),
					iterate: iterate$2,
					getItem: getItem$2,
					setItem: setItem$2,
					removeItem: removeItem$2,
					clear: clear$2,
					length: length$2,
					key: key$2,
					keys: keys$2,
					dropInstance: dropInstance$2
				};
				var sameValue = function sameValue(x, y) {
					return x === y || typeof x === "number" && typeof y === "number" && isNaN(x) && isNaN(y);
				};
				var includes = function includes(array, searchElement) {
					var len = array.length;
					var i = 0;
					while (i < len) {
						if (sameValue(array[i], searchElement)) return true;
						i++;
					}
					return false;
				};
				var isArray = Array.isArray || function(arg) {
					return Object.prototype.toString.call(arg) === "[object Array]";
				};
				var DefinedDrivers = {};
				var DriverSupport = {};
				var DefaultDrivers = {
					INDEXEDDB: asyncStorage,
					WEBSQL: webSQLStorage,
					LOCALSTORAGE: localStorageWrapper
				};
				var DefaultDriverOrder = [
					DefaultDrivers.INDEXEDDB._driver,
					DefaultDrivers.WEBSQL._driver,
					DefaultDrivers.LOCALSTORAGE._driver
				];
				var OptionalDriverMethods = ["dropInstance"];
				var LibraryMethods = [
					"clear",
					"getItem",
					"iterate",
					"key",
					"keys",
					"length",
					"removeItem",
					"setItem"
				].concat(OptionalDriverMethods);
				var DefaultConfig = {
					description: "",
					driver: DefaultDriverOrder.slice(),
					name: "localforage",
					size: 4980736,
					storeName: "keyvaluepairs",
					version: 1
				};
				function callWhenReady(localForageInstance, libraryMethod) {
					localForageInstance[libraryMethod] = function() {
						var _args = arguments;
						return localForageInstance.ready().then(function() {
							return localForageInstance[libraryMethod].apply(localForageInstance, _args);
						});
					};
				}
				function extend() {
					for (var i = 1; i < arguments.length; i++) {
						var arg = arguments[i];
						if (arg) {
							for (var _key in arg) if (arg.hasOwnProperty(_key)) if (isArray(arg[_key])) arguments[0][_key] = arg[_key].slice();
							else arguments[0][_key] = arg[_key];
						}
					}
					return arguments[0];
				}
				module$4.exports = new (function() {
					function LocalForage(options) {
						_classCallCheck(this, LocalForage);
						for (var driverTypeKey in DefaultDrivers) if (DefaultDrivers.hasOwnProperty(driverTypeKey)) {
							var driver = DefaultDrivers[driverTypeKey];
							var driverName = driver._driver;
							this[driverTypeKey] = driverName;
							if (!DefinedDrivers[driverName]) this.defineDriver(driver);
						}
						this._defaultConfig = extend({}, DefaultConfig);
						this._config = extend({}, this._defaultConfig, options);
						this._driverSet = null;
						this._initDriver = null;
						this._ready = false;
						this._dbInfo = null;
						this._wrapLibraryMethodsWithReady();
						this.setDriver(this._config.driver)["catch"](function() {});
					}
					LocalForage.prototype.config = function config(options) {
						if ((typeof options === "undefined" ? "undefined" : _typeof(options)) === "object") {
							if (this._ready) return /* @__PURE__ */ new Error("Can't call config() after localforage has been used.");
							for (var i in options) {
								if (i === "storeName") options[i] = options[i].replace(/\W/g, "_");
								if (i === "version" && typeof options[i] !== "number") return /* @__PURE__ */ new Error("Database version must be a number.");
								this._config[i] = options[i];
							}
							if ("driver" in options && options.driver) return this.setDriver(this._config.driver);
							return true;
						} else if (typeof options === "string") return this._config[options];
						else return this._config;
					};
					LocalForage.prototype.defineDriver = function defineDriver(driverObject, callback, errorCallback) {
						var promise = new Promise$1(function(resolve, reject) {
							try {
								var driverName = driverObject._driver;
								var complianceError = /* @__PURE__ */ new Error("Custom driver not compliant; see https://mozilla.github.io/localForage/#definedriver");
								if (!driverObject._driver) {
									reject(complianceError);
									return;
								}
								var driverMethods = LibraryMethods.concat("_initStorage");
								for (var i = 0, len = driverMethods.length; i < len; i++) {
									var driverMethodName = driverMethods[i];
									if ((!includes(OptionalDriverMethods, driverMethodName) || driverObject[driverMethodName]) && typeof driverObject[driverMethodName] !== "function") {
										reject(complianceError);
										return;
									}
								}
								(function configureMissingMethods() {
									var methodNotImplementedFactory = function methodNotImplementedFactory(methodName) {
										return function() {
											var error = /* @__PURE__ */ new Error("Method " + methodName + " is not implemented by the current driver");
											var promise = Promise$1.reject(error);
											executeCallback(promise, arguments[arguments.length - 1]);
											return promise;
										};
									};
									for (var _i = 0, _len = OptionalDriverMethods.length; _i < _len; _i++) {
										var optionalDriverMethod = OptionalDriverMethods[_i];
										if (!driverObject[optionalDriverMethod]) driverObject[optionalDriverMethod] = methodNotImplementedFactory(optionalDriverMethod);
									}
								})();
								var setDriverSupport = function setDriverSupport(support) {
									if (DefinedDrivers[driverName]) console.info("Redefining LocalForage driver: " + driverName);
									DefinedDrivers[driverName] = driverObject;
									DriverSupport[driverName] = support;
									resolve();
								};
								if ("_support" in driverObject) if (driverObject._support && typeof driverObject._support === "function") driverObject._support().then(setDriverSupport, reject);
								else setDriverSupport(!!driverObject._support);
								else setDriverSupport(true);
							} catch (e) {
								reject(e);
							}
						});
						executeTwoCallbacks(promise, callback, errorCallback);
						return promise;
					};
					LocalForage.prototype.driver = function driver() {
						return this._driver || null;
					};
					LocalForage.prototype.getDriver = function getDriver(driverName, callback, errorCallback) {
						var getDriverPromise = DefinedDrivers[driverName] ? Promise$1.resolve(DefinedDrivers[driverName]) : Promise$1.reject(/* @__PURE__ */ new Error("Driver not found."));
						executeTwoCallbacks(getDriverPromise, callback, errorCallback);
						return getDriverPromise;
					};
					LocalForage.prototype.getSerializer = function getSerializer(callback) {
						var serializerPromise = Promise$1.resolve(localforageSerializer);
						executeTwoCallbacks(serializerPromise, callback);
						return serializerPromise;
					};
					LocalForage.prototype.ready = function ready(callback) {
						var self = this;
						var promise = self._driverSet.then(function() {
							if (self._ready === null) self._ready = self._initDriver();
							return self._ready;
						});
						executeTwoCallbacks(promise, callback, callback);
						return promise;
					};
					LocalForage.prototype.setDriver = function setDriver(drivers, callback, errorCallback) {
						var self = this;
						if (!isArray(drivers)) drivers = [drivers];
						var supportedDrivers = this._getSupportedDrivers(drivers);
						function setDriverToConfig() {
							self._config.driver = self.driver();
						}
						function extendSelfWithDriver(driver) {
							self._extend(driver);
							setDriverToConfig();
							self._ready = self._initStorage(self._config);
							return self._ready;
						}
						function initDriver(supportedDrivers) {
							return function() {
								var currentDriverIndex = 0;
								function driverPromiseLoop() {
									while (currentDriverIndex < supportedDrivers.length) {
										var driverName = supportedDrivers[currentDriverIndex];
										currentDriverIndex++;
										self._dbInfo = null;
										self._ready = null;
										return self.getDriver(driverName).then(extendSelfWithDriver)["catch"](driverPromiseLoop);
									}
									setDriverToConfig();
									var error = /* @__PURE__ */ new Error("No available storage method found.");
									self._driverSet = Promise$1.reject(error);
									return self._driverSet;
								}
								return driverPromiseLoop();
							};
						}
						var oldDriverSetDone = this._driverSet !== null ? this._driverSet["catch"](function() {
							return Promise$1.resolve();
						}) : Promise$1.resolve();
						this._driverSet = oldDriverSetDone.then(function() {
							var driverName = supportedDrivers[0];
							self._dbInfo = null;
							self._ready = null;
							return self.getDriver(driverName).then(function(driver) {
								self._driver = driver._driver;
								setDriverToConfig();
								self._wrapLibraryMethodsWithReady();
								self._initDriver = initDriver(supportedDrivers);
							});
						})["catch"](function() {
							setDriverToConfig();
							var error = /* @__PURE__ */ new Error("No available storage method found.");
							self._driverSet = Promise$1.reject(error);
							return self._driverSet;
						});
						executeTwoCallbacks(this._driverSet, callback, errorCallback);
						return this._driverSet;
					};
					LocalForage.prototype.supports = function supports(driverName) {
						return !!DriverSupport[driverName];
					};
					LocalForage.prototype._extend = function _extend(libraryMethodsAndProperties) {
						extend(this, libraryMethodsAndProperties);
					};
					LocalForage.prototype._getSupportedDrivers = function _getSupportedDrivers(drivers) {
						var supportedDrivers = [];
						for (var i = 0, len = drivers.length; i < len; i++) {
							var driverName = drivers[i];
							if (this.supports(driverName)) supportedDrivers.push(driverName);
						}
						return supportedDrivers;
					};
					LocalForage.prototype._wrapLibraryMethodsWithReady = function _wrapLibraryMethodsWithReady() {
						for (var i = 0, len = LibraryMethods.length; i < len; i++) callWhenReady(this, LibraryMethods[i]);
					};
					LocalForage.prototype.createInstance = function createInstance(options) {
						return new LocalForage(options);
					};
					return LocalForage;
				}())();
			}, { "3": 3 }]
		}, {}, [4])(4);
	});
}));
//#endregion
export default require_localforage();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYWxmb3JhZ2UuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vbG9jYWxmb3JhZ2UvZGlzdC9sb2NhbGZvcmFnZS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAgICBsb2NhbEZvcmFnZSAtLSBPZmZsaW5lIFN0b3JhZ2UsIEltcHJvdmVkXG4gICAgVmVyc2lvbiAxLjEwLjBcbiAgICBodHRwczovL2xvY2FsZm9yYWdlLmdpdGh1Yi5pby9sb2NhbEZvcmFnZVxuICAgIChjKSAyMDEzLTIwMTcgTW96aWxsYSwgQXBhY2hlIExpY2Vuc2UgMi4wXG4qL1xuKGZ1bmN0aW9uKGYpe2lmKHR5cGVvZiBleHBvcnRzPT09XCJvYmplY3RcIiYmdHlwZW9mIG1vZHVsZSE9PVwidW5kZWZpbmVkXCIpe21vZHVsZS5leHBvcnRzPWYoKX1lbHNlIGlmKHR5cGVvZiBkZWZpbmU9PT1cImZ1bmN0aW9uXCImJmRlZmluZS5hbWQpe2RlZmluZShbXSxmKX1lbHNle3ZhciBnO2lmKHR5cGVvZiB3aW5kb3chPT1cInVuZGVmaW5lZFwiKXtnPXdpbmRvd31lbHNlIGlmKHR5cGVvZiBnbG9iYWwhPT1cInVuZGVmaW5lZFwiKXtnPWdsb2JhbH1lbHNlIGlmKHR5cGVvZiBzZWxmIT09XCJ1bmRlZmluZWRcIil7Zz1zZWxmfWVsc2V7Zz10aGlzfWcubG9jYWxmb3JhZ2UgPSBmKCl9fSkoZnVuY3Rpb24oKXt2YXIgZGVmaW5lLG1vZHVsZSxleHBvcnRzO3JldHVybiAoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgKGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIiwgZil9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSh7MTpbZnVuY3Rpb24oX2RlcmVxXyxtb2R1bGUsZXhwb3J0cyl7XG4oZnVuY3Rpb24gKGdsb2JhbCl7XG4ndXNlIHN0cmljdCc7XG52YXIgTXV0YXRpb24gPSBnbG9iYWwuTXV0YXRpb25PYnNlcnZlciB8fCBnbG9iYWwuV2ViS2l0TXV0YXRpb25PYnNlcnZlcjtcblxudmFyIHNjaGVkdWxlRHJhaW47XG5cbntcbiAgaWYgKE11dGF0aW9uKSB7XG4gICAgdmFyIGNhbGxlZCA9IDA7XG4gICAgdmFyIG9ic2VydmVyID0gbmV3IE11dGF0aW9uKG5leHRUaWNrKTtcbiAgICB2YXIgZWxlbWVudCA9IGdsb2JhbC5kb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSgnJyk7XG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50LCB7XG4gICAgICBjaGFyYWN0ZXJEYXRhOiB0cnVlXG4gICAgfSk7XG4gICAgc2NoZWR1bGVEcmFpbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIGVsZW1lbnQuZGF0YSA9IChjYWxsZWQgPSArK2NhbGxlZCAlIDIpO1xuICAgIH07XG4gIH0gZWxzZSBpZiAoIWdsb2JhbC5zZXRJbW1lZGlhdGUgJiYgdHlwZW9mIGdsb2JhbC5NZXNzYWdlQ2hhbm5lbCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICB2YXIgY2hhbm5lbCA9IG5ldyBnbG9iYWwuTWVzc2FnZUNoYW5uZWwoKTtcbiAgICBjaGFubmVsLnBvcnQxLm9ubWVzc2FnZSA9IG5leHRUaWNrO1xuICAgIHNjaGVkdWxlRHJhaW4gPSBmdW5jdGlvbiAoKSB7XG4gICAgICBjaGFubmVsLnBvcnQyLnBvc3RNZXNzYWdlKDApO1xuICAgIH07XG4gIH0gZWxzZSBpZiAoJ2RvY3VtZW50JyBpbiBnbG9iYWwgJiYgJ29ucmVhZHlzdGF0ZWNoYW5nZScgaW4gZ2xvYmFsLmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpKSB7XG4gICAgc2NoZWR1bGVEcmFpbiA9IGZ1bmN0aW9uICgpIHtcblxuICAgICAgLy8gQ3JlYXRlIGEgPHNjcmlwdD4gZWxlbWVudDsgaXRzIHJlYWR5c3RhdGVjaGFuZ2UgZXZlbnQgd2lsbCBiZSBmaXJlZCBhc3luY2hyb25vdXNseSBvbmNlIGl0IGlzIGluc2VydGVkXG4gICAgICAvLyBpbnRvIHRoZSBkb2N1bWVudC4gRG8gc28sIHRodXMgcXVldWluZyB1cCB0aGUgdGFzay4gUmVtZW1iZXIgdG8gY2xlYW4gdXAgb25jZSBpdCdzIGJlZW4gY2FsbGVkLlxuICAgICAgdmFyIHNjcmlwdEVsID0gZ2xvYmFsLmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICAgICAgc2NyaXB0RWwub25yZWFkeXN0YXRlY2hhbmdlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBuZXh0VGljaygpO1xuXG4gICAgICAgIHNjcmlwdEVsLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IG51bGw7XG4gICAgICAgIHNjcmlwdEVsLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0RWwpO1xuICAgICAgICBzY3JpcHRFbCA9IG51bGw7XG4gICAgICB9O1xuICAgICAgZ2xvYmFsLmRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5hcHBlbmRDaGlsZChzY3JpcHRFbCk7XG4gICAgfTtcbiAgfSBlbHNlIHtcbiAgICBzY2hlZHVsZURyYWluID0gZnVuY3Rpb24gKCkge1xuICAgICAgc2V0VGltZW91dChuZXh0VGljaywgMCk7XG4gICAgfTtcbiAgfVxufVxuXG52YXIgZHJhaW5pbmc7XG52YXIgcXVldWUgPSBbXTtcbi8vbmFtZWQgbmV4dFRpY2sgZm9yIGxlc3MgY29uZnVzaW5nIHN0YWNrIHRyYWNlc1xuZnVuY3Rpb24gbmV4dFRpY2soKSB7XG4gIGRyYWluaW5nID0gdHJ1ZTtcbiAgdmFyIGksIG9sZFF1ZXVlO1xuICB2YXIgbGVuID0gcXVldWUubGVuZ3RoO1xuICB3aGlsZSAobGVuKSB7XG4gICAgb2xkUXVldWUgPSBxdWV1ZTtcbiAgICBxdWV1ZSA9IFtdO1xuICAgIGkgPSAtMTtcbiAgICB3aGlsZSAoKytpIDwgbGVuKSB7XG4gICAgICBvbGRRdWV1ZVtpXSgpO1xuICAgIH1cbiAgICBsZW4gPSBxdWV1ZS5sZW5ndGg7XG4gIH1cbiAgZHJhaW5pbmcgPSBmYWxzZTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBpbW1lZGlhdGU7XG5mdW5jdGlvbiBpbW1lZGlhdGUodGFzaykge1xuICBpZiAocXVldWUucHVzaCh0YXNrKSA9PT0gMSAmJiAhZHJhaW5pbmcpIHtcbiAgICBzY2hlZHVsZURyYWluKCk7XG4gIH1cbn1cblxufSkuY2FsbCh0aGlzLHR5cGVvZiBnbG9iYWwgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWwgOiB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDoge30pXG59LHt9XSwyOltmdW5jdGlvbihfZGVyZXFfLG1vZHVsZSxleHBvcnRzKXtcbid1c2Ugc3RyaWN0JztcbnZhciBpbW1lZGlhdGUgPSBfZGVyZXFfKDEpO1xuXG4vKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xuZnVuY3Rpb24gSU5URVJOQUwoKSB7fVxuXG52YXIgaGFuZGxlcnMgPSB7fTtcblxudmFyIFJFSkVDVEVEID0gWydSRUpFQ1RFRCddO1xudmFyIEZVTEZJTExFRCA9IFsnRlVMRklMTEVEJ107XG52YXIgUEVORElORyA9IFsnUEVORElORyddO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFByb21pc2U7XG5cbmZ1bmN0aW9uIFByb21pc2UocmVzb2x2ZXIpIHtcbiAgaWYgKHR5cGVvZiByZXNvbHZlciAhPT0gJ2Z1bmN0aW9uJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ3Jlc29sdmVyIG11c3QgYmUgYSBmdW5jdGlvbicpO1xuICB9XG4gIHRoaXMuc3RhdGUgPSBQRU5ESU5HO1xuICB0aGlzLnF1ZXVlID0gW107XG4gIHRoaXMub3V0Y29tZSA9IHZvaWQgMDtcbiAgaWYgKHJlc29sdmVyICE9PSBJTlRFUk5BTCkge1xuICAgIHNhZmVseVJlc29sdmVUaGVuYWJsZSh0aGlzLCByZXNvbHZlcik7XG4gIH1cbn1cblxuUHJvbWlzZS5wcm90b3R5cGVbXCJjYXRjaFwiXSA9IGZ1bmN0aW9uIChvblJlamVjdGVkKSB7XG4gIHJldHVybiB0aGlzLnRoZW4obnVsbCwgb25SZWplY3RlZCk7XG59O1xuUHJvbWlzZS5wcm90b3R5cGUudGhlbiA9IGZ1bmN0aW9uIChvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkge1xuICBpZiAodHlwZW9mIG9uRnVsZmlsbGVkICE9PSAnZnVuY3Rpb24nICYmIHRoaXMuc3RhdGUgPT09IEZVTEZJTExFRCB8fFxuICAgIHR5cGVvZiBvblJlamVjdGVkICE9PSAnZnVuY3Rpb24nICYmIHRoaXMuc3RhdGUgPT09IFJFSkVDVEVEKSB7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgdmFyIHByb21pc2UgPSBuZXcgdGhpcy5jb25zdHJ1Y3RvcihJTlRFUk5BTCk7XG4gIGlmICh0aGlzLnN0YXRlICE9PSBQRU5ESU5HKSB7XG4gICAgdmFyIHJlc29sdmVyID0gdGhpcy5zdGF0ZSA9PT0gRlVMRklMTEVEID8gb25GdWxmaWxsZWQgOiBvblJlamVjdGVkO1xuICAgIHVud3JhcChwcm9taXNlLCByZXNvbHZlciwgdGhpcy5vdXRjb21lKTtcbiAgfSBlbHNlIHtcbiAgICB0aGlzLnF1ZXVlLnB1c2gobmV3IFF1ZXVlSXRlbShwcm9taXNlLCBvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkpO1xuICB9XG5cbiAgcmV0dXJuIHByb21pc2U7XG59O1xuZnVuY3Rpb24gUXVldWVJdGVtKHByb21pc2UsIG9uRnVsZmlsbGVkLCBvblJlamVjdGVkKSB7XG4gIHRoaXMucHJvbWlzZSA9IHByb21pc2U7XG4gIGlmICh0eXBlb2Ygb25GdWxmaWxsZWQgPT09ICdmdW5jdGlvbicpIHtcbiAgICB0aGlzLm9uRnVsZmlsbGVkID0gb25GdWxmaWxsZWQ7XG4gICAgdGhpcy5jYWxsRnVsZmlsbGVkID0gdGhpcy5vdGhlckNhbGxGdWxmaWxsZWQ7XG4gIH1cbiAgaWYgKHR5cGVvZiBvblJlamVjdGVkID09PSAnZnVuY3Rpb24nKSB7XG4gICAgdGhpcy5vblJlamVjdGVkID0gb25SZWplY3RlZDtcbiAgICB0aGlzLmNhbGxSZWplY3RlZCA9IHRoaXMub3RoZXJDYWxsUmVqZWN0ZWQ7XG4gIH1cbn1cblF1ZXVlSXRlbS5wcm90b3R5cGUuY2FsbEZ1bGZpbGxlZCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICBoYW5kbGVycy5yZXNvbHZlKHRoaXMucHJvbWlzZSwgdmFsdWUpO1xufTtcblF1ZXVlSXRlbS5wcm90b3R5cGUub3RoZXJDYWxsRnVsZmlsbGVkID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIHVud3JhcCh0aGlzLnByb21pc2UsIHRoaXMub25GdWxmaWxsZWQsIHZhbHVlKTtcbn07XG5RdWV1ZUl0ZW0ucHJvdG90eXBlLmNhbGxSZWplY3RlZCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICBoYW5kbGVycy5yZWplY3QodGhpcy5wcm9taXNlLCB2YWx1ZSk7XG59O1xuUXVldWVJdGVtLnByb3RvdHlwZS5vdGhlckNhbGxSZWplY3RlZCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICB1bndyYXAodGhpcy5wcm9taXNlLCB0aGlzLm9uUmVqZWN0ZWQsIHZhbHVlKTtcbn07XG5cbmZ1bmN0aW9uIHVud3JhcChwcm9taXNlLCBmdW5jLCB2YWx1ZSkge1xuICBpbW1lZGlhdGUoZnVuY3Rpb24gKCkge1xuICAgIHZhciByZXR1cm5WYWx1ZTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuVmFsdWUgPSBmdW5jKHZhbHVlKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICByZXR1cm4gaGFuZGxlcnMucmVqZWN0KHByb21pc2UsIGUpO1xuICAgIH1cbiAgICBpZiAocmV0dXJuVmFsdWUgPT09IHByb21pc2UpIHtcbiAgICAgIGhhbmRsZXJzLnJlamVjdChwcm9taXNlLCBuZXcgVHlwZUVycm9yKCdDYW5ub3QgcmVzb2x2ZSBwcm9taXNlIHdpdGggaXRzZWxmJykpO1xuICAgIH0gZWxzZSB7XG4gICAgICBoYW5kbGVycy5yZXNvbHZlKHByb21pc2UsIHJldHVyblZhbHVlKTtcbiAgICB9XG4gIH0pO1xufVxuXG5oYW5kbGVycy5yZXNvbHZlID0gZnVuY3Rpb24gKHNlbGYsIHZhbHVlKSB7XG4gIHZhciByZXN1bHQgPSB0cnlDYXRjaChnZXRUaGVuLCB2YWx1ZSk7XG4gIGlmIChyZXN1bHQuc3RhdHVzID09PSAnZXJyb3InKSB7XG4gICAgcmV0dXJuIGhhbmRsZXJzLnJlamVjdChzZWxmLCByZXN1bHQudmFsdWUpO1xuICB9XG4gIHZhciB0aGVuYWJsZSA9IHJlc3VsdC52YWx1ZTtcblxuICBpZiAodGhlbmFibGUpIHtcbiAgICBzYWZlbHlSZXNvbHZlVGhlbmFibGUoc2VsZiwgdGhlbmFibGUpO1xuICB9IGVsc2Uge1xuICAgIHNlbGYuc3RhdGUgPSBGVUxGSUxMRUQ7XG4gICAgc2VsZi5vdXRjb21lID0gdmFsdWU7XG4gICAgdmFyIGkgPSAtMTtcbiAgICB2YXIgbGVuID0gc2VsZi5xdWV1ZS5sZW5ndGg7XG4gICAgd2hpbGUgKCsraSA8IGxlbikge1xuICAgICAgc2VsZi5xdWV1ZVtpXS5jYWxsRnVsZmlsbGVkKHZhbHVlKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHNlbGY7XG59O1xuaGFuZGxlcnMucmVqZWN0ID0gZnVuY3Rpb24gKHNlbGYsIGVycm9yKSB7XG4gIHNlbGYuc3RhdGUgPSBSRUpFQ1RFRDtcbiAgc2VsZi5vdXRjb21lID0gZXJyb3I7XG4gIHZhciBpID0gLTE7XG4gIHZhciBsZW4gPSBzZWxmLnF1ZXVlLmxlbmd0aDtcbiAgd2hpbGUgKCsraSA8IGxlbikge1xuICAgIHNlbGYucXVldWVbaV0uY2FsbFJlamVjdGVkKGVycm9yKTtcbiAgfVxuICByZXR1cm4gc2VsZjtcbn07XG5cbmZ1bmN0aW9uIGdldFRoZW4ob2JqKSB7XG4gIC8vIE1ha2Ugc3VyZSB3ZSBvbmx5IGFjY2VzcyB0aGUgYWNjZXNzb3Igb25jZSBhcyByZXF1aXJlZCBieSB0aGUgc3BlY1xuICB2YXIgdGhlbiA9IG9iaiAmJiBvYmoudGhlbjtcbiAgaWYgKG9iaiAmJiAodHlwZW9mIG9iaiA9PT0gJ29iamVjdCcgfHwgdHlwZW9mIG9iaiA9PT0gJ2Z1bmN0aW9uJykgJiYgdHlwZW9mIHRoZW4gPT09ICdmdW5jdGlvbicpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gYXBweVRoZW4oKSB7XG4gICAgICB0aGVuLmFwcGx5KG9iaiwgYXJndW1lbnRzKTtcbiAgICB9O1xuICB9XG59XG5cbmZ1bmN0aW9uIHNhZmVseVJlc29sdmVUaGVuYWJsZShzZWxmLCB0aGVuYWJsZSkge1xuICAvLyBFaXRoZXIgZnVsZmlsbCwgcmVqZWN0IG9yIHJlamVjdCB3aXRoIGVycm9yXG4gIHZhciBjYWxsZWQgPSBmYWxzZTtcbiAgZnVuY3Rpb24gb25FcnJvcih2YWx1ZSkge1xuICAgIGlmIChjYWxsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY2FsbGVkID0gdHJ1ZTtcbiAgICBoYW5kbGVycy5yZWplY3Qoc2VsZiwgdmFsdWUpO1xuICB9XG5cbiAgZnVuY3Rpb24gb25TdWNjZXNzKHZhbHVlKSB7XG4gICAgaWYgKGNhbGxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjYWxsZWQgPSB0cnVlO1xuICAgIGhhbmRsZXJzLnJlc29sdmUoc2VsZiwgdmFsdWUpO1xuICB9XG5cbiAgZnVuY3Rpb24gdHJ5VG9VbndyYXAoKSB7XG4gICAgdGhlbmFibGUob25TdWNjZXNzLCBvbkVycm9yKTtcbiAgfVxuXG4gIHZhciByZXN1bHQgPSB0cnlDYXRjaCh0cnlUb1Vud3JhcCk7XG4gIGlmIChyZXN1bHQuc3RhdHVzID09PSAnZXJyb3InKSB7XG4gICAgb25FcnJvcihyZXN1bHQudmFsdWUpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHRyeUNhdGNoKGZ1bmMsIHZhbHVlKSB7XG4gIHZhciBvdXQgPSB7fTtcbiAgdHJ5IHtcbiAgICBvdXQudmFsdWUgPSBmdW5jKHZhbHVlKTtcbiAgICBvdXQuc3RhdHVzID0gJ3N1Y2Nlc3MnO1xuICB9IGNhdGNoIChlKSB7XG4gICAgb3V0LnN0YXR1cyA9ICdlcnJvcic7XG4gICAgb3V0LnZhbHVlID0gZTtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5Qcm9taXNlLnJlc29sdmUgPSByZXNvbHZlO1xuZnVuY3Rpb24gcmVzb2x2ZSh2YWx1ZSkge1xuICBpZiAodmFsdWUgaW5zdGFuY2VvZiB0aGlzKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIHJldHVybiBoYW5kbGVycy5yZXNvbHZlKG5ldyB0aGlzKElOVEVSTkFMKSwgdmFsdWUpO1xufVxuXG5Qcm9taXNlLnJlamVjdCA9IHJlamVjdDtcbmZ1bmN0aW9uIHJlamVjdChyZWFzb24pIHtcbiAgdmFyIHByb21pc2UgPSBuZXcgdGhpcyhJTlRFUk5BTCk7XG4gIHJldHVybiBoYW5kbGVycy5yZWplY3QocHJvbWlzZSwgcmVhc29uKTtcbn1cblxuUHJvbWlzZS5hbGwgPSBhbGw7XG5mdW5jdGlvbiBhbGwoaXRlcmFibGUpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBpZiAoT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGl0ZXJhYmxlKSAhPT0gJ1tvYmplY3QgQXJyYXldJykge1xuICAgIHJldHVybiB0aGlzLnJlamVjdChuZXcgVHlwZUVycm9yKCdtdXN0IGJlIGFuIGFycmF5JykpO1xuICB9XG5cbiAgdmFyIGxlbiA9IGl0ZXJhYmxlLmxlbmd0aDtcbiAgdmFyIGNhbGxlZCA9IGZhbHNlO1xuICBpZiAoIWxlbikge1xuICAgIHJldHVybiB0aGlzLnJlc29sdmUoW10pO1xuICB9XG5cbiAgdmFyIHZhbHVlcyA9IG5ldyBBcnJheShsZW4pO1xuICB2YXIgcmVzb2x2ZWQgPSAwO1xuICB2YXIgaSA9IC0xO1xuICB2YXIgcHJvbWlzZSA9IG5ldyB0aGlzKElOVEVSTkFMKTtcblxuICB3aGlsZSAoKytpIDwgbGVuKSB7XG4gICAgYWxsUmVzb2x2ZXIoaXRlcmFibGVbaV0sIGkpO1xuICB9XG4gIHJldHVybiBwcm9taXNlO1xuICBmdW5jdGlvbiBhbGxSZXNvbHZlcih2YWx1ZSwgaSkge1xuICAgIHNlbGYucmVzb2x2ZSh2YWx1ZSkudGhlbihyZXNvbHZlRnJvbUFsbCwgZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgICBpZiAoIWNhbGxlZCkge1xuICAgICAgICBjYWxsZWQgPSB0cnVlO1xuICAgICAgICBoYW5kbGVycy5yZWplY3QocHJvbWlzZSwgZXJyb3IpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGZ1bmN0aW9uIHJlc29sdmVGcm9tQWxsKG91dFZhbHVlKSB7XG4gICAgICB2YWx1ZXNbaV0gPSBvdXRWYWx1ZTtcbiAgICAgIGlmICgrK3Jlc29sdmVkID09PSBsZW4gJiYgIWNhbGxlZCkge1xuICAgICAgICBjYWxsZWQgPSB0cnVlO1xuICAgICAgICBoYW5kbGVycy5yZXNvbHZlKHByb21pc2UsIHZhbHVlcyk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cblByb21pc2UucmFjZSA9IHJhY2U7XG5mdW5jdGlvbiByYWNlKGl0ZXJhYmxlKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgaWYgKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChpdGVyYWJsZSkgIT09ICdbb2JqZWN0IEFycmF5XScpIHtcbiAgICByZXR1cm4gdGhpcy5yZWplY3QobmV3IFR5cGVFcnJvcignbXVzdCBiZSBhbiBhcnJheScpKTtcbiAgfVxuXG4gIHZhciBsZW4gPSBpdGVyYWJsZS5sZW5ndGg7XG4gIHZhciBjYWxsZWQgPSBmYWxzZTtcbiAgaWYgKCFsZW4pIHtcbiAgICByZXR1cm4gdGhpcy5yZXNvbHZlKFtdKTtcbiAgfVxuXG4gIHZhciBpID0gLTE7XG4gIHZhciBwcm9taXNlID0gbmV3IHRoaXMoSU5URVJOQUwpO1xuXG4gIHdoaWxlICgrK2kgPCBsZW4pIHtcbiAgICByZXNvbHZlcihpdGVyYWJsZVtpXSk7XG4gIH1cbiAgcmV0dXJuIHByb21pc2U7XG4gIGZ1bmN0aW9uIHJlc29sdmVyKHZhbHVlKSB7XG4gICAgc2VsZi5yZXNvbHZlKHZhbHVlKS50aGVuKGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgaWYgKCFjYWxsZWQpIHtcbiAgICAgICAgY2FsbGVkID0gdHJ1ZTtcbiAgICAgICAgaGFuZGxlcnMucmVzb2x2ZShwcm9taXNlLCByZXNwb25zZSk7XG4gICAgICB9XG4gICAgfSwgZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgICBpZiAoIWNhbGxlZCkge1xuICAgICAgICBjYWxsZWQgPSB0cnVlO1xuICAgICAgICBoYW5kbGVycy5yZWplY3QocHJvbWlzZSwgZXJyb3IpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59XG5cbn0se1wiMVwiOjF9XSwzOltmdW5jdGlvbihfZGVyZXFfLG1vZHVsZSxleHBvcnRzKXtcbihmdW5jdGlvbiAoZ2xvYmFsKXtcbid1c2Ugc3RyaWN0JztcbmlmICh0eXBlb2YgZ2xvYmFsLlByb21pc2UgIT09ICdmdW5jdGlvbicpIHtcbiAgZ2xvYmFsLlByb21pc2UgPSBfZGVyZXFfKDIpO1xufVxuXG59KS5jYWxsKHRoaXMsdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB7fSlcbn0se1wiMlwiOjJ9XSw0OltmdW5jdGlvbihfZGVyZXFfLG1vZHVsZSxleHBvcnRzKXtcbid1c2Ugc3RyaWN0JztcblxudmFyIF90eXBlb2YgPSB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mIFN5bWJvbC5pdGVyYXRvciA9PT0gXCJzeW1ib2xcIiA/IGZ1bmN0aW9uIChvYmopIHsgcmV0dXJuIHR5cGVvZiBvYmo7IH0gOiBmdW5jdGlvbiAob2JqKSB7IHJldHVybiBvYmogJiYgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9iai5jb25zdHJ1Y3RvciA9PT0gU3ltYm9sICYmIG9iaiAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2Ygb2JqOyB9O1xuXG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soaW5zdGFuY2UsIENvbnN0cnVjdG9yKSB7IGlmICghKGluc3RhbmNlIGluc3RhbmNlb2YgQ29uc3RydWN0b3IpKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb25cIik7IH0gfVxuXG5mdW5jdGlvbiBnZXRJREIoKSB7XG4gICAgLyogZ2xvYmFsIGluZGV4ZWREQix3ZWJraXRJbmRleGVkREIsbW96SW5kZXhlZERCLE9JbmRleGVkREIsbXNJbmRleGVkREIgKi9cbiAgICB0cnkge1xuICAgICAgICBpZiAodHlwZW9mIGluZGV4ZWREQiAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgIHJldHVybiBpbmRleGVkREI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiB3ZWJraXRJbmRleGVkREIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICByZXR1cm4gd2Via2l0SW5kZXhlZERCO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgbW96SW5kZXhlZERCICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgcmV0dXJuIG1vekluZGV4ZWREQjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIE9JbmRleGVkREIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICByZXR1cm4gT0luZGV4ZWREQjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIG1zSW5kZXhlZERCICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgcmV0dXJuIG1zSW5kZXhlZERCO1xuICAgICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxufVxuXG52YXIgaWRiID0gZ2V0SURCKCk7XG5cbmZ1bmN0aW9uIGlzSW5kZXhlZERCVmFsaWQoKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgLy8gSW5pdGlhbGl6ZSBJbmRleGVkREI7IGZhbGwgYmFjayB0byB2ZW5kb3ItcHJlZml4ZWQgdmVyc2lvbnNcbiAgICAgICAgLy8gaWYgbmVlZGVkLlxuICAgICAgICBpZiAoIWlkYiB8fCAhaWRiLm9wZW4pIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBXZSBtaW1pYyBQb3VjaERCIGhlcmU7XG4gICAgICAgIC8vXG4gICAgICAgIC8vIFdlIHRlc3QgZm9yIG9wZW5EYXRhYmFzZSBiZWNhdXNlIElFIE1vYmlsZSBpZGVudGlmaWVzIGl0c2VsZlxuICAgICAgICAvLyBhcyBTYWZhcmkuIE9oIHRoZSBsdWx6Li4uXG4gICAgICAgIHZhciBpc1NhZmFyaSA9IHR5cGVvZiBvcGVuRGF0YWJhc2UgIT09ICd1bmRlZmluZWQnICYmIC8oU2FmYXJpfGlQaG9uZXxpUGFkfGlQb2QpLy50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpICYmICEvQ2hyb21lLy50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpICYmICEvQmxhY2tCZXJyeS8udGVzdChuYXZpZ2F0b3IucGxhdGZvcm0pO1xuXG4gICAgICAgIHZhciBoYXNGZXRjaCA9IHR5cGVvZiBmZXRjaCA9PT0gJ2Z1bmN0aW9uJyAmJiBmZXRjaC50b1N0cmluZygpLmluZGV4T2YoJ1tuYXRpdmUgY29kZScpICE9PSAtMTtcblxuICAgICAgICAvLyBTYWZhcmkgPDEwLjEgZG9lcyBub3QgbWVldCBvdXIgcmVxdWlyZW1lbnRzIGZvciBJREIgc3VwcG9ydFxuICAgICAgICAvLyAoc2VlOiBodHRwczovL2dpdGh1Yi5jb20vcG91Y2hkYi9wb3VjaGRiL2lzc3Vlcy81NTcyKS5cbiAgICAgICAgLy8gU2FmYXJpIDEwLjEgc2hpcHBlZCB3aXRoIGZldGNoLCB3ZSBjYW4gdXNlIHRoYXQgdG8gZGV0ZWN0IGl0LlxuICAgICAgICAvLyBOb3RlOiB0aGlzIGNyZWF0ZXMgaXNzdWVzIHdpdGggYHdpbmRvdy5mZXRjaGAgcG9seWZpbGxzIGFuZFxuICAgICAgICAvLyBvdmVycmlkZXM7IHNlZTpcbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2xvY2FsRm9yYWdlL2xvY2FsRm9yYWdlL2lzc3Vlcy84NTZcbiAgICAgICAgcmV0dXJuICghaXNTYWZhcmkgfHwgaGFzRmV0Y2gpICYmIHR5cGVvZiBpbmRleGVkREIgIT09ICd1bmRlZmluZWQnICYmXG4gICAgICAgIC8vIHNvbWUgb3V0ZGF0ZWQgaW1wbGVtZW50YXRpb25zIG9mIElEQiB0aGF0IGFwcGVhciBvbiBTYW1zdW5nXG4gICAgICAgIC8vIGFuZCBIVEMgQW5kcm9pZCBkZXZpY2VzIDw0LjQgYXJlIG1pc3NpbmcgSURCS2V5UmFuZ2VcbiAgICAgICAgLy8gU2VlOiBodHRwczovL2dpdGh1Yi5jb20vbW96aWxsYS9sb2NhbEZvcmFnZS9pc3N1ZXMvMTI4XG4gICAgICAgIC8vIFNlZTogaHR0cHM6Ly9naXRodWIuY29tL21vemlsbGEvbG9jYWxGb3JhZ2UvaXNzdWVzLzI3MlxuICAgICAgICB0eXBlb2YgSURCS2V5UmFuZ2UgIT09ICd1bmRlZmluZWQnO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbn1cblxuLy8gQWJzdHJhY3RzIGNvbnN0cnVjdGluZyBhIEJsb2Igb2JqZWN0LCBzbyBpdCBhbHNvIHdvcmtzIGluIG9sZGVyXG4vLyBicm93c2VycyB0aGF0IGRvbid0IHN1cHBvcnQgdGhlIG5hdGl2ZSBCbG9iIGNvbnN0cnVjdG9yLiAoaS5lLlxuLy8gb2xkIFF0V2ViS2l0IHZlcnNpb25zLCBhdCBsZWFzdCkuXG4vLyBBYnN0cmFjdHMgY29uc3RydWN0aW5nIGEgQmxvYiBvYmplY3QsIHNvIGl0IGFsc28gd29ya3MgaW4gb2xkZXJcbi8vIGJyb3dzZXJzIHRoYXQgZG9uJ3Qgc3VwcG9ydCB0aGUgbmF0aXZlIEJsb2IgY29uc3RydWN0b3IuIChpLmUuXG4vLyBvbGQgUXRXZWJLaXQgdmVyc2lvbnMsIGF0IGxlYXN0KS5cbmZ1bmN0aW9uIGNyZWF0ZUJsb2IocGFydHMsIHByb3BlcnRpZXMpIHtcbiAgICAvKiBnbG9iYWwgQmxvYkJ1aWxkZXIsTVNCbG9iQnVpbGRlcixNb3pCbG9iQnVpbGRlcixXZWJLaXRCbG9iQnVpbGRlciAqL1xuICAgIHBhcnRzID0gcGFydHMgfHwgW107XG4gICAgcHJvcGVydGllcyA9IHByb3BlcnRpZXMgfHwge307XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIG5ldyBCbG9iKHBhcnRzLCBwcm9wZXJ0aWVzKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChlLm5hbWUgIT09ICdUeXBlRXJyb3InKSB7XG4gICAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICB9XG4gICAgICAgIHZhciBCdWlsZGVyID0gdHlwZW9mIEJsb2JCdWlsZGVyICE9PSAndW5kZWZpbmVkJyA/IEJsb2JCdWlsZGVyIDogdHlwZW9mIE1TQmxvYkJ1aWxkZXIgIT09ICd1bmRlZmluZWQnID8gTVNCbG9iQnVpbGRlciA6IHR5cGVvZiBNb3pCbG9iQnVpbGRlciAhPT0gJ3VuZGVmaW5lZCcgPyBNb3pCbG9iQnVpbGRlciA6IFdlYktpdEJsb2JCdWlsZGVyO1xuICAgICAgICB2YXIgYnVpbGRlciA9IG5ldyBCdWlsZGVyKCk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcGFydHMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgICAgIGJ1aWxkZXIuYXBwZW5kKHBhcnRzW2ldKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYnVpbGRlci5nZXRCbG9iKHByb3BlcnRpZXMudHlwZSk7XG4gICAgfVxufVxuXG4vLyBUaGlzIGlzIENvbW1vbkpTIGJlY2F1c2UgbGllIGlzIGFuIGV4dGVybmFsIGRlcGVuZGVuY3ksIHNvIFJvbGx1cFxuLy8gY2FuIGp1c3QgaWdub3JlIGl0LlxuaWYgKHR5cGVvZiBQcm9taXNlID09PSAndW5kZWZpbmVkJykge1xuICAgIC8vIEluIHRoZSBcIm5vcHJvbWlzZXNcIiBidWlsZCB0aGlzIHdpbGwganVzdCB0aHJvdyBpZiB5b3UgZG9uJ3QgaGF2ZVxuICAgIC8vIGEgZ2xvYmFsIHByb21pc2Ugb2JqZWN0LCBidXQgaXQgd291bGQgdGhyb3cgYW55d2F5IGxhdGVyLlxuICAgIF9kZXJlcV8oMyk7XG59XG52YXIgUHJvbWlzZSQxID0gUHJvbWlzZTtcblxuZnVuY3Rpb24gZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKSB7XG4gICAgaWYgKGNhbGxiYWNrKSB7XG4gICAgICAgIHByb21pc2UudGhlbihmdW5jdGlvbiAocmVzdWx0KSB7XG4gICAgICAgICAgICBjYWxsYmFjayhudWxsLCByZXN1bHQpO1xuICAgICAgICB9LCBmdW5jdGlvbiAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNhbGxiYWNrKGVycm9yKTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBleGVjdXRlVHdvQ2FsbGJhY2tzKHByb21pc2UsIGNhbGxiYWNrLCBlcnJvckNhbGxiYWNrKSB7XG4gICAgaWYgKHR5cGVvZiBjYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBwcm9taXNlLnRoZW4oY2FsbGJhY2spO1xuICAgIH1cblxuICAgIGlmICh0eXBlb2YgZXJyb3JDYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBwcm9taXNlW1wiY2F0Y2hcIl0oZXJyb3JDYWxsYmFjayk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBub3JtYWxpemVLZXkoa2V5KSB7XG4gICAgLy8gQ2FzdCB0aGUga2V5IHRvIGEgc3RyaW5nLCBhcyB0aGF0J3MgYWxsIHdlIGNhbiBzZXQgYXMgYSBrZXkuXG4gICAgaWYgKHR5cGVvZiBrZXkgIT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihrZXkgKyAnIHVzZWQgYXMgYSBrZXksIGJ1dCBpdCBpcyBub3QgYSBzdHJpbmcuJyk7XG4gICAgICAgIGtleSA9IFN0cmluZyhrZXkpO1xuICAgIH1cblxuICAgIHJldHVybiBrZXk7XG59XG5cbmZ1bmN0aW9uIGdldENhbGxiYWNrKCkge1xuICAgIGlmIChhcmd1bWVudHMubGVuZ3RoICYmIHR5cGVvZiBhcmd1bWVudHNbYXJndW1lbnRzLmxlbmd0aCAtIDFdID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHJldHVybiBhcmd1bWVudHNbYXJndW1lbnRzLmxlbmd0aCAtIDFdO1xuICAgIH1cbn1cblxuLy8gU29tZSBjb2RlIG9yaWdpbmFsbHkgZnJvbSBhc3luY19zdG9yYWdlLmpzIGluXG4vLyBbR2FpYV0oaHR0cHM6Ly9naXRodWIuY29tL21vemlsbGEtYjJnL2dhaWEpLlxuXG52YXIgREVURUNUX0JMT0JfU1VQUE9SVF9TVE9SRSA9ICdsb2NhbC1mb3JhZ2UtZGV0ZWN0LWJsb2Itc3VwcG9ydCc7XG52YXIgc3VwcG9ydHNCbG9icyA9IHZvaWQgMDtcbnZhciBkYkNvbnRleHRzID0ge307XG52YXIgdG9TdHJpbmcgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nO1xuXG4vLyBUcmFuc2FjdGlvbiBNb2Rlc1xudmFyIFJFQURfT05MWSA9ICdyZWFkb25seSc7XG52YXIgUkVBRF9XUklURSA9ICdyZWFkd3JpdGUnO1xuXG4vLyBUcmFuc2Zvcm0gYSBiaW5hcnkgc3RyaW5nIHRvIGFuIGFycmF5IGJ1ZmZlciwgYmVjYXVzZSBvdGhlcndpc2Vcbi8vIHdlaXJkIHN0dWZmIGhhcHBlbnMgd2hlbiB5b3UgdHJ5IHRvIHdvcmsgd2l0aCB0aGUgYmluYXJ5IHN0cmluZyBkaXJlY3RseS5cbi8vIEl0IGlzIGtub3duLlxuLy8gRnJvbSBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzE0OTY3NjQ3LyAoY29udGludWVzIG9uIG5leHQgbGluZSlcbi8vIGVuY29kZS1kZWNvZGUtaW1hZ2Utd2l0aC1iYXNlNjQtYnJlYWtzLWltYWdlICgyMDEzLTA0LTIxKVxuZnVuY3Rpb24gX2JpblN0cmluZ1RvQXJyYXlCdWZmZXIoYmluKSB7XG4gICAgdmFyIGxlbmd0aCA9IGJpbi5sZW5ndGg7XG4gICAgdmFyIGJ1ZiA9IG5ldyBBcnJheUJ1ZmZlcihsZW5ndGgpO1xuICAgIHZhciBhcnIgPSBuZXcgVWludDhBcnJheShidWYpO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgICAgYXJyW2ldID0gYmluLmNoYXJDb2RlQXQoaSk7XG4gICAgfVxuICAgIHJldHVybiBidWY7XG59XG5cbi8vXG4vLyBCbG9icyBhcmUgbm90IHN1cHBvcnRlZCBpbiBhbGwgdmVyc2lvbnMgb2YgSW5kZXhlZERCLCBub3RhYmx5XG4vLyBDaHJvbWUgPDM3IGFuZCBBbmRyb2lkIDw1LiBJbiB0aG9zZSB2ZXJzaW9ucywgc3RvcmluZyBhIGJsb2Igd2lsbCB0aHJvdy5cbi8vXG4vLyBWYXJpb3VzIG90aGVyIGJsb2IgYnVncyBleGlzdCBpbiBDaHJvbWUgdjM3LTQyIChpbmNsdXNpdmUpLlxuLy8gRGV0ZWN0aW5nIHRoZW0gaXMgZXhwZW5zaXZlIGFuZCBjb25mdXNpbmcgdG8gdXNlcnMsIGFuZCBDaHJvbWUgMzctNDJcbi8vIGlzIGF0IHZlcnkgbG93IHVzYWdlIHdvcmxkd2lkZSwgc28gd2UgZG8gYSBoYWNreSB1c2VyQWdlbnQgY2hlY2sgaW5zdGVhZC5cbi8vXG4vLyBjb250ZW50LXR5cGUgYnVnOiBodHRwczovL2NvZGUuZ29vZ2xlLmNvbS9wL2Nocm9taXVtL2lzc3Vlcy9kZXRhaWw/aWQ9NDA4MTIwXG4vLyA0MDQgYnVnOiBodHRwczovL2NvZGUuZ29vZ2xlLmNvbS9wL2Nocm9taXVtL2lzc3Vlcy9kZXRhaWw/aWQ9NDQ3OTE2XG4vLyBGaWxlUmVhZGVyIGJ1ZzogaHR0cHM6Ly9jb2RlLmdvb2dsZS5jb20vcC9jaHJvbWl1bS9pc3N1ZXMvZGV0YWlsP2lkPTQ0NzgzNlxuLy9cbi8vIENvZGUgYm9ycm93ZWQgZnJvbSBQb3VjaERCLiBTZWU6XG4vLyBodHRwczovL2dpdGh1Yi5jb20vcG91Y2hkYi9wb3VjaGRiL2Jsb2IvbWFzdGVyL3BhY2thZ2VzL25vZGVfbW9kdWxlcy9wb3VjaGRiLWFkYXB0ZXItaWRiL3NyYy9ibG9iU3VwcG9ydC5qc1xuLy9cbmZ1bmN0aW9uIF9jaGVja0Jsb2JTdXBwb3J0V2l0aG91dENhY2hpbmcoaWRiKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlJDEoZnVuY3Rpb24gKHJlc29sdmUpIHtcbiAgICAgICAgdmFyIHR4biA9IGlkYi50cmFuc2FjdGlvbihERVRFQ1RfQkxPQl9TVVBQT1JUX1NUT1JFLCBSRUFEX1dSSVRFKTtcbiAgICAgICAgdmFyIGJsb2IgPSBjcmVhdGVCbG9iKFsnJ10pO1xuICAgICAgICB0eG4ub2JqZWN0U3RvcmUoREVURUNUX0JMT0JfU1VQUE9SVF9TVE9SRSkucHV0KGJsb2IsICdrZXknKTtcblxuICAgICAgICB0eG4ub25hYm9ydCA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAvLyBJZiB0aGUgdHJhbnNhY3Rpb24gYWJvcnRzIG5vdyBpdHMgZHVlIHRvIG5vdCBiZWluZyBhYmxlIHRvXG4gICAgICAgICAgICAvLyB3cml0ZSB0byB0aGUgZGF0YWJhc2UsIGxpa2VseSBkdWUgdG8gdGhlIGRpc2sgYmVpbmcgZnVsbFxuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgIHJlc29sdmUoZmFsc2UpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHR4bi5vbmNvbXBsZXRlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIG1hdGNoZWRDaHJvbWUgPSBuYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9DaHJvbWVcXC8oXFxkKykvKTtcbiAgICAgICAgICAgIHZhciBtYXRjaGVkRWRnZSA9IG5hdmlnYXRvci51c2VyQWdlbnQubWF0Y2goL0VkZ2VcXC8vKTtcbiAgICAgICAgICAgIC8vIE1TIEVkZ2UgcHJldGVuZHMgdG8gYmUgQ2hyb21lIDQyOlxuICAgICAgICAgICAgLy8gaHR0cHM6Ly9tc2RuLm1pY3Jvc29mdC5jb20vZW4tdXMvbGlicmFyeS9oaDg2OTMwMSUyOHY9dnMuODUlMjkuYXNweFxuICAgICAgICAgICAgcmVzb2x2ZShtYXRjaGVkRWRnZSB8fCAhbWF0Y2hlZENocm9tZSB8fCBwYXJzZUludChtYXRjaGVkQ2hyb21lWzFdLCAxMCkgPj0gNDMpO1xuICAgICAgICB9O1xuICAgIH0pW1wiY2F0Y2hcIl0oZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7IC8vIGVycm9yLCBzbyBhc3N1bWUgdW5zdXBwb3J0ZWRcbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gX2NoZWNrQmxvYlN1cHBvcnQoaWRiKSB7XG4gICAgaWYgKHR5cGVvZiBzdXBwb3J0c0Jsb2JzID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UkMS5yZXNvbHZlKHN1cHBvcnRzQmxvYnMpO1xuICAgIH1cbiAgICByZXR1cm4gX2NoZWNrQmxvYlN1cHBvcnRXaXRob3V0Q2FjaGluZyhpZGIpLnRoZW4oZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgIHN1cHBvcnRzQmxvYnMgPSB2YWx1ZTtcbiAgICAgICAgcmV0dXJuIHN1cHBvcnRzQmxvYnM7XG4gICAgfSk7XG59XG5cbmZ1bmN0aW9uIF9kZWZlclJlYWRpbmVzcyhkYkluZm8pIHtcbiAgICB2YXIgZGJDb250ZXh0ID0gZGJDb250ZXh0c1tkYkluZm8ubmFtZV07XG5cbiAgICAvLyBDcmVhdGUgYSBkZWZlcnJlZCBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBjdXJyZW50IGRhdGFiYXNlIG9wZXJhdGlvbi5cbiAgICB2YXIgZGVmZXJyZWRPcGVyYXRpb24gPSB7fTtcblxuICAgIGRlZmVycmVkT3BlcmF0aW9uLnByb21pc2UgPSBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZGVmZXJyZWRPcGVyYXRpb24ucmVzb2x2ZSA9IHJlc29sdmU7XG4gICAgICAgIGRlZmVycmVkT3BlcmF0aW9uLnJlamVjdCA9IHJlamVjdDtcbiAgICB9KTtcblxuICAgIC8vIEVucXVldWUgdGhlIGRlZmVycmVkIG9wZXJhdGlvbi5cbiAgICBkYkNvbnRleHQuZGVmZXJyZWRPcGVyYXRpb25zLnB1c2goZGVmZXJyZWRPcGVyYXRpb24pO1xuXG4gICAgLy8gQ2hhaW4gaXRzIHByb21pc2UgdG8gdGhlIGRhdGFiYXNlIHJlYWRpbmVzcy5cbiAgICBpZiAoIWRiQ29udGV4dC5kYlJlYWR5KSB7XG4gICAgICAgIGRiQ29udGV4dC5kYlJlYWR5ID0gZGVmZXJyZWRPcGVyYXRpb24ucHJvbWlzZTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBkYkNvbnRleHQuZGJSZWFkeSA9IGRiQ29udGV4dC5kYlJlYWR5LnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIGRlZmVycmVkT3BlcmF0aW9uLnByb21pc2U7XG4gICAgICAgIH0pO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gX2FkdmFuY2VSZWFkaW5lc3MoZGJJbmZvKSB7XG4gICAgdmFyIGRiQ29udGV4dCA9IGRiQ29udGV4dHNbZGJJbmZvLm5hbWVdO1xuXG4gICAgLy8gRGVxdWV1ZSBhIGRlZmVycmVkIG9wZXJhdGlvbi5cbiAgICB2YXIgZGVmZXJyZWRPcGVyYXRpb24gPSBkYkNvbnRleHQuZGVmZXJyZWRPcGVyYXRpb25zLnBvcCgpO1xuXG4gICAgLy8gUmVzb2x2ZSBpdHMgcHJvbWlzZSAod2hpY2ggaXMgcGFydCBvZiB0aGUgZGF0YWJhc2UgcmVhZGluZXNzXG4gICAgLy8gY2hhaW4gb2YgcHJvbWlzZXMpLlxuICAgIGlmIChkZWZlcnJlZE9wZXJhdGlvbikge1xuICAgICAgICBkZWZlcnJlZE9wZXJhdGlvbi5yZXNvbHZlKCk7XG4gICAgICAgIHJldHVybiBkZWZlcnJlZE9wZXJhdGlvbi5wcm9taXNlO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gX3JlamVjdFJlYWRpbmVzcyhkYkluZm8sIGVycikge1xuICAgIHZhciBkYkNvbnRleHQgPSBkYkNvbnRleHRzW2RiSW5mby5uYW1lXTtcblxuICAgIC8vIERlcXVldWUgYSBkZWZlcnJlZCBvcGVyYXRpb24uXG4gICAgdmFyIGRlZmVycmVkT3BlcmF0aW9uID0gZGJDb250ZXh0LmRlZmVycmVkT3BlcmF0aW9ucy5wb3AoKTtcblxuICAgIC8vIFJlamVjdCBpdHMgcHJvbWlzZSAod2hpY2ggaXMgcGFydCBvZiB0aGUgZGF0YWJhc2UgcmVhZGluZXNzXG4gICAgLy8gY2hhaW4gb2YgcHJvbWlzZXMpLlxuICAgIGlmIChkZWZlcnJlZE9wZXJhdGlvbikge1xuICAgICAgICBkZWZlcnJlZE9wZXJhdGlvbi5yZWplY3QoZXJyKTtcbiAgICAgICAgcmV0dXJuIGRlZmVycmVkT3BlcmF0aW9uLnByb21pc2U7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBfZ2V0Q29ubmVjdGlvbihkYkluZm8sIHVwZ3JhZGVOZWVkZWQpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UkMShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIGRiQ29udGV4dHNbZGJJbmZvLm5hbWVdID0gZGJDb250ZXh0c1tkYkluZm8ubmFtZV0gfHwgY3JlYXRlRGJDb250ZXh0KCk7XG5cbiAgICAgICAgaWYgKGRiSW5mby5kYikge1xuICAgICAgICAgICAgaWYgKHVwZ3JhZGVOZWVkZWQpIHtcbiAgICAgICAgICAgICAgICBfZGVmZXJSZWFkaW5lc3MoZGJJbmZvKTtcbiAgICAgICAgICAgICAgICBkYkluZm8uZGIuY2xvc2UoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc29sdmUoZGJJbmZvLmRiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBkYkFyZ3MgPSBbZGJJbmZvLm5hbWVdO1xuXG4gICAgICAgIGlmICh1cGdyYWRlTmVlZGVkKSB7XG4gICAgICAgICAgICBkYkFyZ3MucHVzaChkYkluZm8udmVyc2lvbik7XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgb3BlbnJlcSA9IGlkYi5vcGVuLmFwcGx5KGlkYiwgZGJBcmdzKTtcblxuICAgICAgICBpZiAodXBncmFkZU5lZWRlZCkge1xuICAgICAgICAgICAgb3BlbnJlcS5vbnVwZ3JhZGVuZWVkZWQgPSBmdW5jdGlvbiAoZSkge1xuICAgICAgICAgICAgICAgIHZhciBkYiA9IG9wZW5yZXEucmVzdWx0O1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGRiLmNyZWF0ZU9iamVjdFN0b3JlKGRiSW5mby5zdG9yZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZS5vbGRWZXJzaW9uIDw9IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFkZGVkIHdoZW4gc3VwcG9ydCBmb3IgYmxvYiBzaGltcyB3YXMgYWRkZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIGRiLmNyZWF0ZU9iamVjdFN0b3JlKERFVEVDVF9CTE9CX1NVUFBPUlRfU1RPUkUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGV4Lm5hbWUgPT09ICdDb25zdHJhaW50RXJyb3InKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ1RoZSBkYXRhYmFzZSBcIicgKyBkYkluZm8ubmFtZSArICdcIicgKyAnIGhhcyBiZWVuIHVwZ3JhZGVkIGZyb20gdmVyc2lvbiAnICsgZS5vbGRWZXJzaW9uICsgJyB0byB2ZXJzaW9uICcgKyBlLm5ld1ZlcnNpb24gKyAnLCBidXQgdGhlIHN0b3JhZ2UgXCInICsgZGJJbmZvLnN0b3JlTmFtZSArICdcIiBhbHJlYWR5IGV4aXN0cy4nKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGV4O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIG9wZW5yZXEub25lcnJvciA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICByZWplY3Qob3BlbnJlcS5lcnJvcik7XG4gICAgICAgIH07XG5cbiAgICAgICAgb3BlbnJlcS5vbnN1Y2Nlc3MgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgZGIgPSBvcGVucmVxLnJlc3VsdDtcbiAgICAgICAgICAgIGRiLm9udmVyc2lvbmNoYW5nZSA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAgICAgLy8gVHJpZ2dlcmVkIHdoZW4gdGhlIGRhdGFiYXNlIGlzIG1vZGlmaWVkIChlLmcuIGFkZGluZyBhbiBvYmplY3RTdG9yZSkgb3JcbiAgICAgICAgICAgICAgICAvLyBkZWxldGVkIChldmVuIHdoZW4gaW5pdGlhdGVkIGJ5IG90aGVyIHNlc3Npb25zIGluIGRpZmZlcmVudCB0YWJzKS5cbiAgICAgICAgICAgICAgICAvLyBDbG9zaW5nIHRoZSBjb25uZWN0aW9uIGhlcmUgcHJldmVudHMgdGhvc2Ugb3BlcmF0aW9ucyBmcm9tIGJlaW5nIGJsb2NrZWQuXG4gICAgICAgICAgICAgICAgLy8gSWYgdGhlIGRhdGFiYXNlIGlzIGFjY2Vzc2VkIGFnYWluIGxhdGVyIGJ5IHRoaXMgaW5zdGFuY2UsIHRoZSBjb25uZWN0aW9uXG4gICAgICAgICAgICAgICAgLy8gd2lsbCBiZSByZW9wZW5lZCBvciB0aGUgZGF0YWJhc2UgcmVjcmVhdGVkIGFzIG5lZWRlZC5cbiAgICAgICAgICAgICAgICBlLnRhcmdldC5jbG9zZSgpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHJlc29sdmUoZGIpO1xuICAgICAgICAgICAgX2FkdmFuY2VSZWFkaW5lc3MoZGJJbmZvKTtcbiAgICAgICAgfTtcbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gX2dldE9yaWdpbmFsQ29ubmVjdGlvbihkYkluZm8pIHtcbiAgICByZXR1cm4gX2dldENvbm5lY3Rpb24oZGJJbmZvLCBmYWxzZSk7XG59XG5cbmZ1bmN0aW9uIF9nZXRVcGdyYWRlZENvbm5lY3Rpb24oZGJJbmZvKSB7XG4gICAgcmV0dXJuIF9nZXRDb25uZWN0aW9uKGRiSW5mbywgdHJ1ZSk7XG59XG5cbmZ1bmN0aW9uIF9pc1VwZ3JhZGVOZWVkZWQoZGJJbmZvLCBkZWZhdWx0VmVyc2lvbikge1xuICAgIGlmICghZGJJbmZvLmRiKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIHZhciBpc05ld1N0b3JlID0gIWRiSW5mby5kYi5vYmplY3RTdG9yZU5hbWVzLmNvbnRhaW5zKGRiSW5mby5zdG9yZU5hbWUpO1xuICAgIHZhciBpc0Rvd25ncmFkZSA9IGRiSW5mby52ZXJzaW9uIDwgZGJJbmZvLmRiLnZlcnNpb247XG4gICAgdmFyIGlzVXBncmFkZSA9IGRiSW5mby52ZXJzaW9uID4gZGJJbmZvLmRiLnZlcnNpb247XG5cbiAgICBpZiAoaXNEb3duZ3JhZGUpIHtcbiAgICAgICAgLy8gSWYgdGhlIHZlcnNpb24gaXMgbm90IHRoZSBkZWZhdWx0IG9uZVxuICAgICAgICAvLyB0aGVuIHdhcm4gZm9yIGltcG9zc2libGUgZG93bmdyYWRlLlxuICAgICAgICBpZiAoZGJJbmZvLnZlcnNpb24gIT09IGRlZmF1bHRWZXJzaW9uKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ1RoZSBkYXRhYmFzZSBcIicgKyBkYkluZm8ubmFtZSArICdcIicgKyBcIiBjYW4ndCBiZSBkb3duZ3JhZGVkIGZyb20gdmVyc2lvbiBcIiArIGRiSW5mby5kYi52ZXJzaW9uICsgJyB0byB2ZXJzaW9uICcgKyBkYkluZm8udmVyc2lvbiArICcuJyk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQWxpZ24gdGhlIHZlcnNpb25zIHRvIHByZXZlbnQgZXJyb3JzLlxuICAgICAgICBkYkluZm8udmVyc2lvbiA9IGRiSW5mby5kYi52ZXJzaW9uO1xuICAgIH1cblxuICAgIGlmIChpc1VwZ3JhZGUgfHwgaXNOZXdTdG9yZSkge1xuICAgICAgICAvLyBJZiB0aGUgc3RvcmUgaXMgbmV3IHRoZW4gaW5jcmVtZW50IHRoZSB2ZXJzaW9uIChpZiBuZWVkZWQpLlxuICAgICAgICAvLyBUaGlzIHdpbGwgdHJpZ2dlciBhbiBcInVwZ3JhZGVuZWVkZWRcIiBldmVudCB3aGljaCBpcyByZXF1aXJlZFxuICAgICAgICAvLyBmb3IgY3JlYXRpbmcgYSBzdG9yZS5cbiAgICAgICAgaWYgKGlzTmV3U3RvcmUpIHtcbiAgICAgICAgICAgIHZhciBpbmNWZXJzaW9uID0gZGJJbmZvLmRiLnZlcnNpb24gKyAxO1xuICAgICAgICAgICAgaWYgKGluY1ZlcnNpb24gPiBkYkluZm8udmVyc2lvbikge1xuICAgICAgICAgICAgICAgIGRiSW5mby52ZXJzaW9uID0gaW5jVmVyc2lvbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbn1cblxuLy8gZW5jb2RlIGEgYmxvYiBmb3IgaW5kZXhlZGRiIGVuZ2luZXMgdGhhdCBkb24ndCBzdXBwb3J0IGJsb2JzXG5mdW5jdGlvbiBfZW5jb2RlQmxvYihibG9iKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlJDEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICB2YXIgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgICAgcmVhZGVyLm9uZXJyb3IgPSByZWplY3Q7XG4gICAgICAgIHJlYWRlci5vbmxvYWRlbmQgPSBmdW5jdGlvbiAoZSkge1xuICAgICAgICAgICAgdmFyIGJhc2U2NCA9IGJ0b2EoZS50YXJnZXQucmVzdWx0IHx8ICcnKTtcbiAgICAgICAgICAgIHJlc29sdmUoe1xuICAgICAgICAgICAgICAgIF9fbG9jYWxfZm9yYWdlX2VuY29kZWRfYmxvYjogdHJ1ZSxcbiAgICAgICAgICAgICAgICBkYXRhOiBiYXNlNjQsXG4gICAgICAgICAgICAgICAgdHlwZTogYmxvYi50eXBlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfTtcbiAgICAgICAgcmVhZGVyLnJlYWRBc0JpbmFyeVN0cmluZyhibG9iKTtcbiAgICB9KTtcbn1cblxuLy8gZGVjb2RlIGFuIGVuY29kZWQgYmxvYlxuZnVuY3Rpb24gX2RlY29kZUJsb2IoZW5jb2RlZEJsb2IpIHtcbiAgICB2YXIgYXJyYXlCdWZmID0gX2JpblN0cmluZ1RvQXJyYXlCdWZmZXIoYXRvYihlbmNvZGVkQmxvYi5kYXRhKSk7XG4gICAgcmV0dXJuIGNyZWF0ZUJsb2IoW2FycmF5QnVmZl0sIHsgdHlwZTogZW5jb2RlZEJsb2IudHlwZSB9KTtcbn1cblxuLy8gaXMgdGhpcyBvbmUgb2Ygb3VyIGZhbmN5IGVuY29kZWQgYmxvYnM/XG5mdW5jdGlvbiBfaXNFbmNvZGVkQmxvYih2YWx1ZSkge1xuICAgIHJldHVybiB2YWx1ZSAmJiB2YWx1ZS5fX2xvY2FsX2ZvcmFnZV9lbmNvZGVkX2Jsb2I7XG59XG5cbi8vIFNwZWNpYWxpemUgdGhlIGRlZmF1bHQgYHJlYWR5KClgIGZ1bmN0aW9uIGJ5IG1ha2luZyBpdCBkZXBlbmRlbnRcbi8vIG9uIHRoZSBjdXJyZW50IGRhdGFiYXNlIG9wZXJhdGlvbnMuIFRodXMsIHRoZSBkcml2ZXIgd2lsbCBiZSBhY3R1YWxseVxuLy8gcmVhZHkgd2hlbiBpdCdzIGJlZW4gaW5pdGlhbGl6ZWQgKGRlZmF1bHQpICphbmQqIHRoZXJlIGFyZSBubyBwZW5kaW5nXG4vLyBvcGVyYXRpb25zIG9uIHRoZSBkYXRhYmFzZSAoaW5pdGlhdGVkIGJ5IHNvbWUgb3RoZXIgaW5zdGFuY2VzKS5cbmZ1bmN0aW9uIF9mdWxseVJlYWR5KGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgdmFyIHByb21pc2UgPSBzZWxmLl9pbml0UmVhZHkoKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGRiQ29udGV4dCA9IGRiQ29udGV4dHNbc2VsZi5fZGJJbmZvLm5hbWVdO1xuXG4gICAgICAgIGlmIChkYkNvbnRleHQgJiYgZGJDb250ZXh0LmRiUmVhZHkpIHtcbiAgICAgICAgICAgIHJldHVybiBkYkNvbnRleHQuZGJSZWFkeTtcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgZXhlY3V0ZVR3b0NhbGxiYWNrcyhwcm9taXNlLCBjYWxsYmFjaywgY2FsbGJhY2spO1xuICAgIHJldHVybiBwcm9taXNlO1xufVxuXG4vLyBUcnkgdG8gZXN0YWJsaXNoIGEgbmV3IGRiIGNvbm5lY3Rpb24gdG8gcmVwbGFjZSB0aGVcbi8vIGN1cnJlbnQgb25lIHdoaWNoIGlzIGJyb2tlbiAoaS5lLiBleHBlcmllbmNpbmdcbi8vIEludmFsaWRTdGF0ZUVycm9yIHdoaWxlIGNyZWF0aW5nIGEgdHJhbnNhY3Rpb24pLlxuZnVuY3Rpb24gX3RyeVJlY29ubmVjdChkYkluZm8pIHtcbiAgICBfZGVmZXJSZWFkaW5lc3MoZGJJbmZvKTtcblxuICAgIHZhciBkYkNvbnRleHQgPSBkYkNvbnRleHRzW2RiSW5mby5uYW1lXTtcbiAgICB2YXIgZm9yYWdlcyA9IGRiQ29udGV4dC5mb3JhZ2VzO1xuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBmb3JhZ2VzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHZhciBmb3JhZ2UgPSBmb3JhZ2VzW2ldO1xuICAgICAgICBpZiAoZm9yYWdlLl9kYkluZm8uZGIpIHtcbiAgICAgICAgICAgIGZvcmFnZS5fZGJJbmZvLmRiLmNsb3NlKCk7XG4gICAgICAgICAgICBmb3JhZ2UuX2RiSW5mby5kYiA9IG51bGw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZGJJbmZvLmRiID0gbnVsbDtcblxuICAgIHJldHVybiBfZ2V0T3JpZ2luYWxDb25uZWN0aW9uKGRiSW5mbykudGhlbihmdW5jdGlvbiAoZGIpIHtcbiAgICAgICAgZGJJbmZvLmRiID0gZGI7XG4gICAgICAgIGlmIChfaXNVcGdyYWRlTmVlZGVkKGRiSW5mbykpIHtcbiAgICAgICAgICAgIC8vIFJlb3BlbiB0aGUgZGF0YWJhc2UgZm9yIHVwZ3JhZGluZy5cbiAgICAgICAgICAgIHJldHVybiBfZ2V0VXBncmFkZWRDb25uZWN0aW9uKGRiSW5mbyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGRiO1xuICAgIH0pLnRoZW4oZnVuY3Rpb24gKGRiKSB7XG4gICAgICAgIC8vIHN0b3JlIHRoZSBsYXRlc3QgZGIgcmVmZXJlbmNlXG4gICAgICAgIC8vIGluIGNhc2UgdGhlIGRiIHdhcyB1cGdyYWRlZFxuICAgICAgICBkYkluZm8uZGIgPSBkYkNvbnRleHQuZGIgPSBkYjtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBmb3JhZ2VzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBmb3JhZ2VzW2ldLl9kYkluZm8uZGIgPSBkYjtcbiAgICAgICAgfVxuICAgIH0pW1wiY2F0Y2hcIl0oZnVuY3Rpb24gKGVycikge1xuICAgICAgICBfcmVqZWN0UmVhZGluZXNzKGRiSW5mbywgZXJyKTtcbiAgICAgICAgdGhyb3cgZXJyO1xuICAgIH0pO1xufVxuXG4vLyBGRiBkb2Vzbid0IGxpa2UgUHJvbWlzZXMgKG1pY3JvLXRhc2tzKSBhbmQgSUREQiBzdG9yZSBvcGVyYXRpb25zLFxuLy8gc28gd2UgaGF2ZSB0byBkbyBpdCB3aXRoIGNhbGxiYWNrc1xuZnVuY3Rpb24gY3JlYXRlVHJhbnNhY3Rpb24oZGJJbmZvLCBtb2RlLCBjYWxsYmFjaywgcmV0cmllcykge1xuICAgIGlmIChyZXRyaWVzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0cmllcyA9IDE7XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgICAgdmFyIHR4ID0gZGJJbmZvLmRiLnRyYW5zYWN0aW9uKGRiSW5mby5zdG9yZU5hbWUsIG1vZGUpO1xuICAgICAgICBjYWxsYmFjayhudWxsLCB0eCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmIChyZXRyaWVzID4gMCAmJiAoIWRiSW5mby5kYiB8fCBlcnIubmFtZSA9PT0gJ0ludmFsaWRTdGF0ZUVycm9yJyB8fCBlcnIubmFtZSA9PT0gJ05vdEZvdW5kRXJyb3InKSkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UkMS5yZXNvbHZlKCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFkYkluZm8uZGIgfHwgZXJyLm5hbWUgPT09ICdOb3RGb3VuZEVycm9yJyAmJiAhZGJJbmZvLmRiLm9iamVjdFN0b3JlTmFtZXMuY29udGFpbnMoZGJJbmZvLnN0b3JlTmFtZSkgJiYgZGJJbmZvLnZlcnNpb24gPD0gZGJJbmZvLmRiLnZlcnNpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gaW5jcmVhc2UgdGhlIGRiIHZlcnNpb24sIHRvIGNyZWF0ZSB0aGUgbmV3IE9iamVjdFN0b3JlXG4gICAgICAgICAgICAgICAgICAgIGlmIChkYkluZm8uZGIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRiSW5mby52ZXJzaW9uID0gZGJJbmZvLmRiLnZlcnNpb24gKyAxO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vIFJlb3BlbiB0aGUgZGF0YWJhc2UgZm9yIHVwZ3JhZGluZy5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9nZXRVcGdyYWRlZENvbm5lY3Rpb24oZGJJbmZvKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX3RyeVJlY29ubmVjdChkYkluZm8pLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBjcmVhdGVUcmFuc2FjdGlvbihkYkluZm8sIG1vZGUsIGNhbGxiYWNrLCByZXRyaWVzIC0gMSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KVtcImNhdGNoXCJdKGNhbGxiYWNrKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNhbGxiYWNrKGVycik7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBjcmVhdGVEYkNvbnRleHQoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgLy8gUnVubmluZyBsb2NhbEZvcmFnZXMgc2hhcmluZyBhIGRhdGFiYXNlLlxuICAgICAgICBmb3JhZ2VzOiBbXSxcbiAgICAgICAgLy8gU2hhcmVkIGRhdGFiYXNlLlxuICAgICAgICBkYjogbnVsbCxcbiAgICAgICAgLy8gRGF0YWJhc2UgcmVhZGluZXNzIChwcm9taXNlKS5cbiAgICAgICAgZGJSZWFkeTogbnVsbCxcbiAgICAgICAgLy8gRGVmZXJyZWQgb3BlcmF0aW9ucyBvbiB0aGUgZGF0YWJhc2UuXG4gICAgICAgIGRlZmVycmVkT3BlcmF0aW9uczogW11cbiAgICB9O1xufVxuXG4vLyBPcGVuIHRoZSBJbmRleGVkREIgZGF0YWJhc2UgKGF1dG9tYXRpY2FsbHkgY3JlYXRlcyBvbmUgaWYgb25lIGRpZG4ndFxuLy8gcHJldmlvdXNseSBleGlzdCksIHVzaW5nIGFueSBvcHRpb25zIHNldCBpbiB0aGUgY29uZmlnLlxuZnVuY3Rpb24gX2luaXRTdG9yYWdlKG9wdGlvbnMpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIGRiSW5mbyA9IHtcbiAgICAgICAgZGI6IG51bGxcbiAgICB9O1xuXG4gICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgICAgZm9yICh2YXIgaSBpbiBvcHRpb25zKSB7XG4gICAgICAgICAgICBkYkluZm9baV0gPSBvcHRpb25zW2ldO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8gR2V0IHRoZSBjdXJyZW50IGNvbnRleHQgb2YgdGhlIGRhdGFiYXNlO1xuICAgIHZhciBkYkNvbnRleHQgPSBkYkNvbnRleHRzW2RiSW5mby5uYW1lXTtcblxuICAgIC8vIC4uLm9yIGNyZWF0ZSBhIG5ldyBjb250ZXh0LlxuICAgIGlmICghZGJDb250ZXh0KSB7XG4gICAgICAgIGRiQ29udGV4dCA9IGNyZWF0ZURiQ29udGV4dCgpO1xuICAgICAgICAvLyBSZWdpc3RlciB0aGUgbmV3IGNvbnRleHQgaW4gdGhlIGdsb2JhbCBjb250YWluZXIuXG4gICAgICAgIGRiQ29udGV4dHNbZGJJbmZvLm5hbWVdID0gZGJDb250ZXh0O1xuICAgIH1cblxuICAgIC8vIFJlZ2lzdGVyIGl0c2VsZiBhcyBhIHJ1bm5pbmcgbG9jYWxGb3JhZ2UgaW4gdGhlIGN1cnJlbnQgY29udGV4dC5cbiAgICBkYkNvbnRleHQuZm9yYWdlcy5wdXNoKHNlbGYpO1xuXG4gICAgLy8gUmVwbGFjZSB0aGUgZGVmYXVsdCBgcmVhZHkoKWAgZnVuY3Rpb24gd2l0aCB0aGUgc3BlY2lhbGl6ZWQgb25lLlxuICAgIGlmICghc2VsZi5faW5pdFJlYWR5KSB7XG4gICAgICAgIHNlbGYuX2luaXRSZWFkeSA9IHNlbGYucmVhZHk7XG4gICAgICAgIHNlbGYucmVhZHkgPSBfZnVsbHlSZWFkeTtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGUgYW4gYXJyYXkgb2YgaW5pdGlhbGl6YXRpb24gc3RhdGVzIG9mIHRoZSByZWxhdGVkIGxvY2FsRm9yYWdlcy5cbiAgICB2YXIgaW5pdFByb21pc2VzID0gW107XG5cbiAgICBmdW5jdGlvbiBpZ25vcmVFcnJvcnMoKSB7XG4gICAgICAgIC8vIERvbid0IGhhbmRsZSBlcnJvcnMgaGVyZSxcbiAgICAgICAgLy8ganVzdCBtYWtlcyBzdXJlIHJlbGF0ZWQgbG9jYWxGb3JhZ2VzIGFyZW4ndCBwZW5kaW5nLlxuICAgICAgICByZXR1cm4gUHJvbWlzZSQxLnJlc29sdmUoKTtcbiAgICB9XG5cbiAgICBmb3IgKHZhciBqID0gMDsgaiA8IGRiQ29udGV4dC5mb3JhZ2VzLmxlbmd0aDsgaisrKSB7XG4gICAgICAgIHZhciBmb3JhZ2UgPSBkYkNvbnRleHQuZm9yYWdlc1tqXTtcbiAgICAgICAgaWYgKGZvcmFnZSAhPT0gc2VsZikge1xuICAgICAgICAgICAgLy8gRG9uJ3Qgd2FpdCBmb3IgaXRzZWxmLi4uXG4gICAgICAgICAgICBpbml0UHJvbWlzZXMucHVzaChmb3JhZ2UuX2luaXRSZWFkeSgpW1wiY2F0Y2hcIl0oaWdub3JlRXJyb3JzKSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBUYWtlIGEgc25hcHNob3Qgb2YgdGhlIHJlbGF0ZWQgbG9jYWxGb3JhZ2VzLlxuICAgIHZhciBmb3JhZ2VzID0gZGJDb250ZXh0LmZvcmFnZXMuc2xpY2UoMCk7XG5cbiAgICAvLyBJbml0aWFsaXplIHRoZSBjb25uZWN0aW9uIHByb2Nlc3Mgb25seSB3aGVuXG4gICAgLy8gYWxsIHRoZSByZWxhdGVkIGxvY2FsRm9yYWdlcyBhcmVuJ3QgcGVuZGluZy5cbiAgICByZXR1cm4gUHJvbWlzZSQxLmFsbChpbml0UHJvbWlzZXMpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICBkYkluZm8uZGIgPSBkYkNvbnRleHQuZGI7XG4gICAgICAgIC8vIEdldCB0aGUgY29ubmVjdGlvbiBvciBvcGVuIGEgbmV3IG9uZSB3aXRob3V0IHVwZ3JhZGUuXG4gICAgICAgIHJldHVybiBfZ2V0T3JpZ2luYWxDb25uZWN0aW9uKGRiSW5mbyk7XG4gICAgfSkudGhlbihmdW5jdGlvbiAoZGIpIHtcbiAgICAgICAgZGJJbmZvLmRiID0gZGI7XG4gICAgICAgIGlmIChfaXNVcGdyYWRlTmVlZGVkKGRiSW5mbywgc2VsZi5fZGVmYXVsdENvbmZpZy52ZXJzaW9uKSkge1xuICAgICAgICAgICAgLy8gUmVvcGVuIHRoZSBkYXRhYmFzZSBmb3IgdXBncmFkaW5nLlxuICAgICAgICAgICAgcmV0dXJuIF9nZXRVcGdyYWRlZENvbm5lY3Rpb24oZGJJbmZvKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZGI7XG4gICAgfSkudGhlbihmdW5jdGlvbiAoZGIpIHtcbiAgICAgICAgZGJJbmZvLmRiID0gZGJDb250ZXh0LmRiID0gZGI7XG4gICAgICAgIHNlbGYuX2RiSW5mbyA9IGRiSW5mbztcbiAgICAgICAgLy8gU2hhcmUgdGhlIGZpbmFsIGNvbm5lY3Rpb24gYW1vbmdzdCByZWxhdGVkIGxvY2FsRm9yYWdlcy5cbiAgICAgICAgZm9yICh2YXIgayA9IDA7IGsgPCBmb3JhZ2VzLmxlbmd0aDsgaysrKSB7XG4gICAgICAgICAgICB2YXIgZm9yYWdlID0gZm9yYWdlc1trXTtcbiAgICAgICAgICAgIGlmIChmb3JhZ2UgIT09IHNlbGYpIHtcbiAgICAgICAgICAgICAgICAvLyBTZWxmIGlzIGFscmVhZHkgdXAtdG8tZGF0ZS5cbiAgICAgICAgICAgICAgICBmb3JhZ2UuX2RiSW5mby5kYiA9IGRiSW5mby5kYjtcbiAgICAgICAgICAgICAgICBmb3JhZ2UuX2RiSW5mby52ZXJzaW9uID0gZGJJbmZvLnZlcnNpb247XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gZ2V0SXRlbShrZXksIGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAga2V5ID0gbm9ybWFsaXplS2V5KGtleSk7XG5cbiAgICB2YXIgcHJvbWlzZSA9IG5ldyBQcm9taXNlJDEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjcmVhdGVUcmFuc2FjdGlvbihzZWxmLl9kYkluZm8sIFJFQURfT05MWSwgZnVuY3Rpb24gKGVyciwgdHJhbnNhY3Rpb24pIHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZWplY3QoZXJyKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgc3RvcmUgPSB0cmFuc2FjdGlvbi5vYmplY3RTdG9yZShzZWxmLl9kYkluZm8uc3RvcmVOYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcSA9IHN0b3JlLmdldChrZXkpO1xuXG4gICAgICAgICAgICAgICAgICAgIHJlcS5vbnN1Y2Nlc3MgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgdmFsdWUgPSByZXEucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoX2lzRW5jb2RlZEJsb2IodmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUgPSBfZGVjb2RlQmxvYih2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICByZXEub25lcnJvciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChyZXEuZXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KVtcImNhdGNoXCJdKHJlamVjdCk7XG4gICAgfSk7XG5cbiAgICBleGVjdXRlQ2FsbGJhY2socHJvbWlzZSwgY2FsbGJhY2spO1xuICAgIHJldHVybiBwcm9taXNlO1xufVxuXG4vLyBJdGVyYXRlIG92ZXIgYWxsIGl0ZW1zIHN0b3JlZCBpbiBkYXRhYmFzZS5cbmZ1bmN0aW9uIGl0ZXJhdGUoaXRlcmF0b3IsIGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgdmFyIHByb21pc2UgPSBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgc2VsZi5yZWFkeSgpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY3JlYXRlVHJhbnNhY3Rpb24oc2VsZi5fZGJJbmZvLCBSRUFEX09OTFksIGZ1bmN0aW9uIChlcnIsIHRyYW5zYWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVqZWN0KGVycik7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHN0b3JlID0gdHJhbnNhY3Rpb24ub2JqZWN0U3RvcmUoc2VsZi5fZGJJbmZvLnN0b3JlTmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZXEgPSBzdG9yZS5vcGVuQ3Vyc29yKCk7XG4gICAgICAgICAgICAgICAgICAgIHZhciBpdGVyYXRpb25OdW1iZXIgPSAxO1xuXG4gICAgICAgICAgICAgICAgICAgIHJlcS5vbnN1Y2Nlc3MgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgY3Vyc29yID0gcmVxLnJlc3VsdDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnNvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9IGN1cnNvci52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoX2lzRW5jb2RlZEJsb2IodmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlID0gX2RlY29kZUJsb2IodmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gaXRlcmF0b3IodmFsdWUsIGN1cnNvci5rZXksIGl0ZXJhdGlvbk51bWJlcisrKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHdoZW4gdGhlIGl0ZXJhdG9yIGNhbGxiYWNrIHJldHVybnMgYW55XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gKG5vbi1gdW5kZWZpbmVkYCkgdmFsdWUsIHRoZW4gd2Ugc3RvcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoZSBpdGVyYXRpb24gaW1tZWRpYXRlbHlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0ICE9PSB2b2lkIDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvcltcImNvbnRpbnVlXCJdKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgcmVxLm9uZXJyb3IgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QocmVxLmVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSlbXCJjYXRjaFwiXShyZWplY3QpO1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcblxuICAgIHJldHVybiBwcm9taXNlO1xufVxuXG5mdW5jdGlvbiBzZXRJdGVtKGtleSwgdmFsdWUsIGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAga2V5ID0gbm9ybWFsaXplS2V5KGtleSk7XG5cbiAgICB2YXIgcHJvbWlzZSA9IG5ldyBQcm9taXNlJDEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICB2YXIgZGJJbmZvO1xuICAgICAgICBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBkYkluZm8gPSBzZWxmLl9kYkluZm87XG4gICAgICAgICAgICBpZiAodG9TdHJpbmcuY2FsbCh2YWx1ZSkgPT09ICdbb2JqZWN0IEJsb2JdJykge1xuICAgICAgICAgICAgICAgIHJldHVybiBfY2hlY2tCbG9iU3VwcG9ydChkYkluZm8uZGIpLnRoZW4oZnVuY3Rpb24gKGJsb2JTdXBwb3J0KSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChibG9iU3VwcG9ydCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBfZW5jb2RlQmxvYih2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgIH0pLnRoZW4oZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBjcmVhdGVUcmFuc2FjdGlvbihzZWxmLl9kYkluZm8sIFJFQURfV1JJVEUsIGZ1bmN0aW9uIChlcnIsIHRyYW5zYWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVqZWN0KGVycik7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHN0b3JlID0gdHJhbnNhY3Rpb24ub2JqZWN0U3RvcmUoc2VsZi5fZGJJbmZvLnN0b3JlTmFtZSk7XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gVGhlIHJlYXNvbiB3ZSBkb24ndCBfc2F2ZV8gbnVsbCBpcyBiZWNhdXNlIElFIDEwIGRvZXNcbiAgICAgICAgICAgICAgICAgICAgLy8gbm90IHN1cHBvcnQgc2F2aW5nIHRoZSBgbnVsbGAgdHlwZSBpbiBJbmRleGVkREIuIEhvd1xuICAgICAgICAgICAgICAgICAgICAvLyBpcm9uaWMsIGdpdmVuIHRoZSBidWcgYmVsb3chXG4gICAgICAgICAgICAgICAgICAgIC8vIFNlZTogaHR0cHM6Ly9naXRodWIuY29tL21vemlsbGEvbG9jYWxGb3JhZ2UvaXNzdWVzLzE2MVxuICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcSA9IHN0b3JlLnB1dCh2YWx1ZSwga2V5KTtcblxuICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbi5vbmNvbXBsZXRlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ2FzdCB0byB1bmRlZmluZWQgc28gdGhlIHZhbHVlIHBhc3NlZCB0b1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2FsbGJhY2svcHJvbWlzZSBpcyB0aGUgc2FtZSBhcyB3aGF0IG9uZSB3b3VsZCBnZXQgb3V0XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBvZiBgZ2V0SXRlbSgpYCBsYXRlci4gVGhpcyBsZWFkcyB0byBzb21lIHdlaXJkbmVzc1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gKHNldEl0ZW0oJ2ZvbycsIHVuZGVmaW5lZCkgd2lsbCByZXR1cm4gYG51bGxgKSwgYnV0XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpdCdzIG5vdCBteSBmYXVsdCBsb2NhbFN0b3JhZ2UgaXMgb3VyIGJhc2VsaW5lIGFuZCB0aGF0XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpdCdzIHdlaXJkLlxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUodmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbi5vbmFib3J0ID0gdHJhbnNhY3Rpb24ub25lcnJvciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBlcnIgPSByZXEuZXJyb3IgPyByZXEuZXJyb3IgOiByZXEudHJhbnNhY3Rpb24uZXJyb3I7XG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSlbXCJjYXRjaFwiXShyZWplY3QpO1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuZnVuY3Rpb24gcmVtb3ZlSXRlbShrZXksIGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAga2V5ID0gbm9ybWFsaXplS2V5KGtleSk7XG5cbiAgICB2YXIgcHJvbWlzZSA9IG5ldyBQcm9taXNlJDEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjcmVhdGVUcmFuc2FjdGlvbihzZWxmLl9kYkluZm8sIFJFQURfV1JJVEUsIGZ1bmN0aW9uIChlcnIsIHRyYW5zYWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVqZWN0KGVycik7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHN0b3JlID0gdHJhbnNhY3Rpb24ub2JqZWN0U3RvcmUoc2VsZi5fZGJJbmZvLnN0b3JlTmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIC8vIFdlIHVzZSBhIEdydW50IHRhc2sgdG8gbWFrZSB0aGlzIHNhZmUgZm9yIElFIGFuZCBzb21lXG4gICAgICAgICAgICAgICAgICAgIC8vIHZlcnNpb25zIG9mIEFuZHJvaWQgKGluY2x1ZGluZyB0aG9zZSB1c2VkIGJ5IENvcmRvdmEpLlxuICAgICAgICAgICAgICAgICAgICAvLyBOb3JtYWxseSBJRSB3b24ndCBsaWtlIGAuZGVsZXRlKClgIGFuZCB3aWxsIGluc2lzdCBvblxuICAgICAgICAgICAgICAgICAgICAvLyB1c2luZyBgWydkZWxldGUnXSgpYCwgYnV0IHdlIGhhdmUgYSBidWlsZCBzdGVwIHRoYXRcbiAgICAgICAgICAgICAgICAgICAgLy8gZml4ZXMgdGhpcyBmb3IgdXMgbm93LlxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVxID0gc3RvcmVbXCJkZWxldGVcIl0oa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNhY3Rpb24ub25jb21wbGV0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbi5vbmVycm9yID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KHJlcS5lcnJvcik7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gVGhlIHJlcXVlc3Qgd2lsbCBiZSBhbHNvIGJlIGFib3J0ZWQgaWYgd2UndmUgZXhjZWVkZWQgb3VyIHN0b3JhZ2VcbiAgICAgICAgICAgICAgICAgICAgLy8gc3BhY2UuXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uLm9uYWJvcnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZXJyID0gcmVxLmVycm9yID8gcmVxLmVycm9yIDogcmVxLnRyYW5zYWN0aW9uLmVycm9yO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICByZWplY3QoZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pW1wiY2F0Y2hcIl0ocmVqZWN0KTtcbiAgICB9KTtcblxuICAgIGV4ZWN1dGVDYWxsYmFjayhwcm9taXNlLCBjYWxsYmFjayk7XG4gICAgcmV0dXJuIHByb21pc2U7XG59XG5cbmZ1bmN0aW9uIGNsZWFyKGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgdmFyIHByb21pc2UgPSBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgc2VsZi5yZWFkeSgpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY3JlYXRlVHJhbnNhY3Rpb24oc2VsZi5fZGJJbmZvLCBSRUFEX1dSSVRFLCBmdW5jdGlvbiAoZXJyLCB0cmFuc2FjdGlvbikge1xuICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBzdG9yZSA9IHRyYW5zYWN0aW9uLm9iamVjdFN0b3JlKHNlbGYuX2RiSW5mby5zdG9yZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICB2YXIgcmVxID0gc3RvcmUuY2xlYXIoKTtcblxuICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbi5vbmNvbXBsZXRlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uLm9uYWJvcnQgPSB0cmFuc2FjdGlvbi5vbmVycm9yID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVyciA9IHJlcS5lcnJvciA/IHJlcS5lcnJvciA6IHJlcS50cmFuc2FjdGlvbi5lcnJvcjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KVtcImNhdGNoXCJdKHJlamVjdCk7XG4gICAgfSk7XG5cbiAgICBleGVjdXRlQ2FsbGJhY2socHJvbWlzZSwgY2FsbGJhY2spO1xuICAgIHJldHVybiBwcm9taXNlO1xufVxuXG5mdW5jdGlvbiBsZW5ndGgoY2FsbGJhY2spIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICB2YXIgcHJvbWlzZSA9IG5ldyBQcm9taXNlJDEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjcmVhdGVUcmFuc2FjdGlvbihzZWxmLl9kYkluZm8sIFJFQURfT05MWSwgZnVuY3Rpb24gKGVyciwgdHJhbnNhY3Rpb24pIHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZWplY3QoZXJyKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgc3RvcmUgPSB0cmFuc2FjdGlvbi5vYmplY3RTdG9yZShzZWxmLl9kYkluZm8uc3RvcmVOYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcSA9IHN0b3JlLmNvdW50KCk7XG5cbiAgICAgICAgICAgICAgICAgICAgcmVxLm9uc3VjY2VzcyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVxLnJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgcmVxLm9uZXJyb3IgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QocmVxLmVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSlbXCJjYXRjaFwiXShyZWplY3QpO1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuZnVuY3Rpb24ga2V5KG4sIGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgdmFyIHByb21pc2UgPSBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgaWYgKG4gPCAwKSB7XG4gICAgICAgICAgICByZXNvbHZlKG51bGwpO1xuXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjcmVhdGVUcmFuc2FjdGlvbihzZWxmLl9kYkluZm8sIFJFQURfT05MWSwgZnVuY3Rpb24gKGVyciwgdHJhbnNhY3Rpb24pIHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZWplY3QoZXJyKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgc3RvcmUgPSB0cmFuc2FjdGlvbi5vYmplY3RTdG9yZShzZWxmLl9kYkluZm8uc3RvcmVOYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFkdmFuY2VkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZXEgPSBzdG9yZS5vcGVuS2V5Q3Vyc29yKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgcmVxLm9uc3VjY2VzcyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjdXJzb3IgPSByZXEucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFjdXJzb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGlzIG1lYW5zIHRoZXJlIHdlcmVuJ3QgZW5vdWdoIGtleXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKG51bGwpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobiA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFdlIGhhdmUgdGhlIGZpcnN0IGtleSwgcmV0dXJuIGl0IGlmIHRoYXQncyB3aGF0IHRoZXlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB3YW50ZWQuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShjdXJzb3Iua2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFhZHZhbmNlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBPdGhlcndpc2UsIGFzayB0aGUgY3Vyc29yIHRvIHNraXAgYWhlYWQgblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyByZWNvcmRzLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZHZhbmNlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5hZHZhbmNlKG4pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFdoZW4gd2UgZ2V0IGhlcmUsIHdlJ3ZlIGdvdCB0aGUgbnRoIGtleS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShjdXJzb3Iua2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgcmVxLm9uZXJyb3IgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QocmVxLmVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSlbXCJjYXRjaFwiXShyZWplY3QpO1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuZnVuY3Rpb24ga2V5cyhjYWxsYmFjaykge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIHZhciBwcm9taXNlID0gbmV3IFByb21pc2UkMShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIHNlbGYucmVhZHkoKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNyZWF0ZVRyYW5zYWN0aW9uKHNlbGYuX2RiSW5mbywgUkVBRF9PTkxZLCBmdW5jdGlvbiAoZXJyLCB0cmFuc2FjdGlvbikge1xuICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBzdG9yZSA9IHRyYW5zYWN0aW9uLm9iamVjdFN0b3JlKHNlbGYuX2RiSW5mby5zdG9yZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICB2YXIgcmVxID0gc3RvcmUub3BlbktleUN1cnNvcigpO1xuICAgICAgICAgICAgICAgICAgICB2YXIga2V5cyA9IFtdO1xuXG4gICAgICAgICAgICAgICAgICAgIHJlcS5vbnN1Y2Nlc3MgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgY3Vyc29yID0gcmVxLnJlc3VsdDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFjdXJzb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKGtleXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAga2V5cy5wdXNoKGN1cnNvci5rZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yW1wiY29udGludWVcIl0oKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICByZXEub25lcnJvciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChyZXEuZXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KVtcImNhdGNoXCJdKHJlamVjdCk7XG4gICAgfSk7XG5cbiAgICBleGVjdXRlQ2FsbGJhY2socHJvbWlzZSwgY2FsbGJhY2spO1xuICAgIHJldHVybiBwcm9taXNlO1xufVxuXG5mdW5jdGlvbiBkcm9wSW5zdGFuY2Uob3B0aW9ucywgY2FsbGJhY2spIHtcbiAgICBjYWxsYmFjayA9IGdldENhbGxiYWNrLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cbiAgICB2YXIgY3VycmVudENvbmZpZyA9IHRoaXMuY29uZmlnKCk7XG4gICAgb3B0aW9ucyA9IHR5cGVvZiBvcHRpb25zICE9PSAnZnVuY3Rpb24nICYmIG9wdGlvbnMgfHwge307XG4gICAgaWYgKCFvcHRpb25zLm5hbWUpIHtcbiAgICAgICAgb3B0aW9ucy5uYW1lID0gb3B0aW9ucy5uYW1lIHx8IGN1cnJlbnRDb25maWcubmFtZTtcbiAgICAgICAgb3B0aW9ucy5zdG9yZU5hbWUgPSBvcHRpb25zLnN0b3JlTmFtZSB8fCBjdXJyZW50Q29uZmlnLnN0b3JlTmFtZTtcbiAgICB9XG5cbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIHByb21pc2U7XG4gICAgaWYgKCFvcHRpb25zLm5hbWUpIHtcbiAgICAgICAgcHJvbWlzZSA9IFByb21pc2UkMS5yZWplY3QoJ0ludmFsaWQgYXJndW1lbnRzJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgdmFyIGlzQ3VycmVudERiID0gb3B0aW9ucy5uYW1lID09PSBjdXJyZW50Q29uZmlnLm5hbWUgJiYgc2VsZi5fZGJJbmZvLmRiO1xuXG4gICAgICAgIHZhciBkYlByb21pc2UgPSBpc0N1cnJlbnREYiA/IFByb21pc2UkMS5yZXNvbHZlKHNlbGYuX2RiSW5mby5kYikgOiBfZ2V0T3JpZ2luYWxDb25uZWN0aW9uKG9wdGlvbnMpLnRoZW4oZnVuY3Rpb24gKGRiKSB7XG4gICAgICAgICAgICB2YXIgZGJDb250ZXh0ID0gZGJDb250ZXh0c1tvcHRpb25zLm5hbWVdO1xuICAgICAgICAgICAgdmFyIGZvcmFnZXMgPSBkYkNvbnRleHQuZm9yYWdlcztcbiAgICAgICAgICAgIGRiQ29udGV4dC5kYiA9IGRiO1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBmb3JhZ2VzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgZm9yYWdlc1tpXS5fZGJJbmZvLmRiID0gZGI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZGI7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmICghb3B0aW9ucy5zdG9yZU5hbWUpIHtcbiAgICAgICAgICAgIHByb21pc2UgPSBkYlByb21pc2UudGhlbihmdW5jdGlvbiAoZGIpIHtcbiAgICAgICAgICAgICAgICBfZGVmZXJSZWFkaW5lc3Mob3B0aW9ucyk7XG5cbiAgICAgICAgICAgICAgICB2YXIgZGJDb250ZXh0ID0gZGJDb250ZXh0c1tvcHRpb25zLm5hbWVdO1xuICAgICAgICAgICAgICAgIHZhciBmb3JhZ2VzID0gZGJDb250ZXh0LmZvcmFnZXM7XG5cbiAgICAgICAgICAgICAgICBkYi5jbG9zZSgpO1xuICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZm9yYWdlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgZm9yYWdlID0gZm9yYWdlc1tpXTtcbiAgICAgICAgICAgICAgICAgICAgZm9yYWdlLl9kYkluZm8uZGIgPSBudWxsO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHZhciBkcm9wREJQcm9taXNlID0gbmV3IFByb21pc2UkMShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZXEgPSBpZGIuZGVsZXRlRGF0YWJhc2Uob3B0aW9ucy5uYW1lKTtcblxuICAgICAgICAgICAgICAgICAgICByZXEub25lcnJvciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkYiA9IHJlcS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYi5jbG9zZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KHJlcS5lcnJvcik7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgcmVxLm9uYmxvY2tlZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIENsb3NpbmcgYWxsIG9wZW4gY29ubmVjdGlvbnMgaW4gb252ZXJzaW9uY2hhbmdlIGhhbmRsZXIgc2hvdWxkIHByZXZlbnQgdGhpcyBzaXR1YXRpb24sIGJ1dCBpZlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2UgZG8gZ2V0IGhlcmUsIGl0IGp1c3QgbWVhbnMgdGhlIHJlcXVlc3QgcmVtYWlucyBwZW5kaW5nIC0gZXZlbnR1YWxseSBpdCB3aWxsIHN1Y2NlZWQgb3IgZXJyb3JcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignZHJvcEluc3RhbmNlIGJsb2NrZWQgZm9yIGRhdGFiYXNlIFwiJyArIG9wdGlvbnMubmFtZSArICdcIiB1bnRpbCBhbGwgb3BlbiBjb25uZWN0aW9ucyBhcmUgY2xvc2VkJyk7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgcmVxLm9uc3VjY2VzcyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkYiA9IHJlcS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYi5jbG9zZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShkYik7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZHJvcERCUHJvbWlzZS50aGVuKGZ1bmN0aW9uIChkYikge1xuICAgICAgICAgICAgICAgICAgICBkYkNvbnRleHQuZGIgPSBkYjtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBmb3JhZ2VzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX2ZvcmFnZSA9IGZvcmFnZXNbaV07XG4gICAgICAgICAgICAgICAgICAgICAgICBfYWR2YW5jZVJlYWRpbmVzcyhfZm9yYWdlLl9kYkluZm8pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSlbXCJjYXRjaFwiXShmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIChfcmVqZWN0UmVhZGluZXNzKG9wdGlvbnMsIGVycikgfHwgUHJvbWlzZSQxLnJlc29sdmUoKSlbXCJjYXRjaFwiXShmdW5jdGlvbiAoKSB7fSk7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcHJvbWlzZSA9IGRiUHJvbWlzZS50aGVuKGZ1bmN0aW9uIChkYikge1xuICAgICAgICAgICAgICAgIGlmICghZGIub2JqZWN0U3RvcmVOYW1lcy5jb250YWlucyhvcHRpb25zLnN0b3JlTmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHZhciBuZXdWZXJzaW9uID0gZGIudmVyc2lvbiArIDE7XG5cbiAgICAgICAgICAgICAgICBfZGVmZXJSZWFkaW5lc3Mob3B0aW9ucyk7XG5cbiAgICAgICAgICAgICAgICB2YXIgZGJDb250ZXh0ID0gZGJDb250ZXh0c1tvcHRpb25zLm5hbWVdO1xuICAgICAgICAgICAgICAgIHZhciBmb3JhZ2VzID0gZGJDb250ZXh0LmZvcmFnZXM7XG5cbiAgICAgICAgICAgICAgICBkYi5jbG9zZSgpO1xuICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZm9yYWdlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgZm9yYWdlID0gZm9yYWdlc1tpXTtcbiAgICAgICAgICAgICAgICAgICAgZm9yYWdlLl9kYkluZm8uZGIgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICBmb3JhZ2UuX2RiSW5mby52ZXJzaW9uID0gbmV3VmVyc2lvbjtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB2YXIgZHJvcE9iamVjdFByb21pc2UgPSBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlcSA9IGlkYi5vcGVuKG9wdGlvbnMubmFtZSwgbmV3VmVyc2lvbik7XG5cbiAgICAgICAgICAgICAgICAgICAgcmVxLm9uZXJyb3IgPSBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGIgPSByZXEucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgZGIuY2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgIHJlcS5vbnVwZ3JhZGVuZWVkZWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGIgPSByZXEucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgZGIuZGVsZXRlT2JqZWN0U3RvcmUob3B0aW9ucy5zdG9yZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgIHJlcS5vbnN1Y2Nlc3MgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGIgPSByZXEucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgZGIuY2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoZGIpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGRyb3BPYmplY3RQcm9taXNlLnRoZW4oZnVuY3Rpb24gKGRiKSB7XG4gICAgICAgICAgICAgICAgICAgIGRiQ29udGV4dC5kYiA9IGRiO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGZvcmFnZXMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfZm9yYWdlMiA9IGZvcmFnZXNbal07XG4gICAgICAgICAgICAgICAgICAgICAgICBfZm9yYWdlMi5fZGJJbmZvLmRiID0gZGI7XG4gICAgICAgICAgICAgICAgICAgICAgICBfYWR2YW5jZVJlYWRpbmVzcyhfZm9yYWdlMi5fZGJJbmZvKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pW1wiY2F0Y2hcIl0oZnVuY3Rpb24gKGVycikge1xuICAgICAgICAgICAgICAgICAgICAoX3JlamVjdFJlYWRpbmVzcyhvcHRpb25zLCBlcnIpIHx8IFByb21pc2UkMS5yZXNvbHZlKCkpW1wiY2F0Y2hcIl0oZnVuY3Rpb24gKCkge30pO1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGV4ZWN1dGVDYWxsYmFjayhwcm9taXNlLCBjYWxsYmFjayk7XG4gICAgcmV0dXJuIHByb21pc2U7XG59XG5cbnZhciBhc3luY1N0b3JhZ2UgPSB7XG4gICAgX2RyaXZlcjogJ2FzeW5jU3RvcmFnZScsXG4gICAgX2luaXRTdG9yYWdlOiBfaW5pdFN0b3JhZ2UsXG4gICAgX3N1cHBvcnQ6IGlzSW5kZXhlZERCVmFsaWQoKSxcbiAgICBpdGVyYXRlOiBpdGVyYXRlLFxuICAgIGdldEl0ZW06IGdldEl0ZW0sXG4gICAgc2V0SXRlbTogc2V0SXRlbSxcbiAgICByZW1vdmVJdGVtOiByZW1vdmVJdGVtLFxuICAgIGNsZWFyOiBjbGVhcixcbiAgICBsZW5ndGg6IGxlbmd0aCxcbiAgICBrZXk6IGtleSxcbiAgICBrZXlzOiBrZXlzLFxuICAgIGRyb3BJbnN0YW5jZTogZHJvcEluc3RhbmNlXG59O1xuXG5mdW5jdGlvbiBpc1dlYlNRTFZhbGlkKCkge1xuICAgIHJldHVybiB0eXBlb2Ygb3BlbkRhdGFiYXNlID09PSAnZnVuY3Rpb24nO1xufVxuXG4vLyBTYWRseSwgdGhlIGJlc3Qgd2F5IHRvIHNhdmUgYmluYXJ5IGRhdGEgaW4gV2ViU1FML2xvY2FsU3RvcmFnZSBpcyBzZXJpYWxpemluZ1xuLy8gaXQgdG8gQmFzZTY0LCBzbyB0aGlzIGlzIGhvdyB3ZSBzdG9yZSBpdCB0byBwcmV2ZW50IHZlcnkgc3RyYW5nZSBlcnJvcnMgd2l0aCBsZXNzXG4vLyB2ZXJib3NlIHdheXMgb2YgYmluYXJ5IDwtPiBzdHJpbmcgZGF0YSBzdG9yYWdlLlxudmFyIEJBU0VfQ0hBUlMgPSAnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLyc7XG5cbnZhciBCTE9CX1RZUEVfUFJFRklYID0gJ35+bG9jYWxfZm9yYWdlX3R5cGV+JztcbnZhciBCTE9CX1RZUEVfUFJFRklYX1JFR0VYID0gL15+fmxvY2FsX2ZvcmFnZV90eXBlfihbXn5dKyl+LztcblxudmFyIFNFUklBTElaRURfTUFSS0VSID0gJ19fbGZzY19fOic7XG52YXIgU0VSSUFMSVpFRF9NQVJLRVJfTEVOR1RIID0gU0VSSUFMSVpFRF9NQVJLRVIubGVuZ3RoO1xuXG4vLyBPTUcgdGhlIHNlcmlhbGl6YXRpb25zIVxudmFyIFRZUEVfQVJSQVlCVUZGRVIgPSAnYXJiZic7XG52YXIgVFlQRV9CTE9CID0gJ2Jsb2InO1xudmFyIFRZUEVfSU5UOEFSUkFZID0gJ3NpMDgnO1xudmFyIFRZUEVfVUlOVDhBUlJBWSA9ICd1aTA4JztcbnZhciBUWVBFX1VJTlQ4Q0xBTVBFREFSUkFZID0gJ3VpYzgnO1xudmFyIFRZUEVfSU5UMTZBUlJBWSA9ICdzaTE2JztcbnZhciBUWVBFX0lOVDMyQVJSQVkgPSAnc2kzMic7XG52YXIgVFlQRV9VSU5UMTZBUlJBWSA9ICd1cjE2JztcbnZhciBUWVBFX1VJTlQzMkFSUkFZID0gJ3VpMzInO1xudmFyIFRZUEVfRkxPQVQzMkFSUkFZID0gJ2ZsMzInO1xudmFyIFRZUEVfRkxPQVQ2NEFSUkFZID0gJ2ZsNjQnO1xudmFyIFRZUEVfU0VSSUFMSVpFRF9NQVJLRVJfTEVOR1RIID0gU0VSSUFMSVpFRF9NQVJLRVJfTEVOR1RIICsgVFlQRV9BUlJBWUJVRkZFUi5sZW5ndGg7XG5cbnZhciB0b1N0cmluZyQxID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZztcblxuZnVuY3Rpb24gc3RyaW5nVG9CdWZmZXIoc2VyaWFsaXplZFN0cmluZykge1xuICAgIC8vIEZpbGwgdGhlIHN0cmluZyBpbnRvIGEgQXJyYXlCdWZmZXIuXG4gICAgdmFyIGJ1ZmZlckxlbmd0aCA9IHNlcmlhbGl6ZWRTdHJpbmcubGVuZ3RoICogMC43NTtcbiAgICB2YXIgbGVuID0gc2VyaWFsaXplZFN0cmluZy5sZW5ndGg7XG4gICAgdmFyIGk7XG4gICAgdmFyIHAgPSAwO1xuICAgIHZhciBlbmNvZGVkMSwgZW5jb2RlZDIsIGVuY29kZWQzLCBlbmNvZGVkNDtcblxuICAgIGlmIChzZXJpYWxpemVkU3RyaW5nW3NlcmlhbGl6ZWRTdHJpbmcubGVuZ3RoIC0gMV0gPT09ICc9Jykge1xuICAgICAgICBidWZmZXJMZW5ndGgtLTtcbiAgICAgICAgaWYgKHNlcmlhbGl6ZWRTdHJpbmdbc2VyaWFsaXplZFN0cmluZy5sZW5ndGggLSAyXSA9PT0gJz0nKSB7XG4gICAgICAgICAgICBidWZmZXJMZW5ndGgtLTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHZhciBidWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoYnVmZmVyTGVuZ3RoKTtcbiAgICB2YXIgYnl0ZXMgPSBuZXcgVWludDhBcnJheShidWZmZXIpO1xuXG4gICAgZm9yIChpID0gMDsgaSA8IGxlbjsgaSArPSA0KSB7XG4gICAgICAgIGVuY29kZWQxID0gQkFTRV9DSEFSUy5pbmRleE9mKHNlcmlhbGl6ZWRTdHJpbmdbaV0pO1xuICAgICAgICBlbmNvZGVkMiA9IEJBU0VfQ0hBUlMuaW5kZXhPZihzZXJpYWxpemVkU3RyaW5nW2kgKyAxXSk7XG4gICAgICAgIGVuY29kZWQzID0gQkFTRV9DSEFSUy5pbmRleE9mKHNlcmlhbGl6ZWRTdHJpbmdbaSArIDJdKTtcbiAgICAgICAgZW5jb2RlZDQgPSBCQVNFX0NIQVJTLmluZGV4T2Yoc2VyaWFsaXplZFN0cmluZ1tpICsgM10pO1xuXG4gICAgICAgIC8qanNsaW50IGJpdHdpc2U6IHRydWUgKi9cbiAgICAgICAgYnl0ZXNbcCsrXSA9IGVuY29kZWQxIDw8IDIgfCBlbmNvZGVkMiA+PiA0O1xuICAgICAgICBieXRlc1twKytdID0gKGVuY29kZWQyICYgMTUpIDw8IDQgfCBlbmNvZGVkMyA+PiAyO1xuICAgICAgICBieXRlc1twKytdID0gKGVuY29kZWQzICYgMykgPDwgNiB8IGVuY29kZWQ0ICYgNjM7XG4gICAgfVxuICAgIHJldHVybiBidWZmZXI7XG59XG5cbi8vIENvbnZlcnRzIGEgYnVmZmVyIHRvIGEgc3RyaW5nIHRvIHN0b3JlLCBzZXJpYWxpemVkLCBpbiB0aGUgYmFja2VuZFxuLy8gc3RvcmFnZSBsaWJyYXJ5LlxuZnVuY3Rpb24gYnVmZmVyVG9TdHJpbmcoYnVmZmVyKSB7XG4gICAgLy8gYmFzZTY0LWFycmF5YnVmZmVyXG4gICAgdmFyIGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoYnVmZmVyKTtcbiAgICB2YXIgYmFzZTY0U3RyaW5nID0gJyc7XG4gICAgdmFyIGk7XG5cbiAgICBmb3IgKGkgPSAwOyBpIDwgYnl0ZXMubGVuZ3RoOyBpICs9IDMpIHtcbiAgICAgICAgLypqc2xpbnQgYml0d2lzZTogdHJ1ZSAqL1xuICAgICAgICBiYXNlNjRTdHJpbmcgKz0gQkFTRV9DSEFSU1tieXRlc1tpXSA+PiAyXTtcbiAgICAgICAgYmFzZTY0U3RyaW5nICs9IEJBU0VfQ0hBUlNbKGJ5dGVzW2ldICYgMykgPDwgNCB8IGJ5dGVzW2kgKyAxXSA+PiA0XTtcbiAgICAgICAgYmFzZTY0U3RyaW5nICs9IEJBU0VfQ0hBUlNbKGJ5dGVzW2kgKyAxXSAmIDE1KSA8PCAyIHwgYnl0ZXNbaSArIDJdID4+IDZdO1xuICAgICAgICBiYXNlNjRTdHJpbmcgKz0gQkFTRV9DSEFSU1tieXRlc1tpICsgMl0gJiA2M107XG4gICAgfVxuXG4gICAgaWYgKGJ5dGVzLmxlbmd0aCAlIDMgPT09IDIpIHtcbiAgICAgICAgYmFzZTY0U3RyaW5nID0gYmFzZTY0U3RyaW5nLnN1YnN0cmluZygwLCBiYXNlNjRTdHJpbmcubGVuZ3RoIC0gMSkgKyAnPSc7XG4gICAgfSBlbHNlIGlmIChieXRlcy5sZW5ndGggJSAzID09PSAxKSB7XG4gICAgICAgIGJhc2U2NFN0cmluZyA9IGJhc2U2NFN0cmluZy5zdWJzdHJpbmcoMCwgYmFzZTY0U3RyaW5nLmxlbmd0aCAtIDIpICsgJz09JztcbiAgICB9XG5cbiAgICByZXR1cm4gYmFzZTY0U3RyaW5nO1xufVxuXG4vLyBTZXJpYWxpemUgYSB2YWx1ZSwgYWZ0ZXJ3YXJkcyBleGVjdXRpbmcgYSBjYWxsYmFjayAod2hpY2ggdXN1YWxseVxuLy8gaW5zdHJ1Y3RzIHRoZSBgc2V0SXRlbSgpYCBjYWxsYmFjay9wcm9taXNlIHRvIGJlIGV4ZWN1dGVkKS4gVGhpcyBpcyBob3dcbi8vIHdlIHN0b3JlIGJpbmFyeSBkYXRhIHdpdGggbG9jYWxTdG9yYWdlLlxuZnVuY3Rpb24gc2VyaWFsaXplKHZhbHVlLCBjYWxsYmFjaykge1xuICAgIHZhciB2YWx1ZVR5cGUgPSAnJztcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgdmFsdWVUeXBlID0gdG9TdHJpbmckMS5jYWxsKHZhbHVlKTtcbiAgICB9XG5cbiAgICAvLyBDYW5ub3QgdXNlIGB2YWx1ZSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyYCBvciBzdWNoIGhlcmUsIGFzIHRoZXNlXG4gICAgLy8gY2hlY2tzIGZhaWwgd2hlbiBydW5uaW5nIHRoZSB0ZXN0cyB1c2luZyBjYXNwZXIuanMuLi5cbiAgICAvL1xuICAgIC8vIFRPRE86IFNlZSB3aHkgdGhvc2UgdGVzdHMgZmFpbCBhbmQgdXNlIGEgYmV0dGVyIHNvbHV0aW9uLlxuICAgIGlmICh2YWx1ZSAmJiAodmFsdWVUeXBlID09PSAnW29iamVjdCBBcnJheUJ1ZmZlcl0nIHx8IHZhbHVlLmJ1ZmZlciAmJiB0b1N0cmluZyQxLmNhbGwodmFsdWUuYnVmZmVyKSA9PT0gJ1tvYmplY3QgQXJyYXlCdWZmZXJdJykpIHtcbiAgICAgICAgLy8gQ29udmVydCBiaW5hcnkgYXJyYXlzIHRvIGEgc3RyaW5nIGFuZCBwcmVmaXggdGhlIHN0cmluZyB3aXRoXG4gICAgICAgIC8vIGEgc3BlY2lhbCBtYXJrZXIuXG4gICAgICAgIHZhciBidWZmZXI7XG4gICAgICAgIHZhciBtYXJrZXIgPSBTRVJJQUxJWkVEX01BUktFUjtcblxuICAgICAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikge1xuICAgICAgICAgICAgYnVmZmVyID0gdmFsdWU7XG4gICAgICAgICAgICBtYXJrZXIgKz0gVFlQRV9BUlJBWUJVRkZFUjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGJ1ZmZlciA9IHZhbHVlLmJ1ZmZlcjtcblxuICAgICAgICAgICAgaWYgKHZhbHVlVHlwZSA9PT0gJ1tvYmplY3QgSW50OEFycmF5XScpIHtcbiAgICAgICAgICAgICAgICBtYXJrZXIgKz0gVFlQRV9JTlQ4QVJSQVk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHZhbHVlVHlwZSA9PT0gJ1tvYmplY3QgVWludDhBcnJheV0nKSB7XG4gICAgICAgICAgICAgICAgbWFya2VyICs9IFRZUEVfVUlOVDhBUlJBWTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodmFsdWVUeXBlID09PSAnW29iamVjdCBVaW50OENsYW1wZWRBcnJheV0nKSB7XG4gICAgICAgICAgICAgICAgbWFya2VyICs9IFRZUEVfVUlOVDhDTEFNUEVEQVJSQVk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHZhbHVlVHlwZSA9PT0gJ1tvYmplY3QgSW50MTZBcnJheV0nKSB7XG4gICAgICAgICAgICAgICAgbWFya2VyICs9IFRZUEVfSU5UMTZBUlJBWTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodmFsdWVUeXBlID09PSAnW29iamVjdCBVaW50MTZBcnJheV0nKSB7XG4gICAgICAgICAgICAgICAgbWFya2VyICs9IFRZUEVfVUlOVDE2QVJSQVk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHZhbHVlVHlwZSA9PT0gJ1tvYmplY3QgSW50MzJBcnJheV0nKSB7XG4gICAgICAgICAgICAgICAgbWFya2VyICs9IFRZUEVfSU5UMzJBUlJBWTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodmFsdWVUeXBlID09PSAnW29iamVjdCBVaW50MzJBcnJheV0nKSB7XG4gICAgICAgICAgICAgICAgbWFya2VyICs9IFRZUEVfVUlOVDMyQVJSQVk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHZhbHVlVHlwZSA9PT0gJ1tvYmplY3QgRmxvYXQzMkFycmF5XScpIHtcbiAgICAgICAgICAgICAgICBtYXJrZXIgKz0gVFlQRV9GTE9BVDMyQVJSQVk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHZhbHVlVHlwZSA9PT0gJ1tvYmplY3QgRmxvYXQ2NEFycmF5XScpIHtcbiAgICAgICAgICAgICAgICBtYXJrZXIgKz0gVFlQRV9GTE9BVDY0QVJSQVk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrKG5ldyBFcnJvcignRmFpbGVkIHRvIGdldCB0eXBlIGZvciBCaW5hcnlBcnJheScpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNhbGxiYWNrKG1hcmtlciArIGJ1ZmZlclRvU3RyaW5nKGJ1ZmZlcikpO1xuICAgIH0gZWxzZSBpZiAodmFsdWVUeXBlID09PSAnW29iamVjdCBCbG9iXScpIHtcbiAgICAgICAgLy8gQ29udmVyIHRoZSBibG9iIHRvIGEgYmluYXJ5QXJyYXkgYW5kIHRoZW4gdG8gYSBzdHJpbmcuXG4gICAgICAgIHZhciBmaWxlUmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcblxuICAgICAgICBmaWxlUmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIC8vIEJhY2t3YXJkcy1jb21wYXRpYmxlIHByZWZpeCBmb3IgdGhlIGJsb2IgdHlwZS5cbiAgICAgICAgICAgIHZhciBzdHIgPSBCTE9CX1RZUEVfUFJFRklYICsgdmFsdWUudHlwZSArICd+JyArIGJ1ZmZlclRvU3RyaW5nKHRoaXMucmVzdWx0KTtcblxuICAgICAgICAgICAgY2FsbGJhY2soU0VSSUFMSVpFRF9NQVJLRVIgKyBUWVBFX0JMT0IgKyBzdHIpO1xuICAgICAgICB9O1xuXG4gICAgICAgIGZpbGVSZWFkZXIucmVhZEFzQXJyYXlCdWZmZXIodmFsdWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjYWxsYmFjayhKU09OLnN0cmluZ2lmeSh2YWx1ZSkpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiQ291bGRuJ3QgY29udmVydCB2YWx1ZSBpbnRvIGEgSlNPTiBzdHJpbmc6IFwiLCB2YWx1ZSk7XG5cbiAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIGUpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4vLyBEZXNlcmlhbGl6ZSBkYXRhIHdlJ3ZlIGluc2VydGVkIGludG8gYSB2YWx1ZSBjb2x1bW4vZmllbGQuIFdlIHBsYWNlXG4vLyBzcGVjaWFsIG1hcmtlcnMgaW50byBvdXIgc3RyaW5ncyB0byBtYXJrIHRoZW0gYXMgZW5jb2RlZDsgdGhpcyBpc24ndFxuLy8gYXMgbmljZSBhcyBhIG1ldGEgZmllbGQsIGJ1dCBpdCdzIHRoZSBvbmx5IHNhbmUgdGhpbmcgd2UgY2FuIGRvIHdoaWxzdFxuLy8ga2VlcGluZyBsb2NhbFN0b3JhZ2Ugc3VwcG9ydCBpbnRhY3QuXG4vL1xuLy8gT2Z0ZW50aW1lcyB0aGlzIHdpbGwganVzdCBkZXNlcmlhbGl6ZSBKU09OIGNvbnRlbnQsIGJ1dCBpZiB3ZSBoYXZlIGFcbi8vIHNwZWNpYWwgbWFya2VyIChTRVJJQUxJWkVEX01BUktFUiwgZGVmaW5lZCBhYm92ZSksIHdlIHdpbGwgZXh0cmFjdFxuLy8gc29tZSBraW5kIG9mIGFycmF5YnVmZmVyL2JpbmFyeSBkYXRhL3R5cGVkIGFycmF5IG91dCBvZiB0aGUgc3RyaW5nLlxuZnVuY3Rpb24gZGVzZXJpYWxpemUodmFsdWUpIHtcbiAgICAvLyBJZiB3ZSBoYXZlbid0IG1hcmtlZCB0aGlzIHN0cmluZyBhcyBiZWluZyBzcGVjaWFsbHkgc2VyaWFsaXplZCAoaS5lLlxuICAgIC8vIHNvbWV0aGluZyBvdGhlciB0aGFuIHNlcmlhbGl6ZWQgSlNPTiksIHdlIGNhbiBqdXN0IHJldHVybiBpdCBhbmQgYmVcbiAgICAvLyBkb25lIHdpdGggaXQuXG4gICAgaWYgKHZhbHVlLnN1YnN0cmluZygwLCBTRVJJQUxJWkVEX01BUktFUl9MRU5HVEgpICE9PSBTRVJJQUxJWkVEX01BUktFUikge1xuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSk7XG4gICAgfVxuXG4gICAgLy8gVGhlIGZvbGxvd2luZyBjb2RlIGRlYWxzIHdpdGggZGVzZXJpYWxpemluZyBzb21lIGtpbmQgb2YgQmxvYiBvclxuICAgIC8vIFR5cGVkQXJyYXkuIEZpcnN0IHdlIHNlcGFyYXRlIG91dCB0aGUgdHlwZSBvZiBkYXRhIHdlJ3JlIGRlYWxpbmdcbiAgICAvLyB3aXRoIGZyb20gdGhlIGRhdGEgaXRzZWxmLlxuICAgIHZhciBzZXJpYWxpemVkU3RyaW5nID0gdmFsdWUuc3Vic3RyaW5nKFRZUEVfU0VSSUFMSVpFRF9NQVJLRVJfTEVOR1RIKTtcbiAgICB2YXIgdHlwZSA9IHZhbHVlLnN1YnN0cmluZyhTRVJJQUxJWkVEX01BUktFUl9MRU5HVEgsIFRZUEVfU0VSSUFMSVpFRF9NQVJLRVJfTEVOR1RIKTtcblxuICAgIHZhciBibG9iVHlwZTtcbiAgICAvLyBCYWNrd2FyZHMtY29tcGF0aWJsZSBibG9iIHR5cGUgc2VyaWFsaXphdGlvbiBzdHJhdGVneS5cbiAgICAvLyBEQnMgY3JlYXRlZCB3aXRoIG9sZGVyIHZlcnNpb25zIG9mIGxvY2FsRm9yYWdlIHdpbGwgc2ltcGx5IG5vdCBoYXZlIHRoZSBibG9iIHR5cGUuXG4gICAgaWYgKHR5cGUgPT09IFRZUEVfQkxPQiAmJiBCTE9CX1RZUEVfUFJFRklYX1JFR0VYLnRlc3Qoc2VyaWFsaXplZFN0cmluZykpIHtcbiAgICAgICAgdmFyIG1hdGNoZXIgPSBzZXJpYWxpemVkU3RyaW5nLm1hdGNoKEJMT0JfVFlQRV9QUkVGSVhfUkVHRVgpO1xuICAgICAgICBibG9iVHlwZSA9IG1hdGNoZXJbMV07XG4gICAgICAgIHNlcmlhbGl6ZWRTdHJpbmcgPSBzZXJpYWxpemVkU3RyaW5nLnN1YnN0cmluZyhtYXRjaGVyWzBdLmxlbmd0aCk7XG4gICAgfVxuICAgIHZhciBidWZmZXIgPSBzdHJpbmdUb0J1ZmZlcihzZXJpYWxpemVkU3RyaW5nKTtcblxuICAgIC8vIFJldHVybiB0aGUgcmlnaHQgdHlwZSBiYXNlZCBvbiB0aGUgY29kZS90eXBlIHNldCBkdXJpbmdcbiAgICAvLyBzZXJpYWxpemF0aW9uLlxuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgICBjYXNlIFRZUEVfQVJSQVlCVUZGRVI6XG4gICAgICAgICAgICByZXR1cm4gYnVmZmVyO1xuICAgICAgICBjYXNlIFRZUEVfQkxPQjpcbiAgICAgICAgICAgIHJldHVybiBjcmVhdGVCbG9iKFtidWZmZXJdLCB7IHR5cGU6IGJsb2JUeXBlIH0pO1xuICAgICAgICBjYXNlIFRZUEVfSU5UOEFSUkFZOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBJbnQ4QXJyYXkoYnVmZmVyKTtcbiAgICAgICAgY2FzZSBUWVBFX1VJTlQ4QVJSQVk6XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkoYnVmZmVyKTtcbiAgICAgICAgY2FzZSBUWVBFX1VJTlQ4Q0xBTVBFREFSUkFZOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBVaW50OENsYW1wZWRBcnJheShidWZmZXIpO1xuICAgICAgICBjYXNlIFRZUEVfSU5UMTZBUlJBWTpcbiAgICAgICAgICAgIHJldHVybiBuZXcgSW50MTZBcnJheShidWZmZXIpO1xuICAgICAgICBjYXNlIFRZUEVfVUlOVDE2QVJSQVk6XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVpbnQxNkFycmF5KGJ1ZmZlcik7XG4gICAgICAgIGNhc2UgVFlQRV9JTlQzMkFSUkFZOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBJbnQzMkFycmF5KGJ1ZmZlcik7XG4gICAgICAgIGNhc2UgVFlQRV9VSU5UMzJBUlJBWTpcbiAgICAgICAgICAgIHJldHVybiBuZXcgVWludDMyQXJyYXkoYnVmZmVyKTtcbiAgICAgICAgY2FzZSBUWVBFX0ZMT0FUMzJBUlJBWTpcbiAgICAgICAgICAgIHJldHVybiBuZXcgRmxvYXQzMkFycmF5KGJ1ZmZlcik7XG4gICAgICAgIGNhc2UgVFlQRV9GTE9BVDY0QVJSQVk6XG4gICAgICAgICAgICByZXR1cm4gbmV3IEZsb2F0NjRBcnJheShidWZmZXIpO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmtvd24gdHlwZTogJyArIHR5cGUpO1xuICAgIH1cbn1cblxudmFyIGxvY2FsZm9yYWdlU2VyaWFsaXplciA9IHtcbiAgICBzZXJpYWxpemU6IHNlcmlhbGl6ZSxcbiAgICBkZXNlcmlhbGl6ZTogZGVzZXJpYWxpemUsXG4gICAgc3RyaW5nVG9CdWZmZXI6IHN0cmluZ1RvQnVmZmVyLFxuICAgIGJ1ZmZlclRvU3RyaW5nOiBidWZmZXJUb1N0cmluZ1xufTtcblxuLypcbiAqIEluY2x1ZGVzIGNvZGUgZnJvbTpcbiAqXG4gKiBiYXNlNjQtYXJyYXlidWZmZXJcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9uaWtsYXN2aC9iYXNlNjQtYXJyYXlidWZmZXJcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIDIwMTIgTmlrbGFzIHZvbiBIZXJ0emVuXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTUlUIGxpY2Vuc2UuXG4gKi9cblxuZnVuY3Rpb24gY3JlYXRlRGJUYWJsZSh0LCBkYkluZm8sIGNhbGxiYWNrLCBlcnJvckNhbGxiYWNrKSB7XG4gICAgdC5leGVjdXRlU3FsKCdDUkVBVEUgVEFCTEUgSUYgTk9UIEVYSVNUUyAnICsgZGJJbmZvLnN0b3JlTmFtZSArICcgJyArICcoaWQgSU5URUdFUiBQUklNQVJZIEtFWSwga2V5IHVuaXF1ZSwgdmFsdWUpJywgW10sIGNhbGxiYWNrLCBlcnJvckNhbGxiYWNrKTtcbn1cblxuLy8gT3BlbiB0aGUgV2ViU1FMIGRhdGFiYXNlIChhdXRvbWF0aWNhbGx5IGNyZWF0ZXMgb25lIGlmIG9uZSBkaWRuJ3Rcbi8vIHByZXZpb3VzbHkgZXhpc3QpLCB1c2luZyBhbnkgb3B0aW9ucyBzZXQgaW4gdGhlIGNvbmZpZy5cbmZ1bmN0aW9uIF9pbml0U3RvcmFnZSQxKG9wdGlvbnMpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIGRiSW5mbyA9IHtcbiAgICAgICAgZGI6IG51bGxcbiAgICB9O1xuXG4gICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgICAgZm9yICh2YXIgaSBpbiBvcHRpb25zKSB7XG4gICAgICAgICAgICBkYkluZm9baV0gPSB0eXBlb2Ygb3B0aW9uc1tpXSAhPT0gJ3N0cmluZycgPyBvcHRpb25zW2ldLnRvU3RyaW5nKCkgOiBvcHRpb25zW2ldO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgdmFyIGRiSW5mb1Byb21pc2UgPSBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgLy8gT3BlbiB0aGUgZGF0YWJhc2U7IHRoZSBvcGVuRGF0YWJhc2UgQVBJIHdpbGwgYXV0b21hdGljYWxseVxuICAgICAgICAvLyBjcmVhdGUgaXQgZm9yIHVzIGlmIGl0IGRvZXNuJ3QgZXhpc3QuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBkYkluZm8uZGIgPSBvcGVuRGF0YWJhc2UoZGJJbmZvLm5hbWUsIFN0cmluZyhkYkluZm8udmVyc2lvbiksIGRiSW5mby5kZXNjcmlwdGlvbiwgZGJJbmZvLnNpemUpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICByZXR1cm4gcmVqZWN0KGUpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQ3JlYXRlIG91ciBrZXkvdmFsdWUgdGFibGUgaWYgaXQgZG9lc24ndCBleGlzdC5cbiAgICAgICAgZGJJbmZvLmRiLnRyYW5zYWN0aW9uKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgICAgICBjcmVhdGVEYlRhYmxlKHQsIGRiSW5mbywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHNlbGYuX2RiSW5mbyA9IGRiSW5mbztcbiAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB9LCBmdW5jdGlvbiAodCwgZXJyb3IpIHtcbiAgICAgICAgICAgICAgICByZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sIHJlamVjdCk7XG4gICAgfSk7XG5cbiAgICBkYkluZm8uc2VyaWFsaXplciA9IGxvY2FsZm9yYWdlU2VyaWFsaXplcjtcbiAgICByZXR1cm4gZGJJbmZvUHJvbWlzZTtcbn1cblxuZnVuY3Rpb24gdHJ5RXhlY3V0ZVNxbCh0LCBkYkluZm8sIHNxbFN0YXRlbWVudCwgYXJncywgY2FsbGJhY2ssIGVycm9yQ2FsbGJhY2spIHtcbiAgICB0LmV4ZWN1dGVTcWwoc3FsU3RhdGVtZW50LCBhcmdzLCBjYWxsYmFjaywgZnVuY3Rpb24gKHQsIGVycm9yKSB7XG4gICAgICAgIGlmIChlcnJvci5jb2RlID09PSBlcnJvci5TWU5UQVhfRVJSKSB7XG4gICAgICAgICAgICB0LmV4ZWN1dGVTcWwoJ1NFTEVDVCBuYW1lIEZST00gc3FsaXRlX21hc3RlciAnICsgXCJXSEVSRSB0eXBlPSd0YWJsZScgQU5EIG5hbWUgPSA/XCIsIFtkYkluZm8uc3RvcmVOYW1lXSwgZnVuY3Rpb24gKHQsIHJlc3VsdHMpIHtcbiAgICAgICAgICAgICAgICBpZiAoIXJlc3VsdHMucm93cy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gaWYgdGhlIHRhYmxlIGlzIG1pc3NpbmcgKHdhcyBkZWxldGVkKVxuICAgICAgICAgICAgICAgICAgICAvLyByZS1jcmVhdGUgaXQgdGFibGUgYW5kIHJldHJ5XG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZURiVGFibGUodCwgZGJJbmZvLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0LmV4ZWN1dGVTcWwoc3FsU3RhdGVtZW50LCBhcmdzLCBjYWxsYmFjaywgZXJyb3JDYWxsYmFjayk7XG4gICAgICAgICAgICAgICAgICAgIH0sIGVycm9yQ2FsbGJhY2spO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGVycm9yQ2FsbGJhY2sodCwgZXJyb3IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sIGVycm9yQ2FsbGJhY2spO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZXJyb3JDYWxsYmFjayh0LCBlcnJvcik7XG4gICAgICAgIH1cbiAgICB9LCBlcnJvckNhbGxiYWNrKTtcbn1cblxuZnVuY3Rpb24gZ2V0SXRlbSQxKGtleSwgY2FsbGJhY2spIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICBrZXkgPSBub3JtYWxpemVLZXkoa2V5KTtcblxuICAgIHZhciBwcm9taXNlID0gbmV3IFByb21pc2UkMShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIHNlbGYucmVhZHkoKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBkYkluZm8gPSBzZWxmLl9kYkluZm87XG4gICAgICAgICAgICBkYkluZm8uZGIudHJhbnNhY3Rpb24oZnVuY3Rpb24gKHQpIHtcbiAgICAgICAgICAgICAgICB0cnlFeGVjdXRlU3FsKHQsIGRiSW5mbywgJ1NFTEVDVCAqIEZST00gJyArIGRiSW5mby5zdG9yZU5hbWUgKyAnIFdIRVJFIGtleSA9ID8gTElNSVQgMScsIFtrZXldLCBmdW5jdGlvbiAodCwgcmVzdWx0cykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gcmVzdWx0cy5yb3dzLmxlbmd0aCA/IHJlc3VsdHMucm93cy5pdGVtKDApLnZhbHVlIDogbnVsbDtcblxuICAgICAgICAgICAgICAgICAgICAvLyBDaGVjayB0byBzZWUgaWYgdGhpcyBpcyBzZXJpYWxpemVkIGNvbnRlbnQgd2UgbmVlZCB0b1xuICAgICAgICAgICAgICAgICAgICAvLyB1bnBhY2suXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IGRiSW5mby5zZXJpYWxpemVyLmRlc2VyaWFsaXplKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKHQsIGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSlbXCJjYXRjaFwiXShyZWplY3QpO1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuZnVuY3Rpb24gaXRlcmF0ZSQxKGl0ZXJhdG9yLCBjYWxsYmFjaykge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIHZhciBwcm9taXNlID0gbmV3IFByb21pc2UkMShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIHNlbGYucmVhZHkoKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBkYkluZm8gPSBzZWxmLl9kYkluZm87XG5cbiAgICAgICAgICAgIGRiSW5mby5kYi50cmFuc2FjdGlvbihmdW5jdGlvbiAodCkge1xuICAgICAgICAgICAgICAgIHRyeUV4ZWN1dGVTcWwodCwgZGJJbmZvLCAnU0VMRUNUICogRlJPTSAnICsgZGJJbmZvLnN0b3JlTmFtZSwgW10sIGZ1bmN0aW9uICh0LCByZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciByb3dzID0gcmVzdWx0cy5yb3dzO1xuICAgICAgICAgICAgICAgICAgICB2YXIgbGVuZ3RoID0gcm93cy5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSByb3dzLml0ZW0oaSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gaXRlbS52YWx1ZTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ2hlY2sgdG8gc2VlIGlmIHRoaXMgaXMgc2VyaWFsaXplZCBjb250ZW50XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB3ZSBuZWVkIHRvIHVucGFjay5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBkYkluZm8uc2VyaWFsaXplci5kZXNlcmlhbGl6ZShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBpdGVyYXRvcihyZXN1bHQsIGl0ZW0ua2V5LCBpICsgMSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZvaWQoMCkgcHJldmVudHMgcHJvYmxlbXMgd2l0aCByZWRlZmluaXRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIG9mIGB1bmRlZmluZWRgLlxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCAhPT0gdm9pZCAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAodCwgZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KVtcImNhdGNoXCJdKHJlamVjdCk7XG4gICAgfSk7XG5cbiAgICBleGVjdXRlQ2FsbGJhY2socHJvbWlzZSwgY2FsbGJhY2spO1xuICAgIHJldHVybiBwcm9taXNlO1xufVxuXG5mdW5jdGlvbiBfc2V0SXRlbShrZXksIHZhbHVlLCBjYWxsYmFjaywgcmV0cmllc0xlZnQpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICBrZXkgPSBub3JtYWxpemVLZXkoa2V5KTtcblxuICAgIHZhciBwcm9taXNlID0gbmV3IFByb21pc2UkMShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIHNlbGYucmVhZHkoKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIC8vIFRoZSBsb2NhbFN0b3JhZ2UgQVBJIGRvZXNuJ3QgcmV0dXJuIHVuZGVmaW5lZCB2YWx1ZXMgaW4gYW5cbiAgICAgICAgICAgIC8vIFwiZXhwZWN0ZWRcIiB3YXksIHNvIHVuZGVmaW5lZCBpcyBhbHdheXMgY2FzdCB0byBudWxsIGluIGFsbFxuICAgICAgICAgICAgLy8gZHJpdmVycy4gU2VlOiBodHRwczovL2dpdGh1Yi5jb20vbW96aWxsYS9sb2NhbEZvcmFnZS9wdWxsLzQyXG4gICAgICAgICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIHZhbHVlID0gbnVsbDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gU2F2ZSB0aGUgb3JpZ2luYWwgdmFsdWUgdG8gcGFzcyB0byB0aGUgY2FsbGJhY2suXG4gICAgICAgICAgICB2YXIgb3JpZ2luYWxWYWx1ZSA9IHZhbHVlO1xuXG4gICAgICAgICAgICB2YXIgZGJJbmZvID0gc2VsZi5fZGJJbmZvO1xuICAgICAgICAgICAgZGJJbmZvLnNlcmlhbGl6ZXIuc2VyaWFsaXplKHZhbHVlLCBmdW5jdGlvbiAodmFsdWUsIGVycm9yKSB7XG4gICAgICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZGJJbmZvLmRiLnRyYW5zYWN0aW9uKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnlFeGVjdXRlU3FsKHQsIGRiSW5mbywgJ0lOU0VSVCBPUiBSRVBMQUNFIElOVE8gJyArIGRiSW5mby5zdG9yZU5hbWUgKyAnICcgKyAnKGtleSwgdmFsdWUpIFZBTFVFUyAoPywgPyknLCBba2V5LCB2YWx1ZV0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKG9yaWdpbmFsVmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKHQsIGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAoc3FsRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRoZSB0cmFuc2FjdGlvbiBmYWlsZWQ7IGNoZWNrXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0byBzZWUgaWYgaXQncyBhIHF1b3RhIGVycm9yLlxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNxbEVycm9yLmNvZGUgPT09IHNxbEVycm9yLlFVT1RBX0VSUikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFdlIHJlamVjdCB0aGUgY2FsbGJhY2sgb3V0cmlnaHQgZm9yIG5vdywgYnV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaXQncyB3b3J0aCB0cnlpbmcgdG8gcmUtcnVuIHRoZSB0cmFuc2FjdGlvbi5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBFdmVuIGlmIHRoZSB1c2VyIGFjY2VwdHMgdGhlIHByb21wdCB0byB1c2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBtb3JlIHN0b3JhZ2Ugb24gU2FmYXJpLCB0aGlzIGVycm9yIHdpbGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBiZSBjYWxsZWQuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBUcnkgdG8gcmUtcnVuIHRoZSB0cmFuc2FjdGlvbi5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmV0cmllc0xlZnQgPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoX3NldEl0ZW0uYXBwbHkoc2VsZiwgW2tleSwgb3JpZ2luYWxWYWx1ZSwgY2FsbGJhY2ssIHJldHJpZXNMZWZ0IC0gMV0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWplY3Qoc3FsRXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSlbXCJjYXRjaFwiXShyZWplY3QpO1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuZnVuY3Rpb24gc2V0SXRlbSQxKGtleSwgdmFsdWUsIGNhbGxiYWNrKSB7XG4gICAgcmV0dXJuIF9zZXRJdGVtLmFwcGx5KHRoaXMsIFtrZXksIHZhbHVlLCBjYWxsYmFjaywgMV0pO1xufVxuXG5mdW5jdGlvbiByZW1vdmVJdGVtJDEoa2V5LCBjYWxsYmFjaykge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIGtleSA9IG5vcm1hbGl6ZUtleShrZXkpO1xuXG4gICAgdmFyIHByb21pc2UgPSBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgc2VsZi5yZWFkeSgpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGRiSW5mbyA9IHNlbGYuX2RiSW5mbztcbiAgICAgICAgICAgIGRiSW5mby5kYi50cmFuc2FjdGlvbihmdW5jdGlvbiAodCkge1xuICAgICAgICAgICAgICAgIHRyeUV4ZWN1dGVTcWwodCwgZGJJbmZvLCAnREVMRVRFIEZST00gJyArIGRiSW5mby5zdG9yZU5hbWUgKyAnIFdIRVJFIGtleSA9ID8nLCBba2V5XSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKHQsIGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSlbXCJjYXRjaFwiXShyZWplY3QpO1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuLy8gRGVsZXRlcyBldmVyeSBpdGVtIGluIHRoZSB0YWJsZS5cbi8vIFRPRE86IEZpbmQgb3V0IGlmIHRoaXMgcmVzZXRzIHRoZSBBVVRPX0lOQ1JFTUVOVCBudW1iZXIuXG5mdW5jdGlvbiBjbGVhciQxKGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgdmFyIHByb21pc2UgPSBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgc2VsZi5yZWFkeSgpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGRiSW5mbyA9IHNlbGYuX2RiSW5mbztcbiAgICAgICAgICAgIGRiSW5mby5kYi50cmFuc2FjdGlvbihmdW5jdGlvbiAodCkge1xuICAgICAgICAgICAgICAgIHRyeUV4ZWN1dGVTcWwodCwgZGJJbmZvLCAnREVMRVRFIEZST00gJyArIGRiSW5mby5zdG9yZU5hbWUsIFtdLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAodCwgZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KVtcImNhdGNoXCJdKHJlamVjdCk7XG4gICAgfSk7XG5cbiAgICBleGVjdXRlQ2FsbGJhY2socHJvbWlzZSwgY2FsbGJhY2spO1xuICAgIHJldHVybiBwcm9taXNlO1xufVxuXG4vLyBEb2VzIGEgc2ltcGxlIGBDT1VOVChrZXkpYCB0byBnZXQgdGhlIG51bWJlciBvZiBpdGVtcyBzdG9yZWQgaW5cbi8vIGxvY2FsRm9yYWdlLlxuZnVuY3Rpb24gbGVuZ3RoJDEoY2FsbGJhY2spIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICB2YXIgcHJvbWlzZSA9IG5ldyBQcm9taXNlJDEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgZGJJbmZvID0gc2VsZi5fZGJJbmZvO1xuICAgICAgICAgICAgZGJJbmZvLmRiLnRyYW5zYWN0aW9uKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgICAgICAgICAgLy8gQWhoaCwgU1FMIG1ha2VzIHRoaXMgb25lIHNvb29vb28gZWFzeS5cbiAgICAgICAgICAgICAgICB0cnlFeGVjdXRlU3FsKHQsIGRiSW5mbywgJ1NFTEVDVCBDT1VOVChrZXkpIGFzIGMgRlJPTSAnICsgZGJJbmZvLnN0b3JlTmFtZSwgW10sIGZ1bmN0aW9uICh0LCByZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSByZXN1bHRzLnJvd3MuaXRlbSgwKS5jO1xuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKHQsIGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSlbXCJjYXRjaFwiXShyZWplY3QpO1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuLy8gUmV0dXJuIHRoZSBrZXkgbG9jYXRlZCBhdCBrZXkgaW5kZXggWDsgZXNzZW50aWFsbHkgZ2V0cyB0aGUga2V5IGZyb20gYVxuLy8gYFdIRVJFIGlkID0gP2AuIFRoaXMgaXMgdGhlIG1vc3QgZWZmaWNpZW50IHdheSBJIGNhbiB0aGluayB0byBpbXBsZW1lbnRcbi8vIHRoaXMgcmFyZWx5LXVzZWQgKGluIG15IGV4cGVyaWVuY2UpIHBhcnQgb2YgdGhlIEFQSSwgYnV0IGl0IGNhbiBzZWVtXG4vLyBpbmNvbnNpc3RlbnQsIGJlY2F1c2Ugd2UgZG8gYElOU0VSVCBPUiBSRVBMQUNFIElOVE9gIG9uIGBzZXRJdGVtKClgLCBzb1xuLy8gdGhlIElEIG9mIGVhY2gga2V5IHdpbGwgY2hhbmdlIGV2ZXJ5IHRpbWUgaXQncyB1cGRhdGVkLiBQZXJoYXBzIGEgc3RvcmVkXG4vLyBwcm9jZWR1cmUgZm9yIHRoZSBgc2V0SXRlbSgpYCBTUUwgd291bGQgc29sdmUgdGhpcyBwcm9ibGVtP1xuLy8gVE9ETzogRG9uJ3QgY2hhbmdlIElEIG9uIGBzZXRJdGVtKClgLlxuZnVuY3Rpb24ga2V5JDEobiwgY2FsbGJhY2spIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICB2YXIgcHJvbWlzZSA9IG5ldyBQcm9taXNlJDEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgZGJJbmZvID0gc2VsZi5fZGJJbmZvO1xuICAgICAgICAgICAgZGJJbmZvLmRiLnRyYW5zYWN0aW9uKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgICAgICAgICAgdHJ5RXhlY3V0ZVNxbCh0LCBkYkluZm8sICdTRUxFQ1Qga2V5IEZST00gJyArIGRiSW5mby5zdG9yZU5hbWUgKyAnIFdIRVJFIGlkID0gPyBMSU1JVCAxJywgW24gKyAxXSwgZnVuY3Rpb24gKHQsIHJlc3VsdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IHJlc3VsdHMucm93cy5sZW5ndGggPyByZXN1bHRzLnJvd3MuaXRlbSgwKS5rZXkgOiBudWxsO1xuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKHQsIGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSlbXCJjYXRjaFwiXShyZWplY3QpO1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuZnVuY3Rpb24ga2V5cyQxKGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgdmFyIHByb21pc2UgPSBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgc2VsZi5yZWFkeSgpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGRiSW5mbyA9IHNlbGYuX2RiSW5mbztcbiAgICAgICAgICAgIGRiSW5mby5kYi50cmFuc2FjdGlvbihmdW5jdGlvbiAodCkge1xuICAgICAgICAgICAgICAgIHRyeUV4ZWN1dGVTcWwodCwgZGJJbmZvLCAnU0VMRUNUIGtleSBGUk9NICcgKyBkYkluZm8uc3RvcmVOYW1lLCBbXSwgZnVuY3Rpb24gKHQsIHJlc3VsdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGtleXMgPSBbXTtcblxuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHJlc3VsdHMucm93cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5cy5wdXNoKHJlc3VsdHMucm93cy5pdGVtKGkpLmtleSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKGtleXMpO1xuICAgICAgICAgICAgICAgIH0sIGZ1bmN0aW9uICh0LCBlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICByZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pW1wiY2F0Y2hcIl0ocmVqZWN0KTtcbiAgICB9KTtcblxuICAgIGV4ZWN1dGVDYWxsYmFjayhwcm9taXNlLCBjYWxsYmFjayk7XG4gICAgcmV0dXJuIHByb21pc2U7XG59XG5cbi8vIGh0dHBzOi8vd3d3LnczLm9yZy9UUi93ZWJkYXRhYmFzZS8jZGF0YWJhc2VzXG4vLyA+IFRoZXJlIGlzIG5vIHdheSB0byBlbnVtZXJhdGUgb3IgZGVsZXRlIHRoZSBkYXRhYmFzZXMgYXZhaWxhYmxlIGZvciBhbiBvcmlnaW4gZnJvbSB0aGlzIEFQSS5cbmZ1bmN0aW9uIGdldEFsbFN0b3JlTmFtZXMoZGIpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UkMShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIGRiLnRyYW5zYWN0aW9uKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgICAgICB0LmV4ZWN1dGVTcWwoJ1NFTEVDVCBuYW1lIEZST00gc3FsaXRlX21hc3RlciAnICsgXCJXSEVSRSB0eXBlPSd0YWJsZScgQU5EIG5hbWUgPD4gJ19fV2ViS2l0RGF0YWJhc2VJbmZvVGFibGVfXydcIiwgW10sIGZ1bmN0aW9uICh0LCByZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgdmFyIHN0b3JlTmFtZXMgPSBbXTtcblxuICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcmVzdWx0cy5yb3dzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHN0b3JlTmFtZXMucHVzaChyZXN1bHRzLnJvd3MuaXRlbShpKS5uYW1lKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICByZXNvbHZlKHtcbiAgICAgICAgICAgICAgICAgICAgZGI6IGRiLFxuICAgICAgICAgICAgICAgICAgICBzdG9yZU5hbWVzOiBzdG9yZU5hbWVzXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9LCBmdW5jdGlvbiAodCwgZXJyb3IpIHtcbiAgICAgICAgICAgICAgICByZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sIGZ1bmN0aW9uIChzcWxFcnJvcikge1xuICAgICAgICAgICAgcmVqZWN0KHNxbEVycm9yKTtcbiAgICAgICAgfSk7XG4gICAgfSk7XG59XG5cbmZ1bmN0aW9uIGRyb3BJbnN0YW5jZSQxKG9wdGlvbnMsIGNhbGxiYWNrKSB7XG4gICAgY2FsbGJhY2sgPSBnZXRDYWxsYmFjay5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuXG4gICAgdmFyIGN1cnJlbnRDb25maWcgPSB0aGlzLmNvbmZpZygpO1xuICAgIG9wdGlvbnMgPSB0eXBlb2Ygb3B0aW9ucyAhPT0gJ2Z1bmN0aW9uJyAmJiBvcHRpb25zIHx8IHt9O1xuICAgIGlmICghb3B0aW9ucy5uYW1lKSB7XG4gICAgICAgIG9wdGlvbnMubmFtZSA9IG9wdGlvbnMubmFtZSB8fCBjdXJyZW50Q29uZmlnLm5hbWU7XG4gICAgICAgIG9wdGlvbnMuc3RvcmVOYW1lID0gb3B0aW9ucy5zdG9yZU5hbWUgfHwgY3VycmVudENvbmZpZy5zdG9yZU5hbWU7XG4gICAgfVxuXG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIHZhciBwcm9taXNlO1xuICAgIGlmICghb3B0aW9ucy5uYW1lKSB7XG4gICAgICAgIHByb21pc2UgPSBQcm9taXNlJDEucmVqZWN0KCdJbnZhbGlkIGFyZ3VtZW50cycpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHByb21pc2UgPSBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlKSB7XG4gICAgICAgICAgICB2YXIgZGI7XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5uYW1lID09PSBjdXJyZW50Q29uZmlnLm5hbWUpIHtcbiAgICAgICAgICAgICAgICAvLyB1c2UgdGhlIGRiIHJlZmVyZW5jZSBvZiB0aGUgY3VycmVudCBpbnN0YW5jZVxuICAgICAgICAgICAgICAgIGRiID0gc2VsZi5fZGJJbmZvLmRiO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBkYiA9IG9wZW5EYXRhYmFzZShvcHRpb25zLm5hbWUsICcnLCAnJywgMCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICghb3B0aW9ucy5zdG9yZU5hbWUpIHtcbiAgICAgICAgICAgICAgICAvLyBkcm9wIGFsbCBkYXRhYmFzZSB0YWJsZXNcbiAgICAgICAgICAgICAgICByZXNvbHZlKGdldEFsbFN0b3JlTmFtZXMoZGIpKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSh7XG4gICAgICAgICAgICAgICAgICAgIGRiOiBkYixcbiAgICAgICAgICAgICAgICAgICAgc3RvcmVOYW1lczogW29wdGlvbnMuc3RvcmVOYW1lXVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KS50aGVuKGZ1bmN0aW9uIChvcGVyYXRpb25JbmZvKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UkMShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgb3BlcmF0aW9uSW5mby5kYi50cmFuc2FjdGlvbihmdW5jdGlvbiAodCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBkcm9wVGFibGUoc3RvcmVOYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UkMShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdC5leGVjdXRlU3FsKCdEUk9QIFRBQkxFIElGIEVYSVNUUyAnICsgc3RvcmVOYW1lLCBbXSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKHQsIGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHZhciBvcGVyYXRpb25zID0gW107XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSBvcGVyYXRpb25JbmZvLnN0b3JlTmFtZXMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wZXJhdGlvbnMucHVzaChkcm9wVGFibGUob3BlcmF0aW9uSW5mby5zdG9yZU5hbWVzW2ldKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBQcm9taXNlJDEuYWxsKG9wZXJhdGlvbnMpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICAgICAgICB9KVtcImNhdGNoXCJdKGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoZSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0sIGZ1bmN0aW9uIChzcWxFcnJvcikge1xuICAgICAgICAgICAgICAgICAgICByZWplY3Qoc3FsRXJyb3IpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGV4ZWN1dGVDYWxsYmFjayhwcm9taXNlLCBjYWxsYmFjayk7XG4gICAgcmV0dXJuIHByb21pc2U7XG59XG5cbnZhciB3ZWJTUUxTdG9yYWdlID0ge1xuICAgIF9kcml2ZXI6ICd3ZWJTUUxTdG9yYWdlJyxcbiAgICBfaW5pdFN0b3JhZ2U6IF9pbml0U3RvcmFnZSQxLFxuICAgIF9zdXBwb3J0OiBpc1dlYlNRTFZhbGlkKCksXG4gICAgaXRlcmF0ZTogaXRlcmF0ZSQxLFxuICAgIGdldEl0ZW06IGdldEl0ZW0kMSxcbiAgICBzZXRJdGVtOiBzZXRJdGVtJDEsXG4gICAgcmVtb3ZlSXRlbTogcmVtb3ZlSXRlbSQxLFxuICAgIGNsZWFyOiBjbGVhciQxLFxuICAgIGxlbmd0aDogbGVuZ3RoJDEsXG4gICAga2V5OiBrZXkkMSxcbiAgICBrZXlzOiBrZXlzJDEsXG4gICAgZHJvcEluc3RhbmNlOiBkcm9wSW5zdGFuY2UkMVxufTtcblxuZnVuY3Rpb24gaXNMb2NhbFN0b3JhZ2VWYWxpZCgpIHtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gdHlwZW9mIGxvY2FsU3RvcmFnZSAhPT0gJ3VuZGVmaW5lZCcgJiYgJ3NldEl0ZW0nIGluIGxvY2FsU3RvcmFnZSAmJlxuICAgICAgICAvLyBpbiBJRTggdHlwZW9mIGxvY2FsU3RvcmFnZS5zZXRJdGVtID09PSAnb2JqZWN0J1xuICAgICAgICAhIWxvY2FsU3RvcmFnZS5zZXRJdGVtO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gX2dldEtleVByZWZpeChvcHRpb25zLCBkZWZhdWx0Q29uZmlnKSB7XG4gICAgdmFyIGtleVByZWZpeCA9IG9wdGlvbnMubmFtZSArICcvJztcblxuICAgIGlmIChvcHRpb25zLnN0b3JlTmFtZSAhPT0gZGVmYXVsdENvbmZpZy5zdG9yZU5hbWUpIHtcbiAgICAgICAga2V5UHJlZml4ICs9IG9wdGlvbnMuc3RvcmVOYW1lICsgJy8nO1xuICAgIH1cbiAgICByZXR1cm4ga2V5UHJlZml4O1xufVxuXG4vLyBDaGVjayBpZiBsb2NhbFN0b3JhZ2UgdGhyb3dzIHdoZW4gc2F2aW5nIGFuIGl0ZW1cbmZ1bmN0aW9uIGNoZWNrSWZMb2NhbFN0b3JhZ2VUaHJvd3MoKSB7XG4gICAgdmFyIGxvY2FsU3RvcmFnZVRlc3RLZXkgPSAnX2xvY2FsZm9yYWdlX3N1cHBvcnRfdGVzdCc7XG5cbiAgICB0cnkge1xuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShsb2NhbFN0b3JhZ2VUZXN0S2V5LCB0cnVlKTtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0obG9jYWxTdG9yYWdlVGVzdEtleSk7XG5cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxufVxuXG4vLyBDaGVjayBpZiBsb2NhbFN0b3JhZ2UgaXMgdXNhYmxlIGFuZCBhbGxvd3MgdG8gc2F2ZSBhbiBpdGVtXG4vLyBUaGlzIG1ldGhvZCBjaGVja3MgaWYgbG9jYWxTdG9yYWdlIGlzIHVzYWJsZSBpbiBTYWZhcmkgUHJpdmF0ZSBCcm93c2luZ1xuLy8gbW9kZSwgb3IgaW4gYW55IG90aGVyIGNhc2Ugd2hlcmUgdGhlIGF2YWlsYWJsZSBxdW90YSBmb3IgbG9jYWxTdG9yYWdlXG4vLyBpcyAwIGFuZCB0aGVyZSB3YXNuJ3QgYW55IHNhdmVkIGl0ZW1zIHlldC5cbmZ1bmN0aW9uIF9pc0xvY2FsU3RvcmFnZVVzYWJsZSgpIHtcbiAgICByZXR1cm4gIWNoZWNrSWZMb2NhbFN0b3JhZ2VUaHJvd3MoKSB8fCBsb2NhbFN0b3JhZ2UubGVuZ3RoID4gMDtcbn1cblxuLy8gQ29uZmlnIHRoZSBsb2NhbFN0b3JhZ2UgYmFja2VuZCwgdXNpbmcgb3B0aW9ucyBzZXQgaW4gdGhlIGNvbmZpZy5cbmZ1bmN0aW9uIF9pbml0U3RvcmFnZSQyKG9wdGlvbnMpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIGRiSW5mbyA9IHt9O1xuICAgIGlmIChvcHRpb25zKSB7XG4gICAgICAgIGZvciAodmFyIGkgaW4gb3B0aW9ucykge1xuICAgICAgICAgICAgZGJJbmZvW2ldID0gb3B0aW9uc1tpXTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGRiSW5mby5rZXlQcmVmaXggPSBfZ2V0S2V5UHJlZml4KG9wdGlvbnMsIHNlbGYuX2RlZmF1bHRDb25maWcpO1xuXG4gICAgaWYgKCFfaXNMb2NhbFN0b3JhZ2VVc2FibGUoKSkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZSQxLnJlamVjdCgpO1xuICAgIH1cblxuICAgIHNlbGYuX2RiSW5mbyA9IGRiSW5mbztcbiAgICBkYkluZm8uc2VyaWFsaXplciA9IGxvY2FsZm9yYWdlU2VyaWFsaXplcjtcblxuICAgIHJldHVybiBQcm9taXNlJDEucmVzb2x2ZSgpO1xufVxuXG4vLyBSZW1vdmUgYWxsIGtleXMgZnJvbSB0aGUgZGF0YXN0b3JlLCBlZmZlY3RpdmVseSBkZXN0cm95aW5nIGFsbCBkYXRhIGluXG4vLyB0aGUgYXBwJ3Mga2V5L3ZhbHVlIHN0b3JlIVxuZnVuY3Rpb24gY2xlYXIkMihjYWxsYmFjaykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICB2YXIgcHJvbWlzZSA9IHNlbGYucmVhZHkoKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGtleVByZWZpeCA9IHNlbGYuX2RiSW5mby5rZXlQcmVmaXg7XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IGxvY2FsU3RvcmFnZS5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICAgICAgdmFyIGtleSA9IGxvY2FsU3RvcmFnZS5rZXkoaSk7XG5cbiAgICAgICAgICAgIGlmIChrZXkuaW5kZXhPZihrZXlQcmVmaXgpID09PSAwKSB7XG4gICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oa2V5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuLy8gUmV0cmlldmUgYW4gaXRlbSBmcm9tIHRoZSBzdG9yZS4gVW5saWtlIHRoZSBvcmlnaW5hbCBhc3luY19zdG9yYWdlXG4vLyBsaWJyYXJ5IGluIEdhaWEsIHdlIGRvbid0IG1vZGlmeSByZXR1cm4gdmFsdWVzIGF0IGFsbC4gSWYgYSBrZXkncyB2YWx1ZVxuLy8gaXMgYHVuZGVmaW5lZGAsIHdlIHBhc3MgdGhhdCB2YWx1ZSB0byB0aGUgY2FsbGJhY2sgZnVuY3Rpb24uXG5mdW5jdGlvbiBnZXRJdGVtJDIoa2V5LCBjYWxsYmFjaykge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIGtleSA9IG5vcm1hbGl6ZUtleShrZXkpO1xuXG4gICAgdmFyIHByb21pc2UgPSBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBkYkluZm8gPSBzZWxmLl9kYkluZm87XG4gICAgICAgIHZhciByZXN1bHQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShkYkluZm8ua2V5UHJlZml4ICsga2V5KTtcblxuICAgICAgICAvLyBJZiBhIHJlc3VsdCB3YXMgZm91bmQsIHBhcnNlIGl0IGZyb20gdGhlIHNlcmlhbGl6ZWRcbiAgICAgICAgLy8gc3RyaW5nIGludG8gYSBKUyBvYmplY3QuIElmIHJlc3VsdCBpc24ndCB0cnV0aHksIHRoZSBrZXlcbiAgICAgICAgLy8gaXMgbGlrZWx5IHVuZGVmaW5lZCBhbmQgd2UnbGwgcGFzcyBpdCBzdHJhaWdodCB0byB0aGVcbiAgICAgICAgLy8gY2FsbGJhY2suXG4gICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IGRiSW5mby5zZXJpYWxpemVyLmRlc2VyaWFsaXplKHJlc3VsdCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuLy8gSXRlcmF0ZSBvdmVyIGFsbCBpdGVtcyBpbiB0aGUgc3RvcmUuXG5mdW5jdGlvbiBpdGVyYXRlJDIoaXRlcmF0b3IsIGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgdmFyIHByb21pc2UgPSBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBkYkluZm8gPSBzZWxmLl9kYkluZm87XG4gICAgICAgIHZhciBrZXlQcmVmaXggPSBkYkluZm8ua2V5UHJlZml4O1xuICAgICAgICB2YXIga2V5UHJlZml4TGVuZ3RoID0ga2V5UHJlZml4Lmxlbmd0aDtcbiAgICAgICAgdmFyIGxlbmd0aCA9IGxvY2FsU3RvcmFnZS5sZW5ndGg7XG5cbiAgICAgICAgLy8gV2UgdXNlIGEgZGVkaWNhdGVkIGl0ZXJhdG9yIGluc3RlYWQgb2YgdGhlIGBpYCB2YXJpYWJsZSBiZWxvd1xuICAgICAgICAvLyBzbyBvdGhlciBrZXlzIHdlIGZldGNoIGluIGxvY2FsU3RvcmFnZSBhcmVuJ3QgY291bnRlZCBpblxuICAgICAgICAvLyB0aGUgYGl0ZXJhdGlvbk51bWJlcmAgYXJndW1lbnQgcGFzc2VkIHRvIHRoZSBgaXRlcmF0ZSgpYFxuICAgICAgICAvLyBjYWxsYmFjay5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gU2VlOiBnaXRodWIuY29tL21vemlsbGEvbG9jYWxGb3JhZ2UvcHVsbC80MzUjZGlzY3Vzc2lvbl9yMzgwNjE1MzBcbiAgICAgICAgdmFyIGl0ZXJhdGlvbk51bWJlciA9IDE7XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdmFyIGtleSA9IGxvY2FsU3RvcmFnZS5rZXkoaSk7XG4gICAgICAgICAgICBpZiAoa2V5LmluZGV4T2Yoa2V5UHJlZml4KSAhPT0gMCkge1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIHZhbHVlID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KTtcblxuICAgICAgICAgICAgLy8gSWYgYSByZXN1bHQgd2FzIGZvdW5kLCBwYXJzZSBpdCBmcm9tIHRoZSBzZXJpYWxpemVkXG4gICAgICAgICAgICAvLyBzdHJpbmcgaW50byBhIEpTIG9iamVjdC4gSWYgcmVzdWx0IGlzbid0IHRydXRoeSwgdGhlXG4gICAgICAgICAgICAvLyBrZXkgaXMgbGlrZWx5IHVuZGVmaW5lZCBhbmQgd2UnbGwgcGFzcyBpdCBzdHJhaWdodFxuICAgICAgICAgICAgLy8gdG8gdGhlIGl0ZXJhdG9yLlxuICAgICAgICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgdmFsdWUgPSBkYkluZm8uc2VyaWFsaXplci5kZXNlcmlhbGl6ZSh2YWx1ZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZhbHVlID0gaXRlcmF0b3IodmFsdWUsIGtleS5zdWJzdHJpbmcoa2V5UHJlZml4TGVuZ3RoKSwgaXRlcmF0aW9uTnVtYmVyKyspO1xuXG4gICAgICAgICAgICBpZiAodmFsdWUgIT09IHZvaWQgMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuLy8gU2FtZSBhcyBsb2NhbFN0b3JhZ2UncyBrZXkoKSBtZXRob2QsIGV4Y2VwdCB0YWtlcyBhIGNhbGxiYWNrLlxuZnVuY3Rpb24ga2V5JDIobiwgY2FsbGJhY2spIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIHByb21pc2UgPSBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBkYkluZm8gPSBzZWxmLl9kYkluZm87XG4gICAgICAgIHZhciByZXN1bHQ7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXN1bHQgPSBsb2NhbFN0b3JhZ2Uua2V5KG4pO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgcmVzdWx0ID0gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFJlbW92ZSB0aGUgcHJlZml4IGZyb20gdGhlIGtleSwgaWYgYSBrZXkgaXMgZm91bmQuXG4gICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IHJlc3VsdC5zdWJzdHJpbmcoZGJJbmZvLmtleVByZWZpeC5sZW5ndGgpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9KTtcblxuICAgIGV4ZWN1dGVDYWxsYmFjayhwcm9taXNlLCBjYWxsYmFjayk7XG4gICAgcmV0dXJuIHByb21pc2U7XG59XG5cbmZ1bmN0aW9uIGtleXMkMihjYWxsYmFjaykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICB2YXIgcHJvbWlzZSA9IHNlbGYucmVhZHkoKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGRiSW5mbyA9IHNlbGYuX2RiSW5mbztcbiAgICAgICAgdmFyIGxlbmd0aCA9IGxvY2FsU3RvcmFnZS5sZW5ndGg7XG4gICAgICAgIHZhciBrZXlzID0gW107XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdmFyIGl0ZW1LZXkgPSBsb2NhbFN0b3JhZ2Uua2V5KGkpO1xuICAgICAgICAgICAgaWYgKGl0ZW1LZXkuaW5kZXhPZihkYkluZm8ua2V5UHJlZml4KSA9PT0gMCkge1xuICAgICAgICAgICAgICAgIGtleXMucHVzaChpdGVtS2V5LnN1YnN0cmluZyhkYkluZm8ua2V5UHJlZml4Lmxlbmd0aCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGtleXM7XG4gICAgfSk7XG5cbiAgICBleGVjdXRlQ2FsbGJhY2socHJvbWlzZSwgY2FsbGJhY2spO1xuICAgIHJldHVybiBwcm9taXNlO1xufVxuXG4vLyBTdXBwbHkgdGhlIG51bWJlciBvZiBrZXlzIGluIHRoZSBkYXRhc3RvcmUgdG8gdGhlIGNhbGxiYWNrIGZ1bmN0aW9uLlxuZnVuY3Rpb24gbGVuZ3RoJDIoY2FsbGJhY2spIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIHByb21pc2UgPSBzZWxmLmtleXMoKS50aGVuKGZ1bmN0aW9uIChrZXlzKSB7XG4gICAgICAgIHJldHVybiBrZXlzLmxlbmd0aDtcbiAgICB9KTtcblxuICAgIGV4ZWN1dGVDYWxsYmFjayhwcm9taXNlLCBjYWxsYmFjayk7XG4gICAgcmV0dXJuIHByb21pc2U7XG59XG5cbi8vIFJlbW92ZSBhbiBpdGVtIGZyb20gdGhlIHN0b3JlLCBuaWNlIGFuZCBzaW1wbGUuXG5mdW5jdGlvbiByZW1vdmVJdGVtJDIoa2V5LCBjYWxsYmFjaykge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIGtleSA9IG5vcm1hbGl6ZUtleShrZXkpO1xuXG4gICAgdmFyIHByb21pc2UgPSBzZWxmLnJlYWR5KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBkYkluZm8gPSBzZWxmLl9kYkluZm87XG4gICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKGRiSW5mby5rZXlQcmVmaXggKyBrZXkpO1xuICAgIH0pO1xuXG4gICAgZXhlY3V0ZUNhbGxiYWNrKHByb21pc2UsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cblxuLy8gU2V0IGEga2V5J3MgdmFsdWUgYW5kIHJ1biBhbiBvcHRpb25hbCBjYWxsYmFjayBvbmNlIHRoZSB2YWx1ZSBpcyBzZXQuXG4vLyBVbmxpa2UgR2FpYSdzIGltcGxlbWVudGF0aW9uLCB0aGUgY2FsbGJhY2sgZnVuY3Rpb24gaXMgcGFzc2VkIHRoZSB2YWx1ZSxcbi8vIGluIGNhc2UgeW91IHdhbnQgdG8gb3BlcmF0ZSBvbiB0aGF0IHZhbHVlIG9ubHkgYWZ0ZXIgeW91J3JlIHN1cmUgaXRcbi8vIHNhdmVkLCBvciBzb21ldGhpbmcgbGlrZSB0aGF0LlxuZnVuY3Rpb24gc2V0SXRlbSQyKGtleSwgdmFsdWUsIGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAga2V5ID0gbm9ybWFsaXplS2V5KGtleSk7XG5cbiAgICB2YXIgcHJvbWlzZSA9IHNlbGYucmVhZHkoKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgLy8gQ29udmVydCB1bmRlZmluZWQgdmFsdWVzIHRvIG51bGwuXG4gICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9tb3ppbGxhL2xvY2FsRm9yYWdlL3B1bGwvNDJcbiAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHZhbHVlID0gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFNhdmUgdGhlIG9yaWdpbmFsIHZhbHVlIHRvIHBhc3MgdG8gdGhlIGNhbGxiYWNrLlxuICAgICAgICB2YXIgb3JpZ2luYWxWYWx1ZSA9IHZhbHVlO1xuXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSQxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgIHZhciBkYkluZm8gPSBzZWxmLl9kYkluZm87XG4gICAgICAgICAgICBkYkluZm8uc2VyaWFsaXplci5zZXJpYWxpemUodmFsdWUsIGZ1bmN0aW9uICh2YWx1ZSwgZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oZGJJbmZvLmtleVByZWZpeCArIGtleSwgdmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShvcmlnaW5hbFZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gbG9jYWxTdG9yYWdlIGNhcGFjaXR5IGV4Y2VlZGVkLlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gVE9ETzogTWFrZSB0aGlzIGEgc3BlY2lmaWMgZXJyb3IvZXZlbnQuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZS5uYW1lID09PSAnUXVvdGFFeGNlZWRlZEVycm9yJyB8fCBlLm5hbWUgPT09ICdOU19FUlJPUl9ET01fUVVPVEFfUkVBQ0hFRCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBleGVjdXRlQ2FsbGJhY2socHJvbWlzZSwgY2FsbGJhY2spO1xuICAgIHJldHVybiBwcm9taXNlO1xufVxuXG5mdW5jdGlvbiBkcm9wSW5zdGFuY2UkMihvcHRpb25zLCBjYWxsYmFjaykge1xuICAgIGNhbGxiYWNrID0gZ2V0Q2FsbGJhY2suYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblxuICAgIG9wdGlvbnMgPSB0eXBlb2Ygb3B0aW9ucyAhPT0gJ2Z1bmN0aW9uJyAmJiBvcHRpb25zIHx8IHt9O1xuICAgIGlmICghb3B0aW9ucy5uYW1lKSB7XG4gICAgICAgIHZhciBjdXJyZW50Q29uZmlnID0gdGhpcy5jb25maWcoKTtcbiAgICAgICAgb3B0aW9ucy5uYW1lID0gb3B0aW9ucy5uYW1lIHx8IGN1cnJlbnRDb25maWcubmFtZTtcbiAgICAgICAgb3B0aW9ucy5zdG9yZU5hbWUgPSBvcHRpb25zLnN0b3JlTmFtZSB8fCBjdXJyZW50Q29uZmlnLnN0b3JlTmFtZTtcbiAgICB9XG5cbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIHByb21pc2U7XG4gICAgaWYgKCFvcHRpb25zLm5hbWUpIHtcbiAgICAgICAgcHJvbWlzZSA9IFByb21pc2UkMS5yZWplY3QoJ0ludmFsaWQgYXJndW1lbnRzJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcHJvbWlzZSA9IG5ldyBQcm9taXNlJDEoZnVuY3Rpb24gKHJlc29sdmUpIHtcbiAgICAgICAgICAgIGlmICghb3B0aW9ucy5zdG9yZU5hbWUpIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKG9wdGlvbnMubmFtZSArICcvJyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlc29sdmUoX2dldEtleVByZWZpeChvcHRpb25zLCBzZWxmLl9kZWZhdWx0Q29uZmlnKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pLnRoZW4oZnVuY3Rpb24gKGtleVByZWZpeCkge1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IGxvY2FsU3RvcmFnZS5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICAgICAgICAgIHZhciBrZXkgPSBsb2NhbFN0b3JhZ2Uua2V5KGkpO1xuXG4gICAgICAgICAgICAgICAgaWYgKGtleS5pbmRleE9mKGtleVByZWZpeCkgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oa2V5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGV4ZWN1dGVDYWxsYmFjayhwcm9taXNlLCBjYWxsYmFjayk7XG4gICAgcmV0dXJuIHByb21pc2U7XG59XG5cbnZhciBsb2NhbFN0b3JhZ2VXcmFwcGVyID0ge1xuICAgIF9kcml2ZXI6ICdsb2NhbFN0b3JhZ2VXcmFwcGVyJyxcbiAgICBfaW5pdFN0b3JhZ2U6IF9pbml0U3RvcmFnZSQyLFxuICAgIF9zdXBwb3J0OiBpc0xvY2FsU3RvcmFnZVZhbGlkKCksXG4gICAgaXRlcmF0ZTogaXRlcmF0ZSQyLFxuICAgIGdldEl0ZW06IGdldEl0ZW0kMixcbiAgICBzZXRJdGVtOiBzZXRJdGVtJDIsXG4gICAgcmVtb3ZlSXRlbTogcmVtb3ZlSXRlbSQyLFxuICAgIGNsZWFyOiBjbGVhciQyLFxuICAgIGxlbmd0aDogbGVuZ3RoJDIsXG4gICAga2V5OiBrZXkkMixcbiAgICBrZXlzOiBrZXlzJDIsXG4gICAgZHJvcEluc3RhbmNlOiBkcm9wSW5zdGFuY2UkMlxufTtcblxudmFyIHNhbWVWYWx1ZSA9IGZ1bmN0aW9uIHNhbWVWYWx1ZSh4LCB5KSB7XG4gICAgcmV0dXJuIHggPT09IHkgfHwgdHlwZW9mIHggPT09ICdudW1iZXInICYmIHR5cGVvZiB5ID09PSAnbnVtYmVyJyAmJiBpc05hTih4KSAmJiBpc05hTih5KTtcbn07XG5cbnZhciBpbmNsdWRlcyA9IGZ1bmN0aW9uIGluY2x1ZGVzKGFycmF5LCBzZWFyY2hFbGVtZW50KSB7XG4gICAgdmFyIGxlbiA9IGFycmF5Lmxlbmd0aDtcbiAgICB2YXIgaSA9IDA7XG4gICAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICAgICAgaWYgKHNhbWVWYWx1ZShhcnJheVtpXSwgc2VhcmNoRWxlbWVudCkpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGkrKztcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG59O1xuXG52YXIgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkgfHwgZnVuY3Rpb24gKGFyZykge1xuICAgIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoYXJnKSA9PT0gJ1tvYmplY3QgQXJyYXldJztcbn07XG5cbi8vIERyaXZlcnMgYXJlIHN0b3JlZCBoZXJlIHdoZW4gYGRlZmluZURyaXZlcigpYCBpcyBjYWxsZWQuXG4vLyBUaGV5IGFyZSBzaGFyZWQgYWNyb3NzIGFsbCBpbnN0YW5jZXMgb2YgbG9jYWxGb3JhZ2UuXG52YXIgRGVmaW5lZERyaXZlcnMgPSB7fTtcblxudmFyIERyaXZlclN1cHBvcnQgPSB7fTtcblxudmFyIERlZmF1bHREcml2ZXJzID0ge1xuICAgIElOREVYRUREQjogYXN5bmNTdG9yYWdlLFxuICAgIFdFQlNRTDogd2ViU1FMU3RvcmFnZSxcbiAgICBMT0NBTFNUT1JBR0U6IGxvY2FsU3RvcmFnZVdyYXBwZXJcbn07XG5cbnZhciBEZWZhdWx0RHJpdmVyT3JkZXIgPSBbRGVmYXVsdERyaXZlcnMuSU5ERVhFRERCLl9kcml2ZXIsIERlZmF1bHREcml2ZXJzLldFQlNRTC5fZHJpdmVyLCBEZWZhdWx0RHJpdmVycy5MT0NBTFNUT1JBR0UuX2RyaXZlcl07XG5cbnZhciBPcHRpb25hbERyaXZlck1ldGhvZHMgPSBbJ2Ryb3BJbnN0YW5jZSddO1xuXG52YXIgTGlicmFyeU1ldGhvZHMgPSBbJ2NsZWFyJywgJ2dldEl0ZW0nLCAnaXRlcmF0ZScsICdrZXknLCAna2V5cycsICdsZW5ndGgnLCAncmVtb3ZlSXRlbScsICdzZXRJdGVtJ10uY29uY2F0KE9wdGlvbmFsRHJpdmVyTWV0aG9kcyk7XG5cbnZhciBEZWZhdWx0Q29uZmlnID0ge1xuICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICBkcml2ZXI6IERlZmF1bHREcml2ZXJPcmRlci5zbGljZSgpLFxuICAgIG5hbWU6ICdsb2NhbGZvcmFnZScsXG4gICAgLy8gRGVmYXVsdCBEQiBzaXplIGlzIF9KVVNUIFVOREVSXyA1TUIsIGFzIGl0J3MgdGhlIGhpZ2hlc3Qgc2l6ZVxuICAgIC8vIHdlIGNhbiB1c2Ugd2l0aG91dCBhIHByb21wdC5cbiAgICBzaXplOiA0OTgwNzM2LFxuICAgIHN0b3JlTmFtZTogJ2tleXZhbHVlcGFpcnMnLFxuICAgIHZlcnNpb246IDEuMFxufTtcblxuZnVuY3Rpb24gY2FsbFdoZW5SZWFkeShsb2NhbEZvcmFnZUluc3RhbmNlLCBsaWJyYXJ5TWV0aG9kKSB7XG4gICAgbG9jYWxGb3JhZ2VJbnN0YW5jZVtsaWJyYXJ5TWV0aG9kXSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIF9hcmdzID0gYXJndW1lbnRzO1xuICAgICAgICByZXR1cm4gbG9jYWxGb3JhZ2VJbnN0YW5jZS5yZWFkeSgpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIGxvY2FsRm9yYWdlSW5zdGFuY2VbbGlicmFyeU1ldGhvZF0uYXBwbHkobG9jYWxGb3JhZ2VJbnN0YW5jZSwgX2FyZ3MpO1xuICAgICAgICB9KTtcbiAgICB9O1xufVxuXG5mdW5jdGlvbiBleHRlbmQoKSB7XG4gICAgZm9yICh2YXIgaSA9IDE7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdmFyIGFyZyA9IGFyZ3VtZW50c1tpXTtcblxuICAgICAgICBpZiAoYXJnKSB7XG4gICAgICAgICAgICBmb3IgKHZhciBfa2V5IGluIGFyZykge1xuICAgICAgICAgICAgICAgIGlmIChhcmcuaGFzT3duUHJvcGVydHkoX2tleSkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzQXJyYXkoYXJnW19rZXldKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXJndW1lbnRzWzBdW19rZXldID0gYXJnW19rZXldLnNsaWNlKCk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhcmd1bWVudHNbMF1bX2tleV0gPSBhcmdbX2tleV07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gYXJndW1lbnRzWzBdO1xufVxuXG52YXIgTG9jYWxGb3JhZ2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gTG9jYWxGb3JhZ2Uob3B0aW9ucykge1xuICAgICAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgTG9jYWxGb3JhZ2UpO1xuXG4gICAgICAgIGZvciAodmFyIGRyaXZlclR5cGVLZXkgaW4gRGVmYXVsdERyaXZlcnMpIHtcbiAgICAgICAgICAgIGlmIChEZWZhdWx0RHJpdmVycy5oYXNPd25Qcm9wZXJ0eShkcml2ZXJUeXBlS2V5KSkge1xuICAgICAgICAgICAgICAgIHZhciBkcml2ZXIgPSBEZWZhdWx0RHJpdmVyc1tkcml2ZXJUeXBlS2V5XTtcbiAgICAgICAgICAgICAgICB2YXIgZHJpdmVyTmFtZSA9IGRyaXZlci5fZHJpdmVyO1xuICAgICAgICAgICAgICAgIHRoaXNbZHJpdmVyVHlwZUtleV0gPSBkcml2ZXJOYW1lO1xuXG4gICAgICAgICAgICAgICAgaWYgKCFEZWZpbmVkRHJpdmVyc1tkcml2ZXJOYW1lXSkge1xuICAgICAgICAgICAgICAgICAgICAvLyB3ZSBkb24ndCBuZWVkIHRvIHdhaXQgZm9yIHRoZSBwcm9taXNlLFxuICAgICAgICAgICAgICAgICAgICAvLyBzaW5jZSB0aGUgZGVmYXVsdCBkcml2ZXJzIGNhbiBiZSBkZWZpbmVkXG4gICAgICAgICAgICAgICAgICAgIC8vIGluIGEgYmxvY2tpbmcgbWFubmVyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZGVmaW5lRHJpdmVyKGRyaXZlcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5fZGVmYXVsdENvbmZpZyA9IGV4dGVuZCh7fSwgRGVmYXVsdENvbmZpZyk7XG4gICAgICAgIHRoaXMuX2NvbmZpZyA9IGV4dGVuZCh7fSwgdGhpcy5fZGVmYXVsdENvbmZpZywgb3B0aW9ucyk7XG4gICAgICAgIHRoaXMuX2RyaXZlclNldCA9IG51bGw7XG4gICAgICAgIHRoaXMuX2luaXREcml2ZXIgPSBudWxsO1xuICAgICAgICB0aGlzLl9yZWFkeSA9IGZhbHNlO1xuICAgICAgICB0aGlzLl9kYkluZm8gPSBudWxsO1xuXG4gICAgICAgIHRoaXMuX3dyYXBMaWJyYXJ5TWV0aG9kc1dpdGhSZWFkeSgpO1xuICAgICAgICB0aGlzLnNldERyaXZlcih0aGlzLl9jb25maWcuZHJpdmVyKVtcImNhdGNoXCJdKGZ1bmN0aW9uICgpIHt9KTtcbiAgICB9XG5cbiAgICAvLyBTZXQgYW55IGNvbmZpZyB2YWx1ZXMgZm9yIGxvY2FsRm9yYWdlOyBjYW4gYmUgY2FsbGVkIGFueXRpbWUgYmVmb3JlXG4gICAgLy8gdGhlIGZpcnN0IEFQSSBjYWxsIChlLmcuIGBnZXRJdGVtYCwgYHNldEl0ZW1gKS5cbiAgICAvLyBXZSBsb29wIHRocm91Z2ggb3B0aW9ucyBzbyB3ZSBkb24ndCBvdmVyd3JpdGUgZXhpc3RpbmcgY29uZmlnXG4gICAgLy8gdmFsdWVzLlxuXG5cbiAgICBMb2NhbEZvcmFnZS5wcm90b3R5cGUuY29uZmlnID0gZnVuY3Rpb24gY29uZmlnKG9wdGlvbnMpIHtcbiAgICAgICAgLy8gSWYgdGhlIG9wdGlvbnMgYXJndW1lbnQgaXMgYW4gb2JqZWN0LCB3ZSB1c2UgaXQgdG8gc2V0IHZhbHVlcy5cbiAgICAgICAgLy8gT3RoZXJ3aXNlLCB3ZSByZXR1cm4gZWl0aGVyIGEgc3BlY2lmaWVkIGNvbmZpZyB2YWx1ZSBvciBhbGxcbiAgICAgICAgLy8gY29uZmlnIHZhbHVlcy5cbiAgICAgICAgaWYgKCh0eXBlb2Ygb3B0aW9ucyA9PT0gJ3VuZGVmaW5lZCcgPyAndW5kZWZpbmVkJyA6IF90eXBlb2Yob3B0aW9ucykpID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgLy8gSWYgbG9jYWxmb3JhZ2UgaXMgcmVhZHkgYW5kIGZ1bGx5IGluaXRpYWxpemVkLCB3ZSBjYW4ndCBzZXRcbiAgICAgICAgICAgIC8vIGFueSBuZXcgY29uZmlndXJhdGlvbiB2YWx1ZXMuIEluc3RlYWQsIHdlIHJldHVybiBhbiBlcnJvci5cbiAgICAgICAgICAgIGlmICh0aGlzLl9yZWFkeSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgRXJyb3IoXCJDYW4ndCBjYWxsIGNvbmZpZygpIGFmdGVyIGxvY2FsZm9yYWdlIFwiICsgJ2hhcyBiZWVuIHVzZWQuJyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGZvciAodmFyIGkgaW4gb3B0aW9ucykge1xuICAgICAgICAgICAgICAgIGlmIChpID09PSAnc3RvcmVOYW1lJykge1xuICAgICAgICAgICAgICAgICAgICBvcHRpb25zW2ldID0gb3B0aW9uc1tpXS5yZXBsYWNlKC9cXFcvZywgJ18nKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAoaSA9PT0gJ3ZlcnNpb24nICYmIHR5cGVvZiBvcHRpb25zW2ldICE9PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEVycm9yKCdEYXRhYmFzZSB2ZXJzaW9uIG11c3QgYmUgYSBudW1iZXIuJyk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdGhpcy5fY29uZmlnW2ldID0gb3B0aW9uc1tpXTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gYWZ0ZXIgYWxsIGNvbmZpZyBvcHRpb25zIGFyZSBzZXQgYW5kXG4gICAgICAgICAgICAvLyB0aGUgZHJpdmVyIG9wdGlvbiBpcyB1c2VkLCB0cnkgc2V0dGluZyBpdFxuICAgICAgICAgICAgaWYgKCdkcml2ZXInIGluIG9wdGlvbnMgJiYgb3B0aW9ucy5kcml2ZXIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5zZXREcml2ZXIodGhpcy5fY29uZmlnLmRyaXZlcik7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBvcHRpb25zID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2NvbmZpZ1tvcHRpb25zXTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jb25maWc7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gVXNlZCB0byBkZWZpbmUgYSBjdXN0b20gZHJpdmVyLCBzaGFyZWQgYWNyb3NzIGFsbCBpbnN0YW5jZXMgb2ZcbiAgICAvLyBsb2NhbEZvcmFnZS5cblxuXG4gICAgTG9jYWxGb3JhZ2UucHJvdG90eXBlLmRlZmluZURyaXZlciA9IGZ1bmN0aW9uIGRlZmluZURyaXZlcihkcml2ZXJPYmplY3QsIGNhbGxiYWNrLCBlcnJvckNhbGxiYWNrKSB7XG4gICAgICAgIHZhciBwcm9taXNlID0gbmV3IFByb21pc2UkMShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHZhciBkcml2ZXJOYW1lID0gZHJpdmVyT2JqZWN0Ll9kcml2ZXI7XG4gICAgICAgICAgICAgICAgdmFyIGNvbXBsaWFuY2VFcnJvciA9IG5ldyBFcnJvcignQ3VzdG9tIGRyaXZlciBub3QgY29tcGxpYW50OyBzZWUgJyArICdodHRwczovL21vemlsbGEuZ2l0aHViLmlvL2xvY2FsRm9yYWdlLyNkZWZpbmVkcml2ZXInKTtcblxuICAgICAgICAgICAgICAgIC8vIEEgZHJpdmVyIG5hbWUgc2hvdWxkIGJlIGRlZmluZWQgYW5kIG5vdCBvdmVybGFwIHdpdGggdGhlXG4gICAgICAgICAgICAgICAgLy8gbGlicmFyeS1kZWZpbmVkLCBkZWZhdWx0IGRyaXZlcnMuXG4gICAgICAgICAgICAgICAgaWYgKCFkcml2ZXJPYmplY3QuX2RyaXZlcikge1xuICAgICAgICAgICAgICAgICAgICByZWplY3QoY29tcGxpYW5jZUVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHZhciBkcml2ZXJNZXRob2RzID0gTGlicmFyeU1ldGhvZHMuY29uY2F0KCdfaW5pdFN0b3JhZ2UnKTtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gZHJpdmVyTWV0aG9kcy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgZHJpdmVyTWV0aG9kTmFtZSA9IGRyaXZlck1ldGhvZHNbaV07XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gd2hlbiB0aGUgcHJvcGVydHkgaXMgdGhlcmUsXG4gICAgICAgICAgICAgICAgICAgIC8vIGl0IHNob3VsZCBiZSBhIG1ldGhvZCBldmVuIHdoZW4gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICAgICAgdmFyIGlzUmVxdWlyZWQgPSAhaW5jbHVkZXMoT3B0aW9uYWxEcml2ZXJNZXRob2RzLCBkcml2ZXJNZXRob2ROYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKChpc1JlcXVpcmVkIHx8IGRyaXZlck9iamVjdFtkcml2ZXJNZXRob2ROYW1lXSkgJiYgdHlwZW9mIGRyaXZlck9iamVjdFtkcml2ZXJNZXRob2ROYW1lXSAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGNvbXBsaWFuY2VFcnJvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB2YXIgY29uZmlndXJlTWlzc2luZ01ldGhvZHMgPSBmdW5jdGlvbiBjb25maWd1cmVNaXNzaW5nTWV0aG9kcygpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIG1ldGhvZE5vdEltcGxlbWVudGVkRmFjdG9yeSA9IGZ1bmN0aW9uIG1ldGhvZE5vdEltcGxlbWVudGVkRmFjdG9yeShtZXRob2ROYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBlcnJvciA9IG5ldyBFcnJvcignTWV0aG9kICcgKyBtZXRob2ROYW1lICsgJyBpcyBub3QgaW1wbGVtZW50ZWQgYnkgdGhlIGN1cnJlbnQgZHJpdmVyJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHByb21pc2UgPSBQcm9taXNlJDEucmVqZWN0KGVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBleGVjdXRlQ2FsbGJhY2socHJvbWlzZSwgYXJndW1lbnRzW2FyZ3VtZW50cy5sZW5ndGggLSAxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9pID0gMCwgX2xlbiA9IE9wdGlvbmFsRHJpdmVyTWV0aG9kcy5sZW5ndGg7IF9pIDwgX2xlbjsgX2krKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG9wdGlvbmFsRHJpdmVyTWV0aG9kID0gT3B0aW9uYWxEcml2ZXJNZXRob2RzW19pXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZHJpdmVyT2JqZWN0W29wdGlvbmFsRHJpdmVyTWV0aG9kXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRyaXZlck9iamVjdFtvcHRpb25hbERyaXZlck1ldGhvZF0gPSBtZXRob2ROb3RJbXBsZW1lbnRlZEZhY3Rvcnkob3B0aW9uYWxEcml2ZXJNZXRob2QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIGNvbmZpZ3VyZU1pc3NpbmdNZXRob2RzKCk7XG5cbiAgICAgICAgICAgICAgICB2YXIgc2V0RHJpdmVyU3VwcG9ydCA9IGZ1bmN0aW9uIHNldERyaXZlclN1cHBvcnQoc3VwcG9ydCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoRGVmaW5lZERyaXZlcnNbZHJpdmVyTmFtZV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuaW5mbygnUmVkZWZpbmluZyBMb2NhbEZvcmFnZSBkcml2ZXI6ICcgKyBkcml2ZXJOYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBEZWZpbmVkRHJpdmVyc1tkcml2ZXJOYW1lXSA9IGRyaXZlck9iamVjdDtcbiAgICAgICAgICAgICAgICAgICAgRHJpdmVyU3VwcG9ydFtkcml2ZXJOYW1lXSA9IHN1cHBvcnQ7XG4gICAgICAgICAgICAgICAgICAgIC8vIGRvbid0IHVzZSBhIHRoZW4sIHNvIHRoYXQgd2UgY2FuIGRlZmluZVxuICAgICAgICAgICAgICAgICAgICAvLyBkcml2ZXJzIHRoYXQgaGF2ZSBzaW1wbGUgX3N1cHBvcnQgbWV0aG9kc1xuICAgICAgICAgICAgICAgICAgICAvLyBpbiBhIGJsb2NraW5nIG1hbm5lclxuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIGlmICgnX3N1cHBvcnQnIGluIGRyaXZlck9iamVjdCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZHJpdmVyT2JqZWN0Ll9zdXBwb3J0ICYmIHR5cGVvZiBkcml2ZXJPYmplY3QuX3N1cHBvcnQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRyaXZlck9iamVjdC5fc3VwcG9ydCgpLnRoZW4oc2V0RHJpdmVyU3VwcG9ydCwgcmVqZWN0KTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldERyaXZlclN1cHBvcnQoISFkcml2ZXJPYmplY3QuX3N1cHBvcnQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0RHJpdmVyU3VwcG9ydCh0cnVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICBleGVjdXRlVHdvQ2FsbGJhY2tzKHByb21pc2UsIGNhbGxiYWNrLCBlcnJvckNhbGxiYWNrKTtcbiAgICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgfTtcblxuICAgIExvY2FsRm9yYWdlLnByb3RvdHlwZS5kcml2ZXIgPSBmdW5jdGlvbiBkcml2ZXIoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9kcml2ZXIgfHwgbnVsbDtcbiAgICB9O1xuXG4gICAgTG9jYWxGb3JhZ2UucHJvdG90eXBlLmdldERyaXZlciA9IGZ1bmN0aW9uIGdldERyaXZlcihkcml2ZXJOYW1lLCBjYWxsYmFjaywgZXJyb3JDYWxsYmFjaykge1xuICAgICAgICB2YXIgZ2V0RHJpdmVyUHJvbWlzZSA9IERlZmluZWREcml2ZXJzW2RyaXZlck5hbWVdID8gUHJvbWlzZSQxLnJlc29sdmUoRGVmaW5lZERyaXZlcnNbZHJpdmVyTmFtZV0pIDogUHJvbWlzZSQxLnJlamVjdChuZXcgRXJyb3IoJ0RyaXZlciBub3QgZm91bmQuJykpO1xuXG4gICAgICAgIGV4ZWN1dGVUd29DYWxsYmFja3MoZ2V0RHJpdmVyUHJvbWlzZSwgY2FsbGJhY2ssIGVycm9yQ2FsbGJhY2spO1xuICAgICAgICByZXR1cm4gZ2V0RHJpdmVyUHJvbWlzZTtcbiAgICB9O1xuXG4gICAgTG9jYWxGb3JhZ2UucHJvdG90eXBlLmdldFNlcmlhbGl6ZXIgPSBmdW5jdGlvbiBnZXRTZXJpYWxpemVyKGNhbGxiYWNrKSB7XG4gICAgICAgIHZhciBzZXJpYWxpemVyUHJvbWlzZSA9IFByb21pc2UkMS5yZXNvbHZlKGxvY2FsZm9yYWdlU2VyaWFsaXplcik7XG4gICAgICAgIGV4ZWN1dGVUd29DYWxsYmFja3Moc2VyaWFsaXplclByb21pc2UsIGNhbGxiYWNrKTtcbiAgICAgICAgcmV0dXJuIHNlcmlhbGl6ZXJQcm9taXNlO1xuICAgIH07XG5cbiAgICBMb2NhbEZvcmFnZS5wcm90b3R5cGUucmVhZHkgPSBmdW5jdGlvbiByZWFkeShjYWxsYmFjaykge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICAgICAgdmFyIHByb21pc2UgPSBzZWxmLl9kcml2ZXJTZXQudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoc2VsZi5fcmVhZHkgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICBzZWxmLl9yZWFkeSA9IHNlbGYuX2luaXREcml2ZXIoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHNlbGYuX3JlYWR5O1xuICAgICAgICB9KTtcblxuICAgICAgICBleGVjdXRlVHdvQ2FsbGJhY2tzKHByb21pc2UsIGNhbGxiYWNrLCBjYWxsYmFjayk7XG4gICAgICAgIHJldHVybiBwcm9taXNlO1xuICAgIH07XG5cbiAgICBMb2NhbEZvcmFnZS5wcm90b3R5cGUuc2V0RHJpdmVyID0gZnVuY3Rpb24gc2V0RHJpdmVyKGRyaXZlcnMsIGNhbGxiYWNrLCBlcnJvckNhbGxiYWNrKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgICAgICBpZiAoIWlzQXJyYXkoZHJpdmVycykpIHtcbiAgICAgICAgICAgIGRyaXZlcnMgPSBbZHJpdmVyc107XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgc3VwcG9ydGVkRHJpdmVycyA9IHRoaXMuX2dldFN1cHBvcnRlZERyaXZlcnMoZHJpdmVycyk7XG5cbiAgICAgICAgZnVuY3Rpb24gc2V0RHJpdmVyVG9Db25maWcoKSB7XG4gICAgICAgICAgICBzZWxmLl9jb25maWcuZHJpdmVyID0gc2VsZi5kcml2ZXIoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGV4dGVuZFNlbGZXaXRoRHJpdmVyKGRyaXZlcikge1xuICAgICAgICAgICAgc2VsZi5fZXh0ZW5kKGRyaXZlcik7XG4gICAgICAgICAgICBzZXREcml2ZXJUb0NvbmZpZygpO1xuXG4gICAgICAgICAgICBzZWxmLl9yZWFkeSA9IHNlbGYuX2luaXRTdG9yYWdlKHNlbGYuX2NvbmZpZyk7XG4gICAgICAgICAgICByZXR1cm4gc2VsZi5fcmVhZHk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBpbml0RHJpdmVyKHN1cHBvcnRlZERyaXZlcnMpIHtcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIGN1cnJlbnREcml2ZXJJbmRleCA9IDA7XG5cbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBkcml2ZXJQcm9taXNlTG9vcCgpIHtcbiAgICAgICAgICAgICAgICAgICAgd2hpbGUgKGN1cnJlbnREcml2ZXJJbmRleCA8IHN1cHBvcnRlZERyaXZlcnMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZHJpdmVyTmFtZSA9IHN1cHBvcnRlZERyaXZlcnNbY3VycmVudERyaXZlckluZGV4XTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnREcml2ZXJJbmRleCsrO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxmLl9kYkluZm8gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5fcmVhZHkgPSBudWxsO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gc2VsZi5nZXREcml2ZXIoZHJpdmVyTmFtZSkudGhlbihleHRlbmRTZWxmV2l0aERyaXZlcilbXCJjYXRjaFwiXShkcml2ZXJQcm9taXNlTG9vcCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBzZXREcml2ZXJUb0NvbmZpZygpO1xuICAgICAgICAgICAgICAgICAgICB2YXIgZXJyb3IgPSBuZXcgRXJyb3IoJ05vIGF2YWlsYWJsZSBzdG9yYWdlIG1ldGhvZCBmb3VuZC4nKTtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5fZHJpdmVyU2V0ID0gUHJvbWlzZSQxLnJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBzZWxmLl9kcml2ZXJTZXQ7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGRyaXZlclByb21pc2VMb29wKCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVGhlcmUgbWlnaHQgYmUgYSBkcml2ZXIgaW5pdGlhbGl6YXRpb24gaW4gcHJvZ3Jlc3NcbiAgICAgICAgLy8gc28gd2FpdCBmb3IgaXQgdG8gZmluaXNoIGluIG9yZGVyIHRvIGF2b2lkIGEgcG9zc2libGVcbiAgICAgICAgLy8gcmFjZSBjb25kaXRpb24gdG8gc2V0IF9kYkluZm9cbiAgICAgICAgdmFyIG9sZERyaXZlclNldERvbmUgPSB0aGlzLl9kcml2ZXJTZXQgIT09IG51bGwgPyB0aGlzLl9kcml2ZXJTZXRbXCJjYXRjaFwiXShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZSQxLnJlc29sdmUoKTtcbiAgICAgICAgfSkgOiBQcm9taXNlJDEucmVzb2x2ZSgpO1xuXG4gICAgICAgIHRoaXMuX2RyaXZlclNldCA9IG9sZERyaXZlclNldERvbmUudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgZHJpdmVyTmFtZSA9IHN1cHBvcnRlZERyaXZlcnNbMF07XG4gICAgICAgICAgICBzZWxmLl9kYkluZm8gPSBudWxsO1xuICAgICAgICAgICAgc2VsZi5fcmVhZHkgPSBudWxsO1xuXG4gICAgICAgICAgICByZXR1cm4gc2VsZi5nZXREcml2ZXIoZHJpdmVyTmFtZSkudGhlbihmdW5jdGlvbiAoZHJpdmVyKSB7XG4gICAgICAgICAgICAgICAgc2VsZi5fZHJpdmVyID0gZHJpdmVyLl9kcml2ZXI7XG4gICAgICAgICAgICAgICAgc2V0RHJpdmVyVG9Db25maWcoKTtcbiAgICAgICAgICAgICAgICBzZWxmLl93cmFwTGlicmFyeU1ldGhvZHNXaXRoUmVhZHkoKTtcbiAgICAgICAgICAgICAgICBzZWxmLl9pbml0RHJpdmVyID0gaW5pdERyaXZlcihzdXBwb3J0ZWREcml2ZXJzKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KVtcImNhdGNoXCJdKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHNldERyaXZlclRvQ29uZmlnKCk7XG4gICAgICAgICAgICB2YXIgZXJyb3IgPSBuZXcgRXJyb3IoJ05vIGF2YWlsYWJsZSBzdG9yYWdlIG1ldGhvZCBmb3VuZC4nKTtcbiAgICAgICAgICAgIHNlbGYuX2RyaXZlclNldCA9IFByb21pc2UkMS5yZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgcmV0dXJuIHNlbGYuX2RyaXZlclNldDtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgZXhlY3V0ZVR3b0NhbGxiYWNrcyh0aGlzLl9kcml2ZXJTZXQsIGNhbGxiYWNrLCBlcnJvckNhbGxiYWNrKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2RyaXZlclNldDtcbiAgICB9O1xuXG4gICAgTG9jYWxGb3JhZ2UucHJvdG90eXBlLnN1cHBvcnRzID0gZnVuY3Rpb24gc3VwcG9ydHMoZHJpdmVyTmFtZSkge1xuICAgICAgICByZXR1cm4gISFEcml2ZXJTdXBwb3J0W2RyaXZlck5hbWVdO1xuICAgIH07XG5cbiAgICBMb2NhbEZvcmFnZS5wcm90b3R5cGUuX2V4dGVuZCA9IGZ1bmN0aW9uIF9leHRlbmQobGlicmFyeU1ldGhvZHNBbmRQcm9wZXJ0aWVzKSB7XG4gICAgICAgIGV4dGVuZCh0aGlzLCBsaWJyYXJ5TWV0aG9kc0FuZFByb3BlcnRpZXMpO1xuICAgIH07XG5cbiAgICBMb2NhbEZvcmFnZS5wcm90b3R5cGUuX2dldFN1cHBvcnRlZERyaXZlcnMgPSBmdW5jdGlvbiBfZ2V0U3VwcG9ydGVkRHJpdmVycyhkcml2ZXJzKSB7XG4gICAgICAgIHZhciBzdXBwb3J0ZWREcml2ZXJzID0gW107XG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSBkcml2ZXJzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgZHJpdmVyTmFtZSA9IGRyaXZlcnNbaV07XG4gICAgICAgICAgICBpZiAodGhpcy5zdXBwb3J0cyhkcml2ZXJOYW1lKSkge1xuICAgICAgICAgICAgICAgIHN1cHBvcnRlZERyaXZlcnMucHVzaChkcml2ZXJOYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3VwcG9ydGVkRHJpdmVycztcbiAgICB9O1xuXG4gICAgTG9jYWxGb3JhZ2UucHJvdG90eXBlLl93cmFwTGlicmFyeU1ldGhvZHNXaXRoUmVhZHkgPSBmdW5jdGlvbiBfd3JhcExpYnJhcnlNZXRob2RzV2l0aFJlYWR5KCkge1xuICAgICAgICAvLyBBZGQgYSBzdHViIGZvciBlYWNoIGRyaXZlciBBUEkgbWV0aG9kIHRoYXQgZGVsYXlzIHRoZSBjYWxsIHRvIHRoZVxuICAgICAgICAvLyBjb3JyZXNwb25kaW5nIGRyaXZlciBtZXRob2QgdW50aWwgbG9jYWxGb3JhZ2UgaXMgcmVhZHkuIFRoZXNlIHN0dWJzXG4gICAgICAgIC8vIHdpbGwgYmUgcmVwbGFjZWQgYnkgdGhlIGRyaXZlciBtZXRob2RzIGFzIHNvb24gYXMgdGhlIGRyaXZlciBpc1xuICAgICAgICAvLyBsb2FkZWQsIHNvIHRoZXJlIGlzIG5vIHBlcmZvcm1hbmNlIGltcGFjdC5cbiAgICAgICAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IExpYnJhcnlNZXRob2RzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgICAgICBjYWxsV2hlblJlYWR5KHRoaXMsIExpYnJhcnlNZXRob2RzW2ldKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBMb2NhbEZvcmFnZS5wcm90b3R5cGUuY3JlYXRlSW5zdGFuY2UgPSBmdW5jdGlvbiBjcmVhdGVJbnN0YW5jZShvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiBuZXcgTG9jYWxGb3JhZ2Uob3B0aW9ucyk7XG4gICAgfTtcblxuICAgIHJldHVybiBMb2NhbEZvcmFnZTtcbn0oKTtcblxuLy8gVGhlIGFjdHVhbCBsb2NhbEZvcmFnZSBvYmplY3QgdGhhdCB3ZSBleHBvc2UgYXMgYSBtb2R1bGUgb3IgdmlhIGFcbi8vIGdsb2JhbC4gSXQncyBleHRlbmRlZCBieSBwdWxsaW5nIGluIG9uZSBvZiBvdXIgb3RoZXIgbGlicmFyaWVzLlxuXG5cbnZhciBsb2NhbGZvcmFnZV9qcyA9IG5ldyBMb2NhbEZvcmFnZSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGxvY2FsZm9yYWdlX2pzO1xuXG59LHtcIjNcIjozfV19LHt9LFs0XSkoNClcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Q0FNQSxDQUFDLFNBQVMsR0FBRTtFQUFDLElBQUcsT0FBTyxZQUFVLFlBQVUsT0FBTyxXQUFTLGFBQWEsT0FBTyxVQUFRLEVBQUU7T0FBTyxJQUFHLE9BQU8sV0FBUyxjQUFZLE9BQU8sS0FBSyxPQUFPLENBQUMsR0FBRSxDQUFDO09BQU07R0FBQyxJQUFJO0dBQUUsSUFBRyxPQUFPLFdBQVMsYUFBYSxJQUFFO1FBQVksSUFBRyxPQUFPLFdBQVMsYUFBYSxJQUFFO1FBQVksSUFBRyxPQUFPLFNBQU8sYUFBYSxJQUFFO1FBQVUsSUFBRTtHQUFLLEVBQUUsY0FBYyxFQUFFO0VBQUM7Q0FBQyxFQUFBLENBQUcsV0FBVTtFQUEyQixRQUFRLFNBQVMsRUFBRSxHQUFFLEdBQUUsR0FBRTtHQUFDLFNBQVMsRUFBRSxHQUFFLEdBQUU7SUFBQyxJQUFHLENBQUMsRUFBRSxJQUFHO0tBQUMsSUFBRyxDQUFDLEVBQUUsSUFBRztNQUFDLElBQUksSUFBRSxPQUFBLGFBQWdCLGNBQUE7TUFBb0IsSUFBRyxDQUFDLEtBQUcsR0FBRSxPQUFPLEVBQUUsR0FBRSxDQUFDLENBQUM7TUFBRSxJQUFHLEdBQUUsT0FBTyxFQUFFLEdBQUUsQ0FBQyxDQUFDO01BQUUsSUFBSSxvQkFBRSxJQUFJLE1BQU0seUJBQXVCLElBQUUsR0FBRztNQUFFLE1BQU8sRUFBRSxPQUFLLG9CQUFvQjtLQUFFO0tBQUMsSUFBSSxJQUFFLEVBQUUsS0FBRyxFQUFDLFNBQVEsQ0FBQyxFQUFDO0tBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxTQUFRLFNBQVMsR0FBRTtNQUFDLElBQUksSUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUM7TUFBRyxPQUFPLEVBQUUsSUFBRSxJQUFFLENBQUM7S0FBQyxHQUFFLEdBQUUsRUFBRSxTQUFRLEdBQUUsR0FBRSxHQUFFLENBQUM7SUFBQztJQUFDLE9BQU8sRUFBRSxFQUFFLENBQUM7R0FBTztHQUFDLElBQUksSUFBRSxPQUFBLGFBQWdCLGNBQUE7R0FBb0IsS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUUsUUFBTyxLQUFJLEVBQUUsRUFBRSxFQUFFO0dBQUUsT0FBTztFQUFDLEVBQUEsQ0FBRztHQUFDLEdBQUUsQ0FBQyxTQUFTLFNBQVEsVUFBTyxXQUFRO0lBQ3IxQixDQUFDLFNBQVUsUUFBTztLQUNsQjtLQUNBLElBQUksV0FBVyxPQUFPLG9CQUFvQixPQUFPO0tBRWpELElBQUk7S0FHRixJQUFJLFVBQVU7TUFDWixJQUFJLFNBQVM7TUFDYixJQUFJLFdBQVcsSUFBSSxTQUFTLFFBQVE7TUFDcEMsSUFBSSxVQUFVLE9BQU8sU0FBUyxlQUFlLEVBQUU7TUFDL0MsU0FBUyxRQUFRLFNBQVMsRUFDeEIsZUFBZSxLQUNqQixDQUFDO01BQ0QsZ0JBQWdCLFdBQVk7T0FDMUIsUUFBUSxPQUFRLFNBQVMsRUFBRSxTQUFTO01BQ3RDO0tBQ0YsT0FBTyxJQUFJLENBQUMsT0FBTyxnQkFBZ0IsT0FBTyxPQUFPLG1CQUFtQixhQUFhO01BQy9FLElBQUksVUFBVSxJQUFJLE9BQU8sZUFBZTtNQUN4QyxRQUFRLE1BQU0sWUFBWTtNQUMxQixnQkFBZ0IsV0FBWTtPQUMxQixRQUFRLE1BQU0sWUFBWSxDQUFDO01BQzdCO0tBQ0YsT0FBTyxJQUFJLGNBQWMsVUFBVSx3QkFBd0IsT0FBTyxTQUFTLGNBQWMsUUFBUSxHQUMvRixnQkFBZ0IsV0FBWTtNQUkxQixJQUFJLFdBQVcsT0FBTyxTQUFTLGNBQWMsUUFBUTtNQUNyRCxTQUFTLHFCQUFxQixXQUFZO09BQ3hDLFNBQVM7T0FFVCxTQUFTLHFCQUFxQjtPQUM5QixTQUFTLFdBQVcsWUFBWSxRQUFRO09BQ3hDLFdBQVc7TUFDYjtNQUNBLE9BQU8sU0FBUyxnQkFBZ0IsWUFBWSxRQUFRO0tBQ3REO1VBRUEsZ0JBQWdCLFdBQVk7TUFDMUIsV0FBVyxVQUFVLENBQUM7S0FDeEI7S0FJSixJQUFJO0tBQ0osSUFBSSxRQUFRLENBQUM7S0FFYixTQUFTLFdBQVc7TUFDbEIsV0FBVztNQUNYLElBQUksR0FBRztNQUNQLElBQUksTUFBTSxNQUFNO01BQ2hCLE9BQU8sS0FBSztPQUNWLFdBQVc7T0FDWCxRQUFRLENBQUM7T0FDVCxJQUFJO09BQ0osT0FBTyxFQUFFLElBQUksS0FDWCxTQUFTLEVBQUUsQ0FBQztPQUVkLE1BQU0sTUFBTTtNQUNkO01BQ0EsV0FBVztLQUNiO0tBRUEsU0FBTyxVQUFVO0tBQ2pCLFNBQVMsVUFBVSxNQUFNO01BQ3ZCLElBQUksTUFBTSxLQUFLLElBQUksTUFBTSxLQUFLLENBQUMsVUFDN0IsY0FBYztLQUVsQjtJQUVBLEVBQUEsQ0FBRyxLQUFLLE1BQUssT0FBTyxXQUFXLGNBQWMsU0FBUyxPQUFPLFNBQVMsY0FBYyxPQUFPLE9BQU8sV0FBVyxjQUFjLFNBQVMsQ0FBQyxDQUFDO0dBQ3RJLEdBQUUsQ0FBQyxDQUFDO0dBQUUsR0FBRSxDQUFDLFNBQVMsU0FBUSxVQUFPLFdBQVE7SUFDekM7SUFDQSxJQUFJLFlBQVksUUFBUSxDQUFDOztJQUd6QixTQUFTLFdBQVcsQ0FBQztJQUVyQixJQUFJLFdBQVcsQ0FBQztJQUVoQixJQUFJLFdBQVcsQ0FBQyxVQUFVO0lBQzFCLElBQUksWUFBWSxDQUFDLFdBQVc7SUFDNUIsSUFBSSxVQUFVLENBQUMsU0FBUztJQUV4QixTQUFPLFVBQVU7SUFFakIsU0FBUyxRQUFRLFVBQVU7S0FDekIsSUFBSSxPQUFPLGFBQWEsWUFDdEIsTUFBTSxJQUFJLFVBQVUsNkJBQTZCO0tBRW5ELEtBQUssUUFBUTtLQUNiLEtBQUssUUFBUSxDQUFDO0tBQ2QsS0FBSyxVQUFVLEtBQUs7S0FDcEIsSUFBSSxhQUFhLFVBQ2Ysc0JBQXNCLE1BQU0sUUFBUTtJQUV4QztJQUVBLFFBQVEsVUFBVSxXQUFXLFNBQVUsWUFBWTtLQUNqRCxPQUFPLEtBQUssS0FBSyxNQUFNLFVBQVU7SUFDbkM7SUFDQSxRQUFRLFVBQVUsT0FBTyxTQUFVLGFBQWEsWUFBWTtLQUMxRCxJQUFJLE9BQU8sZ0JBQWdCLGNBQWMsS0FBSyxVQUFVLGFBQ3RELE9BQU8sZUFBZSxjQUFjLEtBQUssVUFBVSxVQUNuRCxPQUFPO0tBRVQsSUFBSSxVQUFVLElBQUksS0FBSyxZQUFZLFFBQVE7S0FDM0MsSUFBSSxLQUFLLFVBQVUsU0FFakIsT0FBTyxTQURRLEtBQUssVUFBVSxZQUFZLGNBQWMsWUFDOUIsS0FBSyxPQUFPO1VBRXRDLEtBQUssTUFBTSxLQUFLLElBQUksVUFBVSxTQUFTLGFBQWEsVUFBVSxDQUFDO0tBR2pFLE9BQU87SUFDVDtJQUNBLFNBQVMsVUFBVSxTQUFTLGFBQWEsWUFBWTtLQUNuRCxLQUFLLFVBQVU7S0FDZixJQUFJLE9BQU8sZ0JBQWdCLFlBQVk7TUFDckMsS0FBSyxjQUFjO01BQ25CLEtBQUssZ0JBQWdCLEtBQUs7S0FDNUI7S0FDQSxJQUFJLE9BQU8sZUFBZSxZQUFZO01BQ3BDLEtBQUssYUFBYTtNQUNsQixLQUFLLGVBQWUsS0FBSztLQUMzQjtJQUNGO0lBQ0EsVUFBVSxVQUFVLGdCQUFnQixTQUFVLE9BQU87S0FDbkQsU0FBUyxRQUFRLEtBQUssU0FBUyxLQUFLO0lBQ3RDO0lBQ0EsVUFBVSxVQUFVLHFCQUFxQixTQUFVLE9BQU87S0FDeEQsT0FBTyxLQUFLLFNBQVMsS0FBSyxhQUFhLEtBQUs7SUFDOUM7SUFDQSxVQUFVLFVBQVUsZUFBZSxTQUFVLE9BQU87S0FDbEQsU0FBUyxPQUFPLEtBQUssU0FBUyxLQUFLO0lBQ3JDO0lBQ0EsVUFBVSxVQUFVLG9CQUFvQixTQUFVLE9BQU87S0FDdkQsT0FBTyxLQUFLLFNBQVMsS0FBSyxZQUFZLEtBQUs7SUFDN0M7SUFFQSxTQUFTLE9BQU8sU0FBUyxNQUFNLE9BQU87S0FDcEMsVUFBVSxXQUFZO01BQ3BCLElBQUk7TUFDSixJQUFJO09BQ0YsY0FBYyxLQUFLLEtBQUs7TUFDMUIsU0FBUyxHQUFHO09BQ1YsT0FBTyxTQUFTLE9BQU8sU0FBUyxDQUFDO01BQ25DO01BQ0EsSUFBSSxnQkFBZ0IsU0FDbEIsU0FBUyxPQUFPLHlCQUFTLElBQUksVUFBVSxvQ0FBb0MsQ0FBQztXQUU1RSxTQUFTLFFBQVEsU0FBUyxXQUFXO0tBRXpDLENBQUM7SUFDSDtJQUVBLFNBQVMsVUFBVSxTQUFVLE1BQU0sT0FBTztLQUN4QyxJQUFJLFNBQVMsU0FBUyxTQUFTLEtBQUs7S0FDcEMsSUFBSSxPQUFPLFdBQVcsU0FDcEIsT0FBTyxTQUFTLE9BQU8sTUFBTSxPQUFPLEtBQUs7S0FFM0MsSUFBSSxXQUFXLE9BQU87S0FFdEIsSUFBSSxVQUNGLHNCQUFzQixNQUFNLFFBQVE7VUFDL0I7TUFDTCxLQUFLLFFBQVE7TUFDYixLQUFLLFVBQVU7TUFDZixJQUFJLElBQUk7TUFDUixJQUFJLE1BQU0sS0FBSyxNQUFNO01BQ3JCLE9BQU8sRUFBRSxJQUFJLEtBQ1gsS0FBSyxNQUFNLEVBQUUsQ0FBQyxjQUFjLEtBQUs7S0FFckM7S0FDQSxPQUFPO0lBQ1Q7SUFDQSxTQUFTLFNBQVMsU0FBVSxNQUFNLE9BQU87S0FDdkMsS0FBSyxRQUFRO0tBQ2IsS0FBSyxVQUFVO0tBQ2YsSUFBSSxJQUFJO0tBQ1IsSUFBSSxNQUFNLEtBQUssTUFBTTtLQUNyQixPQUFPLEVBQUUsSUFBSSxLQUNYLEtBQUssTUFBTSxFQUFFLENBQUMsYUFBYSxLQUFLO0tBRWxDLE9BQU87SUFDVDtJQUVBLFNBQVMsUUFBUSxLQUFLO0tBRXBCLElBQUksT0FBTyxPQUFPLElBQUk7S0FDdEIsSUFBSSxRQUFRLE9BQU8sUUFBUSxZQUFZLE9BQU8sUUFBUSxlQUFlLE9BQU8sU0FBUyxZQUNuRixPQUFPLFNBQVMsV0FBVztNQUN6QixLQUFLLE1BQU0sS0FBSyxTQUFTO0tBQzNCO0lBRUo7SUFFQSxTQUFTLHNCQUFzQixNQUFNLFVBQVU7S0FFN0MsSUFBSSxTQUFTO0tBQ2IsU0FBUyxRQUFRLE9BQU87TUFDdEIsSUFBSSxRQUNGO01BRUYsU0FBUztNQUNULFNBQVMsT0FBTyxNQUFNLEtBQUs7S0FDN0I7S0FFQSxTQUFTLFVBQVUsT0FBTztNQUN4QixJQUFJLFFBQ0Y7TUFFRixTQUFTO01BQ1QsU0FBUyxRQUFRLE1BQU0sS0FBSztLQUM5QjtLQUVBLFNBQVMsY0FBYztNQUNyQixTQUFTLFdBQVcsT0FBTztLQUM3QjtLQUVBLElBQUksU0FBUyxTQUFTLFdBQVc7S0FDakMsSUFBSSxPQUFPLFdBQVcsU0FDcEIsUUFBUSxPQUFPLEtBQUs7SUFFeEI7SUFFQSxTQUFTLFNBQVMsTUFBTSxPQUFPO0tBQzdCLElBQUksTUFBTSxDQUFDO0tBQ1gsSUFBSTtNQUNGLElBQUksUUFBUSxLQUFLLEtBQUs7TUFDdEIsSUFBSSxTQUFTO0tBQ2YsU0FBUyxHQUFHO01BQ1YsSUFBSSxTQUFTO01BQ2IsSUFBSSxRQUFRO0tBQ2Q7S0FDQSxPQUFPO0lBQ1Q7SUFFQSxRQUFRLFVBQVU7SUFDbEIsU0FBUyxRQUFRLE9BQU87S0FDdEIsSUFBSSxpQkFBaUIsTUFDbkIsT0FBTztLQUVULE9BQU8sU0FBUyxRQUFRLElBQUksS0FBSyxRQUFRLEdBQUcsS0FBSztJQUNuRDtJQUVBLFFBQVEsU0FBUztJQUNqQixTQUFTLE9BQU8sUUFBUTtLQUN0QixJQUFJLFVBQVUsSUFBSSxLQUFLLFFBQVE7S0FDL0IsT0FBTyxTQUFTLE9BQU8sU0FBUyxNQUFNO0lBQ3hDO0lBRUEsUUFBUSxNQUFNO0lBQ2QsU0FBUyxJQUFJLFVBQVU7S0FDckIsSUFBSSxPQUFPO0tBQ1gsSUFBSSxPQUFPLFVBQVUsU0FBUyxLQUFLLFFBQVEsTUFBTSxrQkFDL0MsT0FBTyxLQUFLLHVCQUFPLElBQUksVUFBVSxrQkFBa0IsQ0FBQztLQUd0RCxJQUFJLE1BQU0sU0FBUztLQUNuQixJQUFJLFNBQVM7S0FDYixJQUFJLENBQUMsS0FDSCxPQUFPLEtBQUssUUFBUSxDQUFDLENBQUM7S0FHeEIsSUFBSSxTQUFTLElBQUksTUFBTSxHQUFHO0tBQzFCLElBQUksV0FBVztLQUNmLElBQUksSUFBSTtLQUNSLElBQUksVUFBVSxJQUFJLEtBQUssUUFBUTtLQUUvQixPQUFPLEVBQUUsSUFBSSxLQUNYLFlBQVksU0FBUyxJQUFJLENBQUM7S0FFNUIsT0FBTztLQUNQLFNBQVMsWUFBWSxPQUFPLEdBQUc7TUFDN0IsS0FBSyxRQUFRLEtBQUssQ0FBQyxDQUFDLEtBQUssZ0JBQWdCLFNBQVUsT0FBTztPQUN4RCxJQUFJLENBQUMsUUFBUTtRQUNYLFNBQVM7UUFDVCxTQUFTLE9BQU8sU0FBUyxLQUFLO09BQ2hDO01BQ0YsQ0FBQztNQUNELFNBQVMsZUFBZSxVQUFVO09BQ2hDLE9BQU8sS0FBSztPQUNaLElBQUksRUFBRSxhQUFhLE9BQU8sQ0FBQyxRQUFRO1FBQ2pDLFNBQVM7UUFDVCxTQUFTLFFBQVEsU0FBUyxNQUFNO09BQ2xDO01BQ0Y7S0FDRjtJQUNGO0lBRUEsUUFBUSxPQUFPO0lBQ2YsU0FBUyxLQUFLLFVBQVU7S0FDdEIsSUFBSSxPQUFPO0tBQ1gsSUFBSSxPQUFPLFVBQVUsU0FBUyxLQUFLLFFBQVEsTUFBTSxrQkFDL0MsT0FBTyxLQUFLLHVCQUFPLElBQUksVUFBVSxrQkFBa0IsQ0FBQztLQUd0RCxJQUFJLE1BQU0sU0FBUztLQUNuQixJQUFJLFNBQVM7S0FDYixJQUFJLENBQUMsS0FDSCxPQUFPLEtBQUssUUFBUSxDQUFDLENBQUM7S0FHeEIsSUFBSSxJQUFJO0tBQ1IsSUFBSSxVQUFVLElBQUksS0FBSyxRQUFRO0tBRS9CLE9BQU8sRUFBRSxJQUFJLEtBQ1gsU0FBUyxTQUFTLEVBQUU7S0FFdEIsT0FBTztLQUNQLFNBQVMsU0FBUyxPQUFPO01BQ3ZCLEtBQUssUUFBUSxLQUFLLENBQUMsQ0FBQyxLQUFLLFNBQVUsVUFBVTtPQUMzQyxJQUFJLENBQUMsUUFBUTtRQUNYLFNBQVM7UUFDVCxTQUFTLFFBQVEsU0FBUyxRQUFRO09BQ3BDO01BQ0YsR0FBRyxTQUFVLE9BQU87T0FDbEIsSUFBSSxDQUFDLFFBQVE7UUFDWCxTQUFTO1FBQ1QsU0FBUyxPQUFPLFNBQVMsS0FBSztPQUNoQztNQUNGLENBQUM7S0FDSDtJQUNGO0dBRUEsR0FBRSxFQUFDLEtBQUksRUFBQyxDQUFDO0dBQUUsR0FBRSxDQUFDLFNBQVMsU0FBUSxVQUFPLFdBQVE7SUFDOUMsQ0FBQyxTQUFVLFFBQU87S0FDbEI7S0FDQSxJQUFJLE9BQU8sT0FBTyxZQUFZLFlBQzVCLE9BQU8sVUFBVSxRQUFRLENBQUM7SUFHNUIsRUFBQSxDQUFHLEtBQUssTUFBSyxPQUFPLFdBQVcsY0FBYyxTQUFTLE9BQU8sU0FBUyxjQUFjLE9BQU8sT0FBTyxXQUFXLGNBQWMsU0FBUyxDQUFDLENBQUM7R0FDdEksR0FBRSxFQUFDLEtBQUksRUFBQyxDQUFDO0dBQUUsR0FBRSxDQUFDLFNBQVMsU0FBUSxVQUFPLFdBQVE7SUFDOUM7SUFFQSxJQUFJLFVBQVUsT0FBTyxXQUFXLGNBQWMsT0FBTyxPQUFPLGFBQWEsV0FBVyxTQUFVLEtBQUs7S0FBRSxPQUFPLE9BQU87SUFBSyxJQUFJLFNBQVUsS0FBSztLQUFFLE9BQU8sT0FBTyxPQUFPLFdBQVcsY0FBYyxJQUFJLGdCQUFnQixVQUFVLFFBQVEsT0FBTyxZQUFZLFdBQVcsT0FBTztJQUFLO0lBRTNRLFNBQVMsZ0JBQWdCLFVBQVUsYUFBYTtLQUFFLElBQUksRUFBRSxvQkFBb0IsY0FBZ0IsTUFBTSxJQUFJLFVBQVUsbUNBQW1DO0lBQUs7SUFFeEosU0FBUyxTQUFTO0tBRWQsSUFBSTtNQUNBLElBQUksT0FBTyxjQUFjLGFBQ3JCLE9BQU87TUFFWCxJQUFJLE9BQU8sb0JBQW9CLGFBQzNCLE9BQU87TUFFWCxJQUFJLE9BQU8saUJBQWlCLGFBQ3hCLE9BQU87TUFFWCxJQUFJLE9BQU8sZUFBZSxhQUN0QixPQUFPO01BRVgsSUFBSSxPQUFPLGdCQUFnQixhQUN2QixPQUFPO0tBRWYsU0FBUyxHQUFHO01BQ1I7S0FDSjtJQUNKO0lBRUEsSUFBSSxNQUFNLE9BQU87SUFFakIsU0FBUyxtQkFBbUI7S0FDeEIsSUFBSTtNQUdBLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUNiLE9BQU87TUFNWCxJQUFJLFdBQVcsT0FBTyxpQkFBaUIsZUFBZSw0QkFBNEIsS0FBSyxVQUFVLFNBQVMsS0FBSyxDQUFDLFNBQVMsS0FBSyxVQUFVLFNBQVMsS0FBSyxDQUFDLGFBQWEsS0FBSyxVQUFVLFFBQVE7TUFFM0wsSUFBSSxXQUFXLE9BQU8sVUFBVSxjQUFjLE1BQU0sU0FBUyxDQUFDLENBQUMsUUFBUSxjQUFjLE1BQU07TUFRM0YsUUFBUSxDQUFDLFlBQVksYUFBYSxPQUFPLGNBQWMsZUFLdkQsT0FBTyxnQkFBZ0I7S0FDM0IsU0FBUyxHQUFHO01BQ1IsT0FBTztLQUNYO0lBQ0o7SUFRQSxTQUFTLFdBQVcsT0FBTyxZQUFZO0tBRW5DLFFBQVEsU0FBUyxDQUFDO0tBQ2xCLGFBQWEsY0FBYyxDQUFDO0tBQzVCLElBQUk7TUFDQSxPQUFPLElBQUksS0FBSyxPQUFPLFVBQVU7S0FDckMsU0FBUyxHQUFHO01BQ1IsSUFBSSxFQUFFLFNBQVMsYUFDWCxNQUFNO01BR1YsSUFBSSxVQUFVLEtBREEsT0FBTyxnQkFBZ0IsY0FBYyxjQUFjLE9BQU8sa0JBQWtCLGNBQWMsZ0JBQWdCLE9BQU8sbUJBQW1CLGNBQWMsaUJBQWlCLG1CQUN2SjtNQUMxQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssR0FDbkMsUUFBUSxPQUFPLE1BQU0sRUFBRTtNQUUzQixPQUFPLFFBQVEsUUFBUSxXQUFXLElBQUk7S0FDMUM7SUFDSjtJQUlBLElBQUksT0FBTyxZQUFZLGFBR25CLFFBQVEsQ0FBQztJQUViLElBQUksWUFBWTtJQUVoQixTQUFTLGdCQUFnQixTQUFTLFVBQVU7S0FDeEMsSUFBSSxVQUNBLFFBQVEsS0FBSyxTQUFVLFFBQVE7TUFDM0IsU0FBUyxNQUFNLE1BQU07S0FDekIsR0FBRyxTQUFVLE9BQU87TUFDaEIsU0FBUyxLQUFLO0tBQ2xCLENBQUM7SUFFVDtJQUVBLFNBQVMsb0JBQW9CLFNBQVMsVUFBVSxlQUFlO0tBQzNELElBQUksT0FBTyxhQUFhLFlBQ3BCLFFBQVEsS0FBSyxRQUFRO0tBR3pCLElBQUksT0FBTyxrQkFBa0IsWUFDekIsUUFBUSxRQUFRLENBQUMsYUFBYTtJQUV0QztJQUVBLFNBQVMsYUFBYSxLQUFLO0tBRXZCLElBQUksT0FBTyxRQUFRLFVBQVU7TUFDekIsUUFBUSxLQUFLLE1BQU0seUNBQXlDO01BQzVELE1BQU0sT0FBTyxHQUFHO0tBQ3BCO0tBRUEsT0FBTztJQUNYO0lBRUEsU0FBUyxjQUFjO0tBQ25CLElBQUksVUFBVSxVQUFVLE9BQU8sVUFBVSxVQUFVLFNBQVMsT0FBTyxZQUMvRCxPQUFPLFVBQVUsVUFBVSxTQUFTO0lBRTVDO0lBS0EsSUFBSSw0QkFBNEI7SUFDaEMsSUFBSSxnQkFBZ0IsS0FBSztJQUN6QixJQUFJLGFBQWEsQ0FBQztJQUNsQixJQUFJLFdBQVcsT0FBTyxVQUFVO0lBR2hDLElBQUksWUFBWTtJQUNoQixJQUFJLGFBQWE7SUFPakIsU0FBUyx3QkFBd0IsS0FBSztLQUNsQyxJQUFJLFNBQVMsSUFBSTtLQUNqQixJQUFJLE1BQU0sSUFBSSxZQUFZLE1BQU07S0FDaEMsSUFBSSxNQUFNLElBQUksV0FBVyxHQUFHO0tBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQ3hCLElBQUksS0FBSyxJQUFJLFdBQVcsQ0FBQztLQUU3QixPQUFPO0lBQ1g7SUFpQkEsU0FBUyxnQ0FBZ0MsS0FBSztLQUMxQyxPQUFPLElBQUksVUFBVSxTQUFVLFNBQVM7TUFDcEMsSUFBSSxNQUFNLElBQUksWUFBWSwyQkFBMkIsVUFBVTtNQUMvRCxJQUFJLE9BQU8sV0FBVyxDQUFDLEVBQUUsQ0FBQztNQUMxQixJQUFJLFlBQVkseUJBQXlCLENBQUMsQ0FBQyxJQUFJLE1BQU0sS0FBSztNQUUxRCxJQUFJLFVBQVUsU0FBVSxHQUFHO09BR3ZCLEVBQUUsZUFBZTtPQUNqQixFQUFFLGdCQUFnQjtPQUNsQixRQUFRLEtBQUs7TUFDakI7TUFFQSxJQUFJLGFBQWEsV0FBWTtPQUN6QixJQUFJLGdCQUFnQixVQUFVLFVBQVUsTUFBTSxlQUFlO09BSTdELFFBSGtCLFVBQVUsVUFBVSxNQUFNLFFBRzFCLEtBQUssQ0FBQyxpQkFBaUIsU0FBUyxjQUFjLElBQUksRUFBRSxLQUFLLEVBQUU7TUFDakY7S0FDSixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBWTtNQUNwQixPQUFPO0tBQ1gsQ0FBQztJQUNMO0lBRUEsU0FBUyxrQkFBa0IsS0FBSztLQUM1QixJQUFJLE9BQU8sa0JBQWtCLFdBQ3pCLE9BQU8sVUFBVSxRQUFRLGFBQWE7S0FFMUMsT0FBTyxnQ0FBZ0MsR0FBRyxDQUFDLENBQUMsS0FBSyxTQUFVLE9BQU87TUFDOUQsZ0JBQWdCO01BQ2hCLE9BQU87S0FDWCxDQUFDO0lBQ0w7SUFFQSxTQUFTLGdCQUFnQixRQUFRO0tBQzdCLElBQUksWUFBWSxXQUFXLE9BQU87S0FHbEMsSUFBSSxvQkFBb0IsQ0FBQztLQUV6QixrQkFBa0IsVUFBVSxJQUFJLFVBQVUsU0FBVSxTQUFTLFFBQVE7TUFDakUsa0JBQWtCLFVBQVU7TUFDNUIsa0JBQWtCLFNBQVM7S0FDL0IsQ0FBQztLQUdELFVBQVUsbUJBQW1CLEtBQUssaUJBQWlCO0tBR25ELElBQUksQ0FBQyxVQUFVLFNBQ1gsVUFBVSxVQUFVLGtCQUFrQjtVQUV0QyxVQUFVLFVBQVUsVUFBVSxRQUFRLEtBQUssV0FBWTtNQUNuRCxPQUFPLGtCQUFrQjtLQUM3QixDQUFDO0lBRVQ7SUFFQSxTQUFTLGtCQUFrQixRQUFRO0tBSS9CLElBQUksb0JBSFksV0FBVyxPQUFPLEtBR0QsQ0FBQyxtQkFBbUIsSUFBSTtLQUl6RCxJQUFJLG1CQUFtQjtNQUNuQixrQkFBa0IsUUFBUTtNQUMxQixPQUFPLGtCQUFrQjtLQUM3QjtJQUNKO0lBRUEsU0FBUyxpQkFBaUIsUUFBUSxLQUFLO0tBSW5DLElBQUksb0JBSFksV0FBVyxPQUFPLEtBR0QsQ0FBQyxtQkFBbUIsSUFBSTtLQUl6RCxJQUFJLG1CQUFtQjtNQUNuQixrQkFBa0IsT0FBTyxHQUFHO01BQzVCLE9BQU8sa0JBQWtCO0tBQzdCO0lBQ0o7SUFFQSxTQUFTLGVBQWUsUUFBUSxlQUFlO0tBQzNDLE9BQU8sSUFBSSxVQUFVLFNBQVUsU0FBUyxRQUFRO01BQzVDLFdBQVcsT0FBTyxRQUFRLFdBQVcsT0FBTyxTQUFTLGdCQUFnQjtNQUVyRSxJQUFJLE9BQU8sSUFDUCxJQUFJLGVBQWU7T0FDZixnQkFBZ0IsTUFBTTtPQUN0QixPQUFPLEdBQUcsTUFBTTtNQUNwQixPQUNJLE9BQU8sUUFBUSxPQUFPLEVBQUU7TUFJaEMsSUFBSSxTQUFTLENBQUMsT0FBTyxJQUFJO01BRXpCLElBQUksZUFDQSxPQUFPLEtBQUssT0FBTyxPQUFPO01BRzlCLElBQUksVUFBVSxJQUFJLEtBQUssTUFBTSxLQUFLLE1BQU07TUFFeEMsSUFBSSxlQUNBLFFBQVEsa0JBQWtCLFNBQVUsR0FBRztPQUNuQyxJQUFJLEtBQUssUUFBUTtPQUNqQixJQUFJO1FBQ0EsR0FBRyxrQkFBa0IsT0FBTyxTQUFTO1FBQ3JDLElBQUksRUFBRSxjQUFjLEdBRWhCLEdBQUcsa0JBQWtCLHlCQUF5QjtPQUV0RCxTQUFTLElBQUk7UUFDVCxJQUFJLEdBQUcsU0FBUyxtQkFDWixRQUFRLEtBQUssb0JBQW1CLE9BQU8sT0FBTyx1Q0FBMkMsRUFBRSxhQUFhLGlCQUFpQixFQUFFLGFBQWEseUJBQXdCLE9BQU8sWUFBWSxvQkFBbUI7YUFFdE0sTUFBTTtPQUVkO01BQ0o7TUFHSixRQUFRLFVBQVUsU0FBVSxHQUFHO09BQzNCLEVBQUUsZUFBZTtPQUNqQixPQUFPLFFBQVEsS0FBSztNQUN4QjtNQUVBLFFBQVEsWUFBWSxXQUFZO09BQzVCLElBQUksS0FBSyxRQUFRO09BQ2pCLEdBQUcsa0JBQWtCLFNBQVUsR0FBRztRQU05QixFQUFFLE9BQU8sTUFBTTtPQUNuQjtPQUNBLFFBQVEsRUFBRTtPQUNWLGtCQUFrQixNQUFNO01BQzVCO0tBQ0osQ0FBQztJQUNMO0lBRUEsU0FBUyx1QkFBdUIsUUFBUTtLQUNwQyxPQUFPLGVBQWUsUUFBUSxLQUFLO0lBQ3ZDO0lBRUEsU0FBUyx1QkFBdUIsUUFBUTtLQUNwQyxPQUFPLGVBQWUsUUFBUSxJQUFJO0lBQ3RDO0lBRUEsU0FBUyxpQkFBaUIsUUFBUSxnQkFBZ0I7S0FDOUMsSUFBSSxDQUFDLE9BQU8sSUFDUixPQUFPO0tBR1gsSUFBSSxhQUFhLENBQUMsT0FBTyxHQUFHLGlCQUFpQixTQUFTLE9BQU8sU0FBUztLQUN0RSxJQUFJLGNBQWMsT0FBTyxVQUFVLE9BQU8sR0FBRztLQUM3QyxJQUFJLFlBQVksT0FBTyxVQUFVLE9BQU8sR0FBRztLQUUzQyxJQUFJLGFBQWE7TUFHYixJQUFJLE9BQU8sWUFBWSxnQkFDbkIsUUFBUSxLQUFLLG9CQUFtQixPQUFPLE9BQU8seUNBQTZDLE9BQU8sR0FBRyxVQUFVLGlCQUFpQixPQUFPLFVBQVUsR0FBRztNQUd4SixPQUFPLFVBQVUsT0FBTyxHQUFHO0tBQy9CO0tBRUEsSUFBSSxhQUFhLFlBQVk7TUFJekIsSUFBSSxZQUFZO09BQ1osSUFBSSxhQUFhLE9BQU8sR0FBRyxVQUFVO09BQ3JDLElBQUksYUFBYSxPQUFPLFNBQ3BCLE9BQU8sVUFBVTtNQUV6QjtNQUVBLE9BQU87S0FDWDtLQUVBLE9BQU87SUFDWDtJQUdBLFNBQVMsWUFBWSxNQUFNO0tBQ3ZCLE9BQU8sSUFBSSxVQUFVLFNBQVUsU0FBUyxRQUFRO01BQzVDLElBQUksU0FBUyxJQUFJLFdBQVc7TUFDNUIsT0FBTyxVQUFVO01BQ2pCLE9BQU8sWUFBWSxTQUFVLEdBQUc7T0FFNUIsUUFBUTtRQUNKLDZCQUE2QjtRQUM3QixNQUhTLEtBQUssRUFBRSxPQUFPLFVBQVUsRUFHdEI7UUFDWCxNQUFNLEtBQUs7T0FDZixDQUFDO01BQ0w7TUFDQSxPQUFPLG1CQUFtQixJQUFJO0tBQ2xDLENBQUM7SUFDTDtJQUdBLFNBQVMsWUFBWSxhQUFhO0tBRTlCLE9BQU8sV0FBVyxDQURGLHdCQUF3QixLQUFLLFlBQVksSUFBSSxDQUNsQyxDQUFDLEdBQUcsRUFBRSxNQUFNLFlBQVksS0FBSyxDQUFDO0lBQzdEO0lBR0EsU0FBUyxlQUFlLE9BQU87S0FDM0IsT0FBTyxTQUFTLE1BQU07SUFDMUI7SUFNQSxTQUFTLFlBQVksVUFBVTtLQUMzQixJQUFJLE9BQU87S0FFWCxJQUFJLFVBQVUsS0FBSyxXQUFXLENBQUMsQ0FBQyxLQUFLLFdBQVk7TUFDN0MsSUFBSSxZQUFZLFdBQVcsS0FBSyxRQUFRO01BRXhDLElBQUksYUFBYSxVQUFVLFNBQ3ZCLE9BQU8sVUFBVTtLQUV6QixDQUFDO0tBRUQsb0JBQW9CLFNBQVMsVUFBVSxRQUFRO0tBQy9DLE9BQU87SUFDWDtJQUtBLFNBQVMsY0FBYyxRQUFRO0tBQzNCLGdCQUFnQixNQUFNO0tBRXRCLElBQUksWUFBWSxXQUFXLE9BQU87S0FDbEMsSUFBSSxVQUFVLFVBQVU7S0FFeEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO01BQ3JDLElBQUksU0FBUyxRQUFRO01BQ3JCLElBQUksT0FBTyxRQUFRLElBQUk7T0FDbkIsT0FBTyxRQUFRLEdBQUcsTUFBTTtPQUN4QixPQUFPLFFBQVEsS0FBSztNQUN4QjtLQUNKO0tBQ0EsT0FBTyxLQUFLO0tBRVosT0FBTyx1QkFBdUIsTUFBTSxDQUFDLENBQUMsS0FBSyxTQUFVLElBQUk7TUFDckQsT0FBTyxLQUFLO01BQ1osSUFBSSxpQkFBaUIsTUFBTSxHQUV2QixPQUFPLHVCQUF1QixNQUFNO01BRXhDLE9BQU87S0FDWCxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVUsSUFBSTtNQUdsQixPQUFPLEtBQUssVUFBVSxLQUFLO01BQzNCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FDaEMsUUFBUSxFQUFFLENBQUMsUUFBUSxLQUFLO0tBRWhDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFVLEtBQUs7TUFDdkIsaUJBQWlCLFFBQVEsR0FBRztNQUM1QixNQUFNO0tBQ1YsQ0FBQztJQUNMO0lBSUEsU0FBUyxrQkFBa0IsUUFBUSxNQUFNLFVBQVUsU0FBUztLQUN4RCxJQUFJLFlBQVksS0FBQSxHQUNaLFVBQVU7S0FHZCxJQUFJO01BRUEsU0FBUyxNQURBLE9BQU8sR0FBRyxZQUFZLE9BQU8sV0FBVyxJQUNqQyxDQUFDO0tBQ3JCLFNBQVMsS0FBSztNQUNWLElBQUksVUFBVSxNQUFNLENBQUMsT0FBTyxNQUFNLElBQUksU0FBUyx1QkFBdUIsSUFBSSxTQUFTLGtCQUMvRSxPQUFPLFVBQVUsUUFBUSxDQUFDLENBQUMsS0FBSyxXQUFZO09BQ3hDLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBSSxTQUFTLG1CQUFtQixDQUFDLE9BQU8sR0FBRyxpQkFBaUIsU0FBUyxPQUFPLFNBQVMsS0FBSyxPQUFPLFdBQVcsT0FBTyxHQUFHLFNBQVM7UUFFN0ksSUFBSSxPQUFPLElBQ1AsT0FBTyxVQUFVLE9BQU8sR0FBRyxVQUFVO1FBR3pDLE9BQU8sdUJBQXVCLE1BQU07T0FDeEM7TUFDSixDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVk7T0FDaEIsT0FBTyxjQUFjLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBWTtRQUMxQyxrQkFBa0IsUUFBUSxNQUFNLFVBQVUsVUFBVSxDQUFDO09BQ3pELENBQUM7TUFDTCxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUTtNQUd4QixTQUFTLEdBQUc7S0FDaEI7SUFDSjtJQUVBLFNBQVMsa0JBQWtCO0tBQ3ZCLE9BQU87TUFFSCxTQUFTLENBQUM7TUFFVixJQUFJO01BRUosU0FBUztNQUVULG9CQUFvQixDQUFDO0tBQ3pCO0lBQ0o7SUFJQSxTQUFTLGFBQWEsU0FBUztLQUMzQixJQUFJLE9BQU87S0FDWCxJQUFJLFNBQVMsRUFDVCxJQUFJLEtBQ1I7S0FFQSxJQUFJLFNBQ0EsS0FBSyxJQUFJLEtBQUssU0FDVixPQUFPLEtBQUssUUFBUTtLQUs1QixJQUFJLFlBQVksV0FBVyxPQUFPO0tBR2xDLElBQUksQ0FBQyxXQUFXO01BQ1osWUFBWSxnQkFBZ0I7TUFFNUIsV0FBVyxPQUFPLFFBQVE7S0FDOUI7S0FHQSxVQUFVLFFBQVEsS0FBSyxJQUFJO0tBRzNCLElBQUksQ0FBQyxLQUFLLFlBQVk7TUFDbEIsS0FBSyxhQUFhLEtBQUs7TUFDdkIsS0FBSyxRQUFRO0tBQ2pCO0tBR0EsSUFBSSxlQUFlLENBQUM7S0FFcEIsU0FBUyxlQUFlO01BR3BCLE9BQU8sVUFBVSxRQUFRO0tBQzdCO0tBRUEsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxRQUFRLEtBQUs7TUFDL0MsSUFBSSxTQUFTLFVBQVUsUUFBUTtNQUMvQixJQUFJLFdBQVcsTUFFWCxhQUFhLEtBQUssT0FBTyxXQUFXLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDO0tBRXBFO0tBR0EsSUFBSSxVQUFVLFVBQVUsUUFBUSxNQUFNLENBQUM7S0FJdkMsT0FBTyxVQUFVLElBQUksWUFBWSxDQUFDLENBQUMsS0FBSyxXQUFZO01BQ2hELE9BQU8sS0FBSyxVQUFVO01BRXRCLE9BQU8sdUJBQXVCLE1BQU07S0FDeEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFVLElBQUk7TUFDbEIsT0FBTyxLQUFLO01BQ1osSUFBSSxpQkFBaUIsUUFBUSxLQUFLLGVBQWUsT0FBTyxHQUVwRCxPQUFPLHVCQUF1QixNQUFNO01BRXhDLE9BQU87S0FDWCxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVUsSUFBSTtNQUNsQixPQUFPLEtBQUssVUFBVSxLQUFLO01BQzNCLEtBQUssVUFBVTtNQUVmLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztPQUNyQyxJQUFJLFNBQVMsUUFBUTtPQUNyQixJQUFJLFdBQVcsTUFBTTtRQUVqQixPQUFPLFFBQVEsS0FBSyxPQUFPO1FBQzNCLE9BQU8sUUFBUSxVQUFVLE9BQU87T0FDcEM7TUFDSjtLQUNKLENBQUM7SUFDTDtJQUVBLFNBQVMsUUFBUSxLQUFLLFVBQVU7S0FDNUIsSUFBSSxPQUFPO0tBRVgsTUFBTSxhQUFhLEdBQUc7S0FFdEIsSUFBSSxVQUFVLElBQUksVUFBVSxTQUFVLFNBQVMsUUFBUTtNQUNuRCxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBWTtPQUMxQixrQkFBa0IsS0FBSyxTQUFTLFdBQVcsU0FBVSxLQUFLLGFBQWE7UUFDbkUsSUFBSSxLQUNBLE9BQU8sT0FBTyxHQUFHO1FBR3JCLElBQUk7U0FFQSxJQUFJLE1BRFEsWUFBWSxZQUFZLEtBQUssUUFBUSxTQUNuQyxDQUFDLENBQUMsSUFBSSxHQUFHO1NBRXZCLElBQUksWUFBWSxXQUFZO1VBQ3hCLElBQUksUUFBUSxJQUFJO1VBQ2hCLElBQUksVUFBVSxLQUFBLEdBQ1YsUUFBUTtVQUVaLElBQUksZUFBZSxLQUFLLEdBQ3BCLFFBQVEsWUFBWSxLQUFLO1VBRTdCLFFBQVEsS0FBSztTQUNqQjtTQUVBLElBQUksVUFBVSxXQUFZO1VBQ3RCLE9BQU8sSUFBSSxLQUFLO1NBQ3BCO1FBQ0osU0FBUyxHQUFHO1NBQ1IsT0FBTyxDQUFDO1FBQ1o7T0FDSixDQUFDO01BQ0wsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU07S0FDdEIsQ0FBQztLQUVELGdCQUFnQixTQUFTLFFBQVE7S0FDakMsT0FBTztJQUNYO0lBR0EsU0FBUyxRQUFRLFVBQVUsVUFBVTtLQUNqQyxJQUFJLE9BQU87S0FFWCxJQUFJLFVBQVUsSUFBSSxVQUFVLFNBQVUsU0FBUyxRQUFRO01BQ25ELEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxXQUFZO09BQzFCLGtCQUFrQixLQUFLLFNBQVMsV0FBVyxTQUFVLEtBQUssYUFBYTtRQUNuRSxJQUFJLEtBQ0EsT0FBTyxPQUFPLEdBQUc7UUFHckIsSUFBSTtTQUVBLElBQUksTUFEUSxZQUFZLFlBQVksS0FBSyxRQUFRLFNBQ25DLENBQUMsQ0FBQyxXQUFXO1NBQzNCLElBQUksa0JBQWtCO1NBRXRCLElBQUksWUFBWSxXQUFZO1VBQ3hCLElBQUksU0FBUyxJQUFJO1VBRWpCLElBQUksUUFBUTtXQUNSLElBQUksUUFBUSxPQUFPO1dBQ25CLElBQUksZUFBZSxLQUFLLEdBQ3BCLFFBQVEsWUFBWSxLQUFLO1dBRTdCLElBQUksU0FBUyxTQUFTLE9BQU8sT0FBTyxLQUFLLGlCQUFpQjtXQUsxRCxJQUFJLFdBQVcsS0FBSyxHQUNoQixRQUFRLE1BQU07Z0JBRWQsT0FBTyxXQUFXLENBQUM7VUFFM0IsT0FDSSxRQUFRO1NBRWhCO1NBRUEsSUFBSSxVQUFVLFdBQVk7VUFDdEIsT0FBTyxJQUFJLEtBQUs7U0FDcEI7UUFDSixTQUFTLEdBQUc7U0FDUixPQUFPLENBQUM7UUFDWjtPQUNKLENBQUM7TUFDTCxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTTtLQUN0QixDQUFDO0tBRUQsZ0JBQWdCLFNBQVMsUUFBUTtLQUVqQyxPQUFPO0lBQ1g7SUFFQSxTQUFTLFFBQVEsS0FBSyxPQUFPLFVBQVU7S0FDbkMsSUFBSSxPQUFPO0tBRVgsTUFBTSxhQUFhLEdBQUc7S0FFdEIsSUFBSSxVQUFVLElBQUksVUFBVSxTQUFVLFNBQVMsUUFBUTtNQUNuRCxJQUFJO01BQ0osS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLFdBQVk7T0FDMUIsU0FBUyxLQUFLO09BQ2QsSUFBSSxTQUFTLEtBQUssS0FBSyxNQUFNLGlCQUN6QixPQUFPLGtCQUFrQixPQUFPLEVBQUUsQ0FBQyxDQUFDLEtBQUssU0FBVSxhQUFhO1FBQzVELElBQUksYUFDQSxPQUFPO1FBRVgsT0FBTyxZQUFZLEtBQUs7T0FDNUIsQ0FBQztPQUVMLE9BQU87TUFDWCxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVUsT0FBTztPQUNyQixrQkFBa0IsS0FBSyxTQUFTLFlBQVksU0FBVSxLQUFLLGFBQWE7UUFDcEUsSUFBSSxLQUNBLE9BQU8sT0FBTyxHQUFHO1FBR3JCLElBQUk7U0FDQSxJQUFJLFFBQVEsWUFBWSxZQUFZLEtBQUssUUFBUSxTQUFTO1NBTTFELElBQUksVUFBVSxNQUNWLFFBQVEsS0FBQTtTQUdaLElBQUksTUFBTSxNQUFNLElBQUksT0FBTyxHQUFHO1NBRTlCLFlBQVksYUFBYSxXQUFZO1VBT2pDLElBQUksVUFBVSxLQUFBLEdBQ1YsUUFBUTtVQUdaLFFBQVEsS0FBSztTQUNqQjtTQUNBLFlBQVksVUFBVSxZQUFZLFVBQVUsV0FBWTtVQUVwRCxPQURVLElBQUksUUFBUSxJQUFJLFFBQVEsSUFBSSxZQUFZLEtBQ3hDO1NBQ2Q7UUFDSixTQUFTLEdBQUc7U0FDUixPQUFPLENBQUM7UUFDWjtPQUNKLENBQUM7TUFDTCxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTTtLQUN0QixDQUFDO0tBRUQsZ0JBQWdCLFNBQVMsUUFBUTtLQUNqQyxPQUFPO0lBQ1g7SUFFQSxTQUFTLFdBQVcsS0FBSyxVQUFVO0tBQy9CLElBQUksT0FBTztLQUVYLE1BQU0sYUFBYSxHQUFHO0tBRXRCLElBQUksVUFBVSxJQUFJLFVBQVUsU0FBVSxTQUFTLFFBQVE7TUFDbkQsS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLFdBQVk7T0FDMUIsa0JBQWtCLEtBQUssU0FBUyxZQUFZLFNBQVUsS0FBSyxhQUFhO1FBQ3BFLElBQUksS0FDQSxPQUFPLE9BQU8sR0FBRztRQUdyQixJQUFJO1NBT0EsSUFBSSxNQU5RLFlBQVksWUFBWSxLQUFLLFFBQVEsU0FNbkMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHO1NBQzdCLFlBQVksYUFBYSxXQUFZO1VBQ2pDLFFBQVE7U0FDWjtTQUVBLFlBQVksVUFBVSxXQUFZO1VBQzlCLE9BQU8sSUFBSSxLQUFLO1NBQ3BCO1NBSUEsWUFBWSxVQUFVLFdBQVk7VUFFOUIsT0FEVSxJQUFJLFFBQVEsSUFBSSxRQUFRLElBQUksWUFBWSxLQUN4QztTQUNkO1FBQ0osU0FBUyxHQUFHO1NBQ1IsT0FBTyxDQUFDO1FBQ1o7T0FDSixDQUFDO01BQ0wsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU07S0FDdEIsQ0FBQztLQUVELGdCQUFnQixTQUFTLFFBQVE7S0FDakMsT0FBTztJQUNYO0lBRUEsU0FBUyxNQUFNLFVBQVU7S0FDckIsSUFBSSxPQUFPO0tBRVgsSUFBSSxVQUFVLElBQUksVUFBVSxTQUFVLFNBQVMsUUFBUTtNQUNuRCxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBWTtPQUMxQixrQkFBa0IsS0FBSyxTQUFTLFlBQVksU0FBVSxLQUFLLGFBQWE7UUFDcEUsSUFBSSxLQUNBLE9BQU8sT0FBTyxHQUFHO1FBR3JCLElBQUk7U0FFQSxJQUFJLE1BRFEsWUFBWSxZQUFZLEtBQUssUUFBUSxTQUNuQyxDQUFDLENBQUMsTUFBTTtTQUV0QixZQUFZLGFBQWEsV0FBWTtVQUNqQyxRQUFRO1NBQ1o7U0FFQSxZQUFZLFVBQVUsWUFBWSxVQUFVLFdBQVk7VUFFcEQsT0FEVSxJQUFJLFFBQVEsSUFBSSxRQUFRLElBQUksWUFBWSxLQUN4QztTQUNkO1FBQ0osU0FBUyxHQUFHO1NBQ1IsT0FBTyxDQUFDO1FBQ1o7T0FDSixDQUFDO01BQ0wsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU07S0FDdEIsQ0FBQztLQUVELGdCQUFnQixTQUFTLFFBQVE7S0FDakMsT0FBTztJQUNYO0lBRUEsU0FBUyxPQUFPLFVBQVU7S0FDdEIsSUFBSSxPQUFPO0tBRVgsSUFBSSxVQUFVLElBQUksVUFBVSxTQUFVLFNBQVMsUUFBUTtNQUNuRCxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBWTtPQUMxQixrQkFBa0IsS0FBSyxTQUFTLFdBQVcsU0FBVSxLQUFLLGFBQWE7UUFDbkUsSUFBSSxLQUNBLE9BQU8sT0FBTyxHQUFHO1FBR3JCLElBQUk7U0FFQSxJQUFJLE1BRFEsWUFBWSxZQUFZLEtBQUssUUFBUSxTQUNuQyxDQUFDLENBQUMsTUFBTTtTQUV0QixJQUFJLFlBQVksV0FBWTtVQUN4QixRQUFRLElBQUksTUFBTTtTQUN0QjtTQUVBLElBQUksVUFBVSxXQUFZO1VBQ3RCLE9BQU8sSUFBSSxLQUFLO1NBQ3BCO1FBQ0osU0FBUyxHQUFHO1NBQ1IsT0FBTyxDQUFDO1FBQ1o7T0FDSixDQUFDO01BQ0wsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU07S0FDdEIsQ0FBQztLQUVELGdCQUFnQixTQUFTLFFBQVE7S0FDakMsT0FBTztJQUNYO0lBRUEsU0FBUyxJQUFJLEdBQUcsVUFBVTtLQUN0QixJQUFJLE9BQU87S0FFWCxJQUFJLFVBQVUsSUFBSSxVQUFVLFNBQVUsU0FBUyxRQUFRO01BQ25ELElBQUksSUFBSSxHQUFHO09BQ1AsUUFBUSxJQUFJO09BRVo7TUFDSjtNQUVBLEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxXQUFZO09BQzFCLGtCQUFrQixLQUFLLFNBQVMsV0FBVyxTQUFVLEtBQUssYUFBYTtRQUNuRSxJQUFJLEtBQ0EsT0FBTyxPQUFPLEdBQUc7UUFHckIsSUFBSTtTQUNBLElBQUksUUFBUSxZQUFZLFlBQVksS0FBSyxRQUFRLFNBQVM7U0FDMUQsSUFBSSxXQUFXO1NBQ2YsSUFBSSxNQUFNLE1BQU0sY0FBYztTQUU5QixJQUFJLFlBQVksV0FBWTtVQUN4QixJQUFJLFNBQVMsSUFBSTtVQUNqQixJQUFJLENBQUMsUUFBUTtXQUVULFFBQVEsSUFBSTtXQUVaO1VBQ0o7VUFFQSxJQUFJLE1BQU0sR0FHTixRQUFRLE9BQU8sR0FBRztlQUVsQixJQUFJLENBQUMsVUFBVTtXQUdYLFdBQVc7V0FDWCxPQUFPLFFBQVEsQ0FBQztVQUNwQixPQUVJLFFBQVEsT0FBTyxHQUFHO1NBRzlCO1NBRUEsSUFBSSxVQUFVLFdBQVk7VUFDdEIsT0FBTyxJQUFJLEtBQUs7U0FDcEI7UUFDSixTQUFTLEdBQUc7U0FDUixPQUFPLENBQUM7UUFDWjtPQUNKLENBQUM7TUFDTCxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTTtLQUN0QixDQUFDO0tBRUQsZ0JBQWdCLFNBQVMsUUFBUTtLQUNqQyxPQUFPO0lBQ1g7SUFFQSxTQUFTLEtBQUssVUFBVTtLQUNwQixJQUFJLE9BQU87S0FFWCxJQUFJLFVBQVUsSUFBSSxVQUFVLFNBQVUsU0FBUyxRQUFRO01BQ25ELEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxXQUFZO09BQzFCLGtCQUFrQixLQUFLLFNBQVMsV0FBVyxTQUFVLEtBQUssYUFBYTtRQUNuRSxJQUFJLEtBQ0EsT0FBTyxPQUFPLEdBQUc7UUFHckIsSUFBSTtTQUVBLElBQUksTUFEUSxZQUFZLFlBQVksS0FBSyxRQUFRLFNBQ25DLENBQUMsQ0FBQyxjQUFjO1NBQzlCLElBQUksT0FBTyxDQUFDO1NBRVosSUFBSSxZQUFZLFdBQVk7VUFDeEIsSUFBSSxTQUFTLElBQUk7VUFFakIsSUFBSSxDQUFDLFFBQVE7V0FDVCxRQUFRLElBQUk7V0FDWjtVQUNKO1VBRUEsS0FBSyxLQUFLLE9BQU8sR0FBRztVQUNwQixPQUFPLFdBQVcsQ0FBQztTQUN2QjtTQUVBLElBQUksVUFBVSxXQUFZO1VBQ3RCLE9BQU8sSUFBSSxLQUFLO1NBQ3BCO1FBQ0osU0FBUyxHQUFHO1NBQ1IsT0FBTyxDQUFDO1FBQ1o7T0FDSixDQUFDO01BQ0wsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU07S0FDdEIsQ0FBQztLQUVELGdCQUFnQixTQUFTLFFBQVE7S0FDakMsT0FBTztJQUNYO0lBRUEsU0FBUyxhQUFhLFNBQVMsVUFBVTtLQUNyQyxXQUFXLFlBQVksTUFBTSxNQUFNLFNBQVM7S0FFNUMsSUFBSSxnQkFBZ0IsS0FBSyxPQUFPO0tBQ2hDLFVBQVUsT0FBTyxZQUFZLGNBQWMsV0FBVyxDQUFDO0tBQ3ZELElBQUksQ0FBQyxRQUFRLE1BQU07TUFDZixRQUFRLE9BQU8sUUFBUSxRQUFRLGNBQWM7TUFDN0MsUUFBUSxZQUFZLFFBQVEsYUFBYSxjQUFjO0tBQzNEO0tBRUEsSUFBSSxPQUFPO0tBQ1gsSUFBSTtLQUNKLElBQUksQ0FBQyxRQUFRLE1BQ1QsVUFBVSxVQUFVLE9BQU8sbUJBQW1CO1VBQzNDO01BR0gsSUFBSSxZQUZjLFFBQVEsU0FBUyxjQUFjLFFBQVEsS0FBSyxRQUFRLEtBRXhDLFVBQVUsUUFBUSxLQUFLLFFBQVEsRUFBRSxJQUFJLHVCQUF1QixPQUFPLENBQUMsQ0FBQyxLQUFLLFNBQVUsSUFBSTtPQUNsSCxJQUFJLFlBQVksV0FBVyxRQUFRO09BQ25DLElBQUksVUFBVSxVQUFVO09BQ3hCLFVBQVUsS0FBSztPQUNmLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FDaEMsUUFBUSxFQUFFLENBQUMsUUFBUSxLQUFLO09BRTVCLE9BQU87TUFDWCxDQUFDO01BRUQsSUFBSSxDQUFDLFFBQVEsV0FDVCxVQUFVLFVBQVUsS0FBSyxTQUFVLElBQUk7T0FDbkMsZ0JBQWdCLE9BQU87T0FFdkIsSUFBSSxZQUFZLFdBQVcsUUFBUTtPQUNuQyxJQUFJLFVBQVUsVUFBVTtPQUV4QixHQUFHLE1BQU07T0FDVCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7UUFDckMsSUFBSSxTQUFTLFFBQVE7UUFDckIsT0FBTyxRQUFRLEtBQUs7T0FDeEI7T0E0QkEsT0FBTyxJQTFCaUIsVUFBVSxTQUFVLFNBQVMsUUFBUTtRQUN6RCxJQUFJLE1BQU0sSUFBSSxlQUFlLFFBQVEsSUFBSTtRQUV6QyxJQUFJLFVBQVUsV0FBWTtTQUN0QixJQUFJLEtBQUssSUFBSTtTQUNiLElBQUksSUFDQSxHQUFHLE1BQU07U0FFYixPQUFPLElBQUksS0FBSztRQUNwQjtRQUVBLElBQUksWUFBWSxXQUFZO1NBR3hCLFFBQVEsS0FBSyx5Q0FBd0MsUUFBUSxPQUFPLDBDQUF5QztRQUNqSDtRQUVBLElBQUksWUFBWSxXQUFZO1NBQ3hCLElBQUksS0FBSyxJQUFJO1NBQ2IsSUFBSSxJQUNBLEdBQUcsTUFBTTtTQUViLFFBQVEsRUFBRTtRQUNkO09BQ0osQ0FFbUIsQ0FBQyxDQUFDLEtBQUssU0FBVSxJQUFJO1FBQ3BDLFVBQVUsS0FBSztRQUNmLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztTQUNyQyxJQUFJLFVBQVUsUUFBUTtTQUN0QixrQkFBa0IsUUFBUSxPQUFPO1FBQ3JDO09BQ0osQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVUsS0FBSztRQUN2QixDQUFDLGlCQUFpQixTQUFTLEdBQUcsS0FBSyxVQUFVLFFBQVEsRUFBQSxDQUFHLFFBQVEsQ0FBQyxXQUFZLENBQUMsQ0FBQztRQUMvRSxNQUFNO09BQ1YsQ0FBQztNQUNMLENBQUM7V0FFRCxVQUFVLFVBQVUsS0FBSyxTQUFVLElBQUk7T0FDbkMsSUFBSSxDQUFDLEdBQUcsaUJBQWlCLFNBQVMsUUFBUSxTQUFTLEdBQy9DO09BR0osSUFBSSxhQUFhLEdBQUcsVUFBVTtPQUU5QixnQkFBZ0IsT0FBTztPQUV2QixJQUFJLFlBQVksV0FBVyxRQUFRO09BQ25DLElBQUksVUFBVSxVQUFVO09BRXhCLEdBQUcsTUFBTTtPQUNULEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztRQUNyQyxJQUFJLFNBQVMsUUFBUTtRQUNyQixPQUFPLFFBQVEsS0FBSztRQUNwQixPQUFPLFFBQVEsVUFBVTtPQUM3QjtPQXVCQSxPQUFPLElBckJxQixVQUFVLFNBQVUsU0FBUyxRQUFRO1FBQzdELElBQUksTUFBTSxJQUFJLEtBQUssUUFBUSxNQUFNLFVBQVU7UUFFM0MsSUFBSSxVQUFVLFNBQVUsS0FBSztTQUV6QixJQURhLE9BQ1YsTUFBTTtTQUNULE9BQU8sR0FBRztRQUNkO1FBRUEsSUFBSSxrQkFBa0IsV0FBWTtTQUU5QixJQURhLE9BQ1Ysa0JBQWtCLFFBQVEsU0FBUztRQUMxQztRQUVBLElBQUksWUFBWSxXQUFZO1NBQ3hCLElBQUksS0FBSyxJQUFJO1NBQ2IsR0FBRyxNQUFNO1NBQ1QsUUFBUSxFQUFFO1FBQ2Q7T0FDSixDQUV1QixDQUFDLENBQUMsS0FBSyxTQUFVLElBQUk7UUFDeEMsVUFBVSxLQUFLO1FBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO1NBQ3JDLElBQUksV0FBVyxRQUFRO1NBQ3ZCLFNBQVMsUUFBUSxLQUFLO1NBQ3RCLGtCQUFrQixTQUFTLE9BQU87UUFDdEM7T0FDSixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBVSxLQUFLO1FBQ3ZCLENBQUMsaUJBQWlCLFNBQVMsR0FBRyxLQUFLLFVBQVUsUUFBUSxFQUFBLENBQUcsUUFBUSxDQUFDLFdBQVksQ0FBQyxDQUFDO1FBQy9FLE1BQU07T0FDVixDQUFDO01BQ0wsQ0FBQztLQUVUO0tBRUEsZ0JBQWdCLFNBQVMsUUFBUTtLQUNqQyxPQUFPO0lBQ1g7SUFFQSxJQUFJLGVBQWU7S0FDZixTQUFTO0tBQ0s7S0FDZCxVQUFVLGlCQUFpQjtLQUNsQjtLQUNBO0tBQ0E7S0FDRztLQUNMO0tBQ0M7S0FDSDtLQUNDO0tBQ1E7SUFDbEI7SUFFQSxTQUFTLGdCQUFnQjtLQUNyQixPQUFPLE9BQU8saUJBQWlCO0lBQ25DO0lBS0EsSUFBSSxhQUFhO0lBRWpCLElBQUksbUJBQW1CO0lBQ3ZCLElBQUkseUJBQXlCO0lBRTdCLElBQUksb0JBQW9CO0lBQ3hCLElBQUksMkJBQTJCLGtCQUFrQjtJQUdqRCxJQUFJLG1CQUFtQjtJQUN2QixJQUFJLFlBQVk7SUFDaEIsSUFBSSxpQkFBaUI7SUFDckIsSUFBSSxrQkFBa0I7SUFDdEIsSUFBSSx5QkFBeUI7SUFDN0IsSUFBSSxrQkFBa0I7SUFDdEIsSUFBSSxrQkFBa0I7SUFDdEIsSUFBSSxtQkFBbUI7SUFDdkIsSUFBSSxtQkFBbUI7SUFDdkIsSUFBSSxvQkFBb0I7SUFDeEIsSUFBSSxvQkFBb0I7SUFDeEIsSUFBSSxnQ0FBZ0MsMkJBQTJCLGlCQUFpQjtJQUVoRixJQUFJLGFBQWEsT0FBTyxVQUFVO0lBRWxDLFNBQVMsZUFBZSxrQkFBa0I7S0FFdEMsSUFBSSxlQUFlLGlCQUFpQixTQUFTO0tBQzdDLElBQUksTUFBTSxpQkFBaUI7S0FDM0IsSUFBSTtLQUNKLElBQUksSUFBSTtLQUNSLElBQUksVUFBVSxVQUFVLFVBQVU7S0FFbEMsSUFBSSxpQkFBaUIsaUJBQWlCLFNBQVMsT0FBTyxLQUFLO01BQ3ZEO01BQ0EsSUFBSSxpQkFBaUIsaUJBQWlCLFNBQVMsT0FBTyxLQUNsRDtLQUVSO0tBRUEsSUFBSSxTQUFTLElBQUksWUFBWSxZQUFZO0tBQ3pDLElBQUksUUFBUSxJQUFJLFdBQVcsTUFBTTtLQUVqQyxLQUFLLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSyxHQUFHO01BQ3pCLFdBQVcsV0FBVyxRQUFRLGlCQUFpQixFQUFFO01BQ2pELFdBQVcsV0FBVyxRQUFRLGlCQUFpQixJQUFJLEVBQUU7TUFDckQsV0FBVyxXQUFXLFFBQVEsaUJBQWlCLElBQUksRUFBRTtNQUNyRCxXQUFXLFdBQVcsUUFBUSxpQkFBaUIsSUFBSSxFQUFFO01BR3JELE1BQU0sT0FBTyxZQUFZLElBQUksWUFBWTtNQUN6QyxNQUFNLFFBQVEsV0FBVyxPQUFPLElBQUksWUFBWTtNQUNoRCxNQUFNLFFBQVEsV0FBVyxNQUFNLElBQUksV0FBVztLQUNsRDtLQUNBLE9BQU87SUFDWDtJQUlBLFNBQVMsZUFBZSxRQUFRO0tBRTVCLElBQUksUUFBUSxJQUFJLFdBQVcsTUFBTTtLQUNqQyxJQUFJLGVBQWU7S0FDbkIsSUFBSTtLQUVKLEtBQUssSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRztNQUVsQyxnQkFBZ0IsV0FBVyxNQUFNLE1BQU07TUFDdkMsZ0JBQWdCLFlBQVksTUFBTSxLQUFLLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTTtNQUNqRSxnQkFBZ0IsWUFBWSxNQUFNLElBQUksS0FBSyxPQUFPLElBQUksTUFBTSxJQUFJLE1BQU07TUFDdEUsZ0JBQWdCLFdBQVcsTUFBTSxJQUFJLEtBQUs7S0FDOUM7S0FFQSxJQUFJLE1BQU0sU0FBUyxNQUFNLEdBQ3JCLGVBQWUsYUFBYSxVQUFVLEdBQUcsYUFBYSxTQUFTLENBQUMsSUFBSTtVQUNqRSxJQUFJLE1BQU0sU0FBUyxNQUFNLEdBQzVCLGVBQWUsYUFBYSxVQUFVLEdBQUcsYUFBYSxTQUFTLENBQUMsSUFBSTtLQUd4RSxPQUFPO0lBQ1g7SUFLQSxTQUFTLFVBQVUsT0FBTyxVQUFVO0tBQ2hDLElBQUksWUFBWTtLQUNoQixJQUFJLE9BQ0EsWUFBWSxXQUFXLEtBQUssS0FBSztLQU9yQyxJQUFJLFVBQVUsY0FBYywwQkFBMEIsTUFBTSxVQUFVLFdBQVcsS0FBSyxNQUFNLE1BQU0sTUFBTSx5QkFBeUI7TUFHN0gsSUFBSTtNQUNKLElBQUksU0FBUztNQUViLElBQUksaUJBQWlCLGFBQWE7T0FDOUIsU0FBUztPQUNULFVBQVU7TUFDZCxPQUFPO09BQ0gsU0FBUyxNQUFNO09BRWYsSUFBSSxjQUFjLHNCQUNkLFVBQVU7WUFDUCxJQUFJLGNBQWMsdUJBQ3JCLFVBQVU7WUFDUCxJQUFJLGNBQWMsOEJBQ3JCLFVBQVU7WUFDUCxJQUFJLGNBQWMsdUJBQ3JCLFVBQVU7WUFDUCxJQUFJLGNBQWMsd0JBQ3JCLFVBQVU7WUFDUCxJQUFJLGNBQWMsdUJBQ3JCLFVBQVU7WUFDUCxJQUFJLGNBQWMsd0JBQ3JCLFVBQVU7WUFDUCxJQUFJLGNBQWMseUJBQ3JCLFVBQVU7WUFDUCxJQUFJLGNBQWMseUJBQ3JCLFVBQVU7WUFFVix5QkFBUyxJQUFJLE1BQU0sb0NBQW9DLENBQUM7TUFFaEU7TUFFQSxTQUFTLFNBQVMsZUFBZSxNQUFNLENBQUM7S0FDNUMsT0FBTyxJQUFJLGNBQWMsaUJBQWlCO01BRXRDLElBQUksYUFBYSxJQUFJLFdBQVc7TUFFaEMsV0FBVyxTQUFTLFdBQVk7T0FFNUIsSUFBSSxNQUFNLG1CQUFtQixNQUFNLE9BQU8sTUFBTSxlQUFlLEtBQUssTUFBTTtPQUUxRSxTQUFTLG9CQUFvQixZQUFZLEdBQUc7TUFDaEQ7TUFFQSxXQUFXLGtCQUFrQixLQUFLO0tBQ3RDLE9BQ0ksSUFBSTtNQUNBLFNBQVMsS0FBSyxVQUFVLEtBQUssQ0FBQztLQUNsQyxTQUFTLEdBQUc7TUFDUixRQUFRLE1BQU0sK0NBQStDLEtBQUs7TUFFbEUsU0FBUyxNQUFNLENBQUM7S0FDcEI7SUFFUjtJQVVBLFNBQVMsWUFBWSxPQUFPO0tBSXhCLElBQUksTUFBTSxVQUFVLEdBQUcsd0JBQXdCLE1BQU0sbUJBQ2pELE9BQU8sS0FBSyxNQUFNLEtBQUs7S0FNM0IsSUFBSSxtQkFBbUIsTUFBTSxVQUFVLDZCQUE2QjtLQUNwRSxJQUFJLE9BQU8sTUFBTSxVQUFVLDBCQUEwQiw2QkFBNkI7S0FFbEYsSUFBSTtLQUdKLElBQUksU0FBUyxhQUFhLHVCQUF1QixLQUFLLGdCQUFnQixHQUFHO01BQ3JFLElBQUksVUFBVSxpQkFBaUIsTUFBTSxzQkFBc0I7TUFDM0QsV0FBVyxRQUFRO01BQ25CLG1CQUFtQixpQkFBaUIsVUFBVSxRQUFRLEVBQUUsQ0FBQyxNQUFNO0tBQ25FO0tBQ0EsSUFBSSxTQUFTLGVBQWUsZ0JBQWdCO0tBSTVDLFFBQVEsTUFBUjtNQUNJLEtBQUssa0JBQ0QsT0FBTztNQUNYLEtBQUssV0FDRCxPQUFPLFdBQVcsQ0FBQyxNQUFNLEdBQUcsRUFBRSxNQUFNLFNBQVMsQ0FBQztNQUNsRCxLQUFLLGdCQUNELE9BQU8sSUFBSSxVQUFVLE1BQU07TUFDL0IsS0FBSyxpQkFDRCxPQUFPLElBQUksV0FBVyxNQUFNO01BQ2hDLEtBQUssd0JBQ0QsT0FBTyxJQUFJLGtCQUFrQixNQUFNO01BQ3ZDLEtBQUssaUJBQ0QsT0FBTyxJQUFJLFdBQVcsTUFBTTtNQUNoQyxLQUFLLGtCQUNELE9BQU8sSUFBSSxZQUFZLE1BQU07TUFDakMsS0FBSyxpQkFDRCxPQUFPLElBQUksV0FBVyxNQUFNO01BQ2hDLEtBQUssa0JBQ0QsT0FBTyxJQUFJLFlBQVksTUFBTTtNQUNqQyxLQUFLLG1CQUNELE9BQU8sSUFBSSxhQUFhLE1BQU07TUFDbEMsS0FBSyxtQkFDRCxPQUFPLElBQUksYUFBYSxNQUFNO01BQ2xDLFNBQ0ksTUFBTSxJQUFJLE1BQU0sa0JBQWtCLElBQUk7S0FDOUM7SUFDSjtJQUVBLElBQUksd0JBQXdCO0tBQ2I7S0FDRTtLQUNHO0tBQ0E7SUFDcEI7SUFZQSxTQUFTLGNBQWMsR0FBRyxRQUFRLFVBQVUsZUFBZTtLQUN2RCxFQUFFLFdBQVcsZ0NBQWdDLE9BQU8sWUFBWSxnREFBcUQsQ0FBQyxHQUFHLFVBQVUsYUFBYTtJQUNwSjtJQUlBLFNBQVMsZUFBZSxTQUFTO0tBQzdCLElBQUksT0FBTztLQUNYLElBQUksU0FBUyxFQUNULElBQUksS0FDUjtLQUVBLElBQUksU0FDQSxLQUFLLElBQUksS0FBSyxTQUNWLE9BQU8sS0FBSyxPQUFPLFFBQVEsT0FBTyxXQUFXLFFBQVEsRUFBRSxDQUFDLFNBQVMsSUFBSSxRQUFRO0tBSXJGLElBQUksZ0JBQWdCLElBQUksVUFBVSxTQUFVLFNBQVMsUUFBUTtNQUd6RCxJQUFJO09BQ0EsT0FBTyxLQUFLLGFBQWEsT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLEdBQUcsT0FBTyxhQUFhLE9BQU8sSUFBSTtNQUNqRyxTQUFTLEdBQUc7T0FDUixPQUFPLE9BQU8sQ0FBQztNQUNuQjtNQUdBLE9BQU8sR0FBRyxZQUFZLFNBQVUsR0FBRztPQUMvQixjQUFjLEdBQUcsUUFBUSxXQUFZO1FBQ2pDLEtBQUssVUFBVTtRQUNmLFFBQVE7T0FDWixHQUFHLFNBQVUsR0FBRyxPQUFPO1FBQ25CLE9BQU8sS0FBSztPQUNoQixDQUFDO01BQ0wsR0FBRyxNQUFNO0tBQ2IsQ0FBQztLQUVELE9BQU8sYUFBYTtLQUNwQixPQUFPO0lBQ1g7SUFFQSxTQUFTLGNBQWMsR0FBRyxRQUFRLGNBQWMsTUFBTSxVQUFVLGVBQWU7S0FDM0UsRUFBRSxXQUFXLGNBQWMsTUFBTSxVQUFVLFNBQVUsR0FBRyxPQUFPO01BQzNELElBQUksTUFBTSxTQUFTLE1BQU0sWUFDckIsRUFBRSxXQUFXLGtFQUF1RSxDQUFDLE9BQU8sU0FBUyxHQUFHLFNBQVUsR0FBRyxTQUFTO09BQzFILElBQUksQ0FBQyxRQUFRLEtBQUssUUFHZCxjQUFjLEdBQUcsUUFBUSxXQUFZO1FBQ2pDLEVBQUUsV0FBVyxjQUFjLE1BQU0sVUFBVSxhQUFhO09BQzVELEdBQUcsYUFBYTtZQUVoQixjQUFjLEdBQUcsS0FBSztNQUU5QixHQUFHLGFBQWE7V0FFaEIsY0FBYyxHQUFHLEtBQUs7S0FFOUIsR0FBRyxhQUFhO0lBQ3BCO0lBRUEsU0FBUyxVQUFVLEtBQUssVUFBVTtLQUM5QixJQUFJLE9BQU87S0FFWCxNQUFNLGFBQWEsR0FBRztLQUV0QixJQUFJLFVBQVUsSUFBSSxVQUFVLFNBQVUsU0FBUyxRQUFRO01BQ25ELEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxXQUFZO09BQzFCLElBQUksU0FBUyxLQUFLO09BQ2xCLE9BQU8sR0FBRyxZQUFZLFNBQVUsR0FBRztRQUMvQixjQUFjLEdBQUcsUUFBUSxtQkFBbUIsT0FBTyxZQUFZLDBCQUEwQixDQUFDLEdBQUcsR0FBRyxTQUFVLEdBQUcsU0FBUztTQUNsSCxJQUFJLFNBQVMsUUFBUSxLQUFLLFNBQVMsUUFBUSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUTtTQUloRSxJQUFJLFFBQ0EsU0FBUyxPQUFPLFdBQVcsWUFBWSxNQUFNO1NBR2pELFFBQVEsTUFBTTtRQUNsQixHQUFHLFNBQVUsR0FBRyxPQUFPO1NBQ25CLE9BQU8sS0FBSztRQUNoQixDQUFDO09BQ0wsQ0FBQztNQUNMLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNO0tBQ3RCLENBQUM7S0FFRCxnQkFBZ0IsU0FBUyxRQUFRO0tBQ2pDLE9BQU87SUFDWDtJQUVBLFNBQVMsVUFBVSxVQUFVLFVBQVU7S0FDbkMsSUFBSSxPQUFPO0tBRVgsSUFBSSxVQUFVLElBQUksVUFBVSxTQUFVLFNBQVMsUUFBUTtNQUNuRCxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBWTtPQUMxQixJQUFJLFNBQVMsS0FBSztPQUVsQixPQUFPLEdBQUcsWUFBWSxTQUFVLEdBQUc7UUFDL0IsY0FBYyxHQUFHLFFBQVEsbUJBQW1CLE9BQU8sV0FBVyxDQUFDLEdBQUcsU0FBVSxHQUFHLFNBQVM7U0FDcEYsSUFBSSxPQUFPLFFBQVE7U0FDbkIsSUFBSSxTQUFTLEtBQUs7U0FFbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FBSztVQUM3QixJQUFJLE9BQU8sS0FBSyxLQUFLLENBQUM7VUFDdEIsSUFBSSxTQUFTLEtBQUs7VUFJbEIsSUFBSSxRQUNBLFNBQVMsT0FBTyxXQUFXLFlBQVksTUFBTTtVQUdqRCxTQUFTLFNBQVMsUUFBUSxLQUFLLEtBQUssSUFBSSxDQUFDO1VBSXpDLElBQUksV0FBVyxLQUFLLEdBQUc7V0FDbkIsUUFBUSxNQUFNO1dBQ2Q7VUFDSjtTQUNKO1NBRUEsUUFBUTtRQUNaLEdBQUcsU0FBVSxHQUFHLE9BQU87U0FDbkIsT0FBTyxLQUFLO1FBQ2hCLENBQUM7T0FDTCxDQUFDO01BQ0wsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU07S0FDdEIsQ0FBQztLQUVELGdCQUFnQixTQUFTLFFBQVE7S0FDakMsT0FBTztJQUNYO0lBRUEsU0FBUyxTQUFTLEtBQUssT0FBTyxVQUFVLGFBQWE7S0FDakQsSUFBSSxPQUFPO0tBRVgsTUFBTSxhQUFhLEdBQUc7S0FFdEIsSUFBSSxVQUFVLElBQUksVUFBVSxTQUFVLFNBQVMsUUFBUTtNQUNuRCxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBWTtPQUkxQixJQUFJLFVBQVUsS0FBQSxHQUNWLFFBQVE7T0FJWixJQUFJLGdCQUFnQjtPQUVwQixJQUFJLFNBQVMsS0FBSztPQUNsQixPQUFPLFdBQVcsVUFBVSxPQUFPLFNBQVUsT0FBTyxPQUFPO1FBQ3ZELElBQUksT0FDQSxPQUFPLEtBQUs7YUFFWixPQUFPLEdBQUcsWUFBWSxTQUFVLEdBQUc7U0FDL0IsY0FBYyxHQUFHLFFBQVEsNEJBQTRCLE9BQU8sWUFBWSwrQkFBb0MsQ0FBQyxLQUFLLEtBQUssR0FBRyxXQUFZO1VBQ2xJLFFBQVEsYUFBYTtTQUN6QixHQUFHLFNBQVUsR0FBRyxPQUFPO1VBQ25CLE9BQU8sS0FBSztTQUNoQixDQUFDO1FBQ0wsR0FBRyxTQUFVLFVBQVU7U0FHbkIsSUFBSSxTQUFTLFNBQVMsU0FBUyxXQUFXO1VBUXRDLElBQUksY0FBYyxHQUFHO1dBQ2pCLFFBQVEsU0FBUyxNQUFNLE1BQU07WUFBQztZQUFLO1lBQWU7WUFBVSxjQUFjO1dBQUMsQ0FBQyxDQUFDO1dBQzdFO1VBQ0o7VUFDQSxPQUFPLFFBQVE7U0FDbkI7UUFDSixDQUFDO09BRVQsQ0FBQztNQUNMLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNO0tBQ3RCLENBQUM7S0FFRCxnQkFBZ0IsU0FBUyxRQUFRO0tBQ2pDLE9BQU87SUFDWDtJQUVBLFNBQVMsVUFBVSxLQUFLLE9BQU8sVUFBVTtLQUNyQyxPQUFPLFNBQVMsTUFBTSxNQUFNO01BQUM7TUFBSztNQUFPO01BQVU7S0FBQyxDQUFDO0lBQ3pEO0lBRUEsU0FBUyxhQUFhLEtBQUssVUFBVTtLQUNqQyxJQUFJLE9BQU87S0FFWCxNQUFNLGFBQWEsR0FBRztLQUV0QixJQUFJLFVBQVUsSUFBSSxVQUFVLFNBQVUsU0FBUyxRQUFRO01BQ25ELEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxXQUFZO09BQzFCLElBQUksU0FBUyxLQUFLO09BQ2xCLE9BQU8sR0FBRyxZQUFZLFNBQVUsR0FBRztRQUMvQixjQUFjLEdBQUcsUUFBUSxpQkFBaUIsT0FBTyxZQUFZLGtCQUFrQixDQUFDLEdBQUcsR0FBRyxXQUFZO1NBQzlGLFFBQVE7UUFDWixHQUFHLFNBQVUsR0FBRyxPQUFPO1NBQ25CLE9BQU8sS0FBSztRQUNoQixDQUFDO09BQ0wsQ0FBQztNQUNMLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNO0tBQ3RCLENBQUM7S0FFRCxnQkFBZ0IsU0FBUyxRQUFRO0tBQ2pDLE9BQU87SUFDWDtJQUlBLFNBQVMsUUFBUSxVQUFVO0tBQ3ZCLElBQUksT0FBTztLQUVYLElBQUksVUFBVSxJQUFJLFVBQVUsU0FBVSxTQUFTLFFBQVE7TUFDbkQsS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLFdBQVk7T0FDMUIsSUFBSSxTQUFTLEtBQUs7T0FDbEIsT0FBTyxHQUFHLFlBQVksU0FBVSxHQUFHO1FBQy9CLGNBQWMsR0FBRyxRQUFRLGlCQUFpQixPQUFPLFdBQVcsQ0FBQyxHQUFHLFdBQVk7U0FDeEUsUUFBUTtRQUNaLEdBQUcsU0FBVSxHQUFHLE9BQU87U0FDbkIsT0FBTyxLQUFLO1FBQ2hCLENBQUM7T0FDTCxDQUFDO01BQ0wsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU07S0FDdEIsQ0FBQztLQUVELGdCQUFnQixTQUFTLFFBQVE7S0FDakMsT0FBTztJQUNYO0lBSUEsU0FBUyxTQUFTLFVBQVU7S0FDeEIsSUFBSSxPQUFPO0tBRVgsSUFBSSxVQUFVLElBQUksVUFBVSxTQUFVLFNBQVMsUUFBUTtNQUNuRCxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBWTtPQUMxQixJQUFJLFNBQVMsS0FBSztPQUNsQixPQUFPLEdBQUcsWUFBWSxTQUFVLEdBQUc7UUFFL0IsY0FBYyxHQUFHLFFBQVEsaUNBQWlDLE9BQU8sV0FBVyxDQUFDLEdBQUcsU0FBVSxHQUFHLFNBQVM7U0FDbEcsSUFBSSxTQUFTLFFBQVEsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDO1NBQ2xDLFFBQVEsTUFBTTtRQUNsQixHQUFHLFNBQVUsR0FBRyxPQUFPO1NBQ25CLE9BQU8sS0FBSztRQUNoQixDQUFDO09BQ0wsQ0FBQztNQUNMLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNO0tBQ3RCLENBQUM7S0FFRCxnQkFBZ0IsU0FBUyxRQUFRO0tBQ2pDLE9BQU87SUFDWDtJQVNBLFNBQVMsTUFBTSxHQUFHLFVBQVU7S0FDeEIsSUFBSSxPQUFPO0tBRVgsSUFBSSxVQUFVLElBQUksVUFBVSxTQUFVLFNBQVMsUUFBUTtNQUNuRCxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBWTtPQUMxQixJQUFJLFNBQVMsS0FBSztPQUNsQixPQUFPLEdBQUcsWUFBWSxTQUFVLEdBQUc7UUFDL0IsY0FBYyxHQUFHLFFBQVEscUJBQXFCLE9BQU8sWUFBWSx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxTQUFVLEdBQUcsU0FBUztTQUVySCxRQURhLFFBQVEsS0FBSyxTQUFTLFFBQVEsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFDaEQ7UUFDbEIsR0FBRyxTQUFVLEdBQUcsT0FBTztTQUNuQixPQUFPLEtBQUs7UUFDaEIsQ0FBQztPQUNMLENBQUM7TUFDTCxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTTtLQUN0QixDQUFDO0tBRUQsZ0JBQWdCLFNBQVMsUUFBUTtLQUNqQyxPQUFPO0lBQ1g7SUFFQSxTQUFTLE9BQU8sVUFBVTtLQUN0QixJQUFJLE9BQU87S0FFWCxJQUFJLFVBQVUsSUFBSSxVQUFVLFNBQVUsU0FBUyxRQUFRO01BQ25ELEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxXQUFZO09BQzFCLElBQUksU0FBUyxLQUFLO09BQ2xCLE9BQU8sR0FBRyxZQUFZLFNBQVUsR0FBRztRQUMvQixjQUFjLEdBQUcsUUFBUSxxQkFBcUIsT0FBTyxXQUFXLENBQUMsR0FBRyxTQUFVLEdBQUcsU0FBUztTQUN0RixJQUFJLE9BQU8sQ0FBQztTQUVaLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUssUUFBUSxLQUNyQyxLQUFLLEtBQUssUUFBUSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRztTQUd0QyxRQUFRLElBQUk7UUFDaEIsR0FBRyxTQUFVLEdBQUcsT0FBTztTQUNuQixPQUFPLEtBQUs7UUFDaEIsQ0FBQztPQUNMLENBQUM7TUFDTCxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTTtLQUN0QixDQUFDO0tBRUQsZ0JBQWdCLFNBQVMsUUFBUTtLQUNqQyxPQUFPO0lBQ1g7SUFJQSxTQUFTLGlCQUFpQixJQUFJO0tBQzFCLE9BQU8sSUFBSSxVQUFVLFNBQVUsU0FBUyxRQUFRO01BQzVDLEdBQUcsWUFBWSxTQUFVLEdBQUc7T0FDeEIsRUFBRSxXQUFXLCtGQUFvRyxDQUFDLEdBQUcsU0FBVSxHQUFHLFNBQVM7UUFDdkksSUFBSSxhQUFhLENBQUM7UUFFbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FBSyxRQUFRLEtBQ3JDLFdBQVcsS0FBSyxRQUFRLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJO1FBRzdDLFFBQVE7U0FDQTtTQUNRO1FBQ2hCLENBQUM7T0FDTCxHQUFHLFNBQVUsR0FBRyxPQUFPO1FBQ25CLE9BQU8sS0FBSztPQUNoQixDQUFDO01BQ0wsR0FBRyxTQUFVLFVBQVU7T0FDbkIsT0FBTyxRQUFRO01BQ25CLENBQUM7S0FDTCxDQUFDO0lBQ0w7SUFFQSxTQUFTLGVBQWUsU0FBUyxVQUFVO0tBQ3ZDLFdBQVcsWUFBWSxNQUFNLE1BQU0sU0FBUztLQUU1QyxJQUFJLGdCQUFnQixLQUFLLE9BQU87S0FDaEMsVUFBVSxPQUFPLFlBQVksY0FBYyxXQUFXLENBQUM7S0FDdkQsSUFBSSxDQUFDLFFBQVEsTUFBTTtNQUNmLFFBQVEsT0FBTyxRQUFRLFFBQVEsY0FBYztNQUM3QyxRQUFRLFlBQVksUUFBUSxhQUFhLGNBQWM7S0FDM0Q7S0FFQSxJQUFJLE9BQU87S0FDWCxJQUFJO0tBQ0osSUFBSSxDQUFDLFFBQVEsTUFDVCxVQUFVLFVBQVUsT0FBTyxtQkFBbUI7VUFFOUMsVUFBVSxJQUFJLFVBQVUsU0FBVSxTQUFTO01BQ3ZDLElBQUk7TUFDSixJQUFJLFFBQVEsU0FBUyxjQUFjLE1BRS9CLEtBQUssS0FBSyxRQUFRO1dBRWxCLEtBQUssYUFBYSxRQUFRLE1BQU0sSUFBSSxJQUFJLENBQUM7TUFHN0MsSUFBSSxDQUFDLFFBQVEsV0FFVCxRQUFRLGlCQUFpQixFQUFFLENBQUM7V0FFNUIsUUFBUTtPQUNBO09BQ0osWUFBWSxDQUFDLFFBQVEsU0FBUztNQUNsQyxDQUFDO0tBRVQsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFVLGVBQWU7TUFDN0IsT0FBTyxJQUFJLFVBQVUsU0FBVSxTQUFTLFFBQVE7T0FDNUMsY0FBYyxHQUFHLFlBQVksU0FBVSxHQUFHO1FBQ3RDLFNBQVMsVUFBVSxXQUFXO1NBQzFCLE9BQU8sSUFBSSxVQUFVLFNBQVUsU0FBUyxRQUFRO1VBQzVDLEVBQUUsV0FBVywwQkFBMEIsV0FBVyxDQUFDLEdBQUcsV0FBWTtXQUM5RCxRQUFRO1VBQ1osR0FBRyxTQUFVLEdBQUcsT0FBTztXQUNuQixPQUFPLEtBQUs7VUFDaEIsQ0FBQztTQUNMLENBQUM7UUFDTDtRQUVBLElBQUksYUFBYSxDQUFDO1FBQ2xCLEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxjQUFjLFdBQVcsUUFBUSxJQUFJLEtBQUssS0FDNUQsV0FBVyxLQUFLLFVBQVUsY0FBYyxXQUFXLEVBQUUsQ0FBQztRQUcxRCxVQUFVLElBQUksVUFBVSxDQUFDLENBQUMsS0FBSyxXQUFZO1NBQ3ZDLFFBQVE7UUFDWixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBVSxHQUFHO1NBQ3JCLE9BQU8sQ0FBQztRQUNaLENBQUM7T0FDTCxHQUFHLFNBQVUsVUFBVTtRQUNuQixPQUFPLFFBQVE7T0FDbkIsQ0FBQztNQUNMLENBQUM7S0FDTCxDQUFDO0tBR0wsZ0JBQWdCLFNBQVMsUUFBUTtLQUNqQyxPQUFPO0lBQ1g7SUFFQSxJQUFJLGdCQUFnQjtLQUNoQixTQUFTO0tBQ1QsY0FBYztLQUNkLFVBQVUsY0FBYztLQUN4QixTQUFTO0tBQ1QsU0FBUztLQUNULFNBQVM7S0FDVCxZQUFZO0tBQ1osT0FBTztLQUNQLFFBQVE7S0FDUixLQUFLO0tBQ0wsTUFBTTtLQUNOLGNBQWM7SUFDbEI7SUFFQSxTQUFTLHNCQUFzQjtLQUMzQixJQUFJO01BQ0EsT0FBTyxPQUFPLGlCQUFpQixlQUFlLGFBQWEsZ0JBRTNELENBQUMsQ0FBQyxhQUFhO0tBQ25CLFNBQVMsR0FBRztNQUNSLE9BQU87S0FDWDtJQUNKO0lBRUEsU0FBUyxjQUFjLFNBQVMsZUFBZTtLQUMzQyxJQUFJLFlBQVksUUFBUSxPQUFPO0tBRS9CLElBQUksUUFBUSxjQUFjLGNBQWMsV0FDcEMsYUFBYSxRQUFRLFlBQVk7S0FFckMsT0FBTztJQUNYO0lBR0EsU0FBUyw0QkFBNEI7S0FDakMsSUFBSSxzQkFBc0I7S0FFMUIsSUFBSTtNQUNBLGFBQWEsUUFBUSxxQkFBcUIsSUFBSTtNQUM5QyxhQUFhLFdBQVcsbUJBQW1CO01BRTNDLE9BQU87S0FDWCxTQUFTLEdBQUc7TUFDUixPQUFPO0tBQ1g7SUFDSjtJQU1BLFNBQVMsd0JBQXdCO0tBQzdCLE9BQU8sQ0FBQywwQkFBMEIsS0FBSyxhQUFhLFNBQVM7SUFDakU7SUFHQSxTQUFTLGVBQWUsU0FBUztLQUM3QixJQUFJLE9BQU87S0FDWCxJQUFJLFNBQVMsQ0FBQztLQUNkLElBQUksU0FDQSxLQUFLLElBQUksS0FBSyxTQUNWLE9BQU8sS0FBSyxRQUFRO0tBSTVCLE9BQU8sWUFBWSxjQUFjLFNBQVMsS0FBSyxjQUFjO0tBRTdELElBQUksQ0FBQyxzQkFBc0IsR0FDdkIsT0FBTyxVQUFVLE9BQU87S0FHNUIsS0FBSyxVQUFVO0tBQ2YsT0FBTyxhQUFhO0tBRXBCLE9BQU8sVUFBVSxRQUFRO0lBQzdCO0lBSUEsU0FBUyxRQUFRLFVBQVU7S0FDdkIsSUFBSSxPQUFPO0tBQ1gsSUFBSSxVQUFVLEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxXQUFZO01BQ3hDLElBQUksWUFBWSxLQUFLLFFBQVE7TUFFN0IsS0FBSyxJQUFJLElBQUksYUFBYSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7T0FDL0MsSUFBSSxNQUFNLGFBQWEsSUFBSSxDQUFDO09BRTVCLElBQUksSUFBSSxRQUFRLFNBQVMsTUFBTSxHQUMzQixhQUFhLFdBQVcsR0FBRztNQUVuQztLQUNKLENBQUM7S0FFRCxnQkFBZ0IsU0FBUyxRQUFRO0tBQ2pDLE9BQU87SUFDWDtJQUtBLFNBQVMsVUFBVSxLQUFLLFVBQVU7S0FDOUIsSUFBSSxPQUFPO0tBRVgsTUFBTSxhQUFhLEdBQUc7S0FFdEIsSUFBSSxVQUFVLEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxXQUFZO01BQ3hDLElBQUksU0FBUyxLQUFLO01BQ2xCLElBQUksU0FBUyxhQUFhLFFBQVEsT0FBTyxZQUFZLEdBQUc7TUFNeEQsSUFBSSxRQUNBLFNBQVMsT0FBTyxXQUFXLFlBQVksTUFBTTtNQUdqRCxPQUFPO0tBQ1gsQ0FBQztLQUVELGdCQUFnQixTQUFTLFFBQVE7S0FDakMsT0FBTztJQUNYO0lBR0EsU0FBUyxVQUFVLFVBQVUsVUFBVTtLQUNuQyxJQUFJLE9BQU87S0FFWCxJQUFJLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLFdBQVk7TUFDeEMsSUFBSSxTQUFTLEtBQUs7TUFDbEIsSUFBSSxZQUFZLE9BQU87TUFDdkIsSUFBSSxrQkFBa0IsVUFBVTtNQUNoQyxJQUFJLFNBQVMsYUFBYTtNQVExQixJQUFJLGtCQUFrQjtNQUV0QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLO09BQzdCLElBQUksTUFBTSxhQUFhLElBQUksQ0FBQztPQUM1QixJQUFJLElBQUksUUFBUSxTQUFTLE1BQU0sR0FDM0I7T0FFSixJQUFJLFFBQVEsYUFBYSxRQUFRLEdBQUc7T0FNcEMsSUFBSSxPQUNBLFFBQVEsT0FBTyxXQUFXLFlBQVksS0FBSztPQUcvQyxRQUFRLFNBQVMsT0FBTyxJQUFJLFVBQVUsZUFBZSxHQUFHLGlCQUFpQjtPQUV6RSxJQUFJLFVBQVUsS0FBSyxHQUNmLE9BQU87TUFFZjtLQUNKLENBQUM7S0FFRCxnQkFBZ0IsU0FBUyxRQUFRO0tBQ2pDLE9BQU87SUFDWDtJQUdBLFNBQVMsTUFBTSxHQUFHLFVBQVU7S0FDeEIsSUFBSSxPQUFPO0tBQ1gsSUFBSSxVQUFVLEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxXQUFZO01BQ3hDLElBQUksU0FBUyxLQUFLO01BQ2xCLElBQUk7TUFDSixJQUFJO09BQ0EsU0FBUyxhQUFhLElBQUksQ0FBQztNQUMvQixTQUFTLE9BQU87T0FDWixTQUFTO01BQ2I7TUFHQSxJQUFJLFFBQ0EsU0FBUyxPQUFPLFVBQVUsT0FBTyxVQUFVLE1BQU07TUFHckQsT0FBTztLQUNYLENBQUM7S0FFRCxnQkFBZ0IsU0FBUyxRQUFRO0tBQ2pDLE9BQU87SUFDWDtJQUVBLFNBQVMsT0FBTyxVQUFVO0tBQ3RCLElBQUksT0FBTztLQUNYLElBQUksVUFBVSxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBWTtNQUN4QyxJQUFJLFNBQVMsS0FBSztNQUNsQixJQUFJLFNBQVMsYUFBYTtNQUMxQixJQUFJLE9BQU8sQ0FBQztNQUVaLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7T0FDN0IsSUFBSSxVQUFVLGFBQWEsSUFBSSxDQUFDO09BQ2hDLElBQUksUUFBUSxRQUFRLE9BQU8sU0FBUyxNQUFNLEdBQ3RDLEtBQUssS0FBSyxRQUFRLFVBQVUsT0FBTyxVQUFVLE1BQU0sQ0FBQztNQUU1RDtNQUVBLE9BQU87S0FDWCxDQUFDO0tBRUQsZ0JBQWdCLFNBQVMsUUFBUTtLQUNqQyxPQUFPO0lBQ1g7SUFHQSxTQUFTLFNBQVMsVUFBVTtLQUV4QixJQUFJLFVBQVUsS0FBSyxLQUFLLENBQUMsQ0FBQyxLQUFLLFNBQVUsTUFBTTtNQUMzQyxPQUFPLEtBQUs7S0FDaEIsQ0FBQztLQUVELGdCQUFnQixTQUFTLFFBQVE7S0FDakMsT0FBTztJQUNYO0lBR0EsU0FBUyxhQUFhLEtBQUssVUFBVTtLQUNqQyxJQUFJLE9BQU87S0FFWCxNQUFNLGFBQWEsR0FBRztLQUV0QixJQUFJLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLFdBQVk7TUFDeEMsSUFBSSxTQUFTLEtBQUs7TUFDbEIsYUFBYSxXQUFXLE9BQU8sWUFBWSxHQUFHO0tBQ2xELENBQUM7S0FFRCxnQkFBZ0IsU0FBUyxRQUFRO0tBQ2pDLE9BQU87SUFDWDtJQU1BLFNBQVMsVUFBVSxLQUFLLE9BQU8sVUFBVTtLQUNyQyxJQUFJLE9BQU87S0FFWCxNQUFNLGFBQWEsR0FBRztLQUV0QixJQUFJLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLFdBQVk7TUFHeEMsSUFBSSxVQUFVLEtBQUEsR0FDVixRQUFRO01BSVosSUFBSSxnQkFBZ0I7TUFFcEIsT0FBTyxJQUFJLFVBQVUsU0FBVSxTQUFTLFFBQVE7T0FDNUMsSUFBSSxTQUFTLEtBQUs7T0FDbEIsT0FBTyxXQUFXLFVBQVUsT0FBTyxTQUFVLE9BQU8sT0FBTztRQUN2RCxJQUFJLE9BQ0EsT0FBTyxLQUFLO2FBRVosSUFBSTtTQUNBLGFBQWEsUUFBUSxPQUFPLFlBQVksS0FBSyxLQUFLO1NBQ2xELFFBQVEsYUFBYTtRQUN6QixTQUFTLEdBQUc7U0FHUixJQUFJLEVBQUUsU0FBUyx3QkFBd0IsRUFBRSxTQUFTLDhCQUM5QyxPQUFPLENBQUM7U0FFWixPQUFPLENBQUM7UUFDWjtPQUVSLENBQUM7TUFDTCxDQUFDO0tBQ0wsQ0FBQztLQUVELGdCQUFnQixTQUFTLFFBQVE7S0FDakMsT0FBTztJQUNYO0lBRUEsU0FBUyxlQUFlLFNBQVMsVUFBVTtLQUN2QyxXQUFXLFlBQVksTUFBTSxNQUFNLFNBQVM7S0FFNUMsVUFBVSxPQUFPLFlBQVksY0FBYyxXQUFXLENBQUM7S0FDdkQsSUFBSSxDQUFDLFFBQVEsTUFBTTtNQUNmLElBQUksZ0JBQWdCLEtBQUssT0FBTztNQUNoQyxRQUFRLE9BQU8sUUFBUSxRQUFRLGNBQWM7TUFDN0MsUUFBUSxZQUFZLFFBQVEsYUFBYSxjQUFjO0tBQzNEO0tBRUEsSUFBSSxPQUFPO0tBQ1gsSUFBSTtLQUNKLElBQUksQ0FBQyxRQUFRLE1BQ1QsVUFBVSxVQUFVLE9BQU8sbUJBQW1CO1VBRTlDLFVBQVUsSUFBSSxVQUFVLFNBQVUsU0FBUztNQUN2QyxJQUFJLENBQUMsUUFBUSxXQUNULFFBQVEsUUFBUSxPQUFPLEdBQUc7V0FFMUIsUUFBUSxjQUFjLFNBQVMsS0FBSyxjQUFjLENBQUM7S0FFM0QsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFVLFdBQVc7TUFDekIsS0FBSyxJQUFJLElBQUksYUFBYSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7T0FDL0MsSUFBSSxNQUFNLGFBQWEsSUFBSSxDQUFDO09BRTVCLElBQUksSUFBSSxRQUFRLFNBQVMsTUFBTSxHQUMzQixhQUFhLFdBQVcsR0FBRztNQUVuQztLQUNKLENBQUM7S0FHTCxnQkFBZ0IsU0FBUyxRQUFRO0tBQ2pDLE9BQU87SUFDWDtJQUVBLElBQUksc0JBQXNCO0tBQ3RCLFNBQVM7S0FDVCxjQUFjO0tBQ2QsVUFBVSxvQkFBb0I7S0FDOUIsU0FBUztLQUNULFNBQVM7S0FDVCxTQUFTO0tBQ1QsWUFBWTtLQUNaLE9BQU87S0FDUCxRQUFRO0tBQ1IsS0FBSztLQUNMLE1BQU07S0FDTixjQUFjO0lBQ2xCO0lBRUEsSUFBSSxZQUFZLFNBQVMsVUFBVSxHQUFHLEdBQUc7S0FDckMsT0FBTyxNQUFNLEtBQUssT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFlBQVksTUFBTSxDQUFDLEtBQUssTUFBTSxDQUFDO0lBQzNGO0lBRUEsSUFBSSxXQUFXLFNBQVMsU0FBUyxPQUFPLGVBQWU7S0FDbkQsSUFBSSxNQUFNLE1BQU07S0FDaEIsSUFBSSxJQUFJO0tBQ1IsT0FBTyxJQUFJLEtBQUs7TUFDWixJQUFJLFVBQVUsTUFBTSxJQUFJLGFBQWEsR0FDakMsT0FBTztNQUVYO0tBQ0o7S0FFQSxPQUFPO0lBQ1g7SUFFQSxJQUFJLFVBQVUsTUFBTSxXQUFXLFNBQVUsS0FBSztLQUMxQyxPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssR0FBRyxNQUFNO0lBQ25EO0lBSUEsSUFBSSxpQkFBaUIsQ0FBQztJQUV0QixJQUFJLGdCQUFnQixDQUFDO0lBRXJCLElBQUksaUJBQWlCO0tBQ2pCLFdBQVc7S0FDWCxRQUFRO0tBQ1IsY0FBYztJQUNsQjtJQUVBLElBQUkscUJBQXFCO0tBQUMsZUFBZSxVQUFVO0tBQVMsZUFBZSxPQUFPO0tBQVMsZUFBZSxhQUFhO0lBQU87SUFFOUgsSUFBSSx3QkFBd0IsQ0FBQyxjQUFjO0lBRTNDLElBQUksaUJBQWlCO0tBQUM7S0FBUztLQUFXO0tBQVc7S0FBTztLQUFRO0tBQVU7S0FBYztJQUFTLENBQUMsQ0FBQyxPQUFPLHFCQUFxQjtJQUVuSSxJQUFJLGdCQUFnQjtLQUNoQixhQUFhO0tBQ2IsUUFBUSxtQkFBbUIsTUFBTTtLQUNqQyxNQUFNO0tBR04sTUFBTTtLQUNOLFdBQVc7S0FDWCxTQUFTO0lBQ2I7SUFFQSxTQUFTLGNBQWMscUJBQXFCLGVBQWU7S0FDdkQsb0JBQW9CLGlCQUFpQixXQUFZO01BQzdDLElBQUksUUFBUTtNQUNaLE9BQU8sb0JBQW9CLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBWTtPQUNoRCxPQUFPLG9CQUFvQixjQUFjLENBQUMsTUFBTSxxQkFBcUIsS0FBSztNQUM5RSxDQUFDO0tBQ0w7SUFDSjtJQUVBLFNBQVMsU0FBUztLQUNkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsS0FBSztNQUN2QyxJQUFJLE1BQU0sVUFBVTtNQUVwQixJQUFJO1lBQ0ssSUFBSSxRQUFRLEtBQ2IsSUFBSSxJQUFJLGVBQWUsSUFBSSxHQUN2QixJQUFJLFFBQVEsSUFBSSxLQUFLLEdBQ2pCLFVBQVUsRUFBRSxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsTUFBTTtZQUVyQyxVQUFVLEVBQUUsQ0FBQyxRQUFRLElBQUk7TUFBQTtLQUs3QztLQUVBLE9BQU8sVUFBVTtJQUNyQjtJQWdUQSxTQUFPLFVBQVUsS0E5U0MsV0FBWTtLQUMxQixTQUFTLFlBQVksU0FBUztNQUMxQixnQkFBZ0IsTUFBTSxXQUFXO01BRWpDLEtBQUssSUFBSSxpQkFBaUIsZ0JBQ3RCLElBQUksZUFBZSxlQUFlLGFBQWEsR0FBRztPQUM5QyxJQUFJLFNBQVMsZUFBZTtPQUM1QixJQUFJLGFBQWEsT0FBTztPQUN4QixLQUFLLGlCQUFpQjtPQUV0QixJQUFJLENBQUMsZUFBZSxhQUloQixLQUFLLGFBQWEsTUFBTTtNQUVoQztNQUdKLEtBQUssaUJBQWlCLE9BQU8sQ0FBQyxHQUFHLGFBQWE7TUFDOUMsS0FBSyxVQUFVLE9BQU8sQ0FBQyxHQUFHLEtBQUssZ0JBQWdCLE9BQU87TUFDdEQsS0FBSyxhQUFhO01BQ2xCLEtBQUssY0FBYztNQUNuQixLQUFLLFNBQVM7TUFDZCxLQUFLLFVBQVU7TUFFZixLQUFLLDZCQUE2QjtNQUNsQyxLQUFLLFVBQVUsS0FBSyxRQUFRLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFZLENBQUMsQ0FBQztLQUMvRDtLQVFBLFlBQVksVUFBVSxTQUFTLFNBQVMsT0FBTyxTQUFTO01BSXBELEtBQUssT0FBTyxZQUFZLGNBQWMsY0FBYyxRQUFRLE9BQU8sT0FBTyxVQUFVO09BR2hGLElBQUksS0FBSyxRQUNMLHVCQUFPLElBQUksTUFBTSxzREFBMkQ7T0FHaEYsS0FBSyxJQUFJLEtBQUssU0FBUztRQUNuQixJQUFJLE1BQU0sYUFDTixRQUFRLEtBQUssUUFBUSxFQUFFLENBQUMsUUFBUSxPQUFPLEdBQUc7UUFHOUMsSUFBSSxNQUFNLGFBQWEsT0FBTyxRQUFRLE9BQU8sVUFDekMsdUJBQU8sSUFBSSxNQUFNLG9DQUFvQztRQUd6RCxLQUFLLFFBQVEsS0FBSyxRQUFRO09BQzlCO09BSUEsSUFBSSxZQUFZLFdBQVcsUUFBUSxRQUMvQixPQUFPLEtBQUssVUFBVSxLQUFLLFFBQVEsTUFBTTtPQUc3QyxPQUFPO01BQ1gsT0FBTyxJQUFJLE9BQU8sWUFBWSxVQUMxQixPQUFPLEtBQUssUUFBUTtXQUVwQixPQUFPLEtBQUs7S0FFcEI7S0FNQSxZQUFZLFVBQVUsZUFBZSxTQUFTLGFBQWEsY0FBYyxVQUFVLGVBQWU7TUFDOUYsSUFBSSxVQUFVLElBQUksVUFBVSxTQUFVLFNBQVMsUUFBUTtPQUNuRCxJQUFJO1FBQ0EsSUFBSSxhQUFhLGFBQWE7UUFDOUIsSUFBSSxrQ0FBa0IsSUFBSSxNQUFNLHNGQUEyRjtRQUkzSCxJQUFJLENBQUMsYUFBYSxTQUFTO1NBQ3ZCLE9BQU8sZUFBZTtTQUN0QjtRQUNKO1FBRUEsSUFBSSxnQkFBZ0IsZUFBZSxPQUFPLGNBQWM7UUFDeEQsS0FBSyxJQUFJLElBQUksR0FBRyxNQUFNLGNBQWMsUUFBUSxJQUFJLEtBQUssS0FBSztTQUN0RCxJQUFJLG1CQUFtQixjQUFjO1NBS3JDLEtBQUssQ0FEYSxTQUFTLHVCQUF1QixnQkFBZ0IsS0FDL0MsYUFBYSxzQkFBc0IsT0FBTyxhQUFhLHNCQUFzQixZQUFZO1VBQ3hHLE9BQU8sZUFBZTtVQUN0QjtTQUNKO1FBQ0o7UUFvQkEsQ0FBQSxTQWxCdUMsMEJBQTBCO1NBQzdELElBQUksOEJBQThCLFNBQVMsNEJBQTRCLFlBQVk7VUFDL0UsT0FBTyxXQUFZO1dBQ2YsSUFBSSx3QkFBUSxJQUFJLE1BQU0sWUFBWSxhQUFhLDJDQUEyQztXQUMxRixJQUFJLFVBQVUsVUFBVSxPQUFPLEtBQUs7V0FDcEMsZ0JBQWdCLFNBQVMsVUFBVSxVQUFVLFNBQVMsRUFBRTtXQUN4RCxPQUFPO1VBQ1g7U0FDSjtTQUVBLEtBQUssSUFBSSxLQUFLLEdBQUcsT0FBTyxzQkFBc0IsUUFBUSxLQUFLLE1BQU0sTUFBTTtVQUNuRSxJQUFJLHVCQUF1QixzQkFBc0I7VUFDakQsSUFBSSxDQUFDLGFBQWEsdUJBQ2QsYUFBYSx3QkFBd0IsNEJBQTRCLG9CQUFvQjtTQUU3RjtRQUNKLEVBQUEsQ0FFd0I7UUFFeEIsSUFBSSxtQkFBbUIsU0FBUyxpQkFBaUIsU0FBUztTQUN0RCxJQUFJLGVBQWUsYUFDZixRQUFRLEtBQUssb0NBQW9DLFVBQVU7U0FFL0QsZUFBZSxjQUFjO1NBQzdCLGNBQWMsY0FBYztTQUk1QixRQUFRO1FBQ1o7UUFFQSxJQUFJLGNBQWMsY0FDZCxJQUFJLGFBQWEsWUFBWSxPQUFPLGFBQWEsYUFBYSxZQUMxRCxhQUFhLFNBQVMsQ0FBQyxDQUFDLEtBQUssa0JBQWtCLE1BQU07YUFFckQsaUJBQWlCLENBQUMsQ0FBQyxhQUFhLFFBQVE7YUFHNUMsaUJBQWlCLElBQUk7T0FFN0IsU0FBUyxHQUFHO1FBQ1IsT0FBTyxDQUFDO09BQ1o7TUFDSixDQUFDO01BRUQsb0JBQW9CLFNBQVMsVUFBVSxhQUFhO01BQ3BELE9BQU87S0FDWDtLQUVBLFlBQVksVUFBVSxTQUFTLFNBQVMsU0FBUztNQUM3QyxPQUFPLEtBQUssV0FBVztLQUMzQjtLQUVBLFlBQVksVUFBVSxZQUFZLFNBQVMsVUFBVSxZQUFZLFVBQVUsZUFBZTtNQUN0RixJQUFJLG1CQUFtQixlQUFlLGNBQWMsVUFBVSxRQUFRLGVBQWUsV0FBVyxJQUFJLFVBQVUsdUJBQU8sSUFBSSxNQUFNLG1CQUFtQixDQUFDO01BRW5KLG9CQUFvQixrQkFBa0IsVUFBVSxhQUFhO01BQzdELE9BQU87S0FDWDtLQUVBLFlBQVksVUFBVSxnQkFBZ0IsU0FBUyxjQUFjLFVBQVU7TUFDbkUsSUFBSSxvQkFBb0IsVUFBVSxRQUFRLHFCQUFxQjtNQUMvRCxvQkFBb0IsbUJBQW1CLFFBQVE7TUFDL0MsT0FBTztLQUNYO0tBRUEsWUFBWSxVQUFVLFFBQVEsU0FBUyxNQUFNLFVBQVU7TUFDbkQsSUFBSSxPQUFPO01BRVgsSUFBSSxVQUFVLEtBQUssV0FBVyxLQUFLLFdBQVk7T0FDM0MsSUFBSSxLQUFLLFdBQVcsTUFDaEIsS0FBSyxTQUFTLEtBQUssWUFBWTtPQUduQyxPQUFPLEtBQUs7TUFDaEIsQ0FBQztNQUVELG9CQUFvQixTQUFTLFVBQVUsUUFBUTtNQUMvQyxPQUFPO0tBQ1g7S0FFQSxZQUFZLFVBQVUsWUFBWSxTQUFTLFVBQVUsU0FBUyxVQUFVLGVBQWU7TUFDbkYsSUFBSSxPQUFPO01BRVgsSUFBSSxDQUFDLFFBQVEsT0FBTyxHQUNoQixVQUFVLENBQUMsT0FBTztNQUd0QixJQUFJLG1CQUFtQixLQUFLLHFCQUFxQixPQUFPO01BRXhELFNBQVMsb0JBQW9CO09BQ3pCLEtBQUssUUFBUSxTQUFTLEtBQUssT0FBTztNQUN0QztNQUVBLFNBQVMscUJBQXFCLFFBQVE7T0FDbEMsS0FBSyxRQUFRLE1BQU07T0FDbkIsa0JBQWtCO09BRWxCLEtBQUssU0FBUyxLQUFLLGFBQWEsS0FBSyxPQUFPO09BQzVDLE9BQU8sS0FBSztNQUNoQjtNQUVBLFNBQVMsV0FBVyxrQkFBa0I7T0FDbEMsT0FBTyxXQUFZO1FBQ2YsSUFBSSxxQkFBcUI7UUFFekIsU0FBUyxvQkFBb0I7U0FDekIsT0FBTyxxQkFBcUIsaUJBQWlCLFFBQVE7VUFDakQsSUFBSSxhQUFhLGlCQUFpQjtVQUNsQztVQUVBLEtBQUssVUFBVTtVQUNmLEtBQUssU0FBUztVQUVkLE9BQU8sS0FBSyxVQUFVLFVBQVUsQ0FBQyxDQUFDLEtBQUssb0JBQW9CLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCO1NBQzNGO1NBRUEsa0JBQWtCO1NBQ2xCLElBQUksd0JBQVEsSUFBSSxNQUFNLG9DQUFvQztTQUMxRCxLQUFLLGFBQWEsVUFBVSxPQUFPLEtBQUs7U0FDeEMsT0FBTyxLQUFLO1FBQ2hCO1FBRUEsT0FBTyxrQkFBa0I7T0FDN0I7TUFDSjtNQUtBLElBQUksbUJBQW1CLEtBQUssZUFBZSxPQUFPLEtBQUssV0FBVyxRQUFRLENBQUMsV0FBWTtPQUNuRixPQUFPLFVBQVUsUUFBUTtNQUM3QixDQUFDLElBQUksVUFBVSxRQUFRO01BRXZCLEtBQUssYUFBYSxpQkFBaUIsS0FBSyxXQUFZO09BQ2hELElBQUksYUFBYSxpQkFBaUI7T0FDbEMsS0FBSyxVQUFVO09BQ2YsS0FBSyxTQUFTO09BRWQsT0FBTyxLQUFLLFVBQVUsVUFBVSxDQUFDLENBQUMsS0FBSyxTQUFVLFFBQVE7UUFDckQsS0FBSyxVQUFVLE9BQU87UUFDdEIsa0JBQWtCO1FBQ2xCLEtBQUssNkJBQTZCO1FBQ2xDLEtBQUssY0FBYyxXQUFXLGdCQUFnQjtPQUNsRCxDQUFDO01BQ0wsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVk7T0FDcEIsa0JBQWtCO09BQ2xCLElBQUksd0JBQVEsSUFBSSxNQUFNLG9DQUFvQztPQUMxRCxLQUFLLGFBQWEsVUFBVSxPQUFPLEtBQUs7T0FDeEMsT0FBTyxLQUFLO01BQ2hCLENBQUM7TUFFRCxvQkFBb0IsS0FBSyxZQUFZLFVBQVUsYUFBYTtNQUM1RCxPQUFPLEtBQUs7S0FDaEI7S0FFQSxZQUFZLFVBQVUsV0FBVyxTQUFTLFNBQVMsWUFBWTtNQUMzRCxPQUFPLENBQUMsQ0FBQyxjQUFjO0tBQzNCO0tBRUEsWUFBWSxVQUFVLFVBQVUsU0FBUyxRQUFRLDZCQUE2QjtNQUMxRSxPQUFPLE1BQU0sMkJBQTJCO0tBQzVDO0tBRUEsWUFBWSxVQUFVLHVCQUF1QixTQUFTLHFCQUFxQixTQUFTO01BQ2hGLElBQUksbUJBQW1CLENBQUM7TUFDeEIsS0FBSyxJQUFJLElBQUksR0FBRyxNQUFNLFFBQVEsUUFBUSxJQUFJLEtBQUssS0FBSztPQUNoRCxJQUFJLGFBQWEsUUFBUTtPQUN6QixJQUFJLEtBQUssU0FBUyxVQUFVLEdBQ3hCLGlCQUFpQixLQUFLLFVBQVU7TUFFeEM7TUFDQSxPQUFPO0tBQ1g7S0FFQSxZQUFZLFVBQVUsK0JBQStCLFNBQVMsK0JBQStCO01BS3pGLEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxlQUFlLFFBQVEsSUFBSSxLQUFLLEtBQ2xELGNBQWMsTUFBTSxlQUFlLEVBQUU7S0FFN0M7S0FFQSxZQUFZLFVBQVUsaUJBQWlCLFNBQVMsZUFBZSxTQUFTO01BQ3BFLE9BQU8sSUFBSSxZQUFZLE9BQU87S0FDbEM7S0FFQSxPQUFPO0lBQ1gsRUFNbUMsR0FFTDtHQUU5QixHQUFFLEVBQUMsS0FBSSxFQUFDLENBQUM7RUFBQyxHQUFFLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztDQUNyQixDQUFDIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==