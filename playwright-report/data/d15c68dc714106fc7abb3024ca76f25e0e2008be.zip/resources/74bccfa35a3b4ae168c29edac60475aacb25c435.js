import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SubestacionComponent.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { Shield, Hammer, Activity, Compass, Home, Save, User, Calendar, Clock, Zap, Printer, RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
import MetrologiaElectricaSection from "/src/components/MetrologiaElectricaSection.jsx";
import DualPhotoUploader from "/src/components/DualPhotoUploader.jsx?t=1790793566895";
import { TENSIONES_COVENIN_159_MT, TENSIONES_COVENIN_TODAS } from "/src/utils/constants.js";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SubestacionComponent.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function SubestacionComponent({ subestacionData, onUpdate, readOnly }) {
	_s();
	const { alert: customAlert, confirm: customConfirm } = useConfirm();
	if (!subestacionData) return /* @__PURE__ */ _jsxDEV("div", {
		className: "text-center p-8 text-slate-400",
		children: "No hay datos de subestación seleccionados."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 32
	}, this);
	const { id, nombre = "", ubicacion = "", fecha = "", hora = "", inspector = "", nivelTension = "", fotoBlob = null, foto = null, mediciones = {}, estadoEntorno = {}, obrasCiviles = {}, equiposPrincipales = {}, puestaTierra = {}, edificioControl = {}, firmaInspector = "", firmaSupervisor = "" } = subestacionData;
	const [previewUrl, setPreviewUrl] = useState(null);
	const updateField = (field, value) => {
		if (readOnly) return;
		onUpdate({
			...subestacionData,
			[field]: value
		});
	};
	const handleLimpiarFormulario = async () => {
		if (readOnly) return;
		const confirmed = await customConfirm("¿Deseas reiniciar todos los campos de esta inspección de subestación a blanco?");
		if (!confirmed) return;
		onUpdate({
			...subestacionData,
			ubicacion: "",
			inspector: "",
			nivelTension: "",
			fotoBlob: null,
			foto: null,
			mediciones: {},
			estadoEntorno: {},
			obrasCiviles: {},
			equiposPrincipales: {},
			puestaTierra: {},
			edificioControl: {},
			firmaInspector: "",
			firmaSupervisor: ""
		});
		if (previewUrl) URL.revokeObjectURL(previewUrl);
		setPreviewUrl(null);
	};
	const updateSectionItem = (section, elementKey, type, value) => {
		if (readOnly) return;
		const sectionData = subestacionData[section] || {};
		const itemData = sectionData[elementKey] || {
			estado: "B",
			observaciones: ""
		};
		onUpdate({
			...subestacionData,
			[section]: {
				...sectionData,
				[elementKey]: {
					...itemData,
					[type]: value
				}
			}
		});
	};
	// Definición de las secciones y sus correspondientes elementos
	const SECCIONES = [
		{
			key: "estadoEntorno",
			title: "2. Estado del Entorno y Perímetro",
			icon: /* @__PURE__ */ _jsxDEV(Compass, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 13
			}, this),
			description: "Evalúe visualmente las condiciones de seguridad exterior del perímetro.",
			elements: [
				{
					key: "cercaPerimetral",
					label: "Cerca perimetral / Muros"
				},
				{
					key: "portonAcceso",
					label: "Portón de acceso y candados"
				},
				{
					key: "senalizacionSeguridad",
					label: "Señalización de seguridad"
				},
				{
					key: "estadoViasAcceso",
					label: "Estado de vías de acceso"
				},
				{
					key: "controlMaleza",
					label: "Control de maleza y vegetación"
				},
				{
					key: "sistemaDrenaje",
					label: "Sistema de drenaje de aguas"
				}
			]
		},
		{
			key: "obrasCiviles",
			title: "3. Obras Civiles y Estructuras Soportes",
			icon: /* @__PURE__ */ _jsxDEV(Hammer, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 13
			}, this),
			description: "Inspección del estado físico de las bases de concreto y soportes de equipos.",
			elements: [
				{
					key: "basesConcreto",
					label: "Bases de concreto (Fisuras/Asentamientos)"
				},
				{
					key: "estructurasMetalicas",
					label: "Estructuras metálicas (Óxido/Corrosión)"
				},
				{
					key: "porticosLlegada",
					label: "Pórticos de llegada y salida"
				},
				{
					key: "tornilleriaConexiones",
					label: "Tornillería y conexiones mecánicas"
				},
				{
					key: "murosCortafuegos",
					label: "Muros cortafuegos (si aplica)"
				},
				{
					key: "estadoGravilla",
					label: "Estado de la gravilla/piedra chancada"
				}
			]
		},
		{
			key: "equiposPrincipales",
			title: "4. Inspección Visual de Equipos Principales",
			icon: /* @__PURE__ */ _jsxDEV(Activity, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 13
			}, this),
			description: "Detección de fugas, suciedad, daños mecánicos y niveles de fluidos.",
			elements: [
				{
					key: "transfFugasAceite",
					label: "Transformador: Fugas de aceite"
				},
				{
					key: "transfNivelAceite",
					label: "Transformador: Nivel de aceite"
				},
				{
					key: "interruptoresPotencia",
					label: "Interruptores de potencia (Estado visual)"
				},
				{
					key: "seccionadoresCortadores",
					label: "Seccionadores (cortadores)"
				},
				{
					key: "transformadoresMedida",
					label: "Transformadores de medida (CT/PT)"
				},
				{
					key: "pararrayosAisladores",
					label: "Pararrayos (Contadores/Aisladores)"
				},
				{
					key: "aisladoresPorcelana",
					label: "Aisladores de porcelana/poliméricos"
				}
			]
		},
		{
			key: "puestaTierra",
			title: "5. Sistema de Puesta a Tierra y Conexiones",
			icon: /* @__PURE__ */ _jsxDEV(Shield, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 132,
				columnNumber: 13
			}, this),
			description: "Verificación visual y estado de conexiones de puesta a tierra (SPT).",
			elements: [
				{
					key: "medicionResistencia",
					label: "Mediciones de resistencia de malla de tierra"
				},
				{
					key: "conexionesVisibles",
					label: "Conexiones visibles de equipos a tierra"
				},
				{
					key: "estadoCableSpt",
					label: "Estado del cable de SPT"
				},
				{
					key: "corrosionConectores",
					label: "Corrosión en conectores de tierra"
				}
			]
		},
		{
			key: "edificioControl",
			title: "6. Edificio de Control y Sala de Tableros",
			icon: /* @__PURE__ */ _jsxDEV(Home, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 144,
				columnNumber: 13
			}, this),
			description: "Verificación de equipos, limpieza, iluminación y sistemas de seguridad.",
			elements: [
				{
					key: "tablerosControl",
					label: "Tableros y control"
				},
				{
					key: "bancoCondensadores",
					label: "Banco de condensadores"
				},
				{
					key: "sistemaIluminacion",
					label: "Sistema de iluminación (Normal/Emergencia)"
				},
				{
					key: "extintoresIncendios",
					label: "Estado de extintores de incendios"
				}
			]
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `w-full text-slate-100 bg-slate-900/60 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl backdrop-blur-md select-text max-w-5xl mx-auto space-y-8 print-card print:bg-white print:text-slate-900 print:border-none print:shadow-none print:p-0 print:m-0 ${readOnly ? "pointer-events-none opacity-90" : ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-slate-800 print:border-gray-200",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] text-amber-500 font-extrabold uppercase tracking-widest print:text-amber-600",
					children: "Inspección de Subestación Eléctrica"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("h2", {
					className: "text-xl md:text-2xl font-extrabold text-slate-100 tracking-wide mt-1 print:text-slate-900",
					children: nombre || "Subestación Eléctrica"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 161,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [
						!readOnly && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleLimpiarFormulario,
							className: "no-print bg-slate-900 hover:bg-red-950/60 text-slate-400 hover:text-red-400 border border-slate-800 hover:border-red-800 font-bold px-3 py-2 rounded-lg flex items-center gap-1.5 text-xs transition-all cursor-pointer",
							title: "Reiniciar todos los campos a blanco",
							children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden sm:inline",
								children: "Limpiar Formulario"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => window.print(),
							className: "no-print bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-3.5 py-2 rounded-lg flex items-center gap-2 text-xs transition-all cursor-pointer shadow-sm",
							title: "Guardar como PDF o Imprimir esta Inspección",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 13
							}, this), " Guardar PDF"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "inline-flex items-center justify-center font-mono font-black text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/30 text-xs shadow-sm",
							children: ["ID: ", id]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 163,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 158,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-slate-50 print:border-gray-200",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-900 pb-2.5 flex items-center gap-2 print:text-slate-700 print:border-gray-200",
					children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-amber-500 print:text-amber-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 11
					}, this), " 1. Información General"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 190,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-600",
								children: "Ubicación / Código"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: ubicacion,
								onChange: (e) => updateField("ubicacion", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300 print:placeholder-transparent",
								placeholder: "Ej. Patio de Transformadores A"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-600",
								children: "Nivel de Tensión (COVENIN 159)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-2",
								children: /* @__PURE__ */ _jsxDEV("select", {
									value: nivelTension,
									onChange: (e) => updateField("nivelTension", e.target.value),
									className: "w-full bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono font-bold",
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "",
											children: "-- Seleccionar Nivel de Tensión --"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 216,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("optgroup", {
											label: "Media Tensión (MT - COVENIN 159)",
											children: TENSIONES_COVENIN_159_MT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
												value: v,
												children: v
											}, v, false, {
												fileName: _jsxFileName,
												lineNumber: 219,
												columnNumber: 21
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 217,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("optgroup", {
											label: "Baja Tensión (BT - COVENIN 159)",
											children: TENSIONES_COVENIN_TODAS.filter((v) => !TENSIONES_COVENIN_159_MT.includes(v)).map((v) => /* @__PURE__ */ _jsxDEV("option", {
												value: v,
												children: v
											}, v, false, {
												fileName: _jsxFileName,
												lineNumber: 224,
												columnNumber: 21
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 222,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 211,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 210,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-600",
								children: "Nombre del Inspector"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 233,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: inspector,
								onChange: (e) => updateField("inspector", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300 print:placeholder-transparent",
								placeholder: "Nombre y Apellido"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 232,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1.5 print:text-slate-600",
								children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5 text-slate-400 print:text-slate-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 246,
									columnNumber: 15
								}, this), " Fecha de Inspección"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "date",
								value: fecha,
								onChange: (e) => updateField("fecha", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 248,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 244,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1.5 print:text-slate-600",
								children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5 text-slate-400 print:text-slate-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 15
								}, this), " Hora"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 258,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "time",
								value: hora,
								onChange: (e) => updateField("hora", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 261,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 257,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 194,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(MetrologiaElectricaSection, {
				mediciones,
				onChange: (nuevasMediciones) => updateField("mediciones", nuevasMediciones),
				readOnly,
				titulo: "Metrología Eléctrica en Subestación (COVENIN 159)",
				subtitulo: "Medición de voltajes de línea L-L, fase L-N y 5 canales de corriente en celda o barraje"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 272,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-8",
				children: SECCIONES.map((sec) => {
					const sectionData = subestacionData[sec.key] || {};
					return /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950/20 border border-slate-800/80 rounded-2xl overflow-hidden shadow-sm print:bg-white print:border-gray-200 print:shadow-none",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-950/40 px-5 py-4 border-b border-slate-800 flex items-start gap-3 print:bg-slate-50 print:border-gray-200",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "p-2 bg-slate-900 border border-slate-800 rounded-xl mt-0.5 shadow-inner print:bg-white print:border-gray-300",
								children: sec.icon
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-slate-200 print:text-slate-800",
								children: sec.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 293,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[10px] text-slate-500 mt-1 print:text-slate-500",
								children: sec.description
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 288,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "divide-y divide-slate-800/60 print:divide-gray-200",
							children: sec.elements.map((elem) => {
								const item = sectionData[elem.key] || {
									estado: "B",
									observaciones: ""
								};
								return /* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 md:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-900/10 transition-all print:bg-white print:text-slate-900",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "md:w-[35%] flex flex-col",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-bold text-slate-200 print:text-slate-800",
												children: elem.label
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 307,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 306,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[9px] font-bold text-slate-500 uppercase tracking-wider mr-2 hidden md:inline print:text-slate-500",
												children: "Estado:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 312,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex bg-slate-900/60 p-1 rounded-xl border border-slate-800/80 shadow-inner print:bg-gray-100 print:border-gray-300 print:shadow-none",
												children: [
													{
														value: "B",
														label: "Bueno",
														color: "bg-emerald-500 text-slate-950 font-bold",
														hover: "hover:text-emerald-400"
													},
													{
														value: "R",
														label: "Regular",
														color: "bg-amber-500 text-slate-950 font-bold",
														hover: "hover:text-amber-400"
													},
													{
														value: "M",
														label: "Malo",
														color: "bg-red-500 text-white font-bold",
														hover: "hover:text-red-400"
													}
												].map((opt) => {
													const isSelected = item.estado === opt.value;
													return /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => updateSectionItem(sec.key, elem.key, "estado", opt.value),
														className: `px-3 py-1.5 text-[10px] rounded-lg font-bold transition-all cursor-pointer ${isSelected ? opt.color + " shadow-md scale-105 print:shadow-none print:scale-100" : "text-slate-400 hover:bg-slate-800/50 print:text-slate-400 print:hover:bg-transparent " + opt.hover}`,
														children: opt.value
													}, opt.value, false, {
														fileName: _jsxFileName,
														lineNumber: 321,
														columnNumber: 31
													}, this);
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 313,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 311,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex-1 min-w-[30%]",
											children: /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: item.observaciones || "",
												onChange: (e) => updateSectionItem(sec.key, elem.key, "observaciones", e.target.value),
												className: "w-full bg-slate-900/50 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all placeholder-slate-600 font-sans print:bg-white print:text-slate-900 print:border-gray-300 print:placeholder-transparent",
												placeholder: "Observaciones / Hallazgos encontrados..."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 340,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 339,
											columnNumber: 23
										}, this)
									]
								}, elem.key, true, {
									fileName: _jsxFileName,
									lineNumber: 304,
									columnNumber: 21
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 299,
							columnNumber: 15
						}, this)]
					}, sec.key, true, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 281,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5",
				children: /* @__PURE__ */ _jsxDEV(DualPhotoUploader, {
					fotoBlob,
					fotoSrc: foto,
					previewUrl,
					onImageSelected: (file) => {
						updateField("fotoBlob", file);
						if (previewUrl) URL.revokeObjectURL(previewUrl);
						setPreviewUrl(URL.createObjectURL(file));
					},
					onRemove: () => {
						updateField("fotoBlob", null);
						updateField("foto", null);
						if (previewUrl) URL.revokeObjectURL(previewUrl);
						setPreviewUrl(null);
					},
					readOnly,
					label: "Fotografía de la Subestación / Patio de Transformadores",
					sublabel: "Cámara en vivo o selección desde galería"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 359,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 358,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-slate-50 print:border-gray-200 print:mt-3",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-900 pb-2.5 print:text-slate-700 print:border-gray-200",
					children: "Firma y Cierre de Inspección"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 382,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1.5 items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-600",
								children: "Firma del Inspector"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 389,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: firmaInspector,
								onChange: (e) => updateField("firmaInspector", e.target.value),
								className: "w-full max-w-xs bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all text-center no-print",
								placeholder: "Iniciales o Nombre del Inspector"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 390,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "hidden print:block text-xs font-bold text-slate-900 mt-1 h-6",
								children: firmaInspector || "___________________________"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 397,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "hidden print:block w-48 border-b border-gray-400 mt-6 h-1" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 400,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 388,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1.5 items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-600",
								children: "Firma / Sello de la Empresa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 405,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: firmaSupervisor,
								onChange: (e) => updateField("firmaSupervisor", e.target.value),
								className: "w-full max-w-xs bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all text-center no-print",
								placeholder: "Nombre / Sello de la Empresa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 406,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "hidden print:block text-xs font-bold text-slate-900 mt-1 h-6",
								children: firmaSupervisor || "___________________________"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 413,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "hidden print:block w-48 border-b border-gray-400 mt-6 h-1" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 416,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 404,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 386,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 381,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "text-[10px] text-slate-500 text-center leading-relaxed border-t border-slate-800 pt-4 font-sans select-none print:border-gray-200 print:text-slate-500",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "font-bold text-slate-400 uppercase print:text-slate-600",
					children: "Nota de Evaluación:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 423,
					columnNumber: 9
				}, this), " B = Bueno, R = Regular (Requiere mantenimiento preventivo), M = Malo (Acción correctiva inmediata)."]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 422,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 156,
		columnNumber: 5
	}, this);
}
_s(SubestacionComponent, "wiipo1FF4cbrO6Ttwf3TCKSMdYs=", false, function() {
	return [useConfirm];
});
_c = SubestacionComponent;
var _c;
$RefreshReg$(_c, "SubestacionComponent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SubestacionComponent.jsx?t=1790793566895";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SubestacionComponent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SubestacionComponent.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SubestacionComponent.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLFFBQVEsUUFBUSxVQUFVLFNBQVMsTUFBTSxNQUFNLE1BQU0sVUFBVSxPQUFPLEtBQUssU0FBUyxpQkFBaUI7QUFDOUcsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTyxnQ0FBZ0M7QUFDdkMsT0FBTyx1QkFBdUI7QUFDOUIsU0FBUywwQkFBMEIsK0JBQStCOzs7O0FBRWxFLGVBQWUsU0FBUyxxQkFBcUIsRUFBRSxpQkFBaUIsVUFBVSxZQUFZOztDQUNwRixNQUFNLEVBQUUsT0FBTyxhQUFhLFNBQVMsa0JBQWtCLFdBQVc7Q0FDbEUsSUFBSSxDQUFDLGlCQUFpQixPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWlDO0NBQStDOzs7OztDQUU1SCxNQUFNLEVBQ0osSUFDQSxTQUFTLElBQ1QsWUFBWSxJQUNaLFFBQVEsSUFDUixPQUFPLElBQ1AsWUFBWSxJQUNaLGVBQWUsSUFDZixXQUFXLE1BQ1gsT0FBTyxNQUNQLGFBQWEsQ0FBQyxHQUNkLGdCQUFnQixDQUFDLEdBQ2pCLGVBQWUsQ0FBQyxHQUNoQixxQkFBcUIsQ0FBQyxHQUN0QixlQUFlLENBQUMsR0FDaEIsa0JBQWtCLENBQUMsR0FDbkIsaUJBQWlCLElBQ2pCLGtCQUFrQixPQUNoQjtDQUVKLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLElBQUk7Q0FFakQsTUFBTSxlQUFlLE9BQU8sVUFBVTtFQUNwQyxJQUFJLFVBQVU7RUFDZCxTQUFTO0dBQ1AsR0FBRztJQUNGLFFBQVE7RUFDWCxDQUFDO0NBQ0g7Q0FFQSxNQUFNLDBCQUEwQixZQUFZO0VBQzFDLElBQUksVUFBVTtFQUNkLE1BQU0sWUFBWSxNQUFNLGNBQWMsZ0ZBQWdGO0VBQ3RILElBQUksQ0FBQyxXQUFXO0VBRWhCLFNBQVM7R0FDUCxHQUFHO0dBQ0gsV0FBVztHQUNYLFdBQVc7R0FDWCxjQUFjO0dBQ2QsVUFBVTtHQUNWLE1BQU07R0FDTixZQUFZLENBQUM7R0FDYixlQUFlLENBQUM7R0FDaEIsY0FBYyxDQUFDO0dBQ2Ysb0JBQW9CLENBQUM7R0FDckIsY0FBYyxDQUFDO0dBQ2YsaUJBQWlCLENBQUM7R0FDbEIsZ0JBQWdCO0dBQ2hCLGlCQUFpQjtFQUNuQixDQUFDO0VBQ0QsSUFBSSxZQUFZLElBQUksZ0JBQWdCLFVBQVU7RUFDOUMsY0FBYyxJQUFJO0NBQ3BCO0NBRUEsTUFBTSxxQkFBcUIsU0FBUyxZQUFZLE1BQU0sVUFBVTtFQUM5RCxJQUFJLFVBQVU7RUFDZCxNQUFNLGNBQWMsZ0JBQWdCLFlBQVksQ0FBQztFQUNqRCxNQUFNLFdBQVcsWUFBWSxlQUFlO0dBQUUsUUFBUTtHQUFLLGVBQWU7RUFBRztFQUU3RSxTQUFTO0dBQ1AsR0FBRztJQUNGLFVBQVU7SUFDVCxHQUFHO0tBQ0YsYUFBYTtLQUNaLEdBQUc7TUFDRixPQUFPO0lBQ1Y7R0FDRjtFQUNGLENBQUM7Q0FDSDs7Q0FHQSxNQUFNLFlBQVk7RUFDaEI7R0FDRSxLQUFLO0dBQ0wsT0FBTztHQUNQLE1BQU0sd0JBQUMsU0FBRCxFQUFTLFdBQVUseUJBQTBCOzs7OztHQUNuRCxhQUFhO0dBQ2IsVUFBVTtJQUNSO0tBQUUsS0FBSztLQUFtQixPQUFPO0lBQTJCO0lBQzVEO0tBQUUsS0FBSztLQUFnQixPQUFPO0lBQThCO0lBQzVEO0tBQUUsS0FBSztLQUF5QixPQUFPO0lBQTRCO0lBQ25FO0tBQUUsS0FBSztLQUFvQixPQUFPO0lBQTJCO0lBQzdEO0tBQUUsS0FBSztLQUFpQixPQUFPO0lBQWlDO0lBQ2hFO0tBQUUsS0FBSztLQUFrQixPQUFPO0lBQThCO0dBQ2hFO0VBQ0Y7RUFDQTtHQUNFLEtBQUs7R0FDTCxPQUFPO0dBQ1AsTUFBTSx3QkFBQyxRQUFELEVBQVEsV0FBVSx5QkFBMEI7Ozs7O0dBQ2xELGFBQWE7R0FDYixVQUFVO0lBQ1I7S0FBRSxLQUFLO0tBQWlCLE9BQU87SUFBNEM7SUFDM0U7S0FBRSxLQUFLO0tBQXdCLE9BQU87SUFBMEM7SUFDaEY7S0FBRSxLQUFLO0tBQW1CLE9BQU87SUFBK0I7SUFDaEU7S0FBRSxLQUFLO0tBQXlCLE9BQU87SUFBcUM7SUFDNUU7S0FBRSxLQUFLO0tBQW9CLE9BQU87SUFBZ0M7SUFDbEU7S0FBRSxLQUFLO0tBQWtCLE9BQU87SUFBd0M7R0FDMUU7RUFDRjtFQUNBO0dBQ0UsS0FBSztHQUNMLE9BQU87R0FDUCxNQUFNLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7Ozs7R0FDcEQsYUFBYTtHQUNiLFVBQVU7SUFDUjtLQUFFLEtBQUs7S0FBcUIsT0FBTztJQUFpQztJQUNwRTtLQUFFLEtBQUs7S0FBcUIsT0FBTztJQUFpQztJQUNwRTtLQUFFLEtBQUs7S0FBeUIsT0FBTztJQUE0QztJQUNuRjtLQUFFLEtBQUs7S0FBMkIsT0FBTztJQUE2QjtJQUN0RTtLQUFFLEtBQUs7S0FBeUIsT0FBTztJQUFvQztJQUMzRTtLQUFFLEtBQUs7S0FBd0IsT0FBTztJQUFxQztJQUMzRTtLQUFFLEtBQUs7S0FBdUIsT0FBTztJQUFzQztHQUM3RTtFQUNGO0VBQ0E7R0FDRSxLQUFLO0dBQ0wsT0FBTztHQUNQLE1BQU0sd0JBQUMsUUFBRCxFQUFRLFdBQVUseUJBQTBCOzs7OztHQUNsRCxhQUFhO0dBQ2IsVUFBVTtJQUNSO0tBQUUsS0FBSztLQUF1QixPQUFPO0lBQStDO0lBQ3BGO0tBQUUsS0FBSztLQUFzQixPQUFPO0lBQTBDO0lBQzlFO0tBQUUsS0FBSztLQUFrQixPQUFPO0lBQTBCO0lBQzFEO0tBQUUsS0FBSztLQUF1QixPQUFPO0lBQW9DO0dBQzNFO0VBQ0Y7RUFDQTtHQUNFLEtBQUs7R0FDTCxPQUFPO0dBQ1AsTUFBTSx3QkFBQyxNQUFELEVBQU0sV0FBVSx5QkFBMEI7Ozs7O0dBQ2hELGFBQWE7R0FDYixVQUFVO0lBQ1I7S0FBRSxLQUFLO0tBQW1CLE9BQU87SUFBcUI7SUFDdEQ7S0FBRSxLQUFLO0tBQXNCLE9BQU87SUFBeUI7SUFDN0Q7S0FBRSxLQUFLO0tBQXNCLE9BQU87SUFBNkM7SUFDakY7S0FBRSxLQUFLO0tBQXVCLE9BQU87SUFBb0M7R0FDM0U7RUFDRjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVyxrUUFBa1EsV0FBVyxtQ0FBbUM7WUFBaFU7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQTJGO0lBQXlDOzs7O2NBQ3BKLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQTZGLFVBQVU7SUFBNEI7Ozs7WUFDOUk7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0csQ0FBQyxZQUNBLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUpSLENBTUUsd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7OztpQkFDcEMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1CO09BQXdCOzs7O2VBQ3JEOzs7Ozs7TUFFVix3QkFBQyxVQUFEO09BQ0UsZUFBZSxPQUFPLE1BQU07T0FDNUIsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7O2lCQUFDLGNBQ3pCOzs7Ozs7TUFDUix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FBa0wsUUFDM0ssRUFDRDs7Ozs7O0tBQ0g7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsOENBQStDOzs7O2VBQUMseUJBQzlEOzs7OztjQUVKLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFvRjtPQUF3Qjs7OztpQkFDNUgsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksYUFBYSxFQUFFLE9BQU8sS0FBSztRQUN4RCxXQUFVO1FBQ1YsYUFBWTtPQUNiOzs7O2VBQ0U7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW9GO09BQW9DOzs7O2lCQUN4SSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxVQUFEO1NBQ0UsT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLGdCQUFnQixFQUFFLE9BQU8sS0FBSztTQUMzRCxXQUFVO21CQUhaO1VBS0Usd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQUc7VUFBMEM7Ozs7O1VBQzNELHdCQUFDLFlBQUQ7V0FBVSxPQUFNO3FCQUNiLHlCQUF5QixLQUFJLE1BQzVCLHdCQUFDLFVBQUQ7WUFBZ0IsT0FBTztzQkFBSTtXQUFVLEdBQXhCOzs7O2tCQUF3QixDQUN0QztVQUNPOzs7OztVQUNWLHdCQUFDLFlBQUQ7V0FBVSxPQUFNO3FCQUNiLHdCQUF3QixRQUFPLE1BQUssQ0FBQyx5QkFBeUIsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUksTUFDOUUsd0JBQUMsVUFBRDtZQUFnQixPQUFPO3NCQUFJO1dBQVUsR0FBeEI7Ozs7a0JBQXdCLENBQ3RDO1VBQ087Ozs7O1NBQ0o7Ozs7OztPQUNMOzs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW9GO09BQTBCOzs7O2lCQUM5SCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sWUFBWSxhQUFhLEVBQUUsT0FBTyxLQUFLO1FBQ3hELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7ZUFDRTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxrREFBbUQ7Ozs7a0JBQUMsc0JBQ3BFOzs7OztpQkFDTix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sWUFBWSxTQUFTLEVBQUUsT0FBTyxLQUFLO1FBQ3BELFdBQVU7T0FDWDs7OztlQUNFOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGtEQUFtRDs7OztrQkFBQyxPQUNqRTs7Ozs7aUJBQ04sd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksUUFBUSxFQUFFLE9BQU8sS0FBSztRQUNuRCxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLDRCQUFEO0lBQ2M7SUFDWixXQUFXLHFCQUFxQixZQUFZLGNBQWMsZ0JBQWdCO0lBQ2hFO0lBQ1YsUUFBTztJQUNQLFdBQVU7R0FDWDs7Ozs7R0FHRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFVBQVUsS0FBSyxRQUFRO0tBQ3RCLE1BQU0sY0FBYyxnQkFBZ0IsSUFBSSxRQUFRLENBQUM7S0FFakQsT0FDRSx3QkFBQyxPQUFEO01BQW1CLFdBQVU7Z0JBQTdCLENBRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixJQUFJO09BQ0Y7Ozs7aUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF5RCxJQUFJO09BQVU7Ozs7aUJBQ3JGLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUF3RCxJQUFJO09BQWU7Ozs7ZUFDckY7Ozs7ZUFDRjs7Ozs7Z0JBR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osSUFBSSxTQUFTLEtBQUssU0FBUztRQUMxQixNQUFNLE9BQU8sWUFBWSxLQUFLLFFBQVE7U0FBRSxRQUFRO1NBQUssZUFBZTtRQUFHO1FBRXZFLE9BQ0Usd0JBQUMsT0FBRDtTQUFvQixXQUFVO21CQUE5QjtVQUVFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUF5RCxLQUFLO1dBQVk7Ozs7O1VBQ3ZGOzs7OztVQUdMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTBHO1dBQWE7Ozs7cUJBQ3ZJLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNaO2FBQ0M7Y0FBRSxPQUFPO2NBQUssT0FBTztjQUFTLE9BQU87Y0FBMkMsT0FBTzthQUF5QjthQUNoSDtjQUFFLE9BQU87Y0FBSyxPQUFPO2NBQVcsT0FBTztjQUF5QyxPQUFPO2FBQXVCO2FBQzlHO2NBQUUsT0FBTztjQUFLLE9BQU87Y0FBUSxPQUFPO2NBQW1DLE9BQU87YUFBcUI7WUFDckcsQ0FBQyxDQUFDLEtBQUssUUFBUTthQUNiLE1BQU0sYUFBYSxLQUFLLFdBQVcsSUFBSTthQUN2QyxPQUNFLHdCQUFDLFVBQUQ7Y0FFRSxNQUFLO2NBQ0wsZUFBZSxrQkFBa0IsSUFBSSxLQUFLLEtBQUssS0FBSyxVQUFVLElBQUksS0FBSztjQUN2RSxXQUFXLDhFQUNULGFBQ0ksSUFBSSxRQUFRLDJEQUNaLDBGQUEwRixJQUFJO3dCQUduRyxJQUFJO2FBQ0MsR0FWRCxJQUFJOzs7O29CQVVIO1lBRVosQ0FBQztXQUNFOzs7O21CQUNGOzs7Ozs7VUFHTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU8sS0FBSyxpQkFBaUI7WUFDN0IsV0FBVyxNQUFNLGtCQUFrQixJQUFJLEtBQUssS0FBSyxLQUFLLGlCQUFpQixFQUFFLE9BQU8sS0FBSztZQUNyRixXQUFVO1lBQ1YsYUFBWTtXQUNiOzs7OztVQUNFOzs7OztTQUNGO1dBNUNLLEtBQUs7Ozs7ZUE0Q1Y7T0FFVCxDQUFDO01BQ0U7Ozs7Y0FDRjtRQWxFSyxJQUFJOzs7O1lBa0VUO0lBRVQsQ0FBQztHQUNFOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsbUJBQUQ7S0FDWTtLQUNWLFNBQVM7S0FDRztLQUNaLGtCQUFrQixTQUFTO01BQ3pCLFlBQVksWUFBWSxJQUFJO01BQzVCLElBQUksWUFBWSxJQUFJLGdCQUFnQixVQUFVO01BQzlDLGNBQWMsSUFBSSxnQkFBZ0IsSUFBSSxDQUFDO0tBQ3pDO0tBQ0EsZ0JBQWdCO01BQ2QsWUFBWSxZQUFZLElBQUk7TUFDNUIsWUFBWSxRQUFRLElBQUk7TUFDeEIsSUFBSSxZQUFZLElBQUksZ0JBQWdCLFVBQVU7TUFDOUMsY0FBYyxJQUFJO0tBQ3BCO0tBQ1U7S0FDVixPQUFNO0tBQ04sVUFBUztJQUNWOzs7OztHQUNFOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUF3STtJQUVsSjs7OztjQUVKLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFvRjtPQUF5Qjs7Ozs7T0FDN0gsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1FBQzdELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7O09BQ0Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2Isa0JBQWtCO09BQ2Y7Ozs7O09BQ04sd0JBQUMsT0FBRCxFQUFLLFdBQVUsNERBQWlFOzs7OztNQUM3RTs7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFvRjtPQUFpQzs7Ozs7T0FDckksd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1FBQzlELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7O09BQ0Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsbUJBQW1CO09BQ2hCOzs7OztPQUNOLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDREQUFpRTs7Ozs7TUFDN0U7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUEwRDtJQUF5Qjs7OztjQUFDLHNHQUNqRzs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlN1YmVzdGFjaW9uQ29tcG9uZW50LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBTaGllbGQsIEhhbW1lciwgQWN0aXZpdHksIENvbXBhc3MsIEhvbWUsIFNhdmUsIFVzZXIsIENhbGVuZGFyLCBDbG9jaywgWmFwLCBQcmludGVyLCBSb3RhdGVDY3cgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlQ29uZmlybSB9IGZyb20gJy4uL2NvbnRleHQvQ29uZmlybUNvbnRleHQnO1xuaW1wb3J0IE1ldHJvbG9naWFFbGVjdHJpY2FTZWN0aW9uIGZyb20gJy4vTWV0cm9sb2dpYUVsZWN0cmljYVNlY3Rpb24nO1xuaW1wb3J0IER1YWxQaG90b1VwbG9hZGVyIGZyb20gJy4vRHVhbFBob3RvVXBsb2FkZXInO1xuaW1wb3J0IHsgVEVOU0lPTkVTX0NPVkVOSU5fMTU5X01ULCBURU5TSU9ORVNfQ09WRU5JTl9UT0RBUyB9IGZyb20gJy4uL3V0aWxzL2NvbnN0YW50cyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFN1YmVzdGFjaW9uQ29tcG9uZW50KHsgc3ViZXN0YWNpb25EYXRhLCBvblVwZGF0ZSwgcmVhZE9ubHkgfSkge1xuICBjb25zdCB7IGFsZXJ0OiBjdXN0b21BbGVydCwgY29uZmlybTogY3VzdG9tQ29uZmlybSB9ID0gdXNlQ29uZmlybSgpO1xuICBpZiAoIXN1YmVzdGFjaW9uRGF0YSkgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC04IHRleHQtc2xhdGUtNDAwXCI+Tm8gaGF5IGRhdG9zIGRlIHN1YmVzdGFjacOzbiBzZWxlY2Npb25hZG9zLjwvZGl2PjtcblxuICBjb25zdCB7XG4gICAgaWQsXG4gICAgbm9tYnJlID0gJycsXG4gICAgdWJpY2FjaW9uID0gJycsXG4gICAgZmVjaGEgPSAnJyxcbiAgICBob3JhID0gJycsXG4gICAgaW5zcGVjdG9yID0gJycsXG4gICAgbml2ZWxUZW5zaW9uID0gJycsXG4gICAgZm90b0Jsb2IgPSBudWxsLFxuICAgIGZvdG8gPSBudWxsLFxuICAgIG1lZGljaW9uZXMgPSB7fSxcbiAgICBlc3RhZG9FbnRvcm5vID0ge30sXG4gICAgb2JyYXNDaXZpbGVzID0ge30sXG4gICAgZXF1aXBvc1ByaW5jaXBhbGVzID0ge30sXG4gICAgcHVlc3RhVGllcnJhID0ge30sXG4gICAgZWRpZmljaW9Db250cm9sID0ge30sXG4gICAgZmlybWFJbnNwZWN0b3IgPSBcIlwiLFxuICAgIGZpcm1hU3VwZXJ2aXNvciA9IFwiXCJcbiAgfSA9IHN1YmVzdGFjaW9uRGF0YTtcblxuICBjb25zdCBbcHJldmlld1VybCwgc2V0UHJldmlld1VybF0gPSB1c2VTdGF0ZShudWxsKTtcblxuICBjb25zdCB1cGRhdGVGaWVsZCA9IChmaWVsZCwgdmFsdWUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBvblVwZGF0ZSh7XG4gICAgICAuLi5zdWJlc3RhY2lvbkRhdGEsXG4gICAgICBbZmllbGRdOiB2YWx1ZVxuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxpbXBpYXJGb3JtdWxhcmlvID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmIChyZWFkT25seSkgcmV0dXJuO1xuICAgIGNvbnN0IGNvbmZpcm1lZCA9IGF3YWl0IGN1c3RvbUNvbmZpcm0oXCLCv0Rlc2VhcyByZWluaWNpYXIgdG9kb3MgbG9zIGNhbXBvcyBkZSBlc3RhIGluc3BlY2Npw7NuIGRlIHN1YmVzdGFjacOzbiBhIGJsYW5jbz9cIik7XG4gICAgaWYgKCFjb25maXJtZWQpIHJldHVybjtcblxuICAgIG9uVXBkYXRlKHtcbiAgICAgIC4uLnN1YmVzdGFjaW9uRGF0YSxcbiAgICAgIHViaWNhY2lvbjogJycsXG4gICAgICBpbnNwZWN0b3I6ICcnLFxuICAgICAgbml2ZWxUZW5zaW9uOiAnJyxcbiAgICAgIGZvdG9CbG9iOiBudWxsLFxuICAgICAgZm90bzogbnVsbCxcbiAgICAgIG1lZGljaW9uZXM6IHt9LFxuICAgICAgZXN0YWRvRW50b3Jubzoge30sXG4gICAgICBvYnJhc0NpdmlsZXM6IHt9LFxuICAgICAgZXF1aXBvc1ByaW5jaXBhbGVzOiB7fSxcbiAgICAgIHB1ZXN0YVRpZXJyYToge30sXG4gICAgICBlZGlmaWNpb0NvbnRyb2w6IHt9LFxuICAgICAgZmlybWFJbnNwZWN0b3I6ICcnLFxuICAgICAgZmlybWFTdXBlcnZpc29yOiAnJ1xuICAgIH0pO1xuICAgIGlmIChwcmV2aWV3VXJsKSBVUkwucmV2b2tlT2JqZWN0VVJMKHByZXZpZXdVcmwpO1xuICAgIHNldFByZXZpZXdVcmwobnVsbCk7XG4gIH07XG5cbiAgY29uc3QgdXBkYXRlU2VjdGlvbkl0ZW0gPSAoc2VjdGlvbiwgZWxlbWVudEtleSwgdHlwZSwgdmFsdWUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBzZWN0aW9uRGF0YSA9IHN1YmVzdGFjaW9uRGF0YVtzZWN0aW9uXSB8fCB7fTtcbiAgICBjb25zdCBpdGVtRGF0YSA9IHNlY3Rpb25EYXRhW2VsZW1lbnRLZXldIHx8IHsgZXN0YWRvOiAnQicsIG9ic2VydmFjaW9uZXM6ICcnIH07XG4gICAgXG4gICAgb25VcGRhdGUoe1xuICAgICAgLi4uc3ViZXN0YWNpb25EYXRhLFxuICAgICAgW3NlY3Rpb25dOiB7XG4gICAgICAgIC4uLnNlY3Rpb25EYXRhLFxuICAgICAgICBbZWxlbWVudEtleV06IHtcbiAgICAgICAgICAuLi5pdGVtRGF0YSxcbiAgICAgICAgICBbdHlwZV06IHZhbHVlXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcblxuICAvLyBEZWZpbmljacOzbiBkZSBsYXMgc2VjY2lvbmVzIHkgc3VzIGNvcnJlc3BvbmRpZW50ZXMgZWxlbWVudG9zXG4gIGNvbnN0IFNFQ0NJT05FUyA9IFtcbiAgICB7XG4gICAgICBrZXk6ICdlc3RhZG9FbnRvcm5vJyxcbiAgICAgIHRpdGxlOiAnMi4gRXN0YWRvIGRlbCBFbnRvcm5vIHkgUGVyw61tZXRybycsXG4gICAgICBpY29uOiA8Q29tcGFzcyBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNTAwXCIgLz4sXG4gICAgICBkZXNjcmlwdGlvbjogJ0V2YWzDumUgdmlzdWFsbWVudGUgbGFzIGNvbmRpY2lvbmVzIGRlIHNlZ3VyaWRhZCBleHRlcmlvciBkZWwgcGVyw61tZXRyby4nLFxuICAgICAgZWxlbWVudHM6IFtcbiAgICAgICAgeyBrZXk6ICdjZXJjYVBlcmltZXRyYWwnLCBsYWJlbDogJ0NlcmNhIHBlcmltZXRyYWwgLyBNdXJvcycgfSxcbiAgICAgICAgeyBrZXk6ICdwb3J0b25BY2Nlc28nLCBsYWJlbDogJ1BvcnTDs24gZGUgYWNjZXNvIHkgY2FuZGFkb3MnIH0sXG4gICAgICAgIHsga2V5OiAnc2VuYWxpemFjaW9uU2VndXJpZGFkJywgbGFiZWw6ICdTZcOxYWxpemFjacOzbiBkZSBzZWd1cmlkYWQnIH0sXG4gICAgICAgIHsga2V5OiAnZXN0YWRvVmlhc0FjY2VzbycsIGxhYmVsOiAnRXN0YWRvIGRlIHbDrWFzIGRlIGFjY2VzbycgfSxcbiAgICAgICAgeyBrZXk6ICdjb250cm9sTWFsZXphJywgbGFiZWw6ICdDb250cm9sIGRlIG1hbGV6YSB5IHZlZ2V0YWNpw7NuJyB9LFxuICAgICAgICB7IGtleTogJ3Npc3RlbWFEcmVuYWplJywgbGFiZWw6ICdTaXN0ZW1hIGRlIGRyZW5hamUgZGUgYWd1YXMnIH1cbiAgICAgIF1cbiAgICB9LFxuICAgIHtcbiAgICAgIGtleTogJ29icmFzQ2l2aWxlcycsXG4gICAgICB0aXRsZTogJzMuIE9icmFzIENpdmlsZXMgeSBFc3RydWN0dXJhcyBTb3BvcnRlcycsXG4gICAgICBpY29uOiA8SGFtbWVyIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci01MDBcIiAvPixcbiAgICAgIGRlc2NyaXB0aW9uOiAnSW5zcGVjY2nDs24gZGVsIGVzdGFkbyBmw61zaWNvIGRlIGxhcyBiYXNlcyBkZSBjb25jcmV0byB5IHNvcG9ydGVzIGRlIGVxdWlwb3MuJyxcbiAgICAgIGVsZW1lbnRzOiBbXG4gICAgICAgIHsga2V5OiAnYmFzZXNDb25jcmV0bycsIGxhYmVsOiAnQmFzZXMgZGUgY29uY3JldG8gKEZpc3VyYXMvQXNlbnRhbWllbnRvcyknIH0sXG4gICAgICAgIHsga2V5OiAnZXN0cnVjdHVyYXNNZXRhbGljYXMnLCBsYWJlbDogJ0VzdHJ1Y3R1cmFzIG1ldMOhbGljYXMgKMOTeGlkby9Db3Jyb3Npw7NuKScgfSxcbiAgICAgICAgeyBrZXk6ICdwb3J0aWNvc0xsZWdhZGEnLCBsYWJlbDogJ1DDs3J0aWNvcyBkZSBsbGVnYWRhIHkgc2FsaWRhJyB9LFxuICAgICAgICB7IGtleTogJ3Rvcm5pbGxlcmlhQ29uZXhpb25lcycsIGxhYmVsOiAnVG9ybmlsbGVyw61hIHkgY29uZXhpb25lcyBtZWPDoW5pY2FzJyB9LFxuICAgICAgICB7IGtleTogJ211cm9zQ29ydGFmdWVnb3MnLCBsYWJlbDogJ011cm9zIGNvcnRhZnVlZ29zIChzaSBhcGxpY2EpJyB9LFxuICAgICAgICB7IGtleTogJ2VzdGFkb0dyYXZpbGxhJywgbGFiZWw6ICdFc3RhZG8gZGUgbGEgZ3JhdmlsbGEvcGllZHJhIGNoYW5jYWRhJyB9XG4gICAgICBdXG4gICAgfSxcbiAgICB7XG4gICAgICBrZXk6ICdlcXVpcG9zUHJpbmNpcGFsZXMnLFxuICAgICAgdGl0bGU6ICc0LiBJbnNwZWNjacOzbiBWaXN1YWwgZGUgRXF1aXBvcyBQcmluY2lwYWxlcycsXG4gICAgICBpY29uOiA8QWN0aXZpdHkgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTUwMFwiIC8+LFxuICAgICAgZGVzY3JpcHRpb246ICdEZXRlY2Npw7NuIGRlIGZ1Z2FzLCBzdWNpZWRhZCwgZGHDsW9zIG1lY8Ohbmljb3MgeSBuaXZlbGVzIGRlIGZsdWlkb3MuJyxcbiAgICAgIGVsZW1lbnRzOiBbXG4gICAgICAgIHsga2V5OiAndHJhbnNmRnVnYXNBY2VpdGUnLCBsYWJlbDogJ1RyYW5zZm9ybWFkb3I6IEZ1Z2FzIGRlIGFjZWl0ZScgfSxcbiAgICAgICAgeyBrZXk6ICd0cmFuc2ZOaXZlbEFjZWl0ZScsIGxhYmVsOiAnVHJhbnNmb3JtYWRvcjogTml2ZWwgZGUgYWNlaXRlJyB9LFxuICAgICAgICB7IGtleTogJ2ludGVycnVwdG9yZXNQb3RlbmNpYScsIGxhYmVsOiAnSW50ZXJydXB0b3JlcyBkZSBwb3RlbmNpYSAoRXN0YWRvIHZpc3VhbCknIH0sXG4gICAgICAgIHsga2V5OiAnc2VjY2lvbmFkb3Jlc0NvcnRhZG9yZXMnLCBsYWJlbDogJ1NlY2Npb25hZG9yZXMgKGNvcnRhZG9yZXMpJyB9LFxuICAgICAgICB7IGtleTogJ3RyYW5zZm9ybWFkb3Jlc01lZGlkYScsIGxhYmVsOiAnVHJhbnNmb3JtYWRvcmVzIGRlIG1lZGlkYSAoQ1QvUFQpJyB9LFxuICAgICAgICB7IGtleTogJ3BhcmFycmF5b3NBaXNsYWRvcmVzJywgbGFiZWw6ICdQYXJhcnJheW9zIChDb250YWRvcmVzL0Fpc2xhZG9yZXMpJyB9LFxuICAgICAgICB7IGtleTogJ2Fpc2xhZG9yZXNQb3JjZWxhbmEnLCBsYWJlbDogJ0Fpc2xhZG9yZXMgZGUgcG9yY2VsYW5hL3BvbGltw6lyaWNvcycgfVxuICAgICAgXVxuICAgIH0sXG4gICAge1xuICAgICAga2V5OiAncHVlc3RhVGllcnJhJyxcbiAgICAgIHRpdGxlOiAnNS4gU2lzdGVtYSBkZSBQdWVzdGEgYSBUaWVycmEgeSBDb25leGlvbmVzJyxcbiAgICAgIGljb246IDxTaGllbGQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTUwMFwiIC8+LFxuICAgICAgZGVzY3JpcHRpb246ICdWZXJpZmljYWNpw7NuIHZpc3VhbCB5IGVzdGFkbyBkZSBjb25leGlvbmVzIGRlIHB1ZXN0YSBhIHRpZXJyYSAoU1BUKS4nLFxuICAgICAgZWxlbWVudHM6IFtcbiAgICAgICAgeyBrZXk6ICdtZWRpY2lvblJlc2lzdGVuY2lhJywgbGFiZWw6ICdNZWRpY2lvbmVzIGRlIHJlc2lzdGVuY2lhIGRlIG1hbGxhIGRlIHRpZXJyYScgfSxcbiAgICAgICAgeyBrZXk6ICdjb25leGlvbmVzVmlzaWJsZXMnLCBsYWJlbDogJ0NvbmV4aW9uZXMgdmlzaWJsZXMgZGUgZXF1aXBvcyBhIHRpZXJyYScgfSxcbiAgICAgICAgeyBrZXk6ICdlc3RhZG9DYWJsZVNwdCcsIGxhYmVsOiAnRXN0YWRvIGRlbCBjYWJsZSBkZSBTUFQnIH0sXG4gICAgICAgIHsga2V5OiAnY29ycm9zaW9uQ29uZWN0b3JlcycsIGxhYmVsOiAnQ29ycm9zacOzbiBlbiBjb25lY3RvcmVzIGRlIHRpZXJyYScgfVxuICAgICAgXVxuICAgIH0sXG4gICAge1xuICAgICAga2V5OiAnZWRpZmljaW9Db250cm9sJyxcbiAgICAgIHRpdGxlOiAnNi4gRWRpZmljaW8gZGUgQ29udHJvbCB5IFNhbGEgZGUgVGFibGVyb3MnLFxuICAgICAgaWNvbjogPEhvbWUgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTUwMFwiIC8+LFxuICAgICAgZGVzY3JpcHRpb246ICdWZXJpZmljYWNpw7NuIGRlIGVxdWlwb3MsIGxpbXBpZXphLCBpbHVtaW5hY2nDs24geSBzaXN0ZW1hcyBkZSBzZWd1cmlkYWQuJyxcbiAgICAgIGVsZW1lbnRzOiBbXG4gICAgICAgIHsga2V5OiAndGFibGVyb3NDb250cm9sJywgbGFiZWw6ICdUYWJsZXJvcyB5IGNvbnRyb2wnIH0sXG4gICAgICAgIHsga2V5OiAnYmFuY29Db25kZW5zYWRvcmVzJywgbGFiZWw6ICdCYW5jbyBkZSBjb25kZW5zYWRvcmVzJyB9LFxuICAgICAgICB7IGtleTogJ3Npc3RlbWFJbHVtaW5hY2lvbicsIGxhYmVsOiAnU2lzdGVtYSBkZSBpbHVtaW5hY2nDs24gKE5vcm1hbC9FbWVyZ2VuY2lhKScgfSxcbiAgICAgICAgeyBrZXk6ICdleHRpbnRvcmVzSW5jZW5kaW9zJywgbGFiZWw6ICdFc3RhZG8gZGUgZXh0aW50b3JlcyBkZSBpbmNlbmRpb3MnIH1cbiAgICAgIF1cbiAgICB9XG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YHctZnVsbCB0ZXh0LXNsYXRlLTEwMCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IG1kOnAtOCBzaGFkb3cteGwgYmFja2Ryb3AtYmx1ci1tZCBzZWxlY3QtdGV4dCBtYXgtdy01eGwgbXgtYXV0byBzcGFjZS15LTggcHJpbnQtY2FyZCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItbm9uZSBwcmludDpzaGFkb3ctbm9uZSBwcmludDpwLTAgcHJpbnQ6bS0wICR7cmVhZE9ubHkgPyAncG9pbnRlci1ldmVudHMtbm9uZSBvcGFjaXR5LTkwJyA6ICcnfWB9PlxuICAgICAgey8qIEVuY2FiZXphZG8gR2VuZXJhbCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWQ6aXRlbXMtY2VudGVyIGdhcC00IHBiLTYgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwcmludDpib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTUwMCBmb250LWV4dHJhYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHByaW50OnRleHQtYW1iZXItNjAwXCI+SW5zcGVjY2nDs24gZGUgU3ViZXN0YWNpw7NuIEVsw6ljdHJpY2E8L3NwYW4+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgbWQ6dGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS0xMDAgdHJhY2tpbmctd2lkZSBtdC0xIHByaW50OnRleHQtc2xhdGUtOTAwXCI+e25vbWJyZSB8fCAnU3ViZXN0YWNpw7NuIEVsw6ljdHJpY2EnfTwvaDI+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgeyFyZWFkT25seSAmJiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMaW1waWFyRm9ybXVsYXJpb31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibm8tcHJpbnQgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXJlZC05NTAvNjAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1yZWQtNDAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1yZWQtODAwIGZvbnQtYm9sZCBweC0zIHB5LTIgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICB0aXRsZT1cIlJlaW5pY2lhciB0b2RvcyBsb3MgY2FtcG9zIGEgYmxhbmNvXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5MaW1waWFyIEZvcm11bGFyaW88L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5wcmludCgpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibm8tcHJpbnQgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIHB4LTMuNSBweS0yIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBzaGFkb3ctc21cIlxuICAgICAgICAgICAgdGl0bGU9XCJHdWFyZGFyIGNvbW8gUERGIG8gSW1wcmltaXIgZXN0YSBJbnNwZWNjacOzblwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IEd1YXJkYXIgUERGXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtbW9ubyBmb250LWJsYWNrIHRleHQtYW1iZXItNDAwIGJnLWFtYmVyLTUwMC8xMCBweC0yLjUgcHktMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIHRleHQteHMgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICBJRDoge2lkfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIDEuIEluZm9ybWFjacOzbiBHZW5lcmFsICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgcm91bmRlZC0yeGwgcC01IHNwYWNlLXktNCBwcmludDpiZy1zbGF0ZS01MCBwcmludDpib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBib3JkZXItYiBib3JkZXItc2xhdGUtOTAwIHBiLTIuNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwcmludDp0ZXh0LXNsYXRlLTcwMCBwcmludDpib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwIHByaW50OnRleHQtYW1iZXItNjAwXCIgLz4gMS4gSW5mb3JtYWNpw7NuIEdlbmVyYWxcbiAgICAgICAgPC9oMz5cbiAgICAgICAgXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNVwiPlxuICAgICAgICAgIHsvKiBVYmljYWNpw7NuIC8gQ8OzZGlnbyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHByaW50OnRleHQtc2xhdGUtNjAwXCI+VWJpY2FjacOzbiAvIEPDs2RpZ288L3NwYW4+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17dWJpY2FjaW9ufVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUZpZWxkKCd1YmljYWNpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBwcmludDpwbGFjZWhvbGRlci10cmFuc3BhcmVudFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIFBhdGlvIGRlIFRyYW5zZm9ybWFkb3JlcyBBXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogTml2ZWwgZGUgVGVuc2nDs24gTm9ybWFsaXphZG8gKENPVkVOSU4gMTU5KSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHByaW50OnRleHQtc2xhdGUtNjAwXCI+Tml2ZWwgZGUgVGVuc2nDs24gKENPVkVOSU4gMTU5KTwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgdmFsdWU9e25pdmVsVGVuc2lvbn1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUZpZWxkKCduaXZlbFRlbnNpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIGZvbnQtbW9ubyBmb250LWJvbGRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPi0tIFNlbGVjY2lvbmFyIE5pdmVsIGRlIFRlbnNpw7NuIC0tPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGdyb3VwIGxhYmVsPVwiTWVkaWEgVGVuc2nDs24gKE1UIC0gQ09WRU5JTiAxNTkpXCI+XG4gICAgICAgICAgICAgICAgICB7VEVOU0lPTkVTX0NPVkVOSU5fMTU5X01ULm1hcCh2ID0+IChcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3Z9IHZhbHVlPXt2fT57dn08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvb3B0Z3JvdXA+XG4gICAgICAgICAgICAgICAgPG9wdGdyb3VwIGxhYmVsPVwiQmFqYSBUZW5zacOzbiAoQlQgLSBDT1ZFTklOIDE1OSlcIj5cbiAgICAgICAgICAgICAgICAgIHtURU5TSU9ORVNfQ09WRU5JTl9UT0RBUy5maWx0ZXIodiA9PiAhVEVOU0lPTkVTX0NPVkVOSU5fMTU5X01ULmluY2x1ZGVzKHYpKS5tYXAodiA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt2fSB2YWx1ZT17dn0+e3Z9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L29wdGdyb3VwPlxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEluc3BlY3RvciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHByaW50OnRleHQtc2xhdGUtNjAwXCI+Tm9tYnJlIGRlbCBJbnNwZWN0b3I8L3NwYW4+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17aW5zcGVjdG9yfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUZpZWxkKCdpbnNwZWN0b3InLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBwcmludDpwbGFjZWhvbGRlci10cmFuc3BhcmVudFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tYnJlIHkgQXBlbGxpZG9cIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBGZWNoYSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5cbiAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNTAwXCIgLz4gRmVjaGEgZGUgSW5zcGVjY2nDs25cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmZWNoYX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnZmVjaGEnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIGZvbnQtbW9ubyBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBIb3JhICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPlxuICAgICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS01MDBcIiAvPiBIb3JhXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRpbWVcIlxuICAgICAgICAgICAgICB2YWx1ZT17aG9yYX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnaG9yYScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgZm9udC1tb25vIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTWV0cm9sb2fDrWEgRWzDqWN0cmljYSBkZSBsYSBTdWJlc3RhY2nDs24gKi99XG4gICAgICA8TWV0cm9sb2dpYUVsZWN0cmljYVNlY3Rpb25cbiAgICAgICAgbWVkaWNpb25lcz17bWVkaWNpb25lc31cbiAgICAgICAgb25DaGFuZ2U9eyhudWV2YXNNZWRpY2lvbmVzKSA9PiB1cGRhdGVGaWVsZCgnbWVkaWNpb25lcycsIG51ZXZhc01lZGljaW9uZXMpfVxuICAgICAgICByZWFkT25seT17cmVhZE9ubHl9XG4gICAgICAgIHRpdHVsbz1cIk1ldHJvbG9nw61hIEVsw6ljdHJpY2EgZW4gU3ViZXN0YWNpw7NuIChDT1ZFTklOIDE1OSlcIlxuICAgICAgICBzdWJ0aXR1bG89XCJNZWRpY2nDs24gZGUgdm9sdGFqZXMgZGUgbMOtbmVhIEwtTCwgZmFzZSBMLU4geSA1IGNhbmFsZXMgZGUgY29ycmllbnRlIGVuIGNlbGRhIG8gYmFycmFqZVwiXG4gICAgICAvPlxuXG4gICAgICB7LyogQmxvcXVlcyBkZSBFdmFsdWFjacOzbiBWaXN1YWwgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPlxuICAgICAgICB7U0VDQ0lPTkVTLm1hcCgoc2VjKSA9PiB7XG4gICAgICAgICAgY29uc3Qgc2VjdGlvbkRhdGEgPSBzdWJlc3RhY2lvbkRhdGFbc2VjLmtleV0gfHwge307XG5cbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e3NlYy5rZXl9IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MC8yMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtIHByaW50OmJnLXdoaXRlIHByaW50OmJvcmRlci1ncmF5LTIwMCBwcmludDpzaGFkb3ctbm9uZVwiPlxuICAgICAgICAgICAgICB7LyogRW5jYWJlemFkbyBTZWNjacOzbiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvNDAgcHgtNSBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1zdGFydCBnYXAtMyBwcmludDpiZy1zbGF0ZS01MCBwcmludDpib3JkZXItZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBtdC0wLjUgc2hhZG93LWlubmVyIHByaW50OmJnLXdoaXRlIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAge3NlYy5pY29ufVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDAgcHJpbnQ6dGV4dC1zbGF0ZS04MDBcIj57c2VjLnRpdGxlfTwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBtdC0xIHByaW50OnRleHQtc2xhdGUtNTAwXCI+e3NlYy5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBHcmlkIC8gVGFibGEgcGFyYSBsb3MgRWxlbWVudG9zICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS04MDAvNjAgcHJpbnQ6ZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAge3NlYy5lbGVtZW50cy5tYXAoKGVsZW0pID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBzZWN0aW9uRGF0YVtlbGVtLmtleV0gfHwgeyBlc3RhZG86ICdCJywgb2JzZXJ2YWNpb25lczogJycgfTtcblxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2VsZW0ua2V5fSBjbGFzc05hbWU9XCJwLTQgbWQ6cC01IGZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgbWQ6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBob3ZlcjpiZy1zbGF0ZS05MDAvMTAgdHJhbnNpdGlvbi1hbGwgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogTm9tYnJlIGRlbCBFbGVtZW50byAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOnctWzM1JV0gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDAgcHJpbnQ6dGV4dC1zbGF0ZS04MDBcIj57ZWxlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQm90b25lcyBkZSBFc3RhZG8gKEIgLyBSIC8gTSkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1yLTIgaGlkZGVuIG1kOmlubGluZSBwcmludDp0ZXh0LXNsYXRlLTUwMFwiPkVzdGFkbzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYmctc2xhdGUtOTAwLzYwIHAtMSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHNoYWRvdy1pbm5lciBwcmludDpiZy1ncmF5LTEwMCBwcmludDpib3JkZXItZ3JheS0zMDAgcHJpbnQ6c2hhZG93LW5vbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnQicsIGxhYmVsOiAnQnVlbm8nLCBjb2xvcjogJ2JnLWVtZXJhbGQtNTAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCcsIGhvdmVyOiAnaG92ZXI6dGV4dC1lbWVyYWxkLTQwMCcgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnUicsIGxhYmVsOiAnUmVndWxhcicsIGNvbG9yOiAnYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCcsIGhvdmVyOiAnaG92ZXI6dGV4dC1hbWJlci00MDAnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJ00nLCBsYWJlbDogJ01hbG8nLCBjb2xvcjogJ2JnLXJlZC01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQnLCBob3ZlcjogJ2hvdmVyOnRleHQtcmVkLTQwMCcgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBdLm1hcCgob3B0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IGl0ZW0uZXN0YWRvID09PSBvcHQudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHQudmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB1cGRhdGVTZWN0aW9uSXRlbShzZWMua2V5LCBlbGVtLmtleSwgJ2VzdGFkbycsIG9wdC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHRleHQtWzEwcHhdIHJvdW5kZWQtbGcgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gb3B0LmNvbG9yICsgJyBzaGFkb3ctbWQgc2NhbGUtMTA1IHByaW50OnNoYWRvdy1ub25lIHByaW50OnNjYWxlLTEwMCcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3ZlcjpiZy1zbGF0ZS04MDAvNTAgcHJpbnQ6dGV4dC1zbGF0ZS00MDAgcHJpbnQ6aG92ZXI6YmctdHJhbnNwYXJlbnQgJyArIG9wdC5ob3ZlclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wdC52YWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogSW5wdXQgZGUgT2JzZXJ2YWNpb25lcyAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy1bMzAlXVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0ub2JzZXJ2YWNpb25lcyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVTZWN0aW9uSXRlbShzZWMua2V5LCBlbGVtLmtleSwgJ29ic2VydmFjaW9uZXMnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAvNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCBwbGFjZWhvbGRlci1zbGF0ZS02MDAgZm9udC1zYW5zIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMCBwcmludDpwbGFjZWhvbGRlci10cmFuc3BhcmVudFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiT2JzZXJ2YWNpb25lcyAvIEhhbGxhemdvcyBlbmNvbnRyYWRvcy4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIENhcmdhIER1YWwgZGUgRm90b2dyYWbDrWFzIGRlIGxhIFN1YmVzdGFjacOzbiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHJvdW5kZWQtMnhsIHAtNVwiPlxuICAgICAgICA8RHVhbFBob3RvVXBsb2FkZXJcbiAgICAgICAgICBmb3RvQmxvYj17Zm90b0Jsb2J9XG4gICAgICAgICAgZm90b1NyYz17Zm90b31cbiAgICAgICAgICBwcmV2aWV3VXJsPXtwcmV2aWV3VXJsfVxuICAgICAgICAgIG9uSW1hZ2VTZWxlY3RlZD17KGZpbGUpID0+IHtcbiAgICAgICAgICAgIHVwZGF0ZUZpZWxkKCdmb3RvQmxvYicsIGZpbGUpO1xuICAgICAgICAgICAgaWYgKHByZXZpZXdVcmwpIFVSTC5yZXZva2VPYmplY3RVUkwocHJldmlld1VybCk7XG4gICAgICAgICAgICBzZXRQcmV2aWV3VXJsKFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSkpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25SZW1vdmU9eygpID0+IHtcbiAgICAgICAgICAgIHVwZGF0ZUZpZWxkKCdmb3RvQmxvYicsIG51bGwpO1xuICAgICAgICAgICAgdXBkYXRlRmllbGQoJ2ZvdG8nLCBudWxsKTtcbiAgICAgICAgICAgIGlmIChwcmV2aWV3VXJsKSBVUkwucmV2b2tlT2JqZWN0VVJMKHByZXZpZXdVcmwpO1xuICAgICAgICAgICAgc2V0UHJldmlld1VybChudWxsKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIHJlYWRPbmx5PXtyZWFkT25seX1cbiAgICAgICAgICBsYWJlbD1cIkZvdG9ncmFmw61hIGRlIGxhIFN1YmVzdGFjacOzbiAvIFBhdGlvIGRlIFRyYW5zZm9ybWFkb3Jlc1wiXG4gICAgICAgICAgc3VibGFiZWw9XCJDw6FtYXJhIGVuIHZpdm8gbyBzZWxlY2Npw7NuIGRlc2RlIGdhbGVyw61hXCJcbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQ2llcnJlIC8gRmlybWFzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgcm91bmRlZC0yeGwgcC01IHNwYWNlLXktNCBwcmludDpiZy1zbGF0ZS01MCBwcmludDpib3JkZXItZ3JheS0yMDAgcHJpbnQ6bXQtM1wiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS05MDAgcGItMi41IHByaW50OnRleHQtc2xhdGUtNzAwIHByaW50OmJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgIEZpcm1hIHkgQ2llcnJlIGRlIEluc3BlY2Npw7NuXG4gICAgICAgIDwvaDM+XG4gICAgICAgIFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cbiAgICAgICAgICB7LyogRmlybWEgSW5zcGVjdG9yICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMS41IGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHByaW50OnRleHQtc2xhdGUtNjAwXCI+RmlybWEgZGVsIEluc3BlY3Rvcjwvc3Bhbj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmaXJtYUluc3BlY3Rvcn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnZmlybWFJbnNwZWN0b3InLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy14cyBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCB0ZXh0LWNlbnRlciBuby1wcmludFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSW5pY2lhbGVzIG8gTm9tYnJlIGRlbCBJbnNwZWN0b3JcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBwcmludDpibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtdC0xIGgtNlwiPlxuICAgICAgICAgICAgICB7ZmlybWFJbnNwZWN0b3IgfHwgJ19fX19fX19fX19fX19fX19fX19fX19fX19fXyd9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBwcmludDpibG9jayB3LTQ4IGJvcmRlci1iIGJvcmRlci1ncmF5LTQwMCBtdC02IGgtMVwiPjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEZpcm1hIC8gU2VsbG8gZGUgbGEgRW1wcmVzYSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEuNSBpdGVtcy1jZW50ZXIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPkZpcm1hIC8gU2VsbG8gZGUgbGEgRW1wcmVzYTwvc3Bhbj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmaXJtYVN1cGVydmlzb3J9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ2Zpcm1hU3VwZXJ2aXNvcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyIG5vLXByaW50XCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb21icmUgLyBTZWxsbyBkZSBsYSBFbXByZXNhXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gcHJpbnQ6YmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbXQtMSBoLTZcIj5cbiAgICAgICAgICAgICAge2Zpcm1hU3VwZXJ2aXNvciB8fCAnX19fX19fX19fX19fX19fX19fX19fX19fX19fJ31cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHByaW50OmJsb2NrIHctNDggYm9yZGVyLWIgYm9yZGVyLWdyYXktNDAwIG10LTYgaC0xXCI+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBMZXllbmRhIGRlIEV2YWx1YWNpw7NuICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCB0ZXh0LWNlbnRlciBsZWFkaW5nLXJlbGF4ZWQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBwdC00IGZvbnQtc2FucyBzZWxlY3Qtbm9uZSBwcmludDpib3JkZXItZ3JheS0yMDAgcHJpbnQ6dGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBwcmludDp0ZXh0LXNsYXRlLTYwMFwiPk5vdGEgZGUgRXZhbHVhY2nDs246PC9zcGFuPiBCID0gQnVlbm8sIFIgPSBSZWd1bGFyIChSZXF1aWVyZSBtYW50ZW5pbWllbnRvIHByZXZlbnRpdm8pLCBNID0gTWFsbyAoQWNjacOzbiBjb3JyZWN0aXZhIGlubWVkaWF0YSkuXG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==