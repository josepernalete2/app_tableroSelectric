import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/EmpresaView.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=f49807c8";
import useStore, { formatElementTitleWithId } from "/src/store/useStore.js?t=1790792337841";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
import ModalDiagramaUnifilar from "/src/components/ModalDiagramaUnifilar.jsx?t=1790792337841";
import AvanceProgressBar from "/src/components/AvanceProgressBar.jsx";
import ElementoCardActions from "/src/components/ElementoCardActions.jsx";
import { TENSIONES_COVENIN_159_BT, TENSIONES_COVENIN_159_MT, TENSIONES_COVENIN_TODAS } from "/src/utils/constants.js";
import { ArrowLeft, Plus, Search, AlertTriangle, FolderOpen, X, Building, Layers, Zap, Trash2, Camera, Calendar, User, Cpu, ShieldAlert, RefreshCw, CheckSquare, Database, Gauge, Edit3 } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/EmpresaView.jsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
// Componente para renderizar Blobs de forma segura evitando fugas de memoria
const SafeImage = ({ blob, src, alt, className }) => {
	_s();
	const [objectUrl, setObjectUrl] = useState(null);
	useEffect(() => {
		if (blob) {
			const url = URL.createObjectURL(blob);
			setObjectUrl(url);
			return () => {
				URL.revokeObjectURL(url);
			};
		} else {
			setObjectUrl(null);
		}
	}, [blob]);
	const finalSrc = objectUrl || src;
	if (!finalSrc) return null;
	return /* @__PURE__ */ _jsxDEV("img", {
		src: finalSrc,
		alt,
		className
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 10
	}, this);
};
_s(SafeImage, "Q4ugJUn5miWrvY9z1+S4+H7NbYg=");
_c = SafeImage;
export const EmpresaView = () => {
	_s2();
	const { companyId } = useParams();
	const navigate = useNavigate();
	const { user, companies, addProyecto, deleteProyecto, addElementoUnifilar, deleteElementoUnifilar, updateEmpresa, showToast } = useStore();
	const company = companies.find((c) => c.id === companyId);
	const { confirm, alert: customAlert } = useConfirm();
	// Estados para Edición de Empresa
	const [showEditEmpresaModal, setShowEditEmpresaModal] = useState(false);
	const [editNombre, setEditNombre] = useState("");
	const [editRif, setEditRif] = useState("");
	const [editDireccionFiscal, setEditDireccionFiscal] = useState("");
	const [editGerente1Nombre, setEditGerente1Nombre] = useState("");
	const [editGerente1Telefono, setEditGerente1Telefono] = useState("");
	const [editGerente1Email, setEditGerente1Email] = useState("");
	const [editGerente2Nombre, setEditGerente2Nombre] = useState("");
	const [editGerente2Telefono, setEditGerente2Telefono] = useState("");
	const [editGerente2Email, setEditGerente2Email] = useState("");
	const handleUpdateEmpresaSubmit = async (e) => {
		e.preventDefault();
		await updateEmpresa(companyId, {
			nombre: editNombre,
			rif: editRif,
			direccionFiscal: editDireccionFiscal,
			gerente1Nombre: editGerente1Nombre || null,
			gerente1Telefono: editGerente1Telefono || null,
			gerente1Email: editGerente1Email || null,
			gerente2Nombre: editGerente2Nombre || null,
			gerente2Telefono: editGerente2Telefono || null,
			gerente2Email: editGerente2Email || null
		});
		showToast("Datos de la empresa actualizados correctamente.", "success");
		setShowEditEmpresaModal(false);
	};
	// Modales y búsqueda
	const [showModal, setShowModal] = useState(false);
	const [showElementoModal, setShowElementoModal] = useState(false);
	const [searchQuery, setSearchQuery] = useState("");
	// Estados de selección múltiple
	const [isMultiSelectMode, setIsMultiSelectMode] = useState(false);
	const [selectedIds, setSelectedIds] = useState(new Set());
	// Limpiar selección cuando cambia la búsqueda
	useEffect(() => {
		setSelectedIds(new Set());
	}, [searchQuery]);
	const handleToggleSelect = (id) => {
		setSelectedIds((prev) => {
			const next = new Set(prev);
			if (next.has(id)) {
				next.delete(id);
			} else {
				next.add(id);
			}
			return next;
		});
	};
	const handleSelectAll = () => {
		const listToSelect = typeof filteredElementosGenerales !== "undefined" ? filteredElementosGenerales : [];
		const ids = listToSelect.map((e) => e.id);
		setSelectedIds(new Set(ids));
	};
	const handleDeselectAll = () => {
		setSelectedIds(new Set());
	};
	const handleDeleteSelected = async () => {
		const selectedCount = selectedIds.size;
		if (selectedCount === 0) return;
		const ok = await confirm({
			title: "Eliminar equipos seleccionados",
			message: `¿Estás seguro de que deseas eliminar los ${selectedCount} equipos seleccionados?`,
			type: "danger",
			confirmText: "Eliminar seleccionados"
		});
		if (ok) {
			selectedIds.forEach((id) => {
				deleteElementoUnifilar(null, id);
			});
			showToast?.(`Se eliminaron ${selectedCount} equipos correctamente`, "success");
			setSelectedIds(new Set());
			setIsMultiSelectMode(false);
		}
	};
	const handleDeleteProyecto = async (proyectoId, name) => {
		const ok = await confirm({
			title: "Eliminar Proyecto",
			message: `¿Estás seguro de que deseas eliminar el proyecto "${name}"? Se eliminarán todas sus subestaciones, tableros y elementos unifilares en cascada.`,
			type: "danger",
			confirmText: "Eliminar Proyecto"
		});
		if (ok) {
			deleteProyecto(companyId, proyectoId);
			showToast?.("Proyecto eliminado correctamente", "success");
		}
	};
	// Form states de Proyectos
	const [proyectoNombre, setProyectoNombre] = useState("");
	const [proyectoDescripcion, setProyectoDescripcion] = useState("");
	// Form states de Elementos (Fuera de Proyectos)
	const [tipoElemento, setTipoElemento] = useState("TABLERO");
	const [elementoNombre, setElementoNombre] = useState("");
	const [ubicacion, setUbicacion] = useState("");
	const [alimentadoPor, setAlimentadoPor] = useState("");
	const [observacionesGenerales, setObservacionesGenerales] = useState("");
	const [fotoBlob, setFotoBlob] = useState(null);
	const [previewUrl, setPreviewUrl] = useState(null);
	// Campos de Tablero
	const [maxPoles, setMaxPoles] = useState(24);
	// Campos de Transformador
	const [kvaTrafo, setKvaTrafo] = useState("");
	const [marcaTrafo, setMarcaTrafo] = useState("");
	const [tipoTrafo, setTipoTrafo] = useState("Pedestal");
	const [conexionTrafo, setConexionTrafo] = useState("");
	const [voltajePrimario, setVoltajePrimario] = useState("");
	const [voltajeSecundario, setVoltajeSecundario] = useState("");
	// Campos de Generador
	const [kvaGen, setKvaGen] = useState("");
	const [combustibleGen, setCombustibleGen] = useState("DIESEL");
	const [voltajeGen, setVoltajeGen] = useState("");
	const [potenciaKwGen, setPotenciaKwGen] = useState("");
	const [amperajeGen, setAmperajeGen] = useState("");
	// Campos de Puesta a Tierra
	const [resistenciaOhmios, setResistenciaOhmios] = useState("");
	const [corrienteFuga, setCorrienteFuga] = useState("");
	const [tipoMalla, setTipoMalla] = useState("");
	const [cableAcometidaTierra, setCableAcometidaTierra] = useState("");
	// Campos de Transfer
	const [capacidadAmperios, setCapacidadAmperios] = useState("");
	const [tipoTransferencia, setTipoTransferencia] = useState("AUTOMATICA");
	const [tensionOperativa, setTensionOperativa] = useState("");
	// Campos de Banco de Condensadores
	const [kvarTotal, setKvarTotal] = useState("");
	const [pasosCondensador, setPasosCondensador] = useState("");
	const [tipoBanco, setTipoBanco] = useState("AUTOMATICO");
	const [tensionBanco, setTensionBanco] = useState("");
	// Campos de Punto de Suministro
	const [suministroTension, setSuministroTension] = useState("");
	const [suministroEmpresa, setSuministroEmpresa] = useState("CORPOELEC");
	const [suministroTipoAcometida, setSuministroTipoAcometida] = useState("Subterránea");
	const [suministroCapacidad, setSuministroCapacidad] = useState("");
	const [suministroTipoMedicion, setSuministroTipoMedicion] = useState("Medición Directa (Baja Tensión)");
	const [suministroEnlaceCorpoelec, setSuministroEnlaceCorpoelec] = useState(true);
	const [suministroNumeroContrato, setSuministroNumeroContrato] = useState("");
	const [suministroNic, setSuministroNic] = useState("");
	const [suministroPosteTrafo, setSuministroPosteTrafo] = useState("");
	// Campos de CCM Elemento
	const [ccmCapacidadBarra, setCcmCapacidadBarra] = useState("");
	const [ccmTension, setCcmTension] = useState("");
	const [ccmBreakerPrincipal, setCcmBreakerPrincipal] = useState("");
	const [ccmNumeroGavetas, setCcmNumeroGavetas] = useState(8);
	// Campos de Otro
	const [descripcionOtro, setDescripcionOtro] = useState("");
	const [showDiagramModal, setShowDiagramModal] = useState(false);
	const companyElementos = useMemo(() => {
		if (!company) return [];
		const list = [];
		if (company.elementosUnifilares) {
			list.push(...company.elementosUnifilares);
		}
		if (company.proyectos) {
			company.proyectos.forEach((p) => {
				const pList = p.elementosUnifilares || p.tableros || [];
				list.push(...pList);
			});
		}
		return list;
	}, [company]);
	if (!company) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center p-6 text-center space-y-4 font-sans",
			children: [
				/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-12 h-12 text-amber-500 animate-pulse" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 264,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-bold",
					children: "Empresa no encontrada"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 265,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => navigate("/"),
					className: "px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs rounded-xl font-bold transition-all shadow-md",
					children: "Volver al Dashboard"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 266,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 263,
			columnNumber: 7
		}, this);
	}
	const proyectos = company.proyectos || [];
	const elementosGenerales = company.elementosUnifilares || [];
	const filteredProjects = proyectos.filter((p) => p.nombre.toLowerCase().includes(searchQuery.toLowerCase()) || p.descripcion && p.descripcion.toLowerCase().includes(searchQuery.toLowerCase()));
	const filteredElementosGenerales = elementosGenerales.filter((item) => item.nombre.toLowerCase().includes(searchQuery.toLowerCase()) || item.ubicacion && item.ubicacion.toLowerCase().includes(searchQuery.toLowerCase()) || item.tipoElemento.toLowerCase().includes(searchQuery.toLowerCase()));
	const nombreProyectoDuplicado = proyectos.some((p) => p.nombre.toLowerCase().trim() === proyectoNombre.toLowerCase().trim());
	const isProyectoValid = proyectoNombre.trim() !== "" && !nombreProyectoDuplicado;
	const nombreElementoDuplicado = elementosGenerales.some((e) => e.nombre.toLowerCase().trim() === elementoNombre.toLowerCase().trim());
	const isElementoValid = elementoNombre.trim() !== "" && !nombreElementoDuplicado;
	const handleImageChange = (e) => {
		const file = e.target.files[0];
		if (!file) return;
		if (file.size > 10 * 1024 * 1024) {
			customAlert("La imagen es demasiado grande. Por favor elija una de menos de 10MB.");
			return;
		}
		setFotoBlob(file);
		if (previewUrl) URL.revokeObjectURL(previewUrl);
		setPreviewUrl(URL.createObjectURL(file));
	};
	const handleCreateProyecto = (e) => {
		e.preventDefault();
		if (!isProyectoValid) return;
		const result = addProyecto(proyectoNombre.trim(), proyectoDescripcion.trim(), companyId);
		if (result.success) {
			setProyectoNombre("");
			setProyectoDescripcion("");
			setShowModal(false);
		} else {
			customAlert(result.error);
		}
	};
	const handleCreateElemento = (e) => {
		e.preventDefault();
		if (!isElementoValid) return;
		let datosTecnicos = {};
		if (tipoElemento === "TABLERO") {
			datosTecnicos = {
				maxPoles: parseInt(maxPoles, 10),
				barrasPrincipales: {
					ia: "0",
					ib: "0",
					ic: "0"
				},
				breakerPrincipal: {
					marca: "",
					tipo: "",
					amp: ""
				},
				voltaje: {
					va: "208",
					vb: "205",
					vc: "205"
				},
				acometida: "",
				circuits: [],
				neutroLlegada: {
					calibre: "",
					observaciones: ""
				},
				puestaTierra: {
					calibre: "",
					observaciones: ""
				}
			};
		} else if (tipoElemento === "TRANSFORMADOR") {
			datosTecnicos = {
				marca: marcaTrafo || "",
				fases: "3",
				potenciaKva: kvaTrafo || "",
				kva: kvaTrafo || "",
				tipoTransformador: tipoTrafo || "Pedestal",
				conexion: conexionTrafo || "",
				voltajePrimario: voltajePrimario || "",
				voltajeSecundario: voltajeSecundario || "",
				impedanciaPct: "",
				impedanciaAmp: "",
				impedanciaTemp: "",
				tensionPrimaria: voltajePrimario || "",
				amperiosPrimaria: "",
				tensionSecundaria: voltajeSecundario || "",
				amperiosSecundaria: "",
				aislamiento: "",
				aceite: "",
				seco: "",
				acometidas: {
					primaria: {
						aerea: false,
						subterranea: false,
						calibre: "",
						tipo: "",
						terminal: "",
						fusible: "",
						pararrayo: "",
						observaciones: ""
					},
					secundaria: {
						aerea: false,
						subterranea: false,
						calibre: "",
						tipo: "",
						terminal: "",
						fusible: "",
						pararrayo: "",
						observaciones: ""
					},
					neutro: {
						aerea: false,
						subterranea: false,
						calibre: "",
						tipo: "",
						terminal: "",
						fusible: "",
						pararrayo: "",
						observaciones: ""
					}
				},
				spt: {
					barillaCalibre: "",
					barillaCantidad: "",
					barillaConfiguracion: "",
					conductorCalibre: "",
					conductorTipoSold: "",
					resistencia: "",
					fechaMedicion: ""
				}
			};
		} else if (tipoElemento === "GENERADOR") {
			datosTecnicos = {
				kva: kvaGen,
				combustible: combustibleGen,
				voltajeGeneracion: voltajeGen,
				potenciaKw: potenciaKwGen,
				amperaje: amperajeGen
			};
		} else if (tipoElemento === "BANCO_CONDENSADOR") {
			datosTecnicos = {
				marca: "",
				modelo: "",
				alimentador: "",
				calibreConductor: "",
				fabricante: "",
				anioFabricacion: "",
				tensionNominal: tensionBanco || "208 V",
				tensionRegistrada: tensionBanco || "208 V",
				frecuencia: "60 Hz",
				potenciaReactivaTotal: kvarTotal || "150 kVAR",
				corrienteNominalTotal: "",
				numFases: "Trifásico",
				conexion: "Estrella",
				nivelAislamientoBIL: "",
				tipoCompensacion: tipoBanco === "AUTOMATICO" ? "Automática (Pasos)" : "Fija",
				numPasos: pasosCondensador || "6",
				secuenciaPasosKvar: "",
				tipoConmutacion: "Contactores dedicados",
				potenciaIndividual: "",
				capacitanciaMuf: "",
				tensionCondensador: "",
				tecnologiaDielectrica: "Polipropileno metalizado",
				resistenciaDescarga: "Sí",
				seguridad: "Desconectador por sobrepresión",
				factorDesintonizacion: "N/A",
				tipoNucleo: "Núcleo de Hierro con Entrehierro",
				claseAislamientoTermico: "Clase H (180°C)",
				proteccionTermica: "Sensor Bimetálico / PT100 integrado",
				reguladorMarcaModelo: "",
				relacionTc: "",
				puertoComunicacion: "RS-485 (Modbus RTU)",
				interruptorPrincipalAmp: "",
				proteccionPasos: "Fusibles",
				gradoProteccionEnvolvente: "IP54",
				dimensionesAlto: "",
				dimensionesAncho: "",
				dimensionesProf: "",
				sistemaEnfriamiento: "Ventilación Forzada",
				temperaturaC: "",
				humedadPct: ""
			};
		} else if (tipoElemento === "PUNTO_SUMINISTRO") {
			datosTecnicos = {
				nivelTension: suministroTension || "13.8 kV",
				tensionNominal: suministroTension || "13.8 kV",
				empresaDistribuidora: suministroEmpresa || "CORPOELEC",
				tipoAcometida: suministroTipoAcometida || "Subterránea",
				capacidadContratadaKva: suministroCapacidad || "",
				cargaContratadaKva: suministroCapacidad || "",
				tipoMedicion: suministroTipoMedicion || "Medición Directa (Baja Tensión)",
				enlaceCorpoelec: Boolean(suministroEnlaceCorpoelec),
				numeroContrato: suministroNumeroContrato || "",
				nic: suministroNic || "",
				posteTransformador: suministroPosteTrafo || ""
			};
		} else if (tipoElemento === "CCM") {
			datosTecnicos = {
				capacidadBarraAmperios: ccmCapacidadBarra || "1200 A",
				tensionOperativa: ccmTension || "480 V",
				breakerPrincipal: ccmBreakerPrincipal || "1200A 3P",
				numeroGavetas: parseInt(ccmNumeroGavetas, 10) || 8
			};
		} else if (tipoElemento === "PUESTA_TIERRA") {
			datosTecnicos = {
				resistenciaOhmios,
				corrienteFugaAmperios: corrienteFuga,
				tipoMalla,
				cableAcometida: cableAcometidaTierra
			};
		} else if (tipoElemento === "TRANSFER") {
			datosTecnicos = {
				capacidadAmperios,
				tipoTransferencia,
				tensionOperativa
			};
		} else {
			datosTecnicos = { descripcionEspecificaciones: descripcionOtro };
		}
		const result = addElementoUnifilar({
			proyectoId: null,
			companyId,
			nombre: elementoNombre.trim(),
			tipoElemento,
			ubicacion: ubicacion.trim() || "Sin ubicación",
			alimentadoPor: alimentadoPor.trim() || "No definido",
			fotoBlob,
			observacionesGenerales: observacionesGenerales.trim(),
			datosTecnicos
		});
		if (result.success) {
			setElementoNombre("");
			setUbicacion("");
			setAlimentadoPor("");
			setObservacionesGenerales("");
			setSuministroTension("");
			setSuministroEmpresa("CORPOELEC");
			setSuministroTipoAcometida("Subterránea");
			setSuministroCapacidad("");
			setSuministroTipoMedicion("Medición Directa (Baja Tensión)");
			setSuministroEnlaceCorpoelec(true);
			setSuministroNumeroContrato("");
			setSuministroNic("");
			setSuministroPosteTrafo("");
			setFotoBlob(null);
			if (previewUrl) URL.revokeObjectURL(previewUrl);
			setPreviewUrl(null);
			setShowElementoModal(false);
		} else {
			customAlert(result.error);
		}
	};
	const handleOpenTableroModal = () => {
		setShowElementoModal(true);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased font-sans",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-slate-950 border-b border-slate-800/80 px-6 py-4 flex items-center justify-between shadow-lg",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigate("/"),
						className: "p-2.5 bg-slate-900 hover:bg-slate-800 rounded-xl text-slate-450 hover:text-slate-200 transition-all border border-slate-800 active:scale-95 cursor-pointer",
						title: "Volver al Dashboard",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 497,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 492,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider block",
						children: "Gestión de Empresa"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 500,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-lg font-bold text-slate-100 tracking-tight",
						children: company.nombre
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 503,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 499,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 491,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 490,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-6 py-8 space-y-8",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-start gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] text-amber-500 font-bold uppercase tracking-wider block mb-1",
									children: "Ficha Técnica"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 515,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("h2", {
									className: "text-xl font-extrabold text-slate-100 tracking-tight flex items-center gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV(Building, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 517,
											columnNumber: 17
										}, this),
										" ",
										company.nombre
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 516,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 514,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 flex-wrap",
									children: [user?.role === "ADMIN" && /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setEditNombre(company.nombre);
											setEditRif(company.rif || "");
											setEditDireccionFiscal(company.direccionFiscal || "");
											setEditGerente1Nombre(company.gerente1Nombre || "");
											setEditGerente1Telefono(company.gerente1Telefono || "");
											setEditGerente1Email(company.gerente1Email || "");
											setEditGerente2Nombre(company.gerente2Nombre || "");
											setEditGerente2Telefono(company.gerente2Telefono || "");
											setEditGerente2Email(company.gerente2Email || "");
											setShowEditEmpresaModal(true);
										},
										className: "px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold rounded-lg text-slate-200 hover:text-slate-100 flex items-center gap-1.5 transition-all cursor-pointer shadow-md",
										children: "Editar Empresa"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 522,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => navigate("/backups"),
										className: "px-3.5 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-xs font-bold rounded-lg text-amber-400 hover:text-amber-300 flex items-center gap-1.5 transition-all cursor-pointer shadow-md",
										title: "Ir al Centro de Resguardo y Copias de Seguridad",
										children: [/* @__PURE__ */ _jsxDEV(Database, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 545,
											columnNumber: 17
										}, this), "Resguardo & Backups"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 540,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 520,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 513,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6 pt-6 border-t border-slate-900",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 font-bold uppercase block",
										children: "RIF"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 553,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-sm font-semibold text-slate-200",
										children: company.rif || "J-N/D"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 554,
										columnNumber: 15
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 552,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "md:col-span-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 font-bold uppercase block",
											children: "Dirección Fiscal"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 557,
											columnNumber: 15
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm font-semibold text-slate-200",
											children: company.direccionFiscal || "N/D"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 558,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 556,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 font-bold uppercase block",
										children: "Registro"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 561,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-slate-400 font-mono mt-1 space-y-0.5",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: ["Creado: ", company.createdAt ? new Date(company.createdAt).toLocaleString("es-ES") : "N/D"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 563,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: ["Actualizado: ", company.updatedAt ? new Date(company.updatedAt).toLocaleString("es-ES") : "N/D"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 564,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 562,
										columnNumber: 15
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 560,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 551,
								columnNumber: 11
							}, this),
							user?.role === "ADMIN" && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 pt-6 border-t border-slate-900",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-sky-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 572,
										columnNumber: 17
									}, this), " Contacto Gerencial (Solo Visible para Administradores)"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 571,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 md:grid-cols-2 gap-6",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-slate-900/50 p-4 rounded-xl border border-slate-900",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-sky-400 font-bold uppercase block mb-2",
											children: "Gerente Principal"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 577,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1.5 text-xs",
											children: [
												/* @__PURE__ */ _jsxDEV("div", { children: [
													/* @__PURE__ */ _jsxDEV("strong", {
														className: "text-slate-450",
														children: "Nombre:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 579,
														columnNumber: 26
													}, this),
													" ",
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-slate-255 font-semibold",
														children: company.gerente1Nombre || "N/D"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 579,
														columnNumber: 78
													}, this)
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 579,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [
													/* @__PURE__ */ _jsxDEV("strong", {
														className: "text-slate-450",
														children: "Teléfono:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 580,
														columnNumber: 26
													}, this),
													" ",
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-slate-255 font-semibold",
														children: company.gerente1Telefono || "N/D"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 580,
														columnNumber: 80
													}, this)
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 580,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [
													/* @__PURE__ */ _jsxDEV("strong", {
														className: "text-slate-450",
														children: "Email:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 581,
														columnNumber: 26
													}, this),
													" ",
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-slate-255 font-semibold",
														children: company.gerente1Email || "N/D"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 581,
														columnNumber: 77
													}, this)
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 581,
													columnNumber: 21
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 578,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 576,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "bg-slate-900/50 p-4 rounded-xl border border-slate-900",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-sky-400 font-bold uppercase block mb-2",
											children: "Gerente Secundario"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 587,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1.5 text-xs",
											children: [
												/* @__PURE__ */ _jsxDEV("div", { children: [
													/* @__PURE__ */ _jsxDEV("strong", {
														className: "text-slate-450",
														children: "Nombre:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 589,
														columnNumber: 26
													}, this),
													" ",
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-slate-255 font-semibold",
														children: company.gerente2Nombre || "N/D"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 589,
														columnNumber: 78
													}, this)
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 589,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [
													/* @__PURE__ */ _jsxDEV("strong", {
														className: "text-slate-450",
														children: "Teléfono:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 590,
														columnNumber: 26
													}, this),
													" ",
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-slate-255 font-semibold",
														children: company.gerente2Telefono || "N/D"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 590,
														columnNumber: 80
													}, this)
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 590,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [
													/* @__PURE__ */ _jsxDEV("strong", {
														className: "text-slate-450",
														children: "Email:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 591,
														columnNumber: 26
													}, this),
													" ",
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-slate-255 font-semibold",
														children: company.gerente2Email || "N/D"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 591,
														columnNumber: 77
													}, this)
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 591,
													columnNumber: 21
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 588,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 586,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 574,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 570,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 512,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4 pb-6 border-b border-slate-800/80",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "input-search-container w-full sm:w-64",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: searchQuery,
								onChange: (e) => setSearchQuery(e.target.value),
								placeholder: "Buscar proyecto o equipo...",
								className: "input-search"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 602,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Search, { className: "w-4.5 h-4.5 absolute left-3.5 top-3 text-slate-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 609,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 601,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap sm:flex-nowrap items-center gap-3 w-full sm:w-auto justify-end",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setShowDiagramModal(true),
								className: "bg-violet-600 hover:bg-violet-500 text-slate-100 font-bold active:scale-98 transition-all px-4 py-2.5 rounded-lg flex flex-row items-center justify-center gap-2 h-10 whitespace-nowrap w-full sm:w-auto cursor-pointer text-xs shadow-md",
								children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 fill-slate-100" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 620,
									columnNumber: 15
								}, this), " Ver Diagrama Gráfico"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 615,
								columnNumber: 13
							}, this), user?.role !== "CLIENT" && /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap sm:flex-nowrap items-center gap-3 w-full sm:w-auto justify-end",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setIsMultiSelectMode(!isMultiSelectMode);
											setSelectedIds(new Set());
										},
										className: `border font-semibold transition-all px-4 py-2.5 rounded-lg flex flex-row items-center justify-center gap-2 h-10 whitespace-nowrap w-full sm:w-auto cursor-pointer text-xs ${isMultiSelectMode ? "bg-amber-500/10 border-amber-500/40 text-amber-500" : "bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800"}`,
										children: [
											/* @__PURE__ */ _jsxDEV(CheckSquare, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 637,
												columnNumber: 17
											}, this),
											" ",
											isMultiSelectMode ? "Cancelar Selección" : "Seleccionar Varios"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 626,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleOpenTableroModal,
										className: "bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 active:scale-98 transition-all px-4 py-2.5 rounded-lg flex flex-row items-center justify-center gap-2 h-10 whitespace-nowrap w-full sm:w-auto cursor-pointer text-xs shadow-md",
										children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-slate-950 fill-slate-950" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 645,
											columnNumber: 17
										}, this), " + Crear Elemento"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 641,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setShowModal(true),
										className: "bg-slate-900 border border-slate-700 text-slate-100 font-semibold hover:bg-slate-800 active:scale-98 transition-all px-4 py-2.5 rounded-lg flex flex-row items-center justify-center gap-2 h-10 whitespace-nowrap w-full sm:w-auto cursor-pointer text-xs",
										children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 653,
											columnNumber: 17
										}, this), " + Crear Proyecto"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 649,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 624,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 612,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 600,
						columnNumber: 9
					}, this),
					isMultiSelectMode && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 border border-amber-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 animate-fadeIn shadow-lg shadow-amber-500/5",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-2 h-2 rounded-full bg-amber-500 animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 663,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-300 font-medium",
								children: [
									"Modo Selección Múltiple: ",
									/* @__PURE__ */ _jsxDEV("strong", {
										className: "text-amber-500 font-bold",
										children: selectedIds.size
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 665,
										columnNumber: 42
									}, this),
									" ",
									selectedIds.size === 1 ? "equipo seleccionado" : "equipos seleccionados"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 664,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 662,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleSelectAll,
									className: "px-3.5 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-[11px] font-semibold text-slate-300 transition-all cursor-pointer hover:text-slate-100",
									children: "Seleccionar Todo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 669,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleDeselectAll,
									className: "px-3.5 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-[11px] font-semibold text-slate-300 transition-all cursor-pointer hover:text-slate-100",
									children: "Deseleccionar Todo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 675,
									columnNumber: 15
								}, this),
								selectedIds.size > 0 && user?.role !== "CLIENT" && /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleDeleteSelected,
									className: "px-3.5 py-2 bg-red-950/40 hover:bg-red-900/60 border border-red-800/40 rounded-xl text-[11px] font-bold text-red-400 hover:text-red-300 flex items-center gap-1.5 transition-all cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 686,
											columnNumber: 19
										}, this),
										" Eliminar (",
										selectedIds.size,
										")"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 682,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setIsMultiSelectMode(false);
										setSelectedIds(new Set());
									},
									className: "px-3.5 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-[11px] font-semibold text-slate-400 hover:text-slate-200 transition-all cursor-pointer",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 689,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 668,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 661,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-4",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-extrabold text-slate-100 tracking-wide flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV(FolderOpen, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 706,
									columnNumber: 15
								}, this),
								" Carpetas de Proyectos (",
								proyectos.length,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 705,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-1",
							children: "Organiza las inspecciones en carpetas o proyectos técnicos independientes."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 708,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 704,
						columnNumber: 11
					}, this), filteredProjects.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
						children: filteredProjects.map((proj) => /* @__PURE__ */ _jsxDEV("div", {
							onClick: () => navigate(`/empresa/${companyId}/proyecto/${proj.id}`),
							className: "bg-slate-950 border border-slate-800/80 hover:border-slate-700/60 rounded-2xl shadow-md hover:shadow-xl p-5 flex flex-col justify-between cursor-pointer transition-all hover:translate-y-[-2px] group relative",
							children: [
								user?.role !== "CLIENT" && /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: (e) => {
										e.stopPropagation();
										handleDeleteProyecto(proj.id, proj.nombre);
									},
									className: "absolute top-4 right-4 p-2 bg-slate-900/90 hover:bg-red-950/40 border border-slate-800 hover:border-red-900/60 text-slate-400 hover:text-red-400 rounded-xl transition-all shadow-md z-10 cursor-pointer opacity-100",
									title: "Eliminar Proyecto",
									children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 731,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 722,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-4 pr-12 min-w-0",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 bg-slate-900 border border-slate-850 rounded-xl w-max shadow-inner text-amber-500 group-hover:scale-105 transition-transform",
										children: /* @__PURE__ */ _jsxDEV(FolderOpen, { className: "w-6 h-6" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 736,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 735,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "text-sm font-bold text-slate-100 group-hover:text-amber-400 transition-colors tracking-tight truncate",
											children: proj.nombre
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 740,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed min-h-[32px] font-sans",
											children: proj.descripcion || "Sin descripción disponible."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 743,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 739,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 734,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "border-t border-slate-900/60 pt-4 mt-4 space-y-2.5",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-2 text-[10px] text-slate-400",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1.5 bg-slate-900/40 p-2 rounded-lg border border-slate-900/60 justify-center",
											children: [
												/* @__PURE__ */ _jsxDEV(Layers, { className: "w-3.5 h-3.5 text-sky-400 shrink-0" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 752,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono font-bold text-slate-200",
													children: (proj.elementosUnifilares || proj.tableros || []).length
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 753,
													columnNumber: 25
												}, this),
												" Equipos"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 751,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1.5 bg-slate-900/40 p-2 rounded-lg border border-slate-900/60 justify-center",
											children: [
												/* @__PURE__ */ _jsxDEV(Building, { className: "w-3.5 h-3.5 text-amber-500 shrink-0" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 756,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono font-bold text-slate-200",
													children: (proj.inspeccionesSubestacion || proj.subestaciones || []).length
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 757,
													columnNumber: 25
												}, this),
												" Subestac."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 755,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 750,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-[9px] text-slate-500 font-mono",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Creado:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 762,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: proj.createdAt ? new Date(proj.createdAt).toLocaleDateString("es-ES") : "N/D" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 763,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 761,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 749,
									columnNumber: 19
								}, this)
							]
						}, proj.id, true, {
							fileName: _jsxFileName,
							lineNumber: 716,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 714,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "p-16 border-2 border-dashed border-slate-800 rounded-2xl text-center space-y-4 bg-slate-950/20",
						children: [/* @__PURE__ */ _jsxDEV(FolderOpen, { className: "w-12 h-12 text-slate-700 mx-auto" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 771,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1 font-sans",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold text-slate-400",
								children: "No se encontraron proyectos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 773,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 max-w-sm mx-auto",
								children: "Crea una nueva carpeta de proyecto para comenzar a registrar tableros e inspecciones."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 774,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 772,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 770,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 703,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-8 border-t border-slate-800/80",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "mb-4",
							children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-extrabold text-slate-100 tracking-wide flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV(Zap, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 786,
										columnNumber: 15
									}, this),
									" Equipos fuera de Carpetas (",
									elementosGenerales.length,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 785,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 mt-1",
								children: "Equipos registrados directamente a nivel de empresa, fuera de carpetas de proyectos."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 788,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 784,
							columnNumber: 11
						}, this), filteredElementosGenerales.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
							children: filteredElementosGenerales.map((item) => {
								const isTablero = item.tipoElemento === "TABLERO";
								const isTrafo = item.tipoElemento === "TRANSFORMADOR";
								const isGen = item.tipoElemento === "GENERADOR";
								const isPuestaTierra = item.tipoElemento === "PUESTA_TIERRA";
								const isTransfer = item.tipoElemento === "TRANSFER";
								const isSelected = selectedIds.has(item.id);
								return /* @__PURE__ */ _jsxDEV("div", {
									onClick: () => {
										if (isMultiSelectMode) {
											handleToggleSelect(item.id);
										} else {
											navigate(`/empresa/${companyId}/tablero/${item.id}`);
										}
									},
									className: `bg-slate-950 border flex flex-col justify-between overflow-hidden cursor-pointer transition-all hover:-translate-y-0.5 group rounded-2xl shadow-md hover:shadow-xl ${isMultiSelectMode && isSelected ? "border-amber-500 shadow-amber-500/5 ring-1 ring-amber-500/20" : "border-slate-800/80 hover:border-slate-700/60"}`,
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "h-32 w-full bg-slate-900 relative overflow-hidden flex items-center justify-center border-b border-slate-900/50",
										children: [
											item.fotoBlob || item.foto ? /* @__PURE__ */ _jsxDEV(SafeImage, {
												blob: item.fotoBlob,
												src: item.foto,
												alt: item.nombre,
												className: "w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 822,
												columnNumber: 25
											}, this) : /* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col items-center justify-center text-slate-700 gap-1.5 select-none",
												children: [
													isTablero && /* @__PURE__ */ _jsxDEV(Zap, { className: "w-8 h-8 opacity-25 text-sky-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 830,
														columnNumber: 41
													}, this),
													isTrafo && /* @__PURE__ */ _jsxDEV(Cpu, { className: "w-8 h-8 opacity-25 text-purple-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 831,
														columnNumber: 39
													}, this),
													isGen && /* @__PURE__ */ _jsxDEV(Zap, { className: "w-8 h-8 opacity-25 text-amber-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 832,
														columnNumber: 37
													}, this),
													isPuestaTierra && /* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-8 h-8 opacity-25 text-teal-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 833,
														columnNumber: 46
													}, this),
													isTransfer && /* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-8 h-8 opacity-25 text-emerald-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 834,
														columnNumber: 42
													}, this),
													!isTablero && !isTrafo && !isGen && !isPuestaTierra && !isTransfer && /* @__PURE__ */ _jsxDEV(Layers, { className: "w-8 h-8 opacity-25 text-slate-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 835,
														columnNumber: 98
													}, this),
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-[9px] uppercase font-bold tracking-widest opacity-30",
														children: "Sin Imagen"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 836,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 829,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "absolute top-3 left-3",
												children: [
													isTablero && /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2.5 py-0.5 rounded-lg text-[9px] font-bold bg-sky-950/95 text-sky-400 border border-sky-800/40 font-mono",
														children: "⚡ TABLERO"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 843,
														columnNumber: 27
													}, this),
													isTrafo && /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2.5 py-0.5 rounded-lg text-[9px] font-bold bg-purple-950/95 text-purple-400 border border-purple-800/40 font-mono",
														children: "⚡ TRANSFORMADOR"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 848,
														columnNumber: 27
													}, this),
													isGen && /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2.5 py-0.5 rounded-lg text-[9px] font-bold bg-amber-950/95 text-amber-400 border border-amber-800/40 font-mono",
														children: "⚡ GENERADOR"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 853,
														columnNumber: 27
													}, this),
													isPuestaTierra && /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2.5 py-0.5 rounded-lg text-[9px] font-bold bg-teal-950/95 text-teal-400 border border-teal-800/40 font-mono",
														children: "🛡️ PUESTA A TIERRA"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 858,
														columnNumber: 27
													}, this),
													isTransfer && /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2.5 py-0.5 rounded-lg text-[9px] font-bold bg-emerald-950/95 text-emerald-400 border border-emerald-800/40 font-mono",
														children: "🔄 TRANSFERENCIA"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 863,
														columnNumber: 27
													}, this),
													item.tipoElemento === "PUNTO_SUMINISTRO" && /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2.5 py-0.5 rounded-lg text-[9px] font-bold bg-blue-950/95 text-blue-400 border border-blue-800/40 font-mono",
														children: "🔌 PTO. SUMINISTRO"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 868,
														columnNumber: 27
													}, this),
													item.tipoElemento === "CCM" && /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2.5 py-0.5 rounded-lg text-[9px] font-bold bg-amber-950/95 text-amber-400 border border-amber-800/40 font-mono",
														children: "⚙️ CCM MOTORES"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 873,
														columnNumber: 27
													}, this),
													item.tipoElemento === "BANCO_CONDENSADOR" && /* @__PURE__ */ _jsxDEV("span", {
														className: "px-2.5 py-0.5 rounded-lg text-[9px] font-bold bg-emerald-950/95 text-emerald-400 border border-emerald-800/40 font-mono",
														children: "⚡ BANCO CONDENSADOR"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 878,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 841,
												columnNumber: 23
											}, this),
											!isMultiSelectMode && /* @__PURE__ */ _jsxDEV("div", {
												className: "absolute top-3 right-3 flex items-center gap-2",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono font-black text-amber-400 bg-slate-900 border border-amber-500/30 px-2.5 py-0.5 rounded-lg text-xs shadow-sm",
													children: ["ID: ", item.id]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 887,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 886,
												columnNumber: 25
											}, this),
											isMultiSelectMode && /* @__PURE__ */ _jsxDEV("div", {
												className: "absolute top-3 right-3 z-10",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: `p-1.5 rounded-lg flex items-center justify-center border transition-all ${isSelected ? "bg-amber-500 border-amber-400 text-slate-950 shadow-md shadow-amber-500/20" : "bg-slate-950/90 border-slate-700 text-slate-500"}`,
													children: isSelected ? /* @__PURE__ */ _jsxDEV(CheckSquare, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 902,
														columnNumber: 31
													}, this) : /* @__PURE__ */ _jsxDEV("div", { className: "w-3.5 h-3.5 border border-slate-600 rounded-sm" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 904,
														columnNumber: 31
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 896,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 895,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 820,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "p-5 flex-1 flex flex-col justify-between",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "space-y-1",
												children: [/* @__PURE__ */ _jsxDEV("h3", {
													className: "text-sm font-bold text-slate-100 group-hover:text-amber-500 transition-colors truncate",
													children: formatElementTitleWithId(item.nombre, item.id)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 913,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-1.5 mt-3 text-[11px] text-slate-400 border-t border-slate-900/60 pt-3",
													children: [
														/* @__PURE__ */ _jsxDEV("p", {
															className: "truncate",
															children: [
																/* @__PURE__ */ _jsxDEV("span", {
																	className: "text-slate-500 font-bold",
																	children: "Ubicación:"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 917,
																	columnNumber: 51
																}, this),
																" ",
																item.ubicacion
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 917,
															columnNumber: 27
														}, this),
														/* @__PURE__ */ _jsxDEV("p", {
															className: "truncate",
															children: [
																/* @__PURE__ */ _jsxDEV("span", {
																	className: "text-slate-500 font-bold",
																	children: "Alimentador:"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 918,
																	columnNumber: 51
																}, this),
																" ",
																item.alimentadoPor || "No definido"
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 918,
															columnNumber: 27
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "pt-2",
															children: [
																isTablero && /* @__PURE__ */ _jsxDEV("p", {
																	className: "text-sky-400 font-mono font-semibold text-[10px] bg-sky-950/40 p-1.5 rounded-lg border border-sky-900/40",
																	children: [
																		"⚡ Capacidad: ",
																		item.datosTecnicos?.maxPoles || 24,
																		" Polos (",
																		item.datosTecnicos?.voltajeAcometida || "208/120 V",
																		")"
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 922,
																	columnNumber: 31
																}, this),
																isTrafo && /* @__PURE__ */ _jsxDEV("p", {
																	className: "text-purple-400 font-mono font-semibold text-[10px] bg-purple-950/40 p-1.5 rounded-lg border border-purple-900/40",
																	children: [
																		"⚡ ",
																		item.datosTecnicos?.kva || "500 KVA",
																		" | GE ",
																		item.datosTecnicos?.conexion || "Estrella-Estrella",
																		" (",
																		item.datosTecnicos?.voltajePrimario || "13.8 kV",
																		")"
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 927,
																	columnNumber: 31
																}, this),
																isGen && /* @__PURE__ */ _jsxDEV("p", {
																	className: "text-amber-400 font-mono font-semibold text-[10px] bg-amber-950/40 p-1.5 rounded-lg border border-amber-900/40",
																	children: [
																		"⚡ ",
																		item.datosTecnicos?.kva || "580 kVA",
																		" | ",
																		item.datosTecnicos?.voltajeGeneracion || "208 V",
																		" | Breaker ",
																		item.datosTecnicos?.amperaje || "1600 A"
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 932,
																	columnNumber: 31
																}, this),
																isPuestaTierra && /* @__PURE__ */ _jsxDEV("p", {
																	className: "text-teal-400 font-mono font-semibold text-[10px] bg-teal-950/40 p-1.5 rounded-lg border border-teal-900/40",
																	children: [
																		"🛡️ Corriente Fuga: ",
																		item.datosTecnicos?.corrienteFugaAmperios || "6.4 A",
																		" | ",
																		item.datosTecnicos?.tipoMalla || "Malla Concreto"
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 937,
																	columnNumber: 31
																}, this),
																isTransfer && /* @__PURE__ */ _jsxDEV("p", {
																	className: "text-emerald-400 font-mono font-semibold text-[10px] bg-emerald-950/40 p-1.5 rounded-lg border border-emerald-900/40",
																	children: [
																		"🔄 ",
																		item.datosTecnicos?.capacidadAmperios || "3200 A",
																		" | ",
																		item.datosTecnicos?.tipoTransferencia || "ATS YUYE-YES1"
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 942,
																	columnNumber: 31
																}, this),
																item.tipoElemento === "PUNTO_SUMINISTRO" && /* @__PURE__ */ _jsxDEV("p", {
																	className: "text-blue-400 font-mono font-semibold text-[10px] bg-blue-950/40 p-1.5 rounded-lg border border-blue-900/40",
																	children: [
																		"🔌 ",
																		item.datosTecnicos?.nivelTension || "13.8 kV",
																		" | ",
																		item.datosTecnicos?.cargaContratadaKva || item.datosTecnicos?.capacidadContratadaKva || "1000 kVA",
																		" | ",
																		item.datosTecnicos?.tipoMedicion || "Medición Directa BT"
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 947,
																	columnNumber: 31
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 920,
															columnNumber: 27
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 916,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 912,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "mt-4 pt-3 border-t border-slate-900/80",
												children: /* @__PURE__ */ _jsxDEV(AvanceProgressBar, {
													elemento: item,
													tipoElemento: item.tipoElemento || "TABLERO"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 957,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 956,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "mt-3",
												children: /* @__PURE__ */ _jsxDEV(ElementoCardActions, {
													onEdit: () => navigate(`/empresa/${companyId}/tablero/${item.id}`),
													onNewInspection: () => navigate(`/empresa/${companyId}/tablero/${item.id}`),
													onDelete: async () => {
														const ok = await confirm({
															title: "Eliminar Equipo",
															message: `¿Estás seguro de que deseas eliminar el equipo "${item.nombre}"?`,
															type: "danger",
															confirmText: "Eliminar"
														});
														if (ok) {
															deleteElementoUnifilar(null, item.id);
														}
													},
													readOnly: user?.role === "CLIENT"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 962,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 961,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 911,
										columnNumber: 21
									}, this)]
								}, item.id, true, {
									fileName: _jsxFileName,
									lineNumber: 804,
									columnNumber: 19
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 794,
							columnNumber: 13
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "p-16 border-2 border-dashed border-slate-800 rounded-2xl text-center space-y-4 bg-slate-950/20",
							children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-12 h-12 text-slate-700 mx-auto" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 986,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1 font-sans",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-bold text-slate-400",
									children: "No hay equipos generales"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 988,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 max-w-sm mx-auto",
									children: "Registra un equipo técnico directamente a nivel de empresa."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 989,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 987,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 985,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 783,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 509,
				columnNumber: 7
			}, this),
			showModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200",
					onClick: () => setShowModal(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1002,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden animate-in zoom-in-95 duration-200",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center pb-4 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(FolderOpen, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1007,
								columnNumber: 17
							}, this), "Registrar Nuevo Proyecto"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1006,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowModal(false),
							className: "p-1.5 hover:bg-slate-900 rounded-lg text-slate-500 transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1014,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1010,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1005,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCreateProyecto,
						className: "mt-4 space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
									children: "Nombre del Proyecto"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1020,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									value: proyectoNombre,
									onChange: (e) => setProyectoNombre(e.target.value),
									placeholder: "Ej. Inspecciones Planta Baja 2026",
									className: `w-full px-3.5 py-2.5 bg-slate-900 border focus:ring-1 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all ${nombreProyectoDuplicado ? "border-red-500 focus:border-red-500 focus:ring-red-550" : "border-slate-800 focus:border-amber-500 focus:ring-amber-500"}`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1023,
									columnNumber: 17
								}, this),
								nombreProyectoDuplicado && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-red-555 font-bold flex items-center gap-1.5 mt-1.5",
									children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1037,
										columnNumber: 21
									}, this), " Nombre duplicado: ya existe un proyecto con este nombre."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1036,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1019,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Descripción (Opcional)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1043,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("textarea", {
								value: proyectoDescripcion,
								onChange: (e) => setProyectoDescripcion(e.target.value),
								placeholder: "Describe brevemente el alcance de este proyecto...",
								rows: 4,
								className: "w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none placeholder-slate-600 transition-all font-sans resize-none"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1046,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1042,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-end gap-3 pt-3 border-t border-slate-900/60",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowModal(false),
									className: "px-4.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-xs font-bold rounded-xl text-slate-350 transition-colors cursor-pointer",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1056,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: !isProyectoValid,
									className: "bg-amber-500 text-slate-950 font-semibold hover:bg-amber-400 active:scale-98 transition-all px-4 py-2.5 rounded-lg flex flex-row items-center justify-center gap-2 h-10 whitespace-nowrap text-xs cursor-pointer shadow-md disabled:opacity-40",
									children: "Crear Proyecto"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1063,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1055,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1018,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1004,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1001,
				columnNumber: 9
			}, this),
			showElementoModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200",
					onClick: () => setShowElementoModal(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1080,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center pb-4 border-b border-slate-800 shrink-0",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1085,
								columnNumber: 17
							}, this), " Registrar Plantilla Técnica"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1084,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowElementoModal(false),
							className: "p-1.5 hover:bg-slate-900 rounded-lg text-slate-505 transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1091,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1087,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1083,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCreateElemento,
						className: "mt-4 space-y-4 overflow-y-auto pr-1 flex-1",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Tipo de Plantilla de Elemento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1099,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 sm:grid-cols-3 gap-1.5 bg-slate-900 p-1.5 rounded-xl border border-slate-800 text-[9px]",
								children: [
									{
										id: "TABLERO",
										label: "⚡ PANEL ELÉCTRICO"
									},
									{
										id: "PUNTO_SUMINISTRO",
										label: "🔌 PTO. SUMINISTRO"
									},
									{
										id: "GENERADOR",
										label: "🔋 GENERADOR"
									},
									{
										id: "TRANSFORMADOR",
										label: "🔄 TRANSFORMADOR"
									},
									{
										id: "TRANSFER",
										label: "🔀 TRANSFERENCIA"
									},
									{
										id: "CCM",
										label: "⚙️ CCM (MOTORES)"
									},
									{
										id: "BANCO_CONDENSADOR",
										label: "⚡ BANCO COND."
									}
								].map((t) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTipoElemento(t.id),
									className: `py-2 px-2 font-black rounded-lg transition-all text-center cursor-pointer ${tipoElemento === t.id ? "bg-amber-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"}`,
									children: t.label
								}, t.id, false, {
									fileName: _jsxFileName,
									lineNumber: 1112,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1102,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1098,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
									children: "Nombre descriptivo del equipo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1130,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									value: elementoNombre,
									onChange: (e) => setElementoNombre(e.target.value),
									placeholder: `Ej. ${tipoElemento === "TABLERO" ? "Tablero Principal (TAB 20)" : tipoElemento === "TRANSFORMADOR" ? "Transformador GE 500 KVA" : tipoElemento === "PUESTA_TIERRA" ? "Malla Puesta a Tierra N° 1" : "Generador DOMOSA 1"}`,
									className: `w-full px-3.5 py-2 bg-slate-900 border focus:ring-1 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all ${nombreElementoDuplicado ? "border-red-500 focus:border-red-500 focus:ring-red-550" : "border-slate-800 focus:border-amber-500 focus:ring-amber-500"}`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1133,
									columnNumber: 17
								}, this),
								nombreElementoDuplicado && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-red-555 font-bold flex items-center gap-1.5 mt-1.5",
									children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1147,
										columnNumber: 21
									}, this), " Nombre duplicado: ya existe este equipo en la empresa."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1146,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1129,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Ubicación Física"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1154,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: ubicacion,
								onChange: (e) => setUbicacion(e.target.value),
								placeholder: "Ej. Sótano Sala Técnica o Estacionamiento Exterior",
								className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none placeholder-slate-600 h-11 transition-all"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1157,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1153,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Alimentado Por (Procedencia)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1168,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: alimentadoPor,
								onChange: (e) => setAlimentadoPor(e.target.value),
								placeholder: "Ej. Transformador 500 KVA o CORPOELEC",
								className: "w-full px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none placeholder-slate-600 h-11 transition-all"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1171,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1167,
								columnNumber: 15
							}, this),
							tipoElemento === "TABLERO" && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Número Máximo de Polos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1185,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "number",
									value: maxPoles,
									onChange: (e) => setMaxPoles(parseInt(e.target.value, 10) || 0),
									placeholder: "Escribe el nro. de polos",
									className: "w-2/3 px-3.5 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11 transition-all"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1189,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: maxPoles,
									onChange: (e) => {
										const val = parseInt(e.target.value, 10);
										if (val) setMaxPoles(val);
									},
									className: "w-1/3 px-3 py-2.5 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-sm text-slate-100 focus:outline-none h-11",
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "",
											children: "-- Estándar --"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1204,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 12,
											children: "12 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1205,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 24,
											children: "24 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1206,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 30,
											children: "30 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1207,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 42,
											children: "42 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1208,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 48,
											children: "48 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1209,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 60,
											children: "60 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1210,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 72,
											children: "72 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1211,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 84,
											children: "84 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1212,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: 96,
											children: "96 Polos"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1213,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1196,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1188,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1184,
								columnNumber: 17
							}, this),
							tipoElemento === "TRANSFORMADOR" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Potencia KVA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1224,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: kvaTrafo,
										onChange: (e) => setKvaTrafo(e.target.value),
										placeholder: "Ej. 500 KVA",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1225,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1223,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Marca"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1228,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: marcaTrafo,
										onChange: (e) => setMarcaTrafo(e.target.value),
										placeholder: "Ej. GE",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1229,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1227,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1222,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tipo Transformador"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1234,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: tipoTrafo,
										onChange: (e) => setTipoTrafo(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Aceite",
												children: "Aceite (Sumergido / Exterior)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1236,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Seco",
												children: "Seco (Encapsulado / Interior)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1237,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Pedestal",
												children: "Pedestal (Aceite)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1238,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Poste",
												children: "Montaje en Poste (Aceite)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1239,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1235,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1233,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Conexión"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1243,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: conexionTrafo,
										onChange: (e) => setConexionTrafo(e.target.value),
										placeholder: "Ej. Estrella - Estrella",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1244,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1242,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1232,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1221,
								columnNumber: 17
							}, this),
							tipoElemento === "GENERADOR" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Capacidad kVA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1255,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: kvaGen,
										onChange: (e) => setKvaGen(e.target.value),
										placeholder: "Ej. 580 kVA",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1256,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1254,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Combustible"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1259,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: combustibleGen,
										onChange: (e) => setCombustibleGen(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "DIESEL",
												children: "DIÉSEL / GASOIL"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1261,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "GAS",
												children: "GAS NATURAL"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1262,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "GASOLINA",
												children: "GASOLINA"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1263,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1260,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1258,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1253,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Voltaje Generación"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1269,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: voltajeGen,
										onChange: (e) => setVoltajeGen(e.target.value),
										placeholder: "Ej. 208 / 120 V",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1270,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1268,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Interruptor Amperaje"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1273,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: amperajeGen,
										onChange: (e) => setAmperajeGen(e.target.value),
										placeholder: "Ej. 1600 A",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1274,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1272,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1267,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1252,
								columnNumber: 17
							}, this),
							tipoElemento === "PUESTA_TIERRA" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Resistencia (Ω)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1285,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: resistenciaOhmios,
										onChange: (e) => setResistenciaOhmios(e.target.value),
										placeholder: "Ej. 0.5 Ω",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1286,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1284,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Corriente Fuga (A)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1289,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: corrienteFuga,
										onChange: (e) => setCorrienteFuga(e.target.value),
										placeholder: "Ej. 6.4 A",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono text-amber-450"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1290,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1288,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1283,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
									children: "Tipo de Malla / Ubicación"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1294,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: tipoMalla,
									onChange: (e) => setTipoMalla(e.target.value),
									placeholder: "Ej. Malla debajo de concreto",
									className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1295,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1293,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1282,
								columnNumber: 17
							}, this),
							tipoElemento === "BANCO_CONDENSADOR" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Capacidad Total (kVAR)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1305,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: kvarTotal,
										onChange: (e) => setKvarTotal(e.target.value),
										placeholder: "Ej. 150 kVAR",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1306,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1304,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Pasos / Escalones"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1309,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: pasosCondensador,
										onChange: (e) => setPasosCondensador(e.target.value),
										placeholder: "Ej. 6 pasos",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1310,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1308,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1303,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tipo de Banco"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1315,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: tipoBanco,
										onChange: (e) => setTipoBanco(e.target.value),
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "AUTOMATICO",
											children: "AUTOMÁTICO (CONTROLADOR)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1317,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("option", {
											value: "FIJO",
											children: "FIJO"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1318,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1316,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1314,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tensión Operativa"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1322,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: tensionBanco,
										onChange: (e) => setTensionBanco(e.target.value),
										placeholder: "Ej. 208 V o 480 V",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1323,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1321,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1313,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1302,
								columnNumber: 17
							}, this),
							tipoElemento === "PUNTO_SUMINISTRO" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 md:grid-cols-2 gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
											children: "Tensión de Suministro (COVENIN 159:1997)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1335,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex gap-2",
											children: [/* @__PURE__ */ _jsxDEV("select", {
												value: TENSIONES_COVENIN_TODAS.includes(suministroTension) ? suministroTension : suministroTension ? "CUSTOM" : "",
												onChange: (e) => {
													if (e.target.value !== "CUSTOM") {
														setSuministroTension(e.target.value);
													}
												},
												className: "w-1/2 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10",
												children: [
													/* @__PURE__ */ _jsxDEV("option", {
														value: "",
														children: "Seleccione tensión..."
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1348,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("optgroup", {
														label: "Baja Tensión (BT)",
														children: TENSIONES_COVENIN_159_BT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
															value: v,
															children: v
														}, v, false, {
															fileName: _jsxFileName,
															lineNumber: 1351,
															columnNumber: 31
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1349,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("optgroup", {
														label: "Media Tensión (MT)",
														children: TENSIONES_COVENIN_159_MT.map((v) => /* @__PURE__ */ _jsxDEV("option", {
															value: v,
															children: v
														}, v, false, {
															fileName: _jsxFileName,
															lineNumber: 1356,
															columnNumber: 31
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1354,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "CUSTOM",
														children: "Otra tensión..."
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1359,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1339,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: suministroTension,
												onChange: (e) => setSuministroTension(e.target.value),
												placeholder: "Ej. 13.8 kV o 208/120 V",
												className: "w-1/2 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1361,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1338,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1334,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
											children: "Carga Contratada (kVA)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1372,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: suministroCapacidad,
											onChange: (e) => setSuministroCapacidad(e.target.value),
											placeholder: "Ej. 1000 kVA o 500",
											className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1375,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1371,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1333,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-slate-900/60 p-3.5 rounded-xl border border-slate-800/80 space-y-2",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-[10px] font-bold text-amber-400 uppercase tracking-wide",
											children: "⚡ Tipo de Medición Eléctrica (Obligatorio)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1387,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: suministroTipoMedicion,
											onChange: (e) => setSuministroTipoMedicion(e.target.value),
											className: "w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 h-10 focus:border-amber-500 font-semibold",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Medición Directa (Baja Tensión)",
													children: "1. Medición Directa (Baja Tensión)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1395,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Medición Indirecta BT",
													children: "2. Medición Indirecta BT (con transformadores de corriente TCs)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1396,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Medición Indirecta AT/MT",
													children: "3. Medición Indirecta AT/MT (con TCs y TPs para media/alta tensión)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1397,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1390,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1386,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-slate-900/40 p-4 rounded-xl border border-slate-800 space-y-3",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between pb-2 border-b border-slate-800/60",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] font-bold text-slate-300 uppercase tracking-wide flex items-center gap-2",
													children: [/* @__PURE__ */ _jsxDEV(Gauge, { className: "w-4 h-4 text-blue-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1405,
														columnNumber: 25
													}, this), " Acometida de Servicio / Red Corpoelec"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1404,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("label", {
													className: "flex items-center gap-2 cursor-pointer text-xs text-slate-400",
													children: [/* @__PURE__ */ _jsxDEV("input", {
														type: "checkbox",
														checked: suministroEnlaceCorpoelec,
														onChange: (e) => setSuministroEnlaceCorpoelec(e.target.checked),
														className: "rounded border-slate-700 text-amber-500 focus:ring-amber-500 h-4 w-4 bg-slate-900"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1408,
														columnNumber: 25
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] font-semibold",
														children: "Enlace Activo"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1414,
														columnNumber: 25
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1407,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1403,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "grid grid-cols-1 md:grid-cols-2 gap-3",
												children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
													children: "Empresa Distribuidora"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1420,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "text",
													value: suministroEmpresa,
													onChange: (e) => setSuministroEmpresa(e.target.value),
													placeholder: "Ej. CORPOELEC",
													className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-9"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1421,
													columnNumber: 25
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1419,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
													children: "Tipo de Acometida"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1430,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("select", {
													value: suministroTipoAcometida,
													onChange: (e) => setSuministroTipoAcometida(e.target.value),
													className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-9",
													children: [
														/* @__PURE__ */ _jsxDEV("option", {
															value: "Subterránea",
															children: "Subterránea"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1436,
															columnNumber: 27
														}, this),
														/* @__PURE__ */ _jsxDEV("option", {
															value: "Aérea",
															children: "Aérea"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1437,
															columnNumber: 27
														}, this),
														/* @__PURE__ */ _jsxDEV("option", {
															value: "Mixta",
															children: "Mixta (Aéreo - Subterráneo)"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1438,
															columnNumber: 27
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1431,
													columnNumber: 25
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1429,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1418,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "grid grid-cols-1 md:grid-cols-3 gap-3",
												children: [
													/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
														className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
														children: "N° Contrato / NIC"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1445,
														columnNumber: 25
													}, this), /* @__PURE__ */ _jsxDEV("input", {
														type: "text",
														value: suministroNumeroContrato,
														onChange: (e) => setSuministroNumeroContrato(e.target.value),
														placeholder: "Ej. 1000284759",
														className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-9 font-mono"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1446,
														columnNumber: 25
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1444,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
														className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
														children: "N° Medidor"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1455,
														columnNumber: 25
													}, this), /* @__PURE__ */ _jsxDEV("input", {
														type: "text",
														value: suministroNic,
														onChange: (e) => setSuministroNic(e.target.value),
														placeholder: "Ej. MED-883921",
														className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-9 font-mono"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1456,
														columnNumber: 25
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1454,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
														className: "block text-[9px] font-bold text-slate-400 uppercase mb-1",
														children: "Poste / Trafo Servicio"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1465,
														columnNumber: 25
													}, this), /* @__PURE__ */ _jsxDEV("input", {
														type: "text",
														value: suministroPosteTrafo,
														onChange: (e) => setSuministroPosteTrafo(e.target.value),
														placeholder: "Ej. P-142 / Trafo 50kVA",
														className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-9 font-mono"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1466,
														columnNumber: 25
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1464,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1443,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1402,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1331,
								columnNumber: 17
							}, this),
							tipoElemento === "CCM" && /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Capacidad Barra (A)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1484,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: ccmCapacidadBarra,
										onChange: (e) => setCcmCapacidadBarra(e.target.value),
										placeholder: "Ej. 1200 A",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1485,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1483,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Tensión Operativa"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1488,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: ccmTension,
										onChange: (e) => setCcmTension(e.target.value),
										placeholder: "Ej. 480 V",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1489,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1487,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1482,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Breaker Principal"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1494,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: ccmBreakerPrincipal,
										onChange: (e) => setCcmBreakerPrincipal(e.target.value),
										placeholder: "Ej. 1200A 3P",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1495,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1493,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
										children: "Nro. de Gavetas / Buckets"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1498,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										min: "1",
										max: "48",
										value: ccmNumeroGavetas,
										onChange: (e) => setCcmNumeroGavetas(e.target.value),
										placeholder: "8",
										className: "w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 h-10 font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1499,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1497,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1492,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1481,
								columnNumber: 17
							}, this),
							tipoElemento === "OTRO" && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Especificaciones Técnicas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1508,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("textarea", {
								value: descripcionOtro,
								onChange: (e) => setDescripcionOtro(e.target.value),
								rows: 3,
								placeholder: "Detalles técnicos adicionales...",
								className: "w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none resize-none"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1511,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1507,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5",
								children: "Observaciones del Informe Técnico"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1517,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("textarea", {
								value: observacionesGenerales,
								onChange: (e) => setObservacionesGenerales(e.target.value),
								rows: 2,
								placeholder: "Detalles del estado de mantenimiento, polvo, humedad o recomendaciones...",
								className: "w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-xs text-slate-100 focus:outline-none placeholder-slate-650 transition-all resize-none"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1520,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1516,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1.5 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1532,
									columnNumber: 19
								}, this), "Foto o Imagen de la Placa Técnico"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1531,
								columnNumber: 17
							}, this), previewUrl ? /* @__PURE__ */ _jsxDEV("div", {
								className: "relative rounded-xl overflow-hidden border border-slate-800 bg-slate-900 aspect-video flex items-center justify-center group shadow-md shrink-0",
								children: [/* @__PURE__ */ _jsxDEV("img", {
									src: previewUrl,
									alt: "Vista previa",
									className: "w-full h-full object-cover"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1538,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setFotoBlob(null);
										if (previewUrl) URL.revokeObjectURL(previewUrl);
										setPreviewUrl(null);
									},
									className: "absolute top-2 right-2 p-1.5 bg-slate-950/80 hover:bg-red-650 text-white rounded-lg cursor-pointer",
									children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1548,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1539,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1537,
								columnNumber: 19
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-center w-full",
								children: /* @__PURE__ */ _jsxDEV("label", {
									className: "flex flex-col items-center justify-center w-full h-24 border-2 border-slate-800 border-dashed rounded-xl cursor-pointer bg-slate-900/20 hover:bg-slate-900/40 hover:border-slate-700 transition-all select-none",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-col items-center justify-center pt-3 pb-3",
										children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-5 h-5 text-slate-500 mb-1" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1555,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-slate-450",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold",
												children: "Tomar Foto"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1557,
												columnNumber: 27
											}, this), " o subir"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1556,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1554,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										accept: "image/*",
										capture: "environment",
										onChange: handleImageChange,
										className: "hidden"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1560,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1553,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1552,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1530,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-end gap-3 pt-4 border-t border-slate-900 shrink-0",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowElementoModal(false),
									className: "px-4.5 py-2.5 bg-slate-900 hover:bg-slate-850 text-xs font-bold rounded-xl text-slate-350 transition-colors cursor-pointer",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1574,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: !isElementoValid,
									className: "bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 active:scale-98 transition-all px-4.5 py-2.5 rounded-xl flex items-center justify-center gap-2 h-11 text-xs cursor-pointer shadow-md disabled:opacity-40",
									children: "Guardar Plantilla"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1581,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1573,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1095,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1082,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1079,
				columnNumber: 9
			}, this),
			showEditEmpresaModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center pb-4 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-lg font-bold text-slate-100 flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Building, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1601,
								columnNumber: 17
							}, this), " Editar Empresa"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1600,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowEditEmpresaModal(false),
							className: "p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1607,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1603,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1599,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleUpdateEmpresaSubmit,
						className: "space-y-4 font-sans text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-slate-400 font-semibold mb-1",
								children: "Nombre Comercial"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1613,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: editNombre,
								onChange: (e) => setEditNombre(e.target.value),
								required: true,
								className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1614,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1612,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-400 font-semibold mb-1",
									children: "RIF"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1625,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: editRif,
									onChange: (e) => setEditRif(e.target.value),
									required: true,
									className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1626,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1624,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-400 font-semibold mb-1",
									children: "Dirección Fiscal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1635,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: editDireccionFiscal,
									onChange: (e) => setEditDireccionFiscal(e.target.value),
									required: true,
									className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1636,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1634,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1623,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "border-t border-slate-800 pt-4 mt-4 space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-sky-400 uppercase tracking-wider text-[10px]",
									children: "Gerente Principal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1647,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "col-span-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-500 font-medium mb-1",
												children: "Nombre"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1650,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: editGerente1Nombre,
												onChange: (e) => setEditGerente1Nombre(e.target.value),
												className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1651,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1649,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "col-span-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-500 font-medium mb-1",
												children: "Teléfono"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1659,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: editGerente1Telefono,
												onChange: (e) => setEditGerente1Telefono(e.target.value),
												className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1660,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1658,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "col-span-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-500 font-medium mb-1",
												children: "Email"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1668,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "email",
												value: editGerente1Email,
												onChange: (e) => setEditGerente1Email(e.target.value),
												className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1669,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1667,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1648,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1646,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "border-t border-slate-800 pt-4 mt-4 space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-sky-400 uppercase tracking-wider text-[10px]",
									children: "Gerente Secundario"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1680,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "col-span-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-500 font-medium mb-1",
												children: "Nombre"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1683,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: editGerente2Nombre,
												onChange: (e) => setEditGerente2Nombre(e.target.value),
												className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1684,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1682,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "col-span-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-500 font-medium mb-1",
												children: "Teléfono"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1692,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: editGerente2Telefono,
												onChange: (e) => setEditGerente2Telefono(e.target.value),
												className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1693,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1691,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "col-span-1",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-slate-500 font-medium mb-1",
												children: "Email"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1701,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "email",
												value: editGerente2Email,
												onChange: (e) => setEditGerente2Email(e.target.value),
												className: "w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-amber-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1702,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1700,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1681,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1679,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-end gap-3 pt-6 border-t border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowEditEmpresaModal(false),
									className: "px-4 py-2 border border-slate-700 text-slate-350 hover:bg-slate-800 hover:text-slate-200 rounded-lg font-bold transition-colors cursor-pointer",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1713,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									className: "px-4 py-2 bg-amber-500 text-slate-950 hover:bg-amber-400 active:scale-98 rounded-lg font-bold transition-all shadow-md cursor-pointer",
									children: "Guardar Cambios"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1720,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1712,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1611,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1598,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1597,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(ModalDiagramaUnifilar, {
				isOpen: showDiagramModal,
				onClose: () => setShowDiagramModal(false),
				elementos: companyElementos,
				companyName: company?.nombre,
				companyId
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1733,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 487,
		columnNumber: 5
	}, this);
};
_s2(EmpresaView, "wmAc8ZHatf+fYOzWtGqpLJjCiZw=", false, function() {
	return [
		useParams,
		useNavigate,
		useStore,
		useConfirm
	];
});
_c2 = EmpresaView;
export default EmpresaView;
var _c, _c2;
$RefreshReg$(_c, "SafeImage");
$RefreshReg$(_c2, "EmpresaView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/views/EmpresaView.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/EmpresaView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/EmpresaView.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/views/EmpresaView.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxlQUFlO0FBQ3BELFNBQVMsV0FBVyxtQkFBbUI7QUFDdkMsT0FBTyxZQUFZLGdDQUFnQztBQUNuRCxTQUFTLGtCQUFrQjtBQUMzQixPQUFPLDJCQUEyQjtBQUNsQyxPQUFPLHVCQUF1QjtBQUM5QixPQUFPLHlCQUF5QjtBQUNoQyxTQUNFLDBCQUNBLDBCQUNBLCtCQUNLO0FBQ1AsU0FDRSxXQUNBLE1BQ0EsUUFDQSxlQUNBLFlBQ0EsR0FDQSxVQUNBLFFBQ0EsS0FDQSxRQUNBLFFBQ0EsVUFDQSxNQUNBLEtBQ0EsYUFDQSxXQUNBLGFBQ0EsVUFDQSxPQUNBLGFBQ0s7Ozs7O0FBR1AsTUFBTSxhQUFhLEVBQUUsTUFBTSxLQUFLLEtBQUssZ0JBQWdCOztDQUNuRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxJQUFJO0NBRS9DLGdCQUFnQjtFQUNkLElBQUksTUFBTTtHQUNSLE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO0dBQ3BDLGFBQWEsR0FBRztHQUNoQixhQUFhO0lBQ1gsSUFBSSxnQkFBZ0IsR0FBRztHQUN6QjtFQUNGLE9BQU87R0FDTCxhQUFhLElBQUk7RUFDbkI7Q0FDRixHQUFHLENBQUMsSUFBSSxDQUFDO0NBRVQsTUFBTSxXQUFXLGFBQWE7Q0FDOUIsSUFBSSxDQUFDLFVBQVUsT0FBTztDQUV0QixPQUFPLHdCQUFDLE9BQUQ7RUFBSyxLQUFLO0VBQWU7RUFBZ0I7Q0FBWTs7Ozs7QUFDOUQ7OztBQUVBLE9BQU8sTUFBTSxvQkFBb0I7O0NBQy9CLE1BQU0sRUFBRSxjQUFjLFVBQVU7Q0FDaEMsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsTUFBTSxFQUNKLE1BQ0EsV0FDQSxhQUNBLGdCQUNBLHFCQUNBLHdCQUNBLGVBQ0EsY0FDRSxTQUFTO0NBRWIsTUFBTSxVQUFVLFVBQVUsTUFBTSxNQUFNLEVBQUUsT0FBTyxTQUFTO0NBQ3hELE1BQU0sRUFBRSxTQUFTLE9BQU8sZ0JBQWdCLFdBQVc7O0NBR25ELE1BQU0sQ0FBQyxzQkFBc0IsMkJBQTJCLFNBQVMsS0FBSztDQUN0RSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQVMsRUFBRTtDQUNqRSxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLEVBQUU7Q0FDL0QsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxFQUFFO0NBQ25FLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsRUFBRTtDQUM3RCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLEVBQUU7Q0FDL0QsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxFQUFFO0NBQ25FLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsRUFBRTtDQUU3RCxNQUFNLDRCQUE0QixPQUFPLE1BQU07RUFDN0MsRUFBRSxlQUFlO0VBQ2pCLE1BQU0sY0FBYyxXQUFXO0dBQzdCLFFBQVE7R0FDUixLQUFLO0dBQ0wsaUJBQWlCO0dBQ2pCLGdCQUFnQixzQkFBc0I7R0FDdEMsa0JBQWtCLHdCQUF3QjtHQUMxQyxlQUFlLHFCQUFxQjtHQUNwQyxnQkFBZ0Isc0JBQXNCO0dBQ3RDLGtCQUFrQix3QkFBd0I7R0FDMUMsZUFBZSxxQkFBcUI7RUFDdEMsQ0FBQztFQUNELFVBQVUsbURBQW1ELFNBQVM7RUFDdEUsd0JBQXdCLEtBQUs7Q0FDL0I7O0NBR0EsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7Q0FDaEUsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTs7Q0FHakQsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxLQUFLO0NBQ2hFLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLElBQUksSUFBSSxDQUFDOztDQUd4RCxnQkFBZ0I7RUFDZCxlQUFlLElBQUksSUFBSSxDQUFDO0NBQzFCLEdBQUcsQ0FBQyxXQUFXLENBQUM7Q0FFaEIsTUFBTSxzQkFBc0IsT0FBTztFQUNqQyxnQkFBZ0IsU0FBUztHQUN2QixNQUFNLE9BQU8sSUFBSSxJQUFJLElBQUk7R0FDekIsSUFBSSxLQUFLLElBQUksRUFBRSxHQUFHO0lBQ2hCLEtBQUssT0FBTyxFQUFFO0dBQ2hCLE9BQU87SUFDTCxLQUFLLElBQUksRUFBRTtHQUNiO0dBQ0EsT0FBTztFQUNULENBQUM7Q0FDSDtDQUVBLE1BQU0sd0JBQXdCO0VBQzVCLE1BQU0sZUFBZSxPQUFPLCtCQUErQixjQUFjLDZCQUE2QixDQUFDO0VBQ3ZHLE1BQU0sTUFBTSxhQUFhLEtBQUksTUFBSyxFQUFFLEVBQUU7RUFDdEMsZUFBZSxJQUFJLElBQUksR0FBRyxDQUFDO0NBQzdCO0NBRUEsTUFBTSwwQkFBMEI7RUFDOUIsZUFBZSxJQUFJLElBQUksQ0FBQztDQUMxQjtDQUVBLE1BQU0sdUJBQXVCLFlBQVk7RUFDdkMsTUFBTSxnQkFBZ0IsWUFBWTtFQUNsQyxJQUFJLGtCQUFrQixHQUFHO0VBRXpCLE1BQU0sS0FBSyxNQUFNLFFBQVE7R0FDdkIsT0FBTztHQUNQLFNBQVMsNENBQTRDLGNBQWM7R0FDbkUsTUFBTTtHQUNOLGFBQWE7RUFDZixDQUFDO0VBRUQsSUFBSSxJQUFJO0dBQ04sWUFBWSxTQUFTLE9BQU87SUFDMUIsdUJBQXVCLE1BQU0sRUFBRTtHQUNqQyxDQUFDO0dBQ0QsWUFBWSxpQkFBaUIsY0FBYyx5QkFBeUIsU0FBUztHQUM3RSxlQUFlLElBQUksSUFBSSxDQUFDO0dBQ3hCLHFCQUFxQixLQUFLO0VBQzVCO0NBQ0Y7Q0FFQSxNQUFNLHVCQUF1QixPQUFPLFlBQVksU0FBUztFQUN2RCxNQUFNLEtBQUssTUFBTSxRQUFRO0dBQ3ZCLE9BQU87R0FDUCxTQUFTLHFEQUFxRCxLQUFLO0dBQ25FLE1BQU07R0FDTixhQUFhO0VBQ2YsQ0FBQztFQUVELElBQUksSUFBSTtHQUNOLGVBQWUsV0FBVyxVQUFVO0dBQ3BDLFlBQVksb0NBQW9DLFNBQVM7RUFDM0Q7Q0FDRjs7Q0FHQSxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEVBQUU7Q0FDdkQsTUFBTSxDQUFDLHFCQUFxQiwwQkFBMEIsU0FBUyxFQUFFOztDQUdqRSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxTQUFTO0NBQzFELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTtDQUN2RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxFQUFFO0NBQzdDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEVBQUU7Q0FDckQsTUFBTSxDQUFDLHdCQUF3Qiw2QkFBNkIsU0FBUyxFQUFFO0NBQ3ZFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxJQUFJO0NBQzdDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLElBQUk7O0NBR2pELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFOztDQUczQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLFVBQVU7Q0FDckQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsRUFBRTtDQUNyRCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEVBQUU7Q0FDekQsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxFQUFFOztDQUc3RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRTtDQUN2QyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLFFBQVE7Q0FDN0QsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7O0NBR2pELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsRUFBRTtDQUM3RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FDN0MsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxFQUFFOztDQUduRSxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEVBQUU7Q0FDN0QsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxZQUFZO0NBQ3ZFLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsRUFBRTs7Q0FHM0QsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUM3QyxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEVBQUU7Q0FDM0QsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsWUFBWTtDQUN2RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFOztDQUduRCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEVBQUU7Q0FDN0QsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxXQUFXO0NBQ3RFLE1BQU0sQ0FBQyx5QkFBeUIsOEJBQThCLFNBQVMsYUFBYTtDQUNwRixNQUFNLENBQUMscUJBQXFCLDBCQUEwQixTQUFTLEVBQUU7Q0FDakUsTUFBTSxDQUFDLHdCQUF3Qiw2QkFBNkIsU0FBUyxpQ0FBaUM7Q0FDdEcsTUFBTSxDQUFDLDJCQUEyQixnQ0FBZ0MsU0FBUyxJQUFJO0NBQy9FLE1BQU0sQ0FBQywwQkFBMEIsK0JBQStCLFNBQVMsRUFBRTtDQUMzRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxzQkFBc0IsMkJBQTJCLFNBQVMsRUFBRTs7Q0FHbkUsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxFQUFFO0NBQzdELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEVBQUU7Q0FDL0MsTUFBTSxDQUFDLHFCQUFxQiwwQkFBMEIsU0FBUyxFQUFFO0NBQ2pFLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsQ0FBQzs7Q0FHMUQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFO0NBRXpELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUU5RCxNQUFNLG1CQUFtQixjQUFjO0VBQ3JDLElBQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQztFQUN0QixNQUFNLE9BQU8sQ0FBQztFQUNkLElBQUksUUFBUSxxQkFBcUI7R0FDL0IsS0FBSyxLQUFLLEdBQUcsUUFBUSxtQkFBbUI7RUFDMUM7RUFDQSxJQUFJLFFBQVEsV0FBVztHQUNyQixRQUFRLFVBQVUsU0FBUyxNQUFNO0lBQy9CLE1BQU0sUUFBUSxFQUFFLHVCQUF1QixFQUFFLFlBQVksQ0FBQztJQUN0RCxLQUFLLEtBQUssR0FBRyxLQUFLO0dBQ3BCLENBQUM7RUFDSDtFQUNBLE9BQU87Q0FDVCxHQUFHLENBQUMsT0FBTyxDQUFDO0NBRVosSUFBSSxDQUFDLFNBQVM7RUFDWixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSx5Q0FBMEM7Ozs7O0lBQ25FLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQW9CO0lBQXlCOzs7OztJQUMzRCx3QkFBQyxVQUFEO0tBQVEsZUFBZSxTQUFTLEdBQUc7S0FBRyxXQUFVO2VBQWtHO0lBRTFJOzs7OztHQUNMOzs7Ozs7Q0FFVDtDQUVBLE1BQU0sWUFBWSxRQUFRLGFBQWEsQ0FBQztDQUN4QyxNQUFNLHFCQUFxQixRQUFRLHVCQUF1QixDQUFDO0NBRTNELE1BQU0sbUJBQW1CLFVBQVUsUUFBUSxNQUN6QyxFQUFFLE9BQU8sWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFlBQVksQ0FBQyxLQUN4RCxFQUFFLGVBQWUsRUFBRSxZQUFZLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsQ0FDbEY7Q0FFQSxNQUFNLDZCQUE2QixtQkFBbUIsUUFBUSxTQUM1RCxLQUFLLE9BQU8sWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFlBQVksQ0FBQyxLQUMzRCxLQUFLLGFBQWEsS0FBSyxVQUFVLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsS0FDbEYsS0FBSyxhQUFhLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsQ0FDcEU7Q0FFQSxNQUFNLDBCQUEwQixVQUFVLE1BQ3ZDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDLEtBQUssTUFBTSxlQUFlLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FDN0U7Q0FDQSxNQUFNLGtCQUFrQixlQUFlLEtBQUssTUFBTSxNQUFNLENBQUM7Q0FFekQsTUFBTSwwQkFBMEIsbUJBQW1CLE1BQ2hELE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDLEtBQUssTUFBTSxlQUFlLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FDN0U7Q0FDQSxNQUFNLGtCQUFrQixlQUFlLEtBQUssTUFBTSxNQUFNLENBQUM7Q0FFekQsTUFBTSxxQkFBcUIsTUFBTTtFQUMvQixNQUFNLE9BQU8sRUFBRSxPQUFPLE1BQU07RUFDNUIsSUFBSSxDQUFDLE1BQU07RUFFWCxJQUFJLEtBQUssT0FBTyxLQUFLLE9BQU8sTUFBTTtHQUNoQyxZQUFZLHNFQUFzRTtHQUNsRjtFQUNGO0VBRUEsWUFBWSxJQUFJO0VBQ2hCLElBQUksWUFBWSxJQUFJLGdCQUFnQixVQUFVO0VBQzlDLGNBQWMsSUFBSSxnQkFBZ0IsSUFBSSxDQUFDO0NBQ3pDO0NBRUEsTUFBTSx3QkFBd0IsTUFBTTtFQUNsQyxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLGlCQUFpQjtFQUV0QixNQUFNLFNBQVMsWUFDYixlQUFlLEtBQUssR0FDcEIsb0JBQW9CLEtBQUssR0FDekIsU0FDRjtFQUVBLElBQUksT0FBTyxTQUFTO0dBQ2xCLGtCQUFrQixFQUFFO0dBQ3BCLHVCQUF1QixFQUFFO0dBQ3pCLGFBQWEsS0FBSztFQUNwQixPQUFPO0dBQ0wsWUFBWSxPQUFPLEtBQUs7RUFDMUI7Q0FDRjtDQUVBLE1BQU0sd0JBQXdCLE1BQU07RUFDbEMsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxpQkFBaUI7RUFFdEIsSUFBSSxnQkFBZ0IsQ0FBQztFQUVyQixJQUFJLGlCQUFpQixXQUFXO0dBQzlCLGdCQUFnQjtJQUNkLFVBQVUsU0FBUyxVQUFVLEVBQUU7SUFDL0IsbUJBQW1CO0tBQUUsSUFBSTtLQUFLLElBQUk7S0FBSyxJQUFJO0lBQUk7SUFDL0Msa0JBQWtCO0tBQUUsT0FBTztLQUFJLE1BQU07S0FBSSxLQUFLO0lBQUc7SUFDakQsU0FBUztLQUFFLElBQUk7S0FBTyxJQUFJO0tBQU8sSUFBSTtJQUFNO0lBQzNDLFdBQVc7SUFDWCxVQUFVLENBQUM7SUFDWCxlQUFlO0tBQUUsU0FBUztLQUFJLGVBQWU7SUFBRztJQUNoRCxjQUFjO0tBQUUsU0FBUztLQUFJLGVBQWU7SUFBRztHQUNqRDtFQUNGLE9BQU8sSUFBSSxpQkFBaUIsaUJBQWlCO0dBQzNDLGdCQUFnQjtJQUNkLE9BQU8sY0FBYztJQUNyQixPQUFPO0lBQ1AsYUFBYSxZQUFZO0lBQ3pCLEtBQUssWUFBWTtJQUNqQixtQkFBbUIsYUFBYTtJQUNoQyxVQUFVLGlCQUFpQjtJQUMzQixpQkFBaUIsbUJBQW1CO0lBQ3BDLG1CQUFtQixxQkFBcUI7SUFDeEMsZUFBZTtJQUNmLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsaUJBQWlCLG1CQUFtQjtJQUNwQyxrQkFBa0I7SUFDbEIsbUJBQW1CLHFCQUFxQjtJQUN4QyxvQkFBb0I7SUFDcEIsYUFBYTtJQUNiLFFBQVE7SUFDUixNQUFNO0lBQ04sWUFBWTtLQUNWLFVBQVU7TUFBRSxPQUFPO01BQU8sYUFBYTtNQUFPLFNBQVM7TUFBSSxNQUFNO01BQUksVUFBVTtNQUFJLFNBQVM7TUFBSSxXQUFXO01BQUksZUFBZTtLQUFHO0tBQ2pJLFlBQVk7TUFBRSxPQUFPO01BQU8sYUFBYTtNQUFPLFNBQVM7TUFBSSxNQUFNO01BQUksVUFBVTtNQUFJLFNBQVM7TUFBSSxXQUFXO01BQUksZUFBZTtLQUFHO0tBQ25JLFFBQVE7TUFBRSxPQUFPO01BQU8sYUFBYTtNQUFPLFNBQVM7TUFBSSxNQUFNO01BQUksVUFBVTtNQUFJLFNBQVM7TUFBSSxXQUFXO01BQUksZUFBZTtLQUFHO0lBQ2pJO0lBQ0EsS0FBSztLQUNILGdCQUFnQjtLQUNoQixpQkFBaUI7S0FDakIsc0JBQXNCO0tBQ3RCLGtCQUFrQjtLQUNsQixtQkFBbUI7S0FDbkIsYUFBYTtLQUNiLGVBQWU7SUFDakI7R0FDRjtFQUNGLE9BQU8sSUFBSSxpQkFBaUIsYUFBYTtHQUN2QyxnQkFBZ0I7SUFDZCxLQUFLO0lBQ0wsYUFBYTtJQUNiLG1CQUFtQjtJQUNuQixZQUFZO0lBQ1osVUFBVTtHQUNaO0VBQ0YsT0FBTyxJQUFJLGlCQUFpQixxQkFBcUI7R0FDL0MsZ0JBQWdCO0lBQ2QsT0FBTztJQUFJLFFBQVE7SUFBSSxhQUFhO0lBQUksa0JBQWtCO0lBQUksWUFBWTtJQUFJLGlCQUFpQjtJQUMvRixnQkFBZ0IsZ0JBQWdCO0lBQVMsbUJBQW1CLGdCQUFnQjtJQUFTLFlBQVk7SUFDakcsdUJBQXVCLGFBQWE7SUFDcEMsdUJBQXVCO0lBQUksVUFBVTtJQUFhLFVBQVU7SUFBWSxxQkFBcUI7SUFDN0Ysa0JBQWtCLGNBQWMsZUFBZSx1QkFBdUI7SUFBUSxVQUFVLG9CQUFvQjtJQUFLLG9CQUFvQjtJQUNySSxpQkFBaUI7SUFBeUIsb0JBQW9CO0lBQUksaUJBQWlCO0lBQ25GLG9CQUFvQjtJQUFJLHVCQUF1QjtJQUMvQyxxQkFBcUI7SUFBTSxXQUFXO0lBQ3RDLHVCQUF1QjtJQUFPLFlBQVk7SUFDMUMseUJBQXlCO0lBQW1CLG1CQUFtQjtJQUMvRCxzQkFBc0I7SUFBSSxZQUFZO0lBQUksb0JBQW9CO0lBQzlELHlCQUF5QjtJQUFJLGlCQUFpQjtJQUFZLDJCQUEyQjtJQUNyRixpQkFBaUI7SUFBSSxrQkFBa0I7SUFBSSxpQkFBaUI7SUFDNUQscUJBQXFCO0lBQXVCLGNBQWM7SUFBSSxZQUFZO0dBQzVFO0VBQ0YsT0FBTyxJQUFJLGlCQUFpQixvQkFBb0I7R0FDOUMsZ0JBQWdCO0lBQ2QsY0FBYyxxQkFBcUI7SUFDbkMsZ0JBQWdCLHFCQUFxQjtJQUNyQyxzQkFBc0IscUJBQXFCO0lBQzNDLGVBQWUsMkJBQTJCO0lBQzFDLHdCQUF3Qix1QkFBdUI7SUFDL0Msb0JBQW9CLHVCQUF1QjtJQUMzQyxjQUFjLDBCQUEwQjtJQUN4QyxpQkFBaUIsUUFBUSx5QkFBeUI7SUFDbEQsZ0JBQWdCLDRCQUE0QjtJQUM1QyxLQUFLLGlCQUFpQjtJQUN0QixvQkFBb0Isd0JBQXdCO0dBQzlDO0VBQ0YsT0FBTyxJQUFJLGlCQUFpQixPQUFPO0dBQ2pDLGdCQUFnQjtJQUNkLHdCQUF3QixxQkFBcUI7SUFDN0Msa0JBQWtCLGNBQWM7SUFDaEMsa0JBQWtCLHVCQUF1QjtJQUN6QyxlQUFlLFNBQVMsa0JBQWtCLEVBQUUsS0FBSztHQUNuRDtFQUNGLE9BQU8sSUFBSSxpQkFBaUIsaUJBQWlCO0dBQzNDLGdCQUFnQjtJQUNkO0lBQ0EsdUJBQXVCO0lBQ3ZCO0lBQ0EsZ0JBQWdCO0dBQ2xCO0VBQ0YsT0FBTyxJQUFJLGlCQUFpQixZQUFZO0dBQ3RDLGdCQUFnQjtJQUNkO0lBQ0E7SUFDQTtHQUNGO0VBQ0YsT0FBTztHQUNMLGdCQUFnQixFQUNkLDZCQUE2QixnQkFDL0I7RUFDRjtFQUVBLE1BQU0sU0FBUyxvQkFBb0I7R0FDakMsWUFBWTtHQUNaO0dBQ0EsUUFBUSxlQUFlLEtBQUs7R0FDNUI7R0FDQSxXQUFXLFVBQVUsS0FBSyxLQUFLO0dBQy9CLGVBQWUsY0FBYyxLQUFLLEtBQUs7R0FDdkM7R0FDQSx3QkFBd0IsdUJBQXVCLEtBQUs7R0FDcEQ7RUFDRixDQUFDO0VBRUQsSUFBSSxPQUFPLFNBQVM7R0FDbEIsa0JBQWtCLEVBQUU7R0FDcEIsYUFBYSxFQUFFO0dBQ2YsaUJBQWlCLEVBQUU7R0FDbkIsMEJBQTBCLEVBQUU7R0FDNUIscUJBQXFCLEVBQUU7R0FDdkIscUJBQXFCLFdBQVc7R0FDaEMsMkJBQTJCLGFBQWE7R0FDeEMsdUJBQXVCLEVBQUU7R0FDekIsMEJBQTBCLGlDQUFpQztHQUMzRCw2QkFBNkIsSUFBSTtHQUNqQyw0QkFBNEIsRUFBRTtHQUM5QixpQkFBaUIsRUFBRTtHQUNuQix3QkFBd0IsRUFBRTtHQUMxQixZQUFZLElBQUk7R0FDaEIsSUFBSSxZQUFZLElBQUksZ0JBQWdCLFVBQVU7R0FDOUMsY0FBYyxJQUFJO0dBQ2xCLHFCQUFxQixLQUFLO0VBQzVCLE9BQU87R0FDTCxZQUFZLE9BQU8sS0FBSztFQUMxQjtDQUNGO0NBRUEsTUFBTSwrQkFBK0I7RUFDbkMscUJBQXFCLElBQUk7Q0FDM0I7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FHRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUNoQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsU0FBUyxHQUFHO01BQzNCLFdBQVU7TUFDVixPQUFNO2dCQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O0tBQzFCOzs7O2VBQ1Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFzRTtLQUVoRjs7OztlQUNOLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFtRCxRQUFRO0tBQVc7Ozs7YUFDakY7Ozs7YUFDRjs7Ozs7O0dBQ0M7Ozs7O0dBR1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEI7S0FHRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUEyRTtRQUFtQjs7OztrQkFDOUcsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQ7VUFDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSx5QkFBMEI7Ozs7O1VBQUM7VUFBRSxRQUFRO1NBQ3ZEOzs7OztnQkFDRDs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNHLE1BQU0sU0FBUyxXQUNkLHdCQUFDLFVBQUQ7VUFDRSxlQUFlO1dBQ2IsY0FBYyxRQUFRLE1BQU07V0FDNUIsV0FBVyxRQUFRLE9BQU8sRUFBRTtXQUM1Qix1QkFBdUIsUUFBUSxtQkFBbUIsRUFBRTtXQUNwRCxzQkFBc0IsUUFBUSxrQkFBa0IsRUFBRTtXQUNsRCx3QkFBd0IsUUFBUSxvQkFBb0IsRUFBRTtXQUN0RCxxQkFBcUIsUUFBUSxpQkFBaUIsRUFBRTtXQUNoRCxzQkFBc0IsUUFBUSxrQkFBa0IsRUFBRTtXQUNsRCx3QkFBd0IsUUFBUSxvQkFBb0IsRUFBRTtXQUN0RCxxQkFBcUIsUUFBUSxpQkFBaUIsRUFBRTtXQUNoRCx3QkFBd0IsSUFBSTtVQUM5QjtVQUNBLFdBQVU7b0JBQ1g7U0FFTzs7OzttQkFFVix3QkFBQyxVQUFEO1VBQ0UsZUFBZSxTQUFTLFVBQVU7VUFDbEMsV0FBVTtVQUNWLE9BQU07b0JBSFIsQ0FLRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O29CQUFDLHFCQUU5Qjs7Ozs7aUJBQ0w7Ozs7O2dCQUNGOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUQ7U0FBUzs7OzttQkFDaEYsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXdDLFFBQVEsT0FBTztTQUFjOzs7O2lCQUNsRjs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF1RDtVQUFzQjs7OztvQkFDN0Ysd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXdDLFFBQVEsbUJBQW1CO1VBQVk7Ozs7a0JBQzVGOzs7Ozs7U0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXVEO1NBQWM7Ozs7bUJBQ3JGLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUFLLFlBQVMsUUFBUSxZQUFZLElBQUksS0FBSyxRQUFRLFNBQVMsQ0FBQyxDQUFDLGVBQWUsT0FBTyxJQUFJLEtBQVc7Ozs7b0JBQ25HLHdCQUFDLE9BQUQsYUFBSyxpQkFBYyxRQUFRLFlBQVksSUFBSSxLQUFLLFFBQVEsU0FBUyxDQUFDLENBQUMsZUFBZSxPQUFPLElBQUksS0FBVzs7OztrQkFDckc7Ozs7O2lCQUNGOzs7OztRQUNGOzs7Ozs7T0FFSixNQUFNLFNBQVMsV0FDZCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsdUJBQXdCOzs7O21CQUFDLHlEQUN2Qzs7Ozs7a0JBQ0osd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FFRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUEwRDtVQUF1Qjs7OztvQkFDakcsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxPQUFEO2FBQUssd0JBQUMsVUFBRDtjQUFRLFdBQVU7d0JBQWlCO2FBQWU7Ozs7O2FBQUM7YUFBQyx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBZ0MsUUFBUSxrQkFBa0I7YUFBWTs7Ozs7WUFBTTs7Ozs7WUFDckosd0JBQUMsT0FBRDthQUFLLHdCQUFDLFVBQUQ7Y0FBUSxXQUFVO3dCQUFpQjthQUFpQjs7Ozs7YUFBQzthQUFDLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFnQyxRQUFRLG9CQUFvQjthQUFZOzs7OztZQUFNOzs7OztZQUN6Six3QkFBQyxPQUFEO2FBQUssd0JBQUMsVUFBRDtjQUFRLFdBQVU7d0JBQWlCO2FBQWM7Ozs7O2FBQUM7YUFBQyx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBZ0MsUUFBUSxpQkFBaUI7YUFBWTs7Ozs7WUFBTTs7Ozs7V0FDaEo7Ozs7O2tCQUNGOzs7OzttQkFHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUEwRDtVQUF3Qjs7OztvQkFDbEcsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxPQUFEO2FBQUssd0JBQUMsVUFBRDtjQUFRLFdBQVU7d0JBQWlCO2FBQWU7Ozs7O2FBQUM7YUFBQyx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBZ0MsUUFBUSxrQkFBa0I7YUFBWTs7Ozs7WUFBTTs7Ozs7WUFDckosd0JBQUMsT0FBRDthQUFLLHdCQUFDLFVBQUQ7Y0FBUSxXQUFVO3dCQUFpQjthQUFpQjs7Ozs7YUFBQzthQUFDLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFnQyxRQUFRLG9CQUFvQjthQUFZOzs7OztZQUFNOzs7OztZQUN6Six3QkFBQyxPQUFEO2FBQUssd0JBQUMsVUFBRDtjQUFRLFdBQVU7d0JBQWlCO2FBQWM7Ozs7O2FBQUM7YUFBQyx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBZ0MsUUFBUSxpQkFBaUI7YUFBWTs7Ozs7WUFBTTs7Ozs7V0FDaEo7Ozs7O2tCQUNGOzs7OztpQkFDRjs7Ozs7Z0JBQ0Y7Ozs7OztNQUVKOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7UUFDOUMsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztpQkFDRCx3QkFBQyxRQUFELEVBQVEsV0FBVSxxREFBc0Q7Ozs7ZUFDckU7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBR0Usd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLG9CQUFvQixJQUFJO1FBQ3ZDLFdBQVU7a0JBSFosQ0FLRSx3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7a0JBQUMsdUJBQ3BDOzs7OztpQkFFVCxNQUFNLFNBQVMsWUFDZCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUVFLHdCQUFDLFVBQUQ7VUFDRSxlQUFlO1dBQ2IscUJBQXFCLENBQUMsaUJBQWlCO1dBQ3ZDLGVBQWUsSUFBSSxJQUFJLENBQUM7VUFDMUI7VUFDQSxXQUFXLDZLQUNULG9CQUNJLHVEQUNBO29CQVJSO1dBV0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsVUFBVzs7Ozs7V0FBQztXQUFFLG9CQUFvQix1QkFBdUI7VUFDMUU7Ozs7OztTQUdSLHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtvQkFGWixDQUlFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLHdDQUF5Qzs7OztvQkFBQyxtQkFDbkQ7Ozs7OztTQUdSLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLGFBQWEsSUFBSTtVQUNoQyxXQUFVO29CQUZaLENBSUUsd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7OztvQkFBQyxtQkFDdEI7Ozs7OztRQUNMOzs7OztlQUVGOzs7OztjQUNGOzs7Ozs7S0FFSixxQkFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsa0RBQW1EOzs7O2lCQUNsRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEI7U0FBcUQ7U0FDMUIsd0JBQUMsVUFBRDtVQUFRLFdBQVU7b0JBQTRCLFlBQVk7U0FBYTs7Ozs7U0FBQztTQUFFLFlBQVksU0FBUyxJQUFJLHdCQUF3QjtRQUNoSjs7Ozs7ZUFDSDs7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7bUJBQ1g7UUFFTzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7bUJBQ1g7UUFFTzs7Ozs7UUFDUCxZQUFZLE9BQU8sS0FBSyxNQUFNLFNBQVMsWUFDdEMsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFVO21CQUZaO1VBSUUsd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7Ozs7VUFBQztVQUFZLFlBQVk7VUFBSztTQUN6RDs7Ozs7O1FBRVYsd0JBQUMsVUFBRDtTQUNFLGVBQWU7VUFDYixxQkFBcUIsS0FBSztVQUMxQixlQUFlLElBQUksSUFBSSxDQUFDO1NBQzFCO1NBQ0EsV0FBVTttQkFDWDtRQUVPOzs7OztPQUNMOzs7OztjQUNGOzs7Ozs7S0FJUCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLHlCQUEwQjs7Ozs7UUFBQztRQUF5QixVQUFVO1FBQU87T0FDekY7Ozs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE4QjtNQUV4Qzs7OztjQUNBOzs7OztlQUVKLGlCQUFpQixTQUFTLElBQ3pCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLGlCQUFpQixLQUFLLFNBQ3JCLHdCQUFDLE9BQUQ7T0FFRSxlQUFlLFNBQVMsWUFBWSxVQUFVLFlBQVksS0FBSyxJQUFJO09BQ25FLFdBQVU7aUJBSFo7UUFLRyxNQUFNLFNBQVMsWUFDZCx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFVBQVUsTUFBTTtVQUNkLEVBQUUsZ0JBQWdCO1VBQ2xCLHFCQUFxQixLQUFLLElBQUksS0FBSyxNQUFNO1NBQzNDO1NBQ0EsV0FBVTtTQUNWLE9BQU07bUJBRU4sd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7Ozs7UUFDM0I7Ozs7O1FBRVYsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7OztTQUM5Qjs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLEtBQUs7VUFDSjs7OztvQkFDSix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixLQUFLLGVBQWU7VUFDcEI7Ozs7a0JBQ0E7Ozs7O2lCQUNGOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxvQ0FBcUM7Ozs7O1lBQ3ZELHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3dCQUF1QyxLQUFLLHVCQUF1QixLQUFLLFlBQVksQ0FBQyxFQUFDLENBQUU7WUFBYTs7Ozs7WUFBQztXQUNuSDs7Ozs7b0JBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxzQ0FBdUM7Ozs7O1lBQzNELHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3dCQUF1QyxLQUFLLDJCQUEyQixLQUFLLGlCQUFpQixDQUFDLEVBQUMsQ0FBRTtZQUFhOzs7OztZQUFDO1dBQzVIOzs7OztrQkFDRjs7Ozs7bUJBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sVUFBYTs7OztvQkFDbkIsd0JBQUMsUUFBRCxZQUFPLEtBQUssWUFBWSxJQUFJLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQyxtQkFBbUIsT0FBTyxJQUFJLE1BQVk7Ozs7a0JBQ3hGOzs7OztpQkFDRjs7Ozs7O09BQ0Y7U0FqREUsS0FBSzs7OzthQWlEUCxDQUNOO0tBQ0U7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxZQUFELEVBQVksV0FBVSxtQ0FBb0M7Ozs7Z0JBQzFELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQW1DO09BQStCOzs7O2lCQUNoRix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBMEM7T0FFcEQ7Ozs7ZUFDQTs7Ozs7Y0FDRjs7Ozs7YUFFSjs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQ7U0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7O1NBQUM7U0FBNkIsbUJBQW1CO1NBQU87UUFDL0Y7Ozs7O2lCQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE4QjtPQUV4Qzs7OztlQUNBOzs7OztnQkFFSiwyQkFBMkIsU0FBUyxJQUNuQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWiwyQkFBMkIsS0FBSyxTQUFTO1FBQ3hDLE1BQU0sWUFBWSxLQUFLLGlCQUFpQjtRQUN4QyxNQUFNLFVBQVUsS0FBSyxpQkFBaUI7UUFDdEMsTUFBTSxRQUFRLEtBQUssaUJBQWlCO1FBQ3BDLE1BQU0saUJBQWlCLEtBQUssaUJBQWlCO1FBQzdDLE1BQU0sYUFBYSxLQUFLLGlCQUFpQjtRQUN6QyxNQUFNLGFBQWEsWUFBWSxJQUFJLEtBQUssRUFBRTtRQUUxQyxPQUNFLHdCQUFDLE9BQUQ7U0FFRSxlQUFlO1VBQ2IsSUFBSSxtQkFBbUI7V0FDckIsbUJBQW1CLEtBQUssRUFBRTtVQUM1QixPQUFPO1dBQ0wsU0FBUyxZQUFZLFVBQVUsV0FBVyxLQUFLLElBQUk7VUFDckQ7U0FDRjtTQUNBLFdBQVcsc0tBQ1QscUJBQXFCLGFBQ2pCLGlFQUNBO21CQVpSLENBZ0JFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0csS0FBSyxZQUFZLEtBQUssT0FDckIsd0JBQUMsV0FBRDtZQUNFLE1BQU0sS0FBSztZQUNYLEtBQUssS0FBSztZQUNWLEtBQUssS0FBSztZQUNWLFdBQVU7V0FDWDs7OztzQkFFRCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUNHLGFBQWEsd0JBQUMsS0FBRCxFQUFLLFdBQVUsa0NBQW1DOzs7OzthQUMvRCxXQUFXLHdCQUFDLEtBQUQsRUFBSyxXQUFVLHFDQUFzQzs7Ozs7YUFDaEUsU0FBUyx3QkFBQyxLQUFELEVBQUssV0FBVSxvQ0FBcUM7Ozs7O2FBQzdELGtCQUFrQix3QkFBQyxhQUFELEVBQWEsV0FBVSxtQ0FBb0M7Ozs7O2FBQzdFLGNBQWMsd0JBQUMsV0FBRCxFQUFXLFdBQVUsc0NBQXVDOzs7OzthQUMxRSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLGNBQWMsd0JBQUMsUUFBRCxFQUFRLFdBQVUsb0NBQXFDOzs7OzthQUM5SCx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBNEQ7YUFBZ0I7Ozs7O1lBQ3pGOzs7Ozs7V0FJUCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUNHLGFBQ0Msd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQThHO2FBRXhIOzs7OzthQUVQLFdBQ0Msd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQXVIO2FBRWpJOzs7OzthQUVQLFNBQ0Msd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQW9IO2FBRTlIOzs7OzthQUVQLGtCQUNDLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFpSDthQUUzSDs7Ozs7YUFFUCxjQUNDLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUEwSDthQUVwSTs7Ozs7YUFFUCxLQUFLLGlCQUFpQixzQkFDckIsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWlIO2FBRTNIOzs7OzthQUVQLEtBQUssaUJBQWlCLFNBQ3JCLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFvSDthQUU5SDs7Ozs7YUFFUCxLQUFLLGlCQUFpQix1QkFDckIsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQTBIO2FBRXBJOzs7OztZQUVMOzs7Ozs7V0FHSixDQUFDLHFCQUNBLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUF5SSxRQUNsSSxLQUFLLEVBQ047Ozs7OztXQUNIOzs7OztXQUlOLHFCQUNDLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLFFBQUQ7YUFBTSxXQUFXLDJFQUNmLGFBQ0ksK0VBQ0E7dUJBRUgsYUFDQyx3QkFBQyxhQUFELEVBQWEsV0FBVSxjQUFlOzs7O3dCQUV0Qyx3QkFBQyxPQUFELEVBQUssV0FBVSxpREFBa0Q7Ozs7O1lBRS9EOzs7OztXQUNIOzs7OztVQUVKOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1gseUJBQXlCLEtBQUssUUFBUSxLQUFLLEVBQUU7WUFDNUM7Ozs7c0JBQ0osd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDRSx3QkFBQyxLQUFEO2VBQUcsV0FBVTt5QkFBYjtnQkFBd0Isd0JBQUMsUUFBRDtpQkFBTSxXQUFVOzJCQUEyQjtnQkFBZ0I7Ozs7O2dCQUFDO2dCQUFFLEtBQUs7ZUFBYTs7Ozs7O2NBQ3hHLHdCQUFDLEtBQUQ7ZUFBRyxXQUFVO3lCQUFiO2dCQUF3Qix3QkFBQyxRQUFEO2lCQUFNLFdBQVU7MkJBQTJCO2dCQUFrQjs7Ozs7Z0JBQUM7Z0JBQUUsS0FBSyxpQkFBaUI7ZUFBaUI7Ozs7OztjQUUvSCx3QkFBQyxPQUFEO2VBQUssV0FBVTt5QkFBZjtnQkFDRyxhQUNDLHdCQUFDLEtBQUQ7aUJBQUcsV0FBVTsyQkFBYjtrQkFBd0g7a0JBQ3hHLEtBQUssZUFBZSxZQUFZO2tCQUFHO2tCQUFTLEtBQUssZUFBZSxvQkFBb0I7a0JBQVk7aUJBQzdHOzs7Ozs7Z0JBRUosV0FDQyx3QkFBQyxLQUFEO2lCQUFHLFdBQVU7MkJBQWI7a0JBQWlJO2tCQUM1SCxLQUFLLGVBQWUsT0FBTztrQkFBVTtrQkFBTyxLQUFLLGVBQWUsWUFBWTtrQkFBb0I7a0JBQUcsS0FBSyxlQUFlLG1CQUFtQjtrQkFBVTtpQkFDdEo7Ozs7OztnQkFFSixTQUNDLHdCQUFDLEtBQUQ7aUJBQUcsV0FBVTsyQkFBYjtrQkFBOEg7a0JBQ3pILEtBQUssZUFBZSxPQUFPO2tCQUFVO2tCQUFJLEtBQUssZUFBZSxxQkFBcUI7a0JBQVE7a0JBQVksS0FBSyxlQUFlLFlBQVk7aUJBQ3hJOzs7Ozs7Z0JBRUosa0JBQ0Msd0JBQUMsS0FBRDtpQkFBRyxXQUFVOzJCQUFiO2tCQUEySDtrQkFDcEcsS0FBSyxlQUFlLHlCQUF5QjtrQkFBUTtrQkFBSSxLQUFLLGVBQWUsYUFBYTtpQkFDOUc7Ozs7OztnQkFFSixjQUNDLHdCQUFDLEtBQUQ7aUJBQUcsV0FBVTsyQkFBYjtrQkFBb0k7a0JBQzlILEtBQUssZUFBZSxxQkFBcUI7a0JBQVM7a0JBQUksS0FBSyxlQUFlLHFCQUFxQjtpQkFDbEc7Ozs7OztnQkFFSixLQUFLLGlCQUFpQixzQkFDckIsd0JBQUMsS0FBRDtpQkFBRyxXQUFVOzJCQUFiO2tCQUEySDtrQkFDckgsS0FBSyxlQUFlLGdCQUFnQjtrQkFBVTtrQkFBSSxLQUFLLGVBQWUsc0JBQXNCLEtBQUssZUFBZSwwQkFBMEI7a0JBQVc7a0JBQUksS0FBSyxlQUFlLGdCQUFnQjtpQkFDaE07Ozs7OztlQUVGOzs7Ozs7YUFDRjs7Ozs7b0JBQ0Y7Ozs7OztXQUdMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLG1CQUFEO2FBQW1CLFVBQVU7YUFBTSxjQUFjLEtBQUssZ0JBQWdCO1lBQVk7Ozs7O1dBQy9FOzs7OztXQUdMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLHFCQUFEO2FBQ0UsY0FBYyxTQUFTLFlBQVksVUFBVSxXQUFXLEtBQUssSUFBSTthQUNqRSx1QkFBdUIsU0FBUyxZQUFZLFVBQVUsV0FBVyxLQUFLLElBQUk7YUFDMUUsVUFBVSxZQUFZO2NBQ3BCLE1BQU0sS0FBSyxNQUFNLFFBQVE7ZUFDdkIsT0FBTztlQUNQLFNBQVMsbURBQW1ELEtBQUssT0FBTztlQUN4RSxNQUFNO2VBQ04sYUFBYTtjQUNmLENBQUM7Y0FDRCxJQUFJLElBQUk7ZUFDTix1QkFBdUIsTUFBTSxLQUFLLEVBQUU7Y0FDdEM7YUFDRjthQUNBLFVBQVUsTUFBTSxTQUFTO1lBQzFCOzs7OztXQUNFOzs7OztVQUNGOzs7OztpQkFDRjtXQS9LRSxLQUFLOzs7O2VBK0tQO09BRVQsQ0FBQztNQUNFOzs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsS0FBRCxFQUFLLFdBQVUsbUNBQW9DOzs7O2lCQUNuRCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFtQztRQUE0Qjs7OztrQkFDN0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTBDO1FBRXBEOzs7O2dCQUNBOzs7OztlQUNGOzs7OztjQUVKOzs7Ozs7SUFFRDs7Ozs7O0dBR0wsYUFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBb0YsZUFBZSxhQUFhLEtBQUs7SUFBSTs7OztjQUV4SSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLHlCQUEwQjs7OztpQkFBQywwQkFFL0M7Ozs7O2dCQUNKLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsS0FBSztPQUNqQyxXQUFVO2lCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O01BQ2xCOzs7O2NBQ0w7Ozs7O2VBRUwsd0JBQUMsUUFBRDtNQUFNLFVBQVU7TUFBc0IsV0FBVTtnQkFBaEQ7T0FDRSx3QkFBQyxPQUFEO1FBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTRFO1FBRXRGOzs7OztRQUNQLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxPQUFPO1NBQ1AsV0FBVyxNQUFNLGtCQUFrQixFQUFFLE9BQU8sS0FBSztTQUNqRCxhQUFZO1NBQ1osV0FBVyxrSUFDVCwwQkFDSSwyREFDQTtRQUVQOzs7OztRQUNBLDJCQUNDLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiLENBQ0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUsY0FBZTs7OzttQkFBQywyREFDeEM7Ozs7OztPQUVGOzs7OztPQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEU7T0FFdEY7Ozs7aUJBQ1Asd0JBQUMsWUFBRDtRQUNFLE9BQU87UUFDUCxXQUFXLE1BQU0sdUJBQXVCLEVBQUUsT0FBTyxLQUFLO1FBQ3RELGFBQVk7UUFDWixNQUFNO1FBQ04sV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsYUFBYSxLQUFLO1NBQ2pDLFdBQVU7bUJBQ1g7UUFFTzs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFVBQVUsQ0FBQztTQUNYLFdBQVU7bUJBQ1g7UUFFTzs7OztnQkFDTDs7Ozs7O01BRUQ7Ozs7O2FBQ0g7Ozs7O1lBQ0Y7Ozs7OztHQUlOLHFCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFvRixlQUFlLHFCQUFxQixLQUFLO0lBQUk7Ozs7Y0FFaEosd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7aUJBQUMsOEJBQ3hDOzs7OztnQkFDSix3QkFBQyxVQUFEO09BQ0UsZUFBZSxxQkFBcUIsS0FBSztPQUN6QyxXQUFVO2lCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O01BQ2xCOzs7O2NBQ0w7Ozs7O2VBRUwsd0JBQUMsUUFBRDtNQUFNLFVBQVU7TUFBc0IsV0FBVTtnQkFBaEQ7T0FHRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRFO09BRXRGOzs7O2lCQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaO1NBQ0M7VUFBRSxJQUFJO1VBQVcsT0FBTztTQUFvQjtTQUM1QztVQUFFLElBQUk7VUFBb0IsT0FBTztTQUFxQjtTQUN0RDtVQUFFLElBQUk7VUFBYSxPQUFPO1NBQWU7U0FDekM7VUFBRSxJQUFJO1VBQWlCLE9BQU87U0FBbUI7U0FDakQ7VUFBRSxJQUFJO1VBQVksT0FBTztTQUFtQjtTQUM1QztVQUFFLElBQUk7VUFBTyxPQUFPO1NBQW1CO1NBQ3ZDO1VBQUUsSUFBSTtVQUFxQixPQUFPO1NBQWdCO1FBQ3BELENBQUMsQ0FBQyxLQUFLLE1BQ0wsd0JBQUMsVUFBRDtTQUVFLE1BQUs7U0FDTCxlQUFlLGdCQUFnQixFQUFFLEVBQUU7U0FDbkMsV0FBVyw2RUFDVCxpQkFBaUIsRUFBRSxLQUNmLDBDQUNBO21CQUdMLEVBQUU7UUFDRyxHQVZELEVBQUU7Ozs7ZUFVRCxDQUNUO09BQ0U7Ozs7ZUFDRjs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTRFO1FBRXRGOzs7OztRQUNQLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxPQUFPO1NBQ1AsV0FBVyxNQUFNLGtCQUFrQixFQUFFLE9BQU8sS0FBSztTQUNqRCxhQUFhLE9BQU8saUJBQWlCLFlBQVksK0JBQStCLGlCQUFpQixrQkFBa0IsNkJBQTZCLGlCQUFpQixrQkFBa0IsK0JBQStCO1NBQ2xOLFdBQVcsZ0lBQ1QsMEJBQ0ksMkRBQ0E7UUFFUDs7Ozs7UUFDQSwyQkFDQyx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLGNBQWU7Ozs7bUJBQUMseURBQ3hDOzs7Ozs7T0FFRjs7Ozs7T0FHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRFO09BRXRGOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1FBQzVDLGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRFO09BRXRGOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7UUFDaEQsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUtKLGlCQUFpQixhQUNoQix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRFO09BRXRGOzs7O2lCQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVyxNQUFNLFlBQVksU0FBUyxFQUFFLE9BQU8sT0FBTyxFQUFFLEtBQUssQ0FBQztTQUM5RCxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2tCQUNELHdCQUFDLFVBQUQ7U0FDRSxPQUFPO1NBQ1AsV0FBVyxNQUFNO1VBQ2YsTUFBTSxNQUFNLFNBQVMsRUFBRSxPQUFPLE9BQU8sRUFBRTtVQUN2QyxJQUFJLEtBQUssWUFBWSxHQUFHO1NBQzFCO1NBQ0EsV0FBVTttQkFOWjtVQVFFLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFHO1VBQXNCOzs7OztVQUN2Qyx3QkFBQyxVQUFEO1dBQVEsT0FBTztxQkFBSTtVQUFnQjs7Ozs7VUFDbkMsd0JBQUMsVUFBRDtXQUFRLE9BQU87cUJBQUk7VUFBZ0I7Ozs7O1VBQ25DLHdCQUFDLFVBQUQ7V0FBUSxPQUFPO3FCQUFJO1VBQWdCOzs7OztVQUNuQyx3QkFBQyxVQUFEO1dBQVEsT0FBTztxQkFBSTtVQUFnQjs7Ozs7VUFDbkMsd0JBQUMsVUFBRDtXQUFRLE9BQU87cUJBQUk7VUFBZ0I7Ozs7O1VBQ25DLHdCQUFDLFVBQUQ7V0FBUSxPQUFPO3FCQUFJO1VBQWdCOzs7OztVQUNuQyx3QkFBQyxVQUFEO1dBQVEsT0FBTztxQkFBSTtVQUFnQjs7Ozs7VUFDbkMsd0JBQUMsVUFBRDtXQUFRLE9BQU87cUJBQUk7VUFBZ0I7Ozs7O1VBQ25DLHdCQUFDLFVBQUQ7V0FBUSxPQUFPO3FCQUFJO1VBQWdCOzs7OztTQUM3Qjs7Ozs7Z0JBQ0w7Ozs7O2VBQ0Y7Ozs7O09BSU4saUJBQWlCLG1CQUNoQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUFtQjs7OzttQkFDOUcsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQVUsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQWMsV0FBVTtTQUEwRzs7OztpQkFDN047Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUFZOzs7O21CQUN2Ryx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLE9BQU87VUFBWSxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBUyxXQUFVO1NBQWdHOzs7O2lCQUNsTjs7OztpQkFDRjs7Ozs7a0JBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQXlCOzs7O21CQUNwSCx3QkFBQyxVQUFEO1VBQVEsT0FBTztVQUFXLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1VBQUcsV0FBVTtvQkFBbkY7V0FDRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBUztXQUFxQzs7Ozs7V0FDNUQsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQU87V0FBcUM7Ozs7O1dBQzFELHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFXO1dBQXlCOzs7OztXQUNsRCx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBUTtXQUFpQzs7Ozs7VUFDakQ7Ozs7O2lCQUNMOzs7O21CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FBZTs7OzttQkFDMUcsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQWUsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBMEIsV0FBVTtTQUFnRzs7OztpQkFDek87Ozs7aUJBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FJTixpQkFBaUIsZUFDaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FBb0I7Ozs7bUJBQy9HLHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU8sT0FBTztVQUFRLFdBQVcsTUFBTSxVQUFVLEVBQUUsT0FBTyxLQUFLO1VBQUcsYUFBWTtVQUFjLFdBQVU7U0FBMEc7Ozs7aUJBQ3pOOzs7O21CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FBa0I7Ozs7bUJBQzdHLHdCQUFDLFVBQUQ7VUFBUSxPQUFPO1VBQWdCLFdBQVcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7VUFBRyxXQUFVO29CQUE3RjtXQUNFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFTO1dBQXVCOzs7OztXQUM5Qyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBTTtXQUFtQjs7Ozs7V0FDdkMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVc7V0FBZ0I7Ozs7O1VBQ25DOzs7OztpQkFDTDs7OztpQkFDRjs7Ozs7a0JBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQXlCOzs7O21CQUNwSCx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLE9BQU87VUFBWSxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBa0IsV0FBVTtTQUEwRzs7OztpQkFDck87Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUEyQjs7OzttQkFDdEgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQWEsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQWEsV0FBVTtTQUEwRzs7OztpQkFDbE87Ozs7aUJBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FJTixpQkFBaUIsbUJBQ2hCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQXNCOzs7O21CQUNqSCx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLE9BQU87VUFBbUIsV0FBVyxNQUFNLHFCQUFxQixFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBWSxXQUFVO1NBQTBHOzs7O2lCQUM3Tzs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTBFO1NBQXlCOzs7O21CQUNwSCx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLE9BQU87VUFBZSxXQUFXLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxLQUFLO1VBQUcsYUFBWTtVQUFZLFdBQVU7U0FBeUg7Ozs7aUJBQ3BQOzs7O2lCQUNGOzs7OztrQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTBFO1FBQWdDOzs7O2tCQUMzSCx3QkFBQyxTQUFEO1NBQU8sTUFBSztTQUFPLE9BQU87U0FBVyxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztTQUFHLGFBQVk7U0FBK0IsV0FBVTtRQUFnRzs7OztnQkFDdE87Ozs7Z0JBQ0Y7Ozs7OztPQUlOLGlCQUFpQix1QkFDaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FBNkI7Ozs7bUJBQ3hILHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU8sT0FBTztVQUFXLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1VBQUcsYUFBWTtVQUFlLFdBQVU7U0FBMEc7Ozs7aUJBQ2hPOzs7O21CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FBd0I7Ozs7bUJBQ25ILHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU8sT0FBTztVQUFrQixXQUFXLE1BQU0sb0JBQW9CLEVBQUUsT0FBTyxLQUFLO1VBQUcsYUFBWTtVQUFjLFdBQVU7U0FBMEc7Ozs7aUJBQzdPOzs7O2lCQUNGOzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEU7U0FBb0I7Ozs7bUJBQy9HLHdCQUFDLFVBQUQ7VUFBUSxPQUFPO1VBQVcsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7VUFBRyxXQUFVO29CQUFuRixDQUNFLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFhO1VBQWdDOzs7O29CQUMzRCx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBTztVQUFZOzs7O2tCQUMzQjs7Ozs7aUJBQ0w7Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUF3Qjs7OzttQkFDbkgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQWMsV0FBVyxNQUFNLGdCQUFnQixFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBb0IsV0FBVTtTQUEwRzs7OztpQkFDM087Ozs7aUJBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FJTixpQkFBaUIsc0JBQ2hCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBRUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTBFO1VBRXBGOzs7O29CQUNQLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsVUFBRDtZQUNFLE9BQU8sd0JBQXdCLFNBQVMsaUJBQWlCLElBQUksb0JBQXFCLG9CQUFvQixXQUFXO1lBQ2pILFdBQVcsTUFBTTthQUNmLElBQUksRUFBRSxPQUFPLFVBQVUsVUFBVTtjQUMvQixxQkFBcUIsRUFBRSxPQUFPLEtBQUs7YUFDckM7WUFDRjtZQUNBLFdBQVU7c0JBUFo7YUFTRSx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBRzthQUE2Qjs7Ozs7YUFDOUMsd0JBQUMsWUFBRDtjQUFVLE9BQU07d0JBQ2IseUJBQXlCLEtBQUksTUFDNUIsd0JBQUMsVUFBRDtlQUFnQixPQUFPO3lCQUFJO2NBQVUsR0FBeEI7Ozs7cUJBQXdCLENBQ3RDO2FBQ087Ozs7O2FBQ1Ysd0JBQUMsWUFBRDtjQUFVLE9BQU07d0JBQ2IseUJBQXlCLEtBQUksTUFDNUIsd0JBQUMsVUFBRDtlQUFnQixPQUFPO3lCQUFJO2NBQVUsR0FBeEI7Ozs7cUJBQXdCLENBQ3RDO2FBQ087Ozs7O2FBQ1Ysd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQVM7YUFBdUI7Ozs7O1lBQ3hDOzs7OztxQkFDUix3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0scUJBQXFCLEVBQUUsT0FBTyxLQUFLO1lBQ3BELGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7bUJBQ0U7Ozs7O2tCQUNGOzs7O29CQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBMEU7VUFFcEY7Ozs7b0JBQ1Asd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPO1dBQ1AsV0FBVyxNQUFNLHVCQUF1QixFQUFFLE9BQU8sS0FBSztXQUN0RCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7O2tCQUNFOzs7O2tCQUNGOzs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFxRTtVQUUvRTs7OztvQkFDUCx3QkFBQyxVQUFEO1dBQ0UsT0FBTztXQUNQLFdBQVcsTUFBTSwwQkFBMEIsRUFBRSxPQUFPLEtBQUs7V0FDekQsV0FBVTtxQkFIWjtZQUtFLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFrQztZQUEwQzs7Ozs7WUFDMUYsd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQXdCO1lBQXVFOzs7OztZQUM3Ryx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBMkI7WUFBMkU7Ozs7O1dBQzlHOzs7OztrQkFDTDs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHdCQUF5Qjs7Ozt1QkFBQyx3Q0FDdkM7Ozs7O3NCQUNOLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUFqQixDQUNFLHdCQUFDLFNBQUQ7Y0FDRSxNQUFLO2NBQ0wsU0FBUztjQUNULFdBQVcsTUFBTSw2QkFBNkIsRUFBRSxPQUFPLE9BQU87Y0FDOUQsV0FBVTthQUNYOzs7O3VCQUNELHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUE0QjthQUFtQjs7OztxQkFDMUQ7Ozs7O29CQUNKOzs7Ozs7V0FFTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBMkQ7WUFBNEI7Ozs7c0JBQ3hHLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsT0FBTzthQUNQLFdBQVcsTUFBTSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7YUFDcEQsYUFBWTthQUNaLFdBQVU7WUFDWDs7OztvQkFDRTs7OztzQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDthQUFPLFdBQVU7dUJBQTJEO1lBQXdCOzs7O3NCQUNwRyx3QkFBQyxVQUFEO2FBQ0UsT0FBTzthQUNQLFdBQVcsTUFBTSwyQkFBMkIsRUFBRSxPQUFPLEtBQUs7YUFDMUQsV0FBVTt1QkFIWjtjQUtFLHdCQUFDLFVBQUQ7ZUFBUSxPQUFNO3lCQUFjO2NBQW1COzs7OztjQUMvQyx3QkFBQyxVQUFEO2VBQVEsT0FBTTt5QkFBUTtjQUFhOzs7OztjQUNuQyx3QkFBQyxVQUFEO2VBQVEsT0FBTTt5QkFBUTtjQUFtQzs7Ozs7YUFDbkQ7Ozs7O29CQUNMOzs7O29CQUNGOzs7Ozs7V0FFTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO2NBQU8sV0FBVTt3QkFBMkQ7YUFBd0I7Ozs7dUJBQ3BHLHdCQUFDLFNBQUQ7Y0FDRSxNQUFLO2NBQ0wsT0FBTztjQUNQLFdBQVcsTUFBTSw0QkFBNEIsRUFBRSxPQUFPLEtBQUs7Y0FDM0QsYUFBWTtjQUNaLFdBQVU7YUFDWDs7OztxQkFDRTs7Ozs7YUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtjQUFPLFdBQVU7d0JBQTJEO2FBQWlCOzs7O3VCQUM3Rix3QkFBQyxTQUFEO2NBQ0UsTUFBSztjQUNMLE9BQU87Y0FDUCxXQUFXLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxLQUFLO2NBQ2hELGFBQVk7Y0FDWixXQUFVO2FBQ1g7Ozs7cUJBQ0U7Ozs7O2FBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7Y0FBTyxXQUFVO3dCQUEyRDthQUE2Qjs7Ozt1QkFDekcsd0JBQUMsU0FBRDtjQUNFLE1BQUs7Y0FDTCxPQUFPO2NBQ1AsV0FBVyxNQUFNLHdCQUF3QixFQUFFLE9BQU8sS0FBSztjQUN2RCxhQUFZO2NBQ1osV0FBVTthQUNYOzs7O3FCQUNFOzs7OztZQUNGOzs7Ozs7VUFDRjs7Ozs7O1FBQ0Y7Ozs7OztPQUlOLGlCQUFpQixTQUNoQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUEwQjs7OzttQkFDckgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQW1CLFdBQVcsTUFBTSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQWEsV0FBVTtTQUEwRzs7OztpQkFDOU87Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUF3Qjs7OzttQkFDbkgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQVksV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQVksV0FBVTtTQUEwRzs7OztpQkFDL047Ozs7aUJBQ0Y7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUF3Qjs7OzttQkFDbkgsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBTyxPQUFPO1VBQXFCLFdBQVcsTUFBTSx1QkFBdUIsRUFBRSxPQUFPLEtBQUs7VUFBRyxhQUFZO1VBQWUsV0FBVTtTQUEwRzs7OztpQkFDcFA7Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwRTtTQUFnQzs7OzttQkFDM0gsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBUyxLQUFJO1VBQUksS0FBSTtVQUFLLE9BQU87VUFBa0IsV0FBVyxNQUFNLG9CQUFvQixFQUFFLE9BQU8sS0FBSztVQUFHLGFBQVk7VUFBSSxXQUFVO1NBQTBHOzs7O2lCQUN0UDs7OztpQkFDRjs7Ozs7Z0JBQ0Y7Ozs7OztPQUlOLGlCQUFpQixVQUNoQix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRFO09BRXRGOzs7O2lCQUNQLHdCQUFDLFlBQUQ7UUFBVSxPQUFPO1FBQWlCLFdBQVcsTUFBTSxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7UUFBRyxNQUFNO1FBQUcsYUFBWTtRQUFtQyxXQUFVO09BQThIOzs7O2VBQ3BSOzs7OztPQUlQLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEU7T0FFdEY7Ozs7aUJBQ1Asd0JBQUMsWUFBRDtRQUNFLE9BQU87UUFDUCxXQUFXLE1BQU0sMEJBQTBCLEVBQUUsT0FBTyxLQUFLO1FBQ3pELE1BQU07UUFDTixhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHlCQUEwQjs7OztrQkFBQyxtQ0FFeEM7Ozs7O2lCQUVOLGFBQ0Msd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssS0FBSztTQUFZLEtBQUk7U0FBZSxXQUFVO1FBQThCOzs7O2tCQUNqRix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWU7VUFDYixZQUFZLElBQUk7VUFDaEIsSUFBSSxZQUFZLElBQUksZ0JBQWdCLFVBQVU7VUFDOUMsY0FBYyxJQUFJO1NBQ3BCO1NBQ0EsV0FBVTttQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztRQUNsQjs7OztnQkFDTDs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSw4QkFBK0I7Ozs7b0JBQ2pELHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFiLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQVk7V0FBZ0I7Ozs7cUJBQUMsVUFDNUM7Ozs7O2tCQUNBOzs7OzttQkFDTCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLFFBQU87VUFDUCxTQUFRO1VBQ1IsVUFBVTtVQUNWLFdBQVU7U0FDWDs7OztpQkFDSTs7Ozs7O09BQ0o7Ozs7ZUFFSjs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxxQkFBcUIsS0FBSztTQUN6QyxXQUFVO21CQUNYO1FBRU87Ozs7a0JBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxVQUFVLENBQUM7U0FDWCxXQUFVO21CQUNYO1FBRU87Ozs7Z0JBQ0w7Ozs7OztNQUVEOzs7OzthQUNIOzs7OztZQUNGOzs7Ozs7R0FJTix3QkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUseUJBQTBCOzs7O2lCQUFDLGlCQUM3Qzs7Ozs7Z0JBQ0osd0JBQUMsVUFBRDtPQUNFLGVBQWUsd0JBQXdCLEtBQUs7T0FDNUMsV0FBVTtpQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztNQUNsQjs7OztjQUNMOzs7OztlQUVMLHdCQUFDLFFBQUQ7TUFBTSxVQUFVO01BQTJCLFdBQVU7Z0JBQXJEO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUEwQztPQUF1Qjs7OztpQkFDbEYsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7UUFDN0M7UUFDQSxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBMEM7UUFBVTs7OztrQkFDckUsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVyxNQUFNLFdBQVcsRUFBRSxPQUFPLEtBQUs7U0FDMUM7U0FDQSxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUEwQztRQUF1Qjs7OztrQkFDbEYsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVyxNQUFNLHVCQUF1QixFQUFFLE9BQU8sS0FBSztTQUN0RDtTQUNBLFdBQVU7UUFDWDs7OztnQkFDRTs7OztnQkFDRjs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBOEQ7UUFBcUI7Ozs7a0JBQ2pHLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBd0M7V0FBYTs7OztxQkFDdEUsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLHNCQUFzQixFQUFFLE9BQU8sS0FBSztZQUNyRCxXQUFVO1dBQ1g7Ozs7bUJBQ0U7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQXdDO1dBQWU7Ozs7cUJBQ3hFLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVcsTUFBTSx3QkFBd0IsRUFBRSxPQUFPLEtBQUs7WUFDdkQsV0FBVTtXQUNYOzs7O21CQUNFOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUF3QztXQUFZOzs7O3FCQUNyRSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0scUJBQXFCLEVBQUUsT0FBTyxLQUFLO1lBQ3BELFdBQVU7V0FDWDs7OzttQkFDRTs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUE4RDtRQUFzQjs7OztrQkFDbEcsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUF3QztXQUFhOzs7O3FCQUN0RSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU0sc0JBQXNCLEVBQUUsT0FBTyxLQUFLO1lBQ3JELFdBQVU7V0FDWDs7OzttQkFDRTs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBd0M7V0FBZTs7OztxQkFDeEUsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLHdCQUF3QixFQUFFLE9BQU8sS0FBSztZQUN2RCxXQUFVO1dBQ1g7Ozs7bUJBQ0U7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQXdDO1dBQVk7Ozs7cUJBQ3JFLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVcsTUFBTSxxQkFBcUIsRUFBRSxPQUFPLEtBQUs7WUFDcEQsV0FBVTtXQUNYOzs7O21CQUNFOzs7Ozs7U0FDRjs7Ozs7Z0JBQ0Y7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLHdCQUF3QixLQUFLO1NBQzVDLFdBQVU7bUJBQ1g7UUFFTzs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7bUJBQ1g7UUFFTzs7OztnQkFDTDs7Ozs7O01BQ0Q7Ozs7O2FBQ0g7Ozs7OztHQUNGOzs7OztHQUlQLHdCQUFDLHVCQUFEO0lBQ0UsUUFBUTtJQUNSLGVBQWUsb0JBQW9CLEtBQUs7SUFDeEMsV0FBVztJQUNYLGFBQWEsU0FBUztJQUNYO0dBQ1o7Ozs7O0VBRUU7Ozs7OztBQUVUOzs7Ozs7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJFbXByZXNhVmlldy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgdXNlU3RvcmUsIHsgZm9ybWF0RWxlbWVudFRpdGxlV2l0aElkIH0gZnJvbSAnLi4vc3RvcmUvdXNlU3RvcmUnO1xuaW1wb3J0IHsgdXNlQ29uZmlybSB9IGZyb20gJy4uL2NvbnRleHQvQ29uZmlybUNvbnRleHQnO1xuaW1wb3J0IE1vZGFsRGlhZ3JhbWFVbmlmaWxhciBmcm9tICcuLi9jb21wb25lbnRzL01vZGFsRGlhZ3JhbWFVbmlmaWxhcic7XG5pbXBvcnQgQXZhbmNlUHJvZ3Jlc3NCYXIgZnJvbSAnLi4vY29tcG9uZW50cy9BdmFuY2VQcm9ncmVzc0Jhcic7XG5pbXBvcnQgRWxlbWVudG9DYXJkQWN0aW9ucyBmcm9tICcuLi9jb21wb25lbnRzL0VsZW1lbnRvQ2FyZEFjdGlvbnMnO1xuaW1wb3J0IHsgXG4gIFRFTlNJT05FU19DT1ZFTklOXzE1OV9CVCwgXG4gIFRFTlNJT05FU19DT1ZFTklOXzE1OV9NVCwgXG4gIFRFTlNJT05FU19DT1ZFTklOX1RPREFTIFxufSBmcm9tICcuLi91dGlscy9jb25zdGFudHMnO1xuaW1wb3J0IHsgXG4gIEFycm93TGVmdCwgXG4gIFBsdXMsIFxuICBTZWFyY2gsIFxuICBBbGVydFRyaWFuZ2xlLFxuICBGb2xkZXJPcGVuLFxuICBYLFxuICBCdWlsZGluZyxcbiAgTGF5ZXJzLFxuICBaYXAsXG4gIFRyYXNoMixcbiAgQ2FtZXJhLFxuICBDYWxlbmRhcixcbiAgVXNlcixcbiAgQ3B1LFxuICBTaGllbGRBbGVydCxcbiAgUmVmcmVzaEN3LFxuICBDaGVja1NxdWFyZSxcbiAgRGF0YWJhc2UsXG4gIEdhdWdlLFxuICBFZGl0M1xufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG4vLyBDb21wb25lbnRlIHBhcmEgcmVuZGVyaXphciBCbG9icyBkZSBmb3JtYSBzZWd1cmEgZXZpdGFuZG8gZnVnYXMgZGUgbWVtb3JpYVxuY29uc3QgU2FmZUltYWdlID0gKHsgYmxvYiwgc3JjLCBhbHQsIGNsYXNzTmFtZSB9KSA9PiB7XG4gIGNvbnN0IFtvYmplY3RVcmwsIHNldE9iamVjdFVybF0gPSB1c2VTdGF0ZShudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChibG9iKSB7XG4gICAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgICAgc2V0T2JqZWN0VXJsKHVybCk7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRPYmplY3RVcmwobnVsbCk7XG4gICAgfVxuICB9LCBbYmxvYl0pO1xuXG4gIGNvbnN0IGZpbmFsU3JjID0gb2JqZWN0VXJsIHx8IHNyYztcbiAgaWYgKCFmaW5hbFNyYykgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIDxpbWcgc3JjPXtmaW5hbFNyY30gYWx0PXthbHR9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSAvPjtcbn07XG5cbmV4cG9ydCBjb25zdCBFbXByZXNhVmlldyA9ICgpID0+IHtcbiAgY29uc3QgeyBjb21wYW55SWQgfSA9IHVzZVBhcmFtcygpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIFxuICBjb25zdCB7IFxuICAgIHVzZXIsXG4gICAgY29tcGFuaWVzLCBcbiAgICBhZGRQcm95ZWN0bywgXG4gICAgZGVsZXRlUHJveWVjdG8sXG4gICAgYWRkRWxlbWVudG9VbmlmaWxhcixcbiAgICBkZWxldGVFbGVtZW50b1VuaWZpbGFyLFxuICAgIHVwZGF0ZUVtcHJlc2EsXG4gICAgc2hvd1RvYXN0XG4gIH0gPSB1c2VTdG9yZSgpO1xuICBcbiAgY29uc3QgY29tcGFueSA9IGNvbXBhbmllcy5maW5kKChjKSA9PiBjLmlkID09PSBjb21wYW55SWQpO1xuICBjb25zdCB7IGNvbmZpcm0sIGFsZXJ0OiBjdXN0b21BbGVydCB9ID0gdXNlQ29uZmlybSgpO1xuICBcbiAgLy8gRXN0YWRvcyBwYXJhIEVkaWNpw7NuIGRlIEVtcHJlc2FcbiAgY29uc3QgW3Nob3dFZGl0RW1wcmVzYU1vZGFsLCBzZXRTaG93RWRpdEVtcHJlc2FNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlZGl0Tm9tYnJlLCBzZXRFZGl0Tm9tYnJlXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2VkaXRSaWYsIHNldEVkaXRSaWZdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZWRpdERpcmVjY2lvbkZpc2NhbCwgc2V0RWRpdERpcmVjY2lvbkZpc2NhbF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtlZGl0R2VyZW50ZTFOb21icmUsIHNldEVkaXRHZXJlbnRlMU5vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtlZGl0R2VyZW50ZTFUZWxlZm9ubywgc2V0RWRpdEdlcmVudGUxVGVsZWZvbm9dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZWRpdEdlcmVudGUxRW1haWwsIHNldEVkaXRHZXJlbnRlMUVtYWlsXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2VkaXRHZXJlbnRlMk5vbWJyZSwgc2V0RWRpdEdlcmVudGUyTm9tYnJlXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2VkaXRHZXJlbnRlMlRlbGVmb25vLCBzZXRFZGl0R2VyZW50ZTJUZWxlZm9ub10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtlZGl0R2VyZW50ZTJFbWFpbCwgc2V0RWRpdEdlcmVudGUyRW1haWxdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZUVtcHJlc2FTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBhd2FpdCB1cGRhdGVFbXByZXNhKGNvbXBhbnlJZCwge1xuICAgICAgbm9tYnJlOiBlZGl0Tm9tYnJlLFxuICAgICAgcmlmOiBlZGl0UmlmLFxuICAgICAgZGlyZWNjaW9uRmlzY2FsOiBlZGl0RGlyZWNjaW9uRmlzY2FsLFxuICAgICAgZ2VyZW50ZTFOb21icmU6IGVkaXRHZXJlbnRlMU5vbWJyZSB8fCBudWxsLFxuICAgICAgZ2VyZW50ZTFUZWxlZm9ubzogZWRpdEdlcmVudGUxVGVsZWZvbm8gfHwgbnVsbCxcbiAgICAgIGdlcmVudGUxRW1haWw6IGVkaXRHZXJlbnRlMUVtYWlsIHx8IG51bGwsXG4gICAgICBnZXJlbnRlMk5vbWJyZTogZWRpdEdlcmVudGUyTm9tYnJlIHx8IG51bGwsXG4gICAgICBnZXJlbnRlMlRlbGVmb25vOiBlZGl0R2VyZW50ZTJUZWxlZm9ubyB8fCBudWxsLFxuICAgICAgZ2VyZW50ZTJFbWFpbDogZWRpdEdlcmVudGUyRW1haWwgfHwgbnVsbFxuICAgIH0pO1xuICAgIHNob3dUb2FzdChcIkRhdG9zIGRlIGxhIGVtcHJlc2EgYWN0dWFsaXphZG9zIGNvcnJlY3RhbWVudGUuXCIsIFwic3VjY2Vzc1wiKTtcbiAgICBzZXRTaG93RWRpdEVtcHJlc2FNb2RhbChmYWxzZSk7XG4gIH07XG5cbiAgLy8gTW9kYWxlcyB5IGLDunNxdWVkYVxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpOyAvLyBNb2RhbCBQcm95ZWN0b1xuICBjb25zdCBbc2hvd0VsZW1lbnRvTW9kYWwsIHNldFNob3dFbGVtZW50b01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTsgLy8gTW9kYWwgRWxlbWVudG9cbiAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gRXN0YWRvcyBkZSBzZWxlY2Npw7NuIG3Dumx0aXBsZVxuICBjb25zdCBbaXNNdWx0aVNlbGVjdE1vZGUsIHNldElzTXVsdGlTZWxlY3RNb2RlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NlbGVjdGVkSWRzLCBzZXRTZWxlY3RlZElkc10gPSB1c2VTdGF0ZShuZXcgU2V0KCkpO1xuXG4gIC8vIExpbXBpYXIgc2VsZWNjacOzbiBjdWFuZG8gY2FtYmlhIGxhIGLDunNxdWVkYVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldFNlbGVjdGVkSWRzKG5ldyBTZXQoKSk7XG4gIH0sIFtzZWFyY2hRdWVyeV0pO1xuXG4gIGNvbnN0IGhhbmRsZVRvZ2dsZVNlbGVjdCA9IChpZCkgPT4ge1xuICAgIHNldFNlbGVjdGVkSWRzKChwcmV2KSA9PiB7XG4gICAgICBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2KTtcbiAgICAgIGlmIChuZXh0LmhhcyhpZCkpIHtcbiAgICAgICAgbmV4dC5kZWxldGUoaWQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmV4dC5hZGQoaWQpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG5leHQ7XG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2VsZWN0QWxsID0gKCkgPT4ge1xuICAgIGNvbnN0IGxpc3RUb1NlbGVjdCA9IHR5cGVvZiBmaWx0ZXJlZEVsZW1lbnRvc0dlbmVyYWxlcyAhPT0gJ3VuZGVmaW5lZCcgPyBmaWx0ZXJlZEVsZW1lbnRvc0dlbmVyYWxlcyA6IFtdO1xuICAgIGNvbnN0IGlkcyA9IGxpc3RUb1NlbGVjdC5tYXAoZSA9PiBlLmlkKTtcbiAgICBzZXRTZWxlY3RlZElkcyhuZXcgU2V0KGlkcykpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlc2VsZWN0QWxsID0gKCkgPT4ge1xuICAgIHNldFNlbGVjdGVkSWRzKG5ldyBTZXQoKSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlU2VsZWN0ZWQgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2VsZWN0ZWRDb3VudCA9IHNlbGVjdGVkSWRzLnNpemU7XG4gICAgaWYgKHNlbGVjdGVkQ291bnQgPT09IDApIHJldHVybjtcblxuICAgIGNvbnN0IG9rID0gYXdhaXQgY29uZmlybSh7XG4gICAgICB0aXRsZTogJ0VsaW1pbmFyIGVxdWlwb3Mgc2VsZWNjaW9uYWRvcycsXG4gICAgICBtZXNzYWdlOiBgwr9Fc3TDoXMgc2VndXJvIGRlIHF1ZSBkZXNlYXMgZWxpbWluYXIgbG9zICR7c2VsZWN0ZWRDb3VudH0gZXF1aXBvcyBzZWxlY2Npb25hZG9zP2AsXG4gICAgICB0eXBlOiAnZGFuZ2VyJyxcbiAgICAgIGNvbmZpcm1UZXh0OiAnRWxpbWluYXIgc2VsZWNjaW9uYWRvcydcbiAgICB9KTtcblxuICAgIGlmIChvaykge1xuICAgICAgc2VsZWN0ZWRJZHMuZm9yRWFjaCgoaWQpID0+IHtcbiAgICAgICAgZGVsZXRlRWxlbWVudG9VbmlmaWxhcihudWxsLCBpZCk7XG4gICAgICB9KTtcbiAgICAgIHNob3dUb2FzdD8uKGBTZSBlbGltaW5hcm9uICR7c2VsZWN0ZWRDb3VudH0gZXF1aXBvcyBjb3JyZWN0YW1lbnRlYCwgJ3N1Y2Nlc3MnKTtcbiAgICAgIHNldFNlbGVjdGVkSWRzKG5ldyBTZXQoKSk7XG4gICAgICBzZXRJc011bHRpU2VsZWN0TW9kZShmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVByb3llY3RvID0gYXN5bmMgKHByb3llY3RvSWQsIG5hbWUpID0+IHtcbiAgICBjb25zdCBvayA9IGF3YWl0IGNvbmZpcm0oe1xuICAgICAgdGl0bGU6ICdFbGltaW5hciBQcm95ZWN0bycsXG4gICAgICBtZXNzYWdlOiBgwr9Fc3TDoXMgc2VndXJvIGRlIHF1ZSBkZXNlYXMgZWxpbWluYXIgZWwgcHJveWVjdG8gXCIke25hbWV9XCI/IFNlIGVsaW1pbmFyw6FuIHRvZGFzIHN1cyBzdWJlc3RhY2lvbmVzLCB0YWJsZXJvcyB5IGVsZW1lbnRvcyB1bmlmaWxhcmVzIGVuIGNhc2NhZGEuYCxcbiAgICAgIHR5cGU6ICdkYW5nZXInLFxuICAgICAgY29uZmlybVRleHQ6ICdFbGltaW5hciBQcm95ZWN0bydcbiAgICB9KTtcblxuICAgIGlmIChvaykge1xuICAgICAgZGVsZXRlUHJveWVjdG8oY29tcGFueUlkLCBwcm95ZWN0b0lkKTtcbiAgICAgIHNob3dUb2FzdD8uKCdQcm95ZWN0byBlbGltaW5hZG8gY29ycmVjdGFtZW50ZScsICdzdWNjZXNzJyk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEZvcm0gc3RhdGVzIGRlIFByb3llY3Rvc1xuICBjb25zdCBbcHJveWVjdG9Ob21icmUsIHNldFByb3llY3RvTm9tYnJlXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3Byb3llY3RvRGVzY3JpcGNpb24sIHNldFByb3llY3RvRGVzY3JpcGNpb25dID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIEZvcm0gc3RhdGVzIGRlIEVsZW1lbnRvcyAoRnVlcmEgZGUgUHJveWVjdG9zKVxuICBjb25zdCBbdGlwb0VsZW1lbnRvLCBzZXRUaXBvRWxlbWVudG9dID0gdXNlU3RhdGUoJ1RBQkxFUk8nKTtcbiAgY29uc3QgW2VsZW1lbnRvTm9tYnJlLCBzZXRFbGVtZW50b05vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFt1YmljYWNpb24sIHNldFViaWNhY2lvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFthbGltZW50YWRvUG9yLCBzZXRBbGltZW50YWRvUG9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW29ic2VydmFjaW9uZXNHZW5lcmFsZXMsIHNldE9ic2VydmFjaW9uZXNHZW5lcmFsZXNdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZm90b0Jsb2IsIHNldEZvdG9CbG9iXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbcHJldmlld1VybCwgc2V0UHJldmlld1VybF0gPSB1c2VTdGF0ZShudWxsKTtcblxuICAvLyBDYW1wb3MgZGUgVGFibGVyb1xuICBjb25zdCBbbWF4UG9sZXMsIHNldE1heFBvbGVzXSA9IHVzZVN0YXRlKDI0KTtcblxuICAvLyBDYW1wb3MgZGUgVHJhbnNmb3JtYWRvclxuICBjb25zdCBba3ZhVHJhZm8sIHNldEt2YVRyYWZvXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW21hcmNhVHJhZm8sIHNldE1hcmNhVHJhZm9dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbdGlwb1RyYWZvLCBzZXRUaXBvVHJhZm9dID0gdXNlU3RhdGUoJ1BlZGVzdGFsJyk7XG4gIGNvbnN0IFtjb25leGlvblRyYWZvLCBzZXRDb25leGlvblRyYWZvXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3ZvbHRhamVQcmltYXJpbywgc2V0Vm9sdGFqZVByaW1hcmlvXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3ZvbHRhamVTZWN1bmRhcmlvLCBzZXRWb2x0YWplU2VjdW5kYXJpb10gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gQ2FtcG9zIGRlIEdlbmVyYWRvclxuICBjb25zdCBba3ZhR2VuLCBzZXRLdmFHZW5dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbY29tYnVzdGlibGVHZW4sIHNldENvbWJ1c3RpYmxlR2VuXSA9IHVzZVN0YXRlKCdESUVTRUwnKTtcbiAgY29uc3QgW3ZvbHRhamVHZW4sIHNldFZvbHRhamVHZW5dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcG90ZW5jaWFLd0dlbiwgc2V0UG90ZW5jaWFLd0dlbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFthbXBlcmFqZUdlbiwgc2V0QW1wZXJhamVHZW5dID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIENhbXBvcyBkZSBQdWVzdGEgYSBUaWVycmFcbiAgY29uc3QgW3Jlc2lzdGVuY2lhT2htaW9zLCBzZXRSZXNpc3RlbmNpYU9obWlvc10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjb3JyaWVudGVGdWdhLCBzZXRDb3JyaWVudGVGdWdhXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3RpcG9NYWxsYSwgc2V0VGlwb01hbGxhXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2NhYmxlQWNvbWV0aWRhVGllcnJhLCBzZXRDYWJsZUFjb21ldGlkYVRpZXJyYV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gQ2FtcG9zIGRlIFRyYW5zZmVyXG4gIGNvbnN0IFtjYXBhY2lkYWRBbXBlcmlvcywgc2V0Q2FwYWNpZGFkQW1wZXJpb3NdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbdGlwb1RyYW5zZmVyZW5jaWEsIHNldFRpcG9UcmFuc2ZlcmVuY2lhXSA9IHVzZVN0YXRlKCdBVVRPTUFUSUNBJyk7XG4gIGNvbnN0IFt0ZW5zaW9uT3BlcmF0aXZhLCBzZXRUZW5zaW9uT3BlcmF0aXZhXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBDYW1wb3MgZGUgQmFuY28gZGUgQ29uZGVuc2Fkb3Jlc1xuICBjb25zdCBba3ZhclRvdGFsLCBzZXRLdmFyVG90YWxdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGFzb3NDb25kZW5zYWRvciwgc2V0UGFzb3NDb25kZW5zYWRvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFt0aXBvQmFuY28sIHNldFRpcG9CYW5jb10gPSB1c2VTdGF0ZSgnQVVUT01BVElDTycpO1xuICBjb25zdCBbdGVuc2lvbkJhbmNvLCBzZXRUZW5zaW9uQmFuY29dID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIENhbXBvcyBkZSBQdW50byBkZSBTdW1pbmlzdHJvXG4gIGNvbnN0IFtzdW1pbmlzdHJvVGVuc2lvbiwgc2V0U3VtaW5pc3Ryb1RlbnNpb25dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc3VtaW5pc3Ryb0VtcHJlc2EsIHNldFN1bWluaXN0cm9FbXByZXNhXSA9IHVzZVN0YXRlKCdDT1JQT0VMRUMnKTtcbiAgY29uc3QgW3N1bWluaXN0cm9UaXBvQWNvbWV0aWRhLCBzZXRTdW1pbmlzdHJvVGlwb0Fjb21ldGlkYV0gPSB1c2VTdGF0ZSgnU3VidGVycsOhbmVhJyk7XG4gIGNvbnN0IFtzdW1pbmlzdHJvQ2FwYWNpZGFkLCBzZXRTdW1pbmlzdHJvQ2FwYWNpZGFkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3N1bWluaXN0cm9UaXBvTWVkaWNpb24sIHNldFN1bWluaXN0cm9UaXBvTWVkaWNpb25dID0gdXNlU3RhdGUoJ01lZGljacOzbiBEaXJlY3RhIChCYWphIFRlbnNpw7NuKScpO1xuICBjb25zdCBbc3VtaW5pc3Ryb0VubGFjZUNvcnBvZWxlYywgc2V0U3VtaW5pc3Ryb0VubGFjZUNvcnBvZWxlY10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW3N1bWluaXN0cm9OdW1lcm9Db250cmF0bywgc2V0U3VtaW5pc3Ryb051bWVyb0NvbnRyYXRvXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3N1bWluaXN0cm9OaWMsIHNldFN1bWluaXN0cm9OaWNdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc3VtaW5pc3Ryb1Bvc3RlVHJhZm8sIHNldFN1bWluaXN0cm9Qb3N0ZVRyYWZvXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBDYW1wb3MgZGUgQ0NNIEVsZW1lbnRvXG4gIGNvbnN0IFtjY21DYXBhY2lkYWRCYXJyYSwgc2V0Q2NtQ2FwYWNpZGFkQmFycmFdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbY2NtVGVuc2lvbiwgc2V0Q2NtVGVuc2lvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjY21CcmVha2VyUHJpbmNpcGFsLCBzZXRDY21CcmVha2VyUHJpbmNpcGFsXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2NjbU51bWVyb0dhdmV0YXMsIHNldENjbU51bWVyb0dhdmV0YXNdID0gdXNlU3RhdGUoOCk7XG5cbiAgLy8gQ2FtcG9zIGRlIE90cm9cbiAgY29uc3QgW2Rlc2NyaXBjaW9uT3Rybywgc2V0RGVzY3JpcGNpb25PdHJvXSA9IHVzZVN0YXRlKCcnKTtcblxuICBjb25zdCBbc2hvd0RpYWdyYW1Nb2RhbCwgc2V0U2hvd0RpYWdyYW1Nb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgY29tcGFueUVsZW1lbnRvcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmICghY29tcGFueSkgcmV0dXJuIFtdO1xuICAgIGNvbnN0IGxpc3QgPSBbXTtcbiAgICBpZiAoY29tcGFueS5lbGVtZW50b3NVbmlmaWxhcmVzKSB7XG4gICAgICBsaXN0LnB1c2goLi4uY29tcGFueS5lbGVtZW50b3NVbmlmaWxhcmVzKTtcbiAgICB9XG4gICAgaWYgKGNvbXBhbnkucHJveWVjdG9zKSB7XG4gICAgICBjb21wYW55LnByb3llY3Rvcy5mb3JFYWNoKChwKSA9PiB7XG4gICAgICAgIGNvbnN0IHBMaXN0ID0gcC5lbGVtZW50b3NVbmlmaWxhcmVzIHx8IHAudGFibGVyb3MgfHwgW107XG4gICAgICAgIGxpc3QucHVzaCguLi5wTGlzdCk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGxpc3Q7XG4gIH0sIFtjb21wYW55XSk7XG5cbiAgaWYgKCFjb21wYW55KSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTEwMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTYgdGV4dC1jZW50ZXIgc3BhY2UteS00IGZvbnQtc2Fuc1wiPlxuICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1hbWJlci01MDAgYW5pbWF0ZS1wdWxzZVwiIC8+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZFwiPkVtcHJlc2Egbm8gZW5jb250cmFkYTwvaDI+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy8nKX0gY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC14cyByb3VuZGVkLXhsIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctbWRcIj5cbiAgICAgICAgICBWb2x2ZXIgYWwgRGFzaGJvYXJkXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0IHByb3llY3RvcyA9IGNvbXBhbnkucHJveWVjdG9zIHx8IFtdO1xuICBjb25zdCBlbGVtZW50b3NHZW5lcmFsZXMgPSBjb21wYW55LmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgW107XG5cbiAgY29uc3QgZmlsdGVyZWRQcm9qZWN0cyA9IHByb3llY3Rvcy5maWx0ZXIoKHApID0+XG4gICAgcC5ub21icmUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgIChwLmRlc2NyaXBjaW9uICYmIHAuZGVzY3JpcGNpb24udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSlcbiAgKTtcblxuICBjb25zdCBmaWx0ZXJlZEVsZW1lbnRvc0dlbmVyYWxlcyA9IGVsZW1lbnRvc0dlbmVyYWxlcy5maWx0ZXIoKGl0ZW0pID0+XG4gICAgaXRlbS5ub21icmUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgIChpdGVtLnViaWNhY2lvbiAmJiBpdGVtLnViaWNhY2lvbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpKSB8fFxuICAgIGl0ZW0udGlwb0VsZW1lbnRvLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSlcbiAgKTtcblxuICBjb25zdCBub21icmVQcm95ZWN0b0R1cGxpY2FkbyA9IHByb3llY3Rvcy5zb21lKFxuICAgIChwKSA9PiBwLm5vbWJyZS50b0xvd2VyQ2FzZSgpLnRyaW0oKSA9PT0gcHJveWVjdG9Ob21icmUudG9Mb3dlckNhc2UoKS50cmltKClcbiAgKTtcbiAgY29uc3QgaXNQcm95ZWN0b1ZhbGlkID0gcHJveWVjdG9Ob21icmUudHJpbSgpICE9PSAnJyAmJiAhbm9tYnJlUHJveWVjdG9EdXBsaWNhZG87XG5cbiAgY29uc3Qgbm9tYnJlRWxlbWVudG9EdXBsaWNhZG8gPSBlbGVtZW50b3NHZW5lcmFsZXMuc29tZShcbiAgICAoZSkgPT4gZS5ub21icmUudG9Mb3dlckNhc2UoKS50cmltKCkgPT09IGVsZW1lbnRvTm9tYnJlLnRvTG93ZXJDYXNlKCkudHJpbSgpXG4gICk7XG4gIGNvbnN0IGlzRWxlbWVudG9WYWxpZCA9IGVsZW1lbnRvTm9tYnJlLnRyaW0oKSAhPT0gJycgJiYgIW5vbWJyZUVsZW1lbnRvRHVwbGljYWRvO1xuXG4gIGNvbnN0IGhhbmRsZUltYWdlQ2hhbmdlID0gKGUpID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXNbMF07XG4gICAgaWYgKCFmaWxlKSByZXR1cm47XG5cbiAgICBpZiAoZmlsZS5zaXplID4gMTAgKiAxMDI0ICogMTAyNCkge1xuICAgICAgY3VzdG9tQWxlcnQoXCJMYSBpbWFnZW4gZXMgZGVtYXNpYWRvIGdyYW5kZS4gUG9yIGZhdm9yIGVsaWphIHVuYSBkZSBtZW5vcyBkZSAxME1CLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRGb3RvQmxvYihmaWxlKTtcbiAgICBpZiAocHJldmlld1VybCkgVVJMLnJldm9rZU9iamVjdFVSTChwcmV2aWV3VXJsKTtcbiAgICBzZXRQcmV2aWV3VXJsKFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZVByb3llY3RvID0gKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFpc1Byb3llY3RvVmFsaWQpIHJldHVybjtcblxuICAgIGNvbnN0IHJlc3VsdCA9IGFkZFByb3llY3RvKFxuICAgICAgcHJveWVjdG9Ob21icmUudHJpbSgpLFxuICAgICAgcHJveWVjdG9EZXNjcmlwY2lvbi50cmltKCksXG4gICAgICBjb21wYW55SWRcbiAgICApO1xuXG4gICAgaWYgKHJlc3VsdC5zdWNjZXNzKSB7XG4gICAgICBzZXRQcm95ZWN0b05vbWJyZSgnJyk7XG4gICAgICBzZXRQcm95ZWN0b0Rlc2NyaXBjaW9uKCcnKTtcbiAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGN1c3RvbUFsZXJ0KHJlc3VsdC5lcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUVsZW1lbnRvID0gKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFpc0VsZW1lbnRvVmFsaWQpIHJldHVybjtcblxuICAgIGxldCBkYXRvc1RlY25pY29zID0ge307XG5cbiAgICBpZiAodGlwb0VsZW1lbnRvID09PSAnVEFCTEVSTycpIHtcbiAgICAgIGRhdG9zVGVjbmljb3MgPSB7XG4gICAgICAgIG1heFBvbGVzOiBwYXJzZUludChtYXhQb2xlcywgMTApLFxuICAgICAgICBiYXJyYXNQcmluY2lwYWxlczogeyBpYTogJzAnLCBpYjogJzAnLCBpYzogJzAnIH0sXG4gICAgICAgIGJyZWFrZXJQcmluY2lwYWw6IHsgbWFyY2E6ICcnLCB0aXBvOiAnJywgYW1wOiAnJyB9LFxuICAgICAgICB2b2x0YWplOiB7IHZhOiAnMjA4JywgdmI6ICcyMDUnLCB2YzogJzIwNScgfSxcbiAgICAgICAgYWNvbWV0aWRhOiAnJyxcbiAgICAgICAgY2lyY3VpdHM6IFtdLFxuICAgICAgICBuZXV0cm9MbGVnYWRhOiB7IGNhbGlicmU6ICcnLCBvYnNlcnZhY2lvbmVzOiAnJyB9LFxuICAgICAgICBwdWVzdGFUaWVycmE6IHsgY2FsaWJyZTogJycsIG9ic2VydmFjaW9uZXM6ICcnIH1cbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0aXBvRWxlbWVudG8gPT09ICdUUkFOU0ZPUk1BRE9SJykge1xuICAgICAgZGF0b3NUZWNuaWNvcyA9IHtcbiAgICAgICAgbWFyY2E6IG1hcmNhVHJhZm8gfHwgJycsXG4gICAgICAgIGZhc2VzOiAnMycsXG4gICAgICAgIHBvdGVuY2lhS3ZhOiBrdmFUcmFmbyB8fCAnJyxcbiAgICAgICAga3ZhOiBrdmFUcmFmbyB8fCAnJyxcbiAgICAgICAgdGlwb1RyYW5zZm9ybWFkb3I6IHRpcG9UcmFmbyB8fCAnUGVkZXN0YWwnLFxuICAgICAgICBjb25leGlvbjogY29uZXhpb25UcmFmbyB8fCAnJyxcbiAgICAgICAgdm9sdGFqZVByaW1hcmlvOiB2b2x0YWplUHJpbWFyaW8gfHwgJycsXG4gICAgICAgIHZvbHRhamVTZWN1bmRhcmlvOiB2b2x0YWplU2VjdW5kYXJpbyB8fCAnJyxcbiAgICAgICAgaW1wZWRhbmNpYVBjdDogJycsXG4gICAgICAgIGltcGVkYW5jaWFBbXA6ICcnLFxuICAgICAgICBpbXBlZGFuY2lhVGVtcDogJycsXG4gICAgICAgIHRlbnNpb25QcmltYXJpYTogdm9sdGFqZVByaW1hcmlvIHx8ICcnLFxuICAgICAgICBhbXBlcmlvc1ByaW1hcmlhOiAnJyxcbiAgICAgICAgdGVuc2lvblNlY3VuZGFyaWE6IHZvbHRhamVTZWN1bmRhcmlvIHx8ICcnLFxuICAgICAgICBhbXBlcmlvc1NlY3VuZGFyaWE6ICcnLFxuICAgICAgICBhaXNsYW1pZW50bzogJycsXG4gICAgICAgIGFjZWl0ZTogJycsXG4gICAgICAgIHNlY286ICcnLFxuICAgICAgICBhY29tZXRpZGFzOiB7XG4gICAgICAgICAgcHJpbWFyaWE6IHsgYWVyZWE6IGZhbHNlLCBzdWJ0ZXJyYW5lYTogZmFsc2UsIGNhbGlicmU6ICcnLCB0aXBvOiAnJywgdGVybWluYWw6ICcnLCBmdXNpYmxlOiAnJywgcGFyYXJyYXlvOiAnJywgb2JzZXJ2YWNpb25lczogJycgfSxcbiAgICAgICAgICBzZWN1bmRhcmlhOiB7IGFlcmVhOiBmYWxzZSwgc3VidGVycmFuZWE6IGZhbHNlLCBjYWxpYnJlOiAnJywgdGlwbzogJycsIHRlcm1pbmFsOiAnJywgZnVzaWJsZTogJycsIHBhcmFycmF5bzogJycsIG9ic2VydmFjaW9uZXM6ICcnIH0sXG4gICAgICAgICAgbmV1dHJvOiB7IGFlcmVhOiBmYWxzZSwgc3VidGVycmFuZWE6IGZhbHNlLCBjYWxpYnJlOiAnJywgdGlwbzogJycsIHRlcm1pbmFsOiAnJywgZnVzaWJsZTogJycsIHBhcmFycmF5bzogJycsIG9ic2VydmFjaW9uZXM6ICcnIH1cbiAgICAgICAgfSxcbiAgICAgICAgc3B0OiB7XG4gICAgICAgICAgYmFyaWxsYUNhbGlicmU6ICcnLFxuICAgICAgICAgIGJhcmlsbGFDYW50aWRhZDogJycsXG4gICAgICAgICAgYmFyaWxsYUNvbmZpZ3VyYWNpb246ICcnLFxuICAgICAgICAgIGNvbmR1Y3RvckNhbGlicmU6ICcnLFxuICAgICAgICAgIGNvbmR1Y3RvclRpcG9Tb2xkOiAnJyxcbiAgICAgICAgICByZXNpc3RlbmNpYTogJycsXG4gICAgICAgICAgZmVjaGFNZWRpY2lvbjogJydcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9IGVsc2UgaWYgKHRpcG9FbGVtZW50byA9PT0gJ0dFTkVSQURPUicpIHtcbiAgICAgIGRhdG9zVGVjbmljb3MgPSB7XG4gICAgICAgIGt2YToga3ZhR2VuLFxuICAgICAgICBjb21idXN0aWJsZTogY29tYnVzdGlibGVHZW4sXG4gICAgICAgIHZvbHRhamVHZW5lcmFjaW9uOiB2b2x0YWplR2VuLFxuICAgICAgICBwb3RlbmNpYUt3OiBwb3RlbmNpYUt3R2VuLFxuICAgICAgICBhbXBlcmFqZTogYW1wZXJhamVHZW5cbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0aXBvRWxlbWVudG8gPT09ICdCQU5DT19DT05ERU5TQURPUicpIHtcbiAgICAgIGRhdG9zVGVjbmljb3MgPSB7XG4gICAgICAgIG1hcmNhOiAnJywgbW9kZWxvOiAnJywgYWxpbWVudGFkb3I6ICcnLCBjYWxpYnJlQ29uZHVjdG9yOiAnJywgZmFicmljYW50ZTogJycsIGFuaW9GYWJyaWNhY2lvbjogJycsXG4gICAgICAgIHRlbnNpb25Ob21pbmFsOiB0ZW5zaW9uQmFuY28gfHwgJzIwOCBWJywgdGVuc2lvblJlZ2lzdHJhZGE6IHRlbnNpb25CYW5jbyB8fCAnMjA4IFYnLCBmcmVjdWVuY2lhOiAnNjAgSHonLCBcbiAgICAgICAgcG90ZW5jaWFSZWFjdGl2YVRvdGFsOiBrdmFyVG90YWwgfHwgJzE1MCBrVkFSJyxcbiAgICAgICAgY29ycmllbnRlTm9taW5hbFRvdGFsOiAnJywgbnVtRmFzZXM6ICdUcmlmw6FzaWNvJywgY29uZXhpb246ICdFc3RyZWxsYScsIG5pdmVsQWlzbGFtaWVudG9CSUw6ICcnLFxuICAgICAgICB0aXBvQ29tcGVuc2FjaW9uOiB0aXBvQmFuY28gPT09ICdBVVRPTUFUSUNPJyA/ICdBdXRvbcOhdGljYSAoUGFzb3MpJyA6ICdGaWphJywgbnVtUGFzb3M6IHBhc29zQ29uZGVuc2Fkb3IgfHwgJzYnLCBzZWN1ZW5jaWFQYXNvc0t2YXI6ICcnLFxuICAgICAgICB0aXBvQ29ubXV0YWNpb246ICdDb250YWN0b3JlcyBkZWRpY2Fkb3MnLCBwb3RlbmNpYUluZGl2aWR1YWw6ICcnLCBjYXBhY2l0YW5jaWFNdWY6ICcnLFxuICAgICAgICB0ZW5zaW9uQ29uZGVuc2Fkb3I6ICcnLCB0ZWNub2xvZ2lhRGllbGVjdHJpY2E6ICdQb2xpcHJvcGlsZW5vIG1ldGFsaXphZG8nLFxuICAgICAgICByZXNpc3RlbmNpYURlc2NhcmdhOiAnU8OtJywgc2VndXJpZGFkOiAnRGVzY29uZWN0YWRvciBwb3Igc29icmVwcmVzacOzbicsXG4gICAgICAgIGZhY3RvckRlc2ludG9uaXphY2lvbjogJ04vQScsIHRpcG9OdWNsZW86ICdOw7pjbGVvIGRlIEhpZXJybyBjb24gRW50cmVoaWVycm8nLFxuICAgICAgICBjbGFzZUFpc2xhbWllbnRvVGVybWljbzogJ0NsYXNlIEggKDE4MMKwQyknLCBwcm90ZWNjaW9uVGVybWljYTogJ1NlbnNvciBCaW1ldMOhbGljbyAvIFBUMTAwIGludGVncmFkbycsXG4gICAgICAgIHJlZ3VsYWRvck1hcmNhTW9kZWxvOiAnJywgcmVsYWNpb25UYzogJycsIHB1ZXJ0b0NvbXVuaWNhY2lvbjogJ1JTLTQ4NSAoTW9kYnVzIFJUVSknLFxuICAgICAgICBpbnRlcnJ1cHRvclByaW5jaXBhbEFtcDogJycsIHByb3RlY2Npb25QYXNvczogJ0Z1c2libGVzJywgZ3JhZG9Qcm90ZWNjaW9uRW52b2x2ZW50ZTogJ0lQNTQnLFxuICAgICAgICBkaW1lbnNpb25lc0FsdG86ICcnLCBkaW1lbnNpb25lc0FuY2hvOiAnJywgZGltZW5zaW9uZXNQcm9mOiAnJyxcbiAgICAgICAgc2lzdGVtYUVuZnJpYW1pZW50bzogJ1ZlbnRpbGFjacOzbiBGb3J6YWRhJywgdGVtcGVyYXR1cmFDOiAnJywgaHVtZWRhZFBjdDogJydcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0aXBvRWxlbWVudG8gPT09ICdQVU5UT19TVU1JTklTVFJPJykge1xuICAgICAgZGF0b3NUZWNuaWNvcyA9IHtcbiAgICAgICAgbml2ZWxUZW5zaW9uOiBzdW1pbmlzdHJvVGVuc2lvbiB8fCAnMTMuOCBrVicsXG4gICAgICAgIHRlbnNpb25Ob21pbmFsOiBzdW1pbmlzdHJvVGVuc2lvbiB8fCAnMTMuOCBrVicsXG4gICAgICAgIGVtcHJlc2FEaXN0cmlidWlkb3JhOiBzdW1pbmlzdHJvRW1wcmVzYSB8fCAnQ09SUE9FTEVDJyxcbiAgICAgICAgdGlwb0Fjb21ldGlkYTogc3VtaW5pc3Ryb1RpcG9BY29tZXRpZGEgfHwgJ1N1YnRlcnLDoW5lYScsXG4gICAgICAgIGNhcGFjaWRhZENvbnRyYXRhZGFLdmE6IHN1bWluaXN0cm9DYXBhY2lkYWQgfHwgJycsXG4gICAgICAgIGNhcmdhQ29udHJhdGFkYUt2YTogc3VtaW5pc3Ryb0NhcGFjaWRhZCB8fCAnJyxcbiAgICAgICAgdGlwb01lZGljaW9uOiBzdW1pbmlzdHJvVGlwb01lZGljaW9uIHx8ICdNZWRpY2nDs24gRGlyZWN0YSAoQmFqYSBUZW5zacOzbiknLFxuICAgICAgICBlbmxhY2VDb3Jwb2VsZWM6IEJvb2xlYW4oc3VtaW5pc3Ryb0VubGFjZUNvcnBvZWxlYyksXG4gICAgICAgIG51bWVyb0NvbnRyYXRvOiBzdW1pbmlzdHJvTnVtZXJvQ29udHJhdG8gfHwgJycsXG4gICAgICAgIG5pYzogc3VtaW5pc3Ryb05pYyB8fCAnJyxcbiAgICAgICAgcG9zdGVUcmFuc2Zvcm1hZG9yOiBzdW1pbmlzdHJvUG9zdGVUcmFmbyB8fCAnJ1xuICAgICAgfTtcbiAgICB9IGVsc2UgaWYgKHRpcG9FbGVtZW50byA9PT0gJ0NDTScpIHtcbiAgICAgIGRhdG9zVGVjbmljb3MgPSB7XG4gICAgICAgIGNhcGFjaWRhZEJhcnJhQW1wZXJpb3M6IGNjbUNhcGFjaWRhZEJhcnJhIHx8ICcxMjAwIEEnLFxuICAgICAgICB0ZW5zaW9uT3BlcmF0aXZhOiBjY21UZW5zaW9uIHx8ICc0ODAgVicsXG4gICAgICAgIGJyZWFrZXJQcmluY2lwYWw6IGNjbUJyZWFrZXJQcmluY2lwYWwgfHwgJzEyMDBBIDNQJyxcbiAgICAgICAgbnVtZXJvR2F2ZXRhczogcGFyc2VJbnQoY2NtTnVtZXJvR2F2ZXRhcywgMTApIHx8IDhcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0aXBvRWxlbWVudG8gPT09ICdQVUVTVEFfVElFUlJBJykge1xuICAgICAgZGF0b3NUZWNuaWNvcyA9IHtcbiAgICAgICAgcmVzaXN0ZW5jaWFPaG1pb3MsXG4gICAgICAgIGNvcnJpZW50ZUZ1Z2FBbXBlcmlvczogY29ycmllbnRlRnVnYSxcbiAgICAgICAgdGlwb01hbGxhLFxuICAgICAgICBjYWJsZUFjb21ldGlkYTogY2FibGVBY29tZXRpZGFUaWVycmFcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0aXBvRWxlbWVudG8gPT09ICdUUkFOU0ZFUicpIHtcbiAgICAgIGRhdG9zVGVjbmljb3MgPSB7XG4gICAgICAgIGNhcGFjaWRhZEFtcGVyaW9zLFxuICAgICAgICB0aXBvVHJhbnNmZXJlbmNpYSxcbiAgICAgICAgdGVuc2lvbk9wZXJhdGl2YVxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgZGF0b3NUZWNuaWNvcyA9IHtcbiAgICAgICAgZGVzY3JpcGNpb25Fc3BlY2lmaWNhY2lvbmVzOiBkZXNjcmlwY2lvbk90cm9cbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc3QgcmVzdWx0ID0gYWRkRWxlbWVudG9VbmlmaWxhcih7XG4gICAgICBwcm95ZWN0b0lkOiBudWxsLFxuICAgICAgY29tcGFueUlkLFxuICAgICAgbm9tYnJlOiBlbGVtZW50b05vbWJyZS50cmltKCksXG4gICAgICB0aXBvRWxlbWVudG8sXG4gICAgICB1YmljYWNpb246IHViaWNhY2lvbi50cmltKCkgfHwgJ1NpbiB1YmljYWNpw7NuJyxcbiAgICAgIGFsaW1lbnRhZG9Qb3I6IGFsaW1lbnRhZG9Qb3IudHJpbSgpIHx8ICdObyBkZWZpbmlkbycsXG4gICAgICBmb3RvQmxvYixcbiAgICAgIG9ic2VydmFjaW9uZXNHZW5lcmFsZXM6IG9ic2VydmFjaW9uZXNHZW5lcmFsZXMudHJpbSgpLFxuICAgICAgZGF0b3NUZWNuaWNvc1xuICAgIH0pO1xuXG4gICAgaWYgKHJlc3VsdC5zdWNjZXNzKSB7XG4gICAgICBzZXRFbGVtZW50b05vbWJyZSgnJyk7XG4gICAgICBzZXRVYmljYWNpb24oJycpO1xuICAgICAgc2V0QWxpbWVudGFkb1BvcignJyk7XG4gICAgICBzZXRPYnNlcnZhY2lvbmVzR2VuZXJhbGVzKCcnKTtcbiAgICAgIHNldFN1bWluaXN0cm9UZW5zaW9uKCcnKTtcbiAgICAgIHNldFN1bWluaXN0cm9FbXByZXNhKCdDT1JQT0VMRUMnKTtcbiAgICAgIHNldFN1bWluaXN0cm9UaXBvQWNvbWV0aWRhKCdTdWJ0ZXJyw6FuZWEnKTtcbiAgICAgIHNldFN1bWluaXN0cm9DYXBhY2lkYWQoJycpO1xuICAgICAgc2V0U3VtaW5pc3Ryb1RpcG9NZWRpY2lvbignTWVkaWNpw7NuIERpcmVjdGEgKEJhamEgVGVuc2nDs24pJyk7XG4gICAgICBzZXRTdW1pbmlzdHJvRW5sYWNlQ29ycG9lbGVjKHRydWUpO1xuICAgICAgc2V0U3VtaW5pc3Ryb051bWVyb0NvbnRyYXRvKCcnKTtcbiAgICAgIHNldFN1bWluaXN0cm9OaWMoJycpO1xuICAgICAgc2V0U3VtaW5pc3Ryb1Bvc3RlVHJhZm8oJycpO1xuICAgICAgc2V0Rm90b0Jsb2IobnVsbCk7XG4gICAgICBpZiAocHJldmlld1VybCkgVVJMLnJldm9rZU9iamVjdFVSTChwcmV2aWV3VXJsKTtcbiAgICAgIHNldFByZXZpZXdVcmwobnVsbCk7XG4gICAgICBzZXRTaG93RWxlbWVudG9Nb2RhbChmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGN1c3RvbUFsZXJ0KHJlc3VsdC5lcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZU9wZW5UYWJsZXJvTW9kYWwgPSAoKSA9PiB7XG4gICAgc2V0U2hvd0VsZW1lbnRvTW9kYWwodHJ1ZSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBhbnRpYWxpYXNlZCBmb250LXNhbnNcIj5cbiAgICAgIFxuICAgICAgey8qIFRvcCBIZWFkZXIgKi99XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwLzgwIHB4LTYgcHktNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc2hhZG93LWxnXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy8nKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTQ1MCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCB0cmFuc2l0aW9uLWFsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBhY3RpdmU6c2NhbGUtOTUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgdGl0bGU9XCJWb2x2ZXIgYWwgRGFzaGJvYXJkXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTUwMCBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJsb2NrXCI+XG4gICAgICAgICAgICAgIEdlc3Rpw7NuIGRlIEVtcHJlc2FcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCB0cmFja2luZy10aWdodFwiPntjb21wYW55Lm5vbWJyZX08L2gxPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICB7LyogTWFpbiBDb250YWluZXIgKi99XG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LTEgbWF4LXctN3hsIHctZnVsbCBteC1hdXRvIHB4LTYgcHktOCBzcGFjZS15LThcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBDQVJEIElORk9STUFDSU9OIERFIExBIEVNUFJFU0EgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3cteGwgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci01MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9jayBtYi0xXCI+RmljaGEgVMOpY25pY2E8L3NwYW4+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtMTAwIHRyYWNraW5nLXRpZ2h0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPEJ1aWxkaW5nIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci01MDBcIiAvPiB7Y29tcGFueS5ub21icmV9XG4gICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgIHt1c2VyPy5yb2xlID09PSAnQURNSU4nICYmIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldEVkaXROb21icmUoY29tcGFueS5ub21icmUpO1xuICAgICAgICAgICAgICAgICAgICBzZXRFZGl0UmlmKGNvbXBhbnkucmlmIHx8ICcnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0RWRpdERpcmVjY2lvbkZpc2NhbChjb21wYW55LmRpcmVjY2lvbkZpc2NhbCB8fCAnJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldEVkaXRHZXJlbnRlMU5vbWJyZShjb21wYW55LmdlcmVudGUxTm9tYnJlIHx8ICcnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0RWRpdEdlcmVudGUxVGVsZWZvbm8oY29tcGFueS5nZXJlbnRlMVRlbGVmb25vIHx8ICcnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0RWRpdEdlcmVudGUxRW1haWwoY29tcGFueS5nZXJlbnRlMUVtYWlsIHx8ICcnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0RWRpdEdlcmVudGUyTm9tYnJlKGNvbXBhbnkuZ2VyZW50ZTJOb21icmUgfHwgJycpO1xuICAgICAgICAgICAgICAgICAgICBzZXRFZGl0R2VyZW50ZTJUZWxlZm9ubyhjb21wYW55LmdlcmVudGUyVGVsZWZvbm8gfHwgJycpO1xuICAgICAgICAgICAgICAgICAgICBzZXRFZGl0R2VyZW50ZTJFbWFpbChjb21wYW55LmdlcmVudGUyRW1haWwgfHwgJycpO1xuICAgICAgICAgICAgICAgICAgICBzZXRTaG93RWRpdEVtcHJlc2FNb2RhbCh0cnVlKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMS41IGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTIwMCBob3Zlcjp0ZXh0LXNsYXRlLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIHNoYWRvdy1tZFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgRWRpdGFyIEVtcHJlc2FcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvYmFja3VwcycpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgYmctYW1iZXItNTAwLzEwIGhvdmVyOmJnLWFtYmVyLTUwMC8yMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWxnIHRleHQtYW1iZXItNDAwIGhvdmVyOnRleHQtYW1iZXItMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kXCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIklyIGFsIENlbnRybyBkZSBSZXNndWFyZG8geSBDb3BpYXMgZGUgU2VndXJpZGFkXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxEYXRhYmFzZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgUmVzZ3VhcmRvICYgQmFja3Vwc1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC02IG10LTYgcHQtNiBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGQgdXBwZXJjYXNlIGJsb2NrXCI+UklGPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0yMDBcIj57Y29tcGFueS5yaWYgfHwgJ0otTi9EJ308L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGQgdXBwZXJjYXNlIGJsb2NrXCI+RGlyZWNjacOzbiBGaXNjYWw8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTIwMFwiPntjb21wYW55LmRpcmVjY2lvbkZpc2NhbCB8fCAnTi9EJ308L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgYmxvY2tcIj5SZWdpc3Rybzwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm8gbXQtMSBzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgIDxkaXY+Q3JlYWRvOiB7Y29tcGFueS5jcmVhdGVkQXQgPyBuZXcgRGF0ZShjb21wYW55LmNyZWF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoJ2VzLUVTJykgOiAnTi9EJ308L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PkFjdHVhbGl6YWRvOiB7Y29tcGFueS51cGRhdGVkQXQgPyBuZXcgRGF0ZShjb21wYW55LnVwZGF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoJ2VzLUVTJykgOiAnTi9EJ308L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHt1c2VyPy5yb2xlID09PSAnQURNSU4nICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBwdC02IGJvcmRlci10IGJvcmRlci1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi00IGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2t5LTQwMFwiIC8+IENvbnRhY3RvIEdlcmVuY2lhbCAoU29sbyBWaXNpYmxlIHBhcmEgQWRtaW5pc3RyYWRvcmVzKVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cbiAgICAgICAgICAgICAgICB7LyogR2VyZW50ZSAxICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzUwIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNreS00MDAgZm9udC1ib2xkIHVwcGVyY2FzZSBibG9jayBtYi0yXCI+R2VyZW50ZSBQcmluY2lwYWw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj48c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDUwXCI+Tm9tYnJlOjwvc3Ryb25nPiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTI1NSBmb250LXNlbWlib2xkXCI+e2NvbXBhbnkuZ2VyZW50ZTFOb21icmUgfHwgJ04vRCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PjxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00NTBcIj5UZWzDqWZvbm86PC9zdHJvbmc+IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjU1IGZvbnQtc2VtaWJvbGRcIj57Y29tcGFueS5nZXJlbnRlMVRlbGVmb25vIHx8ICdOL0QnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj48c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDUwXCI+RW1haWw6PC9zdHJvbmc+IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjU1IGZvbnQtc2VtaWJvbGRcIj57Y29tcGFueS5nZXJlbnRlMUVtYWlsIHx8ICdOL0QnfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEdlcmVudGUgMiAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC81MCBwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1za3ktNDAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgYmxvY2sgbWItMlwiPkdlcmVudGUgU2VjdW5kYXJpbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PjxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00NTBcIj5Ob21icmU6PC9zdHJvbmc+IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjU1IGZvbnQtc2VtaWJvbGRcIj57Y29tcGFueS5nZXJlbnRlMk5vbWJyZSB8fCAnTi9EJ308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+PHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQ1MFwiPlRlbMOpZm9ubzo8L3N0cm9uZz4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yNTUgZm9udC1zZW1pYm9sZFwiPntjb21wYW55LmdlcmVudGUyVGVsZWZvbm8gfHwgJ04vRCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PjxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00NTBcIj5FbWFpbDo8L3N0cm9uZz4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yNTUgZm9udC1zZW1pYm9sZFwiPntjb21wYW55LmdlcmVudGUyRW1haWwgfHwgJ04vRCd9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIFxuICAgICAgICB7LyogQWN0aW9ucyBwYW5lbCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdHJldGNoIHNtOml0ZW1zLWNlbnRlciBnYXAtNCBwYi02IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAvODBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlucHV0LXNlYXJjaC1jb250YWluZXIgdy1mdWxsIHNtOnctNjRcIj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQnVzY2FyIHByb3llY3RvIG8gZXF1aXBvLi4uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQtc2VhcmNoXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctNC41IGgtNC41IGFic29sdXRlIGxlZnQtMy41IHRvcC0zIHRleHQtc2xhdGUtNTAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgc206ZmxleC1ub3dyYXAgaXRlbXMtY2VudGVyIGdhcC0zIHctZnVsbCBzbTp3LWF1dG8ganVzdGlmeS1lbmRcIj5cblxuICAgICAgICAgICAgey8qIEJvdMOzbiBkZSBEaWFncmFtYSBVbmlmaWxhciBHcsOhZmljbyAqL31cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dEaWFncmFtTW9kYWwodHJ1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXZpb2xldC02MDAgaG92ZXI6YmctdmlvbGV0LTUwMCB0ZXh0LXNsYXRlLTEwMCBmb250LWJvbGQgYWN0aXZlOnNjYWxlLTk4IHRyYW5zaXRpb24tYWxsIHB4LTQgcHktMi41IHJvdW5kZWQtbGcgZmxleCBmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgaC0xMCB3aGl0ZXNwYWNlLW5vd3JhcCB3LWZ1bGwgc206dy1hdXRvIGN1cnNvci1wb2ludGVyIHRleHQteHMgc2hhZG93LW1kXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTQgaC00IGZpbGwtc2xhdGUtMTAwXCIgLz4gVmVyIERpYWdyYW1hIEdyw6FmaWNvXG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIHt1c2VyPy5yb2xlICE9PSAnQ0xJRU5UJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIHNtOmZsZXgtbm93cmFwIGl0ZW1zLWNlbnRlciBnYXAtMyB3LWZ1bGwgc206dy1hdXRvIGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgIHsvKiBCb3TDs24gU2VsZWNjacOzbiBNw7psdGlwbGUgKi99XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRJc011bHRpU2VsZWN0TW9kZSghaXNNdWx0aVNlbGVjdE1vZGUpO1xuICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRJZHMobmV3IFNldCgpKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJvcmRlciBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIHB4LTQgcHktMi41IHJvdW5kZWQtbGcgZmxleCBmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgaC0xMCB3aGl0ZXNwYWNlLW5vd3JhcCB3LWZ1bGwgc206dy1hdXRvIGN1cnNvci1wb2ludGVyIHRleHQteHMgJHtcbiAgICAgICAgICAgICAgICAgIGlzTXVsdGlTZWxlY3RNb2RlIFxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAvMTAgYm9yZGVyLWFtYmVyLTUwMC80MCB0ZXh0LWFtYmVyLTUwMCcgXG4gICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCBib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxDaGVja1NxdWFyZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4ge2lzTXVsdGlTZWxlY3RNb2RlID8gJ0NhbmNlbGFyIFNlbGVjY2nDs24nIDogJ1NlbGVjY2lvbmFyIFZhcmlvcyd9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgIHsvKiBCb3TDs24gUHJpbmNpcGFsOiArIENyZWFyIEVsZW1lbnRvIGZ1ZXJhIGRlIHByb3llY3RvcyAqL31cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU9wZW5UYWJsZXJvTW9kYWx9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCBob3ZlcjpiZy1hbWJlci00MDAgYWN0aXZlOnNjYWxlLTk4IHRyYW5zaXRpb24tYWxsIHB4LTQgcHktMi41IHJvdW5kZWQtbGcgZmxleCBmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgaC0xMCB3aGl0ZXNwYWNlLW5vd3JhcCB3LWZ1bGwgc206dy1hdXRvIGN1cnNvci1wb2ludGVyIHRleHQteHMgc2hhZG93LW1kXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTk1MCBmaWxsLXNsYXRlLTk1MFwiIC8+ICsgQ3JlYXIgRWxlbWVudG9cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgey8qIEJvdMOzbiBTZWN1bmRhcmlvOiArIENyZWFyIFByb3llY3RvICovfVxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsKHRydWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTEwMCBmb250LXNlbWlib2xkIGhvdmVyOmJnLXNsYXRlLTgwMCBhY3RpdmU6c2NhbGUtOTggdHJhbnNpdGlvbi1hbGwgcHgtNCBweS0yLjUgcm91bmRlZC1sZyBmbGV4IGZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBoLTEwIHdoaXRlc3BhY2Utbm93cmFwIHctZnVsbCBzbTp3LWF1dG8gY3Vyc29yLXBvaW50ZXIgdGV4dC14c1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gKyBDcmVhciBQcm95ZWN0b1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtpc011bHRpU2VsZWN0TW9kZSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcm91bmRlZC0yeGwgcC00IGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBhbmltYXRlLWZhZGVJbiBzaGFkb3ctbGcgc2hhZG93LWFtYmVyLTUwMC81XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctYW1iZXItNTAwIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgTW9kbyBTZWxlY2Npw7NuIE3Dumx0aXBsZTogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTUwMCBmb250LWJvbGRcIj57c2VsZWN0ZWRJZHMuc2l6ZX08L3N0cm9uZz4ge3NlbGVjdGVkSWRzLnNpemUgPT09IDEgPyAnZXF1aXBvIHNlbGVjY2lvbmFkbycgOiAnZXF1aXBvcyBzZWxlY2Npb25hZG9zJ31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgc206dy1hdXRvIGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTZWxlY3RBbGx9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgaG92ZXI6dGV4dC1zbGF0ZS0xMDBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgU2VsZWNjaW9uYXIgVG9kb1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURlc2VsZWN0QWxsfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0yIGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGhvdmVyOnRleHQtc2xhdGUtMTAwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIERlc2VsZWNjaW9uYXIgVG9kb1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAge3NlbGVjdGVkSWRzLnNpemUgPiAwICYmIHVzZXI/LnJvbGUgIT09ICdDTElFTlQnICYmIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEZWxldGVTZWxlY3RlZH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0yIGJnLXJlZC05NTAvNDAgaG92ZXI6YmctcmVkLTkwMC82MCBib3JkZXIgYm9yZGVyLXJlZC04MDAvNDAgcm91bmRlZC14bCB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1yZWQtNDAwIGhvdmVyOnRleHQtcmVkLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gRWxpbWluYXIgKHtzZWxlY3RlZElkcy5zaXplfSlcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldElzTXVsdGlTZWxlY3RNb2RlKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkSWRzKG5ldyBTZXQoKSk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBMSVNUQURPIERFIFBST1lFQ1RPUyAqL31cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtMTAwIHRyYWNraW5nLXdpZGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPEZvbGRlck9wZW4gY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTUwMFwiIC8+IENhcnBldGFzIGRlIFByb3llY3RvcyAoe3Byb3llY3Rvcy5sZW5ndGh9KVxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxuICAgICAgICAgICAgICBPcmdhbml6YSBsYXMgaW5zcGVjY2lvbmVzIGVuIGNhcnBldGFzIG8gcHJveWVjdG9zIHTDqWNuaWNvcyBpbmRlcGVuZGllbnRlcy5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHtmaWx0ZXJlZFByb2plY3RzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cbiAgICAgICAgICAgICAge2ZpbHRlcmVkUHJvamVjdHMubWFwKChwcm9qKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAga2V5PXtwcm9qLmlkfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9lbXByZXNhLyR7Y29tcGFueUlkfS9wcm95ZWN0by8ke3Byb2ouaWR9YCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMC82MCByb3VuZGVkLTJ4bCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LXhsIHAtNSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCBob3Zlcjp0cmFuc2xhdGUteS1bLTJweF0gZ3JvdXAgcmVsYXRpdmVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHt1c2VyPy5yb2xlICE9PSAnQ0xJRU5UJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZVByb3llY3RvKHByb2ouaWQsIHByb2oubm9tYnJlKTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC00IHJpZ2h0LTQgcC0yIGJnLXNsYXRlLTkwMC85MCBob3ZlcjpiZy1yZWQtOTUwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1yZWQtOTAwLzYwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtcmVkLTQwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCB6LTEwIGN1cnNvci1wb2ludGVyIG9wYWNpdHktMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVsaW1pbmFyIFByb3llY3RvXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBwci0xMiBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTg1MCByb3VuZGVkLXhsIHctbWF4IHNoYWRvdy1pbm5lciB0ZXh0LWFtYmVyLTUwMCBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Rm9sZGVyT3BlbiBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgZ3JvdXAtaG92ZXI6dGV4dC1hbWJlci00MDAgdHJhbnNpdGlvbi1jb2xvcnMgdHJhY2tpbmctdGlnaHQgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9qLm5vbWJyZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIG10LTEgbGluZS1jbGFtcC0yIGxlYWRpbmctcmVsYXhlZCBtaW4taC1bMzJweF0gZm9udC1zYW5zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cHJvai5kZXNjcmlwY2lvbiB8fCAnU2luIGRlc2NyaXBjacOzbiBkaXNwb25pYmxlLid9XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1zbGF0ZS05MDAvNjAgcHQtNCBtdC00IHNwYWNlLXktMi41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiB0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1zbGF0ZS05MDAvNDAgcC0yIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS05MDAvNjAganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxMYXllcnMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1za3ktNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDBcIj57KHByb2ouZWxlbWVudG9zVW5pZmlsYXJlcyB8fCBwcm9qLnRhYmxlcm9zIHx8IFtdKS5sZW5ndGh9PC9zcGFuPiBFcXVpcG9zXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLXNsYXRlLTkwMC80MCBwLTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTkwMC82MCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1aWxkaW5nIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNTAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDBcIj57KHByb2ouaW5zcGVjY2lvbmVzU3ViZXN0YWNpb24gfHwgcHJvai5zdWJlc3RhY2lvbmVzIHx8IFtdKS5sZW5ndGh9PC9zcGFuPiBTdWJlc3RhYy5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5DcmVhZG86PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntwcm9qLmNyZWF0ZWRBdCA/IG5ldyBEYXRlKHByb2ouY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2VzLUVTJykgOiAnTi9EJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xNiBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgdGV4dC1jZW50ZXIgc3BhY2UteS00IGJnLXNsYXRlLTk1MC8yMFwiPlxuICAgICAgICAgICAgICA8Rm9sZGVyT3BlbiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1zbGF0ZS03MDAgbXgtYXV0b1wiIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIGZvbnQtc2Fuc1wiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMFwiPk5vIHNlIGVuY29udHJhcm9uIHByb3llY3RvczwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtYXgtdy1zbSBteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICBDcmVhIHVuYSBudWV2YSBjYXJwZXRhIGRlIHByb3llY3RvIHBhcmEgY29tZW56YXIgYSByZWdpc3RyYXIgdGFibGVyb3MgZSBpbnNwZWNjaW9uZXMuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBMSVNUQURPIERFIEVRVUlQT1MgR0VORVJBTEVTIChGVUVSQSBERSBQUk9ZRUNUT1MpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTggYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS0xMDAgdHJhY2tpbmctd2lkZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci01MDBcIiAvPiBFcXVpcG9zIGZ1ZXJhIGRlIENhcnBldGFzICh7ZWxlbWVudG9zR2VuZXJhbGVzLmxlbmd0aH0pXG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgIEVxdWlwb3MgcmVnaXN0cmFkb3MgZGlyZWN0YW1lbnRlIGEgbml2ZWwgZGUgZW1wcmVzYSwgZnVlcmEgZGUgY2FycGV0YXMgZGUgcHJveWVjdG9zLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge2ZpbHRlcmVkRWxlbWVudG9zR2VuZXJhbGVzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cbiAgICAgICAgICAgICAge2ZpbHRlcmVkRWxlbWVudG9zR2VuZXJhbGVzLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzVGFibGVybyA9IGl0ZW0udGlwb0VsZW1lbnRvID09PSAnVEFCTEVSTyc7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNUcmFmbyA9IGl0ZW0udGlwb0VsZW1lbnRvID09PSAnVFJBTlNGT1JNQURPUic7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNHZW4gPSBpdGVtLnRpcG9FbGVtZW50byA9PT0gJ0dFTkVSQURPUic7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNQdWVzdGFUaWVycmEgPSBpdGVtLnRpcG9FbGVtZW50byA9PT0gJ1BVRVNUQV9USUVSUkEnO1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzVHJhbnNmZXIgPSBpdGVtLnRpcG9FbGVtZW50byA9PT0gJ1RSQU5TRkVSJztcbiAgICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWRJZHMuaGFzKGl0ZW0uaWQpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGlzTXVsdGlTZWxlY3RNb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVUb2dnbGVTZWxlY3QoaXRlbS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKGAvZW1wcmVzYS8ke2NvbXBhbnlJZH0vdGFibGVyby8ke2l0ZW0uaWR9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1zbGF0ZS05NTAgYm9yZGVyIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIG92ZXJmbG93LWhpZGRlbiBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCBob3ZlcjotdHJhbnNsYXRlLXktMC41IGdyb3VwIHJvdW5kZWQtMnhsIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3cteGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICBpc011bHRpU2VsZWN0TW9kZSAmJiBpc1NlbGVjdGVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWFtYmVyLTUwMCBzaGFkb3ctYW1iZXItNTAwLzUgcmluZy0xIHJpbmctYW1iZXItNTAwLzIwJyBcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS04MDAvODAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMC82MCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBDYWJlY2VyYSBkZSBUYXJqZXRhICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMzIgdy1mdWxsIGJnLXNsYXRlLTkwMCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMC81MFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmZvdG9CbG9iIHx8IGl0ZW0uZm90byA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTYWZlSW1hZ2UgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2I9e2l0ZW0uZm90b0Jsb2J9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17aXRlbS5mb3RvfSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtpdGVtLm5vbWJyZX0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIGdyb3VwLWhvdmVyOnNjYWxlLTEwMiB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDBcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS03MDAgZ2FwLTEuNSBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNUYWJsZXJvICYmIDxaYXAgY2xhc3NOYW1lPVwidy04IGgtOCBvcGFjaXR5LTI1IHRleHQtc2t5LTQwMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNUcmFmbyAmJiA8Q3B1IGNsYXNzTmFtZT1cInctOCBoLTggb3BhY2l0eS0yNSB0ZXh0LXB1cnBsZS00MDBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2lzR2VuICYmIDxaYXAgY2xhc3NOYW1lPVwidy04IGgtOCBvcGFjaXR5LTI1IHRleHQtYW1iZXItNDAwXCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1B1ZXN0YVRpZXJyYSAmJiA8U2hpZWxkQWxlcnQgY2xhc3NOYW1lPVwidy04IGgtOCBvcGFjaXR5LTI1IHRleHQtdGVhbC00MDBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2lzVHJhbnNmZXIgJiYgPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJ3LTggaC04IG9wYWNpdHktMjUgdGV4dC1lbWVyYWxkLTQwMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzVGFibGVybyAmJiAhaXNUcmFmbyAmJiAhaXNHZW4gJiYgIWlzUHVlc3RhVGllcnJhICYmICFpc1RyYW5zZmVyICYmIDxMYXllcnMgY2xhc3NOYW1lPVwidy04IGgtOCBvcGFjaXR5LTI1IHRleHQtc2xhdGUtNDAwXCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0cmFja2luZy13aWRlc3Qgb3BhY2l0eS0zMFwiPlNpbiBJbWFnZW48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBCYWRnZSBwb3IgdGlwb0VsZW1lbnRvICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgbGVmdC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNUYWJsZXJvICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTAuNSByb3VuZGVkLWxnIHRleHQtWzlweF0gZm9udC1ib2xkIGJnLXNreS05NTAvOTUgdGV4dC1za3ktNDAwIGJvcmRlciBib3JkZXItc2t5LTgwMC80MCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDimqEgVEFCTEVST1xuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAge2lzVHJhZm8gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yLjUgcHktMC41IHJvdW5kZWQtbGcgdGV4dC1bOXB4XSBmb250LWJvbGQgYmctcHVycGxlLTk1MC85NSB0ZXh0LXB1cnBsZS00MDAgYm9yZGVyIGJvcmRlci1wdXJwbGUtODAwLzQwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKaoSBUUkFOU0ZPUk1BRE9SXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNHZW4gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yLjUgcHktMC41IHJvdW5kZWQtbGcgdGV4dC1bOXB4XSBmb250LWJvbGQgYmctYW1iZXItOTUwLzk1IHRleHQtYW1iZXItNDAwIGJvcmRlciBib3JkZXItYW1iZXItODAwLzQwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKaoSBHRU5FUkFET1JcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc1B1ZXN0YVRpZXJyYSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIuNSBweS0wLjUgcm91bmRlZC1sZyB0ZXh0LVs5cHhdIGZvbnQtYm9sZCBiZy10ZWFsLTk1MC85NSB0ZXh0LXRlYWwtNDAwIGJvcmRlciBib3JkZXItdGVhbC04MDAvNDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+boe+4jyBQVUVTVEEgQSBUSUVSUkFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc1RyYW5zZmVyICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTAuNSByb3VuZGVkLWxnIHRleHQtWzlweF0gZm9udC1ib2xkIGJnLWVtZXJhbGQtOTUwLzk1IHRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTgwMC80MCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5SEIFRSQU5TRkVSRU5DSUFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRpcG9FbGVtZW50byA9PT0gJ1BVTlRPX1NVTUlOSVNUUk8nICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTAuNSByb3VuZGVkLWxnIHRleHQtWzlweF0gZm9udC1ib2xkIGJnLWJsdWUtOTUwLzk1IHRleHQtYmx1ZS00MDAgYm9yZGVyIGJvcmRlci1ibHVlLTgwMC80MCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5SMIFBUTy4gU1VNSU5JU1RST1xuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGlwb0VsZW1lbnRvID09PSAnQ0NNJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIuNSBweS0wLjUgcm91bmRlZC1sZyB0ZXh0LVs5cHhdIGZvbnQtYm9sZCBiZy1hbWJlci05NTAvOTUgdGV4dC1hbWJlci00MDAgYm9yZGVyIGJvcmRlci1hbWJlci04MDAvNDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4pqZ77iPIENDTSBNT1RPUkVTXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aXBvRWxlbWVudG8gPT09ICdCQU5DT19DT05ERU5TQURPUicgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yLjUgcHktMC41IHJvdW5kZWQtbGcgdGV4dC1bOXB4XSBmb250LWJvbGQgYmctZW1lcmFsZC05NTAvOTUgdGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtODAwLzQwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKaoSBCQU5DTyBDT05ERU5TQURPUlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIElEIEJhZGdlICovfVxuICAgICAgICAgICAgICAgICAgICAgIHshaXNNdWx0aVNlbGVjdE1vZGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMyByaWdodC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJsYWNrIHRleHQtYW1iZXItNDAwIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBweC0yLjUgcHktMC41IHJvdW5kZWQtbGcgdGV4dC14cyBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBJRDoge2l0ZW0uaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogSW5kaWNhZG9yIGRlIGNhc2lsbGEgZGUgdmVyaWZpY2FjacOzbiBwYXJhIFNlbGVjY2nDs24gTcO6bHRpcGxlICovfVxuICAgICAgICAgICAgICAgICAgICAgIHtpc011bHRpU2VsZWN0TW9kZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIHJpZ2h0LTMgei0xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BwLTEuNSByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAgYm9yZGVyLWFtYmVyLTQwMCB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctbWQgc2hhZG93LWFtYmVyLTUwMC8yMCcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAvOTAgYm9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTUwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1NlbGVjdGVkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrU3F1YXJlIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBib3JkZXIgYm9yZGVyLXNsYXRlLTYwMCByb3VuZGVkLXNtXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBmbGV4LTEgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtMTAwIGdyb3VwLWhvdmVyOnRleHQtYW1iZXItNTAwIHRyYW5zaXRpb24tY29sb3JzIHRydW5jYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRFbGVtZW50VGl0bGVXaXRoSWQoaXRlbS5ub21icmUsIGl0ZW0uaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgbXQtMyB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwLzYwIHB0LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGRcIj5VYmljYWNpw7NuOjwvc3Bhbj4ge2l0ZW0udWJpY2FjaW9ufTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGRcIj5BbGltZW50YWRvcjo8L3NwYW4+IHtpdGVtLmFsaW1lbnRhZG9Qb3IgfHwgJ05vIGRlZmluaWRvJ308L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNUYWJsZXJvICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2t5LTQwMCBmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LVsxMHB4XSBiZy1za3ktOTUwLzQwIHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1za3ktOTAwLzQwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKaoSBDYXBhY2lkYWQ6IHtpdGVtLmRhdG9zVGVjbmljb3M/Lm1heFBvbGVzIHx8IDI0fSBQb2xvcyAoe2l0ZW0uZGF0b3NUZWNuaWNvcz8udm9sdGFqZUFjb21ldGlkYSB8fCAnMjA4LzEyMCBWJ30pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNUcmFmbyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS00MDAgZm9udC1tb25vIGZvbnQtc2VtaWJvbGQgdGV4dC1bMTBweF0gYmctcHVycGxlLTk1MC80MCBwLTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItcHVycGxlLTkwMC80MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDimqEge2l0ZW0uZGF0b3NUZWNuaWNvcz8ua3ZhIHx8ICc1MDAgS1ZBJ30gfCBHRSB7aXRlbS5kYXRvc1RlY25pY29zPy5jb25leGlvbiB8fCAnRXN0cmVsbGEtRXN0cmVsbGEnfSAoe2l0ZW0uZGF0b3NUZWNuaWNvcz8udm9sdGFqZVByaW1hcmlvIHx8ICcxMy44IGtWJ30pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNHZW4gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1hbWJlci00MDAgZm9udC1tb25vIGZvbnQtc2VtaWJvbGQgdGV4dC1bMTBweF0gYmctYW1iZXItOTUwLzQwIHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1hbWJlci05MDAvNDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pqhIHtpdGVtLmRhdG9zVGVjbmljb3M/Lmt2YSB8fCAnNTgwIGtWQSd9IHwge2l0ZW0uZGF0b3NUZWNuaWNvcz8udm9sdGFqZUdlbmVyYWNpb24gfHwgJzIwOCBWJ30gfCBCcmVha2VyIHtpdGVtLmRhdG9zVGVjbmljb3M/LmFtcGVyYWplIHx8ICcxNjAwIEEnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzUHVlc3RhVGllcnJhICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGVhbC00MDAgZm9udC1tb25vIGZvbnQtc2VtaWJvbGQgdGV4dC1bMTBweF0gYmctdGVhbC05NTAvNDAgcC0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXRlYWwtOTAwLzQwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCfm6HvuI8gQ29ycmllbnRlIEZ1Z2E6IHtpdGVtLmRhdG9zVGVjbmljb3M/LmNvcnJpZW50ZUZ1Z2FBbXBlcmlvcyB8fCAnNi40IEEnfSB8IHtpdGVtLmRhdG9zVGVjbmljb3M/LnRpcG9NYWxsYSB8fCAnTWFsbGEgQ29uY3JldG8nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzVHJhbnNmZXIgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMCBmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LVsxMHB4XSBiZy1lbWVyYWxkLTk1MC80MCBwLTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZW1lcmFsZC05MDAvNDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+UhCB7aXRlbS5kYXRvc1RlY25pY29zPy5jYXBhY2lkYWRBbXBlcmlvcyB8fCAnMzIwMCBBJ30gfCB7aXRlbS5kYXRvc1RlY25pY29zPy50aXBvVHJhbnNmZXJlbmNpYSB8fCAnQVRTIFlVWUUtWUVTMSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aXBvRWxlbWVudG8gPT09ICdQVU5UT19TVU1JTklTVFJPJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNDAwIGZvbnQtbW9ubyBmb250LXNlbWlib2xkIHRleHQtWzEwcHhdIGJnLWJsdWUtOTUwLzQwIHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ibHVlLTkwMC80MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5SMIHtpdGVtLmRhdG9zVGVjbmljb3M/Lm5pdmVsVGVuc2lvbiB8fCAnMTMuOCBrVid9IHwge2l0ZW0uZGF0b3NUZWNuaWNvcz8uY2FyZ2FDb250cmF0YWRhS3ZhIHx8IGl0ZW0uZGF0b3NUZWNuaWNvcz8uY2FwYWNpZGFkQ29udHJhdGFkYUt2YSB8fCAnMTAwMCBrVkEnfSB8IHtpdGVtLmRhdG9zVGVjbmljb3M/LnRpcG9NZWRpY2lvbiB8fCAnTWVkaWNpw7NuIERpcmVjdGEgQlQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQmFycmEgZGUgQXZhbmNlIHkgUG9yY2VudGFqZSBkZSBDb21wbGV0aXR1ZCAoT2JzIDQpICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS05MDAvODBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxBdmFuY2VQcm9ncmVzc0JhciBlbGVtZW50bz17aXRlbX0gdGlwb0VsZW1lbnRvPXtpdGVtLnRpcG9FbGVtZW50byB8fCAnVEFCTEVSTyd9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQWNjaW9uZXMgQ1JVRCBEaXJlY3RhcyBlbiBUYXJqZXRhIChPYnMgMiB5IDI0KSAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxFbGVtZW50b0NhcmRBY3Rpb25zXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uRWRpdD17KCkgPT4gbmF2aWdhdGUoYC9lbXByZXNhLyR7Y29tcGFueUlkfS90YWJsZXJvLyR7aXRlbS5pZH1gKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25OZXdJbnNwZWN0aW9uPXsoKSA9PiBuYXZpZ2F0ZShgL2VtcHJlc2EvJHtjb21wYW55SWR9L3RhYmxlcm8vJHtpdGVtLmlkfWApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG9rID0gYXdhaXQgY29uZmlybSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0VsaW1pbmFyIEVxdWlwbycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBgwr9Fc3TDoXMgc2VndXJvIGRlIHF1ZSBkZXNlYXMgZWxpbWluYXIgZWwgZXF1aXBvIFwiJHtpdGVtLm5vbWJyZX1cIj9gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2RhbmdlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25maXJtVGV4dDogJ0VsaW1pbmFyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChvaykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlRWxlbWVudG9VbmlmaWxhcihudWxsLCBpdGVtLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5PXt1c2VyPy5yb2xlID09PSAnQ0xJRU5UJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTE2IGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCB0ZXh0LWNlbnRlciBzcGFjZS15LTQgYmctc2xhdGUtOTUwLzIwXCI+XG4gICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtc2xhdGUtNzAwIG14LWF1dG9cIiAvPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMSBmb250LXNhbnNcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDBcIj5ObyBoYXkgZXF1aXBvcyBnZW5lcmFsZXM8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbWF4LXctc20gbXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgUmVnaXN0cmEgdW4gZXF1aXBvIHTDqWNuaWNvIGRpcmVjdGFtZW50ZSBhIG5pdmVsIGRlIGVtcHJlc2EuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L21haW4+XG5cbiAgICAgIHsvKiBNT0RBTCAxOiBSRUdJU1RSQVIgTlVFVk8gUFJPWUVDVE8gKi99XG4gICAgICB7c2hvd01vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLXNsYXRlLTkwMC83MCBiYWNrZHJvcC1ibHVyLXNtIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfSAvPlxuICAgICAgICAgIFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LW1kIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIHAtNiBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8Rm9sZGVyT3BlbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz5cbiAgICAgICAgICAgICAgICBSZWdpc3RyYXIgTnVldm8gUHJveWVjdG9cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IGhvdmVyOmJnLXNsYXRlLTkwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtNTAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQ3JlYXRlUHJveWVjdG99IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIE5vbWJyZSBkZWwgUHJveWVjdG9cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwcm95ZWN0b05vbWJyZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UHJveWVjdG9Ob21icmUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gSW5zcGVjY2lvbmVzIFBsYW50YSBCYWphIDIwMjZcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTMuNSBweS0yLjUgYmctc2xhdGUtOTAwIGJvcmRlciBmb2N1czpyaW5nLTEgcm91bmRlZC14bCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBoLTExIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgIG5vbWJyZVByb3llY3RvRHVwbGljYWRvIFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwIGZvY3VzOnJpbmctcmVkLTU1MCcgXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctYW1iZXItNTAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICB7bm9tYnJlUHJveWVjdG9EdXBsaWNhZG8gJiYgKFxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1yZWQtNTU1IGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG10LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IE5vbWJyZSBkdXBsaWNhZG86IHlhIGV4aXN0ZSB1biBwcm95ZWN0byBjb24gZXN0ZSBub21icmUuXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgRGVzY3JpcGNpw7NuIChPcGNpb25hbClcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3Byb3llY3RvRGVzY3JpcGNpb259XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFByb3llY3RvRGVzY3JpcGNpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEZXNjcmliZSBicmV2ZW1lbnRlIGVsIGFsY2FuY2UgZGUgZXN0ZSBwcm95ZWN0by4uLlwiXG4gICAgICAgICAgICAgICAgICByb3dzPXs0fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0yLjUgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC1zbSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXItc2xhdGUtNjAwIHRyYW5zaXRpb24tYWxsIGZvbnQtc2FucyByZXNpemUtbm9uZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMC82MFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQuNSBweS0yLjUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRleHQtc2xhdGUtMzUwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFpc1Byb3llY3RvVmFsaWR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1hbWJlci00MDAgYWN0aXZlOnNjYWxlLTk4IHRyYW5zaXRpb24tYWxsIHB4LTQgcHktMi41IHJvdW5kZWQtbGcgZmxleCBmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgaC0xMCB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXhzIGN1cnNvci1wb2ludGVyIHNoYWRvdy1tZCBkaXNhYmxlZDpvcGFjaXR5LTQwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDcmVhciBQcm95ZWN0b1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNT0RBTCBNVUxUSS1QTEFOVElMTEEgREUgRUxFTUVOVE9TIFVOSUZJTEFSRVMgRU4gTEEgRU1QUkVTQSAqL31cbiAgICAgIHtzaG93RWxlbWVudG9Nb2RhbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1zbGF0ZS05MDAvNzAgYmFja2Ryb3AtYmx1ci1zbSBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0VsZW1lbnRvTW9kYWwoZmFsc2UpfSAvPlxuICAgICAgICAgIFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LW1kIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIHAtNiBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMCBtYXgtaC1bOTB2aF0gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPiBSZWdpc3RyYXIgUGxhbnRpbGxhIFTDqWNuaWNhXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0VsZW1lbnRvTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IGhvdmVyOmJnLXNsYXRlLTkwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtNTA1IHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQ3JlYXRlRWxlbWVudG99IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS00IG92ZXJmbG93LXktYXV0byBwci0xIGZsZXgtMVwiPlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgey8qIFNlbGVjdG9yIGRlIFRpcG8gZGUgUGxhbnRpbGxhICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICBUaXBvIGRlIFBsYW50aWxsYSBkZSBFbGVtZW50b1xuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy0zIGdhcC0xLjUgYmctc2xhdGUtOTAwIHAtMS41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1bOXB4XVwiPlxuICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ1RBQkxFUk8nLCBsYWJlbDogJ+KaoSBQQU5FTCBFTMOJQ1RSSUNPJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnUFVOVE9fU1VNSU5JU1RSTycsIGxhYmVsOiAn8J+UjCBQVE8uIFNVTUlOSVNUUk8nIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdHRU5FUkFET1InLCBsYWJlbDogJ/CflIsgR0VORVJBRE9SJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnVFJBTlNGT1JNQURPUicsIGxhYmVsOiAn8J+UhCBUUkFOU0ZPUk1BRE9SJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnVFJBTlNGRVInLCBsYWJlbDogJ/CflIAgVFJBTlNGRVJFTkNJQScgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ0NDTScsIGxhYmVsOiAn4pqZ77iPIENDTSAoTU9UT1JFUyknIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdCQU5DT19DT05ERU5TQURPUicsIGxhYmVsOiAn4pqhIEJBTkNPIENPTkQuJyB9XG4gICAgICAgICAgICAgICAgICBdLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXt0LmlkfVxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRpcG9FbGVtZW50byh0LmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTIgZm9udC1ibGFjayByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aXBvRWxlbWVudG8gPT09IHQuaWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctbWQnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7dC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIE5vbWJyZSBkZXNjcmlwdGl2byAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgTm9tYnJlIGRlc2NyaXB0aXZvIGRlbCBlcXVpcG9cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbGVtZW50b05vbWJyZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWxlbWVudG9Ob21icmUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2BFai4gJHt0aXBvRWxlbWVudG8gPT09ICdUQUJMRVJPJyA/ICdUYWJsZXJvIFByaW5jaXBhbCAoVEFCIDIwKScgOiB0aXBvRWxlbWVudG8gPT09ICdUUkFOU0ZPUk1BRE9SJyA/ICdUcmFuc2Zvcm1hZG9yIEdFIDUwMCBLVkEnIDogdGlwb0VsZW1lbnRvID09PSAnUFVFU1RBX1RJRVJSQScgPyAnTWFsbGEgUHVlc3RhIGEgVGllcnJhIE7CsCAxJyA6ICdHZW5lcmFkb3IgRE9NT1NBIDEnfWB9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMy41IHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBmb2N1czpyaW5nLTEgcm91bmRlZC14bCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBoLTExIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgIG5vbWJyZUVsZW1lbnRvRHVwbGljYWRvIFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwIGZvY3VzOnJpbmctcmVkLTU1MCcgXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctYW1iZXItNTAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICB7bm9tYnJlRWxlbWVudG9EdXBsaWNhZG8gJiYgKFxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1yZWQtNTU1IGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG10LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IE5vbWJyZSBkdXBsaWNhZG86IHlhIGV4aXN0ZSBlc3RlIGVxdWlwbyBlbiBsYSBlbXByZXNhLlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBVYmljYWNpw7NuICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICBVYmljYWNpw7NuIEbDrXNpY2FcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3ViaWNhY2lvbn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VWJpY2FjaW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIFPDs3Rhbm8gU2FsYSBUw6ljbmljYSBvIEVzdGFjaW9uYW1pZW50byBFeHRlcmlvclwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC1zbSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXItc2xhdGUtNjAwIGgtMTEgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBBbGltZW50YWNpw7NuICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICBBbGltZW50YWRvIFBvciAoUHJvY2VkZW5jaWEpXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXthbGltZW50YWRvUG9yfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBbGltZW50YWRvUG9yKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIFRyYW5zZm9ybWFkb3IgNTAwIEtWQSBvIENPUlBPRUxFQ1wiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC1zbSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXItc2xhdGUtNjAwIGgtMTEgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBDQU1QT1MgRVNQRUPDjUZJQ09TIFNFR8OaTiBFTCBFTlVNICovfVxuXG4gICAgICAgICAgICAgIHsvKiBUQUJMRVJPICovfVxuICAgICAgICAgICAgICB7dGlwb0VsZW1lbnRvID09PSAnVEFCTEVSTycgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgTsO6bWVybyBNw6F4aW1vIGRlIFBvbG9zXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttYXhQb2xlc31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1heFBvbGVzKHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlLCAxMCkgfHwgMCl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFc2NyaWJlIGVsIG5yby4gZGUgcG9sb3NcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMi8zIHB4LTMuNSBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHRleHQtc20gdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGgtMTEgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21heFBvbGVzfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsID0gcGFyc2VJbnQoZS50YXJnZXQudmFsdWUsIDEwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWwpIHNldE1heFBvbGVzKHZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvMyBweC0zIHB5LTIuNSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC14bCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBoLTExXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj4tLSBFc3TDoW5kYXIgLS08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXsxMn0+MTIgUG9sb3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXsyNH0+MjQgUG9sb3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXszMH0+MzAgUG9sb3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs0Mn0+NDIgUG9sb3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs0OH0+NDggUG9sb3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs2MH0+NjAgUG9sb3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs3Mn0+NzIgUG9sb3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs4NH0+ODQgUG9sb3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs5Nn0+OTYgUG9sb3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogVFJBTlNGT1JNQURPUiAqL31cbiAgICAgICAgICAgICAge3RpcG9FbGVtZW50byA9PT0gJ1RSQU5TRk9STUFET1InICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+UG90ZW5jaWEgS1ZBPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17a3ZhVHJhZm99IG9uQ2hhbmdlPXsoZSkgPT4gc2V0S3ZhVHJhZm8oZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiA1MDAgS1ZBXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+TWFyY2E8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXttYXJjYVRyYWZvfSBvbkNoYW5nZT17KGUpID0+IHNldE1hcmNhVHJhZm8oZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiBHRVwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlRpcG8gVHJhbnNmb3JtYWRvcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17dGlwb1RyYWZvfSBvbkNoYW5nZT17KGUpID0+IHNldFRpcG9UcmFmbyhlLnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQWNlaXRlXCI+QWNlaXRlIChTdW1lcmdpZG8gLyBFeHRlcmlvcik8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTZWNvXCI+U2VjbyAoRW5jYXBzdWxhZG8gLyBJbnRlcmlvcik8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQZWRlc3RhbFwiPlBlZGVzdGFsIChBY2VpdGUpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUG9zdGVcIj5Nb250YWplIGVuIFBvc3RlIChBY2VpdGUpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPkNvbmV4acOzbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2NvbmV4aW9uVHJhZm99IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29uZXhpb25UcmFmbyhlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIEVzdHJlbGxhIC0gRXN0cmVsbGFcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIEdFTkVSQURPUiAqL31cbiAgICAgICAgICAgICAge3RpcG9FbGVtZW50byA9PT0gJ0dFTkVSQURPUicgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5DYXBhY2lkYWQga1ZBPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17a3ZhR2VufSBvbkNoYW5nZT17KGUpID0+IHNldEt2YUdlbihlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIDU4MCBrVkFcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb250LW1vbm9cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5Db21idXN0aWJsZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17Y29tYnVzdGlibGVHZW59IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29tYnVzdGlibGVHZW4oZS50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkRJRVNFTFwiPkRJw4lTRUwgLyBHQVNPSUw8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJHQVNcIj5HQVMgTkFUVVJBTDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkdBU09MSU5BXCI+R0FTT0xJTkE8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlZvbHRhamUgR2VuZXJhY2nDs248L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXt2b2x0YWplR2VufSBvbkNoYW5nZT17KGUpID0+IHNldFZvbHRhamVHZW4oZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiAyMDggLyAxMjAgVlwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPkludGVycnVwdG9yIEFtcGVyYWplPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17YW1wZXJhamVHZW59IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QW1wZXJhamVHZW4oZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiAxNjAwIEFcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb250LW1vbm9cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBQVUVTVEEgQSBUSUVSUkEgKi99XG4gICAgICAgICAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdQVUVTVEFfVElFUlJBJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlJlc2lzdGVuY2lhICjOqSk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtyZXNpc3RlbmNpYU9obWlvc30gb25DaGFuZ2U9eyhlKSA9PiBzZXRSZXNpc3RlbmNpYU9obWlvcyhlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIDAuNSDOqVwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPkNvcnJpZW50ZSBGdWdhIChBKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2NvcnJpZW50ZUZ1Z2F9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29ycmllbnRlRnVnYShlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIDYuNCBBXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vIHRleHQtYW1iZXItNDUwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlRpcG8gZGUgTWFsbGEgLyBVYmljYWNpw7NuPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e3RpcG9NYWxsYX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRUaXBvTWFsbGEoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiBNYWxsYSBkZWJham8gZGUgY29uY3JldG9cIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogQkFOQ08gQ09OREVOU0FET1IgKi99XG4gICAgICAgICAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdCQU5DT19DT05ERU5TQURPUicgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5DYXBhY2lkYWQgVG90YWwgKGtWQVIpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17a3ZhclRvdGFsfSBvbkNoYW5nZT17KGUpID0+IHNldEt2YXJUb3RhbChlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIDE1MCBrVkFSXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+UGFzb3MgLyBFc2NhbG9uZXM8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtwYXNvc0NvbmRlbnNhZG9yfSBvbkNoYW5nZT17KGUpID0+IHNldFBhc29zQ29uZGVuc2Fkb3IoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiA2IHBhc29zXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlRpcG8gZGUgQmFuY288L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e3RpcG9CYW5jb30gb25DaGFuZ2U9eyhlKSA9PiBzZXRUaXBvQmFuY28oZS50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFVVE9NQVRJQ09cIj5BVVRPTcOBVElDTyAoQ09OVFJPTEFET1IpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRklKT1wiPkZJSk88L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+VGVuc2nDs24gT3BlcmF0aXZhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17dGVuc2lvbkJhbmNvfSBvbkNoYW5nZT17KGUpID0+IHNldFRlbnNpb25CYW5jbyhlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRWouIDIwOCBWIG8gNDgwIFZcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb250LW1vbm9cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBQVU5UTyBERSBTVU1JTklTVFJPICovfVxuICAgICAgICAgICAgICB7dGlwb0VsZW1lbnRvID09PSAnUFVOVE9fU1VNSU5JU1RSTycgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICB7LyogVGVuc2lvbiB5IENhcmdhIENvbnRyYXRhZGEgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFRlbnNpw7NuIGRlIFN1bWluaXN0cm8gKENPVkVOSU4gMTU5OjE5OTcpXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1RFTlNJT05FU19DT1ZFTklOX1RPREFTLmluY2x1ZGVzKHN1bWluaXN0cm9UZW5zaW9uKSA/IHN1bWluaXN0cm9UZW5zaW9uIDogKHN1bWluaXN0cm9UZW5zaW9uID8gJ0NVU1RPTScgOiAnJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLnRhcmdldC52YWx1ZSAhPT0gJ0NVU1RPTScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFN1bWluaXN0cm9UZW5zaW9uKGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS8yIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWNjaW9uZSB0ZW5zacOzbi4uLjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0Z3JvdXAgbGFiZWw9XCJCYWphIFRlbnNpw7NuIChCVClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7VEVOU0lPTkVTX0NPVkVOSU5fMTU5X0JULm1hcCh2ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt2fSB2YWx1ZT17dn0+e3Z9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0Z3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRncm91cCBsYWJlbD1cIk1lZGlhIFRlbnNpw7NuIChNVClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7VEVOU0lPTkVTX0NPVkVOSU5fMTU5X01ULm1hcCh2ID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt2fSB2YWx1ZT17dn0+e3Z9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0Z3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDVVNUT01cIj5PdHJhIHRlbnNpw7NuLi4uPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1pbmlzdHJvVGVuc2lvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdW1pbmlzdHJvVGVuc2lvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDEzLjgga1YgbyAyMDgvMTIwIFZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvMiBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQ2FyZ2EgQ29udHJhdGFkYSAoa1ZBKVxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VtaW5pc3Ryb0NhcGFjaWRhZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3VtaW5pc3Ryb0NhcGFjaWRhZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiAxMDAwIGtWQSBvIDUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBUaXBvIGRlIE1lZGljacOzbiBFbMOpY3RyaWNhIChPYnMgMjMpICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvNjAgcC0zLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIOKaoSBUaXBvIGRlIE1lZGljacOzbiBFbMOpY3RyaWNhIChPYmxpZ2F0b3JpbylcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1pbmlzdHJvVGlwb01lZGljaW9ufVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3VtaW5pc3Ryb1RpcG9NZWRpY2lvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNZWRpY2nDs24gRGlyZWN0YSAoQmFqYSBUZW5zacOzbilcIj4xLiBNZWRpY2nDs24gRGlyZWN0YSAoQmFqYSBUZW5zacOzbik8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTWVkaWNpw7NuIEluZGlyZWN0YSBCVFwiPjIuIE1lZGljacOzbiBJbmRpcmVjdGEgQlQgKGNvbiB0cmFuc2Zvcm1hZG9yZXMgZGUgY29ycmllbnRlIFRDcyk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTWVkaWNpw7NuIEluZGlyZWN0YSBBVC9NVFwiPjMuIE1lZGljacOzbiBJbmRpcmVjdGEgQVQvTVQgKGNvbiBUQ3MgeSBUUHMgcGFyYSBtZWRpYS9hbHRhIHRlbnNpw7NuKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogQmxvcXVlIEVubGFjZSBDb3Jwb2VsZWMgLyBSZWQgUMO6YmxpY2EgKE9icyAyMCkgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC80MCBwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwLzYwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8R2F1Z2UgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWJsdWUtNDAwXCIgLz4gQWNvbWV0aWRhIGRlIFNlcnZpY2lvIC8gUmVkIENvcnBvZWxlY1xuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3N1bWluaXN0cm9FbmxhY2VDb3Jwb2VsZWN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3VtaW5pc3Ryb0VubGFjZUNvcnBvZWxlYyhlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBib3JkZXItc2xhdGUtNzAwIHRleHQtYW1iZXItNTAwIGZvY3VzOnJpbmctYW1iZXItNTAwIGgtNCB3LTQgYmctc2xhdGUtOTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkXCI+RW5sYWNlIEFjdGl2bzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBtYi0xXCI+RW1wcmVzYSBEaXN0cmlidWlkb3JhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1pbmlzdHJvRW1wcmVzYX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdW1pbmlzdHJvRW1wcmVzYShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIENPUlBPRUxFQ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBtYi0xXCI+VGlwbyBkZSBBY29tZXRpZGE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VtaW5pc3Ryb1RpcG9BY29tZXRpZGF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3VtaW5pc3Ryb1RpcG9BY29tZXRpZGEoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC05XCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlN1YnRlcnLDoW5lYVwiPlN1YnRlcnLDoW5lYTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQcOpcmVhXCI+QcOpcmVhPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNaXh0YVwiPk1peHRhIChBw6lyZW8gLSBTdWJ0ZXJyw6FuZW8pPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVs5cHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgbWItMVwiPk7CsCBDb250cmF0byAvIE5JQzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VtaW5pc3Ryb051bWVyb0NvbnRyYXRvfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN1bWluaXN0cm9OdW1lcm9Db250cmF0byhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIDEwMDAyODQ3NTlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC05IGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIG1iLTFcIj5OwrAgTWVkaWRvcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VtaW5pc3Ryb05pY31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdW1pbmlzdHJvTmljKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gTUVELTg4MzkyMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTkgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVs5cHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgbWItMVwiPlBvc3RlIC8gVHJhZm8gU2VydmljaW88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3N1bWluaXN0cm9Qb3N0ZVRyYWZvfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN1bWluaXN0cm9Qb3N0ZVRyYWZvKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gUC0xNDIgLyBUcmFmbyA1MGtWQVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTkgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIENDTSAoQ0VOVFJPIERFIENPTlRST0wgREUgTU9UT1JFUykgKi99XG4gICAgICAgICAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdDQ00nICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+Q2FwYWNpZGFkIEJhcnJhIChBKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2NjbUNhcGFjaWRhZEJhcnJhfSBvbkNoYW5nZT17KGUpID0+IHNldENjbUNhcGFjaWRhZEJhcnJhKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFai4gMTIwMCBBXCIgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGgtMTAgZm9udC1tb25vXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+VGVuc2nDs24gT3BlcmF0aXZhPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17Y2NtVGVuc2lvbn0gb25DaGFuZ2U9eyhlKSA9PiBzZXRDY21UZW5zaW9uKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFai4gNDgwIFZcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgaC0xMCBmb250LW1vbm9cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+QnJlYWtlciBQcmluY2lwYWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtjY21CcmVha2VyUHJpbmNpcGFsfSBvbkNoYW5nZT17KGUpID0+IHNldENjbUJyZWFrZXJQcmluY2lwYWwoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVqLiAxMjAwQSAzUFwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPk5yby4gZGUgR2F2ZXRhcyAvIEJ1Y2tldHM8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMVwiIG1heD1cIjQ4XCIgdmFsdWU9e2NjbU51bWVyb0dhdmV0YXN9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2NtTnVtZXJvR2F2ZXRhcyhlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiOFwiIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBoLTEwIGZvbnQtbW9ub1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIE9UUk8gKi99XG4gICAgICAgICAgICAgIHt0aXBvRWxlbWVudG8gPT09ICdPVFJPJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIEVzcGVjaWZpY2FjaW9uZXMgVMOpY25pY2FzXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHRleHRhcmVhIHZhbHVlPXtkZXNjcmlwY2lvbk90cm99IG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGVzY3JpcGNpb25PdHJvKGUudGFyZ2V0LnZhbHVlKX0gcm93cz17M30gcGxhY2Vob2xkZXI9XCJEZXRhbGxlcyB0w6ljbmljb3MgYWRpY2lvbmFsZXMuLi5cIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTIuNSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSByZXNpemUtbm9uZVwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIE9ic2VydmFjaW9uZXMgZ2VuZXJhbGVzICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICBPYnNlcnZhY2lvbmVzIGRlbCBJbmZvcm1lIFTDqWNuaWNvXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtvYnNlcnZhY2lvbmVzR2VuZXJhbGVzfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRPYnNlcnZhY2lvbmVzR2VuZXJhbGVzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRldGFsbGVzIGRlbCBlc3RhZG8gZGUgbWFudGVuaW1pZW50bywgcG9sdm8sIGh1bWVkYWQgbyByZWNvbWVuZGFjaW9uZXMuLi5cIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0yLjUgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXItc2xhdGUtNjUwIHRyYW5zaXRpb24tYWxsIHJlc2l6ZS1ub25lXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRm90byBPZmZsaW5lIEJsb2IgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPENhbWVyYSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIEZvdG8gbyBJbWFnZW4gZGUgbGEgUGxhY2EgVMOpY25pY29cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHtwcmV2aWV3VXJsID8gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS05MDAgYXNwZWN0LXZpZGVvIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdyb3VwIHNoYWRvdy1tZCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17cHJldmlld1VybH0gYWx0PVwiVmlzdGEgcHJldmlhXCIgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm90b0Jsb2IobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldmlld1VybCkgVVJMLnJldm9rZU9iamVjdFVSTChwcmV2aWV3VXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFByZXZpZXdVcmwobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMiByaWdodC0yIHAtMS41IGJnLXNsYXRlLTk1MC84MCBob3ZlcjpiZy1yZWQtNjUwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LWZ1bGxcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctZnVsbCBoLTI0IGJvcmRlci0yIGJvcmRlci1zbGF0ZS04MDAgYm9yZGVyLWRhc2hlZCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIGJnLXNsYXRlLTkwMC8yMCBob3ZlcjpiZy1zbGF0ZS05MDAvNDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbCBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHQtMyBwYi0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FtZXJhIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1zbGF0ZS01MDAgbWItMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQ1MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5Ub21hciBGb3RvPC9zcGFuPiBvIHN1YmlyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhcHR1cmU9XCJlbnZpcm9ubWVudFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW1hZ2VDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQm90b25lcyBkZSBhY2Npw7NuIGNvbiBlc3RpbG8gYW1hcmlsbG8gdW5pZmljYWRvICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93RWxlbWVudG9Nb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00LjUgcHktMi41IGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04NTAgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTM1MCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshaXNFbGVtZW50b1ZhbGlkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCBob3ZlcjpiZy1hbWJlci00MDAgYWN0aXZlOnNjYWxlLTk4IHRyYW5zaXRpb24tYWxsIHB4LTQuNSBweS0yLjUgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBoLTExIHRleHQteHMgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kIGRpc2FibGVkOm9wYWNpdHktNDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEd1YXJkYXIgUGxhbnRpbGxhXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE1vZGFsIGRlIEVkaWNpw7NuIGRlIEVtcHJlc2EgKi99XG4gICAgICB7c2hvd0VkaXRFbXByZXNhTW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctc2xhdGUtOTUwLzgwIGJhY2tkcm9wLWJsdXItc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IHotNTAgYW5pbWF0ZS1mYWRlSW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBtYXgtdy1sZyB3LWZ1bGwgbWF4LWgtWzkwdmhdIG92ZXJmbG93LXktYXV0byBzaGFkb3ctMnhsIHAtNiBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8QnVpbGRpbmcgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTUwMFwiIC8+IEVkaXRhciBFbXByZXNhXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0VkaXRFbXByZXNhTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IGhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlVXBkYXRlRW1wcmVzYVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS00IGZvbnQtc2FucyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNDAwIGZvbnQtc2VtaWJvbGQgbWItMVwiPk5vbWJyZSBDb21lcmNpYWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdE5vbWJyZX0gXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXROb21icmUoZS50YXJnZXQudmFsdWUpfSBcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTQwMCBmb250LXNlbWlib2xkIG1iLTFcIj5SSUY8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdFJpZn0gXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdFJpZihlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS00MDAgZm9udC1zZW1pYm9sZCBtYi0xXCI+RGlyZWNjacOzbiBGaXNjYWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdERpcmVjY2lvbkZpc2NhbH0gXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdERpcmVjY2lvbkZpc2NhbChlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTMgcHktMiB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgcHQtNCBtdC00IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1za3ktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVsxMHB4XVwiPkdlcmVudGUgUHJpbmNpcGFsPC9oND5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW0gbWItMVwiPk5vbWJyZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0R2VyZW50ZTFOb21icmV9IFxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdEdlcmVudGUxTm9tYnJlKGUudGFyZ2V0LnZhbHVlKX0gXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNTAwIGZvbnQtbWVkaXVtIG1iLTFcIj5UZWzDqWZvbm88L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIiBcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdEdlcmVudGUxVGVsZWZvbm99IFxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdEdlcmVudGUxVGVsZWZvbm8oZS50YXJnZXQudmFsdWUpfSBcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW0gbWItMVwiPkVtYWlsPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiIFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0R2VyZW50ZTFFbWFpbH0gXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0R2VyZW50ZTFFbWFpbChlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgcHQtNCBtdC00IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1za3ktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVsxMHB4XVwiPkdlcmVudGUgU2VjdW5kYXJpbzwvaDQ+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNTAwIGZvbnQtbWVkaXVtIG1iLTFcIj5Ob21icmU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIiBcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdEdlcmVudGUyTm9tYnJlfSBcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRHZXJlbnRlMk5vbWJyZShlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bSBtYi0xXCI+VGVsw6lmb25vPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRHZXJlbnRlMlRlbGVmb25vfSBcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRHZXJlbnRlMlRlbGVmb25vKGUudGFyZ2V0LnZhbHVlKX0gXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1hbWJlci01MDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNTAwIGZvbnQtbWVkaXVtIG1iLTFcIj5FbWFpbDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIiBcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdEdlcmVudGUyRW1haWx9IFxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdEdlcmVudGUyRW1haWwoZS50YXJnZXQudmFsdWUpfSBcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB0ZXh0LXNsYXRlLTEwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCIgXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93RWRpdEVtcHJlc2FNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0zNTAgaG92ZXI6Ymctc2xhdGUtODAwIGhvdmVyOnRleHQtc2xhdGUtMjAwIHJvdW5kZWQtbGcgZm9udC1ib2xkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgaG92ZXI6YmctYW1iZXItNDAwIGFjdGl2ZTpzY2FsZS05OCByb3VuZGVkLWxnIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctbWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEd1YXJkYXIgQ2FtYmlvc1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogTW9kYWwgZGVsIERpYWdyYW1hIFVuaWZpbGFyIEdyw6FmaWNvICovfVxuICAgICAgPE1vZGFsRGlhZ3JhbWFVbmlmaWxhclxuICAgICAgICBpc09wZW49e3Nob3dEaWFncmFtTW9kYWx9XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dEaWFncmFtTW9kYWwoZmFsc2UpfVxuICAgICAgICBlbGVtZW50b3M9e2NvbXBhbnlFbGVtZW50b3N9XG4gICAgICAgIGNvbXBhbnlOYW1lPXtjb21wYW55Py5ub21icmV9XG4gICAgICAgIGNvbXBhbnlJZD17Y29tcGFueUlkfVxuICAgICAgLz5cblxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgRW1wcmVzYVZpZXc7XG4iXX0=