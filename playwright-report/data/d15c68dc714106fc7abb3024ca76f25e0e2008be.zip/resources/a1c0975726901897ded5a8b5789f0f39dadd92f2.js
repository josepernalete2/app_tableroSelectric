import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ElementoCardActions.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { Edit3, Trash2, ClipboardList } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ElementoCardActions.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
export const ElementoCardActions = ({ onEdit, onDelete, onNewInspection, editLabel = "Editar Planilla", deleteLabel = "Eliminar Elemento", inspectionLabel = "Registrar Planilla", className = "", userRole = "ADMIN", readOnly = false }) => {
	const isReadOnly = readOnly || userRole === "CLIENT";
	if (isReadOnly) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: `flex items-center gap-2 pt-3 border-t border-slate-900/80 opacity-100 ${className}`,
			children: /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: (e) => {
					e.stopPropagation();
					onEdit?.();
				},
				className: "flex-1 min-w-0 py-2 px-3 bg-slate-900 hover:bg-slate-850 text-slate-200 border border-slate-800 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 shadow-xs",
				title: editLabel,
				children: [/* @__PURE__ */ _jsxDEV(Edit3, { className: "w-3.5 h-3.5 text-amber-500 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "truncate",
					children: "Ver Ficha"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `flex items-center gap-2 pt-3 border-t border-slate-900/80 opacity-100 ${className}`,
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: (e) => {
					e.stopPropagation();
					onEdit?.();
				},
				className: "flex-1 min-w-0 py-2 px-2.5 bg-slate-900 hover:bg-slate-850 text-slate-200 hover:text-amber-400 border border-slate-800 hover:border-amber-500/40 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 shadow-xs",
				title: editLabel || "Abrir y editar la planilla técnica de este elemento",
				children: [/* @__PURE__ */ _jsxDEV(Edit3, { className: "w-3.5 h-3.5 text-amber-500 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "truncate",
					children: editLabel
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 7
			}, this),
			onNewInspection && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: (e) => {
					e.stopPropagation();
					onNewInspection();
				},
				className: "shrink-0 py-2 px-2.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 hover:text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 shadow-xs",
				title: inspectionLabel || "Iniciar o asociar nueva inspección técnica a este activo",
				children: [/* @__PURE__ */ _jsxDEV(ClipboardList, { className: "w-3.5 h-3.5 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "hidden sm:inline",
					children: inspectionLabel
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 9
			}, this),
			onDelete && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: (e) => {
					e.stopPropagation();
					onDelete?.();
				},
				className: "shrink-0 p-2 bg-slate-900 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 border border-slate-800 hover:border-rose-900/60 rounded-xl transition-all cursor-pointer active:scale-95 shadow-xs opacity-100",
				title: deleteLabel,
				children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this);
};
_c = ElementoCardActions;
export default ElementoCardActions;
var _c;
$RefreshReg$(_c, "ElementoCardActions");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ElementoCardActions.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ElementoCardActions.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ElementoCardActions.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/ElementoCardActions.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsT0FBTyxRQUFRLHFCQUFxQjs7O0FBRTdDLE9BQU8sTUFBTSx1QkFBdUIsRUFDbEMsUUFDQSxVQUNBLGlCQUNBLFlBQVksbUJBQ1osY0FBYyxxQkFDZCxrQkFBa0Isc0JBQ2xCLFlBQVksSUFDWixXQUFXLFNBQ1gsV0FBVyxZQUNQO0NBQ0osTUFBTSxhQUFhLFlBQVksYUFBYTtDQUU1QyxJQUFJLFlBQVk7RUFDZCxPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFXLHlFQUF5RTthQUN2Rix3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLFVBQVUsTUFBTTtLQUNkLEVBQUUsZ0JBQWdCO0tBQ2xCLFNBQVM7SUFDWDtJQUNBLFdBQVU7SUFDVixPQUFPO2NBUFQsQ0FTRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxzQ0FBdUM7Ozs7Y0FDeEQsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBVztJQUFlOzs7O1lBQ3BDOzs7Ozs7RUFDTDs7Ozs7Q0FFVDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVcseUVBQXlFO1lBQXpGO0dBRUUsd0JBQUMsVUFBRDtJQUNFLE1BQUs7SUFDTCxVQUFVLE1BQU07S0FDZCxFQUFFLGdCQUFnQjtLQUNsQixTQUFTO0lBQ1g7SUFDQSxXQUFVO0lBQ1YsT0FBTyxhQUFhO2NBUHRCLENBU0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsc0NBQXVDOzs7O2NBQ3hELHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQVk7SUFBZ0I7Ozs7WUFDdEM7Ozs7OztHQUdQLG1CQUNDLHdCQUFDLFVBQUQ7SUFDRSxNQUFLO0lBQ0wsVUFBVSxNQUFNO0tBQ2QsRUFBRSxnQkFBZ0I7S0FDbEIsZ0JBQWdCO0lBQ2xCO0lBQ0EsV0FBVTtJQUNWLE9BQU8sbUJBQW1CO2NBUDVCLENBU0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUsdUJBQXdCOzs7O2NBQ2pELHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQW9CO0lBQXNCOzs7O1lBQ3BEOzs7Ozs7R0FJVCxZQUNDLHdCQUFDLFVBQUQ7SUFDRSxNQUFLO0lBQ0wsVUFBVSxNQUFNO0tBQ2QsRUFBRSxnQkFBZ0I7S0FDbEIsV0FBVztJQUNiO0lBQ0EsV0FBVTtJQUNWLE9BQU87Y0FFUCx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7OztHQUMzQjs7Ozs7RUFFUDs7Ozs7O0FBRVQ7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJFbGVtZW50b0NhcmRBY3Rpb25zLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRWRpdDMsIFRyYXNoMiwgQ2xpcGJvYXJkTGlzdCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBFbGVtZW50b0NhcmRBY3Rpb25zID0gKHtcbiAgb25FZGl0LFxuICBvbkRlbGV0ZSxcbiAgb25OZXdJbnNwZWN0aW9uLFxuICBlZGl0TGFiZWwgPSAnRWRpdGFyIFBsYW5pbGxhJyxcbiAgZGVsZXRlTGFiZWwgPSAnRWxpbWluYXIgRWxlbWVudG8nLFxuICBpbnNwZWN0aW9uTGFiZWwgPSAnUmVnaXN0cmFyIFBsYW5pbGxhJyxcbiAgY2xhc3NOYW1lID0gJycsXG4gIHVzZXJSb2xlID0gJ0FETUlOJyxcbiAgcmVhZE9ubHkgPSBmYWxzZVxufSkgPT4ge1xuICBjb25zdCBpc1JlYWRPbmx5ID0gcmVhZE9ubHkgfHwgdXNlclJvbGUgPT09ICdDTElFTlQnO1xuXG4gIGlmIChpc1JlYWRPbmx5KSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwLzgwIG9wYWNpdHktMTAwICR7Y2xhc3NOYW1lfWB9PlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgICBvbkVkaXQ/LigpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTAgcHktMiBweC0zIGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04NTAgdGV4dC1zbGF0ZS0yMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtOTUgc2hhZG93LXhzXCJcbiAgICAgICAgICB0aXRsZT17ZWRpdExhYmVsfVxuICAgICAgICA+XG4gICAgICAgICAgPEVkaXQzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNTAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPlZlciBGaWNoYTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMC84MCBvcGFjaXR5LTEwMCAke2NsYXNzTmFtZX1gfT5cbiAgICAgIHsvKiAxLiBFZGl0YXIgUGxhbmlsbGEgKi99XG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgb25FZGl0Py4oKTtcbiAgICAgICAgfX1cbiAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTAgcHktMiBweC0yLjUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTg1MCB0ZXh0LXNsYXRlLTIwMCBob3Zlcjp0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwLzQwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtOTUgc2hhZG93LXhzXCJcbiAgICAgICAgdGl0bGU9e2VkaXRMYWJlbCB8fCBcIkFicmlyIHkgZWRpdGFyIGxhIHBsYW5pbGxhIHTDqWNuaWNhIGRlIGVzdGUgZWxlbWVudG9cIn1cbiAgICAgID5cbiAgICAgICAgPEVkaXQzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNTAwIHNocmluay0wXCIgLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57ZWRpdExhYmVsfTwvc3Bhbj5cbiAgICAgIDwvYnV0dG9uPlxuXG4gICAgICB7LyogMi4gUmVnaXN0cmFyIEluc3BlY2Npw7NuICovfVxuICAgICAge29uTmV3SW5zcGVjdGlvbiAmJiAoXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgIG9uTmV3SW5zcGVjdGlvbigpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwic2hyaW5rLTAgcHktMiBweC0yLjUgYmctYW1iZXItNTAwLzEwIGhvdmVyOmJnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTQwMCBob3Zlcjp0ZXh0LWFtYmVyLTMwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXIgYWN0aXZlOnNjYWxlLTk1IHNoYWRvdy14c1wiXG4gICAgICAgICAgdGl0bGU9e2luc3BlY3Rpb25MYWJlbCB8fCBcIkluaWNpYXIgbyBhc29jaWFyIG51ZXZhIGluc3BlY2Npw7NuIHTDqWNuaWNhIGEgZXN0ZSBhY3Rpdm9cIn1cbiAgICAgICAgPlxuICAgICAgICAgIDxDbGlwYm9hcmRMaXN0IGNsYXNzTmFtZT1cInctMy41IGgtMy41IHNocmluay0wXCIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+e2luc3BlY3Rpb25MYWJlbH08L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKX1cblxuICAgICAgey8qIDMuIEVsaW1pbmFyIEVsZW1lbnRvICovfVxuICAgICAge29uRGVsZXRlICYmIChcbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XG4gICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgb25EZWxldGU/LigpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwic2hyaW5rLTAgcC0yIGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1yb3NlLTk1MC80MCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXJvc2UtNDAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1yb3NlLTkwMC82MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGFjdGl2ZTpzY2FsZS05NSBzaGFkb3cteHMgb3BhY2l0eS0xMDBcIlxuICAgICAgICAgIHRpdGxlPXtkZWxldGVMYWJlbH1cbiAgICAgICAgPlxuICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBFbGVtZW50b0NhcmRBY3Rpb25zO1xuIl19