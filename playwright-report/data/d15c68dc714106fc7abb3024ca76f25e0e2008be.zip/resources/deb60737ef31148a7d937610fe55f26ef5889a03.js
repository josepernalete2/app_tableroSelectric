import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SidebarLayout.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { Outlet, useNavigate, useLocation, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=f49807c8";
import useStore from "/src/store/useStore.js?t=1790792337841";
import { useConfirm } from "/src/context/ConfirmContext.jsx";
import io from "/node_modules/.vite/deps/socket__io-client.js?v=f49807c8";
import { API_BASE_URL } from "/src/utils/api.js";
import { Briefcase, TrendingUp, Database, LogOut, Menu, X, Zap, User, UploadCloud, Download, RefreshCw, FileText, Clock, Sparkles, ShieldCheck, Users, MessageSquare, ChevronLeft, ChevronRight, Cloud, Trash2, RotateCcw, Plus, HardDrive } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SidebarLayout.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export const SidebarLayout = () => {
	_s();
	const isChatEnabled = false;
	const { user, token, logout, companies, importCompanies, usersList, addUser, updateUser, deleteUser, messages, sendMessage, socket, setSocket, addIncomingMessage, markMessagesAsRead, fetchUsersList, fetchMessagesList, showToast } = useStore();
	const { confirm } = useConfirm();
	const navigate = useNavigate();
	const location = useLocation();
	// Menú móvil
	const [isMobileOpen, setIsMobileOpen] = useState(false);
	// Modales
	const [showReportsModal, setShowReportsModal] = useState(false);
	const [showUsersModal, setShowUsersModal] = useState(false);
	const [showChatModal, setShowChatModal] = useState(false);
	// Estados de control de usuarios
	const [newUserEmail, setNewUserEmail] = useState("");
	const [newUserPassword, setNewUserPassword] = useState("");
	const [newUserRole, setNewUserRole] = useState("WORKER");
	const [newUserCompanyId, setNewUserCompanyId] = useState("");
	const [editingUserId, setEditingUserId] = useState(null);
	const [editingEmail, setEditingEmail] = useState("");
	const [editingPassword, setEditingPassword] = useState("");
	const [editingRole, setEditingRole] = useState("WORKER");
	const [editingCompanyId, setEditingCompanyId] = useState("");
	// Estados de Chat
	const [activeContactId, setActiveContactId] = useState(null);
	const [chatMessageText, setChatMessageText] = useState("");
	const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
	// Inicialización de Sockets
	useEffect(() => {
		if (isChatEnabled && user && navigator.onLine) {
			fetchUsersList();
			fetchMessagesList(user.id);
			const socketInstance = io(API_BASE_URL);
			socketInstance.on("connect", () => {
				console.log("⚡ Conectado al servidor de Sockets");
				socketInstance.emit("register_user", user.id);
			});
			socketInstance.on("receive_message", (msg) => {
				addIncomingMessage(msg);
			});
			setSocket(socketInstance);
			return () => {
				socketInstance.disconnect();
				setSocket(null);
			};
		}
	}, [user]);
	// Sincronizar la lista de usuarios con el servidor
	useEffect(() => {
		if (user && navigator.onLine) {
			fetchUsersList();
		}
	}, [user]);
	// Marcar como leído al abrir la conversación
	useEffect(() => {
		if (showChatModal && activeContactId) {
			markMessagesAsRead(activeContactId);
		}
	}, [
		showChatModal,
		activeContactId,
		messages
	]);
	const handleLogout = () => {
		if (socket) {
			socket.disconnect();
			setSocket(null);
		}
		logout();
		navigate("/login");
	};
	// Cerrar menú móvil al navegar
	useEffect(() => {
		setIsMobileOpen(false);
	}, [location.pathname]);
	// Agregar usuario
	const handleAddUser = async (e) => {
		e.preventDefault();
		if (!newUserEmail.trim() || !newUserPassword.trim()) {
			showToast("Por favor, rellene todos los campos.", "warning");
			return;
		}
		const result = await addUser({
			username: newUserEmail.trim(),
			email: newUserEmail.trim(),
			password: newUserPassword.trim(),
			role: newUserRole,
			companyId: newUserRole === "CLIENT" ? newUserCompanyId : null
		});
		if (result.success) {
			setNewUserEmail("");
			setNewUserPassword("");
			setNewUserRole("WORKER");
			setNewUserCompanyId("");
			showToast("Usuario registrado con éxito.", "success");
		} else {
			showToast(result.error || "Error al registrar usuario.", "error");
		}
	};
	// Guardar edición
	const handleSaveUserEdit = async (userId) => {
		if (!editingEmail.trim() || !editingPassword.trim()) {
			showToast("Por favor, rellene todos los campos.", "warning");
			return;
		}
		const result = await updateUser(userId, {
			username: editingEmail.trim(),
			email: editingEmail.trim(),
			password: editingPassword.trim(),
			role: editingRole,
			companyId: editingRole === "CLIENT" ? editingCompanyId : null
		});
		if (result.success) {
			setEditingUserId(null);
			setEditingCompanyId("");
			showToast("Usuario actualizado con éxito.", "success");
		} else {
			showToast(result.error || "Error al actualizar usuario.", "error");
		}
	};
	const handleStartEditUser = (u) => {
		setEditingUserId(u.id);
		setEditingEmail(u.username || u.email || "");
		setEditingPassword(u.password);
		setEditingRole(u.role);
		setEditingCompanyId(u.companyId || "");
	};
	const handleDeleteUser = async (userId) => {
		const ok = await confirm({
			title: "Eliminar Usuario",
			message: "¿Está seguro de que desea eliminar este usuario?",
			type: "danger",
			confirmText: "Eliminar"
		});
		if (ok) {
			const result = await deleteUser(userId);
			if (result.success) {
				showToast("Usuario eliminado con éxito.", "success");
			} else {
				showToast(result.error || "Error al eliminar usuario.", "error");
			}
		}
	};
	// Métodos auxiliares de chat
	const getContacts = () => {
		if (!usersList) return [];
		if (user?.role === "ADMIN") {
			return usersList.filter((u) => u.id !== user.id && (u.role === "ADMIN" || u.role === "WORKER" || u.role === "CLIENT"));
		} else if (user?.role === "WORKER") {
			return usersList.filter((u) => u.id !== user.id && (u.role === "ADMIN" || u.role === "CLIENT"));
		} else if (user?.role === "CLIENT") {
			return usersList.filter((u) => u.id !== user.id && u.role === "ADMIN");
		}
		return [];
	};
	const handleSendMessage = (e) => {
		e.preventDefault();
		if (!chatMessageText.trim() || !activeContactId) return;
		sendMessage(activeContactId, chatMessageText.trim());
		setChatMessageText("");
	};
	const getActiveMessages = () => {
		if (!messages || !activeContactId) return [];
		return messages.filter((m) => m.senderId === user?.id && m.receiverId === activeContactId || m.senderId === activeContactId && m.receiverId === user?.id);
	};
	const totalUnreadCount = isChatEnabled ? (messages || []).filter((m) => m.receiverId === user?.id && !m.read).length : 0;
	const navLinks = [{
		name: "Empresas",
		path: "/",
		icon: Briefcase
	}, {
		name: "Mensajería / Chat",
		onClick: () => setShowChatModal(true),
		icon: MessageSquare
	}];
	if (user?.role === "ADMIN") {
		navLinks.push({
			name: "Gestión de Usuarios",
			onClick: () => setShowUsersModal(true),
			icon: Users
		});
	}
	navLinks.push({
		name: "Reportes y Auditoría",
		path: "/reportes",
		icon: FileText
	}, {
		name: "Copias de Seguridad",
		path: "/backups",
		icon: Database
	});
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col lg:flex-row antialiased",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "lg:hidden bg-slate-950/90 border-b border-slate-800/80 px-4 py-3 flex items-center justify-between shadow-md shrink-0 no-print sticky top-0 z-40 backdrop-blur-md",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "p-1.5 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg text-slate-950 shadow-md",
						children: /* @__PURE__ */ _jsxDEV(Zap, { className: "w-5 h-5 fill-slate-950 text-slate-950" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 267,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 266,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "font-extrabold text-sm tracking-widest text-slate-100 font-mono",
						children: "SELECTRIC"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 269,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 265,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setIsMobileOpen(!isMobileOpen),
					className: "p-2 bg-slate-900 rounded-lg text-slate-400 hover:text-slate-200 border border-slate-800",
					children: isMobileOpen ? /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 275,
						columnNumber: 27
					}, this) : /* @__PURE__ */ _jsxDEV(Menu, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 275,
						columnNumber: 55
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 271,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 264,
				columnNumber: 7
			}, this),
			isMobileOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 lg:hidden no-print flex flex-row",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-slate-950/70 backdrop-blur-sm",
					onClick: () => setIsMobileOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 282,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("nav", {
					className: "relative w-64 bg-slate-950 border-r border-slate-800 flex flex-col justify-between p-5 animate-in slide-in-from-left duration-250",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-4 border-b border-slate-900",
							children: [/* @__PURE__ */ _jsxDEV(Link, {
								to: "/",
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-1.5 bg-amber-500 rounded-lg text-slate-950",
									children: /* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 fill-slate-950" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 288,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 287,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-extrabold tracking-widest text-slate-100 font-mono text-sm",
									children: "SELECTRIC"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 290,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 286,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsMobileOpen(false),
								className: "p-1 bg-slate-900 rounded-lg text-slate-400",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 293,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 285,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: navLinks.map((link) => {
								const Icon = link.icon;
								const isActive = link.path ? location.pathname === link.path || link.path === "/backups" && location.pathname === "/backup" : false;
								return link.path ? /* @__PURE__ */ _jsxDEV(Link, {
									to: link.path,
									className: `flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all border ${isActive ? "bg-amber-500/10 border-amber-500/30 text-amber-400" : "bg-transparent border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900"}`,
									children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 313,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: link.name }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 314,
										columnNumber: 23
									}, this)]
								}, link.name, true, {
									fileName: _jsxFileName,
									lineNumber: 304,
									columnNumber: 21
								}, this) : /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setIsMobileOpen(false);
										link.onClick();
									},
									className: "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all border bg-transparent border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900 text-left cursor-pointer relative",
									children: [
										/* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 325,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: link.name }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 326,
											columnNumber: 23
										}, this),
										link.name === "Mensajería / Chat" && totalUnreadCount > 0 && /* @__PURE__ */ _jsxDEV("span", {
											className: "ml-auto bg-red-500 text-slate-950 font-bold rounded-full text-[9px] px-1.5 py-0.5 flex items-center justify-center animate-pulse shrink-0",
											children: totalUnreadCount
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 328,
											columnNumber: 25
										}, this)
									]
								}, link.name, true, {
									fileName: _jsxFileName,
									lineNumber: 317,
									columnNumber: 21
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 297,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 284,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4 border-t border-slate-900 pt-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl",
							children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4.5 h-4.5 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 340,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "truncate min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-slate-500 uppercase font-mono font-bold",
									children: "Usuario Activo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 342,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-semibold text-slate-200 truncate",
									children: user?.username || user?.email
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 343,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 339,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleLogout,
							className: "w-full flex items-center justify-center gap-2 py-2.5 bg-slate-900 hover:bg-red-955/20 hover:text-red-400 border border-slate-800 hover:border-red-900/40 rounded-xl transition-all cursor-pointer text-xs font-bold",
							children: [/* @__PURE__ */ _jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 350,
								columnNumber: 17
							}, this), " Cerrar Sesión"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 346,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 338,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 283,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 281,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("aside", {
				className: `relative hidden lg:flex bg-slate-950 border-r border-slate-800/80 flex-col justify-between shrink-0 no-print sticky top-0 h-screen select-none transition-all duration-300 ${isSidebarCollapsed ? "w-20 p-4" : "w-64 p-6"}`,
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setIsSidebarCollapsed(!isSidebarCollapsed),
						className: "absolute top-6 -right-3 z-35 w-6 h-6 rounded-full bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 flex items-center justify-center cursor-pointer shadow-md hover:bg-slate-800 hover:scale-105 active:scale-95 transition-all",
						title: isSidebarCollapsed ? "Expandir Menú" : "Colapsar Menú",
						children: isSidebarCollapsed ? /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 368,
							columnNumber: 33
						}, this) : /* @__PURE__ */ _jsxDEV(ChevronLeft, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 368,
							columnNumber: 76
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 363,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-8",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between gap-2 px-1",
							children: /* @__PURE__ */ _jsxDEV(Link, {
								to: "/",
								className: "flex items-center gap-2.5 min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl text-slate-950 shadow-md transform hover:rotate-12 transition-transform shrink-0",
									children: /* @__PURE__ */ _jsxDEV(Zap, { className: "w-5 h-5 fill-slate-950 text-slate-950" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 376,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 375,
									columnNumber: 15
								}, this), !isSidebarCollapsed && /* @__PURE__ */ _jsxDEV("div", {
									className: "animate-in fade-in duration-200",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-black text-sm tracking-widest text-slate-100 font-mono block leading-none",
										children: "SELECTRIC"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 380,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[8px] text-amber-500 tracking-widest font-black uppercase",
										children: "Inspección de Red"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 381,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 379,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 374,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 373,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1.5",
							children: [!isSidebarCollapsed && /* @__PURE__ */ _jsxDEV("span", {
								className: "block px-2 text-[9px] font-black uppercase tracking-widest text-slate-500 pb-1 animate-in fade-in duration-200",
								children: "Menú Principal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 390,
								columnNumber: 15
							}, this), navLinks.map((link) => {
								const Icon = link.icon;
								const isActive = link.path ? location.pathname === link.path || link.path === "/backups" && location.pathname === "/backup" : false;
								return link.path ? /* @__PURE__ */ _jsxDEV(Link, {
									to: link.path,
									title: isSidebarCollapsed ? link.name : undefined,
									className: `flex items-center rounded-xl text-xs font-bold transition-all border ${isSidebarCollapsed ? "justify-center p-3" : "gap-3 px-4.5 py-3"}  ${isActive ? "bg-amber-500/10 border-amber-500/30 text-amber-400" : "bg-transparent border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900"}`,
									children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4 shrink-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 412,
										columnNumber: 19
									}, this), !isSidebarCollapsed && /* @__PURE__ */ _jsxDEV("span", {
										className: "animate-in fade-in duration-200",
										children: link.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 413,
										columnNumber: 43
									}, this)]
								}, link.name, true, {
									fileName: _jsxFileName,
									lineNumber: 400,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV("button", {
									onClick: link.onClick,
									title: isSidebarCollapsed ? link.name : undefined,
									className: `w-full flex items-center rounded-xl text-xs font-bold transition-all border bg-transparent border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900 text-left cursor-pointer relative ${isSidebarCollapsed ? "justify-center p-3" : "gap-3 px-4.5 py-3"}`,
									children: [
										/* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4 shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 424,
											columnNumber: 19
										}, this),
										!isSidebarCollapsed && /* @__PURE__ */ _jsxDEV("span", {
											className: "animate-in fade-in duration-200",
											children: link.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 425,
											columnNumber: 43
										}, this),
										link.name === "Mensajería / Chat" && totalUnreadCount > 0 && (isSidebarCollapsed ? /* @__PURE__ */ _jsxDEV("span", { className: "absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse border border-slate-950" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 428,
											columnNumber: 23
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "ml-auto bg-red-500 text-white font-bold rounded-full text-[9px] px-1.5 py-0.5 flex items-center justify-center animate-pulse shrink-0",
											children: totalUnreadCount
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 430,
											columnNumber: 23
										}, this))
									]
								}, link.name, true, {
									fileName: _jsxFileName,
									lineNumber: 416,
									columnNumber: 17
								}, this);
							})]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 388,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 371,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4 border-t border-slate-900 pt-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: `flex items-center bg-slate-900/60 border border-slate-850 rounded-xl ${isSidebarCollapsed ? "justify-center p-2.5" : "gap-3 px-3 py-2.5"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center shrink-0",
								children: /* @__PURE__ */ _jsxDEV(User, { className: "w-4.5 h-4.5 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 447,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 446,
								columnNumber: 13
							}, this), !isSidebarCollapsed && /* @__PURE__ */ _jsxDEV("div", {
								className: "truncate min-w-0 animate-in fade-in duration-200",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[9px] text-slate-500 uppercase font-mono font-black",
									children: user?.role === "ADMIN" ? "👑 Administrador" : "👷 Inspector"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 451,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-bold text-slate-250 truncate",
									children: user?.username || user?.email
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 454,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 450,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 443,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleLogout,
							title: isSidebarCollapsed ? "Cerrar Sesión" : undefined,
							className: `w-full flex items-center justify-center bg-slate-900 hover:bg-red-955/20 hover:text-red-400 border border-slate-800 hover:border-red-900/40 rounded-xl transition-all cursor-pointer text-xs font-bold text-slate-400 ${isSidebarCollapsed ? "p-3" : "gap-2 py-3"}`,
							children: [/* @__PURE__ */ _jsxDEV(LogOut, { className: "w-4 h-4 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 466,
								columnNumber: 13
							}, this), !isSidebarCollapsed && /* @__PURE__ */ _jsxDEV("span", {
								className: "animate-in fade-in duration-200",
								children: "Cerrar Sesión"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 467,
								columnNumber: 37
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 459,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 442,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 358,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 min-w-0 overflow-y-auto max-h-screen",
				children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 474,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 473,
				columnNumber: 7
			}, this),
			showReportsModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 no-print",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200",
					onClick: () => setShowReportsModal(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 480,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full max-w-lg bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden animate-in zoom-in-95 duration-200",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center pb-4 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 485,
								columnNumber: 17
							}, this), "Reportes Futuros y Analíticas IA"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 484,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowReportsModal(false),
							className: "p-1.5 hover:bg-slate-900 rounded-lg text-slate-550 transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 492,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 488,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 483,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-4 space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 leading-relaxed font-sans",
								children: "Estamos trabajando en el desarrollo de herramientas predictivas de inteligencia artificial y módulos avanzados de análisis de red eléctrica. Próximamente dispondrás de los siguientes reportes automáticos:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 497,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 gap-3.5 pt-2",
								children: [
									{
										title: "Reporte de Análisis Predictivo IA",
										desc: "Predice la probabilidad de falla y sobrecarga en interruptores basándose en mediciones de corriente y calibración del conductor.",
										icon: ShieldCheck,
										color: "text-emerald-400 bg-emerald-950/40 border-emerald-900/40"
									},
									{
										title: "Seguimiento Termográfico y Tendencia de Calor",
										desc: "Grafica la evolución de temperaturas máximas detectadas en la placa principal, facilitando la planificación de mantenimientos.",
										icon: Clock,
										color: "text-sky-400 bg-sky-950/40 border-sky-900/40"
									},
									{
										title: "Módulo de Auditoría de Carga (CEN)",
										desc: "Valida automáticamente si las acometidas, barrajes y protecciones cumplen con los límites de capacidad establecidos por el Código Eléctrico Nacional.",
										icon: FileText,
										color: "text-purple-400 bg-purple-950/40 border-purple-900/40"
									}
								].map((item, idx) => {
									const Icon = item.icon;
									return /* @__PURE__ */ _jsxDEV("div", {
										className: `p-4 rounded-xl border flex items-start gap-3.5 shadow-inner ${item.color}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "p-2 rounded-lg bg-slate-900 shrink-0",
											children: /* @__PURE__ */ _jsxDEV(Icon, { className: "w-5 h-5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 526,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 525,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ _jsxDEV("h4", {
												className: "text-xs font-bold text-slate-200",
												children: item.title
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 529,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10.5px] text-slate-400 leading-normal",
												children: item.desc
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 530,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 528,
											columnNumber: 23
										}, this)]
									}, idx, true, {
										fileName: _jsxFileName,
										lineNumber: 524,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 501,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-end pt-4 border-t border-slate-900",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setShowReportsModal(false),
									className: "px-5 py-2.5 bg-amber-500 text-slate-950 hover:bg-amber-400 active:scale-98 transition-all font-bold rounded-xl text-xs cursor-pointer shadow-md",
									children: "Entendido"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 538,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 537,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 496,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 482,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 479,
				columnNumber: 9
			}, this),
			showUsersModal && user?.role === "ADMIN" && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 no-print",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200",
					onClick: () => setShowUsersModal(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 553,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full max-w-4xl bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between items-center pb-4 border-b border-slate-800 shrink-0",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Users, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 558,
									columnNumber: 17
								}, this), "Gestión de Usuarios y Roles"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 557,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setEditingUserId(null);
									setShowUsersModal(false);
								},
								className: "p-1.5 hover:bg-slate-900 rounded-lg text-slate-500 transition-colors cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 568,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 561,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 556,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-4 grid grid-cols-1 lg:grid-cols-5 gap-6 overflow-y-auto pr-1 flex-1 py-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "lg:col-span-2 space-y-4 bg-slate-900/40 p-4 rounded-xl border border-slate-850 h-fit",
								children: [
									/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-xs font-bold text-slate-300 uppercase tracking-wide border-l-2 border-amber-500 pl-2",
										children: "Registrar Nuevo Usuario"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 576,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-400 leading-normal",
										children: "Crea credenciales para inspectores de campo para que puedan usar la tablet y registrar elementos."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 579,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("form", {
										onSubmit: handleAddUser,
										className: "space-y-4",
										children: [
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
												children: "Nombre de Usuario"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 585,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												required: true,
												value: newUserEmail,
												onChange: (e) => setNewUserEmail(e.target.value),
												placeholder: "ej. inspector1",
												className: "w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-lg text-xs text-slate-100 focus:outline-none placeholder-slate-650 h-9"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 588,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 584,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
												children: "Contraseña"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 599,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "password",
												required: true,
												value: newUserPassword,
												onChange: (e) => setNewUserPassword(e.target.value),
												placeholder: "Mínimo 4 caracteres",
												className: "w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-lg text-xs text-slate-100 focus:outline-none placeholder-slate-650 h-9"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 602,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 598,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
												children: "Rol del Usuario"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 613,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("select", {
												value: newUserRole,
												onChange: (e) => setNewUserRole(e.target.value),
												className: "w-full px-3 py-2 bg-white text-slate-900 border border-slate-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-lg text-xs focus:outline-none h-9 font-semibold",
												children: [
													/* @__PURE__ */ _jsxDEV("option", {
														value: "WORKER",
														className: "text-black bg-white",
														children: "👷 INSPECTOR / TRABAJADOR"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 621,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "ADMIN",
														className: "text-black bg-white",
														children: "👑 ADMINISTRADOR"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 622,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "CLIENT",
														className: "text-black bg-white",
														children: "🏢 CLIENTE (EMPRESA)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 623,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 616,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 612,
												columnNumber: 19
											}, this),
											newUserRole === "CLIENT" && /* @__PURE__ */ _jsxDEV("div", {
												className: "animate-in slide-in-from-top duration-200",
												children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "block text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1",
													children: "Empresa Asociada"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 629,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("select", {
													value: newUserCompanyId,
													onChange: (e) => setNewUserCompanyId(e.target.value),
													className: "w-full px-3 py-2 bg-white text-slate-900 border border-slate-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-lg text-xs focus:outline-none h-9 font-semibold",
													children: [/* @__PURE__ */ _jsxDEV("option", {
														value: "",
														className: "text-black",
														children: "-- Seleccionar Empresa --"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 637,
														columnNumber: 25
													}, this), companies.map((c) => /* @__PURE__ */ _jsxDEV("option", {
														value: c.id,
														className: "text-black",
														children: c.nombre
													}, c.id, false, {
														fileName: _jsxFileName,
														lineNumber: 639,
														columnNumber: 27
													}, this))]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 632,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 628,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "submit",
												className: "w-full py-2 bg-amber-500 text-slate-950 hover:bg-amber-400 active:scale-98 transition-all font-bold rounded-lg text-xs cursor-pointer shadow-md",
												children: "+ Registrar Usuario"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 645,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 583,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 575,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "lg:col-span-3 space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-xs font-bold text-slate-300 uppercase tracking-wide border-l-2 border-amber-500 pl-2",
									children: [
										"Usuarios Registrados (",
										usersList?.length || 0,
										")"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 656,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "border border-slate-850 rounded-xl overflow-hidden bg-slate-950/40",
									children: /* @__PURE__ */ _jsxDEV("table", {
										className: "w-full text-left text-xs border-collapse",
										children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
											className: "bg-slate-950 text-slate-400 font-bold border-b border-slate-850 uppercase text-[9px] tracking-widest",
											children: [
												/* @__PURE__ */ _jsxDEV("th", {
													className: "p-3",
													children: "Usuario"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 664,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "p-3",
													children: "Rol"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 665,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "p-3 text-right",
													children: "Acciones"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 666,
													columnNumber: 25
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 663,
											columnNumber: 23
										}, this) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 662,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("tbody", {
											className: "divide-y divide-slate-900",
											children: (usersList || []).map((u) => {
												const isSelf = u.id === user?.id;
												const isEditing = editingUserId === u.id;
												return /* @__PURE__ */ _jsxDEV("tr", {
													className: "hover:bg-slate-900/40 transition-colors",
													children: isEditing ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
														/* @__PURE__ */ _jsxDEV("td", {
															className: "p-3",
															children: /* @__PURE__ */ _jsxDEV("input", {
																type: "text",
																value: editingEmail,
																onChange: (e) => setEditingEmail(e.target.value),
																className: "w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-slate-100"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 679,
																columnNumber: 35
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 678,
															columnNumber: 33
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "p-3 space-y-1.5",
															children: [/* @__PURE__ */ _jsxDEV("select", {
																value: editingRole,
																disabled: isSelf,
																onChange: (e) => setEditingRole(e.target.value),
																className: "w-full px-2 py-1 bg-white text-slate-900 border border-slate-700 rounded text-xs font-semibold",
																children: [
																	/* @__PURE__ */ _jsxDEV("option", {
																		value: "WORKER",
																		className: "text-black",
																		children: "INSPECTOR"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 693,
																		columnNumber: 37
																	}, this),
																	/* @__PURE__ */ _jsxDEV("option", {
																		value: "ADMIN",
																		className: "text-black",
																		children: "ADMIN"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 694,
																		columnNumber: 37
																	}, this),
																	/* @__PURE__ */ _jsxDEV("option", {
																		value: "CLIENT",
																		className: "text-black",
																		children: "CLIENTE"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 695,
																		columnNumber: 37
																	}, this)
																]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 687,
																columnNumber: 35
															}, this), editingRole === "CLIENT" && /* @__PURE__ */ _jsxDEV("select", {
																value: editingCompanyId,
																onChange: (e) => setEditingCompanyId(e.target.value),
																className: "w-full px-2 py-1 bg-white text-slate-900 border border-slate-700 rounded text-xs font-semibold mt-1",
																children: [/* @__PURE__ */ _jsxDEV("option", {
																	value: "",
																	className: "text-black",
																	children: "-- Seleccionar --"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 704,
																	columnNumber: 39
																}, this), companies.map((c) => /* @__PURE__ */ _jsxDEV("option", {
																	value: c.id,
																	className: "text-black",
																	children: c.nombre
																}, c.id, false, {
																	fileName: _jsxFileName,
																	lineNumber: 706,
																	columnNumber: 41
																}, this))]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 699,
																columnNumber: 37
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 686,
															columnNumber: 33
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "p-3 text-right space-y-1 sm:space-y-0 sm:space-x-1 flex flex-col sm:flex-row justify-end",
															children: [/* @__PURE__ */ _jsxDEV("button", {
																onClick: () => handleSaveUserEdit(u.id),
																className: "px-2 py-1 bg-emerald-500 text-slate-950 rounded font-bold hover:bg-emerald-400 text-[10px]",
																children: "Guardar"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 712,
																columnNumber: 35
															}, this), /* @__PURE__ */ _jsxDEV("button", {
																onClick: () => setEditingUserId(null),
																className: "px-2 py-1 bg-slate-800 text-slate-400 rounded hover:bg-slate-700 text-[10px]",
																children: "Cancelar"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 718,
																columnNumber: 35
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 711,
															columnNumber: 33
														}, this)
													] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 677,
														columnNumber: 31
													}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
														/* @__PURE__ */ _jsxDEV("td", {
															className: "p-3 font-mono font-medium truncate max-w-[150px]",
															title: u.username || u.email,
															children: [
																u.username || u.email,
																" ",
																isSelf && /* @__PURE__ */ _jsxDEV("span", {
																	className: "text-[10px] text-amber-500 font-sans font-bold",
																	children: "(Tú)"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 729,
																	columnNumber: 70
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 728,
															columnNumber: 33
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "p-3",
															children: [
																u.role === "ADMIN" && /* @__PURE__ */ _jsxDEV("span", {
																	className: "px-2 py-0.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 text-[9px] font-black tracking-wide",
																	children: "ADMIN"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 733,
																	columnNumber: 37
																}, this),
																u.role === "WORKER" && /* @__PURE__ */ _jsxDEV("span", {
																	className: "px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20 text-[9px] font-black tracking-wide",
																	children: "INSPECTOR"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 738,
																	columnNumber: 37
																}, this),
																u.role === "CLIENT" && /* @__PURE__ */ _jsxDEV("div", {
																	className: "flex flex-col gap-1 items-start",
																	children: [/* @__PURE__ */ _jsxDEV("span", {
																		className: "px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[9px] font-black tracking-wide",
																		children: "CLIENTE"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 744,
																		columnNumber: 39
																	}, this), /* @__PURE__ */ _jsxDEV("span", {
																		className: "text-[9px] text-slate-500 font-mono truncate max-w-[100px]",
																		title: companies.find((c) => c.id === u.companyId)?.nombre || "Sin Empresa",
																		children: ["🏢 ", companies.find((c) => c.id === u.companyId)?.nombre || "Sin Empresa"]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 747,
																		columnNumber: 39
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 743,
																	columnNumber: 37
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 731,
															columnNumber: 33
														}, this),
														/* @__PURE__ */ _jsxDEV("td", {
															className: "p-3 text-right flex items-center justify-end gap-2",
															children: [/* @__PURE__ */ _jsxDEV("button", {
																onClick: () => handleStartEditUser(u),
																className: "px-2.5 py-1 rounded bg-slate-900 border border-slate-800 hover:border-amber-500/40 text-slate-300 hover:text-amber-400 transition-colors font-bold text-[10px] cursor-pointer",
																children: "Editar"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 754,
																columnNumber: 35
															}, this), !isSelf && (u.username || "").toLowerCase() !== "admin1" && /* @__PURE__ */ _jsxDEV("button", {
																onClick: () => handleDeleteUser(u.id),
																className: "px-2 py-1 bg-slate-900 hover:bg-red-955/20 text-slate-500 hover:text-red-400 rounded border border-slate-800 hover:border-red-900/40 transition-all font-bold text-[10px] cursor-pointer",
																children: "Eliminar"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 761,
																columnNumber: 37
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 753,
															columnNumber: 33
														}, this)
													] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 727,
														columnNumber: 31
													}, this)
												}, u.id, false, {
													fileName: _jsxFileName,
													lineNumber: 675,
													columnNumber: 27
												}, this);
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 669,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 661,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 660,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 655,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 572,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-end pt-4 border-t border-slate-800 shrink-0",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setEditingUserId(null);
									setShowUsersModal(false);
								},
								className: "px-5 py-2.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-xl text-xs font-bold text-slate-300 cursor-pointer",
								children: "Cerrar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 782,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 781,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 555,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 552,
				columnNumber: 9
			}, this),
			showChatModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 no-print",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200",
					onClick: () => setShowChatModal(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 799,
					columnNumber: 11
				}, this), !isChatEnabled ? /* @__PURE__ */ _jsxDEV(
					"div",
					/* Pantalla de bloqueo: Módulo en Desarrollo */
					{
						className: "relative w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col items-center text-center space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-center w-full pb-3 border-b border-slate-800 shrink-0",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 806,
										columnNumber: 19
									}, this), "Chat de Soporte e Inspección"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 805,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setShowChatModal(false),
									className: "p-1.5 hover:bg-slate-900 rounded-lg text-slate-500 transition-colors cursor-pointer",
									children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 813,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 809,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 804,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col items-center justify-center py-6 px-2 space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 bg-amber-500/10 text-amber-500 rounded-full animate-pulse border border-amber-500/20",
										children: /* @__PURE__ */ _jsxDEV(Clock, { className: "w-10 h-10" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 819,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 818,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-base font-bold text-slate-100",
										children: "Módulo en Desarrollo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 821,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 max-w-sm leading-relaxed",
										children: "Estamos construyendo un canal de soporte y mensajería en tiempo real para conectar a inspectores, administradores y clientes. Este módulo estará disponible próximamente."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 822,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-full bg-slate-900/40 border border-slate-850 rounded-xl p-4 text-left mt-2 space-y-2",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] font-bold uppercase tracking-wider text-amber-500",
											children: "Características en Desarrollo:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 827,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("ul", {
											className: "text-[11px] text-slate-350 space-y-1.5 list-disc pl-4 font-sans",
											children: [
												/* @__PURE__ */ _jsxDEV("li", { children: "Mensajería instantánea bidireccional." }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 829,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("li", { children: "Soporte técnico directo en campo." }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 830,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("li", { children: "Compartición de tableros e informes." }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 831,
													columnNumber: 21
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 828,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 826,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 817,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowChatModal(false),
								className: "w-full py-3 bg-amber-500 text-slate-950 hover:bg-amber-400 active:scale-95 transition-all font-bold rounded-xl text-xs cursor-pointer shadow-md shrink-0",
								children: "Entendido"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 836,
								columnNumber: 15
							}, this)
						]
					},
					void 0,
					true,
					{
						fileName: _jsxFileName,
						lineNumber: 803,
						columnNumber: 13
					},
					this
				) : 
				/* El chat real completo */
/* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full max-w-4xl bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden animate-in zoom-in-95 duration-200 h-[80vh] flex flex-col",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between items-center pb-4 border-b border-slate-800 shrink-0",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 848,
									columnNumber: 19
								}, this), "Chat de Soporte e Inspección"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 847,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowChatModal(false),
								className: "p-1.5 hover:bg-slate-900 rounded-lg text-slate-500 transition-colors cursor-pointer",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 855,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 851,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 846,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 flex min-h-0 divide-x divide-slate-850 mt-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-1/3 pr-4 flex flex-col min-h-0 overflow-y-auto",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2",
									children: "Contactos Disponibles"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 863,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5 animate-in fade-in duration-200",
									children: getContacts().length > 0 ? getContacts().map((contact) => {
										const isSelected = activeContactId === contact.id;
										return /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setActiveContactId(contact.id);
												markMessagesAsRead(contact.id);
											},
											className: `w-full p-2.5 rounded-xl border text-left transition-all flex flex-col gap-1.5 cursor-pointer ${isSelected ? "bg-amber-500/10 border-amber-500/30 text-amber-400 font-bold" : "bg-slate-900/40 border-slate-850 hover:bg-slate-900/80 text-slate-300"}`,
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between items-center w-full gap-2",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "truncate text-xs font-mono flex-1",
													children: contact.username || contact.email
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 884,
													columnNumber: 31
												}, this), (() => {
													const contactUnreadCount = (messages || []).filter((m) => m.senderId === contact.id && m.receiverId === user?.id && !m.read).length;
													return contactUnreadCount > 0 ? /* @__PURE__ */ _jsxDEV("span", {
														className: "bg-red-500 text-white rounded-full text-[9px] px-1.5 py-0.5 font-bold flex items-center justify-center animate-pulse shrink-0",
														children: contactUnreadCount
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 892,
														columnNumber: 35
													}, this) : null;
												})()]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 883,
												columnNumber: 29
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: contact.role === "ADMIN" ? /* @__PURE__ */ _jsxDEV("span", {
												className: "px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-500 text-[8px] font-bold",
												children: "ADMINISTRADOR"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 900,
												columnNumber: 33
											}, this) : contact.role === "WORKER" ? /* @__PURE__ */ _jsxDEV("span", {
												className: "px-1.5 py-0.5 rounded bg-sky-500/15 text-sky-400 text-[8px] font-bold",
												children: "INSPECTOR"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 902,
												columnNumber: 33
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400 text-[8px] font-bold",
												children: "CLIENTE"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 904,
												columnNumber: 33
											}, this) }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 898,
												columnNumber: 29
											}, this)]
										}, contact.id, true, {
											fileName: _jsxFileName,
											lineNumber: 871,
											columnNumber: 27
										}, this);
									}) : /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-500 italic text-center py-6",
										children: "No hay destinatarios disponibles para tu rol."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 911,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 866,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 862,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "w-2/3 pl-4 flex flex-col min-h-0",
								children: activeContactId ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "pb-3 border-b border-slate-900 flex justify-between items-center shrink-0",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "truncate",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs font-bold text-slate-100 font-mono",
												children: usersList.find((u) => u.id === activeContactId)?.username || usersList.find((u) => u.id === activeContactId)?.email
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 923,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-[9px] text-slate-550 font-mono",
												children: ["Rol: ", usersList.find((u) => u.id === activeContactId)?.role]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 926,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 922,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 921,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 overflow-y-auto py-4 space-y-3.5 pr-1 font-sans",
										children: getActiveMessages().length > 0 ? getActiveMessages().map((msg) => {
											const isMe = msg.senderId === user?.id;
											return /* @__PURE__ */ _jsxDEV("div", {
												className: `flex flex-col ${isMe ? "items-end" : "items-start"}`,
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: `px-3.5 py-2 text-xs rounded-2xl max-w-[80%] ${isMe ? "bg-amber-500 text-slate-950 font-semibold rounded-tr-none shadow-md shadow-amber-500/5" : "bg-slate-900 border border-slate-800 text-slate-100 rounded-tl-none"}`,
													children: /* @__PURE__ */ _jsxDEV("p", {
														className: "leading-relaxed whitespace-pre-wrap select-text",
														children: msg.text
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 944,
														columnNumber: 35
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 939,
													columnNumber: 33
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[8px] text-slate-555 font-mono mt-1 px-1",
													children: [
														isMe ? "Tú" : msg.senderUsername || msg.senderEmail || "Anónimo",
														" • ",
														new Date(msg.createdAt).toLocaleTimeString("es-ES", {
															hour: "2-digit",
															minute: "2-digit"
														})
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 946,
													columnNumber: 33
												}, this)]
											}, msg.id, true, {
												fileName: _jsxFileName,
												lineNumber: 938,
												columnNumber: 31
											}, this);
										}) : /* @__PURE__ */ _jsxDEV("div", {
											className: "h-full flex flex-col items-center justify-center text-slate-650 space-y-2 select-none",
											children: [/* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-8 h-8 opacity-20" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 954,
												columnNumber: 29
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-[11px] italic",
												children: "No hay mensajes. Escribe algo abajo para iniciar."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 955,
												columnNumber: 29
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 953,
											columnNumber: 27
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 933,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("form", {
										onSubmit: handleSendMessage,
										className: "pt-3 border-t border-slate-900 flex gap-2 shrink-0",
										children: [/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											required: true,
											value: chatMessageText,
											onChange: (e) => setChatMessageText(e.target.value),
											placeholder: "Escribe un mensaje de soporte...",
											className: "flex-1 px-3 py-2 bg-slate-900 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-xl text-xs text-slate-100 placeholder-slate-650 focus:outline-none h-10"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 962,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "submit",
											className: "px-4 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 text-xs font-bold rounded-xl cursor-pointer shadow-md",
											children: "Enviar"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 970,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 961,
										columnNumber: 23
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 919,
									columnNumber: 21
								}, this) : /* @__PURE__ */ _jsxDEV("div", {
									className: "flex-1 flex flex-col items-center justify-center text-slate-600 space-y-2.5 select-none",
									children: [
										/* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-12 h-12 opacity-15 animate-bounce" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 980,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-bold",
											children: "Selecciona un contacto del panel izquierdo para chatear"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 981,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] text-slate-550 text-center max-w-xs leading-normal",
											children: "Los administradores chatean con trabajadores y clientes. Los trabajadores con administradores y clientes. Los clientes solo con administradores."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 982,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 979,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 917,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 859,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-end pt-4 border-t border-slate-850 shrink-0 mt-4",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowChatModal(false),
								className: "px-5 py-2.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-xl text-xs font-bold text-slate-300 cursor-pointer",
								children: "Cerrar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 992,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 991,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 845,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 798,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 261,
		columnNumber: 5
	}, this);
};
_s(SidebarLayout, "NjZlMkN2xn1Y8YnPL/ghjhTzvaM=", false, function() {
	return [
		useStore,
		useConfirm,
		useNavigate,
		useLocation
	];
});
_c = SidebarLayout;
export default SidebarLayout;
var _c;
$RefreshReg$(_c, "SidebarLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SidebarLayout.jsx?t=1790792337841";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SidebarLayout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SidebarLayout.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/SidebarLayout.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsUUFBUSxhQUFhLGFBQWEsWUFBWTtBQUN2RCxPQUFPLGNBQWM7QUFDckIsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTyxRQUFRO0FBQ2YsU0FBUyxvQkFBb0I7QUFDN0IsU0FDRSxXQUNBLFlBQ0EsVUFDQSxRQUNBLE1BQ0EsR0FDQSxLQUNBLE1BQ0EsYUFDQSxVQUNBLFdBQ0EsVUFDQSxPQUNBLFVBQ0EsYUFDQSxPQUNBLGVBQ0EsYUFDQSxjQUNBLE9BQ0EsUUFDQSxXQUNBLE1BQ0EsaUJBQ0s7Ozs7QUFFUCxPQUFPLE1BQU0sc0JBQXNCOztDQUNqQyxNQUFNLGdCQUFnQjtDQUN0QixNQUFNLEVBQ0osTUFDQSxPQUNBLFFBQ0EsV0FDQSxpQkFDQSxXQUNBLFNBQ0EsWUFDQSxZQUNBLFVBQ0EsYUFDQSxRQUNBLFdBQ0Esb0JBQ0Esb0JBQ0EsZ0JBQ0EsbUJBQ0EsY0FDRSxTQUFTO0NBRWIsTUFBTSxFQUFFLFlBQVksV0FBVztDQUUvQixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTs7Q0FHN0IsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSzs7Q0FHdEQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxLQUFLO0NBQzlELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsS0FBSztDQUMxRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLOztDQUd4RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFO0NBQ25ELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsRUFBRTtDQUN6RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxRQUFRO0NBQ3ZELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsRUFBRTtDQUUzRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxJQUFJO0NBQ3ZELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEVBQUU7Q0FDbkQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFO0NBQ3pELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLFFBQVE7Q0FDdkQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxFQUFFOztDQUczRCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLElBQUk7Q0FDM0QsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFO0NBQ3pELE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsS0FBSzs7Q0FHbEUsZ0JBQWdCO0VBQ2QsSUFBSSxpQkFBaUIsUUFBUSxVQUFVLFFBQVE7R0FDN0MsZUFBZTtHQUNmLGtCQUFrQixLQUFLLEVBQUU7R0FFekIsTUFBTSxpQkFBaUIsR0FBRyxZQUFZO0dBRXRDLGVBQWUsR0FBRyxpQkFBaUI7SUFDakMsUUFBUSxJQUFJLG9DQUFvQztJQUNoRCxlQUFlLEtBQUssaUJBQWlCLEtBQUssRUFBRTtHQUM5QyxDQUFDO0dBRUQsZUFBZSxHQUFHLG9CQUFvQixRQUFRO0lBQzVDLG1CQUFtQixHQUFHO0dBQ3hCLENBQUM7R0FFRCxVQUFVLGNBQWM7R0FFeEIsYUFBYTtJQUNYLGVBQWUsV0FBVztJQUMxQixVQUFVLElBQUk7R0FDaEI7RUFDRjtDQUNGLEdBQUcsQ0FBQyxJQUFJLENBQUM7O0NBR1QsZ0JBQWdCO0VBQ2QsSUFBSSxRQUFRLFVBQVUsUUFBUTtHQUM1QixlQUFlO0VBQ2pCO0NBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQzs7Q0FHVCxnQkFBZ0I7RUFDZCxJQUFJLGlCQUFpQixpQkFBaUI7R0FDcEMsbUJBQW1CLGVBQWU7RUFDcEM7Q0FDRixHQUFHO0VBQUM7RUFBZTtFQUFpQjtDQUFRLENBQUM7Q0FFN0MsTUFBTSxxQkFBcUI7RUFDekIsSUFBSSxRQUFRO0dBQ1YsT0FBTyxXQUFXO0dBQ2xCLFVBQVUsSUFBSTtFQUNoQjtFQUNBLE9BQU87RUFDUCxTQUFTLFFBQVE7Q0FDbkI7O0NBR0EsZ0JBQWdCO0VBQ2QsZ0JBQWdCLEtBQUs7Q0FDdkIsR0FBRyxDQUFDLFNBQVMsUUFBUSxDQUFDOztDQUd0QixNQUFNLGdCQUFnQixPQUFPLE1BQU07RUFDakMsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxDQUFDLGdCQUFnQixLQUFLLEdBQUc7R0FDbkQsVUFBVSx3Q0FBd0MsU0FBUztHQUMzRDtFQUNGO0VBQ0EsTUFBTSxTQUFTLE1BQU0sUUFBUTtHQUMzQixVQUFVLGFBQWEsS0FBSztHQUM1QixPQUFPLGFBQWEsS0FBSztHQUN6QixVQUFVLGdCQUFnQixLQUFLO0dBQy9CLE1BQU07R0FDTixXQUFXLGdCQUFnQixXQUFXLG1CQUFtQjtFQUMzRCxDQUFDO0VBQ0QsSUFBSSxPQUFPLFNBQVM7R0FDbEIsZ0JBQWdCLEVBQUU7R0FDbEIsbUJBQW1CLEVBQUU7R0FDckIsZUFBZSxRQUFRO0dBQ3ZCLG9CQUFvQixFQUFFO0dBQ3RCLFVBQVUsaUNBQWlDLFNBQVM7RUFDdEQsT0FBTztHQUNMLFVBQVUsT0FBTyxTQUFTLCtCQUErQixPQUFPO0VBQ2xFO0NBQ0Y7O0NBR0EsTUFBTSxxQkFBcUIsT0FBTyxXQUFXO0VBQzNDLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxDQUFDLGdCQUFnQixLQUFLLEdBQUc7R0FDbkQsVUFBVSx3Q0FBd0MsU0FBUztHQUMzRDtFQUNGO0VBQ0EsTUFBTSxTQUFTLE1BQU0sV0FBVyxRQUFRO0dBQ3RDLFVBQVUsYUFBYSxLQUFLO0dBQzVCLE9BQU8sYUFBYSxLQUFLO0dBQ3pCLFVBQVUsZ0JBQWdCLEtBQUs7R0FDL0IsTUFBTTtHQUNOLFdBQVcsZ0JBQWdCLFdBQVcsbUJBQW1CO0VBQzNELENBQUM7RUFDRCxJQUFJLE9BQU8sU0FBUztHQUNsQixpQkFBaUIsSUFBSTtHQUNyQixvQkFBb0IsRUFBRTtHQUN0QixVQUFVLGtDQUFrQyxTQUFTO0VBQ3ZELE9BQU87R0FDTCxVQUFVLE9BQU8sU0FBUyxnQ0FBZ0MsT0FBTztFQUNuRTtDQUNGO0NBRUEsTUFBTSx1QkFBdUIsTUFBTTtFQUNqQyxpQkFBaUIsRUFBRSxFQUFFO0VBQ3JCLGdCQUFnQixFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUU7RUFDM0MsbUJBQW1CLEVBQUUsUUFBUTtFQUM3QixlQUFlLEVBQUUsSUFBSTtFQUNyQixvQkFBb0IsRUFBRSxhQUFhLEVBQUU7Q0FDdkM7Q0FFQSxNQUFNLG1CQUFtQixPQUFPLFdBQVc7RUFDekMsTUFBTSxLQUFLLE1BQU0sUUFBUTtHQUN2QixPQUFPO0dBQ1AsU0FBUztHQUNULE1BQU07R0FDTixhQUFhO0VBQ2YsQ0FBQztFQUVELElBQUksSUFBSTtHQUNOLE1BQU0sU0FBUyxNQUFNLFdBQVcsTUFBTTtHQUN0QyxJQUFJLE9BQU8sU0FBUztJQUNsQixVQUFVLGdDQUFnQyxTQUFTO0dBQ3JELE9BQU87SUFDTCxVQUFVLE9BQU8sU0FBUyw4QkFBOEIsT0FBTztHQUNqRTtFQUNGO0NBQ0Y7O0NBR0EsTUFBTSxvQkFBb0I7RUFDeEIsSUFBSSxDQUFDLFdBQVcsT0FBTyxDQUFDO0VBQ3hCLElBQUksTUFBTSxTQUFTLFNBQVM7R0FDMUIsT0FBTyxVQUFVLFFBQVEsTUFBTSxFQUFFLE9BQU8sS0FBSyxPQUFPLEVBQUUsU0FBUyxXQUFXLEVBQUUsU0FBUyxZQUFZLEVBQUUsU0FBUyxTQUFTO0VBQ3ZILE9BQU8sSUFBSSxNQUFNLFNBQVMsVUFBVTtHQUNsQyxPQUFPLFVBQVUsUUFBUSxNQUFNLEVBQUUsT0FBTyxLQUFLLE9BQU8sRUFBRSxTQUFTLFdBQVcsRUFBRSxTQUFTLFNBQVM7RUFDaEcsT0FBTyxJQUFJLE1BQU0sU0FBUyxVQUFVO0dBQ2xDLE9BQU8sVUFBVSxRQUFRLE1BQU0sRUFBRSxPQUFPLEtBQUssTUFBTSxFQUFFLFNBQVMsT0FBTztFQUN2RTtFQUNBLE9BQU8sQ0FBQztDQUNWO0NBRUEsTUFBTSxxQkFBcUIsTUFBTTtFQUMvQixFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLGdCQUFnQixLQUFLLEtBQUssQ0FBQyxpQkFBaUI7RUFDakQsWUFBWSxpQkFBaUIsZ0JBQWdCLEtBQUssQ0FBQztFQUNuRCxtQkFBbUIsRUFBRTtDQUN2QjtDQUVBLE1BQU0sMEJBQTBCO0VBQzlCLElBQUksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLE9BQU8sQ0FBQztFQUMzQyxPQUFPLFNBQVMsUUFDYixNQUNFLEVBQUUsYUFBYSxNQUFNLE1BQU0sRUFBRSxlQUFlLG1CQUM1QyxFQUFFLGFBQWEsbUJBQW1CLEVBQUUsZUFBZSxNQUFNLEVBQzlEO0NBQ0Y7Q0FFQSxNQUFNLG1CQUFtQixpQkFBaUIsWUFBWSxDQUFDLEVBQUMsQ0FBRSxRQUFRLE1BQU0sRUFBRSxlQUFlLE1BQU0sTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsU0FBUztDQUV2SCxNQUFNLFdBQVcsQ0FDZjtFQUFFLE1BQU07RUFBWSxNQUFNO0VBQUssTUFBTTtDQUFVLEdBQy9DO0VBQUUsTUFBTTtFQUFxQixlQUFlLGlCQUFpQixJQUFJO0VBQUcsTUFBTTtDQUFjLENBQzFGO0NBRUEsSUFBSSxNQUFNLFNBQVMsU0FBUztFQUMxQixTQUFTLEtBQUs7R0FBRSxNQUFNO0dBQXVCLGVBQWUsa0JBQWtCLElBQUk7R0FBRyxNQUFNO0VBQU0sQ0FBQztDQUNwRztDQUVBLFNBQVMsS0FDUDtFQUFFLE1BQU07RUFBd0IsTUFBTTtFQUFhLE1BQU07Q0FBUyxHQUNsRTtFQUFFLE1BQU07RUFBdUIsTUFBTTtFQUFZLE1BQU07Q0FBUyxDQUNsRTtDQUdBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUdFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQ0Usd0JBQUMsTUFBRDtLQUFNLElBQUc7S0FBSSxXQUFVO2VBQXZCLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsS0FBRCxFQUFLLFdBQVUsd0NBQXlDOzs7OztLQUNyRDs7OztlQUNMLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFrRTtLQUFlOzs7O2FBQzdGOzs7OztjQUNOLHdCQUFDLFVBQUQ7S0FDRSxlQUFlLGdCQUFnQixDQUFDLFlBQVk7S0FDNUMsV0FBVTtlQUVULGVBQWUsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7OztnQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztJQUNqRTs7OztZQUNGOzs7Ozs7R0FHUCxnQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBb0QsZUFBZSxnQkFBZ0IsS0FBSztJQUFJOzs7O2NBQzNHLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFNLElBQUc7UUFBSSxXQUFVO2tCQUF2QixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLEtBQUQsRUFBSyxXQUFVLHlCQUEwQjs7Ozs7UUFDdEM7Ozs7a0JBQ0wsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWtFO1FBQWU7Ozs7Z0JBQzdGOzs7OztpQkFDTix3QkFBQyxVQUFEO1FBQVEsZUFBZSxnQkFBZ0IsS0FBSztRQUFHLFdBQVU7a0JBQ3ZELHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O09BQ2xCOzs7O2VBQ0w7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLFNBQVMsS0FBSyxTQUFTO1FBQ3RCLE1BQU0sT0FBTyxLQUFLO1FBQ2xCLE1BQU0sV0FBVyxLQUFLLE9BQ2pCLFNBQVMsYUFBYSxLQUFLLFFBQVMsS0FBSyxTQUFTLGNBQWMsU0FBUyxhQUFhLFlBQ3ZGO1FBQ0osT0FBTyxLQUFLLE9BQ1Ysd0JBQUMsTUFBRDtTQUVFLElBQUksS0FBSztTQUNULFdBQVcsd0ZBQ1QsV0FDSSx1REFDQTttQkFOUixDQVNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7bUJBQzNCLHdCQUFDLFFBQUQsWUFBTyxLQUFLLEtBQVc7Ozs7aUJBQ25CO1dBVkMsS0FBSzs7OztlQVVOLElBRU4sd0JBQUMsVUFBRDtTQUVFLGVBQWU7VUFDYixnQkFBZ0IsS0FBSztVQUNyQixLQUFLLFFBQVE7U0FDZjtTQUNBLFdBQVU7bUJBTlo7VUFRRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztVQUMzQix3QkFBQyxRQUFELFlBQU8sS0FBSyxLQUFXOzs7OztVQUN0QixLQUFLLFNBQVMsdUJBQXVCLG1CQUFtQixLQUN2RCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYjtVQUNHOzs7OztTQUVGO1dBZEQsS0FBSzs7OztlQWNKO09BRVosQ0FBQztNQUNFOzs7O2NBQ0Y7Ozs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLDZCQUE4Qjs7OztpQkFDOUMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBMkQ7UUFBaUI7Ozs7a0JBQ3pGLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFpRCxNQUFNLFlBQVksTUFBTTtRQUFTOzs7O2dCQUM1Rjs7Ozs7ZUFDRjs7Ozs7Z0JBQ0wsd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxXQUFVO2lCQUZaLENBSUUsd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7OztpQkFBQyxnQkFDeEI7Ozs7O2NBQ0w7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUlQLHdCQUFDLFNBQUQ7SUFBTyxXQUFXLDhLQUNoQixxQkFBcUIsYUFBYTtjQURwQztLQUtFLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLHNCQUFzQixDQUFDLGtCQUFrQjtNQUN4RCxXQUFVO01BQ1YsT0FBTyxxQkFBcUIsa0JBQWtCO2dCQUU3QyxxQkFBcUIsd0JBQUMsY0FBRCxFQUFjLFdBQVUsY0FBZTs7OztpQkFBSSx3QkFBQyxhQUFELEVBQWEsV0FBVSxjQUFlOzs7OztLQUNqRzs7Ozs7S0FFUix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE1BQUQ7UUFBTSxJQUFHO1FBQUksV0FBVTtrQkFBdkIsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxLQUFELEVBQUssV0FBVSx3Q0FBeUM7Ozs7O1FBQ3JEOzs7O2tCQUNKLENBQUMsc0JBQ0Esd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUY7U0FBZTs7OzttQkFDaEgsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlFO1NBQXVCOzs7O2lCQUNyRzs7Ozs7Z0JBRUg7Ozs7OztNQUNIOzs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0csQ0FBQyxzQkFDQSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaUg7T0FFM0g7Ozs7aUJBRVAsU0FBUyxLQUFLLFNBQVM7UUFDdEIsTUFBTSxPQUFPLEtBQUs7UUFDbEIsTUFBTSxXQUFXLEtBQUssT0FDakIsU0FBUyxhQUFhLEtBQUssUUFBUyxLQUFLLFNBQVMsY0FBYyxTQUFTLGFBQWEsWUFDdkY7UUFDSixPQUFPLEtBQUssT0FDVix3QkFBQyxNQUFEO1NBRUUsSUFBSSxLQUFLO1NBQ1QsT0FBTyxxQkFBcUIsS0FBSyxPQUFPO1NBQ3hDLFdBQVcsd0VBQ1QscUJBQXFCLHVCQUF1QixvQkFDN0MsSUFDQyxXQUNJLHVEQUNBO21CQVRSLENBWUUsd0JBQUMsTUFBRCxFQUFNLFdBQVUsbUJBQW9COzs7O21CQUNuQyxDQUFDLHNCQUFzQix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBbUMsS0FBSztTQUFXOzs7O2lCQUN2RjtXQWJDLEtBQUs7Ozs7ZUFhTixJQUVOLHdCQUFDLFVBQUQ7U0FFRSxTQUFTLEtBQUs7U0FDZCxPQUFPLHFCQUFxQixLQUFLLE9BQU87U0FDeEMsV0FBVywwTUFDVCxxQkFBcUIsdUJBQXVCO21CQUxoRDtVQVFFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLG1CQUFvQjs7Ozs7VUFDbkMsQ0FBQyxzQkFBc0Isd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQW1DLEtBQUs7VUFBVzs7Ozs7VUFDMUYsS0FBSyxTQUFTLHVCQUF1QixtQkFBbUIsTUFDdkQscUJBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsdUdBQXdHOzs7O3FCQUV4SCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYjtVQUNHOzs7OztTQUdKO1dBbEJELEtBQUs7Ozs7ZUFrQko7T0FFWixDQUFDLENBQ0U7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVcsd0VBQ2QscUJBQXFCLHlCQUF5QjtpQkFEaEQsQ0FHRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSw2QkFBOEI7Ozs7O09BQzNDOzs7O2lCQUNKLENBQUMsc0JBQ0Esd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixNQUFNLFNBQVMsVUFBVSxxQkFBcUI7UUFDOUM7Ozs7a0JBQ0gsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTZDLE1BQU0sWUFBWSxNQUFNO1FBQVM7Ozs7Z0JBQ3hGOzs7OztlQUVKOzs7OztnQkFFTCx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULE9BQU8scUJBQXFCLGtCQUFrQjtPQUM5QyxXQUFXLHlOQUNULHFCQUFxQixRQUFRO2lCQUpqQyxDQU9FLHdCQUFDLFFBQUQsRUFBUSxXQUFVLG1CQUFvQjs7OztpQkFDckMsQ0FBQyxzQkFBc0Isd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWtDO09BQW1COzs7O2VBQ3ZGOzs7OztjQUNMOzs7Ozs7SUFDQTs7Ozs7O0dBR1Asd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxRQUFELENBQVM7Ozs7O0dBQ047Ozs7O0dBR0osb0JBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQW9GLGVBQWUsb0JBQW9CLEtBQUs7SUFBSTs7OztjQUUvSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OztpQkFBQyxrQ0FFN0M7Ozs7O2dCQUNKLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLG9CQUFvQixLQUFLO09BQ3hDLFdBQVU7aUJBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7TUFDbEI7Ozs7Y0FDTDs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFtRDtPQUU3RDs7Ozs7T0FFSCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWjtTQUNDO1VBQ0UsT0FBTztVQUNQLE1BQU07VUFDTixNQUFNO1VBQ04sT0FBTztTQUNUO1NBQ0E7VUFDRSxPQUFPO1VBQ1AsTUFBTTtVQUNOLE1BQU07VUFDTixPQUFPO1NBQ1Q7U0FDQTtVQUNFLE9BQU87VUFDUCxNQUFNO1VBQ04sTUFBTTtVQUNOLE9BQU87U0FDVDtRQUNGLENBQUMsQ0FBQyxLQUFLLE1BQU0sUUFBUTtTQUNuQixNQUFNLE9BQU8sS0FBSztTQUNsQixPQUNFLHdCQUFDLE9BQUQ7VUFBZSxXQUFXLCtEQUErRCxLQUFLO29CQUE5RixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7O1VBQ3hCOzs7O29CQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQW9DLEtBQUs7V0FBVTs7OztxQkFDakUsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQStDLEtBQUs7V0FBUTs7OzttQkFDdEU7Ozs7O2tCQUNGO1lBUks7Ozs7Z0JBUUw7UUFFVCxDQUFDO09BQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsVUFBRDtTQUNFLGVBQWUsb0JBQW9CLEtBQUs7U0FDeEMsV0FBVTttQkFDWDtRQUVPOzs7OztPQUNMOzs7OztNQUNGOzs7OzthQUNGOzs7OztZQUNGOzs7Ozs7R0FJTixrQkFBa0IsTUFBTSxTQUFTLFdBQ2hDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFvRixlQUFlLGtCQUFrQixLQUFLO0lBQUk7Ozs7Y0FFN0ksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSx5QkFBMEI7Ozs7a0JBQUMsNkJBRTFDOzs7OztpQkFDSix3QkFBQyxVQUFEO1FBQ0UsZUFBZTtTQUNiLGlCQUFpQixJQUFJO1NBQ3JCLGtCQUFrQixLQUFLO1FBQ3pCO1FBQ0EsV0FBVTtrQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztPQUNsQjs7OztlQUNMOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUdFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQTRGO1NBRXRHOzs7OztTQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUE0QztTQUV0RDs7Ozs7U0FFSCx3QkFBQyxRQUFEO1VBQU0sVUFBVTtVQUFlLFdBQVU7b0JBQXpDO1dBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUEwRTtXQUVwRjs7OztxQkFDUCx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMO1lBQ0EsT0FBTztZQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7WUFDL0MsYUFBWTtZQUNaLFdBQVU7V0FDWDs7OzttQkFDRTs7Ozs7V0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQTBFO1dBRXBGOzs7O3FCQUNQLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0w7WUFDQSxPQUFPO1lBQ1AsV0FBVyxNQUFNLG1CQUFtQixFQUFFLE9BQU8sS0FBSztZQUNsRCxhQUFZO1lBQ1osV0FBVTtXQUNYOzs7O21CQUNFOzs7OztXQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBMEU7V0FFcEY7Ozs7cUJBQ1Asd0JBQUMsVUFBRDtZQUNFLE9BQU87WUFDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztZQUM5QyxXQUFVO3NCQUhaO2FBS0Usd0JBQUMsVUFBRDtjQUFRLE9BQU07Y0FBUyxXQUFVO3dCQUFzQjthQUFpQzs7Ozs7YUFDeEYsd0JBQUMsVUFBRDtjQUFRLE9BQU07Y0FBUSxXQUFVO3dCQUFzQjthQUF3Qjs7Ozs7YUFDOUUsd0JBQUMsVUFBRDtjQUFRLE9BQU07Y0FBUyxXQUFVO3dCQUFzQjthQUE0Qjs7Ozs7WUFDN0U7Ozs7O21CQUNMOzs7OztXQUVKLGdCQUFnQixZQUNmLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsU0FBRDthQUFPLFdBQVU7dUJBQTBFO1lBRXBGOzs7O3NCQUNQLHdCQUFDLFVBQUQ7YUFDRSxPQUFPO2FBQ1AsV0FBVyxNQUFNLG9CQUFvQixFQUFFLE9BQU8sS0FBSzthQUNuRCxXQUFVO3VCQUhaLENBS0Usd0JBQUMsVUFBRDtjQUFRLE9BQU07Y0FBRyxXQUFVO3dCQUFhO2FBQWlDOzs7O3VCQUN4RSxVQUFVLEtBQUssTUFDZCx3QkFBQyxVQUFEO2NBQW1CLE9BQU8sRUFBRTtjQUFJLFdBQVU7d0JBQWMsRUFBRTthQUFlLEdBQTVELEVBQUU7Ozs7b0JBQTBELENBQzFFLENBQ0s7Ozs7O29CQUNMOzs7Ozs7V0FHUCx3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLFdBQVU7c0JBQ1g7V0FFTzs7Ozs7VUFDSjs7Ozs7O1FBQ0g7Ozs7O2lCQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQ7VUFBMEc7VUFDakYsV0FBVyxVQUFVO1VBQUU7U0FDNUM7Ozs7O2tCQUVKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBZDtZQUNFLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFNO1lBQVc7Ozs7O1lBQy9CLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFNO1lBQU87Ozs7O1lBQzNCLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFpQjtZQUFZOzs7OztXQUN6Qzs7Ozs7bUJBQ0M7Ozs7b0JBQ1Asd0JBQUMsU0FBRDtXQUFPLFdBQVU7c0JBQ2IsYUFBYSxDQUFDLEVBQUMsQ0FBRSxLQUFLLE1BQU07WUFDNUIsTUFBTSxTQUFTLEVBQUUsT0FBTyxNQUFNO1lBQzlCLE1BQU0sWUFBWSxrQkFBa0IsRUFBRTtZQUV0QyxPQUNFLHdCQUFDLE1BQUQ7YUFBZSxXQUFVO3VCQUN0QixZQUNDO2NBQ0Usd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQ1osd0JBQUMsU0FBRDtnQkFDRSxNQUFLO2dCQUNMLE9BQU87Z0JBQ1AsV0FBVyxNQUFNLGdCQUFnQixFQUFFLE9BQU8sS0FBSztnQkFDL0MsV0FBVTtlQUNYOzs7OztjQUNDOzs7OztjQUNKLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUFkLENBQ0Usd0JBQUMsVUFBRDtnQkFDRSxPQUFPO2dCQUNQLFVBQVU7Z0JBQ1YsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7Z0JBQzlDLFdBQVU7MEJBSlo7aUJBTUUsd0JBQUMsVUFBRDtrQkFBUSxPQUFNO2tCQUFTLFdBQVU7NEJBQWE7aUJBQWlCOzs7OztpQkFDL0Qsd0JBQUMsVUFBRDtrQkFBUSxPQUFNO2tCQUFRLFdBQVU7NEJBQWE7aUJBQWE7Ozs7O2lCQUMxRCx3QkFBQyxVQUFEO2tCQUFRLE9BQU07a0JBQVMsV0FBVTs0QkFBYTtpQkFBZTs7Ozs7Z0JBQ3ZEOzs7Ozt5QkFFUCxnQkFBZ0IsWUFDZix3QkFBQyxVQUFEO2dCQUNFLE9BQU87Z0JBQ1AsV0FBVyxNQUFNLG9CQUFvQixFQUFFLE9BQU8sS0FBSztnQkFDbkQsV0FBVTswQkFIWixDQUtFLHdCQUFDLFVBQUQ7aUJBQVEsT0FBTTtpQkFBRyxXQUFVOzJCQUFhO2dCQUF5Qjs7OzswQkFDaEUsVUFBVSxLQUFLLE1BQ2Qsd0JBQUMsVUFBRDtpQkFBbUIsT0FBTyxFQUFFO2lCQUFJLFdBQVU7MkJBQWMsRUFBRTtnQkFBZSxHQUE1RCxFQUFFOzs7O3VCQUEwRCxDQUMxRSxDQUNLOzs7Ozt1QkFFUjs7Ozs7O2NBQ0osd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQWQsQ0FDRSx3QkFBQyxVQUFEO2dCQUNFLGVBQWUsbUJBQW1CLEVBQUUsRUFBRTtnQkFDdEMsV0FBVTswQkFDWDtlQUVPOzs7O3lCQUNSLHdCQUFDLFVBQUQ7Z0JBQ0UsZUFBZSxpQkFBaUIsSUFBSTtnQkFDcEMsV0FBVTswQkFDWDtlQUVPOzs7O3VCQUNOOzs7Ozs7YUFDSjs7Ozt3QkFFRjtjQUNFLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO2VBQW1ELE9BQU8sRUFBRSxZQUFZLEVBQUU7eUJBQXhGO2dCQUNHLEVBQUUsWUFBWSxFQUFFO2dCQUFNO2dCQUFFLFVBQVUsd0JBQUMsUUFBRDtpQkFBTSxXQUFVOzJCQUFpRDtnQkFBVTs7Ozs7ZUFDNUc7Ozs7OztjQUNKLHdCQUFDLE1BQUQ7ZUFBSSxXQUFVO3lCQUFkO2dCQUNHLEVBQUUsU0FBUyxXQUNWLHdCQUFDLFFBQUQ7aUJBQU0sV0FBVTsyQkFBb0g7Z0JBRTlIOzs7OztnQkFFUCxFQUFFLFNBQVMsWUFDVix3QkFBQyxRQUFEO2lCQUFNLFdBQVU7MkJBQThHO2dCQUV4SDs7Ozs7Z0JBRVAsRUFBRSxTQUFTLFlBQ1Ysd0JBQUMsT0FBRDtpQkFBSyxXQUFVOzJCQUFmLENBQ0Usd0JBQUMsUUFBRDtrQkFBTSxXQUFVOzRCQUEwSDtpQkFFcEk7Ozs7MkJBQ04sd0JBQUMsUUFBRDtrQkFBTSxXQUFVO2tCQUE2RCxPQUFPLFVBQVUsTUFBSyxNQUFLLEVBQUUsT0FBTyxFQUFFLFNBQVMsQ0FBQyxFQUFFLFVBQVU7NEJBQXpJLENBQXdKLE9BQ2xKLFVBQVUsTUFBSyxNQUFLLEVBQUUsT0FBTyxFQUFFLFNBQVMsQ0FBQyxFQUFFLFVBQVUsYUFDckQ7Ozs7O3lCQUNIOzs7Ozs7ZUFFTDs7Ozs7O2NBQ0osd0JBQUMsTUFBRDtlQUFJLFdBQVU7eUJBQWQsQ0FDRSx3QkFBQyxVQUFEO2dCQUNFLGVBQWUsb0JBQW9CLENBQUM7Z0JBQ3BDLFdBQVU7MEJBQ1g7ZUFFTzs7Ozt5QkFDUCxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUUsQ0FBRSxZQUFZLE1BQU0sWUFDL0Msd0JBQUMsVUFBRDtnQkFDRSxlQUFlLGlCQUFpQixFQUFFLEVBQUU7Z0JBQ3BDLFdBQVU7MEJBQ1g7ZUFFTzs7Ozt1QkFFUjs7Ozs7O2FBQ0o7Ozs7O1lBRUYsR0FoR0ssRUFBRTs7OzttQkFnR1A7V0FFUixDQUFDO1VBQ0k7Ozs7a0JBQ0Y7Ozs7OztRQUNKOzs7O2dCQUNGOzs7OztlQUVGOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFEO1FBQ0UsZUFBZTtTQUNiLGlCQUFpQixJQUFJO1NBQ3JCLGtCQUFrQixLQUFLO1FBQ3pCO1FBQ0EsV0FBVTtrQkFDWDtPQUVPOzs7OztNQUNMOzs7OztLQUNGOzs7OztZQUNGOzs7Ozs7R0FJTixpQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBb0YsZUFBZSxpQkFBaUIsS0FBSztJQUFJOzs7O2NBRTNJLENBQUMsZ0JBRUE7S0FBQzs7S0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkLENBQ0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUseUJBQTBCOzs7O21CQUFDLDhCQUVsRDs7Ozs7a0JBQ0osd0JBQUMsVUFBRDtTQUNFLGVBQWUsaUJBQWlCLEtBQUs7U0FDckMsV0FBVTttQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztRQUNsQjs7OztnQkFDTDs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxPQUFELEVBQU8sV0FBVSxZQUFhOzs7OztTQUMzQjs7Ozs7U0FDTCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBcUM7U0FBd0I7Ozs7O1NBQzNFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFrRDtTQUU1RDs7Ozs7U0FFSCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFnRTtVQUFpQzs7OztvQkFDOUcsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWQ7WUFDRSx3QkFBQyxNQUFELFlBQUksd0NBQXlDOzs7OztZQUM3Qyx3QkFBQyxNQUFELFlBQUksb0NBQXFDOzs7OztZQUN6Qyx3QkFBQyxNQUFELFlBQUksdUNBQXdDOzs7OztXQUMxQzs7Ozs7a0JBQ0Q7Ozs7OztRQUNGOzs7Ozs7T0FFTCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxpQkFBaUIsS0FBSztRQUNyQyxXQUFVO2tCQUNYO09BRU87Ozs7O01BQ0w7Ozs7Ozs7Ozs7OztBQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUseUJBQTBCOzs7O2tCQUFDLDhCQUVsRDs7Ozs7aUJBQ0osd0JBQUMsVUFBRDtRQUNFLGVBQWUsaUJBQWlCLEtBQUs7UUFDckMsV0FBVTtrQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztPQUNsQjs7OztlQUNMOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUdFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTZFO1FBRXZGOzs7O2tCQUNOLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLFlBQVksQ0FBQyxDQUFDLFNBQVMsSUFDdEIsWUFBWSxDQUFDLENBQUMsS0FBSyxZQUFZO1VBQzdCLE1BQU0sYUFBYSxvQkFBb0IsUUFBUTtVQUMvQyxPQUNFLHdCQUFDLFVBQUQ7V0FFRSxlQUFlO1lBQ2IsbUJBQW1CLFFBQVEsRUFBRTtZQUM3QixtQkFBbUIsUUFBUSxFQUFFO1dBQy9CO1dBQ0EsV0FBVyxnR0FDVCxhQUNJLGlFQUNBO3FCQVRSLENBWUUsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFDWixRQUFRLFlBQVksUUFBUTtZQUMxQjs7Ozs2QkFDRzthQUNOLE1BQU0sc0JBQXNCLFlBQVksQ0FBQyxFQUFDLENBQUUsUUFDekMsTUFBTSxFQUFFLGFBQWEsUUFBUSxNQUFNLEVBQUUsZUFBZSxNQUFNLE1BQU0sQ0FBQyxFQUFFLElBQ3RFLENBQUMsQ0FBQzthQUNGLE9BQU8scUJBQXFCLElBQzFCLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUNiO2FBQ0c7Ozs7d0JBQ0o7WUFDTixFQUFDLENBQUUsQ0FDQTs7Ozs7cUJBQ0wsd0JBQUMsT0FBRCxZQUNHLFFBQVEsU0FBUyxVQUNoQix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNEU7V0FBbUI7Ozs7c0JBQzdHLFFBQVEsU0FBUyxXQUNuQix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBd0U7V0FBZTs7OztzQkFFdkcsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWdGO1dBQWE7Ozs7b0JBRTVHOzs7O21CQUNDO2FBbkNELFFBQVE7Ozs7aUJBbUNQO1NBRVosQ0FBQyxJQUVELHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFxRDtTQUFnRDs7Ozs7UUFFakg7Ozs7Z0JBQ0Y7Ozs7O2lCQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLGtCQUNDO1NBRUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFDVixVQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sZUFBZSxDQUFDLEVBQUUsWUFBWSxVQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sZUFBZSxDQUFDLEVBQUU7V0FDOUc7Ozs7cUJBQ0gsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQWIsQ0FBbUQsU0FDM0MsVUFBVSxNQUFNLE1BQU0sRUFBRSxPQUFPLGVBQWUsQ0FBQyxFQUFFLElBQ3REOzs7OzttQkFDQTs7Ozs7O1NBQ0Y7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osa0JBQWtCLENBQUMsQ0FBQyxTQUFTLElBQzVCLGtCQUFrQixDQUFDLENBQUMsS0FBSyxRQUFRO1dBQy9CLE1BQU0sT0FBTyxJQUFJLGFBQWEsTUFBTTtXQUNwQyxPQUNFLHdCQUFDLE9BQUQ7WUFBa0IsV0FBVyxpQkFBaUIsT0FBTyxjQUFjO3NCQUFuRSxDQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFXLCtDQUNkLE9BQ0ksMkZBQ0E7dUJBRUosd0JBQUMsS0FBRDtjQUFHLFdBQVU7d0JBQW1ELElBQUk7YUFBUTs7Ozs7WUFDekU7Ozs7c0JBQ0wsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCO2NBQ0csT0FBTyxPQUFRLElBQUksa0JBQWtCLElBQUksZUFBZTtjQUFXO2NBQUksSUFBSSxLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsbUJBQW1CLFNBQVM7ZUFBRSxNQUFNO2VBQVcsUUFBUTtjQUFVLENBQUM7YUFDOUo7Ozs7O29CQUNIO2NBWEssSUFBSTs7OztrQkFXVDtVQUVULENBQUMsSUFFRCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLHFCQUFzQjs7OztxQkFDL0Msd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQXFCO1dBQW9EOzs7O21CQUNuRjs7Ozs7O1NBRUo7Ozs7O1NBR0wsd0JBQUMsUUFBRDtVQUFNLFVBQVU7VUFBbUIsV0FBVTtvQkFBN0MsQ0FDRSx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMO1dBQ0EsT0FBTztXQUNQLFdBQVcsTUFBTSxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7V0FDbEQsYUFBWTtXQUNaLFdBQVU7VUFDWDs7OztvQkFDRCx3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLFdBQVU7cUJBQ1g7VUFFTzs7OztrQkFDSjs7Ozs7O1FBQ047Ozs7bUJBRUYsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSxzQ0FBdUM7Ozs7O1VBQ2hFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFvQjtVQUEwRDs7Ozs7VUFDM0Ysd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWlFO1VBRTNFOzs7OztTQUNBOzs7Ozs7T0FFSjs7OztlQUVGOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFEO1FBQ0UsZUFBZSxpQkFBaUIsS0FBSztRQUNyQyxXQUFVO2tCQUNYO09BRU87Ozs7O01BQ0w7Ozs7O0tBQ0Y7Ozs7O1lBRUo7Ozs7OztFQUdKOzs7Ozs7QUFFVDs7Ozs7Ozs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2lkZWJhckxheW91dC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IE91dGxldCwgdXNlTmF2aWdhdGUsIHVzZUxvY2F0aW9uLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB1c2VTdG9yZSBmcm9tICcuLi9zdG9yZS91c2VTdG9yZSc7XHJcbmltcG9ydCB7IHVzZUNvbmZpcm0gfSBmcm9tICcuLi9jb250ZXh0L0NvbmZpcm1Db250ZXh0JztcclxuaW1wb3J0IGlvIGZyb20gJ3NvY2tldC5pby1jbGllbnQnO1xyXG5pbXBvcnQgeyBBUElfQkFTRV9VUkwgfSBmcm9tICcuLi91dGlscy9hcGknO1xyXG5pbXBvcnQgeyBcclxuICBCcmllZmNhc2UsIFxyXG4gIFRyZW5kaW5nVXAsIFxyXG4gIERhdGFiYXNlLCBcclxuICBMb2dPdXQsIFxyXG4gIE1lbnUsIFxyXG4gIFgsIFxyXG4gIFphcCwgXHJcbiAgVXNlciwgXHJcbiAgVXBsb2FkQ2xvdWQsIFxyXG4gIERvd25sb2FkLCBcclxuICBSZWZyZXNoQ3csXHJcbiAgRmlsZVRleHQsXHJcbiAgQ2xvY2ssXHJcbiAgU3BhcmtsZXMsXHJcbiAgU2hpZWxkQ2hlY2ssXHJcbiAgVXNlcnMsXHJcbiAgTWVzc2FnZVNxdWFyZSxcclxuICBDaGV2cm9uTGVmdCxcclxuICBDaGV2cm9uUmlnaHQsXHJcbiAgQ2xvdWQsXHJcbiAgVHJhc2gyLFxyXG4gIFJvdGF0ZUNjdyxcclxuICBQbHVzLFxyXG4gIEhhcmREcml2ZVxyXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XHJcblxyXG5leHBvcnQgY29uc3QgU2lkZWJhckxheW91dCA9ICgpID0+IHtcclxuICBjb25zdCBpc0NoYXRFbmFibGVkID0gZmFsc2U7XHJcbiAgY29uc3QgeyBcclxuICAgIHVzZXIsIFxyXG4gICAgdG9rZW4sXHJcbiAgICBsb2dvdXQsIFxyXG4gICAgY29tcGFuaWVzLCBcclxuICAgIGltcG9ydENvbXBhbmllcyxcclxuICAgIHVzZXJzTGlzdCxcclxuICAgIGFkZFVzZXIsXHJcbiAgICB1cGRhdGVVc2VyLFxyXG4gICAgZGVsZXRlVXNlcixcclxuICAgIG1lc3NhZ2VzLFxyXG4gICAgc2VuZE1lc3NhZ2UsXHJcbiAgICBzb2NrZXQsXHJcbiAgICBzZXRTb2NrZXQsXHJcbiAgICBhZGRJbmNvbWluZ01lc3NhZ2UsXHJcbiAgICBtYXJrTWVzc2FnZXNBc1JlYWQsXHJcbiAgICBmZXRjaFVzZXJzTGlzdCxcclxuICAgIGZldGNoTWVzc2FnZXNMaXN0LFxyXG4gICAgc2hvd1RvYXN0XHJcbiAgfSA9IHVzZVN0b3JlKCk7XHJcbiAgXHJcbiAgY29uc3QgeyBjb25maXJtIH0gPSB1c2VDb25maXJtKCk7XHJcbiAgXHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICBcclxuICAvLyBNZW7DuiBtw7N2aWxcclxuICBjb25zdCBbaXNNb2JpbGVPcGVuLCBzZXRJc01vYmlsZU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIFxyXG4gIC8vIE1vZGFsZXNcclxuICBjb25zdCBbc2hvd1JlcG9ydHNNb2RhbCwgc2V0U2hvd1JlcG9ydHNNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dVc2Vyc01vZGFsLCBzZXRTaG93VXNlcnNNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dDaGF0TW9kYWwsIHNldFNob3dDaGF0TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyBFc3RhZG9zIGRlIGNvbnRyb2wgZGUgdXN1YXJpb3NcclxuICBjb25zdCBbbmV3VXNlckVtYWlsLCBzZXROZXdVc2VyRW1haWxdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtuZXdVc2VyUGFzc3dvcmQsIHNldE5ld1VzZXJQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW25ld1VzZXJSb2xlLCBzZXROZXdVc2VyUm9sZV0gPSB1c2VTdGF0ZSgnV09SS0VSJyk7XHJcbiAgY29uc3QgW25ld1VzZXJDb21wYW55SWQsIHNldE5ld1VzZXJDb21wYW55SWRdID0gdXNlU3RhdGUoJycpO1xyXG5cclxuICBjb25zdCBbZWRpdGluZ1VzZXJJZCwgc2V0RWRpdGluZ1VzZXJJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZWRpdGluZ0VtYWlsLCBzZXRFZGl0aW5nRW1haWxdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtlZGl0aW5nUGFzc3dvcmQsIHNldEVkaXRpbmdQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2VkaXRpbmdSb2xlLCBzZXRFZGl0aW5nUm9sZV0gPSB1c2VTdGF0ZSgnV09SS0VSJyk7XHJcbiAgY29uc3QgW2VkaXRpbmdDb21wYW55SWQsIHNldEVkaXRpbmdDb21wYW55SWRdID0gdXNlU3RhdGUoJycpO1xyXG5cclxuICAvLyBFc3RhZG9zIGRlIENoYXRcclxuICBjb25zdCBbYWN0aXZlQ29udGFjdElkLCBzZXRBY3RpdmVDb250YWN0SWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2NoYXRNZXNzYWdlVGV4dCwgc2V0Q2hhdE1lc3NhZ2VUZXh0XSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbaXNTaWRlYmFyQ29sbGFwc2VkLCBzZXRJc1NpZGViYXJDb2xsYXBzZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyBJbmljaWFsaXphY2nDs24gZGUgU29ja2V0c1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaXNDaGF0RW5hYmxlZCAmJiB1c2VyICYmIG5hdmlnYXRvci5vbkxpbmUpIHtcclxuICAgICAgZmV0Y2hVc2Vyc0xpc3QoKTtcclxuICAgICAgZmV0Y2hNZXNzYWdlc0xpc3QodXNlci5pZCk7XHJcblxyXG4gICAgICBjb25zdCBzb2NrZXRJbnN0YW5jZSA9IGlvKEFQSV9CQVNFX1VSTCk7XHJcblxyXG4gICAgICBzb2NrZXRJbnN0YW5jZS5vbignY29ubmVjdCcsICgpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZygn4pqhIENvbmVjdGFkbyBhbCBzZXJ2aWRvciBkZSBTb2NrZXRzJyk7XHJcbiAgICAgICAgc29ja2V0SW5zdGFuY2UuZW1pdCgncmVnaXN0ZXJfdXNlcicsIHVzZXIuaWQpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNvY2tldEluc3RhbmNlLm9uKCdyZWNlaXZlX21lc3NhZ2UnLCAobXNnKSA9PiB7XHJcbiAgICAgICAgYWRkSW5jb21pbmdNZXNzYWdlKG1zZyk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0U29ja2V0KHNvY2tldEluc3RhbmNlKTtcclxuXHJcbiAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgc29ja2V0SW5zdGFuY2UuZGlzY29ubmVjdCgpO1xyXG4gICAgICAgIHNldFNvY2tldChudWxsKTtcclxuICAgICAgfTtcclxuICAgIH1cclxuICB9LCBbdXNlcl0pO1xyXG5cclxuICAvLyBTaW5jcm9uaXphciBsYSBsaXN0YSBkZSB1c3VhcmlvcyBjb24gZWwgc2Vydmlkb3JcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHVzZXIgJiYgbmF2aWdhdG9yLm9uTGluZSkge1xyXG4gICAgICBmZXRjaFVzZXJzTGlzdCgpO1xyXG4gICAgfVxyXG4gIH0sIFt1c2VyXSk7XHJcblxyXG4gIC8vIE1hcmNhciBjb21vIGxlw61kbyBhbCBhYnJpciBsYSBjb252ZXJzYWNpw7NuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzaG93Q2hhdE1vZGFsICYmIGFjdGl2ZUNvbnRhY3RJZCkge1xyXG4gICAgICBtYXJrTWVzc2FnZXNBc1JlYWQoYWN0aXZlQ29udGFjdElkKTtcclxuICAgIH1cclxuICB9LCBbc2hvd0NoYXRNb2RhbCwgYWN0aXZlQ29udGFjdElkLCBtZXNzYWdlc10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XHJcbiAgICBpZiAoc29ja2V0KSB7XHJcbiAgICAgIHNvY2tldC5kaXNjb25uZWN0KCk7XHJcbiAgICAgIHNldFNvY2tldChudWxsKTtcclxuICAgIH1cclxuICAgIGxvZ291dCgpO1xyXG4gICAgbmF2aWdhdGUoJy9sb2dpbicpO1xyXG4gIH07XHJcblxyXG4gIC8vIENlcnJhciBtZW7DuiBtw7N2aWwgYWwgbmF2ZWdhclxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRJc01vYmlsZU9wZW4oZmFsc2UpO1xyXG4gIH0sIFtsb2NhdGlvbi5wYXRobmFtZV0pO1xyXG5cclxuICAvLyBBZ3JlZ2FyIHVzdWFyaW9cclxuICBjb25zdCBoYW5kbGVBZGRVc2VyID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghbmV3VXNlckVtYWlsLnRyaW0oKSB8fCAhbmV3VXNlclBhc3N3b3JkLnRyaW0oKSkge1xyXG4gICAgICBzaG93VG9hc3QoXCJQb3IgZmF2b3IsIHJlbGxlbmUgdG9kb3MgbG9zIGNhbXBvcy5cIiwgXCJ3YXJuaW5nXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhZGRVc2VyKHtcclxuICAgICAgdXNlcm5hbWU6IG5ld1VzZXJFbWFpbC50cmltKCksXHJcbiAgICAgIGVtYWlsOiBuZXdVc2VyRW1haWwudHJpbSgpLFxyXG4gICAgICBwYXNzd29yZDogbmV3VXNlclBhc3N3b3JkLnRyaW0oKSxcclxuICAgICAgcm9sZTogbmV3VXNlclJvbGUsXHJcbiAgICAgIGNvbXBhbnlJZDogbmV3VXNlclJvbGUgPT09ICdDTElFTlQnID8gbmV3VXNlckNvbXBhbnlJZCA6IG51bGxcclxuICAgIH0pO1xyXG4gICAgaWYgKHJlc3VsdC5zdWNjZXNzKSB7XHJcbiAgICAgIHNldE5ld1VzZXJFbWFpbCgnJyk7XHJcbiAgICAgIHNldE5ld1VzZXJQYXNzd29yZCgnJyk7XHJcbiAgICAgIHNldE5ld1VzZXJSb2xlKCdXT1JLRVInKTtcclxuICAgICAgc2V0TmV3VXNlckNvbXBhbnlJZCgnJyk7XHJcbiAgICAgIHNob3dUb2FzdChcIlVzdWFyaW8gcmVnaXN0cmFkbyBjb24gw6l4aXRvLlwiLCBcInN1Y2Nlc3NcIik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzaG93VG9hc3QocmVzdWx0LmVycm9yIHx8IFwiRXJyb3IgYWwgcmVnaXN0cmFyIHVzdWFyaW8uXCIsIFwiZXJyb3JcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gR3VhcmRhciBlZGljacOzblxyXG4gIGNvbnN0IGhhbmRsZVNhdmVVc2VyRWRpdCA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIGlmICghZWRpdGluZ0VtYWlsLnRyaW0oKSB8fCAhZWRpdGluZ1Bhc3N3b3JkLnRyaW0oKSkge1xyXG4gICAgICBzaG93VG9hc3QoXCJQb3IgZmF2b3IsIHJlbGxlbmUgdG9kb3MgbG9zIGNhbXBvcy5cIiwgXCJ3YXJuaW5nXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB1cGRhdGVVc2VyKHVzZXJJZCwge1xyXG4gICAgICB1c2VybmFtZTogZWRpdGluZ0VtYWlsLnRyaW0oKSxcclxuICAgICAgZW1haWw6IGVkaXRpbmdFbWFpbC50cmltKCksXHJcbiAgICAgIHBhc3N3b3JkOiBlZGl0aW5nUGFzc3dvcmQudHJpbSgpLFxyXG4gICAgICByb2xlOiBlZGl0aW5nUm9sZSxcclxuICAgICAgY29tcGFueUlkOiBlZGl0aW5nUm9sZSA9PT0gJ0NMSUVOVCcgPyBlZGl0aW5nQ29tcGFueUlkIDogbnVsbFxyXG4gICAgfSk7XHJcbiAgICBpZiAocmVzdWx0LnN1Y2Nlc3MpIHtcclxuICAgICAgc2V0RWRpdGluZ1VzZXJJZChudWxsKTtcclxuICAgICAgc2V0RWRpdGluZ0NvbXBhbnlJZCgnJyk7XHJcbiAgICAgIHNob3dUb2FzdChcIlVzdWFyaW8gYWN0dWFsaXphZG8gY29uIMOpeGl0by5cIiwgXCJzdWNjZXNzXCIpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2hvd1RvYXN0KHJlc3VsdC5lcnJvciB8fCBcIkVycm9yIGFsIGFjdHVhbGl6YXIgdXN1YXJpby5cIiwgXCJlcnJvclwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdGFydEVkaXRVc2VyID0gKHUpID0+IHtcclxuICAgIHNldEVkaXRpbmdVc2VySWQodS5pZCk7XHJcbiAgICBzZXRFZGl0aW5nRW1haWwodS51c2VybmFtZSB8fCB1LmVtYWlsIHx8ICcnKTtcclxuICAgIHNldEVkaXRpbmdQYXNzd29yZCh1LnBhc3N3b3JkKTtcclxuICAgIHNldEVkaXRpbmdSb2xlKHUucm9sZSk7XHJcbiAgICBzZXRFZGl0aW5nQ29tcGFueUlkKHUuY29tcGFueUlkIHx8ICcnKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVVc2VyID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgY29uc3Qgb2sgPSBhd2FpdCBjb25maXJtKHtcclxuICAgICAgdGl0bGU6ICdFbGltaW5hciBVc3VhcmlvJyxcclxuICAgICAgbWVzc2FnZTogJ8K/RXN0w6Egc2VndXJvIGRlIHF1ZSBkZXNlYSBlbGltaW5hciBlc3RlIHVzdWFyaW8/JyxcclxuICAgICAgdHlwZTogJ2RhbmdlcicsXHJcbiAgICAgIGNvbmZpcm1UZXh0OiAnRWxpbWluYXInXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAob2spIHtcclxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZGVsZXRlVXNlcih1c2VySWQpO1xyXG4gICAgICBpZiAocmVzdWx0LnN1Y2Nlc3MpIHtcclxuICAgICAgICBzaG93VG9hc3QoXCJVc3VhcmlvIGVsaW1pbmFkbyBjb24gw6l4aXRvLlwiLCBcInN1Y2Nlc3NcIik7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2hvd1RvYXN0KHJlc3VsdC5lcnJvciB8fCBcIkVycm9yIGFsIGVsaW1pbmFyIHVzdWFyaW8uXCIsIFwiZXJyb3JcIik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBNw6l0b2RvcyBhdXhpbGlhcmVzIGRlIGNoYXRcclxuICBjb25zdCBnZXRDb250YWN0cyA9ICgpID0+IHtcclxuICAgIGlmICghdXNlcnNMaXN0KSByZXR1cm4gW107XHJcbiAgICBpZiAodXNlcj8ucm9sZSA9PT0gJ0FETUlOJykge1xyXG4gICAgICByZXR1cm4gdXNlcnNMaXN0LmZpbHRlcigodSkgPT4gdS5pZCAhPT0gdXNlci5pZCAmJiAodS5yb2xlID09PSAnQURNSU4nIHx8IHUucm9sZSA9PT0gJ1dPUktFUicgfHwgdS5yb2xlID09PSAnQ0xJRU5UJykpO1xyXG4gICAgfSBlbHNlIGlmICh1c2VyPy5yb2xlID09PSAnV09SS0VSJykge1xyXG4gICAgICByZXR1cm4gdXNlcnNMaXN0LmZpbHRlcigodSkgPT4gdS5pZCAhPT0gdXNlci5pZCAmJiAodS5yb2xlID09PSAnQURNSU4nIHx8IHUucm9sZSA9PT0gJ0NMSUVOVCcpKTtcclxuICAgIH0gZWxzZSBpZiAodXNlcj8ucm9sZSA9PT0gJ0NMSUVOVCcpIHtcclxuICAgICAgcmV0dXJuIHVzZXJzTGlzdC5maWx0ZXIoKHUpID0+IHUuaWQgIT09IHVzZXIuaWQgJiYgdS5yb2xlID09PSAnQURNSU4nKTtcclxuICAgIH1cclxuICAgIHJldHVybiBbXTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTZW5kTWVzc2FnZSA9IChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAoIWNoYXRNZXNzYWdlVGV4dC50cmltKCkgfHwgIWFjdGl2ZUNvbnRhY3RJZCkgcmV0dXJuO1xyXG4gICAgc2VuZE1lc3NhZ2UoYWN0aXZlQ29udGFjdElkLCBjaGF0TWVzc2FnZVRleHQudHJpbSgpKTtcclxuICAgIHNldENoYXRNZXNzYWdlVGV4dCgnJyk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0QWN0aXZlTWVzc2FnZXMgPSAoKSA9PiB7XHJcbiAgICBpZiAoIW1lc3NhZ2VzIHx8ICFhY3RpdmVDb250YWN0SWQpIHJldHVybiBbXTtcclxuICAgIHJldHVybiBtZXNzYWdlcy5maWx0ZXIoXHJcbiAgICAgIChtKSA9PlxyXG4gICAgICAgIChtLnNlbmRlcklkID09PSB1c2VyPy5pZCAmJiBtLnJlY2VpdmVySWQgPT09IGFjdGl2ZUNvbnRhY3RJZCkgfHxcclxuICAgICAgICAobS5zZW5kZXJJZCA9PT0gYWN0aXZlQ29udGFjdElkICYmIG0ucmVjZWl2ZXJJZCA9PT0gdXNlcj8uaWQpXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRvdGFsVW5yZWFkQ291bnQgPSBpc0NoYXRFbmFibGVkID8gKG1lc3NhZ2VzIHx8IFtdKS5maWx0ZXIoKG0pID0+IG0ucmVjZWl2ZXJJZCA9PT0gdXNlcj8uaWQgJiYgIW0ucmVhZCkubGVuZ3RoIDogMDtcclxuXHJcbiAgY29uc3QgbmF2TGlua3MgPSBbXHJcbiAgICB7IG5hbWU6ICdFbXByZXNhcycsIHBhdGg6ICcvJywgaWNvbjogQnJpZWZjYXNlIH0sXHJcbiAgICB7IG5hbWU6ICdNZW5zYWplcsOtYSAvIENoYXQnLCBvbkNsaWNrOiAoKSA9PiBzZXRTaG93Q2hhdE1vZGFsKHRydWUpLCBpY29uOiBNZXNzYWdlU3F1YXJlIH1cclxuICBdO1xyXG5cclxuICBpZiAodXNlcj8ucm9sZSA9PT0gJ0FETUlOJykge1xyXG4gICAgbmF2TGlua3MucHVzaCh7IG5hbWU6ICdHZXN0acOzbiBkZSBVc3VhcmlvcycsIG9uQ2xpY2s6ICgpID0+IHNldFNob3dVc2Vyc01vZGFsKHRydWUpLCBpY29uOiBVc2VycyB9KTtcclxuICB9XHJcblxyXG4gIG5hdkxpbmtzLnB1c2goXHJcbiAgICB7IG5hbWU6ICdSZXBvcnRlcyB5IEF1ZGl0b3LDrWEnLCBwYXRoOiAnL3JlcG9ydGVzJywgaWNvbjogRmlsZVRleHQgfSxcclxuICAgIHsgbmFtZTogJ0NvcGlhcyBkZSBTZWd1cmlkYWQnLCBwYXRoOiAnL2JhY2t1cHMnLCBpY29uOiBEYXRhYmFzZSB9XHJcbiAgKTtcclxuXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBhbnRpYWxpYXNlZFwiPlxyXG4gICAgICBcclxuICAgICAgey8qIDEuIFRPUCBCQVIgTcOTVklMIChuby1wcmludCkgKi99XHJcbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwibGc6aGlkZGVuIGJnLXNsYXRlLTk1MC85MCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwLzgwIHB4LTQgcHktMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc2hhZG93LW1kIHNocmluay0wIG5vLXByaW50IHN0aWNreSB0b3AtMCB6LTQwIGJhY2tkcm9wLWJsdXItbWRcIj5cclxuICAgICAgICA8TGluayB0bz1cIi9cIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEuNSBiZy1ncmFkaWVudC10by1iciBmcm9tLWFtYmVyLTQwMCB0by1hbWJlci02MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTUgaC01IGZpbGwtc2xhdGUtOTUwIHRleHQtc2xhdGUtOTUwXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbSB0cmFja2luZy13aWRlc3QgdGV4dC1zbGF0ZS0xMDAgZm9udC1tb25vXCI+U0VMRUNUUklDPC9zcGFuPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc01vYmlsZU9wZW4oIWlzTW9iaWxlT3Blbil9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYmctc2xhdGUtOTAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtpc01vYmlsZU9wZW4gPyA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz4gOiA8TWVudSBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz59XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG5cclxuICAgICAgey8qIDIuIERSQVdFUiBERSBNRU7DmiBNw5NWSUwgKG5vLXByaW50KSAqL31cclxuICAgICAge2lzTW9iaWxlT3BlbiAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgbGc6aGlkZGVuIG5vLXByaW50IGZsZXggZmxleC1yb3dcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1zbGF0ZS05NTAvNzAgYmFja2Ryb3AtYmx1ci1zbVwiIG9uQ2xpY2s9eygpID0+IHNldElzTW9iaWxlT3BlbihmYWxzZSl9IC8+XHJcbiAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctNjQgYmctc2xhdGUtOTUwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gcC01IGFuaW1hdGUtaW4gc2xpZGUtaW4tZnJvbS1sZWZ0IGR1cmF0aW9uLTI1MFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEuNSBiZy1hbWJlci01MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTk1MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy00IGgtNCBmaWxsLXNsYXRlLTk1MFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0cmFja2luZy13aWRlc3QgdGV4dC1zbGF0ZS0xMDAgZm9udC1tb25vIHRleHQtc21cIj5TRUxFQ1RSSUM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldElzTW9iaWxlT3BlbihmYWxzZSl9IGNsYXNzTmFtZT1cInAtMSBiZy1zbGF0ZS05MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAge25hdkxpbmtzLm1hcCgobGluaykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBJY29uID0gbGluay5pY29uO1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGxpbmsucGF0aCBcclxuICAgICAgICAgICAgICAgICAgICA/IChsb2NhdGlvbi5wYXRobmFtZSA9PT0gbGluay5wYXRoIHx8IChsaW5rLnBhdGggPT09ICcvYmFja3VwcycgJiYgbG9jYXRpb24ucGF0aG5hbWUgPT09ICcvYmFja3VwJykpXHJcbiAgICAgICAgICAgICAgICAgICAgOiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGxpbmsucGF0aCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICB0bz17bGluay5wYXRofVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNCBweS0zIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgYm9yZGVyICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwLzEwIGJvcmRlci1hbWJlci01MDAvMzAgdGV4dC1hbWJlci00MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctdHJhbnNwYXJlbnQgYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTkwMCdcclxuICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2xpbmsubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17bGluay5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRJc01vYmlsZU9wZW4oZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsaW5rLm9uQ2xpY2soKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNCBweS0zIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgYm9yZGVyIGJnLXRyYW5zcGFyZW50IGJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS05MDAgdGV4dC1sZWZ0IGN1cnNvci1wb2ludGVyIHJlbGF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntsaW5rLm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2xpbmsubmFtZSA9PT0gJ01lbnNhamVyw61hIC8gQ2hhdCcgJiYgdG90YWxVbnJlYWRDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC1hdXRvIGJnLXJlZC01MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ib2xkIHJvdW5kZWQtZnVsbCB0ZXh0LVs5cHhdIHB4LTEuNSBweS0wLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYW5pbWF0ZS1wdWxzZSBzaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0b3RhbFVucmVhZENvdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMCBwdC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC0zIHB5LTIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICAgIDxVc2VyIGNsYXNzTmFtZT1cInctNC41IGgtNC41IHRleHQtYW1iZXItNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJ1bmNhdGUgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgZm9udC1tb25vIGZvbnQtYm9sZFwiPlVzdWFyaW8gQWN0aXZvPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0yMDAgdHJ1bmNhdGVcIj57dXNlcj8udXNlcm5hbWUgfHwgdXNlcj8uZW1haWx9PC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTG9nb3V0fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB5LTIuNSBiZy1zbGF0ZS05MDAgaG92ZXI6YmctcmVkLTk1NS8yMCBob3Zlcjp0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXJlZC05MDAvNDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciB0ZXh0LXhzIGZvbnQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPExvZ091dCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gQ2VycmFyIFNlc2nDs25cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L25hdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiAzLiBTSURFQkFSIEVTQ1JJVE9SSU8gRklKTyAobm8tcHJpbnQpICovfVxyXG4gICAgICA8YXNpZGUgY2xhc3NOYW1lPXtgcmVsYXRpdmUgaGlkZGVuIGxnOmZsZXggYmctc2xhdGUtOTUwIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAvODAgZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHNocmluay0wIG5vLXByaW50IHN0aWNreSB0b3AtMCBoLXNjcmVlbiBzZWxlY3Qtbm9uZSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgJHtcclxuICAgICAgICBpc1NpZGViYXJDb2xsYXBzZWQgPyAndy0yMCBwLTQnIDogJ3ctNjQgcC02J1xyXG4gICAgICB9YH0+XHJcbiAgICAgICAgXHJcbiAgICAgICAgey8qIEJvdMOzbiBkZSBDb2xhcHNvIEZsb3RhbnRlIGVuIGVsIEJvcmRlICovfVxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzU2lkZWJhckNvbGxhcHNlZCghaXNTaWRlYmFyQ29sbGFwc2VkKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC02IC1yaWdodC0zIHotMzUgdy02IGgtNiByb3VuZGVkLWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGN1cnNvci1wb2ludGVyIHNoYWRvdy1tZCBob3ZlcjpiZy1zbGF0ZS04MDAgaG92ZXI6c2NhbGUtMTA1IGFjdGl2ZTpzY2FsZS05NSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICB0aXRsZT17aXNTaWRlYmFyQ29sbGFwc2VkID8gXCJFeHBhbmRpciBNZW7DulwiIDogXCJDb2xhcHNhciBNZW7DulwifVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtpc1NpZGViYXJDb2xsYXBzZWQgPyA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gOiA8Q2hldnJvbkxlZnQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj5cclxuICAgICAgICAgIHsvKiBMb2dvIC8gQnJhbmRpbmcgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBweC0xXCI+XHJcbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYW1iZXItNDAwIHRvLWFtYmVyLTYwMCByb3VuZGVkLXhsIHRleHQtc2xhdGUtOTUwIHNoYWRvdy1tZCB0cmFuc2Zvcm0gaG92ZXI6cm90YXRlLTEyIHRyYW5zaXRpb24tdHJhbnNmb3JtIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNSBoLTUgZmlsbC1zbGF0ZS05NTAgdGV4dC1zbGF0ZS05NTBcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHshaXNTaWRlYmFyQ29sbGFwc2VkICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJsYWNrIHRleHQtc20gdHJhY2tpbmctd2lkZXN0IHRleHQtc2xhdGUtMTAwIGZvbnQtbW9ubyBibG9jayBsZWFkaW5nLW5vbmVcIj5TRUxFQ1RSSUM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzhweF0gdGV4dC1hbWJlci01MDAgdHJhY2tpbmctd2lkZXN0IGZvbnQtYmxhY2sgdXBwZXJjYXNlXCI+SW5zcGVjY2nDs24gZGUgUmVkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIExpbmtzIGRlIE5hdmVnYWNpw7NuICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxyXG4gICAgICAgICAgICB7IWlzU2lkZWJhckNvbGxhcHNlZCAmJiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgcHgtMiB0ZXh0LVs5cHhdIGZvbnQtYmxhY2sgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTUwMCBwYi0xIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgICAgICAgICAgIE1lbsO6IFByaW5jaXBhbFxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAge25hdkxpbmtzLm1hcCgobGluaykgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IEljb24gPSBsaW5rLmljb247XHJcbiAgICAgICAgICAgICAgY29uc3QgaXNBY3RpdmUgPSBsaW5rLnBhdGggXHJcbiAgICAgICAgICAgICAgICA/IChsb2NhdGlvbi5wYXRobmFtZSA9PT0gbGluay5wYXRoIHx8IChsaW5rLnBhdGggPT09ICcvYmFja3VwcycgJiYgbG9jYXRpb24ucGF0aG5hbWUgPT09ICcvYmFja3VwJykpXHJcbiAgICAgICAgICAgICAgICA6IGZhbHNlO1xyXG4gICAgICAgICAgICAgIHJldHVybiBsaW5rLnBhdGggPyAoXHJcbiAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICBrZXk9e2xpbmsubmFtZX1cclxuICAgICAgICAgICAgICAgICAgdG89e2xpbmsucGF0aH1cclxuICAgICAgICAgICAgICAgICAgdGl0bGU9e2lzU2lkZWJhckNvbGxhcHNlZCA/IGxpbmsubmFtZSA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBib3JkZXIgJHtcclxuICAgICAgICAgICAgICAgICAgICBpc1NpZGViYXJDb2xsYXBzZWQgPyAnanVzdGlmeS1jZW50ZXIgcC0zJyA6ICdnYXAtMyBweC00LjUgcHktMydcclxuICAgICAgICAgICAgICAgICAgfSAgJHtcclxuICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwLzEwIGJvcmRlci1hbWJlci01MDAvMzAgdGV4dC1hbWJlci00MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy10cmFuc3BhcmVudCBib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtOTAwJ1xyXG4gICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy00IGgtNCBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIHshaXNTaWRlYmFyQ29sbGFwc2VkICYmIDxzcGFuIGNsYXNzTmFtZT1cImFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj57bGluay5uYW1lfTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAga2V5PXtsaW5rLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2xpbmsub25DbGlja31cclxuICAgICAgICAgICAgICAgICAgdGl0bGU9e2lzU2lkZWJhckNvbGxhcHNlZCA/IGxpbmsubmFtZSA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgYm9yZGVyIGJnLXRyYW5zcGFyZW50IGJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS05MDAgdGV4dC1sZWZ0IGN1cnNvci1wb2ludGVyIHJlbGF0aXZlICR7XHJcbiAgICAgICAgICAgICAgICAgICAgaXNTaWRlYmFyQ29sbGFwc2VkID8gJ2p1c3RpZnktY2VudGVyIHAtMycgOiAnZ2FwLTMgcHgtNC41IHB5LTMnXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wXCIgLz5cclxuICAgICAgICAgICAgICAgICAgeyFpc1NpZGViYXJDb2xsYXBzZWQgJiYgPHNwYW4gY2xhc3NOYW1lPVwiYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiPntsaW5rLm5hbWV9PC9zcGFuPn1cclxuICAgICAgICAgICAgICAgICAge2xpbmsubmFtZSA9PT0gJ01lbnNhamVyw61hIC8gQ2hhdCcgJiYgdG90YWxVbnJlYWRDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIGlzU2lkZWJhckNvbGxhcHNlZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0xLjUgcmlnaHQtMS41IHctMi41IGgtMi41IGJnLXJlZC01MDAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcHVsc2UgYm9yZGVyIGJvcmRlci1zbGF0ZS05NTBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC1hdXRvIGJnLXJlZC01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgcm91bmRlZC1mdWxsIHRleHQtWzlweF0gcHgtMS41IHB5LTAuNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBhbmltYXRlLXB1bHNlIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0b3RhbFVucmVhZENvdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBQZXJmaWwgJiBBY2Npb25lcyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwIHB0LTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtODUwIHJvdW5kZWQteGwgJHtcclxuICAgICAgICAgICAgaXNTaWRlYmFyQ29sbGFwc2VkID8gJ2p1c3RpZnktY2VudGVyIHAtMi41JyA6ICdnYXAtMyBweC0zIHB5LTIuNSdcclxuICAgICAgICAgIH1gfT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtbGcgYmctYW1iZXItNTAwLzEwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy00LjUgaC00LjUgdGV4dC1hbWJlci01MDBcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgeyFpc1NpZGViYXJDb2xsYXBzZWQgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJ1bmNhdGUgbWluLXctMCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBmb250LW1vbm8gZm9udC1ibGFja1wiPlxyXG4gICAgICAgICAgICAgICAgICB7dXNlcj8ucm9sZSA9PT0gJ0FETUlOJyA/ICfwn5GRIEFkbWluaXN0cmFkb3InIDogJ/CfkbcgSW5zcGVjdG9yJ31cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMjUwIHRydW5jYXRlXCI+e3VzZXI/LnVzZXJuYW1lIHx8IHVzZXI/LmVtYWlsfTwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTG9nb3V0fVxyXG4gICAgICAgICAgICB0aXRsZT17aXNTaWRlYmFyQ29sbGFwc2VkID8gXCJDZXJyYXIgU2VzacOzblwiIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXJlZC05NTUvMjAgaG92ZXI6dGV4dC1yZWQtNDAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1yZWQtOTAwLzQwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgJHtcclxuICAgICAgICAgICAgICBpc1NpZGViYXJDb2xsYXBzZWQgPyAncC0zJyA6ICdnYXAtMiBweS0zJ1xyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPExvZ091dCBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wXCIgLz5cclxuICAgICAgICAgICAgeyFpc1NpZGViYXJDb2xsYXBzZWQgJiYgPHNwYW4gY2xhc3NOYW1lPVwiYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiPkNlcnJhciBTZXNpw7NuPC9zcGFuPn1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2FzaWRlPlxyXG5cclxuICAgICAgey8qIDQuIE1BSU4gUEFORUwgREUgQ09OVEVOSURPIChTY3JvbGxhYmxlIGVuIEVzY3JpdG9yaW8pICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wIG92ZXJmbG93LXktYXV0byBtYXgtaC1zY3JlZW5cIj5cclxuICAgICAgICA8T3V0bGV0IC8+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIE1PREFMIDE6IEZVVFVST1MgUkVQT1JURVMgUFJFRElDVElWT1MgKi99XHJcbiAgICAgIHtzaG93UmVwb3J0c01vZGFsICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgbm8tcHJpbnRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1zbGF0ZS05MDAvNzAgYmFja2Ryb3AtYmx1ci1zbSBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd1JlcG9ydHNNb2RhbChmYWxzZSl9IC8+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LWxnIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIHAtNiBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBSZXBvcnRlcyBGdXR1cm9zIHkgQW5hbMOtdGljYXMgSUFcclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UmVwb3J0c01vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IGhvdmVyOmJnLXNsYXRlLTkwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtNTUwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1zYW5zXCI+XHJcbiAgICAgICAgICAgICAgICBFc3RhbW9zIHRyYWJhamFuZG8gZW4gZWwgZGVzYXJyb2xsbyBkZSBoZXJyYW1pZW50YXMgcHJlZGljdGl2YXMgZGUgaW50ZWxpZ2VuY2lhIGFydGlmaWNpYWwgeSBtw7NkdWxvcyBhdmFuemFkb3MgZGUgYW7DoWxpc2lzIGRlIHJlZCBlbMOpY3RyaWNhLiBQcsOzeGltYW1lbnRlIGRpc3BvbmRyw6FzIGRlIGxvcyBzaWd1aWVudGVzIHJlcG9ydGVzIGF1dG9tw6F0aWNvczpcclxuICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtMy41IHB0LTJcIj5cclxuICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJSZXBvcnRlIGRlIEFuw6FsaXNpcyBQcmVkaWN0aXZvIElBXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzYzogXCJQcmVkaWNlIGxhIHByb2JhYmlsaWRhZCBkZSBmYWxsYSB5IHNvYnJlY2FyZ2EgZW4gaW50ZXJydXB0b3JlcyBiYXPDoW5kb3NlIGVuIG1lZGljaW9uZXMgZGUgY29ycmllbnRlIHkgY2FsaWJyYWNpw7NuIGRlbCBjb25kdWN0b3IuXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogU2hpZWxkQ2hlY2ssXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwidGV4dC1lbWVyYWxkLTQwMCBiZy1lbWVyYWxkLTk1MC80MCBib3JkZXItZW1lcmFsZC05MDAvNDBcIlxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiU2VndWltaWVudG8gVGVybW9ncsOhZmljbyB5IFRlbmRlbmNpYSBkZSBDYWxvclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlc2M6IFwiR3JhZmljYSBsYSBldm9sdWNpw7NuIGRlIHRlbXBlcmF0dXJhcyBtw6F4aW1hcyBkZXRlY3RhZGFzIGVuIGxhIHBsYWNhIHByaW5jaXBhbCwgZmFjaWxpdGFuZG8gbGEgcGxhbmlmaWNhY2nDs24gZGUgbWFudGVuaW1pZW50b3MuXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogQ2xvY2ssXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwidGV4dC1za3ktNDAwIGJnLXNreS05NTAvNDAgYm9yZGVyLXNreS05MDAvNDBcIlxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiTcOzZHVsbyBkZSBBdWRpdG9yw61hIGRlIENhcmdhIChDRU4pXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzYzogXCJWYWxpZGEgYXV0b23DoXRpY2FtZW50ZSBzaSBsYXMgYWNvbWV0aWRhcywgYmFycmFqZXMgeSBwcm90ZWNjaW9uZXMgY3VtcGxlbiBjb24gbG9zIGzDrW1pdGVzIGRlIGNhcGFjaWRhZCBlc3RhYmxlY2lkb3MgcG9yIGVsIEPDs2RpZ28gRWzDqWN0cmljbyBOYWNpb25hbC5cIixcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiBGaWxlVGV4dCxcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCJ0ZXh0LXB1cnBsZS00MDAgYmctcHVycGxlLTk1MC80MCBib3JkZXItcHVycGxlLTkwMC80MFwiXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIF0ubWFwKChpdGVtLCBpZHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IGl0ZW0uaWNvbjtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9e2BwLTQgcm91bmRlZC14bCBib3JkZXIgZmxleCBpdGVtcy1zdGFydCBnYXAtMy41IHNoYWRvdy1pbm5lciAke2l0ZW0uY29sb3J9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLWxnIGJnLXNsYXRlLTkwMCBzaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwXCI+e2l0ZW0udGl0bGV9PC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTAuNXB4XSB0ZXh0LXNsYXRlLTQwMCBsZWFkaW5nLW5vcm1hbFwiPntpdGVtLmRlc2N9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UmVwb3J0c01vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGhvdmVyOmJnLWFtYmVyLTQwMCBhY3RpdmU6c2NhbGUtOTggdHJhbnNpdGlvbi1hbGwgZm9udC1ib2xkIHJvdW5kZWQteGwgdGV4dC14cyBjdXJzb3ItcG9pbnRlciBzaGFkb3ctbWRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBFbnRlbmRpZG9cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIE1PREFMIDM6IEdFU1RJw5NOIERFIFVTVUFSSU9TIFkgUk9MRVMgKFNPTE8gQUNDRVNJQkxFIFBBUkEgQURNSU5JU1RSQURPUkVTKSAqL31cclxuICAgICAge3Nob3dVc2Vyc01vZGFsICYmIHVzZXI/LnJvbGUgPT09ICdBRE1JTicgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBuby1wcmludFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLXNsYXRlLTkwMC83MCBiYWNrZHJvcC1ibHVyLXNtIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93VXNlcnNNb2RhbChmYWxzZSl9IC8+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LTR4bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBwLTYgb3ZlcmZsb3ctaGlkZGVuIGFuaW1hdGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDAgbWF4LWgtWzkwdmhdIGZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPFVzZXJzIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgR2VzdGnDs24gZGUgVXN1YXJpb3MgeSBSb2xlc1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1VzZXJJZChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgc2V0U2hvd1VzZXJzTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IGhvdmVyOmJnLXNsYXRlLTkwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtNTAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtNSBnYXAtNiBvdmVyZmxvdy15LWF1dG8gcHItMSBmbGV4LTEgcHktMlwiPlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIHsvKiBGb3JtdWxhcmlvIGRlIHJlZ2lzdHJvIChjb2wtc3Bhbi0yKSAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTIgc3BhY2UteS00IGJnLXNsYXRlLTkwMC80MCBwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTg1MCBoLWZpdFwiPlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGJvcmRlci1sLTIgYm9yZGVyLWFtYmVyLTUwMCBwbC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFJlZ2lzdHJhciBOdWV2byBVc3VhcmlvXHJcbiAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbGVhZGluZy1ub3JtYWxcIj5cclxuICAgICAgICAgICAgICAgICAgQ3JlYSBjcmVkZW5jaWFsZXMgcGFyYSBpbnNwZWN0b3JlcyBkZSBjYW1wbyBwYXJhIHF1ZSBwdWVkYW4gdXNhciBsYSB0YWJsZXQgeSByZWdpc3RyYXIgZWxlbWVudG9zLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVBZGRVc2VyfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE5vbWJyZSBkZSBVc3VhcmlvXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3VXNlckVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdVc2VyRW1haWwoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlai4gaW5zcGVjdG9yMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLWxnIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIHBsYWNlaG9sZGVyLXNsYXRlLTY1MCBoLTlcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIENvbnRyYXNlw7FhXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1VzZXJQYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3VXNlclBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTcOtbmltbyA0IGNhcmFjdGVyZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1hbWJlci01MDAgcm91bmRlZC1sZyB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGZvY3VzOm91dGxpbmUtbm9uZSBwbGFjZWhvbGRlci1zbGF0ZS02NTAgaC05XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSb2wgZGVsIFVzdWFyaW9cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdVc2VyUm9sZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3VXNlclJvbGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy13aGl0ZSB0ZXh0LXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLWxnIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGgtOSBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiV09SS0VSXCIgY2xhc3NOYW1lPVwidGV4dC1ibGFjayBiZy13aGl0ZVwiPvCfkbcgSU5TUEVDVE9SIC8gVFJBQkFKQURPUjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFETUlOXCIgY2xhc3NOYW1lPVwidGV4dC1ibGFjayBiZy13aGl0ZVwiPvCfkZEgQURNSU5JU1RSQURPUjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNMSUVOVFwiIGNsYXNzTmFtZT1cInRleHQtYmxhY2sgYmctd2hpdGVcIj7wn4+iIENMSUVOVEUgKEVNUFJFU0EpPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAge25ld1VzZXJSb2xlID09PSAnQ0xJRU5UJyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLWluIHNsaWRlLWluLWZyb20tdG9wIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEVtcHJlc2EgQXNvY2lhZGFcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdVc2VyQ29tcGFueUlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld1VzZXJDb21wYW55SWQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXdoaXRlIHRleHQtc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYW1iZXItNTAwIHJvdW5kZWQtbGcgdGV4dC14cyBmb2N1czpvdXRsaW5lLW5vbmUgaC05IGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCIgY2xhc3NOYW1lPVwidGV4dC1ibGFja1wiPi0tIFNlbGVjY2lvbmFyIEVtcHJlc2EgLS08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2NvbXBhbmllcy5tYXAoKGMpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Yy5pZH0gdmFsdWU9e2MuaWR9IGNsYXNzTmFtZT1cInRleHQtYmxhY2tcIj57Yy5ub21icmV9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgYmctYW1iZXItNTAwIHRleHQtc2xhdGUtOTUwIGhvdmVyOmJnLWFtYmVyLTQwMCBhY3RpdmU6c2NhbGUtOTggdHJhbnNpdGlvbi1hbGwgZm9udC1ib2xkIHJvdW5kZWQtbGcgdGV4dC14cyBjdXJzb3ItcG9pbnRlciBzaGFkb3ctbWRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgKyBSZWdpc3RyYXIgVXN1YXJpb1xyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIExpc3RhZG8gZGUgdXN1YXJpb3MgYWN0aXZvcyAoY29sLXNwYW4tMykgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0zIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGJvcmRlci1sLTIgYm9yZGVyLWFtYmVyLTUwMCBwbC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFVzdWFyaW9zIFJlZ2lzdHJhZG9zICh7dXNlcnNMaXN0Py5sZW5ndGggfHwgMH0pXHJcbiAgICAgICAgICAgICAgICA8L2g0PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS04NTAgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gYmctc2xhdGUtOTUwLzQwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHRleHQteHMgYm9yZGVyLWNvbGxhcHNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTg1MCB1cHBlcmNhc2UgdGV4dC1bOXB4XSB0cmFja2luZy13aWRlc3RcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtM1wiPlVzdWFyaW88L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zXCI+Um9sPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB0ZXh0LXJpZ2h0XCI+QWNjaW9uZXM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7KHVzZXJzTGlzdCB8fCBbXSkubWFwKCh1KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZiA9IHUuaWQgPT09IHVzZXI/LmlkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0VkaXRpbmcgPSBlZGl0aW5nVXNlcklkID09PSB1LmlkO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXt1LmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS05MDAvNDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRpbmdFbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0aW5nRW1haWwoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQteHMgdGV4dC1zbGF0ZS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgc3BhY2UteS0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRpbmdSb2xlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTZWxmfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRpbmdSb2xlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMSBiZy13aGl0ZSB0ZXh0LXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQteHMgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJXT1JLRVJcIiBjbGFzc05hbWU9XCJ0ZXh0LWJsYWNrXCI+SU5TUEVDVE9SPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBRE1JTlwiIGNsYXNzTmFtZT1cInRleHQtYmxhY2tcIj5BRE1JTjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ0xJRU5UXCIgY2xhc3NOYW1lPVwidGV4dC1ibGFja1wiPkNMSUVOVEU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlZGl0aW5nUm9sZSA9PT0gJ0NMSUVOVCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRpbmdDb21wYW55SWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0aW5nQ29tcGFueUlkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMiBweS0xIGJnLXdoaXRlIHRleHQtc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgdGV4dC14cyBmb250LXNlbWlib2xkIG10LTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiIGNsYXNzTmFtZT1cInRleHQtYmxhY2tcIj4tLSBTZWxlY2Npb25hciAtLTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb21wYW5pZXMubWFwKChjKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Yy5pZH0gdmFsdWU9e2MuaWR9IGNsYXNzTmFtZT1cInRleHQtYmxhY2tcIj57Yy5ub21icmV9PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1yaWdodCBzcGFjZS15LTEgc206c3BhY2UteS0wIHNtOnNwYWNlLXgtMSBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNhdmVVc2VyRWRpdCh1LmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0xIGJnLWVtZXJhbGQtNTAwIHRleHQtc2xhdGUtOTUwIHJvdW5kZWQgZm9udC1ib2xkIGhvdmVyOmJnLWVtZXJhbGQtNDAwIHRleHQtWzEwcHhdXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR3VhcmRhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEVkaXRpbmdVc2VySWQobnVsbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgcm91bmRlZCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1bMTBweF1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDYW5jZWxhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgZm9udC1tb25vIGZvbnQtbWVkaXVtIHRydW5jYXRlIG1heC13LVsxNTBweF1cIiB0aXRsZT17dS51c2VybmFtZSB8fCB1LmVtYWlsfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1LnVzZXJuYW1lIHx8IHUuZW1haWx9IHtpc1NlbGYgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci01MDAgZm9udC1zYW5zIGZvbnQtYm9sZFwiPihUw7opPC9zcGFuPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1LnJvbGUgPT09ICdBRE1JTicgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkIGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTUwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8yMCB0ZXh0LVs5cHhdIGZvbnQtYmxhY2sgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFETUlOXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dS5yb2xlID09PSAnV09SS0VSJyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQgYmctc2t5LTUwMC8xMCB0ZXh0LXNreS00MDAgYm9yZGVyIGJvcmRlci1za3ktNTAwLzIwIHRleHQtWzlweF0gZm9udC1ibGFjayB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSU5TUEVDVE9SXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dS5yb2xlID09PSAnQ0xJRU5UJyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMSBpdGVtcy1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQgYmctZW1lcmFsZC01MDAvMTAgdGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzIwIHRleHQtWzlweF0gZm9udC1ibGFjayB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDTElFTlRFXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1tb25vIHRydW5jYXRlIG1heC13LVsxMDBweF1cIiB0aXRsZT17Y29tcGFuaWVzLmZpbmQoYyA9PiBjLmlkID09PSB1LmNvbXBhbnlJZCk/Lm5vbWJyZSB8fCAnU2luIEVtcHJlc2EnfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCfj6Ige2NvbXBhbmllcy5maW5kKGMgPT4gYy5pZCA9PT0gdS5jb21wYW55SWQpPy5ub21icmUgfHwgJ1NpbiBFbXByZXNhJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1yaWdodCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdGFydEVkaXRVc2VyKHUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSByb3VuZGVkIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwLzQwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtYW1iZXItNDAwIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtYm9sZCB0ZXh0LVsxMHB4XSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzU2VsZiAmJiAodS51c2VybmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKSAhPT0gJ2FkbWluMScgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlVXNlcih1LmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTEgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXJlZC05NTUvMjAgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1yZWQtNDAwIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXJlZC05MDAvNDAgdHJhbnNpdGlvbi1hbGwgZm9udC1ib2xkIHRleHQtWzEwcHhdIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVsaW1pbmFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBzaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1VzZXJJZChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgc2V0U2hvd1VzZXJzTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMi41IGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2VycmFyXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogTU9EQUwgNDogQ0hBVCBERSBTT1BPUlRFIEUgSU5TUEVDQ0nDk04gKi99XHJcbiAgICAgIHtzaG93Q2hhdE1vZGFsICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgbm8tcHJpbnRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1zbGF0ZS05MDAvNzAgYmFja2Ryb3AtYmx1ci1zbSBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0NoYXRNb2RhbChmYWxzZSl9IC8+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIHshaXNDaGF0RW5hYmxlZCA/IChcclxuICAgICAgICAgICAgLyogUGFudGFsbGEgZGUgYmxvcXVlbzogTcOzZHVsbyBlbiBEZXNhcnJvbGxvICovXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LW1kIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIHAtNiBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlciBzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGwgcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxNZXNzYWdlU3F1YXJlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICBDaGF0IGRlIFNvcG9ydGUgZSBJbnNwZWNjacOzblxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dDaGF0TW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBob3ZlcjpiZy1zbGF0ZS05MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktNiBweC0yIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctYW1iZXItNTAwLzEwIHRleHQtYW1iZXItNTAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXB1bHNlIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzIwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTEwIGgtMTBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMFwiPk3Ds2R1bG8gZW4gRGVzYXJyb2xsbzwvaDQ+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG1heC13LXNtIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICBFc3RhbW9zIGNvbnN0cnV5ZW5kbyB1biBjYW5hbCBkZSBzb3BvcnRlIHkgbWVuc2FqZXLDrWEgZW4gdGllbXBvIHJlYWwgcGFyYSBjb25lY3RhciBhIGluc3BlY3RvcmVzLCBhZG1pbmlzdHJhZG9yZXMgeSBjbGllbnRlcy4gRXN0ZSBtw7NkdWxvIGVzdGFyw6EgZGlzcG9uaWJsZSBwcsOzeGltYW1lbnRlLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04NTAgcm91bmRlZC14bCBwLTQgdGV4dC1sZWZ0IG10LTIgc3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci01MDBcIj5DYXJhY3RlcsOtc3RpY2FzIGVuIERlc2Fycm9sbG86PC9wPlxyXG4gICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS0zNTAgc3BhY2UteS0xLjUgbGlzdC1kaXNjIHBsLTQgZm9udC1zYW5zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpPk1lbnNhamVyw61hIGluc3RhbnTDoW5lYSBiaWRpcmVjY2lvbmFsLjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpPlNvcG9ydGUgdMOpY25pY28gZGlyZWN0byBlbiBjYW1wby48L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaT5Db21wYXJ0aWNpw7NuIGRlIHRhYmxlcm9zIGUgaW5mb3JtZXMuPC9saT5cclxuICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q2hhdE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIGJnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBob3ZlcjpiZy1hbWJlci00MDAgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRleHQteHMgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kIHNocmluay0wXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBFbnRlbmRpZG9cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAvKiBFbCBjaGF0IHJlYWwgY29tcGxldG8gKi9cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctNHhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIHAtNiBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMCBoLVs4MHZoXSBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxNZXNzYWdlU3F1YXJlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICBDaGF0IGRlIFNvcG9ydGUgZSBJbnNwZWNjacOzblxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dDaGF0TW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBob3ZlcjpiZy1zbGF0ZS05MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggbWluLWgtMCBkaXZpZGUteCBkaXZpZGUtc2xhdGUtODUwIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgey8qIFBhbmVsIEl6cXVpZXJkbzogTGlzdGEgZGUgQ29udGFjdG9zICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMyBwci00IGZsZXggZmxleC1jb2wgbWluLWgtMCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtc2xhdGUtNTAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBDb250YWN0b3MgRGlzcG9uaWJsZXNcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41IGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Z2V0Q29udGFjdHMoKS5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgZ2V0Q29udGFjdHMoKS5tYXAoKGNvbnRhY3QpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IGFjdGl2ZUNvbnRhY3RJZCA9PT0gY29udGFjdC5pZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2NvbnRhY3QuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZUNvbnRhY3RJZChjb250YWN0LmlkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFya01lc3NhZ2VzQXNSZWFkKGNvbnRhY3QuaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1hbGwgZmxleCBmbGV4LWNvbCBnYXAtMS41IGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAvMTAgYm9yZGVyLWFtYmVyLTUwMC8zMCB0ZXh0LWFtYmVyLTQwMCBmb250LWJvbGQnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwLzQwIGJvcmRlci1zbGF0ZS04NTAgaG92ZXI6Ymctc2xhdGUtOTAwLzgwIHRleHQtc2xhdGUtMzAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC14cyBmb250LW1vbm8gZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbnRhY3QudXNlcm5hbWUgfHwgY29udGFjdC5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbnRhY3RVbnJlYWRDb3VudCA9IChtZXNzYWdlcyB8fCBbXSkuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKG0pID0+IG0uc2VuZGVySWQgPT09IGNvbnRhY3QuaWQgJiYgbS5yZWNlaXZlcklkID09PSB1c2VyPy5pZCAmJiAhbS5yZWFkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS5sZW5ndGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRhY3RVbnJlYWRDb3VudCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1yZWQtNTAwIHRleHQtd2hpdGUgcm91bmRlZC1mdWxsIHRleHQtWzlweF0gcHgtMS41IHB5LTAuNSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYW5pbWF0ZS1wdWxzZSBzaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29udGFjdFVucmVhZENvdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29udGFjdC5yb2xlID09PSAnQURNSU4nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTEuNSBweS0wLjUgcm91bmRlZCBiZy1hbWJlci01MDAvMTUgdGV4dC1hbWJlci01MDAgdGV4dC1bOHB4XSBmb250LWJvbGRcIj5BRE1JTklTVFJBRE9SPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogY29udGFjdC5yb2xlID09PSAnV09SS0VSJyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0xLjUgcHktMC41IHJvdW5kZWQgYmctc2t5LTUwMC8xNSB0ZXh0LXNreS00MDAgdGV4dC1bOHB4XSBmb250LWJvbGRcIj5JTlNQRUNUT1I8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMS41IHB5LTAuNSByb3VuZGVkIGJnLWVtZXJhbGQtNTAwLzE1IHRleHQtZW1lcmFsZC00MDAgdGV4dC1bOHB4XSBmb250LWJvbGRcIj5DTElFTlRFPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBpdGFsaWMgdGV4dC1jZW50ZXIgcHktNlwiPk5vIGhheSBkZXN0aW5hdGFyaW9zIGRpc3BvbmlibGVzIHBhcmEgdHUgcm9sLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBQYW5lbCBEZXJlY2hvOiBIaXN0b3JpYWwgZGUgTWVuc2FqZXMgeSBDYWphIGRlIEVudsOtbyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yLzMgcGwtNCBmbGV4IGZsZXgtY29sIG1pbi1oLTBcIj5cclxuICAgICAgICAgICAgICAgICAge2FjdGl2ZUNvbnRhY3RJZCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEVuY2FiZXphZG8gZGVsIGNoYXQgYWN0aXZvICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYi0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS05MDAgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTEwMCBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2Vyc0xpc3QuZmluZCgodSkgPT4gdS5pZCA9PT0gYWN0aXZlQ29udGFjdElkKT8udXNlcm5hbWUgfHwgdXNlcnNMaXN0LmZpbmQoKHUpID0+IHUuaWQgPT09IGFjdGl2ZUNvbnRhY3RJZCk/LmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTUwIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUm9sOiB7dXNlcnNMaXN0LmZpbmQoKHUpID0+IHUuaWQgPT09IGFjdGl2ZUNvbnRhY3RJZCk/LnJvbGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBNZW5zYWplcyBkZWwgY2hhdCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBweS00IHNwYWNlLXktMy41IHByLTEgZm9udC1zYW5zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRBY3RpdmVNZXNzYWdlcygpLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZ2V0QWN0aXZlTWVzc2FnZXMoKS5tYXAoKG1zZykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNNZSA9IG1zZy5zZW5kZXJJZCA9PT0gdXNlcj8uaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17bXNnLmlkfSBjbGFzc05hbWU9e2BmbGV4IGZsZXgtY29sICR7aXNNZSA/ICdpdGVtcy1lbmQnIDogJ2l0ZW1zLXN0YXJ0J31gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHB4LTMuNSBweS0yIHRleHQteHMgcm91bmRlZC0yeGwgbWF4LXctWzgwJV0gJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTWUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBmb250LXNlbWlib2xkIHJvdW5kZWQtdHItbm9uZSBzaGFkb3ctbWQgc2hhZG93LWFtYmVyLTUwMC81JyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMTAwIHJvdW5kZWQtdGwtbm9uZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWQgd2hpdGVzcGFjZS1wcmUtd3JhcCBzZWxlY3QtdGV4dFwiPnttc2cudGV4dH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOHB4XSB0ZXh0LXNsYXRlLTU1NSBmb250LW1vbm8gbXQtMSBweC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNNZSA/ICdUw7onIDogKG1zZy5zZW5kZXJVc2VybmFtZSB8fCBtc2cuc2VuZGVyRW1haWwgfHwgJ0Fuw7NuaW1vJyl9IOKAoiB7bmV3IERhdGUobXNnLmNyZWF0ZWRBdCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlcy1FUycsIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0JyB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNjUwIHNwYWNlLXktMiBzZWxlY3Qtbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgY2xhc3NOYW1lPVwidy04IGgtOCBvcGFjaXR5LTIwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGl0YWxpY1wiPk5vIGhheSBtZW5zYWplcy4gRXNjcmliZSBhbGdvIGFiYWpvIHBhcmEgaW5pY2lhci48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogQ2FqYSBkZSBFbnRyYWRhIGRlIFRleHRvICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVNlbmRNZXNzYWdlfSBjbGFzc05hbWU9XCJwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS05MDAgZmxleCBnYXAtMiBzaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2hhdE1lc3NhZ2VUZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2hhdE1lc3NhZ2VUZXh0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVzY3JpYmUgdW4gbWVuc2FqZSBkZSBzb3BvcnRlLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtMyBweS0yIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWFtYmVyLTUwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgcGxhY2Vob2xkZXItc2xhdGUtNjUwIGZvY3VzOm91dGxpbmUtbm9uZSBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCBhY3RpdmU6c2NhbGUtOTUgdGV4dC1zbGF0ZS05NTAgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBjdXJzb3ItcG9pbnRlciBzaGFkb3ctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRW52aWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNjAwIHNwYWNlLXktMi41IHNlbGVjdC1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8TWVzc2FnZVNxdWFyZSBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgb3BhY2l0eS0xNSBhbmltYXRlLWJvdW5jZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZFwiPlNlbGVjY2lvbmEgdW4gY29udGFjdG8gZGVsIHBhbmVsIGl6cXVpZXJkbyBwYXJhIGNoYXRlYXI8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTU1MCB0ZXh0LWNlbnRlciBtYXgtdy14cyBsZWFkaW5nLW5vcm1hbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBMb3MgYWRtaW5pc3RyYWRvcmVzIGNoYXRlYW4gY29uIHRyYWJhamFkb3JlcyB5IGNsaWVudGVzLiBMb3MgdHJhYmFqYWRvcmVzIGNvbiBhZG1pbmlzdHJhZG9yZXMgeSBjbGllbnRlcy4gTG9zIGNsaWVudGVzIHNvbG8gY29uIGFkbWluaXN0cmFkb3Jlcy5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTg1MCBzaHJpbmstMCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dDaGF0TW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIuNSBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDZXJyYXJcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFNpZGViYXJMYXlvdXQ7XHJcbiJdfQ==