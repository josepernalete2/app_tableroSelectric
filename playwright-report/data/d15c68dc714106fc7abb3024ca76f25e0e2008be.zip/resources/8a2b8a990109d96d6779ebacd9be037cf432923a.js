import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CcmComponent.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f49807c8";
import { Cpu, Building2, Zap, Activity, ShieldCheck, AlertCircle, Printer, User, Calendar, Clock, Plus, Trash2, Layers, Thermometer, CheckSquare, FileText, Settings } from "/node_modules/.vite/deps/lucide-react.js?v=f49807c8";
import ModalEdicionCircuito from "/src/components/ModalEdicionCircuito.jsx?t=1790793566895";
import useStore from "/src/store/useStore.js?t=1790792337841";
var _jsxFileName = "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/CcmComponent.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f49807c8";
var _s = $RefreshSig$();
export default function CcmComponent({ ccmData, onUpdate, readOnly }) {
	_s();
	const { companies, crearElementoProvisional } = useStore();
	const [modalJerarquiaOpen, setModalJerarquiaOpen] = useState(false);
	const [circuitDataWizard, setCircuitDataWizard] = useState(null);
	const [wizardModo, setWizardModo] = useState("SALIDA");
	if (!ccmData) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "text-center p-8 text-slate-400",
			children: "No hay datos de CCM seleccionados."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 12
		}, this);
	}
	const { id, nombre = "", plantaInstalacion = "", areaProceso = "", fabricanteMarca = "", modeloSerie = "", gradoNemaIp = "", fecha = "", inspector = "", supervisor = "", anoFabricacionInstalacion = "", parametrosElectricos = {}, gavetasBucketLog = [], inspeccionFisica = {}, seguridadTermografia = {}, hallazgosCriticos = [], firmaInspector = "", firmaSupervisor = "" } = ccmData;
	const updateField = (field, value) => {
		if (readOnly) return;
		onUpdate({
			...ccmData,
			[field]: value
		});
	};
	const updateParametro = (key, field, value) => {
		if (readOnly) return;
		const currentParams = ccmData.parametrosElectricos || {};
		const paramObj = currentParams[key] || {};
		onUpdate({
			...ccmData,
			parametrosElectricos: {
				...currentParams,
				[key]: {
					...paramObj,
					[field]: value
				}
			}
		});
	};
	const updateInspeccionFisica = (key, field, value) => {
		if (readOnly) return;
		const currentFisica = ccmData.inspeccionFisica || {};
		const itemObj = currentFisica[key] || {};
		onUpdate({
			...ccmData,
			inspeccionFisica: {
				...currentFisica,
				[key]: {
					...itemObj,
					[field]: value
				}
			}
		});
	};
	const updateSeguridad = (key, field, value) => {
		if (readOnly) return;
		const currentSeg = ccmData.seguridadTermografia || {};
		const itemObj = currentSeg[key] || {};
		onUpdate({
			...ccmData,
			seguridadTermografia: {
				...currentSeg,
				[key]: {
					...itemObj,
					[field]: value
				}
			}
		});
	};
	// Lógica para Gavetas (Bucket Log)
	const addGaveta = () => {
		if (readOnly) return;
		const currentGavetas = ccmData.gavetasBucketLog || [];
		const newGaveta = {
			id: "g-" + Date.now() + "-" + Math.round(Math.random() * 1e3),
			gaveta: `G-0${currentGavetas.length + 1}`,
			tagEquipo: "",
			hpKw: "",
			tipoArranque: "Directo (DOL)",
			proteccion: "",
			marcaModeloVfd: "",
			redComms: "",
			estadoObs: "Operativo"
		};
		onUpdate({
			...ccmData,
			gavetasBucketLog: [...currentGavetas, newGaveta]
		});
	};
	const updateGaveta = (gavetaId, field, value) => {
		if (readOnly) return;
		const currentGavetas = ccmData.gavetasBucketLog || [];
		const updatedGavetas = currentGavetas.map((g) => {
			if (g.id === gavetaId) {
				return {
					...g,
					[field]: value
				};
			}
			return g;
		});
		onUpdate({
			...ccmData,
			gavetasBucketLog: updatedGavetas
		});
	};
	const deleteGaveta = (gavetaId) => {
		if (readOnly) return;
		const currentGavetas = ccmData.gavetasBucketLog || [];
		onUpdate({
			...ccmData,
			gavetasBucketLog: currentGavetas.filter((g) => g.id !== gavetaId)
		});
	};
	// Lógica para Hallazgos Críticos
	const addHallazgo = () => {
		if (readOnly) return;
		const currentHallazgos = ccmData.hallazgosCriticos || [];
		const newHallazgo = {
			id: "h-" + Date.now(),
			itemNum: String(currentHallazgos.length + 1).padStart(2, "0"),
			descripcion: ""
		};
		onUpdate({
			...ccmData,
			hallazgosCriticos: [...currentHallazgos, newHallazgo]
		});
	};
	const updateHallazgo = (hId, value) => {
		if (readOnly) return;
		const currentHallazgos = ccmData.hallazgosCriticos || [];
		onUpdate({
			...ccmData,
			hallazgosCriticos: currentHallazgos.map((h) => h.id === hId ? {
				...h,
				descripcion: value
			} : h)
		});
	};
	const deleteHallazgo = (hId) => {
		if (readOnly) return;
		const currentHallazgos = ccmData.hallazgosCriticos || [];
		onUpdate({
			...ccmData,
			hallazgosCriticos: currentHallazgos.filter((h) => h.id !== hId)
		});
	};
	// Valores predeterminados de gavetas si está vacío
	const defaultGavetas = ccmData.gavetasBucketLog && ccmData.gavetasBucketLog.length > 0 ? ccmData.gavetasBucketLog : [
		{
			id: "g-1",
			gaveta: "G-01",
			tagEquipo: "Bomba Agua Potable 1",
			hpKw: "25 HP",
			tipoArranque: "Directo (DOL)",
			proteccion: "Guardamotor 32A",
			marcaModeloVfd: "N/A (Contactor)",
			redComms: "Modbus RTU",
			estadoObs: "Operativo"
		},
		{
			id: "g-2",
			gaveta: "G-02",
			tagEquipo: "Ventilador Tiro Forzado",
			hpKw: "50 HP",
			tipoArranque: "VFD",
			proteccion: "Breaker C63A",
			marcaModeloVfd: "PowerFlex 525",
			redComms: "EtherNet/IP",
			estadoObs: "Operativo"
		},
		{
			id: "g-3",
			gaveta: "G-03",
			tagEquipo: "Agitador Tanque A",
			hpKw: "15 HP",
			tipoArranque: "Estrella-Triáng.",
			proteccion: "Contactor + Térmico",
			marcaModeloVfd: "N/A",
			redComms: "Discreta",
			estadoObs: "Mantenim."
		},
		{
			id: "g-4",
			gaveta: "G-04",
			tagEquipo: "RESERVA DISPONIBLE",
			hpKw: "-",
			tipoArranque: "-",
			proteccion: "-",
			marcaModeloVfd: "-",
			redComms: "-",
			estadoObs: "Disponible"
		}
	];
	const defaultHallazgos = ccmData.hallazgosCriticos && ccmData.hallazgosCriticos.length > 0 ? ccmData.hallazgosCriticos : [{
		id: "h-1",
		itemNum: "01",
		descripcion: "Sustitución recomendada de filtros de polvo obstruidos en gabinete superior."
	}, {
		id: "h-2",
		itemNum: "02",
		descripcion: "Se sugiere actualización del diagrama unifilar en puerta de acceso."
	}];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `w-full text-slate-100 bg-slate-900/60 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl backdrop-blur-md select-text max-w-5xl mx-auto space-y-8 print-card print:bg-white print:text-slate-900 print:border-none print:shadow-none print:p-0 print:m-0 ${readOnly ? "pointer-events-none opacity-90" : ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-slate-800 print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-amber-500 font-extrabold uppercase tracking-widest print:text-amber-700",
						children: "Formato de Levantamiento de Información Técnica"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl md:text-2xl font-extrabold text-slate-100 tracking-wide mt-1 print:text-slate-900",
						children: "Centro de Control de Motores (CCM) Industrial"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 217,
						columnNumber: 11
					}, this),
					nombre && /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs font-semibold text-slate-400 mt-1 print:text-slate-600",
						children: ["Tag / Identificación: ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-amber-400 font-bold print:text-slate-900",
							children: nombre
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 222,
							columnNumber: 37
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 221,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 213,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => window.print(),
						className: "no-print bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-2 rounded-xl flex items-center gap-2 text-xs transition-all cursor-pointer shadow-md",
						title: "Guardar como PDF o Imprimir esta Inspección de CCM",
						children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 232,
							columnNumber: 13
						}, this), " Guardar PDF"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 227,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "inline-flex items-center justify-center font-mono font-black text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/30 text-xs shadow-sm",
						children: ["ID: ", id]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 234,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 226,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-2.5 flex items-center gap-2 print:text-slate-900 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 11
					}, this), " 1. Datos Generales e Identificación"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 242,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[10px] font-bold text-slate-400 print:text-slate-700 uppercase",
								children: "Planta / Instalación"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 248,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: plantaInstalacion,
								onChange: (e) => updateField("plantaInstalacion", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300",
								placeholder: "Ej. Planta Procesadora Central"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[10px] font-bold text-slate-400 print:text-slate-700 uppercase",
								children: "Área / Proceso"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 259,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: areaProceso,
								onChange: (e) => updateField("areaProceso", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300",
								placeholder: "Ej. Cuarto Eléctrico 02 - Bombeo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 260,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 258,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[10px] font-bold text-slate-400 print:text-slate-700 uppercase",
								children: "Tag / Identificación CCM"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 270,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: nombre,
								onChange: (e) => updateField("nombre", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 font-bold outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300",
								placeholder: "Ej. CCM-IND-01"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 271,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 269,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[10px] font-bold text-slate-400 print:text-slate-700 uppercase",
								children: "Fabricante / Marca"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 281,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: fabricanteMarca,
								onChange: (e) => updateField("fabricanteMarca", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300",
								placeholder: "Ej. Allen-Bradley / Siemens / Schneider"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 282,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 280,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[10px] font-bold text-slate-400 print:text-slate-700 uppercase",
								children: "Modelo / Serie"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: modeloSerie,
								onChange: (e) => updateField("modeloSerie", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300",
								placeholder: "Ej. Centerline 2100 / SN-948102"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 293,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 291,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[10px] font-bold text-slate-400 print:text-slate-700 uppercase",
								children: "Grado NEMA / IP"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: gradoNemaIp,
								onChange: (e) => updateField("gradoNemaIp", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300",
								placeholder: "Ej. NEMA 12 / IP54"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 304,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 302,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[10px] font-bold text-slate-400 print:text-slate-700 uppercase",
								children: "Fecha del Levantamiento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 314,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "date",
								value: fecha,
								onChange: (e) => updateField("fecha", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 313,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[10px] font-bold text-slate-400 print:text-slate-700 uppercase",
								children: "Levantado por (Inspector)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 324,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: inspector,
								onChange: (e) => updateField("inspector", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all print:bg-white print:text-slate-900 print:border-gray-300",
								placeholder: "Nombre del Inspector"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-[10px] font-bold text-slate-400 print:text-slate-700 uppercase",
								children: "Año Fabricación / Instalación"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: anoFabricacionInstalacion,
								onChange: (e) => updateField("anoFabricacionInstalacion", e.target.value),
								className: "bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all font-mono print:bg-white print:text-slate-900 print:border-gray-300",
								placeholder: "Ej. 2018 / 2019"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 336,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 246,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 241,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-2.5 flex items-center gap-2 print:text-slate-900 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 350,
						columnNumber: 11
					}, this), " 2. Parámetros Eléctricos Generales"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 349,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-xs border-collapse",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900 text-slate-400 text-[10px] font-extrabold uppercase border-b border-slate-800 print:bg-slate-100 print:text-slate-700 print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Parámetro Eléctrico"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 357,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Valor Nominal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 358,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Valor Medido / Ajuste"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 359,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Notas / Observaciones"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 360,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 356,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 355,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800/60 print:divide-gray-200",
							children: [
								{
									key: "tensionPrincipal",
									label: "Tensión Principal Nominal (V)",
									defNominal: "480V / 380V"
								},
								{
									key: "frecuencia",
									label: "Frecuencia (Hz)",
									defNominal: "60 Hz / 50 Hz"
								},
								{
									key: "sistemaFases",
									label: "Sistema de Fases e Hilos",
									defNominal: "3Ø3W / 3Ø4W"
								},
								{
									key: "busPrincipal",
									label: "Capacidad de Bus Principal (A)",
									defNominal: "2000 A"
								},
								{
									key: "sccrCorto",
									label: "Nivel de Cortocircuito / SCCR (kA)",
									defNominal: "65 kA"
								},
								{
									key: "tensionControl",
									label: "Tensión de Control / Auxiliar",
									defNominal: "110V AC / 24V DC"
								},
								{
									key: "interruptorMain",
									label: "Interruptor Principal (Main)",
									defNominal: "Marca/Modelo/Amp"
								}
							].map((p) => {
								const itemData = parametrosElectricos[p.key] || {};
								return /* @__PURE__ */ _jsxDEV("tr", {
									className: "hover:bg-slate-900/30 print:hover:bg-transparent",
									children: [
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-2 px-3 font-semibold text-slate-200 print:text-slate-800",
											children: p.label
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 376,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-2 px-3",
											children: /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: itemData.nominal || "",
												onChange: (e) => updateParametro(p.key, "nominal", e.target.value),
												placeholder: p.defNominal,
												className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2.5 py-1 text-xs text-slate-100 outline-none font-mono print:bg-white print:text-slate-900 print:border-gray-300"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 378,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 377,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-2 px-3",
											children: /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: itemData.medido || "",
												onChange: (e) => updateParametro(p.key, "medido", e.target.value),
												placeholder: "Medido / Ajustado",
												className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2.5 py-1 text-xs text-slate-100 outline-none font-mono print:bg-white print:text-slate-900 print:border-gray-300"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 387,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 386,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-2 px-3",
											children: /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: itemData.notas || "",
												onChange: (e) => updateParametro(p.key, "notas", e.target.value),
												placeholder: "Observaciones...",
												className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2.5 py-1 text-xs text-slate-100 outline-none print:bg-white print:text-slate-900 print:border-gray-300"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 396,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 395,
											columnNumber: 21
										}, this)
									]
								}, p.key, true, {
									fileName: _jsxFileName,
									lineNumber: 375,
									columnNumber: 19
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 363,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 354,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 353,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 348,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-between items-center border-b border-slate-800 pb-2.5 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-amber-500 flex items-center gap-2 print:text-slate-900",
						children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 416,
							columnNumber: 13
						}, this), " 3. Registro Técnico de Gavetas / Compartimentos (Bucket Log)"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 415,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: addGaveta,
						className: "no-print bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-400 font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-xs transition-all cursor-pointer",
						children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 423,
							columnNumber: 13
						}, this), " Agregar Gaveta"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 418,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 414,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-xs border-collapse",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-slate-900 text-slate-400 text-[10px] font-extrabold uppercase border-b border-slate-800 print:bg-slate-100 print:text-slate-700 print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-2.5 w-16",
									children: "Gaveta"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 431,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-2.5",
									children: "Tag Equipo / Motor"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-2.5 w-20",
									children: "HP / kW"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 433,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-2.5",
									children: "Tipo Arranque"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-2.5",
									children: "Protección / Breaker"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 435,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-2.5",
									children: "Marca/Modelo VFD o Arrancador"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-2.5",
									children: "Red / Comms"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 437,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-2.5",
									children: "Estado / Obs."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", { className: "py-2.5 px-2 w-10 no-print" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 439,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 430,
							columnNumber: 15
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 429,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800/60 print:divide-gray-200",
							children: defaultGavetas.map((g) => /* @__PURE__ */ _jsxDEV("tr", {
								className: "hover:bg-slate-900/30 print:hover:bg-transparent",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2 px-2",
										children: /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: g.gaveta,
											onChange: (e) => updateGaveta(g.id, "gaveta", e.target.value),
											className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2 py-1 text-xs text-slate-100 outline-none font-mono font-bold print:bg-white print:text-slate-900 print:border-gray-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 446,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 445,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2 px-2",
										children: /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: g.tagEquipo,
											onChange: (e) => updateGaveta(g.id, "tagEquipo", e.target.value),
											placeholder: "Ej. Bomba Agua Potable",
											className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2 py-1 text-xs text-slate-100 outline-none print:bg-white print:text-slate-900 print:border-gray-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 454,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 453,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2 px-2",
										children: /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: g.hpKw,
											onChange: (e) => updateGaveta(g.id, "hpKw", e.target.value),
											placeholder: "25 HP",
											className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2 py-1 text-xs text-slate-100 outline-none font-mono print:bg-white print:text-slate-900 print:border-gray-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 463,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 462,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2 px-2",
										children: /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: g.tipoArranque,
											onChange: (e) => updateGaveta(g.id, "tipoArranque", e.target.value),
											placeholder: "DOL / VFD / SoftStart",
											className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2 py-1 text-xs text-slate-100 outline-none print:bg-white print:text-slate-900 print:border-gray-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 472,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 471,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2 px-2",
										children: /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: g.proteccion,
											onChange: (e) => updateGaveta(g.id, "proteccion", e.target.value),
											placeholder: "Guardamotor 32A",
											className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2 py-1 text-xs text-slate-100 outline-none print:bg-white print:text-slate-900 print:border-gray-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 481,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 480,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2 px-2",
										children: /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: g.marcaModeloVfd,
											onChange: (e) => updateGaveta(g.id, "marcaModeloVfd", e.target.value),
											placeholder: "PowerFlex 525 / N/A",
											className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2 py-1 text-xs text-slate-100 outline-none print:bg-white print:text-slate-900 print:border-gray-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 490,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 489,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2 px-2",
										children: /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: g.redComms,
											onChange: (e) => updateGaveta(g.id, "redComms", e.target.value),
											placeholder: "EtherNet/IP / Modbus",
											className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2 py-1 text-xs text-slate-100 outline-none print:bg-white print:text-slate-900 print:border-gray-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 499,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 498,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2 px-2",
										children: /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: g.estadoObs,
											onChange: (e) => updateGaveta(g.id, "estadoObs", e.target.value),
											placeholder: "Operativo / Mantenim.",
											className: "w-full bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-lg px-2 py-1 text-xs text-slate-100 outline-none print:bg-white print:text-slate-900 print:border-gray-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 508,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 507,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2 px-1 text-center no-print",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => {
													setWizardModo("SALIDA");
													setCircuitDataWizard({
														id: g.id,
														nombre: `Gaveta ${g.gaveta} (${g.tagEquipo || "Sin Tag"})`,
														equipo: g.tagEquipo || "",
														poles: [1],
														breaker: {
															amp: g.proteccion || "",
															marca: "",
															tipo: ""
														}
													});
													setModalJerarquiaOpen(true);
												},
												className: "p-1 hover:bg-amber-500/20 text-amber-400 rounded-lg transition-all cursor-pointer",
												title: "Configurar Conexión / Carga (Wizard)",
												children: /* @__PURE__ */ _jsxDEV(Settings, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 534,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 518,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => deleteGaveta(g.id),
												className: "p-1 hover:bg-red-955/20 text-slate-500 hover:text-red-400 rounded-lg transition-all cursor-pointer",
												title: "Eliminar Gaveta",
												children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 542,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 536,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 517,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 516,
										columnNumber: 19
									}, this)
								]
							}, g.id, true, {
								fileName: _jsxFileName,
								lineNumber: 444,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 442,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 428,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 427,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 413,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-2.5 flex items-center gap-2 print:text-slate-900 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 556,
						columnNumber: 11
					}, this), " 4. Inspección Física y Ambiental del Gabinete"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 555,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4",
					children: [[
						{
							key: "limpiezaPolvo",
							label: "Limpieza Interna / Polvo",
							options: [
								"Buena",
								"Aceptable",
								"Polvo / Acumulación Crítica"
							]
						},
						{
							key: "humedadAgua",
							label: "Humedad / Evidencia de Agua",
							options: [
								"Ausente",
								"Filtración Superior",
								"Condensación"
							]
						},
						{
							key: "acometidaCables",
							label: "Acometida / Entrada Cables",
							options: ["Superior", "Inferior"]
						},
						{
							key: "ventilacion",
							label: "Ventilación y Extracción",
							options: [
								"Operativo",
								"Filtros Obstruidos",
								"Inoperativo"
							]
						},
						{
							key: "puestaTierra",
							label: "Puesta a Tierra (Malla General)",
							options: [
								"Conectada y Ajustada",
								"Corroída",
								"Desconectada"
							]
						}
					].map((item) => {
						const dataObj = inspeccionFisica[item.key] || {};
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-slate-900/40 border border-slate-800/80 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 print:bg-gray-50 print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-slate-200 w-48 print:text-slate-800",
									children: item.label
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 570,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap gap-2",
									children: item.options.map((opt) => {
										const isSelected = dataObj.estado === opt;
										return /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => updateInspeccionFisica(item.key, "estado", opt),
											className: `px-2.5 py-1 rounded-lg border text-[10px] font-bold transition-all cursor-pointer ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-white print:text-slate-700 print:border-gray-300"}`,
											children: [
												"[ ",
												isSelected ? "✓" : " ",
												" ] ",
												opt
											]
										}, opt, true, {
											fileName: _jsxFileName,
											lineNumber: 575,
											columnNumber: 23
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 571,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: dataObj.observaciones || "",
									onChange: (e) => updateInspeccionFisica(item.key, "observaciones", e.target.value),
									placeholder: "Observaciones específicas...",
									className: "flex-1 min-w-[200px] bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-1.5 text-xs text-slate-100 outline-none print:bg-white print:text-slate-900 print:border-gray-300"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 590,
									columnNumber: 17
								}, this)
							]
						}, item.key, true, {
							fileName: _jsxFileName,
							lineNumber: 569,
							columnNumber: 15
						}, this);
					}), /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 bg-slate-900/40 border border-slate-800/80 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 print:bg-gray-50 print:border-gray-300",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-slate-200 w-48 print:text-slate-800 flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(Thermometer, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 604,
								columnNumber: 15
							}, this), " Temperatura Cuarto CCM"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 603,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-400 print:text-slate-700",
									children: "Medida:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 607,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: inspeccionFisica.temperaturaMedida || "",
									onChange: (e) => updateField("inspeccionFisica", {
										...inspeccionFisica,
										temperaturaMedida: e.target.value
									}),
									placeholder: "24 °C",
									className: "w-24 bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-2.5 py-1 text-xs text-slate-100 font-mono outline-none print:bg-white print:text-slate-900 print:border-gray-300"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 608,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-400 print:text-slate-700 ml-2",
									children: "Aire Acondicionado:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 615,
									columnNumber: 15
								}, this),
								["Sí", "No"].map((opt) => {
									const isSelected = inspeccionFisica.aireAcondicionado === opt;
									return /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => updateField("inspeccionFisica", {
											...inspeccionFisica,
											aireAcondicionado: opt
										}),
										className: `px-3 py-1 rounded-lg border text-[10px] font-bold transition-all cursor-pointer ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-white print:text-slate-700 print:border-gray-300"}`,
										children: [
											"[ ",
											isSelected ? "✓" : " ",
											" ] ",
											opt
										]
									}, opt, true, {
										fileName: _jsxFileName,
										lineNumber: 619,
										columnNumber: 19
									}, this);
								})
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 606,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 602,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 559,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 554,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-amber-500 border-b border-slate-800 pb-2.5 flex items-center gap-2 print:text-slate-900 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 641,
						columnNumber: 11
					}, this), " 5. Seguridad, Señalética y Termografía Predictiva"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 640,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-3",
					children: [
						{
							key: "arcFlash",
							label: "Etiquetado Arc Flash (Riesgo)",
							options: ["Presente y Legible", "Ausente / Ilegible"]
						},
						{
							key: "unifilarPuerta",
							label: "Diagrama Unifilar en Puerta",
							options: [
								"Actualizado",
								"Desactualizado",
								"No Existe"
							]
						},
						{
							key: "interlockMecanico",
							label: "Interlock Mecánico de Puertas",
							options: ["Operativo / Funcional", "Forzado / Inoperativo"]
						},
						{
							key: "inspeccionTermografica",
							label: "Inspección Termográfica",
							options: ["Sin Puntos Calientes", "Punto Caliente Detectado"]
						}
					].map((item) => {
						const dataObj = seguridadTermografia[item.key] || {};
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-slate-900/40 border border-slate-800/80 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 print:bg-gray-50 print:border-gray-300",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-slate-200 w-52 print:text-slate-800",
									children: item.label
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 654,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap gap-2",
									children: item.options.map((opt) => {
										const isSelected = dataObj.estado === opt;
										return /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => updateSeguridad(item.key, "estado", opt),
											className: `px-2.5 py-1 rounded-lg border text-[10px] font-bold transition-all cursor-pointer ${isSelected ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md print:bg-amber-100 print:text-slate-900 print:border-amber-600" : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 print:bg-white print:text-slate-700 print:border-gray-300"}`,
											children: [
												"[ ",
												isSelected ? "✓" : " ",
												" ] ",
												opt
											]
										}, opt, true, {
											fileName: _jsxFileName,
											lineNumber: 659,
											columnNumber: 23
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 655,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: dataObj.detalle || "",
									onChange: (e) => updateSeguridad(item.key, "detalle", e.target.value),
									placeholder: "Detalle / Registro de Anomalía...",
									className: "flex-1 min-w-[200px] bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-1.5 text-xs text-slate-100 outline-none print:bg-white print:text-slate-900 print:border-gray-300"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 674,
									columnNumber: 17
								}, this)
							]
						}, item.key, true, {
							fileName: _jsxFileName,
							lineNumber: 653,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 644,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 639,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-white print:border-gray-300",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-between items-center border-b border-slate-800 pb-2.5 print:border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-amber-500 flex items-center gap-2 print:text-slate-900",
						children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 691,
							columnNumber: 13
						}, this), " 6. Observaciones y Hallazgos Críticos"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 690,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: addHallazgo,
						className: "no-print bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-400 font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-xs transition-all cursor-pointer",
						children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 698,
							columnNumber: 13
						}, this), " Agregar Hallazgo"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 693,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 689,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2.5",
					children: defaultHallazgos.map((h) => /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono font-bold text-amber-500 print:bg-gray-100 print:text-slate-900 print:border-gray-300",
								children: h.itemNum
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 705,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: h.descripcion,
								onChange: (e) => updateHallazgo(h.id, e.target.value),
								placeholder: "Descripción del hallazgo crítico o recomendación de mantenimiento...",
								className: "flex-1 bg-slate-900/60 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none transition-all print:bg-white print:text-slate-900 print:border-gray-300"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 708,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => deleteHallazgo(h.id),
								className: "p-2 hover:bg-red-955/40 text-slate-500 hover:text-red-400 rounded-lg transition-all cursor-pointer no-print",
								title: "Eliminar Hallazgo",
								children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 721,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 715,
								columnNumber: 15
							}, this)
						]
					}, h.id, true, {
						fileName: _jsxFileName,
						lineNumber: 704,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 702,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 688,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 print:bg-slate-50 print:border-gray-300 print:mt-4",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-900 pb-2.5 print:text-slate-700 print:border-gray-300",
					children: "7. Control de Registro y Firmas de Conformidad"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 730,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-2 items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-700",
								children: "Realizado por (Inspector de Campo)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 737,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: firmaInspector,
								onChange: (e) => updateField("firmaInspector", e.target.value),
								className: "w-full max-w-xs bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all text-center no-print",
								placeholder: "Firma / Nombre del Inspector"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 738,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "hidden print:block text-xs font-bold text-slate-900 mt-1 h-6",
								children: firmaInspector || "___________________________"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 745,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "hidden print:block w-48 border-b border-gray-400 mt-6 h-1" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 748,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 736,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-2 items-center text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wide print:text-slate-700",
								children: "Revisado y Aprobado por (Supervisor)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 753,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: firmaSupervisor,
								onChange: (e) => updateField("firmaSupervisor", e.target.value),
								className: "w-full max-w-xs bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none h-10 transition-all text-center no-print",
								placeholder: "Firma / Nombre del Supervisor"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 754,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "hidden print:block text-xs font-bold text-slate-900 mt-1 h-6",
								children: firmaSupervisor || "___________________________"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 761,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "hidden print:block w-48 border-b border-gray-400 mt-6 h-1" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 764,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 752,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 734,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 729,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ModalEdicionCircuito, {
				isOpen: modalJerarquiaOpen,
				onClose: () => setModalJerarquiaOpen(false),
				circuitData: circuitDataWizard,
				modo: wizardModo,
				tipoOrigen: "CCM",
				elementosCreados: [],
				onSave: (circuitId, updated) => {
					if (updated.tipoDestino === "SUB_TABLERO_PENDIENTE" && ccmData.proyectoId) {
						const existingProvId = updated.elementoDestinoId || updated.vinculadoId;
						let prov = null;
						if (existingProvId) {
							prov = (companies || []).flatMap((c) => c.proyectos || []).flatMap((p) => p.elementosUnifilares || p.tableros || []).find((e) => e.id === existingProvId);
						}
						if (!prov) {
							prov = crearElementoProvisional(ccmData.proyectoId, {
								nombre: updated.equipo && updated.equipo !== "RESERVA (Pendiente por Crear)" ? updated.equipo : `Sub-Tablero desde CCM (${circuitId})`,
								tipoElemento: "TABLERO",
								circuitoOrigen: circuitId
							});
						}
						if (prov) {
							updated.vinculadoId = prov.id;
							updated.elementoDestinoId = prov.id;
							updated.tipoElementoDestino = "TABLERO";
							updated.equipo = `${prov.nombre} (ID: ${prov.id})`;
							updated.tipoDestino = "SUB_TABLERO";
						}
					}
					if (updated.equipo) updateGaveta(circuitId, "tagEquipo", updated.equipo);
					if (updated.detallesTecnicos?.esquemaArranque) updateGaveta(circuitId, "tipoArranque", updated.detallesTecnicos.esquemaArranque);
					if (updated.detallesTecnicos?.hpKw) updateGaveta(circuitId, "hpKw", updated.detallesTecnicos.hpKw);
					if (updated.detallesTecnicos?.proteccion || updated.breaker?.amp) updateGaveta(circuitId, "proteccion", updated.detallesTecnicos?.proteccion || updated.breaker?.amp);
					if (updated.detallesTecnicos?.redComms) updateGaveta(circuitId, "redComms", updated.detallesTecnicos.redComms);
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 769,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 209,
		columnNumber: 5
	}, this);
}
_s(CcmComponent, "8Gdf4PQVCuNtNdU6gKF/Vt5CF70=", false, function() {
	return [useStore];
});
_c = CcmComponent;
var _c;
$RefreshReg$(_c, "CcmComponent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/CcmComponent.jsx?t=1790793566895";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/CcmComponent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/CcmComponent.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/jose/app_tableroSelectric/app_tableroSelectric/src/components/CcmComponent.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLEtBQ0EsV0FDQSxLQUNBLFVBQ0EsYUFDQSxhQUNBLFNBQ0EsTUFDQSxVQUNBLE9BQ0EsTUFDQSxRQUNBLFFBQ0EsYUFDQSxhQUNBLFVBQ0EsZ0JBQ0s7QUFDUCxPQUFPLDBCQUEwQjtBQUNqQyxPQUFPLGNBQWM7Ozs7QUFFckIsZUFBZSxTQUFTLGFBQWEsRUFBRSxTQUFTLFVBQVUsWUFBWTs7Q0FDcEUsTUFBTSxFQUFFLFdBQVcsNkJBQTZCLFNBQVM7Q0FDekQsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBUyxLQUFLO0NBQ2xFLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsSUFBSTtDQUMvRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxRQUFRO0NBQ3JELElBQUksQ0FBQyxTQUFTO0VBQ1osT0FBTyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFpQztFQUF1Qzs7Ozs7Q0FDaEc7Q0FFQSxNQUFNLEVBQ0osSUFDQSxTQUFTLElBQ1Qsb0JBQW9CLElBQ3BCLGNBQWMsSUFDZCxrQkFBa0IsSUFDbEIsY0FBYyxJQUNkLGNBQWMsSUFDZCxRQUFRLElBQ1IsWUFBWSxJQUNaLGFBQWEsSUFDYiw0QkFBNEIsSUFHNUIsdUJBQXVCLENBQUMsR0FDeEIsbUJBQW1CLENBQUMsR0FDcEIsbUJBQW1CLENBQUMsR0FDcEIsdUJBQXVCLENBQUMsR0FDeEIsb0JBQW9CLENBQUMsR0FFckIsaUJBQWlCLElBQ2pCLGtCQUFrQixPQUNoQjtDQUVKLE1BQU0sZUFBZSxPQUFPLFVBQVU7RUFDcEMsSUFBSSxVQUFVO0VBQ2QsU0FBUztHQUNQLEdBQUc7SUFDRixRQUFRO0VBQ1gsQ0FBQztDQUNIO0NBRUEsTUFBTSxtQkFBbUIsS0FBSyxPQUFPLFVBQVU7RUFDN0MsSUFBSSxVQUFVO0VBQ2QsTUFBTSxnQkFBZ0IsUUFBUSx3QkFBd0IsQ0FBQztFQUN2RCxNQUFNLFdBQVcsY0FBYyxRQUFRLENBQUM7RUFDeEMsU0FBUztHQUNQLEdBQUc7R0FDSCxzQkFBc0I7SUFDcEIsR0FBRztLQUNGLE1BQU07S0FDTCxHQUFHO01BQ0YsUUFBUTtJQUNYO0dBQ0Y7RUFDRixDQUFDO0NBQ0g7Q0FFQSxNQUFNLDBCQUEwQixLQUFLLE9BQU8sVUFBVTtFQUNwRCxJQUFJLFVBQVU7RUFDZCxNQUFNLGdCQUFnQixRQUFRLG9CQUFvQixDQUFDO0VBQ25ELE1BQU0sVUFBVSxjQUFjLFFBQVEsQ0FBQztFQUN2QyxTQUFTO0dBQ1AsR0FBRztHQUNILGtCQUFrQjtJQUNoQixHQUFHO0tBQ0YsTUFBTTtLQUNMLEdBQUc7TUFDRixRQUFRO0lBQ1g7R0FDRjtFQUNGLENBQUM7Q0FDSDtDQUVBLE1BQU0sbUJBQW1CLEtBQUssT0FBTyxVQUFVO0VBQzdDLElBQUksVUFBVTtFQUNkLE1BQU0sYUFBYSxRQUFRLHdCQUF3QixDQUFDO0VBQ3BELE1BQU0sVUFBVSxXQUFXLFFBQVEsQ0FBQztFQUNwQyxTQUFTO0dBQ1AsR0FBRztHQUNILHNCQUFzQjtJQUNwQixHQUFHO0tBQ0YsTUFBTTtLQUNMLEdBQUc7TUFDRixRQUFRO0lBQ1g7R0FDRjtFQUNGLENBQUM7Q0FDSDs7Q0FHQSxNQUFNLGtCQUFrQjtFQUN0QixJQUFJLFVBQVU7RUFDZCxNQUFNLGlCQUFpQixRQUFRLG9CQUFvQixDQUFDO0VBQ3BELE1BQU0sWUFBWTtHQUNoQixJQUFJLE9BQU8sS0FBSyxJQUFJLElBQUksTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksR0FBSTtHQUM3RCxRQUFRLE1BQU0sZUFBZSxTQUFTO0dBQ3RDLFdBQVc7R0FDWCxNQUFNO0dBQ04sY0FBYztHQUNkLFlBQVk7R0FDWixnQkFBZ0I7R0FDaEIsVUFBVTtHQUNWLFdBQVc7RUFDYjtFQUNBLFNBQVM7R0FDUCxHQUFHO0dBQ0gsa0JBQWtCLENBQUMsR0FBRyxnQkFBZ0IsU0FBUztFQUNqRCxDQUFDO0NBQ0g7Q0FFQSxNQUFNLGdCQUFnQixVQUFVLE9BQU8sVUFBVTtFQUMvQyxJQUFJLFVBQVU7RUFDZCxNQUFNLGlCQUFpQixRQUFRLG9CQUFvQixDQUFDO0VBQ3BELE1BQU0saUJBQWlCLGVBQWUsS0FBSyxNQUFNO0dBQy9DLElBQUksRUFBRSxPQUFPLFVBQVU7SUFDckIsT0FBTztLQUFFLEdBQUc7TUFBSSxRQUFRO0lBQU07R0FDaEM7R0FDQSxPQUFPO0VBQ1QsQ0FBQztFQUNELFNBQVM7R0FDUCxHQUFHO0dBQ0gsa0JBQWtCO0VBQ3BCLENBQUM7Q0FDSDtDQUVBLE1BQU0sZ0JBQWdCLGFBQWE7RUFDakMsSUFBSSxVQUFVO0VBQ2QsTUFBTSxpQkFBaUIsUUFBUSxvQkFBb0IsQ0FBQztFQUNwRCxTQUFTO0dBQ1AsR0FBRztHQUNILGtCQUFrQixlQUFlLFFBQVEsTUFBTSxFQUFFLE9BQU8sUUFBUTtFQUNsRSxDQUFDO0NBQ0g7O0NBR0EsTUFBTSxvQkFBb0I7RUFDeEIsSUFBSSxVQUFVO0VBQ2QsTUFBTSxtQkFBbUIsUUFBUSxxQkFBcUIsQ0FBQztFQUN2RCxNQUFNLGNBQWM7R0FDbEIsSUFBSSxPQUFPLEtBQUssSUFBSTtHQUNwQixTQUFTLE9BQU8saUJBQWlCLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7R0FDNUQsYUFBYTtFQUNmO0VBQ0EsU0FBUztHQUNQLEdBQUc7R0FDSCxtQkFBbUIsQ0FBQyxHQUFHLGtCQUFrQixXQUFXO0VBQ3RELENBQUM7Q0FDSDtDQUVBLE1BQU0sa0JBQWtCLEtBQUssVUFBVTtFQUNyQyxJQUFJLFVBQVU7RUFDZCxNQUFNLG1CQUFtQixRQUFRLHFCQUFxQixDQUFDO0VBQ3ZELFNBQVM7R0FDUCxHQUFHO0dBQ0gsbUJBQW1CLGlCQUFpQixLQUFLLE1BQU0sRUFBRSxPQUFPLE1BQU07SUFBRSxHQUFHO0lBQUcsYUFBYTtHQUFNLElBQUksQ0FBQztFQUNoRyxDQUFDO0NBQ0g7Q0FFQSxNQUFNLGtCQUFrQixRQUFRO0VBQzlCLElBQUksVUFBVTtFQUNkLE1BQU0sbUJBQW1CLFFBQVEscUJBQXFCLENBQUM7RUFDdkQsU0FBUztHQUNQLEdBQUc7R0FDSCxtQkFBbUIsaUJBQWlCLFFBQVEsTUFBTSxFQUFFLE9BQU8sR0FBRztFQUNoRSxDQUFDO0NBQ0g7O0NBR0EsTUFBTSxpQkFBa0IsUUFBUSxvQkFBb0IsUUFBUSxpQkFBaUIsU0FBUyxJQUNsRixRQUFRLG1CQUNSO0VBQ0U7R0FBRSxJQUFJO0dBQU8sUUFBUTtHQUFRLFdBQVc7R0FBd0IsTUFBTTtHQUFTLGNBQWM7R0FBaUIsWUFBWTtHQUFtQixnQkFBZ0I7R0FBbUIsVUFBVTtHQUFjLFdBQVc7RUFBWTtFQUMvTjtHQUFFLElBQUk7R0FBTyxRQUFRO0dBQVEsV0FBVztHQUEyQixNQUFNO0dBQVMsY0FBYztHQUFPLFlBQVk7R0FBZ0IsZ0JBQWdCO0dBQWlCLFVBQVU7R0FBZSxXQUFXO0VBQVk7RUFDcE47R0FBRSxJQUFJO0dBQU8sUUFBUTtHQUFRLFdBQVc7R0FBcUIsTUFBTTtHQUFTLGNBQWM7R0FBb0IsWUFBWTtHQUF1QixnQkFBZ0I7R0FBTyxVQUFVO0dBQVksV0FBVztFQUFZO0VBQ3JOO0dBQUUsSUFBSTtHQUFPLFFBQVE7R0FBUSxXQUFXO0dBQXNCLE1BQU07R0FBSyxjQUFjO0dBQUssWUFBWTtHQUFLLGdCQUFnQjtHQUFLLFVBQVU7R0FBSyxXQUFXO0VBQWE7Q0FDM0s7Q0FFSixNQUFNLG1CQUFvQixRQUFRLHFCQUFxQixRQUFRLGtCQUFrQixTQUFTLElBQ3RGLFFBQVEsb0JBQ1IsQ0FDRTtFQUFFLElBQUk7RUFBTyxTQUFTO0VBQU0sYUFBYTtDQUErRSxHQUN4SDtFQUFFLElBQUk7RUFBTyxTQUFTO0VBQU0sYUFBYTtDQUFzRSxDQUNqSDtDQUVKLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVcsa1FBQWtRLFdBQVcsbUNBQW1DO1lBQWhVO0dBR0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBMkY7S0FFckc7Ozs7O0tBQ04sd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQTRGO0tBRXRHOzs7OztLQUNILFVBQ0Msd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWIsQ0FBOEUsMEJBQ3RELHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFpRDtNQUFhOzs7O2NBQ25HOzs7Ozs7SUFFRjs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsZUFBZSxPQUFPLE1BQU07TUFDNUIsV0FBVTtNQUNWLE9BQU07Z0JBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7O2dCQUFDLGNBQ3pCOzs7OztlQUNSLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUFrTCxRQUMzSyxFQUNEOzs7OzthQUNIOzs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHlCQUEwQjs7OztlQUFDLHNDQUM5Qzs7Ozs7Y0FFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBc0U7T0FBMkI7Ozs7aUJBQ2xILHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxZQUFZLHFCQUFxQixFQUFFLE9BQU8sS0FBSztRQUNoRSxXQUFVO1FBQ1YsYUFBWTtPQUNiOzs7O2VBQ0U7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQXNFO09BQXFCOzs7O2lCQUM1Ryx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sWUFBWSxlQUFlLEVBQUUsT0FBTyxLQUFLO1FBQzFELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7ZUFDRTs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBc0U7T0FBK0I7Ozs7aUJBQ3RILHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxZQUFZLFVBQVUsRUFBRSxPQUFPLEtBQUs7UUFDckQsV0FBVTtRQUNWLGFBQVk7T0FDYjs7OztlQUNFOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFzRTtPQUF5Qjs7OztpQkFDaEgsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1FBQzlELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7ZUFDRTs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBc0U7T0FBcUI7Ozs7aUJBQzVHLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxZQUFZLGVBQWUsRUFBRSxPQUFPLEtBQUs7UUFDMUQsV0FBVTtRQUNWLGFBQVk7T0FDYjs7OztlQUNFOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFzRTtPQUFzQjs7OztpQkFDN0csd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksZUFBZSxFQUFFLE9BQU8sS0FBSztRQUMxRCxXQUFVO1FBQ1YsYUFBWTtPQUNiOzs7O2VBQ0U7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQXNFO09BQThCOzs7O2lCQUNySCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sWUFBWSxTQUFTLEVBQUUsT0FBTyxLQUFLO1FBQ3BELFdBQVU7T0FDWDs7OztlQUNFOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFzRTtPQUFnQzs7OztpQkFDdkgsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksYUFBYSxFQUFFLE9BQU8sS0FBSztRQUN4RCxXQUFVO1FBQ1YsYUFBWTtPQUNiOzs7O2VBQ0U7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQXNFO09BQW9DOzs7O2lCQUMzSCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sWUFBWSw2QkFBNkIsRUFBRSxPQUFPLEtBQUs7UUFDeEUsV0FBVTtRQUNWLGFBQVk7T0FDYjs7OztlQUNFOzs7Ozs7S0FDRjs7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx5QkFBMEI7Ozs7ZUFBQyxxQ0FDeEM7Ozs7O2NBRUosd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUF1Qjs7Ozs7UUFDbkQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWM7UUFBaUI7Ozs7O1FBQzdDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFjO1FBQXlCOzs7OztRQUNyRCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUF5Qjs7Ozs7T0FDbkQ7Ozs7O2VBQ0M7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQ2Q7UUFDQztTQUFFLEtBQUs7U0FBb0IsT0FBTztTQUFpQyxZQUFZO1FBQWM7UUFDN0Y7U0FBRSxLQUFLO1NBQWMsT0FBTztTQUFtQixZQUFZO1FBQWdCO1FBQzNFO1NBQUUsS0FBSztTQUFnQixPQUFPO1NBQTRCLFlBQVk7UUFBYztRQUNwRjtTQUFFLEtBQUs7U0FBZ0IsT0FBTztTQUFrQyxZQUFZO1FBQVM7UUFDckY7U0FBRSxLQUFLO1NBQWEsT0FBTztTQUFzQyxZQUFZO1FBQVE7UUFDckY7U0FBRSxLQUFLO1NBQWtCLE9BQU87U0FBaUMsWUFBWTtRQUFtQjtRQUNoRztTQUFFLEtBQUs7U0FBbUIsT0FBTztTQUFnQyxZQUFZO1FBQW1CO09BQ2xHLENBQUMsQ0FBQyxLQUFLLE1BQU07UUFDWCxNQUFNLFdBQVcscUJBQXFCLEVBQUUsUUFBUSxDQUFDO1FBQ2pELE9BQ0Usd0JBQUMsTUFBRDtTQUFnQixXQUFVO21CQUExQjtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUErRCxFQUFFO1VBQVU7Ozs7O1VBQ3pGLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNaLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsT0FBTyxTQUFTLFdBQVc7WUFDM0IsV0FBVyxNQUFNLGdCQUFnQixFQUFFLEtBQUssV0FBVyxFQUFFLE9BQU8sS0FBSztZQUNqRSxhQUFhLEVBQUU7WUFDZixXQUFVO1dBQ1g7Ozs7O1VBQ0M7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1osd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPLFNBQVMsVUFBVTtZQUMxQixXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsS0FBSyxVQUFVLEVBQUUsT0FBTyxLQUFLO1lBQ2hFLGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7O1VBQ0M7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1osd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPLFNBQVMsU0FBUztZQUN6QixXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsS0FBSyxTQUFTLEVBQUUsT0FBTyxLQUFLO1lBQy9ELGFBQVk7WUFDWixXQUFVO1dBQ1g7Ozs7O1VBQ0M7Ozs7O1NBQ0Y7V0E3QkssRUFBRTs7OztlQTZCUDtPQUVSLENBQUM7TUFDSTs7OztjQUNGOzs7Ozs7SUFDSjs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUseUJBQTBCOzs7O2dCQUFDLCtEQUMzQzs7Ozs7ZUFDSix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFNBQVM7TUFDVCxXQUFVO2dCQUhaLENBS0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OztnQkFBQyxpQkFDMUI7Ozs7O2FBQ0w7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBcUI7UUFBVTs7Ozs7UUFDN0Msd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWdCO1FBQXNCOzs7OztRQUNwRCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBcUI7UUFBVzs7Ozs7UUFDOUMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWdCO1FBQWlCOzs7OztRQUMvQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZ0I7UUFBd0I7Ozs7O1FBQ3RELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFnQjtRQUFpQzs7Ozs7UUFDL0Qsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWdCO1FBQWU7Ozs7O1FBQzdDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFnQjtRQUFpQjs7Ozs7UUFDL0Msd0JBQUMsTUFBRCxFQUFJLFdBQVUsNEJBQWdDOzs7OztPQUM1Qzs7Ozs7ZUFDQzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZCxlQUFlLEtBQUssTUFDbkIsd0JBQUMsTUFBRDtRQUFlLFdBQVU7a0JBQXpCO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1osd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLEVBQUU7V0FDVCxXQUFXLE1BQU0sYUFBYSxFQUFFLElBQUksVUFBVSxFQUFFLE9BQU8sS0FBSztXQUM1RCxXQUFVO1VBQ1g7Ozs7O1NBQ0M7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1osd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLEVBQUU7V0FDVCxXQUFXLE1BQU0sYUFBYSxFQUFFLElBQUksYUFBYSxFQUFFLE9BQU8sS0FBSztXQUMvRCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztTQUNDOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNaLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxFQUFFO1dBQ1QsV0FBVyxNQUFNLGFBQWEsRUFBRSxJQUFJLFFBQVEsRUFBRSxPQUFPLEtBQUs7V0FDMUQsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7U0FDQzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sRUFBRTtXQUNULFdBQVcsTUFBTSxhQUFhLEVBQUUsSUFBSSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7V0FDbEUsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7U0FDQzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sRUFBRTtXQUNULFdBQVcsTUFBTSxhQUFhLEVBQUUsSUFBSSxjQUFjLEVBQUUsT0FBTyxLQUFLO1dBQ2hFLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7O1NBQ0M7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1osd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLEVBQUU7V0FDVCxXQUFXLE1BQU0sYUFBYSxFQUFFLElBQUksa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1dBQ3BFLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7O1NBQ0M7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1osd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLEVBQUU7V0FDVCxXQUFXLE1BQU0sYUFBYSxFQUFFLElBQUksWUFBWSxFQUFFLE9BQU8sS0FBSztXQUM5RCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztTQUNDOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNaLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxFQUFFO1dBQ1QsV0FBVyxNQUFNLGFBQWEsRUFBRSxJQUFJLGFBQWEsRUFBRSxPQUFPLEtBQUs7V0FDL0QsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7U0FDQzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFVBQUQ7WUFDRSxNQUFLO1lBQ0wsZUFBZTthQUNiLGNBQWMsUUFBUTthQUN0QixxQkFBcUI7Y0FDbkIsSUFBSSxFQUFFO2NBQ04sUUFBUSxVQUFVLEVBQUUsT0FBTyxJQUFJLEVBQUUsYUFBYSxVQUFVO2NBQ3hELFFBQVEsRUFBRSxhQUFhO2NBQ3ZCLE9BQU8sQ0FBQyxDQUFDO2NBQ1QsU0FBUztlQUFFLEtBQUssRUFBRSxjQUFjO2VBQUksT0FBTztlQUFJLE1BQU07Y0FBRzthQUMxRCxDQUFDO2FBQ0Qsc0JBQXNCLElBQUk7WUFDNUI7WUFDQSxXQUFVO1lBQ1YsT0FBTTtzQkFFTix3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7OztXQUM3Qjs7OztxQkFDUix3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLGVBQWUsYUFBYSxFQUFFLEVBQUU7WUFDaEMsV0FBVTtZQUNWLE9BQU07c0JBRU4sd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7Ozs7V0FDM0I7Ozs7bUJBQ0w7Ozs7OztTQUNIOzs7OztRQUNGO1VBdEdLLEVBQUU7Ozs7Y0FzR1AsQ0FDTDtNQUNJOzs7O2NBQ0Y7Ozs7OztJQUNKOzs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUseUJBQTBCOzs7O2VBQUMsZ0RBQzdDOzs7OztjQUVKLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRztNQUNDO09BQUUsS0FBSztPQUFpQixPQUFPO09BQTRCLFNBQVM7UUFBQztRQUFTO1FBQWE7T0FBNkI7TUFBRTtNQUMxSDtPQUFFLEtBQUs7T0FBZSxPQUFPO09BQStCLFNBQVM7UUFBQztRQUFXO1FBQXVCO09BQWM7TUFBRTtNQUN4SDtPQUFFLEtBQUs7T0FBbUIsT0FBTztPQUE4QixTQUFTLENBQUMsWUFBWSxVQUFVO01BQUU7TUFDakc7T0FBRSxLQUFLO09BQWUsT0FBTztPQUE0QixTQUFTO1FBQUM7UUFBYTtRQUFzQjtPQUFhO01BQUU7TUFDckg7T0FBRSxLQUFLO09BQWdCLE9BQU87T0FBbUMsU0FBUztRQUFDO1FBQXdCO1FBQVk7T0FBYztNQUFFO0tBQ2pJLENBQUMsQ0FBQyxLQUFLLFNBQVM7TUFDZCxNQUFNLFVBQVUsaUJBQWlCLEtBQUssUUFBUSxDQUFDO01BQy9DLE9BQ0Usd0JBQUMsT0FBRDtPQUFvQixXQUFVO2lCQUE5QjtRQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUE4RCxLQUFLO1FBQVk7Ozs7O1FBQy9GLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLEtBQUssUUFBUSxLQUFLLFFBQVE7VUFDekIsTUFBTSxhQUFhLFFBQVEsV0FBVztVQUN0QyxPQUNFLHdCQUFDLFVBQUQ7V0FFRSxNQUFLO1dBQ0wsZUFBZSx1QkFBdUIsS0FBSyxLQUFLLFVBQVUsR0FBRztXQUM3RCxXQUFXLHFGQUNULGFBQ0ksMEhBQ0E7cUJBUFI7WUFTQztZQUNJLGFBQWEsTUFBTTtZQUFJO1lBQUk7V0FDeEI7YUFWRDs7OztpQkFVQztTQUVaLENBQUM7UUFDRTs7Ozs7UUFDTCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU8sUUFBUSxpQkFBaUI7U0FDaEMsV0FBVyxNQUFNLHVCQUF1QixLQUFLLEtBQUssaUJBQWlCLEVBQUUsT0FBTyxLQUFLO1NBQ2pGLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7O09BQ0U7U0E1QkssS0FBSzs7OzthQTRCVjtLQUVULENBQUMsR0FHRCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHlCQUEwQjs7OztpQkFBQyx5QkFDOUM7Ozs7O2dCQUNOLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQThDO1FBQWE7Ozs7O1FBQzNFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTyxpQkFBaUIscUJBQXFCO1NBQzdDLFdBQVcsTUFBTSxZQUFZLG9CQUFvQjtVQUFFLEdBQUc7VUFBa0IsbUJBQW1CLEVBQUUsT0FBTztTQUFNLENBQUM7U0FDM0csYUFBWTtTQUNaLFdBQVU7UUFDWDs7Ozs7UUFDRCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBbUQ7UUFBeUI7Ozs7O1FBQzNGLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxLQUFLLFFBQVE7U0FDekIsTUFBTSxhQUFhLGlCQUFpQixzQkFBc0I7U0FDMUQsT0FDRSx3QkFBQyxVQUFEO1VBRUUsTUFBSztVQUNMLGVBQWUsWUFBWSxvQkFBb0I7V0FBRSxHQUFHO1dBQWtCLG1CQUFtQjtVQUFJLENBQUM7VUFDOUYsV0FBVyxtRkFDVCxhQUNJLDBIQUNBO29CQVBSO1dBU0M7V0FDSSxhQUFhLE1BQU07V0FBSTtXQUFJO1VBQ3hCO1lBVkQ7Ozs7Z0JBVUM7UUFFWixDQUFDO09BQ0U7Ozs7O2NBQ0Y7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUseUJBQTBCOzs7O2VBQUMsb0RBQ2hEOzs7OztjQUVKLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1o7TUFDQztPQUFFLEtBQUs7T0FBWSxPQUFPO09BQWlDLFNBQVMsQ0FBQyxzQkFBc0Isb0JBQW9CO01BQUU7TUFDakg7T0FBRSxLQUFLO09BQWtCLE9BQU87T0FBK0IsU0FBUztRQUFDO1FBQWU7UUFBa0I7T0FBVztNQUFFO01BQ3ZIO09BQUUsS0FBSztPQUFxQixPQUFPO09BQWlDLFNBQVMsQ0FBQyx5QkFBeUIsdUJBQXVCO01BQUU7TUFDaEk7T0FBRSxLQUFLO09BQTBCLE9BQU87T0FBMkIsU0FBUyxDQUFDLHdCQUF3QiwwQkFBMEI7TUFBRTtLQUNuSSxDQUFDLENBQUMsS0FBSyxTQUFTO01BQ2QsTUFBTSxVQUFVLHFCQUFxQixLQUFLLFFBQVEsQ0FBQztNQUNuRCxPQUNFLHdCQUFDLE9BQUQ7T0FBb0IsV0FBVTtpQkFBOUI7UUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBOEQsS0FBSztRQUFZOzs7OztRQUMvRix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixLQUFLLFFBQVEsS0FBSyxRQUFRO1VBQ3pCLE1BQU0sYUFBYSxRQUFRLFdBQVc7VUFDdEMsT0FDRSx3QkFBQyxVQUFEO1dBRUUsTUFBSztXQUNMLGVBQWUsZ0JBQWdCLEtBQUssS0FBSyxVQUFVLEdBQUc7V0FDdEQsV0FBVyxxRkFDVCxhQUNJLDBIQUNBO3FCQVBSO1lBU0M7WUFDSSxhQUFhLE1BQU07WUFBSTtZQUFJO1dBQ3hCO2FBVkQ7Ozs7aUJBVUM7U0FFWixDQUFDO1FBQ0U7Ozs7O1FBQ0wsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPLFFBQVEsV0FBVztTQUMxQixXQUFXLE1BQU0sZ0JBQWdCLEtBQUssS0FBSyxXQUFXLEVBQUUsT0FBTyxLQUFLO1NBQ3BFLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7O09BQ0U7U0E1QkssS0FBSzs7OzthQTRCVjtLQUVULENBQUM7SUFDRTs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUseUJBQTBCOzs7O2dCQUFDLHdDQUNoRDs7Ozs7ZUFDSix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFNBQVM7TUFDVCxXQUFVO2dCQUhaLENBS0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OztnQkFBQyxtQkFDMUI7Ozs7O2FBQ0w7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixpQkFBaUIsS0FBSyxNQUNyQix3QkFBQyxPQUFEO01BQWdCLFdBQVU7Z0JBQTFCO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsRUFBRTtPQUNDOzs7OztPQUNOLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTyxFQUFFO1FBQ1QsV0FBVyxNQUFNLGVBQWUsRUFBRSxJQUFJLEVBQUUsT0FBTyxLQUFLO1FBQ3BELGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7O09BQ0Qsd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLGVBQWUsRUFBRSxFQUFFO1FBQ2xDLFdBQVU7UUFDVixPQUFNO2tCQUVOLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7O09BQzNCOzs7OztNQUNMO1FBbkJLLEVBQUU7Ozs7WUFtQlAsQ0FDTjtJQUNFOzs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUF3STtJQUVsSjs7OztjQUVKLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFvRjtPQUF3Qzs7Ozs7T0FDNUksd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1FBQzdELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7O09BQ0Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2Isa0JBQWtCO09BQ2Y7Ozs7O09BQ04sd0JBQUMsT0FBRCxFQUFLLFdBQVUsNERBQWlFOzs7OztNQUM3RTs7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFvRjtPQUEwQzs7Ozs7T0FDOUksd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLFlBQVksbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1FBQzlELFdBQVU7UUFDVixhQUFZO09BQ2I7Ozs7O09BQ0Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsbUJBQW1CO09BQ2hCOzs7OztPQUNOLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDREQUFpRTs7Ozs7TUFDN0U7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUVMLHdCQUFDLHNCQUFEO0lBQ0UsUUFBUTtJQUNSLGVBQWUsc0JBQXNCLEtBQUs7SUFDMUMsYUFBYTtJQUNiLE1BQU07SUFDTixZQUFXO0lBQ1gsa0JBQWtCLENBQUM7SUFDbkIsU0FBUyxXQUFXLFlBQVk7S0FDOUIsSUFBSSxRQUFRLGdCQUFnQiwyQkFBMkIsUUFBUSxZQUFZO01BQ3pFLE1BQU0saUJBQWlCLFFBQVEscUJBQXFCLFFBQVE7TUFDNUQsSUFBSSxPQUFPO01BQ1gsSUFBSSxnQkFBZ0I7T0FDbEIsUUFBUSxhQUFhLENBQUMsRUFBQyxDQUFFLFNBQVEsTUFBSyxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFRLE1BQUssRUFBRSx1QkFBdUIsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBSyxNQUFLLEVBQUUsT0FBTyxjQUFjO01BQ3BKO01BQ0EsSUFBSSxDQUFDLE1BQU07T0FDVCxPQUFPLHlCQUF5QixRQUFRLFlBQVk7UUFDbEQsUUFBUSxRQUFRLFVBQVUsUUFBUSxXQUFXLGtDQUFrQyxRQUFRLFNBQVMsMEJBQTBCLFVBQVU7UUFDcEksY0FBYztRQUNkLGdCQUFnQjtPQUNsQixDQUFDO01BQ0g7TUFDQSxJQUFJLE1BQU07T0FDUixRQUFRLGNBQWMsS0FBSztPQUMzQixRQUFRLG9CQUFvQixLQUFLO09BQ2pDLFFBQVEsc0JBQXNCO09BQzlCLFFBQVEsU0FBUyxHQUFHLEtBQUssT0FBTyxRQUFRLEtBQUssR0FBRztPQUNoRCxRQUFRLGNBQWM7TUFDeEI7S0FDRjtLQUNBLElBQUksUUFBUSxRQUFRLGFBQWEsV0FBVyxhQUFhLFFBQVEsTUFBTTtLQUN2RSxJQUFJLFFBQVEsa0JBQWtCLGlCQUFpQixhQUFhLFdBQVcsZ0JBQWdCLFFBQVEsaUJBQWlCLGVBQWU7S0FDL0gsSUFBSSxRQUFRLGtCQUFrQixNQUFNLGFBQWEsV0FBVyxRQUFRLFFBQVEsaUJBQWlCLElBQUk7S0FDakcsSUFBSSxRQUFRLGtCQUFrQixjQUFjLFFBQVEsU0FBUyxLQUFLLGFBQWEsV0FBVyxjQUFjLFFBQVEsa0JBQWtCLGNBQWMsUUFBUSxTQUFTLEdBQUc7S0FDcEssSUFBSSxRQUFRLGtCQUFrQixVQUFVLGFBQWEsV0FBVyxZQUFZLFFBQVEsaUJBQWlCLFFBQVE7SUFDL0c7R0FDRDs7Ozs7RUFFRTs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2NtQ29tcG9uZW50LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgQ3B1LCBcbiAgQnVpbGRpbmcyLCBcbiAgWmFwLCBcbiAgQWN0aXZpdHksIFxuICBTaGllbGRDaGVjaywgXG4gIEFsZXJ0Q2lyY2xlLCBcbiAgUHJpbnRlciwgXG4gIFVzZXIsIFxuICBDYWxlbmRhciwgXG4gIENsb2NrLCBcbiAgUGx1cywgXG4gIFRyYXNoMiwgXG4gIExheWVycywgXG4gIFRoZXJtb21ldGVyLCBcbiAgQ2hlY2tTcXVhcmUsIFxuICBGaWxlVGV4dCxcbiAgU2V0dGluZ3Ncbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBNb2RhbEVkaWNpb25DaXJjdWl0byBmcm9tICcuL01vZGFsRWRpY2lvbkNpcmN1aXRvJztcbmltcG9ydCB1c2VTdG9yZSBmcm9tICcuLi9zdG9yZS91c2VTdG9yZSc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENjbUNvbXBvbmVudCh7IGNjbURhdGEsIG9uVXBkYXRlLCByZWFkT25seSB9KSB7XG4gIGNvbnN0IHsgY29tcGFuaWVzLCBjcmVhckVsZW1lbnRvUHJvdmlzaW9uYWwgfSA9IHVzZVN0b3JlKCk7XG4gIGNvbnN0IFttb2RhbEplcmFycXVpYU9wZW4sIHNldE1vZGFsSmVyYXJxdWlhT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtjaXJjdWl0RGF0YVdpemFyZCwgc2V0Q2lyY3VpdERhdGFXaXphcmRdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFt3aXphcmRNb2RvLCBzZXRXaXphcmRNb2RvXSA9IHVzZVN0YXRlKCdTQUxJREEnKTtcbiAgaWYgKCFjY21EYXRhKSB7XG4gICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC04IHRleHQtc2xhdGUtNDAwXCI+Tm8gaGF5IGRhdG9zIGRlIENDTSBzZWxlY2Npb25hZG9zLjwvZGl2PjtcbiAgfVxuXG4gIGNvbnN0IHtcbiAgICBpZCxcbiAgICBub21icmUgPSAnJyxcbiAgICBwbGFudGFJbnN0YWxhY2lvbiA9ICcnLFxuICAgIGFyZWFQcm9jZXNvID0gJycsXG4gICAgZmFicmljYW50ZU1hcmNhID0gJycsXG4gICAgbW9kZWxvU2VyaWUgPSAnJyxcbiAgICBncmFkb05lbWFJcCA9ICcnLFxuICAgIGZlY2hhID0gJycsXG4gICAgaW5zcGVjdG9yID0gJycsXG4gICAgc3VwZXJ2aXNvciA9ICcnLFxuICAgIGFub0ZhYnJpY2FjaW9uSW5zdGFsYWNpb24gPSAnJyxcblxuICAgIC8vIFNlY2Npb25lcyBlc3RydWN0dXJhZGFzXG4gICAgcGFyYW1ldHJvc0VsZWN0cmljb3MgPSB7fSxcbiAgICBnYXZldGFzQnVja2V0TG9nID0gW10sXG4gICAgaW5zcGVjY2lvbkZpc2ljYSA9IHt9LFxuICAgIHNlZ3VyaWRhZFRlcm1vZ3JhZmlhID0ge30sXG4gICAgaGFsbGF6Z29zQ3JpdGljb3MgPSBbXSxcblxuICAgIGZpcm1hSW5zcGVjdG9yID0gJycsXG4gICAgZmlybWFTdXBlcnZpc29yID0gJydcbiAgfSA9IGNjbURhdGE7XG5cbiAgY29uc3QgdXBkYXRlRmllbGQgPSAoZmllbGQsIHZhbHVlKSA9PiB7XG4gICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgb25VcGRhdGUoe1xuICAgICAgLi4uY2NtRGF0YSxcbiAgICAgIFtmaWVsZF06IHZhbHVlXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgdXBkYXRlUGFyYW1ldHJvID0gKGtleSwgZmllbGQsIHZhbHVlKSA9PiB7XG4gICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgY29uc3QgY3VycmVudFBhcmFtcyA9IGNjbURhdGEucGFyYW1ldHJvc0VsZWN0cmljb3MgfHwge307XG4gICAgY29uc3QgcGFyYW1PYmogPSBjdXJyZW50UGFyYW1zW2tleV0gfHwge307XG4gICAgb25VcGRhdGUoe1xuICAgICAgLi4uY2NtRGF0YSxcbiAgICAgIHBhcmFtZXRyb3NFbGVjdHJpY29zOiB7XG4gICAgICAgIC4uLmN1cnJlbnRQYXJhbXMsXG4gICAgICAgIFtrZXldOiB7XG4gICAgICAgICAgLi4ucGFyYW1PYmosXG4gICAgICAgICAgW2ZpZWxkXTogdmFsdWVcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IHVwZGF0ZUluc3BlY2Npb25GaXNpY2EgPSAoa2V5LCBmaWVsZCwgdmFsdWUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBjdXJyZW50RmlzaWNhID0gY2NtRGF0YS5pbnNwZWNjaW9uRmlzaWNhIHx8IHt9O1xuICAgIGNvbnN0IGl0ZW1PYmogPSBjdXJyZW50RmlzaWNhW2tleV0gfHwge307XG4gICAgb25VcGRhdGUoe1xuICAgICAgLi4uY2NtRGF0YSxcbiAgICAgIGluc3BlY2Npb25GaXNpY2E6IHtcbiAgICAgICAgLi4uY3VycmVudEZpc2ljYSxcbiAgICAgICAgW2tleV06IHtcbiAgICAgICAgICAuLi5pdGVtT2JqLFxuICAgICAgICAgIFtmaWVsZF06IHZhbHVlXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCB1cGRhdGVTZWd1cmlkYWQgPSAoa2V5LCBmaWVsZCwgdmFsdWUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBjdXJyZW50U2VnID0gY2NtRGF0YS5zZWd1cmlkYWRUZXJtb2dyYWZpYSB8fCB7fTtcbiAgICBjb25zdCBpdGVtT2JqID0gY3VycmVudFNlZ1trZXldIHx8IHt9O1xuICAgIG9uVXBkYXRlKHtcbiAgICAgIC4uLmNjbURhdGEsXG4gICAgICBzZWd1cmlkYWRUZXJtb2dyYWZpYToge1xuICAgICAgICAuLi5jdXJyZW50U2VnLFxuICAgICAgICBba2V5XToge1xuICAgICAgICAgIC4uLml0ZW1PYmosXG4gICAgICAgICAgW2ZpZWxkXTogdmFsdWVcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICB9O1xuXG4gIC8vIEzDs2dpY2EgcGFyYSBHYXZldGFzIChCdWNrZXQgTG9nKVxuICBjb25zdCBhZGRHYXZldGEgPSAoKSA9PiB7XG4gICAgaWYgKHJlYWRPbmx5KSByZXR1cm47XG4gICAgY29uc3QgY3VycmVudEdhdmV0YXMgPSBjY21EYXRhLmdhdmV0YXNCdWNrZXRMb2cgfHwgW107XG4gICAgY29uc3QgbmV3R2F2ZXRhID0ge1xuICAgICAgaWQ6ICdnLScgKyBEYXRlLm5vdygpICsgJy0nICsgTWF0aC5yb3VuZChNYXRoLnJhbmRvbSgpICogMTAwMCksXG4gICAgICBnYXZldGE6IGBHLTAke2N1cnJlbnRHYXZldGFzLmxlbmd0aCArIDF9YCxcbiAgICAgIHRhZ0VxdWlwbzogJycsXG4gICAgICBocEt3OiAnJyxcbiAgICAgIHRpcG9BcnJhbnF1ZTogJ0RpcmVjdG8gKERPTCknLFxuICAgICAgcHJvdGVjY2lvbjogJycsXG4gICAgICBtYXJjYU1vZGVsb1ZmZDogJycsXG4gICAgICByZWRDb21tczogJycsXG4gICAgICBlc3RhZG9PYnM6ICdPcGVyYXRpdm8nXG4gICAgfTtcbiAgICBvblVwZGF0ZSh7XG4gICAgICAuLi5jY21EYXRhLFxuICAgICAgZ2F2ZXRhc0J1Y2tldExvZzogWy4uLmN1cnJlbnRHYXZldGFzLCBuZXdHYXZldGFdXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgdXBkYXRlR2F2ZXRhID0gKGdhdmV0YUlkLCBmaWVsZCwgdmFsdWUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBjdXJyZW50R2F2ZXRhcyA9IGNjbURhdGEuZ2F2ZXRhc0J1Y2tldExvZyB8fCBbXTtcbiAgICBjb25zdCB1cGRhdGVkR2F2ZXRhcyA9IGN1cnJlbnRHYXZldGFzLm1hcCgoZykgPT4ge1xuICAgICAgaWYgKGcuaWQgPT09IGdhdmV0YUlkKSB7XG4gICAgICAgIHJldHVybiB7IC4uLmcsIFtmaWVsZF06IHZhbHVlIH07XG4gICAgICB9XG4gICAgICByZXR1cm4gZztcbiAgICB9KTtcbiAgICBvblVwZGF0ZSh7XG4gICAgICAuLi5jY21EYXRhLFxuICAgICAgZ2F2ZXRhc0J1Y2tldExvZzogdXBkYXRlZEdhdmV0YXNcbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCBkZWxldGVHYXZldGEgPSAoZ2F2ZXRhSWQpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBjdXJyZW50R2F2ZXRhcyA9IGNjbURhdGEuZ2F2ZXRhc0J1Y2tldExvZyB8fCBbXTtcbiAgICBvblVwZGF0ZSh7XG4gICAgICAuLi5jY21EYXRhLFxuICAgICAgZ2F2ZXRhc0J1Y2tldExvZzogY3VycmVudEdhdmV0YXMuZmlsdGVyKChnKSA9PiBnLmlkICE9PSBnYXZldGFJZClcbiAgICB9KTtcbiAgfTtcblxuICAvLyBMw7NnaWNhIHBhcmEgSGFsbGF6Z29zIENyw610aWNvc1xuICBjb25zdCBhZGRIYWxsYXpnbyA9ICgpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBjdXJyZW50SGFsbGF6Z29zID0gY2NtRGF0YS5oYWxsYXpnb3NDcml0aWNvcyB8fCBbXTtcbiAgICBjb25zdCBuZXdIYWxsYXpnbyA9IHtcbiAgICAgIGlkOiAnaC0nICsgRGF0ZS5ub3coKSxcbiAgICAgIGl0ZW1OdW06IFN0cmluZyhjdXJyZW50SGFsbGF6Z29zLmxlbmd0aCArIDEpLnBhZFN0YXJ0KDIsICcwJyksXG4gICAgICBkZXNjcmlwY2lvbjogJydcbiAgICB9O1xuICAgIG9uVXBkYXRlKHtcbiAgICAgIC4uLmNjbURhdGEsXG4gICAgICBoYWxsYXpnb3NDcml0aWNvczogWy4uLmN1cnJlbnRIYWxsYXpnb3MsIG5ld0hhbGxhemdvXVxuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IHVwZGF0ZUhhbGxhemdvID0gKGhJZCwgdmFsdWUpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBjdXJyZW50SGFsbGF6Z29zID0gY2NtRGF0YS5oYWxsYXpnb3NDcml0aWNvcyB8fCBbXTtcbiAgICBvblVwZGF0ZSh7XG4gICAgICAuLi5jY21EYXRhLFxuICAgICAgaGFsbGF6Z29zQ3JpdGljb3M6IGN1cnJlbnRIYWxsYXpnb3MubWFwKChoKSA9PiBoLmlkID09PSBoSWQgPyB7IC4uLmgsIGRlc2NyaXBjaW9uOiB2YWx1ZSB9IDogaClcbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCBkZWxldGVIYWxsYXpnbyA9IChoSWQpID0+IHtcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcbiAgICBjb25zdCBjdXJyZW50SGFsbGF6Z29zID0gY2NtRGF0YS5oYWxsYXpnb3NDcml0aWNvcyB8fCBbXTtcbiAgICBvblVwZGF0ZSh7XG4gICAgICAuLi5jY21EYXRhLFxuICAgICAgaGFsbGF6Z29zQ3JpdGljb3M6IGN1cnJlbnRIYWxsYXpnb3MuZmlsdGVyKChoKSA9PiBoLmlkICE9PSBoSWQpXG4gICAgfSk7XG4gIH07XG5cbiAgLy8gVmFsb3JlcyBwcmVkZXRlcm1pbmFkb3MgZGUgZ2F2ZXRhcyBzaSBlc3TDoSB2YWPDrW9cbiAgY29uc3QgZGVmYXVsdEdhdmV0YXMgPSAoY2NtRGF0YS5nYXZldGFzQnVja2V0TG9nICYmIGNjbURhdGEuZ2F2ZXRhc0J1Y2tldExvZy5sZW5ndGggPiAwKSBcbiAgICA/IGNjbURhdGEuZ2F2ZXRhc0J1Y2tldExvZyBcbiAgICA6IFtcbiAgICAgICAgeyBpZDogJ2ctMScsIGdhdmV0YTogJ0ctMDEnLCB0YWdFcXVpcG86ICdCb21iYSBBZ3VhIFBvdGFibGUgMScsIGhwS3c6ICcyNSBIUCcsIHRpcG9BcnJhbnF1ZTogJ0RpcmVjdG8gKERPTCknLCBwcm90ZWNjaW9uOiAnR3VhcmRhbW90b3IgMzJBJywgbWFyY2FNb2RlbG9WZmQ6ICdOL0EgKENvbnRhY3RvciknLCByZWRDb21tczogJ01vZGJ1cyBSVFUnLCBlc3RhZG9PYnM6ICdPcGVyYXRpdm8nIH0sXG4gICAgICAgIHsgaWQ6ICdnLTInLCBnYXZldGE6ICdHLTAyJywgdGFnRXF1aXBvOiAnVmVudGlsYWRvciBUaXJvIEZvcnphZG8nLCBocEt3OiAnNTAgSFAnLCB0aXBvQXJyYW5xdWU6ICdWRkQnLCBwcm90ZWNjaW9uOiAnQnJlYWtlciBDNjNBJywgbWFyY2FNb2RlbG9WZmQ6ICdQb3dlckZsZXggNTI1JywgcmVkQ29tbXM6ICdFdGhlck5ldC9JUCcsIGVzdGFkb09iczogJ09wZXJhdGl2bycgfSxcbiAgICAgICAgeyBpZDogJ2ctMycsIGdhdmV0YTogJ0ctMDMnLCB0YWdFcXVpcG86ICdBZ2l0YWRvciBUYW5xdWUgQScsIGhwS3c6ICcxNSBIUCcsIHRpcG9BcnJhbnF1ZTogJ0VzdHJlbGxhLVRyacOhbmcuJywgcHJvdGVjY2lvbjogJ0NvbnRhY3RvciArIFTDqXJtaWNvJywgbWFyY2FNb2RlbG9WZmQ6ICdOL0EnLCByZWRDb21tczogJ0Rpc2NyZXRhJywgZXN0YWRvT2JzOiAnTWFudGVuaW0uJyB9LFxuICAgICAgICB7IGlkOiAnZy00JywgZ2F2ZXRhOiAnRy0wNCcsIHRhZ0VxdWlwbzogJ1JFU0VSVkEgRElTUE9OSUJMRScsIGhwS3c6ICctJywgdGlwb0FycmFucXVlOiAnLScsIHByb3RlY2Npb246ICctJywgbWFyY2FNb2RlbG9WZmQ6ICctJywgcmVkQ29tbXM6ICctJywgZXN0YWRvT2JzOiAnRGlzcG9uaWJsZScgfVxuICAgICAgXTtcblxuICBjb25zdCBkZWZhdWx0SGFsbGF6Z29zID0gKGNjbURhdGEuaGFsbGF6Z29zQ3JpdGljb3MgJiYgY2NtRGF0YS5oYWxsYXpnb3NDcml0aWNvcy5sZW5ndGggPiAwKVxuICAgID8gY2NtRGF0YS5oYWxsYXpnb3NDcml0aWNvc1xuICAgIDogW1xuICAgICAgICB7IGlkOiAnaC0xJywgaXRlbU51bTogJzAxJywgZGVzY3JpcGNpb246ICdTdXN0aXR1Y2nDs24gcmVjb21lbmRhZGEgZGUgZmlsdHJvcyBkZSBwb2x2byBvYnN0cnVpZG9zIGVuIGdhYmluZXRlIHN1cGVyaW9yLicgfSxcbiAgICAgICAgeyBpZDogJ2gtMicsIGl0ZW1OdW06ICcwMicsIGRlc2NyaXBjaW9uOiAnU2Ugc3VnaWVyZSBhY3R1YWxpemFjacOzbiBkZWwgZGlhZ3JhbWEgdW5pZmlsYXIgZW4gcHVlcnRhIGRlIGFjY2Vzby4nIH1cbiAgICAgIF07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YHctZnVsbCB0ZXh0LXNsYXRlLTEwMCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IG1kOnAtOCBzaGFkb3cteGwgYmFja2Ryb3AtYmx1ci1tZCBzZWxlY3QtdGV4dCBtYXgtdy01eGwgbXgtYXV0byBzcGFjZS15LTggcHJpbnQtY2FyZCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItbm9uZSBwcmludDpzaGFkb3ctbm9uZSBwcmludDpwLTAgcHJpbnQ6bS0wICR7cmVhZE9ubHkgPyAncG9pbnRlci1ldmVudHMtbm9uZSBvcGFjaXR5LTkwJyA6ICcnfWB9PlxuICAgICAgXG4gICAgICB7LyogRW5jYWJlemFkbyBHZW5lcmFsICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBtZDppdGVtcy1jZW50ZXIgZ2FwLTQgcGItNiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNTAwIGZvbnQtZXh0cmFib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgcHJpbnQ6dGV4dC1hbWJlci03MDBcIj5cbiAgICAgICAgICAgIEZvcm1hdG8gZGUgTGV2YW50YW1pZW50byBkZSBJbmZvcm1hY2nDs24gVMOpY25pY2FcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgbWQ6dGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS0xMDAgdHJhY2tpbmctd2lkZSBtdC0xIHByaW50OnRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICBDZW50cm8gZGUgQ29udHJvbCBkZSBNb3RvcmVzIChDQ00pIEluZHVzdHJpYWxcbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIHtub21icmUgJiYgKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNDAwIG10LTEgcHJpbnQ6dGV4dC1zbGF0ZS02MDBcIj5cbiAgICAgICAgICAgICAgVGFnIC8gSWRlbnRpZmljYWNpw7NuOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTQwMCBmb250LWJvbGQgcHJpbnQ6dGV4dC1zbGF0ZS05MDBcIj57bm9tYnJlfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5wcmludCgpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibm8tcHJpbnQgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIHB4LTQgcHktMiByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kXCJcbiAgICAgICAgICAgIHRpdGxlPVwiR3VhcmRhciBjb21vIFBERiBvIEltcHJpbWlyIGVzdGEgSW5zcGVjY2nDs24gZGUgQ0NNXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gR3VhcmRhciBQREZcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1tb25vIGZvbnQtYmxhY2sgdGV4dC1hbWJlci00MDAgYmctYW1iZXItNTAwLzEwIHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgdGV4dC14cyBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgIElEOiB7aWR9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogMS4gREFUT1MgR0VORVJBTEVTIEUgSURFTlRJRklDQUNJw5NOICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgcm91bmRlZC0yeGwgcC01IHNwYWNlLXktNCBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWFtYmVyLTUwMCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTIuNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPiAxLiBEYXRvcyBHZW5lcmFsZXMgZSBJZGVudGlmaWNhY2nDs25cbiAgICAgICAgPC9oMz5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTFcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDAgdXBwZXJjYXNlXCI+UGxhbnRhIC8gSW5zdGFsYWNpw7NuPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtwbGFudGFJbnN0YWxhY2lvbn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgncGxhbnRhSW5zdGFsYWNpb24nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gUGxhbnRhIFByb2Nlc2Fkb3JhIENlbnRyYWxcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMVwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LXNsYXRlLTcwMCB1cHBlcmNhc2VcIj7DgXJlYSAvIFByb2Nlc288L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2FyZWFQcm9jZXNvfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUZpZWxkKCdhcmVhUHJvY2VzbycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBDdWFydG8gRWzDqWN0cmljbyAwMiAtIEJvbWJlb1wiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwIHVwcGVyY2FzZVwiPlRhZyAvIElkZW50aWZpY2FjacOzbiBDQ008L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e25vbWJyZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnbm9tYnJlJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGZvbnQtYm9sZCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBDQ00tSU5ELTAxXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTFcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgcHJpbnQ6dGV4dC1zbGF0ZS03MDAgdXBwZXJjYXNlXCI+RmFicmljYW50ZSAvIE1hcmNhPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmYWJyaWNhbnRlTWFyY2F9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ2ZhYnJpY2FudGVNYXJjYScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBBbGxlbi1CcmFkbGV5IC8gU2llbWVucyAvIFNjaG5laWRlclwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwIHVwcGVyY2FzZVwiPk1vZGVsbyAvIFNlcmllPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXttb2RlbG9TZXJpZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnbW9kZWxvU2VyaWUnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgZm9udC1tb25vIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWouIENlbnRlcmxpbmUgMjEwMCAvIFNOLTk0ODEwMlwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwIHVwcGVyY2FzZVwiPkdyYWRvIE5FTUEgLyBJUDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17Z3JhZG9OZW1hSXB9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ2dyYWRvTmVtYUlwJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIGZvbnQtbW9ubyBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqLiBORU1BIDEyIC8gSVA1NFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwIHVwcGVyY2FzZVwiPkZlY2hhIGRlbCBMZXZhbnRhbWllbnRvPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmZWNoYX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnZmVjaGEnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgZm9udC1tb25vIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHByaW50OnRleHQtc2xhdGUtNzAwIHVwcGVyY2FzZVwiPkxldmFudGFkbyBwb3IgKEluc3BlY3Rvcik8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2luc3BlY3Rvcn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnaW5zcGVjdG9yJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tYnJlIGRlbCBJbnNwZWN0b3JcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMVwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LXNsYXRlLTcwMCB1cHBlcmNhc2VcIj5Bw7FvIEZhYnJpY2FjacOzbiAvIEluc3RhbGFjacOzbjwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17YW5vRmFicmljYWNpb25JbnN0YWxhY2lvbn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnYW5vRmFicmljYWNpb25JbnN0YWxhY2lvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgaC0xMCB0cmFuc2l0aW9uLWFsbCBmb250LW1vbm8gcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gMjAxOCAvIDIwMTlcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIDIuIFBBUsOBTUVUUk9TIEVMw4lDVFJJQ09TIEdFTkVSQUxFUyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHJvdW5kZWQtMnhsIHAtNSBzcGFjZS15LTQgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci01MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0yLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz4gMi4gUGFyw6FtZXRyb3MgRWzDqWN0cmljb3MgR2VuZXJhbGVzXG4gICAgICAgIDwvaDM+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzIGJvcmRlci1jb2xsYXBzZVwiPlxuICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIHRleHQtWzEwcHhdIGZvbnQtZXh0cmFib2xkIHVwcGVyY2FzZSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHByaW50OmJnLXNsYXRlLTEwMCBwcmludDp0ZXh0LXNsYXRlLTcwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5QYXLDoW1ldHJvIEVsw6ljdHJpY288L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPlZhbG9yIE5vbWluYWw8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPlZhbG9yIE1lZGlkbyAvIEFqdXN0ZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+Tm90YXMgLyBPYnNlcnZhY2lvbmVzPC90aD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTgwMC82MCBwcmludDpkaXZpZGUtZ3JheS0yMDBcIj5cbiAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICB7IGtleTogJ3RlbnNpb25QcmluY2lwYWwnLCBsYWJlbDogJ1RlbnNpw7NuIFByaW5jaXBhbCBOb21pbmFsIChWKScsIGRlZk5vbWluYWw6ICc0ODBWIC8gMzgwVicgfSxcbiAgICAgICAgICAgICAgICB7IGtleTogJ2ZyZWN1ZW5jaWEnLCBsYWJlbDogJ0ZyZWN1ZW5jaWEgKEh6KScsIGRlZk5vbWluYWw6ICc2MCBIeiAvIDUwIEh6JyB9LFxuICAgICAgICAgICAgICAgIHsga2V5OiAnc2lzdGVtYUZhc2VzJywgbGFiZWw6ICdTaXN0ZW1hIGRlIEZhc2VzIGUgSGlsb3MnLCBkZWZOb21pbmFsOiAnM8OYM1cgLyAzw5g0VycgfSxcbiAgICAgICAgICAgICAgICB7IGtleTogJ2J1c1ByaW5jaXBhbCcsIGxhYmVsOiAnQ2FwYWNpZGFkIGRlIEJ1cyBQcmluY2lwYWwgKEEpJywgZGVmTm9taW5hbDogJzIwMDAgQScgfSxcbiAgICAgICAgICAgICAgICB7IGtleTogJ3NjY3JDb3J0bycsIGxhYmVsOiAnTml2ZWwgZGUgQ29ydG9jaXJjdWl0byAvIFNDQ1IgKGtBKScsIGRlZk5vbWluYWw6ICc2NSBrQScgfSxcbiAgICAgICAgICAgICAgICB7IGtleTogJ3RlbnNpb25Db250cm9sJywgbGFiZWw6ICdUZW5zacOzbiBkZSBDb250cm9sIC8gQXV4aWxpYXInLCBkZWZOb21pbmFsOiAnMTEwViBBQyAvIDI0ViBEQycgfSxcbiAgICAgICAgICAgICAgICB7IGtleTogJ2ludGVycnVwdG9yTWFpbicsIGxhYmVsOiAnSW50ZXJydXB0b3IgUHJpbmNpcGFsIChNYWluKScsIGRlZk5vbWluYWw6ICdNYXJjYS9Nb2RlbG8vQW1wJyB9XG4gICAgICAgICAgICAgIF0ubWFwKChwKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXRlbURhdGEgPSBwYXJhbWV0cm9zRWxlY3RyaWNvc1twLmtleV0gfHwge307XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3Aua2V5fSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS05MDAvMzAgcHJpbnQ6aG92ZXI6YmctdHJhbnNwYXJlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtMyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMjAwIHByaW50OnRleHQtc2xhdGUtODAwXCI+e3AubGFiZWx9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW1EYXRhLm5vbWluYWwgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZVBhcmFtZXRybyhwLmtleSwgJ25vbWluYWwnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17cC5kZWZOb21pbmFsfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgZm9udC1tb25vIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW1EYXRhLm1lZGlkbyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlUGFyYW1ldHJvKHAua2V5LCAnbWVkaWRvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJNZWRpZG8gLyBBanVzdGFkb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMSB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBmb250LW1vbm8gcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMiBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbURhdGEubm90YXMgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZVBhcmFtZXRybyhwLmtleSwgJ25vdGFzJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJPYnNlcnZhY2lvbmVzLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiAzLiBSRUdJU1RSTyBUw4lDTklDTyBERSBHQVZFVEFTIC8gQ09NUEFSVElNRU5UT1MgKEJVQ0tFVCBMT0cpICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgcm91bmRlZC0yeGwgcC01IHNwYWNlLXktNCBwcmludDpiZy13aGl0ZSBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0yLjUgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWFtYmVyLTUwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwcmludDp0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgPExheWVycyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz4gMy4gUmVnaXN0cm8gVMOpY25pY28gZGUgR2F2ZXRhcyAvIENvbXBhcnRpbWVudG9zIChCdWNrZXQgTG9nKVxuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXthZGRHYXZldGF9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJuby1wcmludCBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtYW1iZXItNDAwIGZvbnQtYm9sZCBweC0zIHB5LTEuNSByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBBZ3JlZ2FyIEdhdmV0YVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHRleHQteHMgYm9yZGVyLWNvbGxhcHNlXCI+XG4gICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS00MDAgdGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHJpbnQ6Ymctc2xhdGUtMTAwIHByaW50OnRleHQtc2xhdGUtNzAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMi41IHctMTZcIj5HYXZldGE8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMi41XCI+VGFnIEVxdWlwbyAvIE1vdG9yPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTIuNSB3LTIwXCI+SFAgLyBrVzwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0yLjVcIj5UaXBvIEFycmFucXVlPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTIuNVwiPlByb3RlY2Npw7NuIC8gQnJlYWtlcjwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0yLjVcIj5NYXJjYS9Nb2RlbG8gVkZEIG8gQXJyYW5jYWRvcjwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0yLjVcIj5SZWQgLyBDb21tczwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0yLjVcIj5Fc3RhZG8gLyBPYnMuPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTIgdy0xMCBuby1wcmludFwiPjwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS04MDAvNjAgcHJpbnQ6ZGl2aWRlLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgIHtkZWZhdWx0R2F2ZXRhcy5tYXAoKGcpID0+IChcbiAgICAgICAgICAgICAgICA8dHIga2V5PXtnLmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS05MDAvMzAgcHJpbnQ6aG92ZXI6YmctdHJhbnNwYXJlbnRcIj5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnLmdhdmV0YX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUdhdmV0YShnLmlkLCAnZ2F2ZXRhJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLWxnIHB4LTIgcHktMSB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBmb250LW1vbm8gZm9udC1ib2xkIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2cudGFnRXF1aXBvfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlR2F2ZXRhKGcuaWQsICd0YWdFcXVpcG8nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFai4gQm9tYmEgQWd1YSBQb3RhYmxlXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC1sZyBweC0yIHB5LTEgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMiBweC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zy5ocEt3fVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlR2F2ZXRhKGcuaWQsICdocEt3JywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMjUgSFBcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLWxnIHB4LTIgcHktMSB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBmb250LW1vbm8gcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMiBweC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zy50aXBvQXJyYW5xdWV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVHYXZldGEoZy5pZCwgJ3RpcG9BcnJhbnF1ZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRPTCAvIFZGRCAvIFNvZnRTdGFydFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQtbGcgcHgtMiBweS0xIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2cucHJvdGVjY2lvbn1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUdhdmV0YShnLmlkLCAncHJvdGVjY2lvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkd1YXJkYW1vdG9yIDMyQVwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQtbGcgcHgtMiBweS0xIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2cubWFyY2FNb2RlbG9WZmR9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVHYXZldGEoZy5pZCwgJ21hcmNhTW9kZWxvVmZkJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUG93ZXJGbGV4IDUyNSAvIE4vQVwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQtbGcgcHgtMiBweS0xIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIgcHgtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2cucmVkQ29tbXN9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVHYXZldGEoZy5pZCwgJ3JlZENvbW1zJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXRoZXJOZXQvSVAgLyBNb2RidXNcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLWxnIHB4LTIgcHktMSB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTkwMCBwcmludDpib3JkZXItZ3JheS0zMDBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yIHB4LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnLmVzdGFkb09ic31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUdhdmV0YShnLmlkLCAnZXN0YWRvT2JzJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiT3BlcmF0aXZvIC8gTWFudGVuaW0uXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC1sZyBweC0yIHB5LTEgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMiBweC0xIHRleHQtY2VudGVyIG5vLXByaW50XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0V2l6YXJkTW9kbygnU0FMSURBJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldENpcmN1aXREYXRhV2l6YXJkKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogZy5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBub21icmU6IGBHYXZldGEgJHtnLmdhdmV0YX0gKCR7Zy50YWdFcXVpcG8gfHwgJ1NpbiBUYWcnfSlgLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVxdWlwbzogZy50YWdFcXVpcG8gfHwgJycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9sZXM6IFsxXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVha2VyOiB7IGFtcDogZy5wcm90ZWNjaW9uIHx8ICcnLCBtYXJjYTogJycsIHRpcG86ICcnIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldE1vZGFsSmVyYXJxdWlhT3Blbih0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgaG92ZXI6YmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItNDAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJDb25maWd1cmFyIENvbmV4acOzbiAvIENhcmdhIChXaXphcmQpXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2V0dGluZ3MgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZGVsZXRlR2F2ZXRhKGcuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIGhvdmVyOmJnLXJlZC05NTUvMjAgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1yZWQtNDAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFbGltaW5hciBHYXZldGFcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiA0LiBJTlNQRUNDScOTTiBGw41TSUNBIFkgQU1CSUVOVEFMIERFTCBHQUJJTkVURSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHJvdW5kZWQtMnhsIHAtNSBzcGFjZS15LTQgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci01MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0yLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgPEFjdGl2aXR5IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPiA0LiBJbnNwZWNjacOzbiBGw61zaWNhIHkgQW1iaWVudGFsIGRlbCBHYWJpbmV0ZVxuICAgICAgICA8L2gzPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAge1tcbiAgICAgICAgICAgIHsga2V5OiAnbGltcGllemFQb2x2bycsIGxhYmVsOiAnTGltcGllemEgSW50ZXJuYSAvIFBvbHZvJywgb3B0aW9uczogWydCdWVuYScsICdBY2VwdGFibGUnLCAnUG9sdm8gLyBBY3VtdWxhY2nDs24gQ3LDrXRpY2EnXSB9LFxuICAgICAgICAgICAgeyBrZXk6ICdodW1lZGFkQWd1YScsIGxhYmVsOiAnSHVtZWRhZCAvIEV2aWRlbmNpYSBkZSBBZ3VhJywgb3B0aW9uczogWydBdXNlbnRlJywgJ0ZpbHRyYWNpw7NuIFN1cGVyaW9yJywgJ0NvbmRlbnNhY2nDs24nXSB9LFxuICAgICAgICAgICAgeyBrZXk6ICdhY29tZXRpZGFDYWJsZXMnLCBsYWJlbDogJ0Fjb21ldGlkYSAvIEVudHJhZGEgQ2FibGVzJywgb3B0aW9uczogWydTdXBlcmlvcicsICdJbmZlcmlvciddIH0sXG4gICAgICAgICAgICB7IGtleTogJ3ZlbnRpbGFjaW9uJywgbGFiZWw6ICdWZW50aWxhY2nDs24geSBFeHRyYWNjacOzbicsIG9wdGlvbnM6IFsnT3BlcmF0aXZvJywgJ0ZpbHRyb3MgT2JzdHJ1aWRvcycsICdJbm9wZXJhdGl2byddIH0sXG4gICAgICAgICAgICB7IGtleTogJ3B1ZXN0YVRpZXJyYScsIGxhYmVsOiAnUHVlc3RhIGEgVGllcnJhIChNYWxsYSBHZW5lcmFsKScsIG9wdGlvbnM6IFsnQ29uZWN0YWRhIHkgQWp1c3RhZGEnLCAnQ29ycm/DrWRhJywgJ0Rlc2NvbmVjdGFkYSddIH1cbiAgICAgICAgICBdLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgZGF0YU9iaiA9IGluc3BlY2Npb25GaXNpY2FbaXRlbS5rZXldIHx8IHt9O1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2l0ZW0ua2V5fSBjbGFzc05hbWU9XCJwLTMuNSBiZy1zbGF0ZS05MDAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgcm91bmRlZC14bCBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcHJpbnQ6YmctZ3JheS01MCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTIwMCB3LTQ4IHByaW50OnRleHQtc2xhdGUtODAwXCI+e2l0ZW0ubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLm9wdGlvbnMubWFwKChvcHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IGRhdGFPYmouZXN0YWRvID09PSBvcHQ7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHR9XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUluc3BlY2Npb25GaXNpY2EoaXRlbS5rZXksICdlc3RhZG8nLCBvcHQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgcm91bmRlZC1sZyBib3JkZXIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgYm9yZGVyLWFtYmVyLTUwMCBzaGFkb3ctbWQgcHJpbnQ6YmctYW1iZXItMTAwIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1hbWJlci02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTcwMCBwcmludDpib3JkZXItZ3JheS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBbIHtpc1NlbGVjdGVkID8gJ+KckycgOiAnICd9IF0ge29wdH1cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2RhdGFPYmoub2JzZXJ2YWNpb25lcyB8fCAnJ31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlSW5zcGVjY2lvbkZpc2ljYShpdGVtLmtleSwgJ29ic2VydmFjaW9uZXMnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk9ic2VydmFjaW9uZXMgZXNwZWPDrWZpY2FzLi4uXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy1bMjAwcHhdIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0xLjUgdGV4dC14cyB0ZXh0LXNsYXRlLTEwMCBvdXRsaW5lLW5vbmUgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG5cbiAgICAgICAgICB7LyogQ2FtcG8gRXNwZWNpYWw6IFRlbXBlcmF0dXJhIEN1YXJ0byBDQ00gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1zbGF0ZS05MDAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgcm91bmRlZC14bCBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcHJpbnQ6YmctZ3JheS01MCBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwIHctNDggcHJpbnQ6dGV4dC1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICA8VGhlcm1vbWV0ZXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+IFRlbXBlcmF0dXJhIEN1YXJ0byBDQ01cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPk1lZGlkYTo8L3NwYW4+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17aW5zcGVjY2lvbkZpc2ljYS50ZW1wZXJhdHVyYU1lZGlkYSB8fCAnJ31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZUZpZWxkKCdpbnNwZWNjaW9uRmlzaWNhJywgeyAuLi5pbnNwZWNjaW9uRmlzaWNhLCB0ZW1wZXJhdHVyYU1lZGlkYTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIyNCDCsENcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMjQgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvY3VzOmJvcmRlci1hbWJlci01MDAgcm91bmRlZC14bCBweC0yLjUgcHktMSB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIGZvbnQtbW9ubyBvdXRsaW5lLW5vbmUgcHJpbnQ6Ymctd2hpdGUgcHJpbnQ6dGV4dC1zbGF0ZS05MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBwcmludDp0ZXh0LXNsYXRlLTcwMCBtbC0yXCI+QWlyZSBBY29uZGljaW9uYWRvOjwvc3Bhbj5cbiAgICAgICAgICAgICAge1snU8OtJywgJ05vJ10ubWFwKChvcHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gaW5zcGVjY2lvbkZpc2ljYS5haXJlQWNvbmRpY2lvbmFkbyA9PT0gb3B0O1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGtleT17b3B0fVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlRmllbGQoJ2luc3BlY2Npb25GaXNpY2EnLCB7IC4uLmluc3BlY2Npb25GaXNpY2EsIGFpcmVBY29uZGljaW9uYWRvOiBvcHQgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMSByb3VuZGVkLWxnIGJvcmRlciB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgYm9yZGVyLWFtYmVyLTUwMCBzaGFkb3ctbWQgcHJpbnQ6YmctYW1iZXItMTAwIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1hbWJlci02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItc2xhdGUtNzAwIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtNzAwIHByaW50OmJvcmRlci1ncmF5LTMwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFsge2lzU2VsZWN0ZWQgPyAn4pyTJyA6ICcgJ30gXSB7b3B0fVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIDUuIFNFR1VSSURBRCwgU0XDkUFMw4lUSUNBIFkgVEVSTU9HUkFGw41BIFBSRURJQ1RJVkEgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MC80MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCByb3VuZGVkLTJ4bCBwLTUgc3BhY2UteS00IHByaW50OmJnLXdoaXRlIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNTAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItMi41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz4gNS4gU2VndXJpZGFkLCBTZcOxYWzDqXRpY2EgeSBUZXJtb2dyYWbDrWEgUHJlZGljdGl2YVxuICAgICAgICA8L2gzPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAge1tcbiAgICAgICAgICAgIHsga2V5OiAnYXJjRmxhc2gnLCBsYWJlbDogJ0V0aXF1ZXRhZG8gQXJjIEZsYXNoIChSaWVzZ28pJywgb3B0aW9uczogWydQcmVzZW50ZSB5IExlZ2libGUnLCAnQXVzZW50ZSAvIElsZWdpYmxlJ10gfSxcbiAgICAgICAgICAgIHsga2V5OiAndW5pZmlsYXJQdWVydGEnLCBsYWJlbDogJ0RpYWdyYW1hIFVuaWZpbGFyIGVuIFB1ZXJ0YScsIG9wdGlvbnM6IFsnQWN0dWFsaXphZG8nLCAnRGVzYWN0dWFsaXphZG8nLCAnTm8gRXhpc3RlJ10gfSxcbiAgICAgICAgICAgIHsga2V5OiAnaW50ZXJsb2NrTWVjYW5pY28nLCBsYWJlbDogJ0ludGVybG9jayBNZWPDoW5pY28gZGUgUHVlcnRhcycsIG9wdGlvbnM6IFsnT3BlcmF0aXZvIC8gRnVuY2lvbmFsJywgJ0ZvcnphZG8gLyBJbm9wZXJhdGl2byddIH0sXG4gICAgICAgICAgICB7IGtleTogJ2luc3BlY2Npb25UZXJtb2dyYWZpY2EnLCBsYWJlbDogJ0luc3BlY2Npw7NuIFRlcm1vZ3LDoWZpY2EnLCBvcHRpb25zOiBbJ1NpbiBQdW50b3MgQ2FsaWVudGVzJywgJ1B1bnRvIENhbGllbnRlIERldGVjdGFkbyddIH1cbiAgICAgICAgICBdLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgZGF0YU9iaiA9IHNlZ3VyaWRhZFRlcm1vZ3JhZmlhW2l0ZW0ua2V5XSB8fCB7fTtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtpdGVtLmtleX0gY2xhc3NOYW1lPVwicC0zLjUgYmctc2xhdGUtOTAwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHJvdW5kZWQteGwgZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHByaW50OmJnLWdyYXktNTAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDAgdy01MiBwcmludDp0ZXh0LXNsYXRlLTgwMFwiPntpdGVtLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICB7aXRlbS5vcHRpb25zLm1hcCgob3B0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBkYXRhT2JqLmVzdGFkbyA9PT0gb3B0O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17b3B0fVxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB1cGRhdGVTZWd1cmlkYWQoaXRlbS5rZXksICdlc3RhZG8nLCBvcHQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgcm91bmRlZC1sZyBib3JkZXIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgYm9yZGVyLWFtYmVyLTUwMCBzaGFkb3ctbWQgcHJpbnQ6YmctYW1iZXItMTAwIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1hbWJlci02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCBwcmludDpiZy13aGl0ZSBwcmludDp0ZXh0LXNsYXRlLTcwMCBwcmludDpib3JkZXItZ3JheS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBbIHtpc1NlbGVjdGVkID8gJ+KckycgOiAnICd9IF0ge29wdH1cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2RhdGFPYmouZGV0YWxsZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlU2VndXJpZGFkKGl0ZW0ua2V5LCAnZGV0YWxsZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGV0YWxsZSAvIFJlZ2lzdHJvIGRlIEFub21hbMOtYS4uLlwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctWzIwMHB4XSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMS41IHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogNi4gT0JTRVJWQUNJT05FUyBZIEhBTExBWkdPUyBDUsONVElDT1MgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MC80MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCByb3VuZGVkLTJ4bCBwLTUgc3BhY2UteS00IHByaW50OmJnLXdoaXRlIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTIuNSBwcmludDpib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYW1iZXItNTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHByaW50OnRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+IDYuIE9ic2VydmFjaW9uZXMgeSBIYWxsYXpnb3MgQ3LDrXRpY29zXG4gICAgICAgICAgPC9oMz5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2FkZEhhbGxhemdvfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibm8tcHJpbnQgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LWFtYmVyLTQwMCBmb250LWJvbGQgcHgtMyBweS0xLjUgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gQWdyZWdhciBIYWxsYXpnb1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMi41XCI+XG4gICAgICAgICAge2RlZmF1bHRIYWxsYXpnb3MubWFwKChoKSA9PiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17aC5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYW1iZXItNTAwIHByaW50OmJnLWdyYXktMTAwIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIHtoLml0ZW1OdW19XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtoLmRlc2NyaXBjaW9ufVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlSGFsbGF6Z28oaC5pZCwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3JpcGNpw7NuIGRlbCBoYWxsYXpnbyBjcsOtdGljbyBvIHJlY29tZW5kYWNpw7NuIGRlIG1hbnRlbmltaWVudG8uLi5cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIHRyYW5zaXRpb24tYWxsIHByaW50OmJnLXdoaXRlIHByaW50OnRleHQtc2xhdGUtOTAwIHByaW50OmJvcmRlci1ncmF5LTMwMFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBkZWxldGVIYWxsYXpnbyhoLmlkKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgaG92ZXI6YmctcmVkLTk1NS80MCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXJlZC00MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBuby1wcmludFwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJFbGltaW5hciBIYWxsYXpnb1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIDcuIENPTlRST0wgREUgUkVHSVNUUk8gWSBGSVJNQVMgREUgQ09ORk9STUlEQUQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MC80MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCByb3VuZGVkLTJ4bCBwLTUgc3BhY2UteS00IHByaW50OmJnLXNsYXRlLTUwIHByaW50OmJvcmRlci1ncmF5LTMwMCBwcmludDptdC00XCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMCBwYi0yLjUgcHJpbnQ6dGV4dC1zbGF0ZS03MDAgcHJpbnQ6Ym9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgNy4gQ29udHJvbCBkZSBSZWdpc3RybyB5IEZpcm1hcyBkZSBDb25mb3JtaWRhZFxuICAgICAgICA8L2gzPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxuICAgICAgICAgIHsvKiBGaXJtYSBJbnNwZWN0b3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yIGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHByaW50OnRleHQtc2xhdGUtNzAwXCI+UmVhbGl6YWRvIHBvciAoSW5zcGVjdG9yIGRlIENhbXBvKTwvc3Bhbj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmaXJtYUluc3BlY3Rvcn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWVsZCgnZmlybWFJbnNwZWN0b3InLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy14cyBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMTAwIG91dGxpbmUtbm9uZSBoLTEwIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyIG5vLXByaW50XCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJGaXJtYSAvIE5vbWJyZSBkZWwgSW5zcGVjdG9yXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gcHJpbnQ6YmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbXQtMSBoLTZcIj5cbiAgICAgICAgICAgICAge2Zpcm1hSW5zcGVjdG9yIHx8ICdfX19fX19fX19fX19fX19fX19fX19fX19fX18nfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gcHJpbnQ6YmxvY2sgdy00OCBib3JkZXItYiBib3JkZXItZ3JheS00MDAgbXQtNiBoLTFcIj48L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBGaXJtYSBTdXBlcnZpc29yICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMiBpdGVtcy1jZW50ZXIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBwcmludDp0ZXh0LXNsYXRlLTcwMFwiPlJldmlzYWRvIHkgQXByb2JhZG8gcG9yIChTdXBlcnZpc29yKTwvc3Bhbj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmaXJtYVN1cGVydmlzb3J9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmllbGQoJ2Zpcm1hU3VwZXJ2aXNvcicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmb2N1czpib3JkZXItYW1iZXItNTAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgb3V0bGluZS1ub25lIGgtMTAgdHJhbnNpdGlvbi1hbGwgdGV4dC1jZW50ZXIgbm8tcHJpbnRcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkZpcm1hIC8gTm9tYnJlIGRlbCBTdXBlcnZpc29yXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gcHJpbnQ6YmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbXQtMSBoLTZcIj5cbiAgICAgICAgICAgICAge2Zpcm1hU3VwZXJ2aXNvciB8fCAnX19fX19fX19fX19fX19fX19fX19fX19fX19fJ31cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHByaW50OmJsb2NrIHctNDggYm9yZGVyLWIgYm9yZGVyLWdyYXktNDAwIG10LTYgaC0xXCI+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxNb2RhbEVkaWNpb25DaXJjdWl0b1xuICAgICAgICBpc09wZW49e21vZGFsSmVyYXJxdWlhT3Blbn1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0TW9kYWxKZXJhcnF1aWFPcGVuKGZhbHNlKX1cbiAgICAgICAgY2lyY3VpdERhdGE9e2NpcmN1aXREYXRhV2l6YXJkfVxuICAgICAgICBtb2RvPXt3aXphcmRNb2RvfVxuICAgICAgICB0aXBvT3JpZ2VuPVwiQ0NNXCJcbiAgICAgICAgZWxlbWVudG9zQ3JlYWRvcz17W119XG4gICAgICAgIG9uU2F2ZT17KGNpcmN1aXRJZCwgdXBkYXRlZCkgPT4ge1xuICAgICAgICAgIGlmICh1cGRhdGVkLnRpcG9EZXN0aW5vID09PSAnU1VCX1RBQkxFUk9fUEVORElFTlRFJyAmJiBjY21EYXRhLnByb3llY3RvSWQpIHtcbiAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nUHJvdklkID0gdXBkYXRlZC5lbGVtZW50b0Rlc3Rpbm9JZCB8fCB1cGRhdGVkLnZpbmN1bGFkb0lkO1xuICAgICAgICAgICAgbGV0IHByb3YgPSBudWxsO1xuICAgICAgICAgICAgaWYgKGV4aXN0aW5nUHJvdklkKSB7XG4gICAgICAgICAgICAgIHByb3YgPSAoY29tcGFuaWVzIHx8IFtdKS5mbGF0TWFwKGMgPT4gYy5wcm95ZWN0b3MgfHwgW10pLmZsYXRNYXAocCA9PiBwLmVsZW1lbnRvc1VuaWZpbGFyZXMgfHwgcC50YWJsZXJvcyB8fCBbXSkuZmluZChlID0+IGUuaWQgPT09IGV4aXN0aW5nUHJvdklkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghcHJvdikge1xuICAgICAgICAgICAgICBwcm92ID0gY3JlYXJFbGVtZW50b1Byb3Zpc2lvbmFsKGNjbURhdGEucHJveWVjdG9JZCwge1xuICAgICAgICAgICAgICAgIG5vbWJyZTogdXBkYXRlZC5lcXVpcG8gJiYgdXBkYXRlZC5lcXVpcG8gIT09ICdSRVNFUlZBIChQZW5kaWVudGUgcG9yIENyZWFyKScgPyB1cGRhdGVkLmVxdWlwbyA6IGBTdWItVGFibGVybyBkZXNkZSBDQ00gKCR7Y2lyY3VpdElkfSlgLFxuICAgICAgICAgICAgICAgIHRpcG9FbGVtZW50bzogJ1RBQkxFUk8nLFxuICAgICAgICAgICAgICAgIGNpcmN1aXRvT3JpZ2VuOiBjaXJjdWl0SWRcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocHJvdikge1xuICAgICAgICAgICAgICB1cGRhdGVkLnZpbmN1bGFkb0lkID0gcHJvdi5pZDtcbiAgICAgICAgICAgICAgdXBkYXRlZC5lbGVtZW50b0Rlc3Rpbm9JZCA9IHByb3YuaWQ7XG4gICAgICAgICAgICAgIHVwZGF0ZWQudGlwb0VsZW1lbnRvRGVzdGlubyA9ICdUQUJMRVJPJztcbiAgICAgICAgICAgICAgdXBkYXRlZC5lcXVpcG8gPSBgJHtwcm92Lm5vbWJyZX0gKElEOiAke3Byb3YuaWR9KWA7XG4gICAgICAgICAgICAgIHVwZGF0ZWQudGlwb0Rlc3Rpbm8gPSAnU1VCX1RBQkxFUk8nO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodXBkYXRlZC5lcXVpcG8pIHVwZGF0ZUdhdmV0YShjaXJjdWl0SWQsICd0YWdFcXVpcG8nLCB1cGRhdGVkLmVxdWlwbyk7XG4gICAgICAgICAgaWYgKHVwZGF0ZWQuZGV0YWxsZXNUZWNuaWNvcz8uZXNxdWVtYUFycmFucXVlKSB1cGRhdGVHYXZldGEoY2lyY3VpdElkLCAndGlwb0FycmFucXVlJywgdXBkYXRlZC5kZXRhbGxlc1RlY25pY29zLmVzcXVlbWFBcnJhbnF1ZSk7XG4gICAgICAgICAgaWYgKHVwZGF0ZWQuZGV0YWxsZXNUZWNuaWNvcz8uaHBLdykgdXBkYXRlR2F2ZXRhKGNpcmN1aXRJZCwgJ2hwS3cnLCB1cGRhdGVkLmRldGFsbGVzVGVjbmljb3MuaHBLdyk7XG4gICAgICAgICAgaWYgKHVwZGF0ZWQuZGV0YWxsZXNUZWNuaWNvcz8ucHJvdGVjY2lvbiB8fCB1cGRhdGVkLmJyZWFrZXI/LmFtcCkgdXBkYXRlR2F2ZXRhKGNpcmN1aXRJZCwgJ3Byb3RlY2Npb24nLCB1cGRhdGVkLmRldGFsbGVzVGVjbmljb3M/LnByb3RlY2Npb24gfHwgdXBkYXRlZC5icmVha2VyPy5hbXApO1xuICAgICAgICAgIGlmICh1cGRhdGVkLmRldGFsbGVzVGVjbmljb3M/LnJlZENvbW1zKSB1cGRhdGVHYXZldGEoY2lyY3VpdElkLCAncmVkQ29tbXMnLCB1cGRhdGVkLmRldGFsbGVzVGVjbmljb3MucmVkQ29tbXMpO1xuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgIDwvZGl2PlxuICApO1xufVxuIl19